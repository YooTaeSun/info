package com.townsi.table.dao;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.townsi.boot.AbstractDAO4;

@Repository("tableDAO4")
public class TableDAO4 extends AbstractDAO4 {
	public List<HashMap> list_mysql(HashMap vo) throws Exception {
		return selectList("com.townsi.table.tableDAO.selectList_mysql", vo);
	}
	
	public List<HashMap> list_oracle(HashMap vo) throws Exception {
		return selectList("com.townsi.table.tableDAO.selectList_oracle", vo);
	}
}