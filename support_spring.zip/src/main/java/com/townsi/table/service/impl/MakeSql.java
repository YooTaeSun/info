package com.townsi.table.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.townsi.utils.FileUtil;
import com.townsi.utils.StrUtil;

@Service("makeSql")
@SuppressWarnings({"rawtypes","unchecked"})
public class MakeSql {

	public static String READ_LINE = "\n";
	public static String TAB = "\t";
	public static String SLASH = File.separator;// lastIndexOf("/")

	@Resource(name = "propMap")
	private HashMap<String, String> propMap;

	public HashMap<String, Object> source(HashMap vo, List<HashMap> list) throws Exception {
		HashMap dataMap = new HashMap();
		try {
			String excludePackagePath = (String) this.propMap.get("excludePackagePath");

			String tableName = (String) vo.get("tableName");
			String bizName = (String) vo.get("bizName");
			String bizNameFirstUp = (String) vo.get("bizNameFirstUp");;
			String bizNameFirstLower = (String) vo.get("bizNameFirstLower");

			String sampleBizName = (String) vo.get("sampleBizName");
			String sampleBizNameFirstUp = (String) vo.get("sampleBizNameFirstUp");
			String sampleBizNameFirstLower = (String) vo.get("sampleBizNameFirstLower");

			String rBasePath = (String) vo.get("rBasePath");
			String wBasePath = (String) vo.get("wBasePath");

			HashMap replaceMap = new HashMap();

			replaceMap.put(sampleBizNameFirstUp, bizNameFirstUp);
			replaceMap.put(sampleBizNameFirstLower, bizNameFirstLower);

			String desc = (String) vo.get("desc");
			replaceMap.put("#desc#", desc);
			String since = (String) vo.get("since");
			replaceMap.put("#since#", since);
			String author = (String) vo.get("author");
			replaceMap.put("#author#", author);
			
			String menuId = (String) vo.get("menuId");
//			replaceMap.put("#menuId#", menuId);
			String serviceId = (String) vo.get("author");
//			replaceMap.put("#serviceId#", serviceId);

			String mapperName = "";
			String wDaoMAPPER = (String) vo.get("wDaoMAPPER");
			if (wDaoMAPPER.lastIndexOf("/") > -1)
				mapperName = wDaoMAPPER.substring(wDaoMAPPER.lastIndexOf("/") + 1, wDaoMAPPER.length());
			else {
				mapperName = wDaoMAPPER;
			}
			mapperName = mapperName.replace(".xml", "");

			StringBuilder selectSql = new StringBuilder(500);
			StringBuilder selectFieldSql = new StringBuilder(500);
			StringBuilder insertSql = new StringBuilder(500);
			StringBuilder insertValSql = new StringBuilder(500);
			StringBuilder updateSql = new StringBuilder(500);
			List pkList = new ArrayList();

			String mybatisIsCamelCase = (String) vo.get("mybatisIsCamelCase");

			String ORDINAL_POSITION = "";
			String COLUMN_NAME = "";
			String CAMEL_COLUMN_NAME = "";
			String COLUMN_COMMENT = "";
			String _COLUMN_COMMENT = "";
			String COLUMN_KEY = "";
			String COLUMN_TYPE = "";
			String COLUMN_DEFAULT = "";
			String AUTO_INCREMENT = "";

			for (HashMap rs : list) {
				ORDINAL_POSITION = String.valueOf(rs.get("ORDINAL_POSITION"));
				COLUMN_NAME = (String) rs.get("COLUMN_NAME");

				COLUMN_COMMENT = (String) rs.get("COLUMN_COMMENT");
				_COLUMN_COMMENT = !"".equals(COLUMN_COMMENT) ? "/* " + COLUMN_COMMENT + " */ " : "";
				COLUMN_KEY = (String) rs.get("COLUMN_KEY");

				COLUMN_TYPE = (String) rs.get("COLUMN_TYPE");
				COLUMN_DEFAULT = (String) rs.get("COLUMN_DEFAULT");

				if ("0".equals(ORDINAL_POSITION)) {
					AUTO_INCREMENT = (String) rs.get("AUTO_INCREMENT");
				} else {
					String columnNameFirstUp = StrUtil.toCamelCase(COLUMN_NAME);
					columnNameFirstUp = columnNameFirstUp.substring(0, 1).toUpperCase()
							+ columnNameFirstUp.substring(1);
					String columnNameLower = columnNameFirstUp.substring(0, 1).toLowerCase()
							+ columnNameFirstUp.substring(1);

					if (("INSERT_DT".equals(COLUMN_NAME)) || ("UPDATE_DT".equals(COLUMN_NAME))) {
						CAMEL_COLUMN_NAME = "NOW()";
						insertValSql.append("\t," + CAMEL_COLUMN_NAME + READ_LINE);
						updateSql.append(StrUtil.alignLine("\t," + COLUMN_NAME + " = " + CAMEL_COLUMN_NAME + "\t\t\t",
								_COLUMN_COMMENT + READ_LINE, 50));
					} else if (("INSERT_ID".equals(COLUMN_NAME)) || ("UPDATE_ID".equals(COLUMN_NAME))) {
						CAMEL_COLUMN_NAME = "loginIDInSession";

						insertValSql.append("\t,[:" + CAMEL_COLUMN_NAME + "]" + READ_LINE);
						updateSql
								.append(StrUtil.alignLine("\t," + COLUMN_NAME + " = #{" + CAMEL_COLUMN_NAME + "}\t\t\t",
										_COLUMN_COMMENT + READ_LINE, 50));
					} else {
						CAMEL_COLUMN_NAME = "Y".equals(mybatisIsCamelCase) ? StrUtil.toCamelCase(COLUMN_NAME)
								: COLUMN_NAME;

						insertValSql.append("\t,[:" + CAMEL_COLUMN_NAME + "]" + READ_LINE);
						updateSql
								.append(StrUtil.alignLine("\t," + "[:" + COLUMN_NAME + " = " + CAMEL_COLUMN_NAME + ",]\t\t\t",
										_COLUMN_COMMENT + READ_LINE, 50));
					}

					selectSql.append(StrUtil.alignLine(StrUtil.alignLine("\t," + COLUMN_NAME, " AS ", 20),
							columnNameLower + "\t\t\t" + _COLUMN_COMMENT + READ_LINE, 20));
					selectFieldSql.append(StrUtil.alignLine(StrUtil.alignLine("\t,A." + COLUMN_NAME, " AS ", 20),
							columnNameLower + "\t\t\t" + _COLUMN_COMMENT + READ_LINE, 20));

					insertSql
							.append(StrUtil.alignLine("\t," + COLUMN_NAME + "\t\t\t", _COLUMN_COMMENT + READ_LINE, 50));

					if ("PK".equals(COLUMN_KEY)) {
						pkList.add(COLUMN_NAME);
					}

				}

			}

			String pk = "";
			String pk_camel = "";
			String pkStr = "";
			for (int pi = 0; pi < pkList.size(); pi++) {
				pk = (String) pkList.get(pi);
				pk_camel = "Y".equals(mybatisIsCamelCase) ? StrUtil.toCamelCase(pk) : pk;
				pkStr = pkStr + "AND " + pk + " = [:" + pk_camel + "] " + READ_LINE;
			}

			HashMap replaceMapperMap = new HashMap();
			replaceMapperMap.put("#desc#", desc);
			String rDaoMAPPER = rBasePath + File.separator + (String) vo.get("rDaoMAPPER");

			String wDaoMAPPERFullPath = wBasePath + File.separator + wDaoMAPPER;

			String wDaoMAPPERPackageFullPath = wBasePath.replace(excludePackagePath, "") + File.separator
					+ wDaoMAPPER.substring(0, wDaoMAPPER.lastIndexOf(SLASH));
			String wDaoMAPPERPackagePath = wDaoMAPPERPackageFullPath.replace(SLASH, ".");
			replaceMapperMap.put("#package#", wDaoMAPPERPackagePath);
			replaceMapperMap.put("#mapperName#", mapperName);

			replaceMapperMap.put("#select#", "SELECT " + READ_LINE + selectSql.toString().replaceFirst(",", " ")
					+ "FROM " + tableName + READ_LINE + "WHERE 1=1 \n" + pkStr);
			replaceMapperMap.put("#select_field#", selectFieldSql.toString().replaceFirst(",", " "));

			if ("N".equals(AUTO_INCREMENT))
				replaceMapperMap.put("#increment#", "");
			else {
				replaceMapperMap.put("#increment#",
						"useGeneratedKeys=\"true\" keyProperty=\"" + StrUtil.toCamelCase(pk) + "\"");
			}

			replaceMapperMap.put("#insert#",
					"INSERT /* " + mapperName + ".xml, insert */\nINTO " + tableName + " (\n"
							+ insertSql.toString().replaceFirst(",", " ") + ") VALUES (" + READ_LINE
							+ insertValSql.toString().replaceFirst(",", " ") + ")");
			replaceMapperMap.put("#update#",
					"UPDATE  /* " + mapperName + ".xml, update */" + READ_LINE + "\t" + tableName + " SET" + READ_LINE
							+ updateSql.toString().replaceFirst(",", " ") + "WHERE 1=1 " + READ_LINE + pkStr);
			replaceMapperMap.put("#delete#", "DELETE  /* " + mapperName + ".xml, delete */" + READ_LINE + "FROM "
					+ tableName + READ_LINE + " WHERE 1=1 " + READ_LINE + pkStr);

			FileUtil.copyFile(rDaoMAPPER, wDaoMAPPERFullPath, replaceMapperMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dataMap;
	}
}