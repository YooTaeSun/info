package com.townsi.table.service;

import java.util.HashMap;

public abstract interface TableService {
	public abstract HashMap<String, Object> source(HashMap paramHashMap) throws Exception;

	public abstract HashMap<String, Object> list(HashMap paramHashMap) throws Exception;
}