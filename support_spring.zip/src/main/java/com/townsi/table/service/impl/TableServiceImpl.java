package com.townsi.table.service.impl;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.townsi.table.dao.TableDAO1;
import com.townsi.table.dao.TableDAO2;
import com.townsi.table.dao.TableDAO3;
import com.townsi.table.dao.TableDAO4;
import com.townsi.table.service.TableService;

@Service("tableService")
@SuppressWarnings({"rawtypes","unchecked"})
public class TableServiceImpl implements TableService {

	@Resource(name = "tableDAO1")
	private TableDAO1 tableDAO1;
	
	@Resource(name = "tableDAO2")
	private TableDAO2 tableDAO2;
	
	@Resource(name = "tableDAO3")
	private TableDAO3 tableDAO3;
	
	@Resource(name = "tableDAO4")
	private TableDAO4 tableDAO4;
	
	@Resource(name = "makeSql")
	private MakeSql makeSql;
	
	public static String READ_LINE = "\n";
	public static String TAB = "\t";
	public static String SLASH = File.separator;// lastIndexOf("/")

	@Resource(name = "propMap")
	private HashMap<String, String> propMap;

	public HashMap<String, Object> source(HashMap vo) throws Exception {
		HashMap dataMap = new HashMap();
		try {
			String excludePackagePath = (String) this.propMap.get("excludePackagePath");

			String bizName = (String) vo.get("bizName");
			String bizNameFirstUp = bizName.substring(0, 1).toUpperCase() + bizName.substring(1);
			vo.put("bizNameFirstUp", bizNameFirstUp);
			String bizNameFirstLower = bizName.substring(0, 1).toLowerCase() + bizName.substring(1);
			vo.put("bizNameFirstLower", bizNameFirstLower);

			String sampleBizName = (String) vo.get("sampleBizName");
			String sampleBizNameFirstUp = sampleBizName.substring(0, 1).toUpperCase() + sampleBizName.substring(1);
			vo.put("sampleBizNameFirstUp", sampleBizNameFirstUp);
			String sampleBizNameFirstLower = sampleBizName.substring(0, 1).toLowerCase() + sampleBizName.substring(1);
			vo.put("sampleBizNameFirstLower", sampleBizNameFirstLower);

//			String rBasePath = (String) vo.get("rBasePath");
//			String wBasePath = (String) vo.get("wBasePath");

//			HashMap replaceMap = new HashMap();

//			replaceMap.put(sampleBizNameFirstUp, bizNameFirstUp);
//			replaceMap.put(sampleBizNameFirstLower, bizNameFirstLower);

//			String desc = (String) vo.get("desc");
//			replaceMap.put("#desc#", desc);
//			String since = (String) vo.get("since");
//			replaceMap.put("#since#", since);
//			String author = (String) vo.get("author");
//			replaceMap.put("#author#", author);

//			String isMakeDTO = (String) vo.get("isMakeDTO");
//			String dtoName = "";
//			if ("Y".equals(isMakeDTO)) {
//				String wDtoFilePath = (String) vo.get("wDtoFilePath");
//				if (wDtoFilePath.lastIndexOf("/") > -1)
//					dtoName = wDtoFilePath.substring(wDtoFilePath.lastIndexOf("/") + 1, wDtoFilePath.length());
//				else {
//					dtoName = wDtoFilePath;
//				}
//				dtoName = dtoName.replace(".java", "");
//			}

//			String mapperName = "";
//			String wDaoMAPPER = (String) vo.get("wDaoMAPPER");
//			if (wDaoMAPPER.lastIndexOf("/") > -1)
//				mapperName = wDaoMAPPER.substring(wDaoMAPPER.lastIndexOf("/") + 1, wDaoMAPPER.length());
//			else {
//				mapperName = wDaoMAPPER;
//			}
//			mapperName = mapperName.replace(".xml", "");

//			String rControllerFilePath = rBasePath + File.separator + (String) vo.get("rControllerFilePath");
//			String wControllerFilePath = (String) vo.get("wControllerFilePath");
//			String wControllerFileFullPath = wBasePath + File.separator + (String) vo.get("wControllerFilePath");
//
//			String wControllerPackageFullPath = wBasePath.replace(excludePackagePath, "") + File.separator
//					+ wControllerFilePath.substring(0, wControllerFilePath.lastIndexOf(SLASH));
//			String wControllerPackagePath = wControllerPackageFullPath.replace(SLASH, ".");
//			replaceMap.put("#package#", wControllerPackagePath);
//			FileUtil.copyFile(rControllerFilePath, wControllerFileFullPath, replaceMap);
//
//			String rServiceFilePath = rBasePath + File.separator + (String) vo.get("rServiceFilePath");
//			String wServiceFilePath = (String) vo.get("wServiceFilePath");
//			String wServiceFileFileFullPath = wBasePath + File.separator + wServiceFilePath;
//
//			String wServiceFilePackageFullPath = wBasePath.replace(excludePackagePath, "") + File.separator
//					+ wServiceFilePath.substring(0, wServiceFilePath.lastIndexOf(SLASH));
//			String wServiceFilePackagePath = wServiceFilePackageFullPath.replace(SLASH, ".");
//			replaceMap.put("#package#", wServiceFilePackagePath);
//			FileUtil.copyFile(rServiceFilePath, wServiceFileFileFullPath, replaceMap);
//
//			if (vo.containsKey("rServiceImplFilePath")) {
//				String rServiceImplFilePath = rBasePath + File.separator + (String) vo.get("rServiceImplFilePath");
//				String wServiceImplFilePath = (String) vo.get("wServiceImplFilePath");
//				String wServiceImplFileFileFullPath = wBasePath + File.separator + wServiceImplFilePath;
//
//				String wServiceImplFilePackageFullPath = wBasePath.replace(excludePackagePath, "") + File.separator
//						+ wServiceImplFilePath.substring(0, wServiceImplFilePath.lastIndexOf(SLASH));
//				String wServiceImplFilePackagePath = wServiceImplFilePackageFullPath.replace(SLASH, ".");
//				replaceMap.put("#package#", wServiceImplFilePackagePath);
//				FileUtil.copyFile(rServiceImplFilePath, wServiceImplFileFileFullPath, replaceMap);
//			}
//
//			String rDaoFilePath = rBasePath + File.separator + (String) vo.get("rDaoFilePath");
//			String wDaoFilePath = (String) vo.get("wDaoFilePath");
//			String wDaoFileFileFullPath = wBasePath + File.separator + wDaoFilePath;
//
//			String wDaoFilePackageFullPath = wBasePath.replace(excludePackagePath, "") + File.separator
//					+ wDaoFilePath.substring(0, wDaoFilePath.lastIndexOf(SLASH));
//			String wDaoFilePackagePath = wDaoFilePackageFullPath.replace(SLASH, ".");
//			replaceMap.put("#package#", wDaoFilePackagePath);
//
//			String daoName = "";
//			if (wDaoFilePath.lastIndexOf("/") > -1)
//				daoName = wDaoFilePath.substring(wDaoFilePath.lastIndexOf("/") + 1, wDaoFilePath.length());
//			else {
//				daoName = wDaoFilePath;
//			}
//			daoName = daoName.replace(".java", "");
//			replaceMap.put("#dtoName#", dtoName);
//
//			FileUtil.copyFile(rDaoFilePath, wDaoFileFileFullPath, replaceMap);
			List<HashMap> list = null;
			String owner= (String)vo.get("owner");
			if("CFS".equals(owner)) {
				list = this.tableDAO1.list_oracle(vo);
			}else if("IRS".equals(owner)) {
				list = this.tableDAO2.list_oracle(vo);
			}else if("NTS".equals(owner)) {
				list = this.tableDAO3.list_oracle(vo);
			}else if("NTS2".equals(owner)) {
				list = this.tableDAO4.list_oracle(vo);
			}
			
			dataMap.put("list", list);
			makeSql.source(vo, list);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dataMap;
	}

	public HashMap<String, Object> list(HashMap vo) throws Exception {
		HashMap dataMap = new HashMap();

		return dataMap;
	}
}