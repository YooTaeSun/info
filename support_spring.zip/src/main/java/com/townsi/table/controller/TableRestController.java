package com.townsi.table.controller;

import com.townsi.table.service.TableService;
import java.util.HashMap;
import javax.annotation.Resource;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({ "/table" })
class TableRestController {
	private static Logger logger = Logger.getLogger(TableRestController.class);

	@Resource(name = "tableService")
	private TableService tableService;

	@Value("${resourcePath}")
	private String resourcePath;

	@Resource(name = "propMap")
	private HashMap<String, String> propMap;

	@RequestMapping({ "/source" })
	public ResponseEntity<HashMap> source(@RequestParam HashMap vo, Model model) throws Exception {
		HashMap resultMap = new HashMap();
		ResponseEntity entity = null;
		try {
			resultMap.put("data", this.tableService.source(vo));
			resultMap.put("param", vo);
			entity = new ResponseEntity(resultMap, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			resultMap.put("error", e.getMessage());
			entity = new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return entity;
	}
}