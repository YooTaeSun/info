package com.townsi.boot;

public class DatabaseConfig {

}
