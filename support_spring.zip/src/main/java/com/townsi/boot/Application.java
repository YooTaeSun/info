package com.townsi.boot;

import com.townsi.utils.FileUtil;
import java.io.File;
import java.util.HashMap;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

@SpringBootApplication(scanBasePackages={"com.townsi"})
public class Application extends SpringBootServletInitializer
{

  @Value("${resourcePath}")
  private String resourcePath;

  protected SpringApplicationBuilder configure(SpringApplicationBuilder application)
  {
    return application.sources(new Class[] { Application.class });
  }

  public static void main(String[] args) throws Exception {
    SpringApplication.run(Application.class, args);
  }
  @PostConstruct
  @Bean
  public HashMap<String, String> propMap() { String configFilePath = this.resourcePath + File.separator + "config.properties";
    HashMap propMap = FileUtil.readFileMap(configFilePath);
    return propMap; }

  @Bean
  public SqlSessionTemplate sqlSession(SqlSessionFactory sqlSessionFactory)
  {
    return new SqlSessionTemplate(sqlSessionFactory);
  }
  @Bean
  public SqlSessionFactory sqlSessionFactory(DataSource dataSource) throws Exception {
    SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
    sqlSessionFactoryBean.setDataSource(dataSource);

    sqlSessionFactoryBean.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:com/townsi/**/dao/*DAOMapper.xml"));
    return sqlSessionFactoryBean.getObject();
  }
}