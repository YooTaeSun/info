package com.townsi.setting.service.impl;

import com.townsi.setting.dao.SettingDAO;
import com.townsi.setting.service.SettingService;
import java.util.HashMap;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;

@Service("settingService")
public class SettingServiceImpl
  implements SettingService
{

  @Resource(name="settingDAO")
  private SettingDAO settingDAO;

  public HashMap<String, Object> list(HashMap vo)
    throws Exception
  {
    HashMap dataMap = new HashMap();
    dataMap.put("list", this.settingDAO.list(vo));
    return dataMap;
  }
}