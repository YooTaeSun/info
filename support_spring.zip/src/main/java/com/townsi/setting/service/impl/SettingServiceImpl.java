package com.townsi.setting.service.impl;

import java.util.HashMap;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.townsi.setting.dao.SettingDAO;
import com.townsi.setting.dao.SettingDAO2;
import com.townsi.setting.service.SettingService;

@Service("settingService")
public class SettingServiceImpl implements SettingService {

	@Resource(name = "settingDAO")
	private SettingDAO settingDAO;
	
	@Resource(name = "settingDAO2")
	private SettingDAO2 settingDAO2;

	public HashMap<String, Object> list(HashMap vo) throws Exception {
		HashMap dataMap = new HashMap();
		
		dataMap.put("list", this.settingDAO.list(vo));
		dataMap.put("list", this.settingDAO2.list(vo));
		return dataMap;
	}
}