package com.townsi.setting.controller;

import com.townsi.setting.service.SettingService;
import com.townsi.utils.FileUtil;
import com.townsi.utils.StrUtil;
import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({ "/setting" })
class SettingRestController {
	private static Logger logger = Logger.getLogger(SettingRestController.class);

	@Resource(name = "settingService")
	private SettingService settingService;

	@Value("${resourcePath}")
	private String resourcePath;

	@Resource(name = "propMap")
	private HashMap<String, String> propMap;

	@RequestMapping({ "/info" })
	public ResponseEntity<HashMap> info(@RequestParam HashMap vo, Model model) throws Exception {
		HashMap resultMap = new HashMap();
		ResponseEntity entity = null;
		try {
			Iterator it = this.propMap.keySet().iterator();
			while (it.hasNext()) {
				String key = (String) it.next();
				resultMap.put(key, this.propMap.get(key));
			}

			String rJspFilePath = (String) this.propMap.get("rJspFilePath");
			if (!"".equals(rJspFilePath)) {
				resultMap.put("fileList", FileUtil.fileList(rJspFilePath));
			}

			resultMap.put("param", vo);
			entity = new ResponseEntity(resultMap, HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage());
			resultMap.put("error", e.getMessage());
			entity = new ResponseEntity(resultMap, HttpStatus.NOT_ACCEPTABLE);
		}
		return entity;
	}

	@RequestMapping({ "/save" })
	public ResponseEntity<HashMap> save(HttpServletRequest request, @RequestParam HashMap vo, Model model)
			throws Exception {
		HashMap resultMap = new HashMap();
		ResponseEntity entity = null;
		try {
			String configFilePath = this.resourcePath + File.separator + "config.properties";
			if ((vo.containsKey("sql")) && (!"".equals((String) vo.get("sql")))) {
				String sql = (String) vo.get("sql");
				if (!sql.trim().equals("")) {
					vo.put("sql", sql.replaceAll("\\n", "<br/>"));
				}
			}

			StrUtil.addMap(this.propMap, vo);
			String content = FileUtil.changeContent(configFilePath, vo);
			FileUtil.writeFile(configFilePath, content);

			if (vo.containsKey("rJspFilePath")) {
				String rJspFilePath = (String) this.propMap.get("rJspFilePath");
				resultMap.put("fileList", FileUtil.fileList(rJspFilePath));
			}

			resultMap.put("param", vo);
			entity = new ResponseEntity(resultMap, HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage());
			resultMap.put("error", e.getMessage());
			entity = new ResponseEntity(resultMap, HttpStatus.NOT_ACCEPTABLE);
		}

		return entity;
	}

	@RequestMapping({ "/list" })
	public ResponseEntity<HashMap> list(@RequestParam HashMap vo, Model model) throws Exception {
		HashMap resultMap = new HashMap();
		ResponseEntity entity = null;
		try {
			resultMap.put("data", this.settingService.list(vo));
			resultMap.put("param", vo);
			entity = new ResponseEntity(resultMap, HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage());
			resultMap.put("error", e.getMessage());
			entity = new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return entity;
	}
}