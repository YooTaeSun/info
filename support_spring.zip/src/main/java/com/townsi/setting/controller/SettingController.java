package com.townsi.setting.controller;

import java.util.HashMap;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping({ "/setting" })
public class SettingController {
	private static Logger logger = Logger.getLogger(SettingController.class);

	@RequestMapping({ "/main" })
	public String main(@RequestParam HashMap vo, Model model) throws Exception {
		return "setting/main";
	}
}