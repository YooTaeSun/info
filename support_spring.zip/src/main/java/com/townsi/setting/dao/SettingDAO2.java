package com.townsi.setting.dao;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.townsi.boot.AbstractDAO2;

@Repository("settingDAO2")
public class SettingDAO2 extends AbstractDAO2 {
	public List<HashMap> list(HashMap vo) throws Exception {
		return selectList("com.townsi.setting.settingDAO.selectList", vo);
	}
}