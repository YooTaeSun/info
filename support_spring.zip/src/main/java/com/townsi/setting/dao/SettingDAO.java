package com.townsi.setting.dao;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.townsi.boot.AbstractDAO1;

@Repository("settingDAO")
public class SettingDAO extends AbstractDAO1 {
	public List<HashMap> list(HashMap vo) throws Exception {
		return selectList("com.townsi.setting.settingDAO.selectList", vo);
	}
}