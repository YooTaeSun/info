package com.townsi.setting.dao;

import com.townsi.boot.AbstractDAO;
import java.util.HashMap;
import java.util.List;
import org.springframework.stereotype.Repository;

@Repository("settingDAO")
public class SettingDAO extends AbstractDAO
{
  public List<HashMap> list(HashMap vo)
    throws Exception
  {
    return selectList("com.townsi.setting.settingDAO.selectList", vo);
  }
}