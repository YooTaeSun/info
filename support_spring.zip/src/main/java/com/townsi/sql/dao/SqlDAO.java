package com.townsi.sql.dao;

import com.townsi.boot.AbstractDAO;
import java.util.HashMap;
import java.util.List;
import org.springframework.stereotype.Repository;

@Repository("sqlDAO")
public class SqlDAO extends AbstractDAO
{
  public List<HashMap> list(HashMap vo)
    throws Exception
  {
    return selectList("com.townsi.sql.sqlDAO.selectList", vo);
  }
}