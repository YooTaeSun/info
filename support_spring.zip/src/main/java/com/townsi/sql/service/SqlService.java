package com.townsi.sql.service;

import java.util.HashMap;

public abstract interface SqlService
{
  public abstract HashMap<String, Object> list(HashMap paramHashMap)
    throws Exception;

  public abstract HashMap<String, Object> source(HashMap paramHashMap)
    throws Exception;
}