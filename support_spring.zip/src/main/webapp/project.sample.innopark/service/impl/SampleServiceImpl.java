package kr.innovation.sample.service.impl;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import kr.innovation.sample.dao.SampleDAO;
import kr.innovation.sample.service.SampleService;

/**
* SampleServiceImpl
* @author #author#
* @since #since#
* @version 1.0
* @see
*
* <pre>
* #desc#
* << 개정이력(Modification Information) >>
*
* 수정일        수정자        수정내용
* ----------      --------       ----------------------------------
* #since#     #author#        최초 생성
* </pre>
*/
@Service("sampleService")
public class SampleServiceImpl implements SampleService {

	@Resource(name="sampleDAO")
	private SampleDAO sampleDAO;

	@Override
	public List<HashMap> selectList(HashMap vo) throws Exception {
		return sampleDAO.selectList(vo);
	}
}
