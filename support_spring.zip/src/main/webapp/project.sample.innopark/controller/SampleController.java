package kr.innovation.sample.controller;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import kr.innovation.sample.service.SampleService;
import kr.innovationpark.utils.ResponseUtil;

/**
* SampleController
* @author #author#
* @since #since#
* @version 1.0
* @see
*
* <pre>
* #desc#
* << 개정이력(Modification Information) >>
*
* 수정일        수정자        수정내용
* ----------      --------       ----------------------------------
* #since#     #author#        최초 생성
* </pre>
*/
@Controller
@RequestMapping(value="/sample")
public class SampleController {

	@Resource(name="sampleService")
	private SampleService sampleService;
	/**
	 * #desc#
	 * @param model
	 * @throws Exception
	 */
	@RequestMapping(value="/list")
	public void selectList(@RequestParam HashMap vo, ModelMap model) throws Exception {
		String resultCode = ResponseUtil.RESULT_CODE_SUCESS;

		 List<HashMap> list = sampleService.selectList(vo);

		model.addAttribute(ResponseUtil.RESULT_CODE_NAME, resultCode);
		model.addAttribute(list);
	}
}
