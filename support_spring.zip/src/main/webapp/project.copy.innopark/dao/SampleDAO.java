package kr.innovation.favorite.dao;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

import kr.innovationpark.framework.BaseDAOSupport;

/**
* FavoriteDAO
* @author 유태선
* @since 2017-10-18
* @version 1.0
* @see
*
* <pre>
* visit site
* << 개정이력(Modification Information) >>
*
* 수정일        수정자        수정내용
* ----------      --------       ----------------------------------
* 2017-10-18     유태선        최초 생성
* </pre>
*/
@Repository("favoriteDAO")
public class FavoriteDAO extends BaseDAOSupport {
	/**
	 * visit site
	 * @return
	 * @throws Exception
	 */
	public List<HashMap> selectList(HashMap vo) throws Exception {
		return getSqlSession().selectList("kr.innovationpark.favorite.favoriteDAO.selectList", vo);
	}
}
