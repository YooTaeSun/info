package kr.innovation.favorite.service;

import java.util.HashMap;
import java.util.List;

/**
* FavoriteService
* @author 유태선
* @since 2017-11-05
* @version 1.0
* @see
*
* <pre>
* visit site
* << 개정이력(Modification Information) >>
*
* 수정일        수정자        수정내용
* ----------      --------       ----------------------------------
* 2017-11-05     유태선        최초 생성
* </pre>
*/
public interface FavoriteService {
	/**
	 * visit site
	 * @return
	 * @throws Exception
	 */
	public List<HashMap> selectList(HashMap vo) throws Exception;
}
