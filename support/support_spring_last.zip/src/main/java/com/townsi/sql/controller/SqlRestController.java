package com.townsi.sql.controller;

import com.townsi.sql.service.SqlService;
import java.util.HashMap;
import javax.annotation.Resource;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({ "/sql" })
class SqlRestController {
	private static Logger logger = Logger.getLogger(SqlRestController.class);

	@Resource(name = "sqlService")
	private SqlService sqlService;

	@Value("${resourcePath}")
	private String resourcePath;

	@Resource(name = "propMap")
	private HashMap<String, String> propMap;

	@RequestMapping({ "/list" })
	public ResponseEntity<HashMap> list(@RequestParam HashMap vo, Model model) throws Exception {
		HashMap resultMap = new HashMap();
		ResponseEntity entity = null;
		try {
			resultMap.put("data", this.sqlService.list(vo));
			resultMap.put("param", vo);
			entity = new ResponseEntity(resultMap, HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage());
			resultMap.put("error", e.getMessage());
			entity = new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return entity;
	}

	@RequestMapping({ "/source" })
	public ResponseEntity<HashMap> source(@RequestParam HashMap vo, Model model) throws Exception {
		HashMap resultMap = new HashMap();
		ResponseEntity entity = null;
		try {
			resultMap.put("data", this.sqlService.source(vo));
			resultMap.put("param", vo);
			entity = new ResponseEntity(resultMap, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			resultMap.put("error", e.getMessage());
			entity = new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return entity;
	}
}