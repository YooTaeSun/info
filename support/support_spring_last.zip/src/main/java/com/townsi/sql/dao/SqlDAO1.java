package com.townsi.sql.dao;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.townsi.boot.AbstractDAO1;

@Repository("sqlDAO1")
public class SqlDAO1 extends AbstractDAO1 {
	public List<HashMap> list(HashMap vo) throws Exception {
		return selectList("com.townsi.sql.sqlDAO.selectList", vo);
	}
}