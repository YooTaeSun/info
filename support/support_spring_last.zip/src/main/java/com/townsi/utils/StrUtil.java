package com.townsi.utils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import org.apache.commons.lang3.StringUtils;

public class StrUtil {
	public static String toCamelCase(String target) {
		StringBuffer buffer = new StringBuffer();
		for (String token : target.toLowerCase().split("_")) {
			buffer.append(StringUtils.capitalize(token));
		}
		return StringUtils.uncapitalize(buffer.toString());
	}

	public static void addMap(HashMap propMap, HashMap vo) {
		Iterator it = vo.keySet().iterator();
		while (it.hasNext()) {
			String key = (String) it.next();
			propMap.put(key, (String) vo.get(key));
		}
	}

	public static String alignLine(String prfixStr, String suffix, int strLength) throws Exception {
		int prfixStrLength = prfixStr.replace("\t", "    ").length();
		int spaceCnt = strLength - prfixStrLength;

		StringBuilder sb = new StringBuilder(30);
		for (int i = 0; i < spaceCnt; i++) {
			sb.append(" ");
		}
		return prfixStr + sb.toString() + suffix;
	}
}