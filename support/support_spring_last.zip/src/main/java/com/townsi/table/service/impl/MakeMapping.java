package com.townsi.table.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.townsi.table.dao.TableDAO1;
import com.townsi.utils.FileUtil;
import com.townsi.utils.StrUtil;

@Service("makeMapping")
@SuppressWarnings({"rawtypes","unchecked"})
public class MakeMapping {

	@Resource(name = "tableDAO1")
	private TableDAO1 tableDAO1;
	public static String READ_LINE = "\n";
	public static String TAB = "\t";
	public static String SLASH = File.separator;// lastIndexOf("/")

	@Resource(name = "propMap")
	private HashMap<String, String> propMap;

	public HashMap<String, Object> source(HashMap vo) throws Exception {
		HashMap dataMap = new HashMap();
		try {
			String excludePackagePath = (String) this.propMap.get("excludePackagePath");

			String tableName = ((String) vo.get("tableName")).toUpperCase();
			if(tableName.contains(".")) {
				String[] tableNameArray = tableName.split("\\.");
				if(tableNameArray != null && tableNameArray.length == 2) {
					String owner = tableNameArray[0];
					tableName = tableNameArray[1];
					vo.put("tableName", tableNameArray[1]);
					vo.put("owner", tableNameArray[0]);
				}
			}
			
			String bizName = (String) vo.get("bizName");
			String bizNameFirstUp = bizName.substring(0, 1).toUpperCase() + bizName.substring(1);
			String bizNameFirstLower = bizName.substring(0, 1).toLowerCase() + bizName.substring(1);

			String sampleBizName = (String) vo.get("sampleBizName");
			String sampleBizNameFirstUp = sampleBizName.substring(0, 1).toUpperCase() + sampleBizName.substring(1);
			String sampleBizNameFirstLower = sampleBizName.substring(0, 1).toLowerCase() + sampleBizName.substring(1);

			String rBasePath = (String) vo.get("rBasePath");
			String wBasePath = (String) vo.get("wBasePath");

			HashMap replaceMap = new HashMap();

			replaceMap.put(sampleBizNameFirstUp, bizNameFirstUp);
			replaceMap.put(sampleBizNameFirstLower, bizNameFirstLower);

			String desc = (String) vo.get("desc");
			replaceMap.put("#desc#", desc);
			String since = (String) vo.get("since");
			replaceMap.put("#since#", since);
			String author = (String) vo.get("author");
			replaceMap.put("#author#", author);

			String isMakeDTO = (String) vo.get("isMakeDTO");
			String dtoName = "";
			if ("Y".equals(isMakeDTO)) {
				String wDtoFilePath = (String) vo.get("wDtoFilePath");
				if (wDtoFilePath.lastIndexOf("/") > -1)
					dtoName = wDtoFilePath.substring(wDtoFilePath.lastIndexOf("/") + 1, wDtoFilePath.length());
				else {
					dtoName = wDtoFilePath;
				}
				dtoName = dtoName.replace(".java", "");
			}

			String mapperName = "";
			String wDaoMAPPER = (String) vo.get("wDaoMAPPER");
			if (wDaoMAPPER.lastIndexOf("/") > -1)
				mapperName = wDaoMAPPER.substring(wDaoMAPPER.lastIndexOf("/") + 1, wDaoMAPPER.length());
			else {
				mapperName = wDaoMAPPER;
			}
			mapperName = mapperName.replace(".xml", "");

			String rControllerFilePath = rBasePath + File.separator + (String) vo.get("rControllerFilePath");
			String wControllerFilePath = (String) vo.get("wControllerFilePath");
			String wControllerFileFullPath = wBasePath + File.separator + (String) vo.get("wControllerFilePath");

			String wControllerPackageFullPath = wBasePath.replace(excludePackagePath, "") + File.separator
					+ wControllerFilePath.substring(0, wControllerFilePath.lastIndexOf(SLASH));
			String wControllerPackagePath = wControllerPackageFullPath.replace(SLASH, ".");
			replaceMap.put("#package#", wControllerPackagePath);
			FileUtil.copyFile(rControllerFilePath, wControllerFileFullPath, replaceMap);

			String rServiceFilePath = rBasePath + File.separator + (String) vo.get("rServiceFilePath");
			String wServiceFilePath = (String) vo.get("wServiceFilePath");
			String wServiceFileFileFullPath = wBasePath + File.separator + wServiceFilePath;

			String wServiceFilePackageFullPath = wBasePath.replace(excludePackagePath, "") + File.separator
					+ wServiceFilePath.substring(0, wServiceFilePath.lastIndexOf(SLASH));
			String wServiceFilePackagePath = wServiceFilePackageFullPath.replace(SLASH, ".");
			replaceMap.put("#package#", wServiceFilePackagePath);
			FileUtil.copyFile(rServiceFilePath, wServiceFileFileFullPath, replaceMap);

			if (vo.containsKey("rServiceImplFilePath")) {
				String rServiceImplFilePath = rBasePath + File.separator + (String) vo.get("rServiceImplFilePath");
				String wServiceImplFilePath = (String) vo.get("wServiceImplFilePath");
				String wServiceImplFileFileFullPath = wBasePath + File.separator + wServiceImplFilePath;

				String wServiceImplFilePackageFullPath = wBasePath.replace(excludePackagePath, "") + File.separator
						+ wServiceImplFilePath.substring(0, wServiceImplFilePath.lastIndexOf(SLASH));
				String wServiceImplFilePackagePath = wServiceImplFilePackageFullPath.replace(SLASH, ".");
				replaceMap.put("#package#", wServiceImplFilePackagePath);
				FileUtil.copyFile(rServiceImplFilePath, wServiceImplFileFileFullPath, replaceMap);
			}

			String rDaoFilePath = rBasePath + File.separator + (String) vo.get("rDaoFilePath");
			String wDaoFilePath = (String) vo.get("wDaoFilePath");
			String wDaoFileFileFullPath = wBasePath + File.separator + wDaoFilePath;

			String wDaoFilePackageFullPath = wBasePath.replace(excludePackagePath, "") + File.separator
					+ wDaoFilePath.substring(0, wDaoFilePath.lastIndexOf(SLASH));
			String wDaoFilePackagePath = wDaoFilePackageFullPath.replace(SLASH, ".");
			replaceMap.put("#package#", wDaoFilePackagePath);

			String daoName = "";
			if (wDaoFilePath.lastIndexOf("/") > -1)
				daoName = wDaoFilePath.substring(wDaoFilePath.lastIndexOf("/") + 1, wDaoFilePath.length());
			else {
				daoName = wDaoFilePath;
			}
			daoName = daoName.replace(".java", "");
			replaceMap.put("#dtoName#", dtoName);

			FileUtil.copyFile(rDaoFilePath, wDaoFileFileFullPath, replaceMap);

			List<HashMap> list = this.tableDAO1.list_oracle(vo);
			dataMap.put("list", list);

			StringBuilder selectSql = new StringBuilder(500);
			StringBuilder selectFieldSql = new StringBuilder(500);
			StringBuilder insertSql = new StringBuilder(500);
			StringBuilder insertValSql = new StringBuilder(500);
			StringBuilder updateSql = new StringBuilder(500);
			StringBuilder dtoSql = new StringBuilder(500);
			StringBuilder dtoMethodSql = new StringBuilder(500);
			StringBuilder resultMapdSql = new StringBuilder(500);
			List pkList = new ArrayList();

			String mybatisIsCamelCase = (String) vo.get("mybatisIsCamelCase");

			String ORDINAL_POSITION = "";
			String COLUMN_NAME = "";
			String CAMEL_COLUMN_NAME = "";
			String COLUMN_COMMENT = "";
			String _COLUMN_COMMENT = "";
			String COLUMN_KEY = "";
			String COLUMN_TYPE = "";
			String COLUMN_DEFAULT = "";
			String AUTO_INCREMENT = "";

			for (HashMap rs : list) {
				ORDINAL_POSITION = String.valueOf(rs.get("ORDINAL_POSITION"));
				COLUMN_NAME = (String) rs.get("COLUMN_NAME");

				COLUMN_COMMENT = (String) rs.get("COLUMN_COMMENT");
				_COLUMN_COMMENT = !"".equals(COLUMN_COMMENT) ? "/* " + COLUMN_COMMENT + " */ " : "";
				COLUMN_KEY = (String) rs.get("COLUMN_KEY");

				COLUMN_TYPE = (String) rs.get("COLUMN_TYPE");
				COLUMN_DEFAULT = (String) rs.get("COLUMN_DEFAULT");

				if ("0".equals(ORDINAL_POSITION)) {
					AUTO_INCREMENT = (String) rs.get("AUTO_INCREMENT");
				} else {
					String columnNameFirstUp = StrUtil.toCamelCase(COLUMN_NAME);
					columnNameFirstUp = columnNameFirstUp.substring(0, 1).toUpperCase()
							+ columnNameFirstUp.substring(1);
					String columnNameLower = columnNameFirstUp.substring(0, 1).toLowerCase()
							+ columnNameFirstUp.substring(1);

					if (("INSERT_DT".equals(COLUMN_NAME)) || ("UPDATE_DT".equals(COLUMN_NAME))) {
						CAMEL_COLUMN_NAME = "NOW()";
						insertValSql.append("\t," + CAMEL_COLUMN_NAME + READ_LINE);
						updateSql.append(StrUtil.alignLine("\t," + COLUMN_NAME + " = " + CAMEL_COLUMN_NAME + "\t\t\t",
								_COLUMN_COMMENT + READ_LINE, 50));
					} else if (("INSERT_ID".equals(COLUMN_NAME)) || ("UPDATE_ID".equals(COLUMN_NAME))) {
						CAMEL_COLUMN_NAME = "loginIDInSession";

						insertValSql.append("\t,#{" + CAMEL_COLUMN_NAME + "}" + READ_LINE);
						updateSql
								.append(StrUtil.alignLine("\t," + COLUMN_NAME + " = #{" + CAMEL_COLUMN_NAME + "}\t\t\t",
										_COLUMN_COMMENT + READ_LINE, 50));
					} else {
						CAMEL_COLUMN_NAME = "Y".equals(mybatisIsCamelCase) ? StrUtil.toCamelCase(COLUMN_NAME)
								: COLUMN_NAME;

						insertValSql.append("\t,#{" + CAMEL_COLUMN_NAME + "}" + READ_LINE);
						updateSql
								.append(StrUtil.alignLine("\t," + COLUMN_NAME + " = #{" + CAMEL_COLUMN_NAME + "}\t\t\t",
										_COLUMN_COMMENT + READ_LINE, 50));
					}

					selectSql.append(StrUtil.alignLine(StrUtil.alignLine("\t," + COLUMN_NAME, " AS ", 20),
							columnNameLower + "\t\t\t" + _COLUMN_COMMENT + READ_LINE, 20));
					selectFieldSql.append(StrUtil.alignLine(StrUtil.alignLine("\t,A." + COLUMN_NAME, " AS ", 20),
							columnNameLower + "\t\t\t" + _COLUMN_COMMENT + READ_LINE, 20));

					insertSql
							.append(StrUtil.alignLine("\t," + COLUMN_NAME + "\t\t\t", _COLUMN_COMMENT + READ_LINE, 50));

					resultMapdSql.append(StrUtil.alignLine("<result column=\"" + columnNameLower + "\"",
							"property=\"" + columnNameLower + "\"/>" + READ_LINE, 40));

					if ("PRI".equals(COLUMN_KEY)) {
						pkList.add(COLUMN_NAME);
					}

					if (!"Y".equals(isMakeDTO))
						continue;
					dtoSql.append(StrUtil.alignLine("\tprivate String " + columnNameLower + ";\t",
							"//" + COLUMN_COMMENT + READ_LINE, 30));
					dtoMethodSql.append("\tpublic String get" + columnNameFirstUp + "() {" + READ_LINE + " \t\t return "
							+ columnNameLower + "; \n \t}" + READ_LINE);
					dtoMethodSql.append(
							"\tpublic void set" + columnNameFirstUp + "(String " + columnNameLower + ") {" + READ_LINE
									+ " \t\t this." + columnNameLower + "=" + columnNameLower + "; \n \t}" + READ_LINE);
				}

			}

			String rJspFilePath = (String) vo.get("rJspFilePath") + File.separator + (String) vo.get("wJsps");
			String wJspFilePath = (String) vo.get("wJspFilePath");
			replaceMap.put("#dtoName#", dtoName);
			FileUtil.copyFile(rJspFilePath, wJspFilePath, replaceMap);

			String pk = "";
			String pk_camel = "";
			String pkStr = "";
			for (int pi = 0; pi < pkList.size(); pi++) {
				pk = (String) pkList.get(pi);
				pk_camel = "Y".equals(mybatisIsCamelCase) ? StrUtil.toCamelCase(pk) : pk;
				pkStr = pkStr + "AND " + pk + " = #{" + pk_camel + "} " + READ_LINE;
			}

			HashMap replaceMapperMap = new HashMap();
			replaceMapperMap.put("#desc#", desc);
			String rDaoMAPPER = rBasePath + File.separator + (String) vo.get("rDaoMAPPER");

			String wDaoMAPPERFullPath = wBasePath + File.separator + wDaoMAPPER;

			String wDaoMAPPERPackageFullPath = wBasePath.replace(excludePackagePath, "") + File.separator
					+ wDaoMAPPER.substring(0, wDaoMAPPER.lastIndexOf(SLASH));
			String wDaoMAPPERPackagePath = wDaoMAPPERPackageFullPath.replace(SLASH, ".");
			replaceMapperMap.put("#package#", wDaoMAPPERPackagePath);
			replaceMapperMap.put("#mapperName#", mapperName);
			replaceMapperMap.put("#dao.package#", wDaoFilePackagePath);
			replaceMapperMap.put("#dtoName#", dtoName);
			replaceMapperMap.put("#tableName#", tableName);

			if ("Y".equals(isMakeDTO)) {
				String rDtoFilePath = rBasePath + File.separator + (String) vo.get("rDtoFilePath");
				String wDtoFilePath = (String) vo.get("wDtoFilePath");
				String wDtoFileFullPath = wBasePath + File.separator + wDtoFilePath;

				String wDtoFilePackageFullPath = wBasePath.replace(excludePackagePath, "") + File.separator
						+ wDtoFilePath.substring(0, wDtoFilePath.lastIndexOf(SLASH));
				String wDtoFilePackagePath = wDtoFilePackageFullPath.replace(SLASH, ".");
				replaceMap.put("#package#", wDtoFilePackagePath);
				String dtoContent = dtoSql.toString() + "\n" + dtoMethodSql.toString();

				replaceMap.put("#tableName#", tableName);

				replaceMap.put("#class#", "public class " + dtoName + " {\n" + dtoContent);
				FileUtil.copyFile(rDtoFilePath, wDtoFileFullPath, replaceMap);
			}

			replaceMapperMap.put("#select#", "SELECT " + READ_LINE + selectSql.toString().replaceFirst(",", " ")
					+ "FROM " + tableName + READ_LINE + "WHERE 1=1 \n" + pkStr);
			replaceMapperMap.put("#select_field#", selectFieldSql.toString().replaceFirst(",", " "));

			if ("N".equals(AUTO_INCREMENT))
				replaceMapperMap.put("#increment#", "");
			else {
				replaceMapperMap.put("#increment#",
						"useGeneratedKeys=\"true\" keyProperty=\"" + StrUtil.toCamelCase(pk) + "\"");
			}

			replaceMapperMap.put("#insert#",
					"INSERT /* " + mapperName + ".xml, insert */\nINTO " + tableName + " (\n"
							+ insertSql.toString().replaceFirst(",", " ") + ") VALUES (" + READ_LINE
							+ insertValSql.toString().replaceFirst(",", " ") + ")");
			replaceMapperMap.put("#update#",
					"UPDATE  /* " + mapperName + ".xml, update */" + READ_LINE + "\t" + tableName + " SET" + READ_LINE
							+ updateSql.toString().replaceFirst(",", " ") + "WHERE 1=1 " + READ_LINE + pkStr);
			replaceMapperMap.put("#delete#", "DELETE  /* " + mapperName + ".xml, delete */" + READ_LINE + "FROM "
					+ tableName + READ_LINE + " WHERE 1=1 " + READ_LINE + pkStr);
			replaceMapperMap.put("#resultMap#",
					"<resultMap type=\"type\" id=\"Map\">\n" + resultMapdSql.toString() + "</resultMap>");

			FileUtil.copyFile(rDaoMAPPER, wDaoMAPPERFullPath, replaceMapperMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dataMap;
	}

	public HashMap<String, Object> list(HashMap vo) throws Exception {
		HashMap dataMap = new HashMap();

		return dataMap;
	}
}