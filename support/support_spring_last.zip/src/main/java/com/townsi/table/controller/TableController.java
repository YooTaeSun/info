package com.townsi.table.controller;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping({ "/table" })
public class TableController {
	private static Logger logger = Logger.getLogger(TableController.class);
}