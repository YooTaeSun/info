package com.townsi.table.dao;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.townsi.boot.AbstractDAO1;

@Repository("tableDAO1")
public class TableDAO1 extends AbstractDAO1 {
	public List<HashMap> list_mysql(HashMap vo) throws Exception {
		return selectList("com.townsi.table.tableDAO.selectList_mysql", vo);
	}
	
	public List<HashMap> list_oracle(HashMap vo) throws Exception {
		return selectList("com.townsi.table.tableDAO.selectList_oracle", vo);
	}
}