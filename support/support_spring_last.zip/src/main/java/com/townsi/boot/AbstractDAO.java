//package com.townsi.boot;
//
//import com.townsi.setting.controller.SettingController;
//import java.util.List;
//import javax.annotation.Resource;
//import org.apache.log4j.Logger;
//import org.mybatis.spring.SqlSessionTemplate;
//
//public class AbstractDAO {
//	private static Logger logger = Logger.getLogger(SettingController.class);
//
//	@Resource(name = "sqlSession")
//	private SqlSessionTemplate sqlSession;
//
//	protected void printQueryId(String queryId) {
//		if (logger.isDebugEnabled())
//			logger.debug("\t QueryId  \t:  " + queryId);
//	}
//
//	public Object insert(String queryId, Object params) {
//		printQueryId(queryId);
//		return Integer.valueOf(this.sqlSession.insert(queryId, params));
//	}
//
//	public Object update(String queryId, Object params) {
//		printQueryId(queryId);
//		return Integer.valueOf(this.sqlSession.update(queryId, params));
//	}
//
//	public Object delete(String queryId, Object params) {
//		printQueryId(queryId);
//		return Integer.valueOf(this.sqlSession.delete(queryId, params));
//	}
//
//	public Object selectOne(String queryId) {
//		printQueryId(queryId);
//		return this.sqlSession.selectOne(queryId);
//	}
//
//	public Object selectOne(String queryId, Object params) {
//		printQueryId(queryId);
//		return this.sqlSession.selectOne(queryId, params);
//	}
//
//	public List selectList(String queryId) {
//		printQueryId(queryId);
//		return this.sqlSession.selectList(queryId);
//	}
//
//	public List selectList(String queryId, Object params) {
//		printQueryId(queryId);
//		return this.sqlSession.selectList(queryId, params);
//	}
//}