package com.townsi.setting.service;

import java.util.HashMap;

public abstract interface SettingService {
	public abstract HashMap<String, Object> list(HashMap paramHashMap) throws Exception;
}