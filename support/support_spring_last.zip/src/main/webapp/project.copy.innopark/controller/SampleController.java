package kr.innovation.favorite.controller;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import kr.innovation.favorite.service.FavoriteService;
import kr.innovationpark.utils.ResponseUtil;

/**
* FavoriteController
* @author 유태선
* @since 2017-11-05
* @version 1.0
* @see
*
* <pre>
* visit site
* << 개정이력(Modification Information) >>
*
* 수정일        수정자        수정내용
* ----------      --------       ----------------------------------
* 2017-11-05     유태선        최초 생성
* </pre>
*/
@Controller
@RequestMapping(value="/favorite")
public class FavoriteController {

	@Resource(name="favoriteService")
	private FavoriteService favoriteService;
	/**
	 * visit site
	 * @param model
	 * @throws Exception
	 */
	@RequestMapping(value="/list")
	public void selectList(@RequestParam HashMap vo, ModelMap model) throws Exception {
		String resultCode = ResponseUtil.RESULT_CODE_SUCESS;

		 List<HashMap> list = favoriteService.selectList(vo);

		model.addAttribute(ResponseUtil.RESULT_CODE_NAME, resultCode);
		model.addAttribute(list);
	}
}
