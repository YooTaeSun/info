package kr.innovation.sample.service;

import java.util.HashMap;
import java.util.List;

/**
* SampleService
* @author #author#
* @since #since#
* @version 1.0
* @see
*
* <pre>
* #desc#
* << 개정이력(Modification Information) >>
*
* 수정일        수정자        수정내용
* ----------      --------       ----------------------------------
* #since#     #author#        최초 생성
* </pre>
*/
public interface SampleService {
	/**
	 * #desc#
	 * @return
	 * @throws Exception
	 */
	public List<HashMap> selectList(HashMap vo) throws Exception;
}
