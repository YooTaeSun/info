//package com.townsi.support;
//
//import org.junit.runner.RunWith;
//import org.springframework.boot.test.context.TestConfiguration;
//import org.springframework.boot.web.support.SpringBootServletInitializer;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@TestConfiguration(classes = ApplicationTest.class)
//public class ApplicationTest extends SpringBootServletInitializer{
//
//
//}