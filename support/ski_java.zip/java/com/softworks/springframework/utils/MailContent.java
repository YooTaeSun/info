package com.softworks.springframework.utils;

public class MailContent {

	/*
	 * 메일 html 생성
	 * Paramater : Param
	 * 		String TITLE 	- 제목
	 * 		String CONTENT	- 내용
	 * 		String LINK_URL	- 연결 URL
	 */
	public static String make(final Param param) {
		StringBuffer sb = new StringBuffer();

		sb.append("<!doctype html>\n");
		sb.append("<html>\n");
		sb.append("<head>\n");
		sb.append("	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n");
		sb.append("	<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\n");
		sb.append("    <title>email</title>\n");
		sb.append("</head>\n");
		sb.append("<body>\n");
		sb.append("    <table align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n");
		sb.append("		<tbody>\n");
		sb.append("			<tr>\n");
		sb.append("				<td style=\"padding-bottom:7px;\">\n");
		sb.append("					<a href=\"#none\"><img src=\"http://sqm.skinnovation.co.kr/images/common/logo.png\" alt=\"SK_inovation\" align=\"middle\"></a>\n");
		sb.append("				</td>\n");
		sb.append("			</tr>\n");
		sb.append("			<tr>\n");
		sb.append("				<td style=\" width:750px; border:1px solid #d8d8d8; border-top:3px solid #444; border-bottom:0;\">\n");
		sb.append("					<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"width:100%; padding:0 0 0 50px; border-bottom:1px solid #dfdfe3; background-color:#f4f4f5;\">\n");
		sb.append("						<tbody>\n");
		sb.append("							<tr>\n");
		sb.append("								<td>\n");
		sb.append("									<h2 style=\" font-family:'NanumGothic', '나눔고딕', '맑은고딕', 'Malgun Gothic','돋움', 'Dotum', sans-serif; font-size:24px; font-weight:600; color:#444; letter-spacing:-.5px;  margin:25px 0;\">SK Information 정보보안포털</h2>\n");
		sb.append("								</td>\n");
		sb.append("							</tr>\n");
		sb.append("					</table>\n");
		sb.append("					<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"width:100%; padding:30px 50px 18px 50px; border-bottom:1px solid #d8d8d8;\">\n");
		sb.append("						<tr>\n");
		sb.append("							<td>\n");
		sb.append("								<p style=\"color:#444; font-weight:500; font-size:20px; letter-spacing:-.5px; font-family:'NanumGothic', '나눔고딕', '맑은고딕', 'Malgun Gothic','돋움', 'Dotum', sans-serif;\">\n");
		sb.append(param.get("TITLE")).append("\n");
		sb.append("								</p>\n");
		sb.append("								<div style=\"line-height:24px; margin:40px 0;\">\n");
		sb.append("									<p style=\" font-family:'NanumGothic', '나눔고딕', '맑은고딕', 'Malgun Gothic','돋움', 'Dotum', sans-serif; font-size:15px; color:#444; letter-spacing:-.5px;\">\n");
		sb.append(param.get("CONTENT")).append("\n");
		sb.append("									</p>\n");										
		sb.append("								</div>\n");								
		sb.append("								<table align=\"center\" style=\"margin:50px auto 50px;\">\n");
		sb.append("									<tbody>\n");
		sb.append("										<tr>\n");
		sb.append("											<td style=\"width:180px; height:40px; text-align:center; background-color:#e8252d;\">\n");
		sb.append("												<a href=\"").append(param.get("LINK_URL")).append("\" style=\"font-size:14px; color:#fff; text-decoration:none; font-family:'NanumGothic', '나눔고딕', '맑은고딕', 'Malgun Gothic','돋움', 'Dotum', sans-serif; font-weight:600; \">시스템 바로가기</a>\n");
		sb.append("											</td>\n");
		sb.append("										</tr>\n");
		sb.append("									</tbody>\n");
		sb.append("								</table>\n");
		sb.append("								<p align=\"center\" style=\"padding:20px 0 0 0; font-weight:100; margin-top:31px; font-size:12px; width:100%; border-top:1px solid #b4b4b4; font-family:'NanumGothic', '나눔고딕', '맑은고딕', 'Malgun Gothic','돋움', 'Dotum', sans-serif; color:#888; \">\n");
		sb.append("									Copyright ⓒ 2019 SK innovation Co., Ltd. All Rights reserved.\n"); 
		sb.append("								</p>\n");
		sb.append("							</td>\n");
		sb.append("						</tr>\n");
		sb.append("					</tbody>\n");
		sb.append("					</table>\n");
		sb.append("				</td>\n");
		sb.append("			</tr>\n");
		sb.append("		</tbody>\n");
		sb.append("    </table>\n");
		sb.append("</body>\n");
		sb.append("</html>\n");

		return sb.toString();
	}
	
	
	/*
	 * add yik 20190529
	 * 신규 메일 html 생성 
	 * Paramater : Param
	 * 		String TITLE 	- 제목
	 * 		String CONTENT	- 내용
	 * 		String LINK_URL	- 연결 URL
	 */
	public String make2(final Param param) {
		StringBuffer sb = new StringBuffer();

		sb.append("<!doctype html>\n");
		sb.append("<html>\n");
		sb.append("<head>\n");
		sb.append("	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n");
		sb.append("	<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\n");
		sb.append("    <title>email</title>\n");
		sb.append("</head>\n");
		sb.append("<body>\n");
		sb.append("    <table align=\"center\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n");
		sb.append("		<tbody>\n");
		/*sb.append("			<tr>\n");
		sb.append("				<td style=\"padding-bottom:7px;\">\n");
		sb.append("					<a href=\"#none\"><img src=\"http://sqm.skinnovation.co.kr/images/common/logo.png\" alt=\"SK_inovation\" align=\"middle\"></a>\n");
		sb.append("				</td>\n");
		sb.append("			</tr>\n");*/
		sb.append("			<tr>\n");
		sb.append("				<td style=\" width:750px; border:1px solid #d8d8d8; border-top:3px solid #444; border-bottom:0;\">\n");
		sb.append("					<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"width:100%; padding:0 0 0 50px; border-bottom:1px solid #dfdfe3; background-color:#f4f4f5;\">\n");
		sb.append("						<tbody>\n");
		sb.append("							<tr>\n");
		sb.append("								<td>\n");
		sb.append("									<h2 style=\" font-family:'NanumGothic', '나눔고딕', '맑은고딕', 'Malgun Gothic','돋움', 'Dotum', sans-serif; font-size:24px; font-weight:600; color:#444; letter-spacing:-.5px;  margin:25px 0;\">SK이노베이션 정보보안포털</h2>\n");
		sb.append("								</td>\n");
		sb.append("							</tr>\n");
		sb.append("					</table>\n");
		sb.append("					<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"width:100%; padding:30px 50px 18px 50px; border-bottom:1px solid #d8d8d8;\">\n");
		sb.append("						<tr>\n");
		sb.append("							<td>\n");
		sb.append("								<p style=\"color:#444; font-weight:500; font-size:20px; letter-spacing:-.5px; font-family:'NanumGothic', '나눔고딕', '맑은고딕', 'Malgun Gothic','돋움', 'Dotum', sans-serif;\">\n");
		sb.append(param.get("mail_title")).append("\n");
		sb.append("								</p>\n");
		sb.append("								<div style=\"line-height:24px; margin:40px 0;\">\n");
		sb.append("									<p style=\" font-family:'NanumGothic', '나눔고딕', '맑은고딕', 'Malgun Gothic','돋움', 'Dotum', sans-serif; font-size:15px; color:#444; letter-spacing:-.5px;\">\n");
		sb.append(param.get("content")).append("\n");
		sb.append("									</p>\n");										
		sb.append("								</div>\n");								
		sb.append("								<table align=\"center\" style=\"margin:50px auto 50px;\">\n");
		sb.append("									<tbody>\n");
		sb.append("										<tr>\n");
		sb.append("											<td style=\"width:180px; height:40px; text-align:center; background-color:#e8252d;\">\n");
		sb.append("												<a target=\"_blank\" href=\"").append(param.get("link_url")).append("\" style=\"font-size:14px; color:#fff; text-decoration:none; font-family:'NanumGothic', '나눔고딕', '맑은고딕', 'Malgun Gothic','돋움', 'Dotum', sans-serif; font-weight:600; \">정보보안포털 바로가기</a>\n");
		sb.append("											</td>\n");
		sb.append("										</tr>\n");
		sb.append("									</tbody>\n");
		sb.append("								</table>\n");
		sb.append("								<p align=\"center\" style=\"padding:20px 0 0 0; font-weight:100; margin-top:16px; font-size:12px; width:100%; border-top:1px solid #b4b4b4; font-family:'NanumGothic', '나눔고딕', '맑은고딕', 'Malgun Gothic','돋움', 'Dotum', sans-serif; color:#888; \">\n");
		sb.append("									본 메일은 정보보안포털 시스템에서 발송한 발신 전용 메일입니다.\n"); 
		sb.append("								</p>\n");
		sb.append("								<p align=\"center\" style=\"padding:5px 0 0 0; font-weight:100; margin-top:4px; font-size:12px; width:100%;font-family:'NanumGothic', '나눔고딕', '맑은고딕', 'Malgun Gothic','돋움', 'Dotum', sans-serif; color:#888; \">\n");
		sb.append("									Copyright ⓒ 2019 SK innovation Co., Ltd. All Rights reserved.\n"); 
		sb.append("								</p>\n");
		sb.append("							</td>\n");
		sb.append("						</tr>\n");
		sb.append("					</tbody>\n");
		sb.append("					</table>\n");
		sb.append("				</td>\n");
		sb.append("			</tr>\n");
		sb.append("		</tbody>\n");
		sb.append("    </table>\n");
		sb.append("</body>\n");
		sb.append("</html>\n");

		return sb.toString();
	}

}
