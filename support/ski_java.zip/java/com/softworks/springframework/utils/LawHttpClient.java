package com.softworks.springframework.utils;

import java.io.BufferedReader;
import java.io.DataOutputStream ;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.SQLException;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.JsonNode;
import org.json.JSONObject;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.web.services.MailSendService;

public class LawHttpClient {
			
	public static int PRETTY_PRINT_INDENT_FACTOR = 4;
	public static String RESULT_MSG;
	public static String RESULT_CD;
	
	public LawHttpClient() {
	}
	public static String apiToken = Property.getProperty("open.api.mail.key") ;
	public static String mailurl = Property.getProperty("open.api.mail") ;
	
	public String callUrl(String httpurl) {

		String resJson = null;
		HttpClient httpClient = new DefaultHttpClient();
		JsonNode rsJson = null;
        JSONObject soapDatainJsonObject = null;
        if ( httpurl.equals("mail"))	httpurl = mailurl ;
		try {

		   HttpResponse httpResponse;
		   HttpPost httpPost= new HttpPost(httpurl);
		   		   
		   httpPost.setHeader("Authorization", apiToken);
		   httpPost.setHeader("Content-type", "application/json; charset=utf-8");
	       httpResponse=httpClient.execute(httpPost);

	       if(httpResponse.getEntity()!=null) {
	    	   resJson = EntityUtils.toString(httpResponse.getEntity());
	       }
	       System.out.println("## resJson ==>"+resJson);
	       	       	                  
		} catch (Exception e) {
			System.out.println("Cannot establish connection! : " + e.getMessage());
		}finally {
		   httpClient.getConnectionManager().shutdown();
		}
		return resJson;
	}

	/*
	 * API 
	 * URL호출 시 JSON 데이터를 제공하면
	 * 이를 받아서 처리하는 로직
	 * 
	 * */
	public String callHttpUrl(String httpurl) throws IOException {
		String mdata = "" ;
		// if ( httpurl.equals("mail"))	httpurl = mailurl ;
		String result = "" ;
		// 사용 될 api url
		URL url = new URL(httpurl);
		
		// 사용될 api url를 HttpURLConnection로 전환
		HttpURLConnection connection = (HttpURLConnection)url.openConnection();
		// output 사용설정
		connection.setDoOutput(true);

		// input 사용설정
		connection.setDoInput(true);
		
		// post 방식
		connection.setRequestMethod("POST");
		
		// cach 요청 안함
		connection.setUseCaches(false);
		
		// 자동 redirect
		connection.setInstanceFollowRedirects(true);
		
		// Token 설정
		connection.setRequestProperty("Authorization", apiToken);
		
		// form,utf-8 설정
		connection.setRequestProperty("Content-Type", "application/x-www-form-urlencodde;charset=utf-8");
		
		// connect open
		connection.connect();
		System.out.println("LawHttpClient connection.connect() result Responsecode = "+connection.getResponseCode());
		
		// output 신규
		DataOutputStream dataout = new DataOutputStream(connection.getOutputStream());
		
		// api 파라미터 연결
		dataout.writeBytes(mdata) ;
		
		// refresh
		dataout.flush();
		
		// close
		dataout.close();
		
		result = connection.getResponseMessage();
		return result;		
	}
	
	public String apiCallUrl(String httpurl,String mdata,Param md) throws IOException {
		
		String result = "" ;
		try {			
			MailSendService	mailsvc = new MailSendService();
			if ( httpurl.equals("mail"))	httpurl = mailurl ;
						
			// 사용 될 api url
			URL objurl = new URL(httpurl);
					
			HttpURLConnection con = (HttpURLConnection)objurl.openConnection();		
			con.setDoOutput(true);
			con.setDoInput(true);
			// Token 설정
			con.setRequestProperty("Authorization", apiToken);				
			// form,utf-8 설정
			con.setRequestProperty("Content-Type", "application/json");				
			// post 방식
			con.setRequestMethod("POST");
			
			// Data 전송
			OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream()) ;
			wr.write(mdata);
			wr.flush();
			
			result = con.getResponseMessage();
			if ( result == null ) result = "메일 전송이 완료 되었습니다." ; 
			
			// Return Log Storage
			StringBuilder sb = new StringBuilder() ;
			int HttpResult = 1000000 ;
			HttpResult = con.getResponseCode() ;
			System.out.println("apiCallUrl HttpResult Data = "+HttpResult);
			if ( HttpResult == HttpURLConnection.HTTP_OK || HttpResult == 201) {
				BufferedReader br = new BufferedReader(
						new InputStreamReader(con.getInputStream(), "utf-8"));					
				String line = null;
				while((line = br.readLine()) != null) {
					sb.append(line + "\n");				
				}
				br.close();
				System.out.println("apiCallUrl Result Data = "+sb.toString());
			}else {
				System.out.println("apiCallUrl Result Error = "+result);
			}
			
			Param mp = new Param();
			mp.set("recv_mail_addr", "");
			mp.set("recv_emp_no", "");
			mp.set("recv_emp_nm", "");
			mp.set("mail_typ_cd", "");
			mp.set("mail_title", "");
			mp.set("mail_cn", "");
			mp.set("send_result_cd", "");
			mp.set("send_result_msg", "");
				
			mailsvc.MailLoginsert(mp);
									
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;	
				
	}
	
	public boolean apiCallUrl2(String httpurl,String mdata,Param md) throws IOException, InterruptedException {
		
		String result = "" ;
		boolean boolRtn = false;
		MailSendService	mailsvc = new MailSendService();
		if ( httpurl.equals("mail"))	httpurl = mailurl ;
		
		// 사용 될 api url
		URL objurl = new URL(httpurl);
				
		HttpURLConnection con = (HttpURLConnection)objurl.openConnection();		
		con.setDoOutput(true);
		con.setDoInput(true);
		// Token 설정
		con.setRequestProperty("Authorization", apiToken);				
		// form,utf-8 설정
		con.setRequestProperty("Content-Type", "application/json");				
		// post 방식
		con.setRequestMethod("POST");
		
		// Data 전송
		OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream()) ;
		wr.write(mdata);
		wr.flush();
		
		result = con.getResponseMessage();
		if ( result == null ) result = "메일 전송이 완료 되었습니다." ; 
		
		// Return Log Storage
		StringBuilder sb = new StringBuilder() ;
		int HttpResult = 1000000 ;
		HttpResult = con.getResponseCode() ;
		System.out.println("apiCallUrl HttpResult Data = "+HttpResult);
		RESULT_CD = String.valueOf(HttpResult);
		
		if ( HttpResult == HttpURLConnection.HTTP_OK || HttpResult == 201) {
			BufferedReader br = new BufferedReader(
					new InputStreamReader(con.getInputStream(), "utf-8"));					
			String line = null;
			while((line = br.readLine()) != null) {
				sb.append(line + "\n");				
			}
			br.close();
			System.out.println("apiCallUrl Result Data = "+sb.toString());
			boolRtn = true;
		}else {
			System.out.println("apiCallUrl Result Error = "+result);
			boolRtn = false;
		}
		RESULT_MSG = result;
		
		// 대량 발송 시 부하를 줄이기 위해 
		Thread.sleep(200);
		
		return boolRtn;	
				
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new LawHttpClient();

	}
}
