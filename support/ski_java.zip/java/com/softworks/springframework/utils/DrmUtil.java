package com.softworks.springframework.utils;

import java.io.File;

import org.apache.log4j.Logger;

import com.softworks.springframework.property.Property;

import SCSL.SLBsUtil;
import SCSL.SLDsFile;

public class DrmUtil {

	final static Logger logger = Logger.getLogger(DrmUtil.class);

	final static String fileDrmSettingPathForProperty = Property.getProperty("file.drm.setting.path.for.property");
	final static String fileDrmKeyFileKeyGrade = Property.getProperty("file.drm.key.file.key.grade");
	final static String fileDrmKeyFileKeyDac = Property.getProperty("file.drm.key.file.key.dac");
	final static String fileDrmExt = Property.getProperty("file.drm.ext");



	public static boolean encryption(String srcFile, String dsfFile, String fileExtsn) {

		boolean isEncrypt = false;

		logger.debug("[DrmUtil encryption] srcFile >> " + srcFile);
		logger.debug("[DrmUtil encryption] dsfFile >> " + dsfFile);

		if(fileDrmExt.indexOf(fileExtsn) == -1) {
			logger.debug("[DrmUtil encryption] 암호화 대상 확정자가  아님  >> " + dsfFile);

			File f2 = new File(dsfFile);
			if(f2.exists()) {
				f2.delete();
			}

			File f1 = new File(srcFile);
			f1.renameTo(f2);

			isEncrypt = false;

		}else {

			logger.debug("[DrmUtil encryption] 암호화 대상 확정자   >> " + dsfFile);

			SLDsFile sFile = new SLDsFile();
			SLBsUtil sUtil = new SLBsUtil();
			int DSSLDocuGradeEncAddCreator =-1;

			sFile.SLDsEnvSet(0); // 0 이면 확장자를 체크하지 않음
			int retVal = sUtil.isEncryptFile(srcFile); // 문서암호화 여부 판단 0:이면 암호화 가능

			logger.debug("[DrmUtil encryption] 문서암호화 여부 판단 0:이면 암호화 가능 retVal >> " + retVal);

			if(retVal == 0) {

				logger.debug("[DrmUtil encryption] SettingPathForProperty >> " + fileDrmSettingPathForProperty);
				logger.debug("[DrmUtil encryption] fileDrmKeyFileKeyGrade >> " + fileDrmKeyFileKeyGrade);
				logger.debug("[DrmUtil encryption] fileDrmKeyFileKeyDac >> " + fileDrmKeyFileKeyDac);

				sFile.SettingPathForProperty(fileDrmSettingPathForProperty);

				DSSLDocuGradeEncAddCreator = sFile.DSSLDocuGradeEncAddCreator(fileDrmKeyFileKeyGrade,"System","none","0000001" ,
						"SECURITYDOMAIN","SECURITYDOMAIN;","none",srcFile,dsfFile,"SECURITYDOMAIN","SECURITYDOMAIN;", fileDrmKeyFileKeyDac,0,0);

				logger.debug("[DrmUtil encryption] DSSLDocuGradeEncAddCreator >> " + DSSLDocuGradeEncAddCreator);

				isEncrypt = true;

			}else if(retVal == 1) {//이미 암호화

				logger.debug("[DrmUtil encryption] 이미 암호화  rename>> " + dsfFile);

				File f1 = new File(srcFile);
				File f2 = new File(dsfFile);
				f1.renameTo(f2);

				isEncrypt = true;
			}else {
			}
		}
		return isEncrypt;
	}

	private static boolean decryption(String srcFile, String dsfFile) {
//		String srcFile = "/home/softcamp/03_Sample/test_Enc.xls" ;
//		String dsfFile = "/home/softcamp/03_Sample/test_Dec.xls" ;

		logger.debug("[DrmUtil decryption] srcFile >> " + srcFile);
		logger.debug("[DrmUtil decryption] dsfFile >> " + dsfFile);

		SLDsFile sFile = new SLDsFile();
		sFile.SettingPathForProperty("/home/softcamp/02_Module/02_ServiceLinker/softcamp.properties");

		int GradeDACCreateDecryptFileDAC = sFile.CreateDecryptFileDAC("/home/softcamp/04_KeyFile/keyDAC_SVR0.sc","SECURITYDOMAIN", srcFile, dsfFile);
		System.out.println("GradeDACCreateDecryptFileDAC [" + GradeDACCreateDecryptFileDAC + "]");

		logger.debug("[DrmUtil decryption] DSSLDocuGradeEncAddCreator >> " + GradeDACCreateDecryptFileDAC);

		return (GradeDACCreateDecryptFileDAC == 0)? true : false;
	}
}