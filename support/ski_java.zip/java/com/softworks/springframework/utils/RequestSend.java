package com.softworks.springframework.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Iterator;

import org.apache.log4j.Logger;

public class RequestSend {

	private	final Logger 	logger	= Logger.getLogger(getClass());
	
	private	URL				url;
	private	URLConnection	conn;
	
	public RequestSend() { }
	
	public RequestSend(String url) throws Exception {
		setUrl(url);
	}
	
	public void setUrl(String url) throws Exception {
		this.url	= new URL(url);
	}
	
	public void setConnection() throws Exception {
		if(null != this.url) conn	= this.url.openConnection();
	}
	
	public String getSend() throws Exception {
		setConnection();
		
		return getData();
	}
	
	public String postSend(final Param param) throws Exception {
		StringBuilder	sb		= new StringBuilder();
    	
		for(Iterator it = param.entrySet().iterator();it.hasNext();) {
			String[] tmp = it.next().toString().split("=");
			
			sb.append("&").append(URLEncoder.encode(tmp[0], "UTF-8")).append("=");
			if(2 == tmp.length) sb.append(URLEncoder.encode(tmp[1], "UTF-8"));
    	}
		
		setConnection();

		this.conn.setDoOutput(true);
		OutputStreamWriter	wr	= new OutputStreamWriter(this.conn.getOutputStream());

		try {
			wr.write(sb.substring(1).toString());
			wr.flush();
			wr.close();
		} catch(Exception e) {
			logger.error("", e);
		} finally {
			if(null != wr) try { wr.close(); } catch(Exception e) {}
		}
		
		
		return getData();
	}
	
	public String getData() {
		String			line= null;
		BufferedReader	rd	= null;
		StringBuilder	sb	= new StringBuilder();
		
		try {
			rd	= new BufferedReader(new InputStreamReader(this.conn.getInputStream(), "UTF-8"));
			
			while((line = rd.readLine()) != null)	sb.append(line);
		} catch(Exception e) {
			logger.error("", e);
		} finally {
			if(null != rd) try { rd.close(); } catch(Exception e) {}
		}
		
		return sb.toString();
	}

}
