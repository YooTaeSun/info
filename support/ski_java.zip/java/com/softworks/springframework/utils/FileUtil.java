package com.softworks.springframework.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;
import java.util.Random;

import org.apache.commons.lang.RandomStringUtils;

public class FileUtil {

	public static final int BUFFER_SIZE = 1024;

	/**
	 * <pre>
	 * Comment : 파일을 생성한다.
	 * </pre>
	 *
	 * @param String
	 *            fileName 파일의 절대경로 +파일명
	 * @param String
	 *            content 저장할 문자열입니다. c:/test/test1/test44.txt
	 *
	 */
	public static String createNewFile(String filePath) {

		// 인자값 유효하지 않은 경우 블랭크 리턴
		if (filePath == null || filePath.equals("")) {
			return "";
		}

		File file = new File(filePath);
		String result = "";
		try {
			if (file.exists()) {
				result = filePath;
			} else {
				// 존재하지 않으면 생성함
				new File(file.getParent()).mkdirs();
				if (file.createNewFile()) {
					result = file.getAbsolutePath();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	public static int fnRandom(int min, int max) throws Exception {
		Random random = new Random(System.currentTimeMillis());
		return random.nextInt(max - min) + min;
	}

	public static String createFilename() throws Exception {
		String output = Utils.getTimeStampString("yyyyMMddHHmmssSSS") + RandomStringUtils.randomAlphanumeric(4); //17 + 4 = 21
//		String output = Utils.getTimeStampString("ddHHmmssSSS") + RandomStringUtils.randomAlphanumeric(4); //11 + 4 = 15
		return output;
	}

	public static String addPath() throws Exception {
		Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;

		String pathStr = "";
		if (month < 10) {
			pathStr = year + "/" + "0" + month;
		} else {
			pathStr = year + "/" + month;
		}
		return pathStr;
	}

	public static String getFileExtsn(String fullPath) throws IOException {
		String fileExtsn = "NA";
		if(!Utils.nvl(fullPath).isEmpty()) {
			fileExtsn = fullPath.substring(fullPath.lastIndexOf(".") + 1).toLowerCase();
		}
		return fileExtsn;
	}

	public static String getEncFullPath(String fullPath) throws IOException {
		String encFullPath = "";
		if(!Utils.nvl(fullPath).isEmpty()) {
			if(fullPath.indexOf(".xls") > -1) {
				encFullPath = fullPath.replace(".xls", "") + "_DRM.xls";
			}else {
				encFullPath = fullPath + "_DRM";
			}
		}
		return encFullPath;
	}

	public static String getEncFullPath(File fullPath) throws IOException {
		return FileUtil.getEncFullPath(fullPath.getAbsolutePath());
	}

	public static String getFileNameExceptExtsn(String fileNm) throws IOException {
		int fix = fileNm.lastIndexOf(".");
		if(!Utils.nvl(fileNm).isEmpty() && fix > -1) {
			return fileNm.substring(0, fix);
		}else {
			return fileNm;
		}
	}

	/**
     * 파일 복사
     * @param source 소스 파일명
     * @param target 타겟 파일명
     * @return
     */
    public static boolean copyFile(String source, String target) throws Exception{
        boolean result = true;
        FileInputStream fis = null;
        FileOutputStream fos = null;

        // 디렉토리가 존재하지 않으면 생성
        File targetDir = new File(target.substring(target.lastIndexOf("/")+1));
        if (!targetDir.exists()) {
            targetDir.mkdirs();
        }

        File sourceFile = new File(source);
        if(!sourceFile.exists()) {
        	throw new RuntimeException("no file : " + sourceFile.getAbsolutePath());
        }


        try {
            fis = new FileInputStream(sourceFile);
            fos = new FileOutputStream(target);

            final int BUFF_SIZE = 1024;
            byte buf[] = new byte[BUFF_SIZE];
            int i = 0;

            while ((i = fis.read(buf)) > 0)
                fos.write(buf, 0, i);
        } catch (Exception e) {
            result = false;
        } finally {
            try { if (fis != null) fis.close(); } catch (IOException ioe) { }
            try { if (fos != null) fos.close(); } catch (IOException ioe) { }
        }

        return result;
    }

    /**
     * 여러 파일을 다른 디렉토리에 복사(Copy)한다.
     * @param String source 원본파일들
     * @param String target 타겟디렉토리
     * @return boolean result 복사여부 True / False
     * @exception Exception
    */
    public static boolean copyFiles(String [] source, String target) throws Exception {

        // 복사여부
        boolean result = true;

        // 복사 이전에 복사할 파일들의 경로가 올바른지 확인한다.
        for (int i = 0; i < source.length; i++) {
            String src = source[i].replace('\\', File.separatorChar).replace('/', File.separatorChar);
            File chkFile = new File(src);
            if (!chkFile.exists()) {
                //log.debug("+++ 원본 파일이 존재하지 않습니다.");
                return result;
            }
        }

        String tar = target.replace('\\', File.separatorChar).replace('/', File.separatorChar);

        // 복사를 시작한다.
        for (int j = 0; j < source.length; j++) {

            if(result){ //result != false

                // 타겟파일이름 명명
                File chkFile = new File(source[j]);
                String tarTemp = tar + File.separatorChar + chkFile.getName();

                try
                {
                    // 복사될 target 파일 생성
                    tarTemp = createNewFile(tarTemp);
                    File tarFile = new File(tarTemp);

                    // 복사
                    result = execCopyFile(chkFile, tarFile);

                } catch (IOException ex){
                    ex.printStackTrace();
                }

            }

        } // end for

        return result;
    }

    /**
     * 복사를 수행하는 기능
     * @param File srcFile 원본파일
     * @param File tarFile 타겟파일
     * @return boolean result 복사여부 True / False
     * @exception Exception
    */
    public static boolean execCopyFile(File srcFile, File tarFile) throws Exception {

        // 결과
        boolean result = false;
        FileInputStream fis = null;
        FileOutputStream fos = null;
        try {
            // 복사
            fis = new FileInputStream(srcFile);

            //예외상황에 따른 처리 추가함. -> 만약 tarFile 이 디렉토리명인 경우 디렉토리 밑으로 새로 파일을 생성해서 복사한다.. like DOS
            File tarFile1 = tarFile;
            if(tarFile1.isDirectory()){
            	tarFile1 = new File(tarFile1.getAbsolutePath()+"/"+srcFile.getName());
            }
            fos = new FileOutputStream(tarFile1);
            byte [] buffer = new byte[BUFFER_SIZE];
            int i = 0;
            if (fis != null && fos != null) {
            	while ((i = fis.read(buffer)) != -1) {
                    fos.write(buffer, 0, i);
                }
            }

            result = true;
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
        	if (fis != null) fis.close();
            if (fos != null) fos.close();
        }


        return result;
    }

    public static void deleteFile(String path) {
		File deleteFolder = new File(path);

		if(deleteFolder.exists()){
			File[] deleteFolderList = deleteFolder.listFiles();

			for (int i = 0; i < deleteFolderList.length; i++) {
				if(deleteFolderList[i].isFile()) {
					deleteFolderList[i].delete();
				}else {
					deleteFile(deleteFolderList[i].getPath());
				}
				deleteFolderList[i].delete();
			}
			deleteFolder.delete();
		}
	}

    /**
     * replace illegal characters in a filename with "_"
     * illegal characters :
     *           : \ / * ? | < >
     * @param name
     * @return
     */
     public static String sanitizeFileNm(String name) {
       return name.replaceAll("[:\\\\/*?|<>]", "_");
     }

 	public static String writeFile(String filePath, String content) {
		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new FileWriter(filePath));
			bw.write(content);
			bw.flush();
		} catch (IOException e) {
			e.printStackTrace();

			if (bw != null)
				try {
					bw.close();
				} catch (IOException localIOException1) {
				}
		} finally {
			if (bw != null)
				try {
					bw.close();
				} catch (IOException localIOException2) {
				}
		}
		return content;
	}


}
