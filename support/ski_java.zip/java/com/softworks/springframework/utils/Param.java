package com.softworks.springframework.utils;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Clob;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import com.nhncorp.lucy.security.xss.XssPreventer;
import org.apache.commons.lang3.math.NumberUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Param extends HashMap {
	private	final	static long serialVersionUID	= 2135268622818763181L;
	
	private	final	static int	MODE_HASHMAP		= 0;
	private	final	static int	MODE_REQUEST		= 1;
	
	private	final	int			MAX_QUERY_BUFFER	= 256;
	
	private	int					initMode			= -1;

	private HttpServletRequest	_request			= null;
	private Enumeration			_enum				= null;
	
	public Param() {
        super();
        
        initMode = MODE_HASHMAP;
    }
	
	public Param(Object o) {
		this((HashMap) o);

        initMode = MODE_HASHMAP;
	}

    public Param(HashMap map) {
        super();
        
        if(null != map) this.putAll(map);
        initMode = MODE_HASHMAP;
    }

    public Param(Map map) {
    	super();
    	if(null != map) this.putAll(map);
    	initMode = MODE_HASHMAP;
    }

    public Param(HttpServletRequest request) {
        super();
        
        setRequest(request);
        initMode = MODE_REQUEST;
    }
       
    public String getQueryString(String name) {
    	String query = _request.getQueryString();
    	if (null == query) return null;
    	
    	if (query.startsWith(name + "=")) {
    		int pos = query.indexOf("&");
    		
    		if (pos > -1) return query.substring(name.length() + 1, pos);
    		else return query.substring(name.length() + 1);
    	}
    	else {
    		int pos1 = query.indexOf("&" + name + "=");
    		
    		if (pos1 > -1) {
        		int pos2 = query.indexOf("&", pos1 + 1);
        		
        		if (pos2 > -1) return query.substring(pos1 + name.length() + 2, pos2);
        		else return query.substring(pos1 + name.length() + 2);
    		}
    	}
    	return null;
    }
    
    public int getQueryStringCount(String name) {
    	String query = _request.getQueryString();
    	if(null == query) return 0;
    	
    	int cnt = 0;
        int last = 0;
        while(true) {
            int start = query.indexOf(name + "=", last);
            if(start > -1) {
            	cnt++;
                last = start + name.length() + 1;
            }
            else break;
        }
    	return cnt;
    }
    
    private boolean hasQueryString(String name) {
    	String query = _request.getQueryString();
    	if(null == query) return false;
    	
    	if(query.startsWith(name + "=")) return true;
    	else {
    		if (query.indexOf("&" + name + "=") > 0) {
    			return true;
    		}
    	}
    	return false;
    }

    public Param copy() {
    	return (Param)super.clone();
    }
    
    public void put(String column, Clob value) {
    	Reader			reader	= null;
        BufferedReader	buffer	= null;
        StringBuilder	text	= new StringBuilder();

		try {
			String line;
        	reader	= value.getCharacterStream();
            buffer	= new BufferedReader(reader);
            
            while(null != (line = buffer.readLine())) {
            	if("".equals(line)) continue;
            	
            	text.append(line).append("\n");
            }
        } catch(Exception e) {
			set(column, "");
		} finally {
        	try {
        		if(null != buffer) buffer.close();
        		if(null != reader) reader.close();
        	} catch(Exception ce) { }
        }
		
		set(column, text.toString());
    }
    
    public void set(String column, Clob value) {
    	Reader			reader	= null;
        BufferedReader	buffer	= null;
        StringBuilder	text	= new StringBuilder();

		try {
			String line;
        	reader	= value.getCharacterStream();
            buffer	= new BufferedReader(reader);
            
            while(null != (line = buffer.readLine())) {
            	if("".equals(line)) continue;
            	
            	text.append(line).append("\n");
            }
        } catch(Exception e) {
			set(column, "");
		} finally {
        	try {
        		if(null != buffer) buffer.close();
        		if(null != reader) reader.close();
        	} catch(Exception ce) { }
        }
		
		set(column, text.toString());
    }

    public void set(String column, String value) {
        super.put(column, value);
    }

    public void set(String column, Object value) {
        super.put(column, value);
    }

    public void set(String column, int value) {
        super.put(column, Integer.toString(value));
    }

    public void set(String column, long value) {
        super.put(column, Long.toString(value));
    }

    public void set(String column, float value) {
        super.put(column, Float.toString(value));
    }

    public void set(String column, double value) {
        super.put(column, Double.toString(value));
    }
    
    public void set(String column, String[] value) {
    	super.put(column, value);
    }
    
    public void set(String column, InputStream value) {
    	super.put(column, value);
    }

    public int getInt(String column) {
        return getInt(column, 0);
    }

    public int getInt(String column, int v_default) {
        int val = v_default;
        try {
        	if(null != super.get(column)) {
	        	if (super.get(column) instanceof Integer){
	        		return ((Integer)super.get(column)).intValue();
	        	} else if(super.get(column) instanceof BigDecimal) {
	        		return Integer.parseInt(((BigDecimal)super.get(column)).toString());
	        	} else if(super.get(column) instanceof Short) {
	        		return Integer.parseInt(((Short)super.get(column)).toString());
	        	} else if(super.get(column) instanceof BigInteger) {
	        		return Integer.parseInt(((BigInteger)super.get(column)).toString());
	        	} else {
	        		return Integer.parseInt((String)super.get(column));
	        	}
        	}
        }
        catch (NumberFormatException e) {
        }

        return val;
    }

    public long getLong(String column) {
        return getLong(column, 0);
    }

    public long getLong(String column, long v_default) {
        long val = v_default;
        try {
        	if(null != super.get(column)) {
        		if(super.get(column) instanceof BigDecimal)
        			val	= Long.parseLong(((BigDecimal)super.get(column)).toString());
        		else
        			val = (long)super.get(column);
        	}
        }
        catch (NumberFormatException e) {
        }

        return val;

    }

    public String get(String key) {
    	if(null == super.get(key) || nvl(super.get(key)).equals("")) return "";
    	else if(super.get(key) instanceof Clob) {
    		Reader			reader	= null;
            BufferedReader	buffer	= null;
            StringBuilder	text	= new StringBuilder();

    		try {
    			String line;
            	reader	= ((Clob)super.get(key)).getCharacterStream();
                buffer	= new BufferedReader(reader);
                
                while(null != (line = buffer.readLine())) {
                	if("".equals(line)) continue;
                	
                	text.append(line).append("\n");
                }
            } catch(Exception e) {
    			return "";
    		} finally {
            	try {
            		if(null != buffer) buffer.close();
            		if(null != reader) reader.close();
            	} catch(Exception ce) { }
            }
    		
    		return text.toString();
    	}
    	else if(super.get(key) instanceof String[]) {
    		String[] val = (String[])super.get(key);
    		
    		if(0 < val.length) return val[0];
    		else return "";
    	}
    	else return nvl(super.get(key));
    }

    public String get(String key, int value) {
    	if(null == super.get(key) || nvl(super.get(key)).equals("")) return Integer.toString(value);
    	else return nvl(super.get(key));
    }

    public String get(String key, String value) {
    	if(null == super.get(key) || nvl(super.get(key)).equals("")) return value;
    	else return nvl(super.get(key));
    }
    
    public List getList(String key) {
    	return getList(key, new ArrayList());
    }
    
    public List getList(String key, List value) {
    	if(null == super.get(key)) return value;
    	return (List)super.get(key);
    }

    public String getString(String column) {
        return getString(column, "");
     }

    public String getString(String column, String v_default) {
        if(null == super.get(column)) return v_default;
        else {
        	if(super.get(column) instanceof BigDecimal) {
                return super.get(column).toString();
        	}
        }
        
        return (String)super.get(column);
    }
    
    public String getSubString(String key, int index) {
    	try {
    		return getString(key).substring(0, index);
    	} catch(IndexOutOfBoundsException e) {
    		return "";
    	}
    }
    
    public byte[] getByte(String key) {
    	if(null != super.get(key)) {
    		try {
    			return (byte[])super.get(key);
    		} catch(Exception e) {
    			return new byte[0];
    		}
    	}
    	
		return new byte[0];
    }
    
    public String[] getValues(String key){
    	if(null != super.get(key)) {
    		try{
    			Object obj = super.get(key);
    			if (obj instanceof ArrayList){
    				ArrayList list = (ArrayList)obj;
    				return (String[])list.toArray(new String[0]);
    			}else if(obj instanceof String){
    				String[] rv = {(String)obj};
    				return rv;
    			}else{
    				return (String[])obj;
    			}
    		}
    		catch(java.lang.ClassCastException e) {
    			String[] rv = {(String)super.get(key)};
    			return rv;
    		}
    		catch(Exception ee) {
    			String[] rv = {(String)super.get(key)};
    			return rv;
    		}
    	}else{
    		return new String[0] ;
    	}
    }

    public float getFloat(String column) {
        return getFloat(column, 0);
    }

    public float getFloat(String column, float v_default) {
        float val = v_default;
        try {
            val = Float.parseFloat((String)super.get(column));
        }
        catch (NullPointerException e) {
        }

        return val;
    }

    public double getDouble(String column) {
        return getDouble(column, 0);
    }

    public double getDouble(String column, double v_default) {
        double val = v_default;
        try {
            val = Double.parseDouble((String)super.get(column));
        }
        catch (NullPointerException e) {
        }

        return val;
    }

    public void remove(String key) {
    	super.remove(key);
    }

    public String toQueryString() {
    	StringBuffer sb = new StringBuffer();
    	String[] values = null;
    	
    	Set set = this.entrySet();
    	Iterator keys = set.iterator();
    	
    	boolean isFirst = true;
    	while (keys.hasNext()) {
    		String sKey = keys.next().toString();
			if (!isFirst) sb.append("&");
			sb.append(sKey);
    		isFirst = false;
    	}
    	
    	return sb.toString();
    }

    public String toQueryString(String url) {
    	if (toQueryString().equals("")) {
    		return url;
    	}
    	else {
	        if (url.indexOf("?") > -1) return url + "&" + toQueryString();
	        else return url + "?" + toQueryString();
    	}
    }
    
    private static String nvl(Object v) {
    	if(null == v) return "";
    	else return String.valueOf(v);
    }
    
	public String toString() {
    	String s = "";
    	Set set = this.entrySet();
    	for(Iterator it = set.iterator(); it.hasNext();) {
    		String key = it.next().toString();
    		
    		s += "[" + key + "]";
    	}
    	
    	return s;
    }

	public String toJSON() {
		StringBuilder	sb	= new StringBuilder();
		
		sb.append("{");
		for(Iterator it = this.entrySet().iterator();it.hasNext();) {
			String[] tmp = it.next().toString().split("=");

			sb.append("\"").append(tmp[0]).append("\"").append(":")
			  .append("\"").append(2 > tmp.length ? "" : Utils.formatJson(tmp[1])).append("\"").append(",");
		}
		sb.setLength(sb.length() - 1);
		sb.append("}");
		
		return sb.toString();
	}

	public String toNumberJSON() {
		StringBuilder	sb	= new StringBuilder();
		
		sb.append("{");
		for(Iterator it = this.entrySet().iterator();it.hasNext();) {
			String[] tmp = it.next().toString().split("=");

			sb.append("\"").append(tmp[0]).append("\"").append(":");

			if (NumberUtils.isNumber(tmp[1])) {
				sb.append(2 > tmp.length ? "0" : tmp[1]).append(",");
			} else {
				sb.append("\"").append(2 > tmp.length ? "" : tmp[1]).append("\"").append(",");
			}
		}
		sb.setLength(sb.length() - 1);
		sb.append("}");
		
		return sb.toString();
	}
	
    public static Map<String, Object> toMap(JSONObject jsonobj)  throws JSONException {
        Map<String, Object> map = new HashMap<String, Object>();
        Iterator<String> keys = jsonobj.keys();
        while(keys.hasNext()) {
            String key = keys.next();
            Object value = jsonobj.get(key);
            if (value instanceof JSONArray) {
                value = toList((JSONArray) value);
            } else if (value instanceof JSONObject) {
                value = toMap((JSONObject) value);
            }   
            map.put(key, value);
        }   return map;
    }

    public static List<Object> toList(JSONArray array) throws JSONException {
        List<Object> list = new ArrayList<Object>();
        for(int i = 0; i < array.length(); i++) {
            Object value = array.get(i);
            if (value instanceof JSONArray) {
                value = toList((JSONArray) value);
            }
            else if (value instanceof JSONObject) {
                value = toMap((JSONObject) value);
            }
            list.add(value);
        }   return list;
}	
    private String antiBufferOverFlow(String org) {
    	if (org.length() > MAX_QUERY_BUFFER) {
    		return org.substring(0, MAX_QUERY_BUFFER);
    	}
    	else return org;
    }

    public void setRequest(HttpServletRequest request) {
        this._request = request;
        try {
    		_enum = _request.getParameterNames();
    		while(_enum.hasMoreElements()){
    			
    			String key = (String)_enum.nextElement();

    			if (hasQueryString(key)) {
    				String sAnti = nvl(_request.getParameter(key));
    				//System.out.println("--1" + key + " : " + sAnti);
    				sAnti = antiBufferOverFlow(sAnti);
    				//System.out.println("--2" + key + " : " + sAnti);
    				sAnti = XssPreventer.escape(sAnti);
    				//System.out.println("--3" + key + " : " + sAnti);

    				this.put(key, sAnti);
    			} else {
    				String sAnti = nvl(_request.getParameter(key));
    				//System.out.println("--1" + key + " : " + sAnti); 
    				sAnti = XssPreventer.escape(sAnti);
    				//System.out.println("--2" + key + " : " + sAnti); 

    				this.put(key, sAnti);
    			}

    			String[] pv= null;
    			if(null != _request.getParameterValues(key)){
    				pv = _request.getParameterValues(key);
    				int nQueryString = getQueryStringCount(key);
    				
    				for (int i=0; i<pv.length; i++) {
    					if (i < nQueryString) {
    	    				String sAnti = nvl(pv[i]);
    	    				//System.out.println("--1" + key + " : " + sAnti); 
    	    				sAnti = antiBufferOverFlow(sAnti);
    	    				//System.out.println("--2" + key + " : " + sAnti); 
    	    				sAnti = Utils.safeHTML(sAnti);
    	    				//System.out.println("--3" + key + " : " + sAnti); 
    	    				sAnti = XssPreventer.escape(sAnti);
    	    				//System.out.println("--4" + key + " : " + sAnti); 
    	    				
    	    				pv[i] = sAnti;
    					}
    				}
    				
    				if(pv.length > 1) this.put(key, pv);
    			}
    		}
    	}
        catch(Exception e) {
    		e.printStackTrace();
    	}
    }
    
    public boolean isNull(String key) {
    	switch (initMode) {
    	case MODE_HASHMAP :
    		return (null == super.get(key));
    	case MODE_REQUEST :
    		return (null == _request.getParameter(key));
    	}
    	
    	return false;
    }
    
    public String toHiddenForm() {
    	StringBuffer sb = new StringBuffer();
    	
    	Iterator keys = this.entrySet().iterator();
    	while (keys.hasNext()) {
    		String sKey = keys.next().toString();
    		String[] tmp = sKey.split("="); 
			sb.append("<input type=\"hidden\" name=\"" + tmp[0] + "\" value=\"" + (2 == tmp.length ? tmp[1] : "") + "\" />\n" );
    	}
    	
    	return sb.toString();
    }
}