package com.softworks.springframework.utils;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.web.services.CodeLoaderService;
import com.softworks.springframework.web.services.CodeLoaderService.CodeInfo;

public class Utils {
	public static boolean isNotEmpty(final Object obj) {
		if(null == obj) return false;
		else {
			if(obj instanceof String) return "".equals(obj) ? false : true;
			else if(obj instanceof List) return !((List)obj).isEmpty();
			else if(obj instanceof Map) return !((Map)obj).isEmpty();
			else if(obj instanceof Object[]) return 0 == Array.getLength(obj) ? false : true;
			else if(obj instanceof Integer) return true;
			else return false;
		}
	}

	public static int nevl(final Integer val) {
		return nevl(val, 0);
	}

	public static int nevl(final Integer val, int rep) {
		return null == val || 0 >= val ? rep : val;
	}

	public static String nvl(final String org) {
		return nvl(org, "");
	}

	public static String nvl(final String org, final String replace) {
		return null == org || "".equals(org) ? replace : org;
	}

	public static String implode(Object[] vals, String separator) {
		if(null == vals || 0 >= vals.length) return "";

		StringBuilder	sb	= new StringBuilder();

		for(int i = 0, count = vals.length;i < count;i++) {
			if(null == vals[i] || "".equals(vals[i])) continue;
			if(0 < i) sb.append(separator);
			sb.append(vals[i].toString());
		}

		return sb.toString();
	}

	public static boolean inArray(final Object[] vals, final Object value) {
		if(null == vals) return false;

		for(int i = 0, count = vals.length;i < count;i++)
			if(null != vals[i] && vals[i].equals(value)) return true;

		return false;
	}

	public static boolean reverseInArray(final Object[] vals, final Object value) {
        if(null == vals) return false;

        for(int i = 0, count = vals.length;i < count;i++)
            if(null != vals[i] && ((String) vals[i]).equalsIgnoreCase((String) value)) return false;

        return true;
    }

	public static boolean inArray(final Object[] vals, final Object[] values) {
		if(null == vals || null == values) return false;

		String arrays	= implode(vals, ",");
		for(int i = 0, count = values.length;i < count;i++)
			if(null != values[i] && (-1 < arrays.indexOf(values[i] + ",") || arrays.endsWith(values[i].toString()))) return true;

		return false;
	}

	public static String[] convertStringArray(final Object[] array) {
		if(null == array) return new String[0];

		String[] arr	= new String[array.length];
		for(int i = 0, count = array.length;i < count;i++) arr[i]	= (String)array[i];

		return arr;
	}

	public static String[] convertStringArray(final List array) {
		if(null == array) return new String[0];

		String[] arr	= new String[array.size()];
		for(int i = 0, count = array.size();i < count;i++) arr[i]	= array.get(i).toString();

		return arr;
	}

	public static boolean compare(final String source, final String value, final int cursor) {
		if(null == source || "".equals(source) || null == value || "".equals(value)) return false;

		return value.charAt(0) == source.charAt(cursor);
	}

//	public static String MD5(final String str) throws NoSuchAlgorithmException {
//		StringBuffer	sb	= new StringBuffer();
//
//		MessageDigest	md	= MessageDigest.getInstance("MD5");
//						md.update(str.getBytes());
//
//		byte	byteData[]	= md.digest();
//
//		for(int i = 0, cnt = byteData.length;i < cnt; i++)
//		sb.append(Integer.toString((byteData[i]&0xff) + 0x100, 16).substring(1));
//
//		return sb.toString();
//	}

	public static String encript(final String value) throws Exception {
		Cipher			cipher	= null;
		SecretKeySpec	keySpec	= null;

        cipher	= Cipher.getInstance("AES/CBC/PKCS5Padding");
		keySpec	= new SecretKeySpec(Property.getProperty("AES.key").getBytes(), "AES");

		cipher.init(Cipher.ENCRYPT_MODE, keySpec, new IvParameterSpec(Property.getProperty("AES.iv").getBytes()));

		return new String(Base64.encodeBase64(cipher.doFinal(value.getBytes()), false));
	}

	public static String decript(final String value) throws Exception {
		Cipher			cipher	= null;
		SecretKeySpec	keySpec	= null;

        cipher	= Cipher.getInstance("AES/CBC/PKCS5Padding");
		keySpec	= new SecretKeySpec(Property.getProperty("AES.key").getBytes(), "AES");

		cipher.init(Cipher.DECRYPT_MODE, keySpec, new IvParameterSpec(Property.getProperty("AES.iv").getBytes()));

		return new String(cipher.doFinal(Base64.decodeBase64(value)));
	}

	public static String replace(final String source, final String oldPart, final String newPart) {
        if(source == null) return "";
        if(oldPart == null || newPart == null) return source;
        StringBuffer stringbuffer = new StringBuffer();

        int last = 0;
        while(true){
            int start = source.indexOf(oldPart, last);
            if(start >= 0) {
                stringbuffer.append(source.substring(last, start));
                stringbuffer.append(newPart);
                last = start + oldPart.length();
            }
            else {
                stringbuffer.append(source.substring(last));
                return stringbuffer.toString();
            }
        }
    }

	public static String getCharConvertEncoding(final String msg) {
		try {
			return new String(msg.getBytes("UTF-8"), "8859_1");
		} catch(Exception e) {
			return "";
		}
	}

	public static String base64Encode(final String value) {
		return new String(Base64.encodeBase64(value.getBytes(), false));
	}

	public static String base64Decode(final String value) {
		return new String(Base64.decodeBase64(value));
	}

	public static String base64DecodeHidden(final String value) {
		if(null == value || "".equals(value)) return "";

		StringBuilder queryHidden	= new StringBuilder();

		String[]	param	= new String(Base64.decodeBase64(value)).split("&");
		for(int i = 0, count = param.length;i < count;i++) {
			String[]	val	= param[i].split("=");

			queryHidden.append("<input type='hidden' name='").append(val[0]).append("' value='").append(1 < val.length ? val[1] : "").append("' />");
		}

		return queryHidden.toString();
	}

	public static String makeQueryString(final String value) {
        if(null == value || "".equals(value)) return "";

        StringBuilder queryHidden = new StringBuilder();
        queryHidden.append("<input type='hidden' name='queryString'").append(" value='").append(value).append("' />");

        return queryHidden.toString();
    }

	public static String getCodeToName(final String pcode, final String code) {
		List<CodeInfo>	list	= CodeLoaderService.CODE.get(pcode);

		for(int i = 0, count = list.size();i < count;i++) {
			if(code.equals(list.get(i).getCode())) return list.get(i).getName();
		}

		return "";
	}

	public static String getTimeStampString(final String format) {
    	return getTimeStampString(new Date(), format);
    }

	public static String getTimeStampString(final Date date) {
		return getTimeStampString(date, "yyyyMMddHHmmss");
	}

    public static String getTimeStampString(final Date date, final String format){
    	java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat (format, java.util.Locale.KOREA);
    	return formatter.format(date);
    }

    public static String getTimeStampString(String date, final String format) {
    	try {
    	    if (date == null || "".equals(date)) return "";

    	    if (date.length() == 14) {
    	    } else if (date.length() == 12)
    	        date += "00";
    	    else if (date.length() == 10)
    	        date += "0000";
    	    else if (date.length() == 8)
    	        date += "000000";
    	    else if(date.length() == 6)
    	        date += "01000000";
    	    else if(date.length() == 4)
    	        date += "0101000000";
    	    else
    	        return "";

    		java.text.SimpleDateFormat tmpFormat = new java.text.SimpleDateFormat("yyyyMMddHHmmss", java.util.Locale.KOREA);

	    	Date d = null;

	    	if (date.equals(""))
	    		d = new Date();
	    	else {
	    	    tmpFormat.setLenient(true);
	    		d = tmpFormat.parse(date);
	    	}

	    	return getTimeStampString(d, format);
    	} catch(Exception e) {
    		e.printStackTrace();
    		return "";
    	}
    }

    public static String getAfterDay(final int date) {
    	java.util.Calendar cal = java.util.Calendar.getInstance();
    	cal.add(java.util.Calendar.DATE, date);

    	return getTimeStampString(cal.getTime());
    }

    public static String getAfterDay(final int date, final String format) {
    	java.util.Calendar cal = java.util.Calendar.getInstance();
    	cal.add(java.util.Calendar.DATE, date);

    	return getTimeStampString(cal.getTime(), format);
    }

    public static String getAfterMonth(final int date) {
    	return getAfterMonth(date, "yyyyMMddHHmmss");
    }

    public static String getLastDay(final String format) {
    	Date	date	= new Date();
				date.setMonth(date.getMonth() + 1);
    			date.setDate(0);

    	return (new java.text.SimpleDateFormat(format, java.util.Locale.KOREA)).format(date);
    }

    public static String getAfterMonth(final int date, final String format) {
    	java.util.Calendar	cal	= java.util.Calendar.getInstance();
    	cal.add(java.util.Calendar.MONTH, date);

    	return getTimeStampString(cal.getTime(), format);
    }

	public static String getSecondToDatetime(final long second) {
		long	day	= second / 86400;
		return 0 < day ? (second / 86400) + "일 " + ((second % 86400) / 3600) + "시간 " + ((second % 86400 % 3600) / 60) + "분 " + (second % 86400 % 3600 % 60) + "초"
				: (second / 3600) + "시간 " + ((second % 3600) / 60) + "분 " + (second % 3600 % 60) + "초";
	}

	 public String formatTime(long lTime) {
	        Calendar c = Calendar.getInstance();
	        c.setTimeInMillis(lTime);
	        return (c.get(Calendar.HOUR_OF_DAY) + "시 " + c.get(Calendar.MINUTE) + "분 " + c.get(Calendar.SECOND) + "." + c.get(Calendar.MILLISECOND) + "초");
	    }

    public static boolean hasQueryString(final String query, final String name) {
    	if(query == null) return false;

    	if(query.startsWith(name + "=")) return true;
    	else
    		if(query.indexOf("&" + name + "=") > 0) return true;

    	return false;
    }

    public static String fillCharacter(final String value, final String fill, final int len, final boolean direction) {
    	StringBuilder	fillText	= new StringBuilder();

    	for(int i = 0, length = len - value.length();i < length;i++)
    		fillText.append(fill);

    	return direction ? fillText.insert(0, value).toString() : fillText.append(value).toString();
    }

    public static String formatHTML(final String source) {
    	String	sReturn	= replace(source, "\r\n", "<br>");
    			sReturn = replace(sReturn, "\n", "<br>");
    			sReturn = replace(sReturn, " ", "&nbsp;");

    	return	sReturn;
    }

    public static String formatJson(final String source) {
        String  sReturn = replace(source, "\r\n", "<br/>");
                sReturn = replace(sReturn, " \n", "<br/>");
                sReturn = replace(sReturn, "\n", "<br/>");
                sReturn = replace(sReturn, "[", "&#91;");
                sReturn = replace(sReturn, "]", "&#93;");
                sReturn = replace(sReturn, "\"", "&#34;");
                sReturn = replace(sReturn, "\\", "&#92;");

        return  sReturn;
     }

    public static String safeHTML(String str) {
    	str	= replace(str, "&", "&amp;");
    	str	= replace(str, "#", "&#35;");
    	str	= replace(str, "<", "&lt;");
    	str	= replace(str, ">", "&gt;");
    	str	= replace(str, "(", "&#40;");
    	str	= replace(str, ")", "&#41;");
    	str	= replace(str, "\"", "&quot;");
    	str	= replace(str, "\'", "&#39;");

		return str;
    }

    public static String safeCrossScript(String value) {
    	value	= value.replaceAll("eval\\((.*)\\)", "");
    	value	= value.replaceAll("[\\\"\\\'][\\s]*javascript:(.*)[\\\"\\\']", "\"\"");
//    	value	= value.replaceAll("[\\<\\s]*form", "");
    	value	= value.replaceAll("\"", "");
    	value	= replace(value, "%", "");
    	value	= replace(value, "javascript", "");
    	value	= replace(value, "script", "");
    	value	= replace(value, "object", "");
    	value	= replace(value, "applet", "");
    	value	= replace(value, "embed", "");
    	value	= replace(value, "iframe", "");

    	return value;
    }

    public static String DBtoHtml(String str) {

    	str	= str.replaceAll("&amp;","&");
    	str	= str.replaceAll("&#35;","#");
    	str	= str.replaceAll("&lt;","<");
    	str	= str.replaceAll("&gt;",">");
    	str	= str.replaceAll("&#40;","\\(");
    	str	= str.replaceAll("&#41;","\\)");
    	str	= str.replaceAll("&quot;","\"");
    	str	= str.replaceAll("&#39;","\'");
    	str	= str.replaceAll("&nbsp;"," ");
		return str;
    }

    public static String safeCrossScriptParameter(final String queryString, final String key, String value) {
    	/* URIEncoding Setting을 UTF-8로 하지 않았을 경우에 주석 해제
    	try {
    		if(hasQueryString(queryString, key))
    			value	= new String(value.getBytes("8859_1"), "UTF-8");
    	} catch(Exception e) { }
    	*/
    	return safeCrossScript(value);
    }

    public static void deleteFile(final String fileFullName) throws Exception {
    	java.io.File	file	= new java.io.File(fileFullName);

    	if(!file.exists()) throw new Exception("파일이 존재하지 않습니다.");
    	if(!file.delete()) throw new Exception("파일을 삭제할 수 없습니다.");
    }

    public static void saveUploadFile(final String copyPath, final String copyName, final byte[] file, final long size, final String orgName, final boolean extention) throws IOException, Exception {
    	long 	maxSize	= Long.parseLong(Property.getProperty("file.max.size"));

    	if(0 >= size) throw new Exception("첨부파일이 비었습니다.");
    	else if(null == file) throw new Exception("파일이 존재하지 않습니다.");
    	else if(maxSize < size) throw new Exception("첨부파일의 업로드 용량이 초과되었습니다.");
    	else if("".equals(copyName)) throw new Exception("복사할 파일명이 지정되지 않았습니다.");
    	else if(reverseInArray(new Object[] {"DOC", "DOCX", "XLS", "XLSX", "PDF", "TXT", "PPT","PPTX", "JPG", "PNG", "GIF", "HWP", "ZIP","WAR"}, orgName.substring(orgName.lastIndexOf(".") + 1)))
    	    throw new Exception("업로드 할 수 없는 유형의 첨부파일 입니다.");
    	File uploadPath = new File(copyPath);
	    if(!uploadPath.exists()){
	    	uploadPath.mkdirs();
	    }
    	FileCopyUtils.copy(file, new java.io.File(copyPath, copyName + (extention ? orgName.substring(orgName.lastIndexOf(".")) : "")));
    }

    public static String getFileName(final String filename) {
    	if(null == filename || "".equals(filename)) return "";

    	return -1 < filename.lastIndexOf(".") ? filename.substring(filename.lastIndexOf("/") + 1) : filename;
    }

    public static StringBuilder	getCodeListToJSON(final List<CodeInfo> list) {
    	StringBuilder	buff	= new StringBuilder();

    	buff.append("[");
    	for(int i = 0, count = list.size();i < count;i++) {
    		if(0 < i) buff.append(",");
    		buff.append("{")
	    			.append("\"code\"").append(":\"").append(list.get(i).getCode()).append("\"").append(",")
	    			.append("\"name\"").append(":\"").append(list.get(i).getName()).append("\"")
	    		.append("}");
    	}
    	buff.append("]");

    	return buff;
    }

    public static StringBuilder getListJSON(final List<Param> list) {
    	StringBuilder	buff	= new StringBuilder();

    	buff.append("[");
    	for(int i = 0, count = list.size();i < count;i++) {
    		if(0 < i) buff.append(",");
    		buff.append(((Param)list.get(i)).toJSON());
    	}
    	buff.append("]");

    	return buff;
    }

    public static StringBuilder getListNumberJSON(final List<Param> list) {
    	StringBuilder	buff	= new StringBuilder();

    	buff.append("[");
    	for(int i = 0, count = list.size();i < count;i++) {
    		if(0 < i) buff.append(",");
    		buff.append(((Param)list.get(i)).toNumberJSON());
    	}
    	buff.append("]");

    	return buff;
    }

    public static String sendMessage(final HttpServletRequest req, final String message) {
    	return sendMessage(req, message, null, null);
    }

    public static String sendMessage(final HttpServletRequest req, final String message, final String location) {
    	return sendMessage(req, message, location, null);
    }

    public static String sendMessage(final HttpServletRequest req, final String message, final String location, final String hiddenQuery) {
    	req.setAttribute("message", message);
    	req.setAttribute("location", location);
    	req.setAttribute("hiddenQuery", hiddenQuery);

    	return "sendMessage";
    }

    public static ModelAndView sendMessageModel(final String code) {
    	return sendMessageModel(code, null);
    }

    public static ModelAndView sendMessageModel(final String code, final String location) {
    	HashMap<String,Object>	param	= new HashMap<String,Object>();
						    	param.put("code", code);
								param.put("location", location);

		return new ModelAndView(new RedirectView("/sendMessage"), param);
    }

    public static void sendUserScript(final HttpServletResponse res, StringBuilder script) {
    	ServletOutputStream	out = null;

		try {
			script.insert(0, "<script type=\"text/javascript\">");
			script.append("</script>");

			res.setContentType("text/html; UTF-8");
			out	= res.getOutputStream();
			out.write(script.toString().getBytes());
			out.flush();
		} catch(Exception e) {
		} finally {
			if(null != out) try { out.close(); } catch(IOException ie) {}
		}
    }

    /**
     * 시스템의 오늘 일자 반.
     */
    public static Date getToday() {
        Calendar cal = Calendar.getInstance();
        cal.setTime( new Date() );
        return cal.getTime();
    }

    /**
     * 문자열을 날짜형으로 변환.
     */
    public static Date getToday(String date) {
        Calendar cal = Calendar.getInstance();
        try {
        	cal.setTime( str2Date(date) );
        } catch (Exception e) {
        	return null;
        }
        return cal.getTime();
    }

    /**
     *  날짜를 문자열로 변환.
     */
    public static String date2Str(Date date) {
        SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");
        return ft.format( date.getTime() );
    }

    /**
     *  날짜를 문자열로 변환 yymmdd
     */
    public static String date6Str(Date date) {
        SimpleDateFormat ft = new SimpleDateFormat("yyMMdd");
        return ft.format( date.getTime() );
    }

    /**
     *  날짜를 문자열로 변환.yyyy-MM
     */
    public static String date4Str(Date date) {
        SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM");
        return ft.format( date.getTime() );
    }

    /**
     *  문자열을 날짜(yyyy-MM-dd)로 변환.
     */
    public static Date str2Date(String date) throws Exception {
        SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");
        Date ret = null;
        try {
            ret = ft.parse( date ) ;
        } catch (ParseException ex) {
        	throw new Exception("날짜 형식을 파싱할 수 없습니다.");
        }
        return ret ;
    }

    /**
     *  문자열을 날짜(yyMMdd)로 변환.
     */
    public static Date date6Str(String date) throws Exception {
        SimpleDateFormat ft = new SimpleDateFormat("yyMMdd");
        Date ret = null;
        try {
            ret = ft.parse( date ) ;
        } catch (ParseException ex) {
        	throw new Exception("날짜 형식을 파싱할 수 없습니다.");
        }
        return ret ;
    }


    /**
     *  2자리 년도 반환 .
     */
    public static String year2Str(Date date) {
        SimpleDateFormat ft = new SimpleDateFormat("yy");
        return ft.format( date.getTime() );
    }

    /**
     * 년도 추출.
     */
    public static Integer getYear(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime( date );

        return cal.get(Calendar.YEAR);
    }

    /**
     * 월 추출.
     */
    public static Integer getMonth(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime( date );

        return cal.get(Calendar.MONTH) + 1;
    }
    
    /**
     * 월 마지막 일 추출.
     */
    public static Integer getActualMaximum(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime( date );
        cal.add(Calendar.MONTH, -1);

        return cal.getActualMaximum(Calendar.DAY_OF_MONTH);
    }

	 /**
	  * 숫자에 천단위마다 콤마 넣기
	  * @param int
	  * @return String
	  * */
	 public static String toNumFormat(int num) {
	  DecimalFormat df = new DecimalFormat("#,###");
	  return df.format(num);
	 }

	 /**
	  * 숫자를 한글짜씩 끊어서 Html 형태로 변경하기
	  * @param int
	  * @return String
	  * */
	 public static String toHtmlFormat(int num) {

		String df = Integer.toString(num).trim();
	    StringBuilder	sb	= new StringBuilder();
	    df = "     " + df;
	    df = df.substring(df.length() - 5, df.length());

/*
        <span><hr></span>
        <span>1<hr></span>
        <span>0<hr></span>
        <span>5<hr></span>
        <span>8<hr></span>
	*/
        for (int i=0; i < df.length(); i++) {
      		sb.append("<span>");
			sb.append(df.charAt(i));
	  		sb.append("<hr></span>\n");
        }

	  return sb.toString();
	 }

	 /**
	  * 숫자를 한글짜씩 끊어서 Html 형태로 변경하기
	  * @param int
	  * @return String
	  * */
	 public static String toHtmlFormat3(int num) {

		String df = Integer.toString(num).trim();
	    StringBuilder	sb	= new StringBuilder();
	    df = "   " + df;
	    df = df.substring(df.length() - 3, df.length());
        for (int i=0; i < df.length(); i++) {
      		sb.append("<span>");
			sb.append(df.charAt(i));
	  		sb.append("<hr></span>\n");
        }

	  return sb.toString();
	 }

	 /**
	     * 시스템의 한달 전 일자 .
	     */
	public static Date getMonthAgo() {
	    Calendar cal = Calendar.getInstance();
	    cal.setTime(new Date());
	    cal.add(Calendar.MONTH, -1);
	    return cal.getTime();
	}

	/**
     * 시스템의 하루 전 일자 .
     */
	public static Date getDayAgo() {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, -1);
        return cal.getTime();
    }

	/**
     * 입력값의 하루 전 일자 .
     */
    public static Date getDayAgo(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, -1);
        return cal.getTime();
    }

	/**
     * 유닉스 시간을 받아 yymmdd 형태 문자열로 반환 .
     */
	public static String getUnixTimeToStr(String unixTimeStr) {

	    long unixTime = Long.parseLong(unixTimeStr) * 1000;

	    Date date = new Date(unixTime);

	    return date6Str(date);
	}

	public static String getMd5(String str) throws Exception {
	String output = "";
	try {
		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(str.getBytes());
		byte byteData[] = md.digest();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < byteData.length; i++) {
			sb.append(Integer.toString((byteData[i]&0xff) + 0x100, 16).substring(1));
		}
		output = sb.toString();
	} catch (NoSuchAlgorithmException e) {
		output = null;
	}

	return output;
}


}