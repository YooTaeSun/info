package com.softworks.springframework.utils;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TemplateParsing {

	private	final Logger		logger	= Logger.getLogger(getClass());

	private	final static String	EXCEL_XLS	= "xls";
	private final static String	EXCEL_XLSX	= "xlsx";
	
	private	final SimpleDateFormat format	= new SimpleDateFormat("yyyy-MM-dd");

	private	String	localFlag = "N";
	private	String	no;
	
	private	int	startCol;
	private	int	startRow;
	private	String[] title;
	private	List<Param> data	= new ArrayList<Param>();

	public TemplateParsing(final String req_no, final Param info) {
		this.no		= req_no;
		
		title		= info.get("title_text").split(",");
		startCol	= (int)info.get("title_line").charAt(0) - 65;
		startRow	= Integer.parseInt(info.get("title_line").substring(1));
		System.out.println("startRow : " + (int)info.get("title_line").charAt(0));
		System.out.println("startCol : " + startCol);
		System.out.println("startRow : " + startRow);

		String serverFlag	= info.get("serverFlag", "");
		System.out.println("serverFlag : " + serverFlag);

		if (serverFlag.equals("") || serverFlag.equals("LOCAL")) {
			localFlag = "Y";
		} else {
			localFlag = "N";
		}
		System.out.println("localFlag : " + localFlag);
	}
	
	public List<Param> parse(final InputStream is, String type) throws Exception {
		try {
			switch(type.toLowerCase()) {
				case EXCEL_XLS:
					xls_load(new HSSFWorkbook(is));
					break;
				case EXCEL_XLSX:
					xlsx_load(new XSSFWorkbook(is));
					break;
				default:
					logger.fatal("엑셀 파일의 타입이 지정된 형식과 일치하지 않습니다.", new Exception("엑셀파일 인식불가"));
			}
			
			return data;
		} catch(Exception e) {
			logger.error("템플릿 파싱중 오류", e);
			throw e;
		}
	}
		
	private void xls_load(final HSSFWorkbook book) throws Exception {
//		for(int i = 0, cnt = book.getNumberOfSheets();i < cnt;i++) { // 0번 시트만 파싱하도록 수정
//			HSSFSheet	sheet	= book.getSheetAt(i);
			HSSFSheet	sheet	= book.getSheetAt(0);
			
			int	cols	= 0;
			int rows	= sheet.getPhysicalNumberOfRows();
			if(startRow > rows) throw new Exception("데이터가 존재하지 않습니다.");
			
			for(int j = startRow;j < rows;j++) {
				HSSFRow	row	= sheet.getRow(j);
				
				if(null == row) continue;
				
				cols	= startCol + title.length;
				if(cols > row.getPhysicalNumberOfCells()) throw new Exception("올바르지 않은 데이터 형식입니다.");
				System.out.println("cols : " + cols);
				
				Param	param	= new Param();
						param.set("req_no", this.no);
				for(int k = startCol;k <= cols;k++) {
					HSSFCell	cell	= row.getCell(k);
					
					if(null == cell) continue;
					
					switch(cell.getCellType()) {
						case HSSFCell.CELL_TYPE_STRING:
							String strValue = cell.getStringCellValue();
							//System.out.println("strValue.getBytes() -> UTF-8 : " + new String(strValue.getBytes(), "UTF-8"));
							//charset(strValue);
							if (localFlag.equals("Y")) {
								param.set(title[k - startCol], new String(strValue.getBytes(), "EUC-KR"));
							} else {
								param.set(title[k - startCol], new String(strValue.getBytes(), "UTF-8"));
							}
							//param.set(title[k - startCol], new String(cell.getStringCellValue().getBytes(), "EUC-KR"));
					 		break;
						case HSSFCell.CELL_TYPE_FORMULA:
						case HSSFCell.CELL_TYPE_NUMERIC:
							if(HSSFDateUtil.isCellDateFormatted(cell))
								param.set(title[k - startCol], format.format(cell.getDateCellValue()));
							else
								param.set(title[k - startCol], (int)cell.getNumericCellValue());
							break;
					}
				}
				
				if(!"".equals(param.get(title[0]))) data.add(param);
			}
//		}
	}
	
	private void xlsx_load(final XSSFWorkbook book) throws Exception {
//		for(int k = 0, sheets = book.getNumberOfSheets();k < sheets;k++) { // 0번 시트만 파싱하도록 수정
//			XSSFSheet	sheet	= book.getSheetAt(k);
			XSSFSheet	sheet	= book.getSheetAt(0);
			
			int cols	= 0;
			int rows	= sheet.getPhysicalNumberOfRows();

			if(startRow > rows) throw new Exception("데이터가 존재하지 않습니다.");
			
			for(int j = startRow;j < rows;j++) {
				XSSFRow	row	= sheet.getRow(j);
				
				if(null == row) continue;
				
				cols	= startCol + title.length;
				if(cols > row.getPhysicalNumberOfCells()) throw new Exception("올바르지 않은 데이터 형식입니다.");
				
				Param	param	= new Param();
						param.set("req_no", this.no);
				for(int i = startCol;i <= cols;i++) {
					XSSFCell	cell	= row.getCell(i);
					
					if(null == cell) continue;
					
					switch(cell.getCellType()) {
						case HSSFCell.CELL_TYPE_STRING:
							String strValue = cell.getStringCellValue();
							//System.out.println("strValue.getBytes() -> UTF-8 : " + new String(strValue.getBytes(), "UTF-8"));
							//charset(strValue);
							if (localFlag.equals("Y")) {
								param.set(title[i - startCol], new String(strValue.getBytes(), "EUC-KR"));
							} else {
								param.set(title[i - startCol], new String(strValue.getBytes(), "UTF-8"));
							}
							//param.set(title[i - startCol], new String(cell.getStringCellValue().getBytes(), "EUC-KR"));
					 		break;
						case HSSFCell.CELL_TYPE_FORMULA:
						case HSSFCell.CELL_TYPE_NUMERIC:
							if(HSSFDateUtil.isCellDateFormatted(cell))
								param.set(title[i - startCol], format.format(cell.getDateCellValue()));
							else
								param.set(title[i - startCol], (int)cell.getNumericCellValue());
							break;
					}
				}
				if(!"".equals(param.get(title[0]))) data.add(param);
			}
//		}
	}
	
	private void charset(final String strValue) throws Exception {
		System.out.println("strValue : " + strValue);
		System.out.println("strValue.getBytes() -> EUC-KR : " + new String(strValue.getBytes(), "EUC-KR"));
		System.out.println("strValue.getBytes() -> UTF-8 : " + new String(strValue.getBytes(), "UTF-8"));
		System.out.println("strValue.getBytes() -> ISO-8859-1 : " + new String(strValue.getBytes(), "ISO-8859-1"));
		System.out.println("strValue.getBytes(\"EUC-KR\") -> UTF-8 : " + new String(strValue.getBytes("EUC-KR"), "UTF-8"));
		System.out.println("strValue.getBytes(\"EUC-KR\") -> ISO-8859-1 : " + new String(strValue.getBytes("EUC-KR"), "ISO-8859-1"));
		System.out.println("strValue.getBytes(\"UTF-8\") -> EUC-KR : " + new String(strValue.getBytes("UTF-8"), "EUC-KR"));
		System.out.println("strValue.getBytes(\"UTF-8\") -> ISO-8859-1 : " + new String(strValue.getBytes("UTF-8"), "ISO-8859-1"));
		System.out.println("strValue.getBytes(\"ISO-8859-1\") -> EUC-KR : " + new String(strValue.getBytes("ISO-8859-1"), "EUC-KR"));
		System.out.println("strValue.getBytes(\"ISO-8859-1\") -> UTF-8 : " + new String(strValue.getBytes("ISO-8859-1"), "UTF-8"));
	}

}
