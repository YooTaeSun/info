package com.softworks.springframework.utils;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import com.nhncorp.lucy.security.xss.XssPreventer;

public class RequestWrapper extends HttpServletRequestWrapper {
	
	public RequestWrapper(HttpServletRequest request) {
		super(request);
	}
	
	@Override
	public String getHeader(String name) {
		if(null == super.getHeader(name)) return null;
		
		return XssPreventer.escape(Utils.safeCrossScript(super.getHeader(name)));
	}
	
	@Override
	public String getParameter(String key) {
		if(null == super.getParameter(key)) return null;
		
		return XssPreventer.escape(Utils.safeCrossScriptParameter(super.getQueryString(), key, super.getParameter(key)));
	}
	
	@Override
	public String[] getParameterValues(String key) {
		String values[]	= super.getParameterValues(key);
		
		if(null == values) return null;
		
		for(int i = 0, count = values.length;i < count;i++)
			values[i]	= XssPreventer.escape(Utils.safeCrossScriptParameter(super.getQueryString(), key, values[i]));
		
		return values;
	}

}
