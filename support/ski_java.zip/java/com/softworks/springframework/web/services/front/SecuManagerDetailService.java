package com.softworks.springframework.web.services.front;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;
import com.softworks.springframework.web.services.MailSendService;
import com.softworks.springframework.web.services.MenuLoaderService;
import com.softworks.springframework.web.services.backoffice.MenuService;

@Service
public class SecuManagerDetailService extends BaseService {

	@Autowired
	private	MenuService menuSvc;

	@Autowired
	private	MenuLoaderService	menuLoader;

	@Autowired
	private MailSendService	mailSendService;

	@Autowired
	private SecurityAuditService	securityAuditSvc;

	@Transactional(readOnly=true)
	public int getListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));

		return session.selectOne("com.softworks.springframework.SecuManagerDetail.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) {
		return session.selectList("com.softworks.springframework.SecuManagerDetail.getList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getAllList(final Param param) {
		return session.selectList("com.softworks.springframework.SecuManagerDetail.getAllList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getExcelList(final Param param) {
		return session.selectList("com.softworks.springframework.SecuManagerDetail.getExcelList", param);
	}

	@Transactional(readOnly=true)
	public Param getDetail(Param param) {
		return session.selectOne("com.softworks.springframework.SecuManagerDetail.getAllList", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int insert(final Param param) throws SQLException {
		return session.insert("com.softworks.springframework.SecuManagerDetail.insert", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void update(final Param param) throws Exception {
		session.update("com.softworks.springframework.SecuManagerDetail.update", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void delete(final Param param) throws Exception {
		session.delete("com.softworks.springframework.SecuManagerDetail.delete", param);
	}

	@Transactional(readOnly=true)
	public Param getAuth(Param param) {
		return session.selectOne("com.softworks.springframework.SecuManagerDetail.getAuth", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteManager(final Param param) throws Exception {

		Param detail = this.getDetail(param);
		String privilegeCd = detail.get("PRIVILEGE_CD");

		//메뉴 권한 삭제
		if(privilegeCd.equals("R") || privilegeCd.equals("P")) {//R 조회, P 업무

			Param securityAuditDetail = securityAuditSvc.getDetail(param);
			String audit_nm = securityAuditDetail.get("AUDIT_NM");

			//메일서비스  EM05		실시간	-	보안 담당자	[알림] 수검/감사 담당자 해제	{AUDIT_NM}	{AUDIT_NM} 수검/감사 담당자로 해제 되었습니다.
			String emp_no = detail.get("EMP_NO");
			Param contentReplaceParam = new Param();
			contentReplaceParam.set("#AUDIT_NM#", audit_nm);
//			mailSendService.sendMail2("EM05", emp_no, contentReplaceParam);

			String noti_id = "C05";
			String schd_id = "C05";
			mailSendService.setNotiHist(noti_id, emp_no, "Y", schd_id, contentReplaceParam);

			Param param01 = new Param();
			param01.put("emp_no", detail.get("EMP_NO"));
			param01.put("privilege_cd_id", "AUDIT_PRIVILEGE_CD");//AUDIT_PRIVILEGE_CD, CHKLIST_PRIVILEGE_CD
			param01.put("privilegeCdList", Arrays.asList("P", "R"));

			List<Param> list = this.getAllList(param01);

			if(list != null && list.size() == 1) {
				this.revmoeAuthMenu(detail.get("EMP_NO"), "AUDIT");// searchType (AUDIT , CHKLIST)
			}
		}
		this.delete(param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteManager(String emp_no, String audit_nm, String job_nm, Param param) throws Exception {

		//메일서비스  EM05		실시간	-	보안 담당자	[알림] 수검/감사 담당자 해제	{AUDIT_NM}	{AUDIT_NM} 수검/감사 담당자로 해제 되었습니다.
		Param contentReplaceParam = new Param();
		contentReplaceParam.set("#AUDIT_NM#", audit_nm);
		contentReplaceParam.set("#JOB_NM#", job_nm);

		String noti_id = "C05";
		String schd_id = "C05";
		mailSendService.setNotiHist(noti_id, emp_no, "Y", schd_id, contentReplaceParam);

		Param param01 = new Param();
		param01.put("emp_no", emp_no);
		param01.put("privilege_cd_id", "AUDIT_PRIVILEGE_CD");//AUDIT_PRIVILEGE_CD, CHKLIST_PRIVILEGE_CD
		param01.put("privilegeCdList", Arrays.asList("P", "R"));

		List<Param> list = this.getAllList(param01);

		if(list != null && list.size() == 1) {
			this.revmoeAuthMenu(emp_no, "AUDIT");// searchType (AUDIT , CHKLIST)
		}
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void registerNotiManager(String emp_no, String audit_nm, String job_nm) throws Exception {

		//메일서비스  EM04		실시간	-	보안 담당자	[알림] 수검/감사 담당자 지정	{AUDIT_NM}	"{AUDIT_NM} 수검/감사 담당자로 지정 되었습니다.
		Param contentReplaceParam = new Param();
		contentReplaceParam.set("#AUDIT_NM#", audit_nm);
		contentReplaceParam.set("#JOB_NM#", job_nm);

		String noti_id = "C04";
		String schd_id = "C04";
		mailSendService.setNotiHist(noti_id, emp_no, "Y", schd_id, contentReplaceParam);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void registerManager(String emp_no, String audit_nm, String job_nm) throws Exception {
		this.addAuthMenu(emp_no, "AUDIT", "SH");//보안수검/감사(AUDIT), 증정(CHKLIST), privilegeCd C:조회, U:업무

		//메일서비스  EM04		실시간	-	보안 담당자	[알림] 수검/감사 담당자 지정	{AUDIT_NM}	"{AUDIT_NM} 수검/감사 담당자로 지정 되었습니다.
		Param contentReplaceParam = new Param();
		contentReplaceParam.set("#AUDIT_NM#", audit_nm);
		contentReplaceParam.set("#JOB_NM#", job_nm);

		String noti_id = "C04";
		String schd_id = "C04";
		mailSendService.setNotiHist(noti_id, emp_no, "Y", schd_id, contentReplaceParam);
	}


	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updatePrivilegeManager(final Param param) throws Exception {

		Param detailParam = new Param();
		detailParam.put("manager_id", param.get("manager_id"));
		detailParam.put("manager_sn", param.get("manager_sn"));
		Param detail = this.getDetail(detailParam);

		String emp_no = detail.get("EMP_NO");
		String before_privilege_cd = detail.get("PRIVILEGE_CD");

		Param securityAuditDetail = securityAuditSvc.getDetail(param);
		String audit_nm = securityAuditDetail.get("AUDIT_NM");

		String privilegeCd = param.get("privilege_cd");
		String job_nm = param.get("privilege_cd_nm");

		//R(조회), U(업무), NA
		if(before_privilege_cd.equals("R") && privilegeCd.equals("R")) {
			logger.debug("[updatePrivilegeManager] 해당 사항 없음");
		}else if(before_privilege_cd.equals("R") && privilegeCd.equals("U")) {
			logger.debug("[updatePrivilegeManager] 조회 -> 업무");
			this.registerNotiManager(emp_no, audit_nm, job_nm);
		}else if(before_privilege_cd.equals("R") && privilegeCd.equals("NA")) {
			logger.debug("[updatePrivilegeManager] 조회 -> NA");
			this.deleteManager(emp_no, audit_nm, job_nm, param);
		}
		else if(before_privilege_cd.equals("U") && privilegeCd.equals("R")) {
			logger.debug("[updatePrivilegeManager] 업무 -> 조회");
			this.registerNotiManager(emp_no, audit_nm, job_nm);
		}else if(before_privilege_cd.equals("U") && privilegeCd.equals("U")) {
			logger.debug("[updatePrivilegeManager] 해당 사항 없음");
		}else if(before_privilege_cd.equals("U") && privilegeCd.equals("NA")) {
			logger.debug("[updatePrivilegeManager] 업무 -> NA");
			this.deleteManager(emp_no, audit_nm, job_nm, param);
		}
		else if(before_privilege_cd.equals("NA") && privilegeCd.equals("R")) {
			logger.debug("[updatePrivilegeManager] NA -> 조회");
			this.registerManager(emp_no, audit_nm, job_nm);
		}else if(before_privilege_cd.equals("NA") && privilegeCd.equals("U")) {
			logger.debug("[updatePrivilegeManager] NA -> 업무");
			this.registerManager(emp_no, audit_nm, job_nm);
		}else if(before_privilege_cd.equals("NA") && privilegeCd.equals("NA")) {
			logger.debug("[updatePrivilegeManager] 해당 사항 없음");
		}

		Param updateParam = new Param();
		updateParam.put("uid", param.get("uid"));
		updateParam.put("uname", param.get("uname"));
		updateParam.put("privilege_cd", param.get("privilege_cd"));
		updateParam.put("manager_id", param.get("manager_id"));
		updateParam.put("manager_sn", param.get("manager_sn"));
		this.update(updateParam);

	}

	public void revmoeAuthMenu(String user_id, String searchType) throws Exception {
		//NN (없음), SN (조회만), SH (조회처리)
		modifyAuthMenu(user_id, searchType, "REMOVE","NN");
	}

	public void revmoeAuthMenu(String user_id, String searchType, String mask) throws Exception {
		//NN (없음), SN (조회만), SH (조회처리)
		modifyAuthMenu(user_id, searchType, "REMOVE", mask);
	}

	public void addAuthMenu(String user_id, String searchType, String mask) throws Exception {
		//NN (없음), SN (조회만), SH (조회처리)
		modifyAuthMenu(user_id, searchType, "ADD", mask);
	}

	private void modifyAuthMenu(String user_id, String searchType, String type, String upMask) throws Exception {

		if(searchType.isEmpty()) {
			throw new RuntimeException("Need searchType");
		}

		Param menuParam = new Param();
		menuParam.put("user_id", user_id);
		menuParam.put("type", "F");
		List<Param> menuAuthList = menuSvc.getAllMenuAuthList(menuParam);

		menuParam.put("searchType", searchType); //보안수검/감사
		List<Param> updateMenulist = session.selectList("com.softworks.springframework.SecuManager.getAllMenuAuthList", menuParam);

		if(menuAuthList != null && menuAuthList.size() > 0 && updateMenulist != null && updateMenulist.size() > 0) {

			int cnt = menuAuthList.size();
			Param menuAuth = null;
			Param updateMenu = null;
			String[] menu	= new String[cnt];
			String[] auth	= new String[cnt];
			String[] old	= new String[cnt];
			String mask = "";
			String menuId = "";
			Map<String, List<Param>> menuAuthMap = menuAuthList.stream().collect(Collectors.groupingBy(x->((Param)x).get("MENU_ID")));

			String mask_002001 =  menuAuthMap.get("002001").get(0).get("MASK");//보안증적관리
			String mask_002002 =  menuAuthMap.get("002002").get(0).get("MASK");//보안수검/감사
			String mask_002003 =  menuAuthMap.get("002003").get(0).get("MASK");//보안준수사항고지
			String mask_002004 =  menuAuthMap.get("002004").get(0).get("MASK");//보안자산관리
			String mask_002001003 =  menuAuthMap.get("002001003").get(0).get("MASK");//국내법규개정이력

			for (int mi = 0; mi < menuAuthList.size(); mi++) {

				menuAuth = menuAuthList.get(mi);
				menuId = menuAuth.get("MENU_ID");
				menu[mi] = menuAuth.get("MENU_ID");
				mask = menuAuth.get("MASK");
				auth[mi] = mask;
				old[mi] = mask;

				for (int mj = 0; mj < updateMenulist.size(); mj++) {
					updateMenu = updateMenulist.get(mj);
					String u_menuId = updateMenu.get("MENU_ID");
					if(menuId.equals(u_menuId)) {

						//NN (없음), SN (조회만), SH (조회처리)

						if("AUDIT".equals(searchType)) {
							if(menuId.equals("002")) {//보안준수
								if("ADD".equals(type)) {//add
									auth[mi] = "SN";//읽기
								}else {
									if( "NN".equals(mask_002001) &&	//보안증적관리
										"NN".equals(mask_002003) && //보안준수사항고지
										"NN".equals(mask_002004)) {	//보안자산관리
										auth[mi] = "NN";
									}else {
										auth[mi] = "SN";
									}

								}

							}else if(menuId.equals("002002")) {
								if("ADD".equals(type)) {//add
									auth[mi] = "SN";
								}else {
									auth[mi] = "NN";
								}

							}else {
								auth[mi] = upMask;
							}
						}else if("CHKLIST".equals(searchType)) {
							//메뉴 폴더라 무조건 조회,처리권한
							if(menuId.equals("002")) {
								if("ADD".equals(type)) {//보안준수
									auth[mi] = "SN";
								}else {

									if(
										"NN".equals(mask_002002) && //보안수검/감사
										"NN".equals(mask_002003) && //보안준수사항고지
										"NN".equals(mask_002004)) {	//보안자산관리
										auth[mi] = "NN";
									}else {
										auth[mi] = "SN";
									}
								}
							}else if(menuId.equals("002001")) {//보안증적관리
								if("ADD".equals(type)) {//add
									auth[mi] = "SN";
								}else {

									if("NN".equals(mask_002001003)) {//국내법규개정이력
										auth[mi] = "NN";
									}else {
										auth[mi] = "SN";
									}
								}
							}else {
								auth[mi] = upMask;
							}
						}
						updateMenulist.remove(mj);
						mj--;
					}
				}

			}
			menuSvc.setUserMenuAuth("F", user_id, menu, auth,  old);
			menuLoader.reload();
		}

	}


}
