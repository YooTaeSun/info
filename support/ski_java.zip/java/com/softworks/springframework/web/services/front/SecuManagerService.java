package com.softworks.springframework.web.services.front;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.softworks.springframework.utils.FileUtil;
import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;
import com.softworks.springframework.web.services.MailSendService;

@Service
public class SecuManagerService extends BaseService {

	@Autowired
	private	SecuManagerDetailService secuManagerDetailSvc;

	@Autowired
	private	SecurityAuditService securityAuditSvc;

	@Autowired
	private MailSendService	mailSendService ;

	@Transactional(readOnly=true)
	public int getListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));

		return session.selectOne("com.softworks.springframework.SecuManager.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) {
		return session.selectList("com.softworks.springframework.SecuManager.getList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getAllList(final Param param) {
		return session.selectList("com.softworks.springframework.SecuManager.getAllList", param);
	}

	@Transactional(readOnly=true)
	public Param getDetail(Param param) {
		return session.selectOne("com.softworks.springframework.SecuManager.getList", param);
	}

	@Transactional(readOnly=true)
    public void getListExcel(final Param param, final ModelMap model) throws SQLException {
		String[] category = {
				 "No","권한","이름","사번","직위"
				,"부서/소속명","근무지명","전화번호","Email","등록자"
				,"등록일"};
		String[] columns = {
        		 "RNUM", "PRIVILEGE_CD_NM","MANAGER_NM","EMP_NO","TITLE_NM"
        		,"TEAM_MAIN_NM","SITE_SMALL_CLS_NM","MOBILE_NO","MAIL_ADDR","REG_NM"
        		,"REG_DT"};

        int[] colWidth	= { 5, 10, 10, 10, 15
        				   ,30, 30, 15, 15, 15
        				   ,15};
        model.addAttribute("category", category);
        model.addAttribute("columns", columns);
        model.addAttribute("columnsWidth", colWidth);


        String audit_nm = param.get("audit_nm");
        String excelName = FileUtil.sanitizeFileNm(audit_nm.replace(" ", "_")) + "_업무담당자_"+ Utils.getTimeStampString("yyyyMMdd");

        model.addAttribute("chapter", "1");
        model.addAttribute("filename", excelName);
        model.addAttribute("data", secuManagerDetailSvc.getExcelList(param));
    }

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int insert(final Param param) throws SQLException {
		return session.insert("com.softworks.springframework.SecuManager.insert", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int merge(final Param param) throws SQLException {
		return session.insert("com.softworks.springframework.SecuManager.merge", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void update(final Param param) throws Exception {
		session.update("com.softworks.springframework.SecuManager.update", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void delete(final Param param) throws Exception {
		session.delete("com.softworks.springframework.SecuManager.delete", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int registManager(final Param param) throws Exception {
		int resultInt = 0;

		Param result = securityAuditSvc.getDetail(param);

		String manager_id = Utils.nvl(result.get("MANAGER_ID"),"");

		if("".equals(manager_id)) {
			//----------- sequence manager_id 생성  -----------------
			manager_id = session.selectOne("com.softworks.springframework.SecuManager.getSequence", param);
			param.set("manager_id", manager_id);
			//----------- SecurityAudit update -----------------
			Param updateParam = new Param();
			updateParam.put("uid", (String)param.get("uid"));
			updateParam.put("uname", (String)param.get("uname"));
			updateParam.put("audit_id", (String)param.get("audit_id"));
			updateParam.put("manager_id", (String)param.get("manager_id"));
			resultInt += securityAuditSvc.update(updateParam);

			//----------- SECU_MANAGER merge -----------------
			resultInt += this.merge(param);
		}else {
			//----------- SECU_MANAGER merge -----------------
			param.set("manager_id", manager_id);
			resultInt += this.merge(param);
		}

		//----------- SECU_MANAGER_DETAIL insert -----------------
		param.set("privilege_cd_id", "AUDIT_PRIVILEGE_CD");//CHKLIST_PRIVILEGE_CD 보안통제항목 권한 구분 코드, AUDIT_PRIVILEGE_CD	감사 권한 구분 코드
		param.set("mail_noti_yn", "Y");
		param.set("office_tel_no", "");

		Param selectParam = new Param();
		selectParam.put("manager_id", (String)param.get("manager_id"));
		selectParam.put("company_cd", (String)param.get("company_cd"));
		selectParam.put("emp_no", (String)param.get("emp_no"));

		List<Param> secuManagerDetailList = secuManagerDetailSvc.getAllList(selectParam);

		if(secuManagerDetailList != null && secuManagerDetailList.size() > 0) {
			throw new RuntimeException("이미 추가 되었습니다.");
		}
		resultInt += secuManagerDetailSvc.insert(param);


		//업무 담당자 추가시 권한 추가
		String emp_no = param.get("emp_no");
		String audit_nm = result.get("AUDIT_NM");
		String privilegeCd = Utils.nvl(param.get("privilege_cd"),"");

		if(privilegeCd.equals("R") || privilegeCd.equals("P")) {//R 조회, P 업무
			secuManagerDetailSvc.addAuthMenu(emp_no, "AUDIT", "SH");//보안수검/감사(AUDIT), 증정(CHKLIST), privilegeCd C:조회, U:업무

			//메일서비스  EM04		실시간	-	보안 담당자	[알림] 수검/감사 담당자 지정	{AUDIT_NM}	"{AUDIT_NM} 수검/감사 담당자로 지정 되었습니다.
			Param contentReplaceParam = new Param();
			contentReplaceParam.set("#AUDIT_NM#", audit_nm);
			contentReplaceParam.set("#JOB_NM#", param.get("privilege_cd_nm"));
//			mailSendService.sendMail2("EM04", emp_no, contentReplaceParam);

			String noti_id = "C04";
			String schd_id = "C04";
			mailSendService.setNotiHist(noti_id, emp_no, "Y", schd_id, contentReplaceParam);
		}
		return resultInt;
	}

}
