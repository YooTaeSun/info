package com.softworks.springframework.web.services.front;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class MyService extends BaseService {

	@Transactional(readOnly=true)
	public Param getInfo(final String id) {
		return (Param)session.selectOne("com.softworks.springframework.User.getInfo", id);
	}


	@Transactional(readOnly=true)
	public List<Param> getCustomerDepartment(final Param param) {
		return session.selectList("com.softworks.springframework.My.getCustomerDepartment", param);
	}

	@Transactional(readOnly=true)
	public boolean isDuplicateId(final String id) throws Exception {
		return null != session.selectOne("com.softworks.springframework.My.isDuplicateId", id);
	}

	@Transactional(readOnly=true)
	public boolean findInfoUser(final Param param) throws Exception {
		return null != session.selectOne("com.softworks.springframework.My.findInfoUser", param);
	}
	
	public void toUseRequest(final Param param) throws Exception {
		session.insert("com.softworks.springframework.My.toUseRequest", param);
	}
	
	public void changePassword(final String id, final String password) throws Exception {
		Param	param	= new Param();
				param.set("user_id", id);
				param.set("passwd", password);
		
		session.update("com.softworks.springframework.My.changePassword", param);
	}

	// ljd
//	public boolean isCertificationKey(final Param param) throws Exception {
//		return 0 < session.update("com.softworks.springframework.My.isCertificationKey", param);
//	}
	// ljd	
//	public void setCertificationKey(final Param param) throws Exception {
//		session.update("com.softworks.springframework.My.setCertificationKey", param);
//	}
	
	public void updateInfo(final Param param) throws Exception {
		session.update("com.softworks.springframework.My.updateInfo", param);
	}

}
