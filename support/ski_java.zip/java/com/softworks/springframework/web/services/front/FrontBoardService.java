package com.softworks.springframework.web.services.front;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class FrontBoardService extends BaseService{

	@Transactional(readOnly=true)
	public int getListCount(final Param param) throws SQLException {

		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*DEFAULT_PAGE_SIZE));

		return (Integer)session.selectOne("com.softworks.springframework.CommBoard.getFrontBoadListCount", param);
	}


	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) throws SQLException {

		return session.selectList("com.softworks.springframework.CommBoard.getFrontBoadList", param);
	}

	@Transactional(readOnly=true)
    public void getListExcel(final Param param, final ModelMap model) throws SQLException {

		model.addAttribute("category", new String[] { "제목", "등록자", "등록일"
                 });

        model.addAttribute("columns", new String[] { "title", "writerNm", "rdate"
                });

        model.addAttribute("chapter", param.getString("boardType")+"자료실");
        model.addAttribute("filename", param.getString("boardType")+"자료실");

        model.addAttribute("data", session.selectList("com.softworks.springframework.CommBoard.getFrontBoadListExcel", param));


    }

	@Transactional(readOnly=true)
	public Param getBoardInfo(final int boardSeq) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.CommBoard.getBoardInfo", boardSeq);
	}

	@Transactional(readOnly=true)
	public List<Param> getBoarFileList(final int boardSeq) throws SQLException {
		return session.selectList("com.softworks.springframework.CommBoard.getBoardFileList", boardSeq);
	}

	@Transactional(readOnly=true)
	public Param getBoardFileInfo(final int seq) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.CommBoard.getBoardFileInfo", seq);
	}

	@Transactional(readOnly=true)
	public int getBoardSeq() throws SQLException {
		return (int)session.selectOne("com.softworks.springframework.CommBoard.getBoardSeq");
	}

	public void insertBoard(final Param param) throws SQLException {
		session.insert("com.softworks.springframework.CommBoard.insertBoard", param);
	}

	public void insertBoardFile(final Param param) throws SQLException {
		session.insert("com.softworks.springframework.CommBoard.insertBoardFile", param);
	}

	public void updateBoard(final Param param) throws SQLException {
		session.update("com.softworks.springframework.CommBoard.updateBoard", param);
	}

	public void deleteBoardFile(final Param param) throws SQLException {
		session.delete("com.softworks.springframework.CommBoard.deleteBoardFile", param);
	}

	public void deleteBoard(final Param param) throws Exception {
		if(!param.isNull("seqList")) param.set("seqList", param.getValues("seqList"));

		session.update("com.softworks.springframework.CommBoard.deleteBoard", param);
		session.delete("com.softworks.springframework.CommBoard.deleteBoardFiles", param);
	}

}
