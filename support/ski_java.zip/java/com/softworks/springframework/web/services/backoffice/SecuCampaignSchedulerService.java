package com.softworks.springframework.web.services.backoffice;

import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;
import com.softworks.springframework.web.services.MailSendService;

@Service
public class SecuCampaignSchedulerService extends BaseService {

	private	final	Logger		logger	= Logger.getLogger(getClass());

	@Autowired
	SchedulerLogService logSvc;

    public void setSession(SqlSessionTemplate session) {
		super.session = session;
		logSvc = new SchedulerLogService();
		logSvc.setSession(session);
	}

    /**
	 * 캠페인 대상 등록
	 * target table : SECURITY_CAMPAIGN, SECURITY_CAMPAIGN_SCHEDULE
	 * Result : void
     * @throws Exception 
	 */
    public void regCampaignTarget(final Param schdInfo) throws Exception {
    	int batch_cnt = 0;
		String	err_chk			= "";
		String	rst_msg			= "";
		Param targetCampaign = null;
		
		// start log
		schdInfo.set("BATCH_SEQ", logSvc.newAppendBatchHistory(schdInfo));
		
		try {
			Param param = new Param();
			
			// 캠페인 대상 스캐줄 가져오기
			param.set("schd_typ_cd", "TARGET");
			targetCampaign = getSecuCampaignSchedule(param);
			
			if(targetCampaign != null){
				/* 기존 캠페인 대상자 삭제 */
				deleteTarget(targetCampaign.get("CAMPAIGN_ID"));
				Param tParam = new Param();
				tParam.set("campaign_id", targetCampaign.get("CAMPAIGN_ID"));
				tParam.set("schd_id", schdInfo.get("SCHD_ID"));
				tParam.set("schd_nm", schdInfo.get("SCHD_NM"));
				/* 캠페인 대상자 등록 */
				if(insertTarget(tParam)){
					batch_cnt++;
				}
			}
		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		}
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		if (!err_chk.equals("")) {
			schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "N");
			schdInfo.set("BATCH_MSG", err_chk);
			logSvc.updateBatchHistory(schdInfo);
			
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
	    	if(batch_cnt > 0){
	    		rst_msg = (targetCampaign != null ? targetCampaign.get("CAMPAIGN_NM") : "" ) + " 캠페인 대상 등록 처리 되었습니다.";
	    	}else{
	    		rst_msg = "캠페인 등록 대상이 없습니다.";
	    	}
	    	schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "Y");
			schdInfo.set("BATCH_MSG", rst_msg);
			logSvc.updateBatchHistory(schdInfo);
			
	    	logger.info("User append Daily Batch totCnt="+batch_cnt);
	    }
	}
    
    /**
	 * 캠페인 대상 이메일 발송
	 * target table : T_USER, T_CONTENT , T_MAIL_SEND_HIST, SECURITY_CAMPAIGN, SECURITY_CAMPAIGN_SCHEDULE
	 * Result : void
     * @throws Exception 
	 */
    public void sendMailCampaignTarget(final Param schdInfo) throws Exception {
    	int batch_cnt = 0;
    	int total_cnt = 0;
		String	err_chk	= "";
		String	rst_msg = "";
		Param targetCampaign = null;
		Param mailRtnParam = null;
		boolean boolTargetReg = false;
		
		// start log
		schdInfo.set("BATCH_SEQ", logSvc.newAppendBatchHistory(schdInfo));
		
		MailSendService mm = new MailSendService();
		mm.setSession(session);

		try {
			// 캠페인 대상 등록
			boolTargetReg = regCampaignTarget2(schdInfo);
			if(boolTargetReg){
				Param param = new Param();
				// 캠페인 메일 스케줄 가져오기
				param.set("schd_typ_cd", "MAIL");
				targetCampaign = getSecuCampaignSchedule(param);
				Param contentReplaceParam;
				
				if(targetCampaign != null){
					/* 이메일 알림 대상자 추출 */
					List<Param> list = getSecuCampaignTarget(targetCampaign.get("CAMPAIGN_ID"));
					total_cnt = list.size();
					for (Param target : list) {
						//메일 발송 
						contentReplaceParam = new Param();
						//mailRtnParam = mm.sendMail2("EM10",target.get("EMP_NO"), contentReplaceParam);
						
						String noti_id = schdInfo.get("NOTI_ID");
						String schd_id = schdInfo.get("SCHD_ID");
						mailRtnParam = mm.setNotiHist(noti_id, target.get("EMP_NO"), "Y", schd_id, contentReplaceParam);
						
						System.out.println("RESULT_MSG ============> "+mailRtnParam.get("RESULT_MSG"));
						if(Boolean.parseBoolean(mailRtnParam.get("RESULT"))){
							batch_cnt++;
						}
					}
				}
			}
		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		}
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		if (!err_chk.equals("")) {
			schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "N");
			schdInfo.set("BATCH_MSG", err_chk);
			logSvc.updateBatchHistory(schdInfo);
			
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
	    	rst_msg = (targetCampaign != null ? targetCampaign.get("CAMPAIGN_NM") : "" ) + " 캠페인 대상자 총 "+total_cnt + "명 중 " + batch_cnt + "명에게 메일이 발송되었습니다.";
	    	schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "Y");
			schdInfo.set("BATCH_MSG", rst_msg);
			logSvc.updateBatchHistory(schdInfo);
	    	logger.info("User append Daily Batch totCnt="+batch_cnt);
	    }
	}
    
    /**
	 * 캠페인 대상 등록
	 * target table : SECURITY_CAMPAIGN, SECURITY_CAMPAIGN_SCHEDULE
	 * Result : void
     * @throws Exception 
	 */
    public boolean regCampaignTarget2(final Param schdInfo) throws Exception {
		Param targetCampaign = null;
		boolean result = false;
		
		try {
			Param param = new Param();
			
			// 캠페인 대상 스캐줄 가져오기
			param.set("schd_typ_cd", "TARGET");
			targetCampaign = getSecuCampaignSchedule(param);
			
			if(targetCampaign != null){
				/* 기존 캠페인 대상자 삭제 */
				deleteTarget(targetCampaign.get("CAMPAIGN_ID"));
				Param tParam = new Param();
				tParam.set("campaign_id", targetCampaign.get("CAMPAIGN_ID"));
				tParam.set("schd_id", schdInfo.get("SCHD_ID"));
				tParam.set("schd_nm", schdInfo.get("SCHD_NM"));
				/* 캠페인 대상자 등록 */
				result = insertTarget(tParam);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
    
	@Transactional(readOnly=true)
	public Param getSecuCampaignSchedule(Param param) throws SQLException {
		return session.selectOne("com.softworks.springframework.SecuCampaignScheduler.getSecuCampaignSchedule",param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getSecuCampaignTarget(final String campaign_id) throws SQLException {
		return session.selectList("com.softworks.springframework.SecuCampaignScheduler.getSecuCampaignTarget", campaign_id);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public boolean insertTarget(final Param param) throws SQLException {
		return 0 < session.insert("com.softworks.springframework.SecuCampaignScheduler.insertTarget", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public boolean deleteTarget(final String campaign_id) throws SQLException {
		return 0 < session.update("com.softworks.springframework.SecuCampaignScheduler.deleteTarget", campaign_id);
	}
	
	@Transactional(readOnly=true)
	public Param getNotiContentsInfo(final String noti_id) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.Main.getNotiContentsInfo", noti_id);
	}
}
