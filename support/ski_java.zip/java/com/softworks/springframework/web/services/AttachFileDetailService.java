package com.softworks.springframework.web.services;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;
import com.softworks.springframework.web.services.backoffice.MetaCompanyService;

@Service
public class AttachFileDetailService extends BaseService {

	@Autowired
	private	AttachFileService attachFileSvc;

	@Autowired
	private	MetaCompanyService metaCompanySvc;

	@Transactional(readOnly=true)
	public int getListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));

		return session.selectOne("com.softworks.springframework.AttachFileDetail.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) {
		return session.selectList("com.softworks.springframework.AttachFileDetail.getList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getAllList(final Param param) {
		return session.selectList("com.softworks.springframework.AttachFileDetail.getAllList", param);
	}

	@Transactional(readOnly=true)
	public Param getDetail(Param param) {
		return session.selectOne("com.softworks.springframework.AttachFileDetail.getAllList", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int insert(final Param param) throws SQLException {
		return session.insert("com.softworks.springframework.AttachFileDetail.insert", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void update(final Param param) throws Exception {
		session.update("com.softworks.springframework.AttachFileDetail.update", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void delete(final Param param) throws Exception {
		session.delete("com.softworks.springframework.AttachFileDetail.delete", param);
	}


	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public Param getDetailHist(Param param) throws Exception {

		param.put("type", "SECU_YN");//M_CHECKLIST SECU_YN 인 경우 zip파일 다운로드
		param.put("storageType", "DB");//파일 DB에 저장시

		Param fileInfo = this.getDetail(param);
		if(Utils.nvl(fileInfo.get("SECU_YN")).equals("Y")) {
			param.put("fileInfo", fileInfo);
			attachFileSvc.batchDownload(param);
		}
		return fileInfo;
	}

	@Transactional(readOnly=true)
	public List<Param> fileSiteList(final Param param) {

		List<Param> fileList =  this.getAllList(param);
		String busiSiteListStr = "";

		for (int i = 0; i < fileList.size(); i++) {
			Param file = fileList.get(i);
			busiSiteListStr = Utils.nvl(file.get("BUSI_SITE_LIST"),"") ;
			if(!busiSiteListStr.isEmpty()) {
				if(!"0".equals(busiSiteListStr)) {// 0이면 전사공통
					List<String> p_busiSiteList = Arrays.asList(busiSiteListStr.split(","));
					param.put("busiSiteList", p_busiSiteList);
				}
				List<Param> busiSiteList =  metaCompanySvc.getCompanyBusiSiteAllList(param);
				file.put("busiSiteList", busiSiteList);
			}
		}
		return this.getAllList(param);
	}

}
