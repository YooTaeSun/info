package com.softworks.springframework.web.services.backoffice;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;
import com.softworks.springframework.web.services.AttachFileService;

@Service
public class SecurityRewardHistService extends BaseService {

	@Autowired
	private	AttachFileService attachFileSvc;

	@Transactional(readOnly=true)
	public int getListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));

		return session.selectOne("com.softworks.springframework.SecurityRewardHist.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) {
		return session.selectList("com.softworks.springframework.SecurityRewardHist.getList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getAllList(final Param param) {
		return session.selectList("com.softworks.springframework.SecurityRewardHist.getAllList", param);
	}

	@Transactional(readOnly=true)
	public Param getDetail(final Param param) {
		return session.selectOne("com.softworks.springframework.SecurityRewardHist.getAllList", param);
	}


	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int insert(final Param param) throws SQLException {
		return session.insert("com.softworks.springframework.SecurityRewardHist.insert", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void update(final Param param) throws Exception {
		session.update("com.softworks.springframework.SecurityRewardHist.update", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void delete(final Param param) throws Exception {
		session.delete("com.softworks.springframework.SecurityRewardHist.delete", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void historyUpdate(final Param param) throws Exception {

		param.put("reward_id", Utils.nvl(param.get("reward_id"), this.getRewardId(param.get("reward_emp_no"))));
		this.update(param);
	}

	@Transactional(readOnly=true)
	public String getRewardId(String empNo) {

		String reward_id = "";
		Param param = new Param();
		param.put("reward_emp_no", empNo);
		List<Param> list = this.getAllList(param);
		if(list != null && list.size()> 0) {
			reward_id = list.get(0).get("REWARD_ID");
		}else {
			reward_id = session.selectOne("com.softworks.springframework.SecurityRewardHist.getRewardId");
		}
		return reward_id;
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int regist(final Param param) throws SQLException {
		param.put("reward_id", Utils.nvl(param.get("reward_id"), this.getRewardId(param.get("reward_emp_no"))));
		param.put("atch_file_id",attachFileSvc.getAtchFileId());
		return this.insert(param);
	}


	@Transactional(readOnly=true)
	public List<Param> getRewardIdList(final Param param) {
		return session.selectList("com.softworks.springframework.SecurityRewardHist.getRewardIdList", param);
	}


	@Transactional(readOnly=true)
	public int getOrgListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));

		return session.selectOne("com.softworks.springframework.SecurityRewardHist.getOrgListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getOrgList(final Param param) {
		return session.selectList("com.softworks.springframework.SecurityRewardHist.getOrgList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getAllOrgList(final Param param) {
		return session.selectList("com.softworks.springframework.SecurityRewardHist.getAllOrgList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getExcelList(final Param param) {
		return session.selectList("com.softworks.springframework.SecurityRewardHist.getExcelList", param);
	}

	@Transactional(readOnly=true)
    public void getListExcel(final Param param, final ModelMap model) throws SQLException {
		model.addAttribute("category", new String[] {
				 "No","회사명","부서명","상점","벌점"
				,"상벌점(상점-벌점)","발생일자","상벌 구분","상벌 유형","세부 유형"
				,"평가기준","상벌점","이름","등록자","등록일자"
				});
        model.addAttribute("columns", new String[] {
        		 "RNUM", "COMPANY_NM","DEPT_NM","GOOD_EVAL_SCORE","BAD_EVAL_SCORE"
        		,"SUM_EVAL_SCORE","OCCU_DAY","REWARD_CD_NM","EVAL_ITEM_NM","EVAL_TYP_NM"
        		,"RISK_TYP_CD_NM","EVAL_SCORE","REWARD_EMP_NM","REG_NM","REG_DT"
        		});


        int[] colWidth	= { 5, 20, 20, 5, 5
		   		   ,15, 15, 15, 20, 15
		   		   ,15, 15, 15, 15, 15
		   		   };

        String excelName = "조직별보안사고현황_" + param.get("aply_start_day") + "_" + param.get("aply_end_day") + "_" + Utils.getTimeStampString("yyyyMMdd");

        model.addAttribute("chapter", "1");
        model.addAttribute("filename", excelName);
        model.addAttribute("columnsWidth", colWidth);
        model.addAttribute("data", this.getExcelList(param));
    }

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void historyDelete(final Param param) throws Exception {

		String uid = param.get("uid");
		String uname = param.get("uname");

		Param detail =  this.getDetail(param);

		String atch_file_id = Utils.nvl(detail.get("ATCH_FILE_ID"));
		if(!atch_file_id.isEmpty()) {

			Param fileParam = new Param();
			fileParam.put("use_yn", "N");
			fileParam.put("uid", uid);
			fileParam.put("uname",uname);

			fileParam.put("atch_file_id", atch_file_id);
			attachFileSvc.update(fileParam);
		}
		this.delete(param);
	}
}
