package com.softworks.springframework.web.services.backoffice;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;

@Service
public class SecurityAssetsService extends BaseService {
	
	@Transactional(readOnly=true)
	public Param getSecurityAssetsOne(Param param) {
		return session.selectOne("com.softworks.springframework.securityAssets.getSecurityAssetsOne", param);
	}
	
	@Transactional(readOnly=true)
	public Param getVItsAssetNetworkOne(Param param) {
		return session.selectOne("com.softworks.springframework.securityAssets.getVItsAssetNetworkOne", param);
	}
	
	@Transactional(readOnly=true)
	public Param getVItsAssetInfraOne(Param param) {
		return session.selectOne("com.softworks.springframework.securityAssets.getVItsAssetInfraOne", param);
	}
	
	@Transactional(readOnly=true)
	public Param getVItsAssetServerOne(Param param) {
		return session.selectOne("com.softworks.springframework.securityAssets.getVItsAssetServerOne", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getSecurityAssetsAttrListList(Param param) {
		return session.selectList("com.softworks.springframework.securityAssets.getSecurityAssetsAttrListList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getSecurityAssetsAttrListListExcel(Param param) {
		return session.selectList("com.softworks.springframework.securityAssets.getSecurityAssetsAttrListListExcel", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getAssetRelatedLawsList(Param param) {
		return session.selectList("com.softworks.springframework.securityAssets.getAssetRelatedLawsList", param);
	}
	
	@Transactional(readOnly=true)
	public int getSecurityAssetsApplListCount(Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*10));

		return session.selectOne("com.softworks.springframework.securityAssets.getSecurityAssetsApplListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getSecurityAssetsApplList(Param param) {
		return session.selectList("com.softworks.springframework.securityAssets.getSecurityAssetsApplList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getIfItsMstApplList(Param param) {
		return session.selectList("com.softworks.springframework.securityAssets.getIfItsMstApplList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getVItsApplCompany(Param param) {
		return session.selectList("com.softworks.springframework.securityAssets.getVItsApplCompany", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getVItsApplTech(Param param) {
		return session.selectList("com.softworks.springframework.securityAssets.getVItsApplTech", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getIfItsMstApplDetailList(Param param) {
		return session.selectList("com.softworks.springframework.securityAssets.getIfItsMstApplDetailList", param);
	}
	
	@Transactional(readOnly=true)
	public int getIfItsMstApplDetailCount(Param param) {
		return session.selectOne("com.softworks.springframework.securityAssets.getIfItsMstApplDetailCount", param);
	}
	
	@Transactional(readOnly=true)
	public Param getVItsApplSecurityOne(Param param) {
		return session.selectOne("com.softworks.springframework.securityAssets.getVItsApplSecurityOne", param);
	}

	@Transactional(readOnly=true)
	public int getSecurityAssetsNetworkListCount(Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*10));

		return session.selectOne("com.softworks.springframework.securityAssets.getSecurityAssetsNetworkListCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getSecurityAssetsNetworkList(Param param) {
		return session.selectList("com.softworks.springframework.securityAssets.getSecurityAssetsNetworkList", param);
	}
	
	@Transactional(readOnly=true)
	public int getSecurityAssetsInfraListCount(Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*10));

		return session.selectOne("com.softworks.springframework.securityAssets.getSecurityAssetsInfraListCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getSecurityAssetsInfraList(Param param) {
		return session.selectList("com.softworks.springframework.securityAssets.getSecurityAssetsInfraList", param);
	}
	
	@Transactional(readOnly=true)
	public int getSecurityAssetsServerListCount(Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*10));

		return session.selectOne("com.softworks.springframework.securityAssets.getSecurityAssetsServerListCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getSecurityAssetsServerList(Param param) {
		return session.selectList("com.softworks.springframework.securityAssets.getSecurityAssetsServerList", param);
	}

	public void insertSecurityAssets(final Param param) throws Exception {
		session.insert("com.softworks.springframework.securityAssets.insertSecurityAssets", param);
	}
	
	public void insertSecurityAssetsAttrList(final Param param) throws Exception {
		session.insert("com.softworks.springframework.securityAssets.insertSecurityAssetsAttrList", param);
	}
	
	public void deleteSecurityAssetsAttrList(final Param param) throws Exception {
		session.delete("com.softworks.springframework.securityAssets.deleteSecurityAssetsAttrList", param);
	}
	
	public void insertAssetRelatedLaws(final Param param) throws Exception {
		session.insert("com.softworks.springframework.securityAssets.insertAssetRelatedLaws", param);
	}
	
	public void deleteAssetRelatedLaws(final Param param) throws Exception {
		session.delete("com.softworks.springframework.securityAssets.deleteAssetRelatedLaws", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateSecurityAssets(final Param param) throws Exception {
		session.update("com.softworks.springframework.securityAssets.updateSecurityAssets", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateSecurityAssetsBusiSiteList(final Param param) throws Exception {
		session.update("com.softworks.springframework.securityAssets.updateSecurityAssetsBusiSiteList", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertSecurityAssetsService1(final Param param) throws Exception {
		
		List<HashMap<String, String>> attrList = param.getList("attrList");
		List<HashMap<String, String>> confList = param.getList("confList");
		List<HashMap<String, String>> lawsList = param.getList("lawsList");

		if("".equals(param.get("asset_seq"))){
			insertSecurityAssets(param);
		}else{
			deleteSecurityAssetsAttrList(param);
			
			param.set("asset_id", param.get("app_no"));
			param.set("asset_class_cd", param.get("asset_typ_class_cd"));
			deleteAssetRelatedLaws(param);
			
			updateSecurityAssets(param);
		}
		
		if("APPL".equals(param.get("asset_typ_cd"))){
			for(HashMap map : attrList){
				Param setMap = new Param();
				setMap.set("asset_seq", param.get("asset_seq"));
				setMap.set("attr_typ_cd_grp_id", map.get("attr_typ_cd_grp_id"));
				setMap.set("attr_typ_cd_id", map.get("attr_typ_cd_id"));
				setMap.set("attr_typ_cd", map.get("attr_typ_cd"));
				setMap.set("reg_id", param.get("reg_id"));
				setMap.set("reg_nm", param.get("reg_nm"));
				if(!"".equals(map.get("attr_typ_cd"))){
					insertSecurityAssetsAttrList(setMap);
				}
			}
		}
		
		for(HashMap map : confList){
			Param setMap = new Param();
			setMap.set("asset_seq", param.get("asset_seq"));
			setMap.set("attr_typ_cd_grp_id", map.get("attr_typ_cd_grp_id"));
			setMap.set("attr_typ_cd_id", map.get("attr_typ_cd_id"));
			setMap.set("attr_typ_cd", map.get("attr_typ_cd"));
			setMap.set("reg_id", param.get("reg_id"));
			setMap.set("reg_nm", param.get("reg_nm"));
			if(!"".equals(map.get("attr_typ_cd"))){
				insertSecurityAssetsAttrList(setMap);
			}
		}
		
		for(HashMap map : lawsList){
			Param setMap = new Param();
			setMap.set("ls_id", map.get("ls_id"));
			setMap.set("asset_id", map.get("asset_id"));
			setMap.set("asset_class_cd", map.get("asset_class_cd"));
			setMap.set("reg_id", param.get("reg_id"));
			setMap.set("reg_nm", param.get("reg_nm"));
			if(!"".equals(map.get("asset_class_cd"))){
				insertAssetRelatedLaws(setMap);
			}
		}
		
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertSecurityAssetsService2(final Param param) throws Exception {
		
		List<HashMap<String, String>> lawsList = param.getList("lawsList");

		if("".equals(param.get("asset_seq"))){
			insertSecurityAssets(param);
		}else{
			
			param.set("asset_id", param.get("conf_id"));
			param.set("asset_class_cd", param.get("asset_typ_class_cd"));
			deleteAssetRelatedLaws(param);
			
			updateSecurityAssets(param);
		}
		
		for(HashMap map : lawsList){
			Param setMap = new Param();
			setMap.set("ls_id", map.get("ls_id"));
			setMap.set("asset_id", map.get("asset_id"));
			setMap.set("asset_class_cd", map.get("asset_class_cd"));
			setMap.set("reg_id", param.get("reg_id"));
			setMap.set("reg_nm", param.get("reg_nm"));
			if(!"".equals(map.get("asset_class_cd"))){
				insertAssetRelatedLaws(setMap);
			}
		}
		
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertSecurityAssetsService3(final Param param) throws Exception {
		
		if("".equals(param.get("asset_seq"))){
			insertSecurityAssets(param);
		}else{
			updateSecurityAssets(param);
		}
		
	}
	
	@Transactional(readOnly=true)
    public void getSecurityAssetsApplListExcel(final Param param, final ModelMap model) throws SQLException {
		
		List<Param> resultList = session.selectList("com.softworks.springframework.securityAssets.getSecurityAssetsApplListExcel", param);

		for(Param temp : resultList){
			String asset_seq = temp.get("ASSET_SEQ");
			String app_no = temp.get("APP_NO");
			Param	paramOne	= new Param();
			paramOne.set("app_no", app_no);
			List<Param> ifItsMstApplList = getIfItsMstApplList(paramOne);
			for(int i=0; i < ifItsMstApplList.size(); i++){
				Param appl = ifItsMstApplList.get(i);
				String name = appl.get("NAME");
				String column_value = appl.get("COLUMN_VALUE");
				temp.set("name"+i, name);
				temp.set("value"+i, column_value);
			}
			
			String cvalue = "";
			List<Param> vItsApplCompany = getVItsApplCompany(paramOne);
			for(int i=0; i < vItsApplCompany.size(); i++){
				Param appl = vItsApplCompany.get(i);
				cvalue = cvalue + appl.get("SKCOMPANYNAME")+"/"+appl.get("TEAMNAMEMAIN");
				if(i != vItsApplCompany.size()-1){
					cvalue = cvalue + ",";
				}
			}
			temp.set("cvalue", cvalue);
			
			Param confParam = new Param();
			confParam.set("asset_seq", asset_seq);
			confParam.set("pcode", "LEGAL_CONF_CD_GRP");
			List<Param> resultAttrList_a = getSecurityAssetsAttrListListExcel(confParam);
			for(int i=0; i < resultAttrList_a.size(); i++){
				Param attr = resultAttrList_a.get(i);
				String attr_typ_cd_nm = attr.get("ATTR_TYP_CD_NM");
				temp.set("avalue"+i, attr_typ_cd_nm);
			}
			
			confParam.set("pcode", "ASSET_ATTR_CD_GRP");
			List<Param> resultAttrList_b = getSecurityAssetsAttrListListExcel(confParam);
			for(int i=0; i < resultAttrList_b.size(); i++){
				Param attr = resultAttrList_b.get(i);
				String attr_typ_cd_nm = attr.get("ATTR_TYP_CD_NM");
				temp.set("bvalue"+i, attr_typ_cd_nm);
			}
			
			String lawValue = "";
			Param	lawParam	= new Param();
			lawParam.set("asset_id", app_no);
			lawParam.set("asset_class_cd", "APPL");
			List<Param> resultLawList = getAssetRelatedLawsList(lawParam);
			for(int i=0; i < resultLawList.size(); i++){
				Param law = resultLawList.get(i);
				String ls_abbr_nm = law.get("LS_ABBR_NM");
				lawValue = lawValue + ls_abbr_nm;
				if(i != resultLawList.size()-1){
					lawValue = lawValue + ",";
				}
			}
			temp.set("ls_abbr_nm", lawValue);
		}
		
		int[]	 colWidth	= {20, 20, 20, 20
				             , 20, 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20, 20
				             , 20
				             };

		model.addAttribute("category", new String[] { "App.번호", "정보시스템명", "대분류" , "오픈일자" 
													, "평가상태", "관리대상", "등록일자"
													, "약어", "정보시스템명"
													, "App.분류(대)", "App.분류(중)"
													, "App.분류(소)", "오픈일자"
													, "폐기일자", "현업담당자"
													, "BA", "운영자"
													, "ERP담당자", "SLA대상여부"
													, "Portfolio 서비스중요도", "가용시간"
													, "공용/전사/전용", "AM운영형태"
													, "개발형태", "외부망접속가능"
													, "URL", "SSL"
													, "SSO등록여부", "ID신청가능여부"
													, "사용회사/주관부서"
													, "개인정보자산가치등급코드", "개인정보관리항목코드"
													, "산업정보자산가치등급코드", "산업정보기밀여부코드"
													, "영업정보자산가치등급코드", "영업정보기밀여부코드"
													, "개인정보영향평가대상구분코드"
													, "준거성평가코드", "정보등급코드"
													, "정보가치코드", "정보연관성코드"
													, "서비스가용성코드", "보안등급(중요도)코드"
													, "관리대상 여부", "SW 구분", "비고"
													, "관련법/제도"
                 });
        
        model.addAttribute("columns", new String[] { "APP_NO", "APP_KOR_NM", "APP_LARGE_NM","OPEN_DAY"
        										   , "ASSET_SEQ_YN", "MANAGED_YN", "REG_DT"
        										   , "value0", "value1"
        										   , "value2", "value3"
        										   , "value4", "value5"
        										   , "value6", "value7"
        										   , "value8", "value9"
        										   , "value10", "value11"
        										   , "value12", "value13"
        										   , "value14", "value15"
        										   , "value16", "value17"
        										   , "value18", "value19"
        										   , "value20", "value21"
        										   , "cvalue"
        										   , "bvalue0","bvalue1"
        										   , "bvalue2","bvalue3"
        										   , "bvalue4","bvalue5"
        										   , "bvalue6"
        										   , "avalue0","avalue1"
        										   , "avalue2","avalue3"
        										   , "avalue4","avalue5"
        										   , "MANAGED_YN", "SW_TYP_CD", "NOTE"
        										   , "ls_abbr_nm"
                });
        model.addAttribute("columnsWidth", colWidth);
        model.addAttribute("chapter", "정보시스템자산");
        model.addAttribute("filename", "정보시스템자산"+"_"+Utils.getTimeStampString("yyyyMMdd"));
           
        model.addAttribute("data", resultList);
        
    }
	
	@Transactional(readOnly=true)
    public void getSecurityAssetsNetworkListExcel(final Param param, final ModelMap model) throws SQLException {

		List<Param> resultList = session.selectList("com.softworks.springframework.securityAssets.getSecurityAssetsNetworkListExcel", param);

		for(Param temp : resultList){
			String asset_seq = temp.get("ASSET_SEQ");
			String conf_id = temp.get("CONF_ID");
			Param	paramOne	= new Param();
			paramOne.set("conf_id", conf_id);
			Param vItsAssetNetworkOne = getVItsAssetNetworkOne(paramOne);
			temp.putAll(vItsAssetNetworkOne);
			
			String lawValue = "";
			Param	lawParam	= new Param();
			lawParam.set("asset_id", conf_id);
			lawParam.set("asset_class_cd", "NW");
			List<Param> resultLawList = getAssetRelatedLawsList(lawParam);
			for(int i=0; i < resultLawList.size(); i++){
				Param law = resultLawList.get(i);
				String ls_abbr_nm = law.get("LS_ABBR_NM");
				lawValue = lawValue + ls_abbr_nm;
				if(i != resultLawList.size()-1){
					lawValue = lawValue + ",";
				}
			}
			temp.set("ls_abbr_nm", lawValue);
		}
		
		int[]	 colWidth	= { 20, 20, 20
							  , 20, 20
							  , 20, 20, 20
							  , 20, 20, 20, 20
							  , 20, 20, 20
							  , 20, 20, 20
							  , 20, 20
							  , 20, 20, 20
							  , 20, 20, 20
							  , 20, 20
							  , 20
							 };
		
		model.addAttribute("category", new String[] {  "구성ID", "자산관리번호", "자산분류(소)" 
													 , "도입년도", "자산상태"
													 , "평가상태", "관리대상", "등록일자"
													 , "자산분류(대)", "자산분류(중)", "자산분류(소)", "고객사"
													 , "자산상태", "도입년도", "모델명"
													 , "구성ID", "APP.번호", "자산관리번호"
													 , "설치장소", "장비용도"
													 , "운영부서", "운영자1", "운영자2"
													 , "사용부서", "사용자1", "사용자2"
													 , "관리대상 여부", "비고"
													 , "관련법/제도"
                 });
        
        model.addAttribute("columns", new String[] {  "CONF_ID", "ASSET_MGMT_NO", "ASSET_BOT_NM"
        											, "INTRO_YEAR", "ASSET_STAT"
        											, "ASSET_SEQ_YN", "MANAGED_YN", "REG_DT"
        											, "ASSET_TOP_NM", "ASSET_MID_NM", "ASSET_BOT_NM", "CUST_COMPANY_NM"
         										    , "ASSET_STAT", "INTRO_YEAR", "MODEL_NM"
         										    , "CONF_ID", "", "ASSET_MGMT_NO"
         										    , "LOCA_NM", "EQUIP_USE"
         										    , "OPR_DEPT_NM", "OPR_1_EMP_NM", "OPR_2_EMP_NM"
         										    , "USE_DEPT_NM", "USE_1_EMP_NM", "USE_2_EMP_NM"
         										    , "MANAGED_YN", "NOTE"
         										    , "ls_abbr_nm"
                });
    
        model.addAttribute("columnsWidth", colWidth);
        model.addAttribute("chapter", "네트워크자산");
        model.addAttribute("filename", "네트워크자산"+"_"+Utils.getTimeStampString("yyyyMMdd"));
           
        model.addAttribute("data", resultList);
        
    }
	
	@Transactional(readOnly=true)
    public void getSecurityAssetsServerListExcel(final Param param, final ModelMap model) throws SQLException {

		List<Param> resultList = session.selectList("com.softworks.springframework.securityAssets.getSecurityAssetsServerListExcel", param);

		for(Param temp : resultList){
			String asset_seq = temp.get("ASSET_SEQ");
			String conf_id = temp.get("CONF_ID");
			Param	paramOne	= new Param();
			paramOne.set("conf_id", conf_id);
			Param vItsAssetServerOne = getVItsAssetServerOne(paramOne);
			temp.putAll(vItsAssetServerOne);
			
		}
		
		int[]	 colWidth	= { 20, 20, 20
							  , 20, 20, 20
							  , 20, 20, 20
							  , 20, 20, 20, 20
							  , 20, 20, 20
							  , 20, 20
							  , 20, 20, 20
							  , 20, 20, 20
							  , 20, 20, 20, 20
							  , 20
							  , 20, 20
							};
		
		model.addAttribute("category", new String[] { "구성ID", "자산관리번호", "APP.번호" 
													, "정보시스템명", "회사명"
													, "평가상태", "관리대상", "등록일자"
													, "자산분류(대)", "자산분류(중)", "자산분류(소)", "고객사"
													, "자산상태", "도입년도", "모델명"
													, "구성ID", "APP.번호", "자산관리번호"
													, "정보시스템명", "장비용도"
													, "운영부서", "운영자1", "운영자2"
													, "사용부서", "사용자1", "사용자2"
													, "설치장소", "Host명", "OS", "OS Version"
													, "IP"
													, "관리대상 여부", "비고"
													
                 });
        
        model.addAttribute("columns", new String[] { "CONF_ID", "ASSET_MGMT_NO", "APP_NO"
        										   , "APP_KOR_NM", "CUST_COMPANY_NM"
        										   , "ASSET_SEQ_YN", "MANAGED_YN", "REG_DT"
        										   , "ASSET_TOP_NM", "ASSET_MID_NM", "ASSET_BOT_NM", "CUST_COMPANY_NM"
        										   , "ASSET_STAT", "INTRO_YEAR", "MODEL_NM"
        										   , "CONF_ID", "", "ASSET_MGMT_NO"
        										   , "","EQUIP_USE"
        										   , "OPR_DEPT_NM", "OPR_1_EMP_NM", "OPR_2_EMP_NM"
        										   , "USE_DEPT_NM", "USE_1_EMP_NM", "USE_2_EMP_NM"
        										   , "LOCA_NM", "HOST_NM", "OS_NM", "OS_VER"
        										   , "IP_ADDR"
        										   , "MANAGED_YN", "NOTE"
                });
    
        model.addAttribute("columnsWidth", colWidth);
        model.addAttribute("chapter", "서버자산");
        model.addAttribute("filename", "서버자산"+"_"+Utils.getTimeStampString("yyyyMMdd"));
           
        model.addAttribute("data", resultList);
        
    }
	
	@Transactional(readOnly=true)
    public void getSecurityAssetsInfraListExcel(final Param param, final ModelMap model) throws SQLException {

		List<Param> resultList = session.selectList("com.softworks.springframework.securityAssets.getSecurityAssetsInfraListExcel", param);

		for(Param temp : resultList){
			String asset_seq    = temp.get("ASSET_SEQ");
			String conf_id      = temp.get("CONF_ID");
			String infra_sw_typ = temp.get("INFRA_SW_TYP");
			Param	paramOne	= new Param();
			paramOne.set("conf_id", conf_id);
			Param vItsAssetInfraOne = getVItsAssetInfraOne(paramOne);
			temp.putAll(vItsAssetInfraOne);
			
			String lawValue = "";
			Param	lawParam	= new Param();
			lawParam.set("asset_id", conf_id);
			lawParam.set("asset_class_cd", infra_sw_typ);
			List<Param> resultLawList = getAssetRelatedLawsList(lawParam);
			for(int i=0; i < resultLawList.size(); i++){
				Param law = resultLawList.get(i);
				String ls_abbr_nm = law.get("LS_ABBR_NM");
				lawValue = lawValue + ls_abbr_nm;
				if(i != resultLawList.size()-1){
					lawValue = lawValue + ",";
				}
			}
			temp.set("ls_abbr_nm", lawValue);
		}
		
		int[]	 colWidth	= { 20, 20, 20
							  , 20, 20, 20
							  , 20, 20, 20, 20
							  , 20, 20, 20, 20
							  , 20, 20, 20
							  , 20, 20
							  , 20, 20, 20
							  , 20, 20, 20
							  , 20, 20
							  , 20
		
		};
		model.addAttribute("category", new String[] { "SW구분", "구성ID" ,"자산관리번호"
													, "APP.번호", "정보시스템명", "회사명"
													, "자산상태", "평가상태", "관리대상", "등록일자"
													, "자산분류(대)", "자산분류(중)", "자산분류(소)", "고객사"
													, "자산상태", "도입년도", "모델명"
													, "구성ID", "APP.번호", "자산관리번호"
													, "설치장소", "장비용도"
													, "운영부서", "운영자1", "운영자2"
													, "사용부서", "사용자1", "사용자2"
													, "관리대상 여부", "비고"
													, "관련법/제도"
                 });
        
        model.addAttribute("columns", new String[] { "INFRA_SW_TYP", "CONF_ID", "ASSET_MGMT_NO"
        										   , "APP_NO", "APP_KOR_NM", "CUST_COMPANY_NM"
        										   , "ASSET_STAT" ,"ASSET_SEQ_YN", "MANAGED_YN", "REG_DT"
        										   , "ASSET_TOP_NM", "ASSET_MID_NM", "ASSET_BOT_NM", "CUST_COMPANY_NM"
        										   , "ASSET_STAT", "INTRO_YEAR", "MODEL_NM"
        										   , "CONF_ID", "", "ASSET_MGMT_NO"
        										   , "LOCA_NM", "EQUIP_USE"
        										   , "OPR_DEPT_NM", "OPR_1_EMP_NM", "OPR_2_EMP_NM"
        										   , "USE_DEPT_NM", "USE_1_EMP_NM", "USE_2_EMP_NM"
        										   , "MANAGED_YN", "NOTE"
        										   , "ls_abbr_nm"
        });
    
        model.addAttribute("columnsWidth", colWidth);
        model.addAttribute("chapter", "인프라SW자산");
        model.addAttribute("filename", "인프라SW자산"+"_"+Utils.getTimeStampString("yyyyMMdd"));
           
        model.addAttribute("data",resultList );
        
    }
	
	@Transactional(readOnly=true)
    public void getSecurityAssetsSecuListExcel(final Param param, final ModelMap model) throws SQLException {

		List<Param> resultList = session.selectList("com.softworks.springframework.securityAssets.getSecurityAssetsApplListExcel", param);
		
		for(Param temp : resultList){
			String asset_seq = temp.get("ASSET_SEQ");
			String app_no = temp.get("APP_NO");
			Param	paramOne	= new Param();
			paramOne.set("app_no", app_no);
			List<Param> ifItsMstApplList = getIfItsMstApplList(paramOne);
			for(int i=0; i < ifItsMstApplList.size(); i++){
				Param appl = ifItsMstApplList.get(i);
				String name = appl.get("NAME");
				String column_value = appl.get("COLUMN_VALUE");
				temp.set("name"+i, name);
				temp.set("value"+i, column_value);
			}
			
			String cvalue = "";
			List<Param> vItsApplCompany = getVItsApplCompany(paramOne);
			for(int i=0; i < vItsApplCompany.size(); i++){
				Param appl = vItsApplCompany.get(i);
				cvalue = cvalue + appl.get("SKCOMPANYNAME")+"/"+appl.get("TEAMNAMEMAIN");
				if(i != vItsApplCompany.size()-1){
					cvalue = cvalue + ",";
				}
			}
			temp.set("cvalue", cvalue);
			
			Param confParam = new Param();
			confParam.set("asset_seq", asset_seq);
			confParam.set("pcode", "LEGAL_CONF_CD_GRP");
			List<Param> resultAttrList = getSecurityAssetsAttrListListExcel(confParam);
			for(int i=0; i < resultAttrList.size(); i++){
				Param attr = resultAttrList.get(i);
				String attr_typ_cd_nm = attr.get("ATTR_TYP_CD_NM");
				temp.set("avalue"+i, attr_typ_cd_nm);
			}
			
			
			String lawValue = "";
			Param	lawParam	= new Param();
			lawParam.set("asset_id", app_no);
			lawParam.set("asset_class_cd", "SECU");
			List<Param> resultLawList = getAssetRelatedLawsList(lawParam);
			for(int i=0; i < resultLawList.size(); i++){
				Param law = resultLawList.get(i);
				String ls_abbr_nm = law.get("LS_ABBR_NM");
				lawValue = lawValue + ls_abbr_nm;
				if(i != resultLawList.size()-1){
					lawValue = lawValue + ",";
				}
			}
			temp.set("ls_abbr_nm", lawValue);
			
		}
		
		int[]	 colWidth	= {20, 20, 20, 20
				             , 20, 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20
				             , 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20, 20
				             , 20
				             };

		model.addAttribute("category", new String[] { "App.번호", "정보시스템명", "대분류" , "오픈일자" 
													, "평가상태", "관리대상", "등록일자"
													, "약어", "정보시스템명"
													, "App.분류(대)", "App.분류(중)"
													, "App.분류(소)", "오픈일자"
													, "현업담당자", "운영자"
													, "SSL"
													, "사용회사/주관부서"
													, "준거성평가코드", "정보등급코드"
													, "정보가치코드", "정보연관성코드"
													, "서비스가용성코드", "보안등급(중요도)코드"
													, "관리대상 여부", "SW 구분", "비고"
													, "관련법/제도"
                 });
        
        model.addAttribute("columns", new String[] { "APP_NO", "APP_KOR_NM", "APP_LARGE_NM","OPEN_DAY"
        										   , "ASSET_SEQ_YN", "MANAGED_YN", "REG_DT"
        										   , "value0", "value1"
        										   , "value2", "value3"
        										   , "value4", "value5"
        										   , "value6", "value7"
        										   , "value8"
        										   , "cvalue"
        										   , "avalue0","avalue1"
        										   , "avalue2","avalue3"
        										   , "avalue4","avalue5"
        										   , "MANAGED_YN", "SW_TYP_CD", "NOTE"
        										   , "ls_abbr_nm"
                });
    
        model.addAttribute("columnsWidth", colWidth);
        model.addAttribute("chapter", "보안시스템자산");
        model.addAttribute("filename", "보안시스템자산"+"_"+Utils.getTimeStampString("yyyyMMdd"));
           
        model.addAttribute("data", resultList);
        
    }
	
	
}