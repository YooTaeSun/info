package com.softworks.springframework.web.services.backoffice;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;
import com.softworks.springframework.web.services.MailSendService;

@Service
public class SecuExptPolicyScheduler extends BaseService {

	private	final	Logger		logger	= Logger.getLogger(getClass());

	@Autowired
	SchedulerLogService logSvc;

    public void setSession(SqlSessionTemplate session) {
		super.session = session;
		logSvc = new SchedulerLogService();
		logSvc.setSession(session);
	}

    /**
	 * [알림] 보안예외정책 적용기간 만료
	 * target table : T_USER, T_CONTENT , T_MAIL_SEND_HIST, EXCEPT_POLICY_PROC_RESULT
	 * Result : void
     * @throws Exception 
	 */
    public void execSecuExptPolicyAplyExp(final Param schdInfo) throws Exception {
    	int batch_cnt = 0;
    	int total_cnt = 0;
		String	err_chk			= "";
		String	rst_msg			= "";
		
		// start log
		schdInfo.set("BATCH_SEQ", logSvc.newAppendBatchHistory(schdInfo));
		
		Param mailRtnParam = null;
		
		MailSendService mm = new MailSendService();
		mm.setSession(session);
		
//		SecuritySystemOperationService ssSvc = new SecuritySystemOperationService();
//		ssSvc.setSession(session);

		try {
			Param param = new Param();
			Param contentReplaceParam;
			// 적용기간 만료 목록
			List<Param> exceptList = getSecuExptPolicyAplyExpList();
			
			
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
			int today = Integer.parseInt(format.format(calendar.getTime()));
			System.out.println("today:" +today);
			
			if(exceptList != null){	
				total_cnt = exceptList.size();
				for (Param exptInfo : exceptList) {
					//메일 발송 
					String recv_emp_no = exptInfo.get("REQ_EMP_NO");
					contentReplaceParam = new Param();
					contentReplaceParam.set("#ITS_NUM#", exptInfo.get("ITS_NO"));
					contentReplaceParam.set("#APLY_START_DAY#", exptInfo.get("START_DAY"));
					contentReplaceParam.set("#APLY_END_DAY#", exptInfo.get("END_DAY"));
					if(exptInfo.getInt("DEADLINE_NUM") > 0){
						contentReplaceParam.set("#DEADLINE#", exptInfo.get("DEADLINE_NUM")+"일 전");
					}else{
						contentReplaceParam.set("#DEADLINE#", "당일");
					}
					// get EXCEPT_POLICY_PROC_DETAIL 
					param.set("its_no", exptInfo.get("ITS_NO"));
					List<Param> exceptPolicyProcDetailList = getExceptPolicyProcDetailList(param);
					
					String apply_cn = "";
					for (Param eList : exceptPolicyProcDetailList) {
						apply_cn += "* 적용 보안시스템 : "+eList.get("SECU_APP_NM")+"</br>";
						apply_cn += "* 적용 내용 : "+eList.get("PROC_DETAIL")+"</br></br>";
					}
					contentReplaceParam.set("#APLY_CN#", apply_cn);
					mailRtnParam = mm.sendMail2("EM09", recv_emp_no, contentReplaceParam);
					System.out.println("RESULT_MSG ============> "+mailRtnParam.get("RESULT_MSG"));
					batch_cnt++;
				}
			}
		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		}
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		if (!err_chk.equals("")) {
			schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "N");
			schdInfo.set("BATCH_MSG", err_chk);
			logSvc.updateBatchHistory(schdInfo);
			
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
	    	if(batch_cnt > 0){
	    		rst_msg = "적용기간 만료 확인 처리 총 "+total_cnt + "건 중 " + batch_cnt + "건이 처리 되었습니다.";
	    	}else{
	    		rst_msg = "적용기간 만료 확인 처리내용이 없습니다.";
	    	}
	    	schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "Y");
			schdInfo.set("BATCH_MSG", rst_msg);
			logSvc.updateBatchHistory(schdInfo);
			
	    	logger.info("User append Daily Batch totCnt="+batch_cnt);
	    }
	}
    
	@Transactional(readOnly=true)
	public List<Param> getSecuExptPolicyAplyExpList() throws SQLException {
		return session.selectList("com.softworks.springframework.SecuExptPolicyScheduler.getSecuExptPolicyAplyExpList");
	}
	
	@Transactional(readOnly=true)
	public List<Param> getExceptPolicyProcDetailList(final Param param) throws SQLException {
		return session.selectList("com.softworks.springframework.SecuExptPolicyScheduler.getExceptPolicyProcDetailList", param);
	}
}
