package com.softworks.springframework.web.services.front;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.AesUtil;
import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
@SuppressWarnings("unchecked")
public class FileDownloadHistService extends BaseService {

	@Transactional(readOnly=true)
	public int getListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));

		return session.selectOne("com.softworks.springframework.FileDownloadHist.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) throws Exception {
		List<Param> list = session.selectList("com.softworks.springframework.FileDownloadHist.getList", param);
		for (Param el : list) {
			el.put("ZIP_PWD",  AesUtil.decrypt(el.get("ZIP_PWD")));
		}
		return list;
	}

	@Transactional(readOnly=true)
	public List<Param> getAllList(final Param param) throws Exception {
		List<Param> list = session.selectList("com.softworks.springframework.FileDownloadHist.getAllList", param);
		for (Param el : list) {
			el.put("ZIP_PWD",  AesUtil.decrypt(el.get("ZIP_PWD")));
		}
		return list;

	}

	@Transactional(readOnly=true)
	public Param getDetail(Param param) throws Exception {
		Param el = session.selectOne("com.softworks.springframework.FileDownloadHist.getList", param);
		el.put("ZIP_PWD",  AesUtil.decrypt(el.get("ZIP_PWD")));
		return el;
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int insert(final Param param) throws SQLException {
		return session.insert("com.softworks.springframework.FileDownloadHist.insert", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void update(final Param param) throws Exception {
		session.update("com.softworks.springframework.FileDownloadHist.update", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void delete(final Param param) throws Exception {
		session.delete("com.softworks.springframework.FileDownloadHist.delete", param);
	}

}
