package com.softworks.springframework.web.services.backoffice;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;
import com.softworks.springframework.web.services.CodeLoaderService.CodeInfo;
import com.softworks.springframework.web.services.MailSendService;

@Service
public class PrvtComSchedulerService extends BaseService {

	private	final	Logger		logger	= Logger.getLogger(getClass());
	
	@Autowired
	SchedulerLogService logSvc;

    public void setSession(SqlSessionTemplate session) {
		super.session = session;
		logSvc = new SchedulerLogService();
		logSvc.setSession(session);
	}

    /**
	 * [알림] 정보보안포털 사용기간 만료
	 * target table : T_USER, T_CONTENT , T_MAIL_SEND_HIST
	 * Result : void
     * @throws Exception 
	 */
    public void execPrvtComAplyExp(final Param schdInfo) throws Exception {
    	int batch_cnt = 0;
    	int total_cnt = 0;
		String	err_chk	= "";
		String	rst_msg = "";
		
		// start log
		schdInfo.set("BATCH_SEQ", logSvc.newAppendBatchHistory(schdInfo));
		
		Param mailRtnParam = null;
		
		MailSendService mm = new MailSendService();
		mm.setSession(session);

		try {
			Param param = new Param();
			param.set("typeChk", "Y");
			param.set("user_typ_cd", "E");
			// 수탁사 정보 가져오기
			int totalCnt = (Integer)session.selectOne("com.softworks.springframework.User.getListCount", param);
			param.set("page", 1);
			param.set("pageSize", totalCnt);
			List<Param> userList = session.selectList("com.softworks.springframework.User.getList", param);
			
			String status = "";
			String lockCd = "";
			int aply_start_day = 0;
			int aply_end_day = 0;
			Param uParam;
			Param contentReplaceParam;
			boolean boolMailSend = false;
			
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
			int today = Integer.parseInt(format.format(calendar.getTime()));
			
			
			if(userList != null){
				for (Param uInfo : userList) {
					boolMailSend = false;
					// 사용기간 만료 확인
					status = uInfo.get("ACNT_STATE_CD");
					aply_start_day = Integer.parseInt(uInfo.get("APLY_START_DAY"));
					aply_end_day = Integer.parseInt(uInfo.get("APLY_END_DAY"));
					lockCd = uInfo.get("ACNT_LOCK_RSN_CD");
					
					if( status.equals("ACT") || (status.equals("LOCK") && !lockCd.equals("L03")) ){
						
						// 사용기간 연장 으로 변경
						if(today > aply_end_day){
							total_cnt++;
							//메일 발송 
							contentReplaceParam = new Param();
							contentReplaceParam.set("#USER_ID#", uInfo.get("USER_ID"));
							contentReplaceParam.set("#APLY_START_DAY#", uInfo.get("APLY_START_DAY"));
							contentReplaceParam.set("#APLY_END_DAY#", uInfo.get("APLY_END_DAY"));
							mailRtnParam = mm.sendMailPrvt("EM34",uInfo.get("USER_ID"), contentReplaceParam);
							System.out.println("RESULT_MSG ============> "+mailRtnParam.get("RESULT_MSG"));
							if(Boolean.parseBoolean(mailRtnParam.get("RESULT"))){
								uParam = new Param();
								uParam.set("user_id", uInfo.get("USER_ID"));
								uParam.set("acnt_state_cd", "LOCK");
								uParam.set("acnt_lock_rsn_cd", "L03");
								uParam.set("user_id",uInfo.get("USER_ID"));
								uParam.set("user_nm",uInfo.get("USER_NM"));
								session.update("com.softworks.springframework.User.updateAcntStateCd", uParam);
								batch_cnt++;
							}
						}
					}
				}
			}
			
		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		}
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		if (!err_chk.equals("")) {
			schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "N");
			schdInfo.set("BATCH_MSG", err_chk);
			logSvc.updateBatchHistory(schdInfo);
			
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
	    	if(batch_cnt > 0){
	    		rst_msg = "사용 기간 만료 확인 처리 총 "+total_cnt + "건 중 " + batch_cnt + "건이 처리 되었습니다.";
	    	}else{
	    		rst_msg = "사용 기간 만료 확인 처리내용이 없습니다.";
	    	}
	    	schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "Y");
			schdInfo.set("BATCH_MSG", rst_msg);
			logSvc.updateBatchHistory(schdInfo);
			
	    	logger.info("User append Daily Batch totCnt="+batch_cnt);
	    }
	}
    
    /**
	 * [알림] 정보보안포털 비밀번호 변경 요청
	 * target table : T_USER, T_CONTENT , T_MAIL_SEND_HIST
	 * Result : void
     * @throws Exception 
	 */
    public void execPrvtComPwExp(final Param schdInfo) throws Exception {
    	int batch_cnt = 0;
    	int total_cnt = 0;
		String	err_chk			= "";
		String	rst_msg			= "";
		
		// start log
		schdInfo.set("BATCH_SEQ", logSvc.newAppendBatchHistory(schdInfo));
		
		List<CodeInfo> chgPwdDayList = getUseCodeList("CHANGE_PWD_DAYS"); // 비밀번호 변경 기한 90일
		int change_pwd_days = Integer.parseInt(chgPwdDayList.get(0).getCode());
		Param mailRtnParam = null;
		
		MailSendService mm = new MailSendService();
		mm.setSession(session);

		try {
			Param param = new Param();
			param.set("typeChk", "Y");
			param.set("user_typ_cd", "E");
			// 수탁사 정보 가져오기
			int totalCnt = (Integer)session.selectOne("com.softworks.springframework.User.getListCount", param);
			param.set("page", 1);
			param.set("pageSize", totalCnt);
			List<Param> userList = session.selectList("com.softworks.springframework.User.getList", param);
			
			String status = "";
			String lockCd = "";
			int aply_start_day = 0;
			int aply_end_day = 0;
			Param uParam;
			Param contentReplaceParam;
			boolean boolMailSend = false;
			
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
			int today = Integer.parseInt(format.format(calendar.getTime()));
			
			if(userList != null){
				for (Param uInfo : userList) {
					boolMailSend = false;
					// 사용기간 만료 확인
					status = uInfo.get("ACNT_STATE_CD");
					aply_start_day = Integer.parseInt(uInfo.get("APLY_START_DAY"));
					aply_end_day = Integer.parseInt(uInfo.get("APLY_END_DAY"));
					lockCd = uInfo.get("ACNT_LOCK_RSN_CD");
					
					if( status.equals("ACT") || (status.equals("LOCK") && !lockCd.equals("L03")) ){
						
						// 사용기간 연장 으로 변경
						if(today <= aply_end_day){
							total_cnt++;
							param.set("user_id", uInfo.get("USER_ID"));
							// 비밀번호 변경 확인 (3개월이 지났는지 확인)
							param.set("change_pwd_days", change_pwd_days);
							List<Param> info = session.selectList("com.softworks.springframework.User.getInfo", param);
							if(info == null || info.size() < 1){
								//메일 발송 
								contentReplaceParam = new Param();
								contentReplaceParam.set("#USER_ID#", uInfo.get("USER_ID"));
								contentReplaceParam.set("#APLY_END_DAY#", uInfo.get("APLY_END_DAY"));
								mailRtnParam = mm.sendMailPrvt("EM35",uInfo.get("USER_ID"), contentReplaceParam);
								System.out.println("RESULT_MSG ============> "+mailRtnParam.get("RESULT_MSG")) ;
								if(Boolean.parseBoolean(mailRtnParam.get("RESULT"))){
									uParam = new Param();
									uParam.set("user_id", uInfo.get("USER_ID"));
									uParam.set("acnt_state_cd", "LOCK");
									uParam.set("acnt_lock_rsn_cd", "L02");
									uParam.set("user_id",uInfo.get("USER_ID"));
									uParam.set("user_nm",uInfo.get("USER_NM"));
									session.update("com.softworks.springframework.User.updateAcntStateCd", uParam);
									batch_cnt++;
								}
							}
						}
					}
				}
			}
			
		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		}
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		if (!err_chk.equals("")) {
			schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "N");
			schdInfo.set("BATCH_MSG", err_chk);
			logSvc.updateBatchHistory(schdInfo);
			
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
	    	if(batch_cnt > 0){
	    		rst_msg = "비밀번호 만료 확인 처리 총 "+total_cnt + "건 중 " + batch_cnt + "건이 처리 되었습니다.";
	    	}else{
	    		rst_msg = "비밀번호 만료 확인 처리내용이 없습니다.";
	    	}
	    	schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "Y");
			schdInfo.set("BATCH_MSG", rst_msg);
			logSvc.updateBatchHistory(schdInfo);
			
	    	logger.info("User append Daily Batch totCnt="+batch_cnt);
	    }
	}
    
    /**
	 * [알림] 개인정보제공업체 계약 갱신 확인
	 * target table : T_USER, T_CONTENT , T_MAIL_SEND_HIST
	 * Result : void
     * @throws Exception 
	 */
    public void chkPrvtComLastUpdDt(final Param schdInfo) throws Exception {
    	int batch_cnt = 0;
    	int total_cnt = 0;
		String	err_chk			= "";
		String	rst_msg			= "";
		
		// start log
		schdInfo.set("BATCH_SEQ", logSvc.newAppendBatchHistory(schdInfo));
		
		List<Param> targetList = getPrvtComLastUpdDt();
		
		Param mailRtnParam = null;
		
		MailSendService mm = new MailSendService();
		mm.setSession(session);

		try {
			Param param = new Param();
			
			Param uParam;
			Param contentReplaceParam;
			boolean boolMailSend = false;
			
			if(targetList != null){
				for (Param target : targetList) {
					total_cnt++;
					boolMailSend = false;
					
					contentReplaceParam = new Param();
					contentReplaceParam.set("#COMPANY_NM#", target.get("COMPANY_NM"));
					mailRtnParam = mm.sendMailPrvt("EM35",target.get("MANAGER_EMP_NO"), contentReplaceParam);
					System.out.println("RESULT_MSG ============> "+mailRtnParam.get("RESULT_MSG")) ;
					if(Boolean.parseBoolean(mailRtnParam.get("RESULT"))){
						batch_cnt++;
					}
				}
			}
			
		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		}
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		if (!err_chk.equals("")) {
			schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "N");
			schdInfo.set("BATCH_MSG", err_chk);
			logSvc.updateBatchHistory(schdInfo);
			
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
	    	if(batch_cnt > 0){
	    		rst_msg = "비밀번호 만료 확인 처리 총 "+total_cnt + "건 중 " + batch_cnt + "건이 처리 되었습니다.";
	    	}else{
	    		rst_msg = "비밀번호 만료 확인 처리내용이 없습니다.";
	    	}
	    	schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "Y");
			schdInfo.set("BATCH_MSG", rst_msg);
			logSvc.updateBatchHistory(schdInfo);
			
	    	logger.info("User append Daily Batch totCnt="+batch_cnt);
	    }
	}
    
    @Transactional(readOnly=true)
	public List<Param> getPrvtComLastUpdDt() throws SQLException {
		return session.selectList("com.softworks.springframework.PrvtComSchedulerScheduler.getPrvtComLastUpdDt");
	}
}
