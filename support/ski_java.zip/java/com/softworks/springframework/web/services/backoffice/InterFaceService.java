package com.softworks.springframework.web.services.backoffice;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class InterFaceService extends BaseService{
    
	@Transactional(readOnly=true)
	public int getBatchListCount(final Param param) throws SQLException {
		
		param.set("page", param.getInt("page", 1));
		param.set("pageSize", param.getInt("pageSize", DEFAULT_PAGE_SIZE));
		param.set("limitSize", (param.getInt("page")-1)*DEFAULT_PAGE_SIZE);
		
		return (Integer)session.selectOne("com.softworks.springframework.InterFace.getBatchHistListCount", param);
	}
	
	
	@Transactional(readOnly=true)
	public List<Param> getBatchList(final Param param) throws SQLException {
		
		return session.selectList("com.softworks.springframework.InterFace.getBatchHistList", param);
	}
	
	@Transactional(readOnly=true)
	public int getSqmsListCount(final Param param) throws SQLException {
		
		param.set("page", param.getInt("page", 1));
		param.set("pageSize", param.getInt("pageSize", DEFAULT_PAGE_SIZE));
		param.set("limitSize", (param.getInt("page")-1)*DEFAULT_PAGE_SIZE);
		
		return (Integer)session.selectOne("com.softworks.springframework.InterFace.getSqmsListCount", param);
	}
	
	
	@Transactional(readOnly=true)
	public List<Param> getSqmsList(final Param param) throws SQLException {
		
		return session.selectList("com.softworks.springframework.InterFace.getSqmsList", param);
	}
	
	@Transactional(readOnly=true)
	public Param getSqmsInfo(final Param param) throws SQLException {
		
		return (Param)session.selectOne("com.softworks.springframework.InterFace.getSqmsMasterInfo", param);
	}
		
	@Transactional(readOnly=true)
	public List<Param> getSqmsUserList(final Param param) throws SQLException {
		
		return session.selectList("com.softworks.springframework.InterFace.getSqmsUserList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getServiceList(final Param param) throws SQLException {
		
		return session.selectList("com.softworks.springframework.InterFace.getServiceList", param);
	}
	
	
	@Transactional(readOnly=true)
	public List<Param> getExceptServiceList(final Param param) throws SQLException {
		
		return session.selectList("com.softworks.springframework.InterFace.getExceptServiceList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getDomainCodeList(final Param param) throws SQLException {
		
		return session.selectList("com.softworks.springframework.InterFace.getDomainCodeList", param);
	}
	
	public void insertTDomainData(final Param param) throws SQLException {
		session.insert("com.softworks.springframework.InterFace.insertTDomainData", param);
	}
	
	public void deleteTDomainData(final Param param) throws SQLException {
		session.delete("com.softworks.springframework.InterFace.deleteTDomainData", param);
	}
	
	@Transactional(readOnly=true)
	public int getBackupStorageListCount(final Param param) throws SQLException {
		
		param.set("page", param.getInt("page", 1));
		param.set("pageSize", param.getInt("pageSize", DEFAULT_PAGE_SIZE));
		param.set("limitSize", (param.getInt("page")-1)*DEFAULT_PAGE_SIZE);
		
		return (Integer)session.selectOne("com.softworks.springframework.InterFace.getAdminBackupStorageListCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getBackupStorageList(final Param param) throws SQLException {
	    return session.selectList("com.softworks.springframework.InterFace.getAdminBackupStorageList" ,param);
	}
	
	@Transactional(readOnly=true)
    public int getClusterListCount(final Param param) throws SQLException {
        
        param.set("page", param.getInt("page", 1));
        param.set("pageSize", param.getInt("pageSize", DEFAULT_PAGE_SIZE));
        param.set("limitSize", (param.getInt("page")-1)*DEFAULT_PAGE_SIZE);
        
        return (Integer)session.selectOne("com.softworks.springframework.InterFaceView.getClusterListCount", param);
    }
    
    
    @Transactional(readOnly=true)
    public List<Param> getClusterList(final Param param) throws SQLException {
        
        return session.selectList("com.softworks.springframework.InterFaceView.getClusterList", param);
    }
    
    @Transactional(readOnly=true)
    public List<Param> getLocationList() throws SQLException {
        
        return session.selectList("com.softworks.springframework.InterFaceView.getLocationList");
    }
    
    @Transactional(readOnly=true)
    public Param getClusterInfo(final String cluster) throws SQLException {
        return (Param)session.selectOne("com.softworks.springframework.InterFaceView.getClusterInfo", cluster);
    }
    
    public void insertCluster(final Param param) throws SQLException {
		session.insert("com.softworks.springframework.InterFaceView.insertCluster", param);
	}
	
	public void updateCluster(final Param param) throws SQLException {
		session.update("com.softworks.springframework.InterFaceView.updateCluster", param);
	}
	
	public void deleteCluster(final String cluster) throws Exception {
		session.delete("com.softworks.springframework.InterFaceView.deleteCluster", cluster);
	}
	
	@Transactional(readOnly=true)
    public int getBackupEquipListCount(final Param param) throws SQLException {
        
        param.set("page", param.getInt("page", 1));
        param.set("pageSize", param.getInt("pageSize", DEFAULT_PAGE_SIZE));
        param.set("limitSize", (param.getInt("page")-1)*DEFAULT_PAGE_SIZE);
        
        return (Integer)session.selectOne("com.softworks.springframework.op.getBackupEquipListCount", param);
    }
    
    
    @Transactional(readOnly=true)
    public List<Param> getBackupEquipList(final Param param) throws SQLException {
        
        return session.selectList("com.softworks.springframework.op.getBackupEquipList", param);
    }
	
    public void insertBackupEquip(final Param param) throws SQLException {
		session.insert("com.softworks.springframework.op.insertBackupEquip", param);
	}
	
	public void updateBackupEquip(final Param param) throws SQLException {
		session.update("com.softworks.springframework.op.updateBackupEquip", param);
	}
	
	public void deleteBackupEquip(final Param param) throws SQLException {
		session.delete("com.softworks.springframework.op.deleteBackupEquip", param);
	}
	
	@Transactional(readOnly=true)
    public int getBackupMasterListCount(final Param param) throws SQLException {
        
        param.set("page", param.getInt("page", 1));
        param.set("pageSize", param.getInt("pageSize", DEFAULT_PAGE_SIZE));
        param.set("limitSize", (param.getInt("page")-1)*DEFAULT_PAGE_SIZE);
        
        return (Integer)session.selectOne("com.softworks.springframework.op.getBackupMasterListCount", param);
    }
    
    
    @Transactional(readOnly=true)
    public List<Param> getBackupMasterList(final Param param) throws SQLException {
        
        return session.selectList("com.softworks.springframework.op.getBackupMasterList", param);
    }
	
    public void insertBackupMaster(final Param param) throws SQLException {
		session.insert("com.softworks.springframework.op.insertBackupMaster", param);
	}
	
	public void updateBackupMaster(final Param param) throws SQLException {
		session.update("com.softworks.springframework.op.updateBackupMaster", param);
	}
	
	public void deleteBackupMaster(final Param param) throws SQLException {
		session.delete("com.softworks.springframework.op.deleteBackupMaster", param);
	}
	
	
	
	
	@Transactional(readOnly=true)
    public int getBackupFileBatchListCount(final Param param) throws SQLException {
        
        param.set("page", param.getInt("page", 1));
        param.set("pageSize", param.getInt("pageSize", DEFAULT_PAGE_SIZE));
        param.set("limitSize", (param.getInt("page")-1)*DEFAULT_PAGE_SIZE);
        
        return (Integer)session.selectOne("com.softworks.springframework.InterFace.getBackupFileBatchListCount", param);
    }
    
    
    @Transactional(readOnly=true)
    public List<Param> getBackupFileBatchList(final Param param) throws SQLException {
        
        return session.selectList("com.softworks.springframework.InterFace.getBackupFileBatchList", param);
    }
    
    
    /* 20180718 변현민
	 *  U002 백업실패시 메일발송 리스트 화면 및 코드개발
	 */
	@Transactional(readOnly=true)
    public int getMailUserListCount(final Param param) throws SQLException {
        
        param.set("page", param.getInt("page", 1));
        param.set("pageSize", param.getInt("pageSize", DEFAULT_PAGE_SIZE));
        param.set("limitSize", (param.getInt("page")-1)*DEFAULT_PAGE_SIZE);
        
        return (Integer)session.selectOne("com.softworks.springframework.InterFace.getMailUserListCount", param);
    }
	
	@Transactional(readOnly=true)
	public List<Param> getMailUserList(final Param param) throws SQLException {
		
		return session.selectList("com.softworks.springframework.InterFace.getMailUserList", param);
	}
	
	public void insertMailUser(final Param param) throws SQLException {
			session.insert("com.softworks.springframework.InterFace.insertMailUser", param);
	}
	
	public void updateMailUser(final Param param) throws SQLException {
		session.update("com.softworks.springframework.InterFace.updateMailUser", param);
	}
	
	public void deleteMailUser(final String seq) throws Exception {
		session.delete("com.softworks.springframework.InterFace.deleteMailUser", seq);
	}
	
	@Transactional(readOnly=true)
	public void getBatchHistListForExcel(final Param param, final ModelMap model) throws SQLException {
	        
	        model.addAttribute("category", new String[] { "순서", "연동코드", "연동구분", "스케쥴명","시작시간", "종료시간", 
	                "성공여부",  "연동건수","작업시간(ms)"});
	        
	        model.addAttribute("columns", new String[] { "seq", "batch_cd","batch_nm", "schedule_cd","start_dt", "end_dt", "success_yn", "batch_cnt","worktim"});
	    
	        model.addAttribute("chapter", "내외부연동결과");
	        model.addAttribute("filename", "내외부연동결과");
	        
	        String regSdate = param.get("sdate");
	        String regEdate = param.get("edate");
	        
	        if(!regSdate.equals("") && !regEdate.equals("")) {
	            model.addAttribute("title", "기간 : " + regSdate + " ~ " + regEdate);
	        }
	        
	        model.addAttribute("data", session.selectList("com.softworks.springframework.InterFace.getBatchHistListForExcel", param));
	        
	        
	}
	
	@Transactional(readOnly=true)
	public void getStorageListForExcel(final Param param, final ModelMap model) throws SQLException {
	        
		model.addAttribute("category", new String[] { "ID", "스토리지명", "IP", "일련번호","모델", "판매사", 
		        "전체용량",  "저장용량","사용율" ,"관리URL" ,"상태" ,"삭제"});
		
		model.addAttribute("columns", new String[] { "storageId", "storageNm","storageIp", "storageSerial","storageModel", "storageVendor", "capacityTotal", "storagePools","usePercent", "managementUrl", "isActive","del_yn"});
		
		model.addAttribute("chapter", "스토리지관리");
		model.addAttribute("filename", "스토리지관리");
		
		model.addAttribute("data", session.selectList("com.softworks.springframework.InterFace.getAdminBackupStorageListForExcel", param));
	        
	}
	
	@Transactional(readOnly=true)
	public void getBackupMasterForExcel(final Param param, final ModelMap model) throws SQLException {
	        
		model.addAttribute("category", new String[] { "백업서버번호", "도메인명", "백업서버 IP", "파일타입", "백업서버TYPE","백업서버명",  "백업서버설명" ,"장비명","장비IP", 
		        "담당자명", "담당자 연락처","사용여부"});
		
		model.addAttribute("columns", new String[] { "backup_master_no", "domain_nm", "master_ip", "master_type_str", "backup_type_nm","master_server_nm", 
				"backup_master_desc",  "equip_nm", "equip_ip",  "backup_charger_nm", "movetelno" ,"backup_use_yn"});
		
		model.addAttribute("chapter", "백업서버관리");
		model.addAttribute("filename", "백업서버관리");
		    
		model.addAttribute("data", session.selectList("com.softworks.springframework.op.getBackupMasterListExcel", param));
		    
	}
	
	@Transactional(readOnly=true)
	public void getBackupFileBatchListForExcel(final Param param, final ModelMap model) throws SQLException {
	        
		model.addAttribute("category", new String[] { "실행일자", "백업마스터IP", "파일구분", "백업타입", "연동파일명","성공여부",  "실패사유" ,"작업일시"});
		
		model.addAttribute("columns", new String[] { "if_date", "master_ip", "master_type_Str", "backup_type_nm", "file_name","success_yn", 
				"fail_desc",  "work_date"});
		
		model.addAttribute("chapter", "백업서버FPT연동결과");
		model.addAttribute("filename", "백업서버FPT연동결과");
		    
		model.addAttribute("data", session.selectList("com.softworks.springframework.InterFace.getBackupFileBatchListForExcel", param));
		    
	}
}
