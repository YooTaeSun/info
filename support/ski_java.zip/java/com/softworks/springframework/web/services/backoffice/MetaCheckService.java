package com.softworks.springframework.web.services.backoffice;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;

@Service
public class MetaCheckService extends BaseService {
	

	@Transactional(readOnly=true)
	public Param getCheckItemOne(Param param) {
		return session.selectOne("com.softworks.springframework.MetaCheck.getCheckItemOne", param);
	}
	
	@Transactional(readOnly=true)
	public int getCheckItemListCount(Param param) {
		return session.selectOne("com.softworks.springframework.MetaCheck.getCheckItemListCount", param);
	}
	
	@Transactional(readOnly=true)
	public int getChckItemDupleCount(Param param) {
		return session.selectOne("com.softworks.springframework.MetaCheck.getChckItemDupleCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getCheckItemList(Param param) {
		return session.selectList("com.softworks.springframework.MetaCheck.getCheckItemList", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertChckItem(final Param param) throws Exception {
		session.insert("com.softworks.springframework.MetaCheck.insertChckItem", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void update510(final Param param) throws Exception {
		session.update("com.softworks.springframework.MetaCheck.update510", param);
	}
	
	public void delete510(final Param param) throws Exception {
		session.delete("com.softworks.springframework.MetaCheck.delete510", param);
	}
	
	@Transactional(readOnly=true)
	public int getCount512(Param param) {
		return session.selectOne("com.softworks.springframework.MetaCheck.getCount512", param);
	}
	
	@Transactional(readOnly=true)
	public Param getCheckLevelOne(Param param) {
		return session.selectOne("com.softworks.springframework.MetaCheck.getCheckLevelOne", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getCheckLevelList(Param param) {
		return session.selectList("com.softworks.springframework.MetaCheck.getCheckLevelList", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertCheckLevel(final Param param) throws Exception {
		session.insert("com.softworks.springframework.MetaCheck.insertCheckLevel", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateCheckLevel(final Param param) throws Exception {
		session.update("com.softworks.springframework.MetaCheck.updateCheckLevel", param);
	}
	
	public void deleteCheckLevelHist(Param param)throws Exception {
		Param selectOne = getCheckLevelOne(param);
		if(selectOne != null){
			param.set("chg_typ_cd", "D");
			param.set("chk_item_cd",selectOne.get("CHK_ITEM_CD"));
			param.set("chk_item_nm",selectOne.get("CHK_ITEM_NM"));
			param.set("chk_level_cd",selectOne.get("CHK_LEVEL_CD"));
			param.set("chk_level_def",selectOne.get("CHK_LEVEL_DEF"));
			param.set("reg_id",param.get("reg_id"));
			param.set("reg_nm",param.get("reg_nm"));
			insertCheckLevelHist(param);
		}
	}
	
	public void delete512(final Param param) throws Exception {
		session.delete("com.softworks.springframework.MetaCheck.delete512", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertCheckLevelHist(final Param param) throws Exception {
		session.insert("com.softworks.springframework.MetaCheck.insertCheckLevelHist", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteService510(final Param param) throws Exception {
		
		param.set("chk_level_cd", "L1");
		deleteCheckLevelHist(param);
		param.set("chk_level_cd", "L2");
		deleteCheckLevelHist(param);
		param.set("chk_level_cd", "L3");
		deleteCheckLevelHist(param);
		param.set("chk_level_cd", "L4");
		deleteCheckLevelHist(param);
		param.set("chk_level_cd", "L5");
		deleteCheckLevelHist(param);
		
		delete512(param);
		delete510(param);
	}
	
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertServiceCheckLevel(final Param param) throws Exception {
		
		String chk_level_def1 = Utils.nvl(param.get("chk_level_def1"));
		String chk_level_def2 = Utils.nvl(param.get("chk_level_def2"));
		String chk_level_def3 = Utils.nvl(param.get("chk_level_def3"));
		String chk_level_def4 = Utils.nvl(param.get("chk_level_def4"));
		String chk_level_def5 = Utils.nvl(param.get("chk_level_def5"));
		
		String use_yn1 = Utils.nvl(param.get("use_yn1"));
		String use_yn2 = Utils.nvl(param.get("use_yn2"));
		String use_yn3 = Utils.nvl(param.get("use_yn3"));
		String use_yn4 = Utils.nvl(param.get("use_yn4"));
		String use_yn5 = Utils.nvl(param.get("use_yn5"));
		
		param.set("chg_typ_cd", "C");
		
		if(!"".equals(chk_level_def1)){
			param.set("chk_level_cd", "L1");
			param.set("chk_level_def", chk_level_def1);
			param.set("use_yn", use_yn1);
			insertCheckLevel(param);
			insertCheckLevelHist(param);
		}
		if(!"".equals(chk_level_def2)){
			param.set("chk_level_cd", "L2");
			param.set("chk_level_def", chk_level_def2);
			param.set("use_yn", use_yn2);
			insertCheckLevel(param);
			insertCheckLevelHist(param);
		}
		if(!"".equals(chk_level_def3)){
			param.set("chk_level_cd", "L3");
			param.set("chk_level_def", chk_level_def3);
			param.set("use_yn", use_yn3);
			insertCheckLevel(param);
			insertCheckLevelHist(param);
		}
		if(!"".equals(chk_level_def4)){
			param.set("chk_level_cd", "L4");
			param.set("chk_level_def", chk_level_def4);
			param.set("use_yn", use_yn4);
			insertCheckLevel(param);
			insertCheckLevelHist(param);
		}
		if(!"".equals(chk_level_def5)){
			param.set("chk_level_cd", "L5");
			param.set("chk_level_def", chk_level_def5);
			param.set("use_yn", use_yn5);
			insertCheckLevel(param);
			insertCheckLevelHist(param);
		}
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateServiceCheckLevel(final Param param) throws Exception {
		
		String chk_level_def1 = Utils.nvl(param.get("chk_level_def1"));
		String chk_level_def2 = Utils.nvl(param.get("chk_level_def2"));
		String chk_level_def3 = Utils.nvl(param.get("chk_level_def3"));
		String chk_level_def4 = Utils.nvl(param.get("chk_level_def4"));
		String chk_level_def5 = Utils.nvl(param.get("chk_level_def5"));
		
		String chk_level_def1_chk = Utils.nvl(param.get("chk_level_def1_chk"));
		String chk_level_def2_chk = Utils.nvl(param.get("chk_level_def2_chk"));
		String chk_level_def3_chk = Utils.nvl(param.get("chk_level_def3_chk"));
		String chk_level_def4_chk = Utils.nvl(param.get("chk_level_def4_chk"));
		String chk_level_def5_chk = Utils.nvl(param.get("chk_level_def5_chk"));	
		
		String use_yn1 = Utils.nvl(param.get("use_yn1"));
		String use_yn2 = Utils.nvl(param.get("use_yn2"));
		String use_yn3 = Utils.nvl(param.get("use_yn3"));
		String use_yn4 = Utils.nvl(param.get("use_yn4"));
		String use_yn5 = Utils.nvl(param.get("use_yn5"));
		
		if("on".equals(chk_level_def1_chk)){
			param.set("chk_level_cd", "L1");
			param.set("chk_level_def", chk_level_def1);
			param.set("use_yn", use_yn1);
			int count = getCount512(param);
			if(count == 0 ){
				param.set("chg_typ_cd", "C");
				insertCheckLevel(param);
				insertCheckLevelHist(param);
			}else{
				param.set("chg_typ_cd", "U");
				updateCheckLevel(param);
				insertCheckLevelHist(param);
			}
		}
		if("on".equals(chk_level_def2_chk)){
			param.set("chk_level_cd", "L2");
			param.set("chk_level_def", chk_level_def2);
			param.set("use_yn", use_yn2);
			int count = getCount512(param);
			if(count == 0 ){
				param.set("chg_typ_cd", "C");
				insertCheckLevel(param);
				insertCheckLevelHist(param);
			}else{
				param.set("chg_typ_cd", "U");
				updateCheckLevel(param);
				insertCheckLevelHist(param);
			}
		}
		if("on".equals(chk_level_def3_chk)){
			param.set("chk_level_cd", "L3");
			param.set("chk_level_def", chk_level_def3);
			param.set("use_yn", use_yn3);
			int count = getCount512(param);
			if(count == 0 ){
				param.set("chg_typ_cd", "C");
				insertCheckLevel(param);
				insertCheckLevelHist(param);
			}else{
				param.set("chg_typ_cd", "U");
				updateCheckLevel(param);
				insertCheckLevelHist(param);
			}
		}
		if("on".equals(chk_level_def4_chk)){
			param.set("chk_level_cd", "L4");
			param.set("chk_level_def", chk_level_def4);
			param.set("use_yn", use_yn4);
			int count = getCount512(param);
			if(count == 0 ){
				param.set("chg_typ_cd", "C");
				insertCheckLevel(param);
				insertCheckLevelHist(param);
			}else{
				param.set("chg_typ_cd", "U");
				updateCheckLevel(param);
				insertCheckLevelHist(param);
			}
		}
		if("on".equals(chk_level_def5_chk)){
			param.set("chk_level_cd", "L5");
			param.set("chk_level_def", chk_level_def5);
			param.set("use_yn", use_yn5);
			int count = getCount512(param);
			if(count == 0 ){
				param.set("chg_typ_cd", "C");
				insertCheckLevel(param);
				insertCheckLevelHist(param);
			}else{
				param.set("chg_typ_cd", "U");
				updateCheckLevel(param);
				insertCheckLevelHist(param);
			}
		}
		
	}
	
	@Transactional(readOnly=true)
	public int getMchecktCount(Param param) {
		return session.selectOne("com.softworks.springframework.MetaCheck.getMchecktCount", param);
	}
	
	@Transactional(readOnly=true)
	public int getMcheckLevelHistListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*10));
		
		return (int)session.selectOne("com.softworks.springframework.MetaCheck.getMcheckLevelHistListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getMcheckLevelHistList(final Param param) {
		return session.selectList("com.softworks.springframework.MetaCheck.getMcheckLevelHistList", param);
	}
	

}