package com.softworks.springframework.web.services.front;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.view.ExcelDownloadView.ExcelMergeInfo;
import com.softworks.springframework.web.services.BaseService;

@Service
public class IfAsmWasMasterService extends BaseService {

	@Transactional(readOnly=true)
	public int getListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));

		return session.selectOne("com.softworks.springframework.IfAsmWasMaster.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) {
		return session.selectList("com.softworks.springframework.IfAsmWasMaster.getList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getAllList(final Param param) {
		return session.selectList("com.softworks.springframework.IfAsmWasMaster.getAllList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getExcelList(final Param param) {
		return session.selectList("com.softworks.springframework.IfAsmWasMaster.getExcelList", param);
	}

	@Transactional(readOnly=true)
	public Param getDetailTotal(final Param param) {
		return session.selectOne("com.softworks.springframework.IfAsmWasMaster.getDetailTotal", param);
	}

	@Transactional(readOnly=true)
    public void getListExcel(final Param param, final ModelMap model) throws SQLException {
		String[] category1 = {
				 "No","년도","App.명","운영자","HOST"
				 ,"IP","진단항목","등급","진단결과","진단결과"
				 ,"진단결과","진단결과","잔존취약"
				};

		String[] category2 = {
				"No","년도","App.명","운영자","HOST"
				,"IP","진단항목","등급","상","중"
				,"하","계","잔존취약"
		};

		String[] columns = {
       		 "RNUM","TARGET_YEAR","KOR_NAME","PM_NM","HOST"
       		 ,"IP","DIAG_WAS_FLATFORM_NM","FINAL_LEVEL","TOP_CNT","MID_CNT"
       		 ,"LOW_CNT","TOTAL_CNT","CURR_CNT"
       		 };

		int[] colWidth	= { 5, 10, 40, 15, 20
		   		   ,50, 30, 10, 10, 10
		   		   ,10, 10, 10};

		List<String[]> multiCategory = new ArrayList<String[]>();
		multiCategory.add(category1);
		multiCategory.add(category2);

		List<ExcelMergeInfo> mergeInfo = new ArrayList<ExcelMergeInfo>();
		//int rowFrom, short colFrom, int rowTo, short colTo
		mergeInfo.add(new ExcelMergeInfo(0, (short)0, 1, (short)0));
		mergeInfo.add(new ExcelMergeInfo(0, (short)1, 1, (short)1));
		mergeInfo.add(new ExcelMergeInfo(0, (short)2, 1, (short)2));
		mergeInfo.add(new ExcelMergeInfo(0, (short)3, 1, (short)3));
		mergeInfo.add(new ExcelMergeInfo(0, (short)4, 1, (short)4));
		mergeInfo.add(new ExcelMergeInfo(0, (short)5, 1, (short)5));
		mergeInfo.add(new ExcelMergeInfo(0, (short)6, 1, (short)6));
		mergeInfo.add(new ExcelMergeInfo(0, (short)7, 1, (short)7));
		mergeInfo.add(new ExcelMergeInfo(0, (short)12, 1, (short)12));

		mergeInfo.add(new ExcelMergeInfo(0, (short)8, 0, (short)11));

       String excelName = "WAS진단현황_" + Utils.getTimeStampString("yyyyMMdd");

		model.addAttribute("filename", excelName);
        model.addAttribute("chapter", "1");
        model.addAttribute("multiCategory", multiCategory);
        model.addAttribute("headerMergeInfo", mergeInfo);
        model.addAttribute("columns", columns);
        model.addAttribute("columnsWidth", colWidth);
        model.addAttribute("data", this.getExcelList(param));
   }
}
