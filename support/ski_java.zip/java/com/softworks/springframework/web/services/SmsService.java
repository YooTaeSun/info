package com.softworks.springframework.web.services;

import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;

/**
 * SK Infosec SMS 전송 Manager<br/>
 * <br/>
 * 사용예 1) setter를 이용한 단일 메시지 보내기
 * <ol>
 *     <li>@Autowired private SmsService smsService</li>
 *     <li>try {</li>
 *     <li>	smsService.setInterval(10); // 10분뒤 전송</li>
 *     <li>	smsService.setRcvTelNo("01012345678"); // 수신전화번호</li>
 *     <li>	smsService.setSendTelNo("0212345678"); // 송신전화번호</li>
 *     <li>	smsService.setMsg("SMS를 보냅니다."); // 메시지</li>
 *     <li>	smsService.send(); // 메시지 전송</li>
 *     <li>} catch (Exception e) {}....</li>
 * </ol>
 * <br/>
 * 사용예 2) parameter를 이용한 단일 메시지 보내기
 * <ol>
 *     <li>@Autowired private SmsService smsService</li>
 *     <li>try {</li>
 *     <li>	Param param = new Param();</li>
 *     <li>	param.set("interval", 10); // 10분뒤 전송</li>
 *     <li>	param.set("rcvTelNo", "01012345678"); // 수신전화번호</li>
 *     <li>	param.set("sendTelNo", "0212345678"); // 송신전화번호</li>
 *     <li>	param.set("msg", "SMS를 보냅니다."); // 메시지</li>
 *     <li>	smsService.send(param); // 메시지 전송</li>
 *     <li>} catch (Exception e) {}....</li>
 * </ol>
 * <br/>
 * 사용예 3) 단일 메시지를 여러 사람에게 보낼 경우
 * <ol>
 *     <li>@Autowired private SmsService smsService</li>
 *     <li>try {</li>
 *     <li>	Param param = new Param();</li>
 *     <li>	smsService.setInterval(10); // 10분뒤 전송</li>
 *     <li>	smsService.setSendTelNo("0212345678"); // 송신전화번호</li>
 *     <li>	smsService.setMsg("SMS를 보냅니다."); // 메시지</li>
 *     <li>	String[] receiver = new String[]{"01012345678", "01012345678", "01012345678", "01012345678"}; // 수신전화번호</li>
 *     <li>	smsService.sendMultiReceiver(receiver); // 메시지 전송</li>
 *     <li>} catch (Exception e) {}....</li>
 * </ol>
 * <br/>
 * 사용예 4) 여러 사람에게 같거나 혹은 다른 메시지를 동시에 보낼 경우
 * <ol>
 *     <li>@Autowired private SmsService smsService</li>
 *     <li>try {</li>
 *     <li>	List<Param> msgList = new ArrayList<Param>();</li>
 *     <li>	for (int i = 0; i < 10; i++) {</li>
 *     <li>		Param param = new Param();</li>
 *     <li>		param.set("interval", 10); // 10분뒤 전송</li>
 *     <li>		param.set("rcvTelNo", "01012345678"); // 수신전화번호</li>
 *     <li>		param.set("sendTelNo", "0212345678"); // 송신전화번호</li>
 *     <li>		param.set("msg", "SMS를 보냅니다."); // 메시지</li>
 *     <li>		msgList.add(param);</li>
 *     <li>	}
 *     <li>	smsService.sendMultiMessage(msgList); // 즉시 보내는 경우</li>
 *     <li>	//smsService.sendMultiMessage(msgList, 10); // 10분뒤로 interval 설정하여 보내는 경우</li>
 *     <li>} catch (Exception e) {}....</li>
 * </ol>
 */
@Service
public class SmsService {
    private final Logger logger = Logger.getLogger(getClass());
	
    private final String[] PARAM_NAMES = {"interval", "sendStat", "rcvTelNo", "sendTelNo", "msg", "msgType"};
    private final String[] PARAM_KORNM = {"전송시점(분)", "전송상태", "수신번호", "송신번호", "메시지", "전송형태"};
    private Param PARAMETERS = new Param();
    
	@Autowired
	private	SqlSessionTemplate	smsSession;
	
    /**
     * SMS 전송 파라미터의 디폴트 값 설정(인터발:0, 전송상태:0)
     */
    private void setDefault() {
    	if (PARAMETERS == null) return;
    	
    	if (!PARAMETERS.containsKey("interval") || !Utils.isNotEmpty(PARAMETERS.get("interval")))
    		PARAMETERS.set("interval", "0");
    	
    	if (!PARAMETERS.containsKey("sendStat") || !Utils.isNotEmpty(PARAMETERS.get("sendStat")))
    		PARAMETERS.set("sendStat", "0");
    	
    	if (!PARAMETERS.containsKey("msgType") || !Utils.isNotEmpty(PARAMETERS.get("msgType")))
    		PARAMETERS.set("msgType", "0");
    }
	
    
    /**
     * 전송시간을 현재시간을 기준으로 분단위 interval을 설정한다.
     * @param interval 분단위 interval
     */
    public void setInterval(int interval) {
    	PARAMETERS.set("interval", String.valueOf(interval));
    }
    
    /**
     * 전송상태를 설정한다.
     * @param sendStat 발송상태(0:발송대기, 1:전송완료, 2:결과수신완료)
     */
    public void setSendStat(String sendStat) {
    	PARAMETERS.set("sendStat", sendStat);
    }
    
    /**
     * SMS 수신 핸드폰 번호 설정
     * @param rcvTelNo 수신 핸드폰 번호
     */
    public void setRcvTelNo(String rcvTelNo) {
    	PARAMETERS.set("rcvTelNo", rcvTelNo);
    }
    
    /**
     * SMS 송신자 전화번호를 설정
     * @param sendTelNo 송신자 전화번호
     */
    public void setSendTelNo(String sendTelNo) {
    	PARAMETERS.set("sendTelNo", sendTelNo);
    }
    
    /**
     * 송신 메시지를 설정한다.
     * @param msg 메시지
     */
    public void setMsg(String msg) {
    	PARAMETERS.set("msg", msg);
    }
    
    /**
     * 문자전송 형태를 설정
     * @param msgType 문자전송 형태(0:일반메시지, 1:콜백 URL 메시지)
     */
    public void setMsgType(String msgType) {
    	PARAMETERS.set("msgType", msgType);
    }
    
    public void send(Param param) throws Exception {
    	this.PARAMETERS = param;
    	send();
    }
    
    /**
     * SMS 메시지를 전송한다.
     * @throws Exception
     */
    public void send() throws Exception {
    	this.setDefault();
    	for (int i = 0; i < PARAM_NAMES.length; i++) {
    		if (!PARAMETERS.containsKey(PARAM_NAMES[i])) {
    			logger.warn(PARAM_KORNM[i] + "(" + PARAM_NAMES[i] + ") 항목의 값을 설정하지 않았습니다.[parameters:" + PARAMETERS + "]");
    			return;
    		}
    	}
    	
    	logger.info("SMS 전송정보: " + PARAMETERS);
    	insert(PARAMETERS);
    }
    
    /**
     * 다중의 수신자에게 동일 메시지를 보낸다.
     * 수신자 번호 이외의 항목은 별도 셋팅하여야 한다.
     * @param receivers String[] 수신자 전화번호 목록 배열
     * @throws Exception
     */
    @Transactional(value="smsTransactionManager", readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
    public void sendMultiReceiver(String[] receivers) throws Exception {
    	if (receivers == null || receivers.length < 1) return;
    	
    	for (int i = 0; i < receivers.length; i++) {
    		this.setRcvTelNo(receivers[i]);
    		send();
    	}
    }
    
    /**
     * 다중의 서로다른 메시지를 한꺼번에 즉시 보낸다.
     * @param list List<Param> 보낼 메시지 정보를 담은 list
     * @throws Exception
     */
    @Transactional(value="smsTransactionManager", readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
    public void sendMultiMessage(List<Param> list) throws Exception {
    	sendMultiMessage(list, 0);
    }
    
    /**
     * 다중의 서로다른 메시지를 한꺼번에 보낸다.
     * @param list List<Param> 보낼 메시지 정보를 담은 list
     * @param interval 전송시간을 현재시간에서 분단위 후의 시간으로 입력(자연수)
     * @throws Exception
     */
    @Transactional(value="smsTransactionManager", readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
    public void sendMultiMessage(List<Param> list, int interval) throws Exception {
    	if (list == null || list.size() < 1) return;
    	
    	for (int i = 0; i < list.size(); i++) {
    		this.PARAMETERS = list.get(i);
    		this.setInterval(interval);
    		send();
    	}
    }

    public List<Param> getList(Param param) {
		return smsSession.selectList("com.softworks.springframework.SMS.getList", param);
	}

	public boolean insert(Param param) throws SQLException {
		if (smsSession == null) System.out.println("###########세션 널이다.");
		return 0 < smsSession.insert("com.softworks.springframework.SMS.insert", param);
	}
}
