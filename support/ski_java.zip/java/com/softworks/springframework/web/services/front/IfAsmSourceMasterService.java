package com.softworks.springframework.web.services.front;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;

@Service
public class IfAsmSourceMasterService extends BaseService {

	@Transactional(readOnly=true)
	public int getListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));

		return session.selectOne("com.softworks.springframework.IfAsmSourceMaster.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) {
		return session.selectList("com.softworks.springframework.IfAsmSourceMaster.getList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getExcelList(final Param param) {
		return session.selectList("com.softworks.springframework.IfAsmSourceMaster.getExcelList", param);
	}

	@Transactional(readOnly=true)
	public Param getDetail(Param param) {
		return session.selectOne("com.softworks.springframework.IfAsmSourceMaster.getList", param);
	}

	@Transactional(readOnly=true)
	public Param getDetailTotal(final Param param) {
		return session.selectOne("com.softworks.springframework.IfAsmSourceMaster.getDetailTotal", param);
	}

	@Transactional(readOnly=true)
    public void getListExcel(final Param param, final ModelMap model) throws SQLException {
		String[] category = {
				 "No","년도","App.명","운영자","최초 진단 일자"
				,"총 취약점","최종 진단 일자","총 취약점","진행단계"
				};

		String[] columns = {
        		 "RNUM","TARGET_YEAR","KOR_NAME","OP_NM","DIAG_FR_DATE"
        		 ,"DIAG_FR_SUM","DIAG_TO_DATE","DIAG_TO_SUM","DIAG_TO_RESULT"
        		 };

		int[] colWidth	= { 5, 10, 40, 15, 15
		   		   ,15, 15, 15, 10};

        String excelName = "소스코드진단현황_" + Utils.getTimeStampString("yyyyMMdd");

        model.addAttribute("chapter", "1");
        model.addAttribute("filename", excelName);
        model.addAttribute("category", category);
        model.addAttribute("columns", columns);
        model.addAttribute("columnsWidth", colWidth);
        model.addAttribute("data", this.getExcelList(param));
    }

}
