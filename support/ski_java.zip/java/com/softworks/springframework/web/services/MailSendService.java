package com.softworks.springframework.web.services;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.utils.LawHttpClient;
import com.softworks.springframework.utils.MailContent;
import com.softworks.springframework.utils.Param;

@Service
public class MailSendService extends BaseService {
	private final Logger logger = Logger.getLogger(getClass());
	private	final String HTTS_URL	= Property.getProperty("site.secure.url");
	
	public void setSession(SqlSessionTemplate session) {
		super.session = session;
	}
	
	@SuppressWarnings("unchecked")
	public String sendMail(String ContentNumber, Param mparam) throws Exception {
		
		LawHttpClient httpcl = new LawHttpClient() ;		
		String rMessage = "" ;
		JSONObject jsonObject = new JSONObject();		
		JSONArray ja = new JSONArray() ;	
		if ( mparam.get("bcc") != null)
		{
			String[] bccsb = null ;
			ja.clear();
			bccsb = mparam.get("bcc").split(",");
			for (int i = 0, count = bccsb.length;i < count;i++)
			{
				ja.add(bccsb[i].toString());			
			}				
			jsonObject.put("bcc", ja);			
		}
		if ( mparam.get("cc") != null)
		{
			String[] ccsb = null ;
			ja.clear();
			ccsb = mparam.get("cc").split(",");
			for (int i = 0, count = ccsb.length;i < count;i++)
			{
				ja.add(ccsb[i].toString());			
			}				
			jsonObject.put("cc", ja);			
		}
		if ( mparam.get("sender_email") != null)
		{
			String[] tosb = null ;
			ja.clear();
			tosb = mparam.get("sender_email").split(",");
			for (int i = 0, count = tosb.length;i < count;i++)
			{
				ja.add(tosb[i].toString());			
			}				
			jsonObject.put("to", ja);
		}
		jsonObject.put("body", mparam.get("content"));
		jsonObject.put("subject", mparam.get("title"));
		System.out.println("sendMail ~~~~~~~~~ jsonObject.toString() : "+jsonObject.toString()) ;
		rMessage = httpcl.apiCallUrl("mail", jsonObject.toString(),mparam) ;
		
		return rMessage ;
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void MailLoginsert(Param param) throws SQLException {
		session.insert("com.softworks.springframework.Schedule.mailSendInsert", param);
	}
	
	/*
	 * new mail send
	 * add yik 20190529 
	 * */
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public Param setNotiHist(String noti_id, String recv_emp_no, String email_send_yn,String schd_id, Param contentReplaceParam) throws Exception {
		int deadline_num = 0;
		String noti_cn = "";
		boolean result = false;
		// noti hist 추가
		Param notiContentsInfo = getNotiContentsInfo(noti_id);
		if(notiContentsInfo != null && notiContentsInfo.size() > 0){
			noti_cn = replaceContentsVal(contentReplaceParam, notiContentsInfo.get("NOTI_CN"));
			Param notiInfo = new Param();
			notiInfo.set("noti_id", notiContentsInfo.get("NOTI_ID"));
			notiInfo.set("noti_typ_cd", notiContentsInfo.get("NOTI_TYP_CD"));
			notiInfo.set("noti_emp_no", recv_emp_no);
			notiInfo.set("noti_menu_url", notiContentsInfo.get("NOTI_MENU_URL"));
			notiInfo.set("email_send_yn", email_send_yn);
			notiInfo.set("schd_id", schd_id);
			notiInfo.set("noti_cn", noti_cn);
			notiInfo.set("deadline_num", deadline_num);
			notiInfo.set("noti_id", notiContentsInfo.get("NOTI_ID"));
			result = appendNotiHist(notiInfo);
		}
		if(result){
			return sendMail2(notiContentsInfo.get("MAIL_ID"), recv_emp_no, contentReplaceParam);
		}
		return null;
	}
	
	@SuppressWarnings({ "unchecked" })
	public Param sendMail2(String mailId, String recv_emp_no, Param contentReplaceParam) throws Exception {
		Param rtnParam = new Param();
		Param mparam = new Param();
		try {
			LawHttpClient httpcl = new LawHttpClient();		
			MailContent mContent = new MailContent();
			String rContent = "" ;
			
			// get mail id contents
			Param pUser = new Param();
			pUser.set("user_id", recv_emp_no);
			Param recvInfo = getEmployeeInfo(pUser);
			String recv_mail_addr = recvInfo.get("EMAIL") != null && !recvInfo.get("EMAIL").equals("") ? recvInfo.get("EMAIL") : "";
			String recv_emp_nm = recvInfo.get("NAME");
			
			Param mailInfo = getMailInfo(mailId);
			String mail_title = mailInfo.get("TITLE");
			String content = replaceContentsVal(contentReplaceParam, mailInfo.get("CONTENT"));
			String link_url = mailInfo.get("LINK_URL") != null && !mailInfo.get("LINK_URL").equals("") ? mailInfo.get("LINK_URL") : HTTS_URL;
			
			mparam.set("recv_mail_addr",recv_mail_addr);
			mparam.set("recv_emp_no",recv_emp_no);
			mparam.set("recv_emp_nm",recv_emp_nm);
			mparam.set("mail_typ_cd",mailId);
			mparam.set("mail_title",mail_title);
			mparam.set("content",content);
			mparam.set("link_url",link_url);
			
			rContent = mContent.make2(mparam);
			System.out.println("rcontent:: "+rContent);
			mparam.set("mail_cn",rContent);
			
			
			if(mailInfo.get("ACTIVE_YN").equals("N")){
				String err_msg = "메일이  비활성화 되어있습니다.";
				mparam.set("send_result_cd", "MAIL_ACTIVE_N");
				mparam.set("send_result_msg", err_msg);
				MailLoginsert(mparam);
				rtnParam.set("RESULT_MSG", err_msg);
				rtnParam.set("RESULT_CD", "MAIL_ACTIVE_N");
				rtnParam.set("RESULT", false);
			}else if(recv_mail_addr == null || recv_mail_addr.trim().equals("")){
					String err_msg = "수신자 이메일이 존재하지 않습니다.";
					mparam.set("send_result_cd", "NO_EMAIL");
					mparam.set("send_result_msg", err_msg);
					MailLoginsert(mparam);
					rtnParam.set("RESULT_MSG", err_msg);
					rtnParam.set("RESULT_CD", "NO_EMAIL");
					rtnParam.set("RESULT", false);
			}else{
				JSONObject jsonObject = new JSONObject();		
				JSONArray ja = new JSONArray() ;	
				
				String[] tosb = null ;
				ja.clear();
				tosb = mparam.get("recv_mail_addr").split(",");
				for (int i = 0, count = tosb.length;i < count;i++)
				{
					ja.add(tosb[i].toString());			
				}				
				jsonObject.put("to", ja);
				
				jsonObject.put("body", rContent);
				jsonObject.put("subject", mail_title);
				
				System.out.println("sendMail ~~~~~~~~~ jsonObject.toString() : "+jsonObject.toString()) ;
				
				String isLocal	= Property.getProperty("local.flag");
				if(isLocal.equals("Y")){
					String RESULT_CD = httpcl.RESULT_CD;
					String RESULT_MSG = httpcl.RESULT_MSG;
					mparam.set("send_result_cd", "SUCCESS");
					mparam.set("send_result_msg", "발송 성공 : "+mailId);
					MailLoginsert(mparam);
					rtnParam.set("RESULT_MSG", "SUCCESS");
					rtnParam.set("RESULT_CD", "발송 성공 : "+mailId);
					rtnParam.set("RESULT", true);
				}else{
					httpcl.apiCallUrl2("mail", jsonObject.toString(),mparam);
					String RESULT_CD = httpcl.RESULT_CD;
					String RESULT_MSG = httpcl.RESULT_MSG;
					mparam.set("send_result_cd", RESULT_CD);
					mparam.set("send_result_msg", RESULT_MSG);
					MailLoginsert(mparam);
					rtnParam.set("RESULT_MSG", RESULT_MSG);
					rtnParam.set("RESULT_CD", RESULT_CD);
					rtnParam.set("RESULT", true);
				}
			}
		} catch (Exception e) {
			// TODO: handle finally clause
			mparam.set("recv_mail_addr","error");
			mparam.set("recv_emp_no","error");
			mparam.set("recv_emp_nm","error");
			mparam.set("mail_typ_cd",mailId);
			mparam.set("mail_title","error");
			mparam.set("mail_cn","error");
			mparam.set("link_url","error");
			String err_msg = "이메일 발송 오류";
			mparam.set("send_result_cd", "ERROR");
			mparam.set("send_result_msg", err_msg);
			MailLoginsert(mparam);
			rtnParam.set("RESULT_MSG", err_msg);
			rtnParam.set("RESULT_CD", "ERROR");
			rtnParam.set("RESULT", false);
			return rtnParam;
		}
		return rtnParam;
	}
	
	@SuppressWarnings({ "unchecked" })
	public Param sendMailPrvt(String mailId, String recv_emp_no, Param contentReplaceParam) throws Exception {
		Param rtnParam = new Param();
		Param mparam = new Param();
		try {
			LawHttpClient httpcl = new LawHttpClient();		
			MailContent mContent = new MailContent();
			String rContent = "" ;
			
			// get mail id contents
			Param pUser = new Param();
			pUser.set("user_id", recv_emp_no);
			pUser.set("user_typ_cd", "E");
			Param recvInfo = getUserInfo(pUser);
			String recv_mail_addr = recvInfo.get("EMAIL") != null && !recvInfo.get("EMAIL").equals("") ? recvInfo.get("EMAIL") : "";
			String recv_emp_nm = recvInfo.get("USER_NM");
			
			Param mailInfo = getMailInfo(mailId);
			String mail_title = mailInfo.get("TITLE");
			String content = replaceContentsVal(contentReplaceParam, mailInfo.get("CONTENT"));
			String link_url = mailInfo.get("LINK_URL") != null && !mailInfo.get("LINK_URL").equals("") ? mailInfo.get("LINK_URL") : HTTS_URL;
			
			mparam.set("recv_mail_addr",recv_mail_addr);
			mparam.set("recv_emp_no",recv_emp_no);
			mparam.set("recv_emp_nm",recv_emp_nm);
			mparam.set("mail_typ_cd",mailId);
			mparam.set("mail_title",mail_title);
			mparam.set("content",content);
			mparam.set("link_url",link_url);
			
			rContent = mContent.make2(mparam);
			System.out.println("rcontent:: "+rContent);
			mparam.set("mail_cn",rContent);
			
			
			if(mailInfo.get("ACTIVE_YN").equals("N")){
				String err_msg = "메일이  비활성화 되어있습니다.";
				mparam.set("send_result_cd", "MAIL_ACTIVE_N");
				mparam.set("send_result_msg", err_msg);
				MailLoginsert(mparam);
				rtnParam.set("RESULT_MSG", err_msg);
				rtnParam.set("RESULT_CD", "MAIL_ACTIVE_N");
				rtnParam.set("RESULT", false);
			}else if(recv_mail_addr == null || recv_mail_addr.trim().equals("")){
					String err_msg = "수신자 이메일이 존재하지 않습니다.";
					mparam.set("send_result_cd", "NO_EMAIL");
					mparam.set("send_result_msg", err_msg);
					MailLoginsert(mparam);
					rtnParam.set("RESULT_MSG", err_msg);
					rtnParam.set("RESULT_CD", "NO_EMAIL");
					rtnParam.set("RESULT", false);
			}else{
				JSONObject jsonObject = new JSONObject();		
				JSONArray ja = new JSONArray() ;	
				
				String[] tosb = null ;
				ja.clear();
				tosb = mparam.get("recv_mail_addr").split(",");
				for (int i = 0, count = tosb.length;i < count;i++)
				{
					ja.add(tosb[i].toString());			
				}				
				jsonObject.put("to", ja);
				
				jsonObject.put("body", rContent);
				jsonObject.put("subject", mail_title);
				
				System.out.println("sendMail ~~~~~~~~~ jsonObject.toString() : "+jsonObject.toString()) ;
				
				String isLocal	= Property.getProperty("local.flag");
				if(isLocal.equals("Y")){
					String RESULT_CD = httpcl.RESULT_CD;
					String RESULT_MSG = httpcl.RESULT_MSG;
					mparam.set("send_result_cd", "SUCCESS");
					mparam.set("send_result_msg", "발송 성공 : "+mailId);
					MailLoginsert(mparam);
					rtnParam.set("RESULT_MSG", "SUCCESS");
					rtnParam.set("RESULT_CD", "발송 성공 : "+mailId);
					rtnParam.set("RESULT", true);
				}else{
					httpcl.apiCallUrl2("mail", jsonObject.toString(),mparam);
					String RESULT_CD = httpcl.RESULT_CD;
					String RESULT_MSG = httpcl.RESULT_MSG;
					mparam.set("send_result_cd", RESULT_CD);
					mparam.set("send_result_msg", RESULT_MSG);
					MailLoginsert(mparam);
					rtnParam.set("RESULT_MSG", RESULT_MSG);
					rtnParam.set("RESULT_CD", RESULT_CD);
					rtnParam.set("RESULT", true);
				}
			}
		} catch (Exception e) {
			// TODO: handle finally clause
			mparam.set("recv_mail_addr","error");
			mparam.set("recv_emp_no","error");
			mparam.set("recv_emp_nm","error");
			mparam.set("mail_typ_cd",mailId);
			mparam.set("mail_title","error");
			mparam.set("mail_cn","error");
			mparam.set("link_url","error");
			String err_msg = "이메일 발송 오류";
			mparam.set("send_result_cd", "ERROR");
			mparam.set("send_result_msg", err_msg);
			MailLoginsert(mparam);
			rtnParam.set("RESULT_MSG", err_msg);
			rtnParam.set("RESULT_CD", "ERROR");
			rtnParam.set("RESULT", false);
			return rtnParam;
		}
		return rtnParam;
	}
	
	@Transactional(readOnly=true)
	public Param getEmployeeInfo(final Param param) {
		return session.selectOne("com.softworks.springframework.Employee.getInfo", param);
	}
	
	@Transactional(readOnly=true)
	public Param getUserInfo(final Param param) {
		return session.selectOne("com.softworks.springframework.User.getInfo", param);
	}
	
	@Transactional(readOnly=true)
	public Param getMailInfo(final String mail_id) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.Content.getMailInfo", mail_id);
	}
	
	@Transactional(readOnly=true)
	public Param getNotiContentsInfo(final String noti_id) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.Main.getNotiContentsInfo", noti_id);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public boolean appendNotiHist(final Param param) throws SQLException {
		return 0 < session.insert("com.softworks.springframework.Main.appendNotiHist", param);
	}
	
	
	@SuppressWarnings("unchecked")
	public String replaceContentsVal(final Param replaceParam,String contents){
		HashMap<String, Object> param = (HashMap<String, Object>)replaceParam;
		for (Entry<String, Object> entry: param.entrySet()) {
		    System.out.println("key : " + entry.getKey() + " / value : " + entry.getValue());
		    contents = contents.replaceAll((String)entry.getKey(), (String)entry.getValue());
		}
		System.out.println("replace contents::"+contents);
		return contents;
	}
	
	@SuppressWarnings("unchecked")
	public String contentActivCheck(final Param replaceParam,String contents){
		HashMap<String, Object> param = (HashMap<String, Object>)replaceParam;
		for (Entry<String, Object> entry: param.entrySet()) {
		    System.out.println("key : " + entry.getKey() + " / value : " + entry.getValue());
		    contents = contents.replaceAll((String)entry.getKey(), (String)entry.getValue());
		}
		System.out.println("replace contents::"+contents);
		return contents;
	}
	
}
