package com.softworks.springframework.web.services.backoffice;

import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;
import com.softworks.springframework.web.services.MailSendService;

@Service
public class LawChangeSchedulerService extends BaseService {

	private	final	Logger		logger	= Logger.getLogger(getClass());

	@Autowired
	SchedulerLogService logSvc;

    public void setSession(SqlSessionTemplate session) {
		super.session = session;
		logSvc = new SchedulerLogService();
		logSvc.setSession(session);
	}

    /**
	 * [안내] 국내 법령 변경 안내
	 * target table : T_USER, T_CONTENT , T_MAIL_SEND_HIST, NOTI_HIST
	 * Result : void
     * @throws Exception 
	 */
    public void lawChangeNoti(final Param schdInfo) throws Exception {
    	int batch_cnt = 0;
    	int total_cnt = 0;
		String	err_chk	= "";
		String	rst_msg = "";
		List<Param> lawList = null;
		List<Param> adminList = null;
		Param contentReplaceParam = null;
		Param mailRtnParam = null;
		
		// start log
		schdInfo.set("BATCH_SEQ", logSvc.newAppendBatchHistory(schdInfo));
		
		MailSendService mm = new MailSendService();
		mm.setSession(session);

		try {
			// 변경 내용 가져오기
			lawList = getLawChangeTarget();
			// 포털관리자 가져오기
			adminList = getAdministrator();
			
			if(lawList.size() > 0){
				for (Param adminInfo : adminList) {
					total_cnt = total_cnt + lawList.size();
					
					for (Param lawInfo : lawList) {
						//메일 발송 
						contentReplaceParam = new Param();
						contentReplaceParam.set("#LAW_NM#", lawInfo.get("LAW_NM"));
						contentReplaceParam.set("#CHANGE_TYPE#", lawInfo.get("CHANGE_TYPE"));
						//mailRtnParam = mm.sendMail2("EM10",target.get("EMP_NO"), contentReplaceParam);
						
						String noti_id = schdInfo.get("NOTI_ID");
						String schd_id = schdInfo.get("SCHD_ID");
						mailRtnParam = mm.setNotiHist(noti_id, adminInfo.get("ADMIN_ID"), "Y", schd_id, contentReplaceParam);
						
						System.out.println("RESULT_MSG ============> "+mailRtnParam.get("RESULT_MSG"));
						if(Boolean.parseBoolean(mailRtnParam.get("RESULT"))){
							batch_cnt++;
						}
					}
				}
			}
			
		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		}
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		if (!err_chk.equals("")) {
			schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "N");
			schdInfo.set("BATCH_MSG", err_chk);
			logSvc.updateBatchHistory(schdInfo);
			
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
	    	rst_msg = "변경 법령 총 "+total_cnt + "명 중 " + batch_cnt + "건 알림성 성공!";
	    	schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "Y");
			schdInfo.set("BATCH_MSG", rst_msg);
			logSvc.updateBatchHistory(schdInfo);
	    	logger.info("User append Daily Batch totCnt="+batch_cnt);
	    }
	}
    
	@Transactional(readOnly=true)
	public List<Param> getLawChangeTarget() throws SQLException {
		return session.selectList("com.softworks.springframework.LawChangeScheduler.getLawChangeTarget");
	}
	
	@Transactional(readOnly=true)
	public List<Param> getAdministrator() throws SQLException {
		return session.selectList("com.softworks.springframework.LawChangeScheduler.getAdministrator");
	}
}
