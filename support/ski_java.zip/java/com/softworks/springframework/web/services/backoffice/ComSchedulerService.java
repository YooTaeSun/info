package com.softworks.springframework.web.services.backoffice;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;
import com.softworks.springframework.web.services.MailSendService;
import com.softworks.springframework.web.services.CodeLoaderService.CodeInfo;

@Service
public class ComSchedulerService extends BaseService {

	private	final	Logger		logger	= Logger.getLogger(getClass());

    public void setSession(SqlSessionTemplate session) {
		super.session = session;
	}

    /**
	 * 인사 사용자를 ITS정보보안포탈 사용자로 등록 및 권한 설정
	 * target table : T_USER, T_MENU_USER_AUTHORIZATION
	 * Result : void
     * @throws Exception 
	 */
    public void execUserInterface(final Param schdInfo) throws Exception {
		int 	batch_cnt		= 0;
		String	err_chk			= "";

		try {
			// ITS정보보안포탈 사용자로 미등록된 인사 정보  조회
			int	cnt	= getUnregisteredUserCnt();
			
			if (cnt > 0) {
				// ITS정보보안포탈 사용자로 미등록된 인사 정보  조회하여 사용자로 저장
				insertUnregisteredUser(null);

				// 금일 등록 사용자의 기본 메뉴권한 등록
				inserMenuUserAuthorization(null);
			} else {
				// 넘어온 데이터가 없는경우    
				logger.info("ITS정보보안포탈 사용자로 미등록된 인사정보 데이터가 없습니다.");
			}

		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		}
		
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		
		if (!err_chk.equals("")) {
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
	    	logger.info("User append Daily Batch totCnt="+batch_cnt);
	    }
	}

    /**
	 * 인사/조직 DB 연계
	 * target table : TB_UNITED_EMPLOYEEEXTS
	 * Result : void
     * @throws Exception 
	 */
//    public void execHrInterface(final Param schdInfo) throws Exception {
//		int 	batch_cnt		= 0;
//		int 	duplicateCnt	= 0;
//		String	err_chk			= "";
//
//		Calendar cal = Calendar.getInstance();
//		cal.add(Calendar.DAY_OF_MONTH, -1);
//		String endDt	= Utils.getTimeStampString(cal.getTime(),"yyyyMMdd");
//		String startDt	= Utils.getTimeStampString(cal.getTime(),"yyyyMMdd");
//
//		String ip		= Utils.decript(Property.getProperty("if.hr.ip").toString());
//		String port		= Utils.decript(Property.getProperty("if.hr.port").toString());
//		String sid		= Utils.decript(Property.getProperty("if.hr.sid").toString());
//		String username = Utils.decript(Property.getProperty("if.hr.id").toString());
//		String password = Utils.decript(Property.getProperty("if.hr.pw").toString());
//
//		String driver	= "com.mysql.jdbc.Driver";
//		String url		= "jdbc:mysql://" + ip + ":" + port + "/" + sid;
//
////		System.out.println("***********sourceQuery***");
////		System.out.println(driver);
////		System.out.println(url);
////		System.out.println(username);
////		System.out.println(password);
////		System.out.println("***********rs***");
//
//		Connection conn = null;                                        // null로 초기화 한다.
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//
//		try {
//			Param	param	= new Param();
//			
//			Class.forName(driver); 
//			conn	= DriverManager.getConnection(url,username,password);
//
//			// 인사 정보 조회
//			StringBuffer sql	= new StringBuffer();
//			sql.append("SELECT EMPNO, EMPNAME, JIKUI_CODE, JIKUI, JIKCHAEK_CODE, ");
//			sql.append("JIKCHAEK, ORGID, ORG_NAME, PARENT_ORGID, PARENT_ORG_NAME, ");
//			sql.append("EMAIL, OFFICEPHONE, CELLPHONE, PRIMARY_ORG, TR_YN, ");
//			sql.append("TR_SDATE, TR_EDATE, DP_YN, DP_SDATE, DP_EDATE, ");
//			sql.append("RANK, ORG_TYPE, ORG_CODE, MANAGER_EMAIL, SDATE, ");
//			sql.append("EDATE, USERORDER_ID, OTHERJOB_FLAG, RESIGNATION_YN, RESIGNATION_DATE, ");
//			sql.append("VACATION_YN, VACATION_SDATE, VACATION_EDATE ");
//			sql.append("FROM if_hr_emp ");
//
//			pstmt	= conn.prepareStatement(sql.toString());              
//			rs		= pstmt.executeQuery();
//
//			if (rs != null) {
//				
//				// db 깨끗하게 삭제 후 다시 담는 형태로 변경
//				deleteTbUnitedEmployeeexts(null);
//				
//				while(rs.next()){
//
//					batch_cnt = batch_cnt + 1;
//		
//					/*
//					* 가져온 데이터 돌면서 insert 또는 update 하기 merge 쿼리
//					 */
//					param.set("skcompanycode"        ,rs.getString("SKCOMPANYCODE"        ));
//					param.set("logonid"              ,rs.getString("LOGONID"              ));
//					param.set("skcompanyname"        ,rs.getString("SKCOMPANYNAME"        ));
//					param.set("regularityyn"         ,rs.getString("REGULARITYYN"         ));
//					param.set("internetmailaddress"  ,rs.getString("INTERNETMAILADDRESS"  ));
//					param.set("hiredt"               ,rs.getString("HIREDT"               ));
//					param.set("retiredt"             ,rs.getString("RETIREDT"             ));
//					param.set("givenname_ko"         ,rs.getString("GIVENNAME_KO"         ));
//					param.set("familyname_ko"        ,rs.getString("FAMILYNAME_KO"        ));
//					param.set("givenname_en"         ,rs.getString("GIVENNAME_EN"         ));
//					param.set("familyname_en"        ,rs.getString("FAMILYNAME_EN"        ));
//					param.set("teamcodemain"         ,rs.getString("TEAMCODEMAIN"         ));
//					param.set("teamnamemain"         ,rs.getString("TEAMNAMEMAIN"         ));
//					param.set("empclasscode"         ,rs.getString("EMPCLASSCODE"         ));
//					param.set("empclassname"         ,rs.getString("EMPCLASSNAME"         ));
//					param.set("officetelno"          ,rs.getString("OFFICETELNO"          ));
//					param.set("officetelno2"         ,rs.getString("OFFICETELNO2"         ));
//					param.set("mobileno"             ,rs.getString("MOBILENO"             ));
//					param.set("blogonid"             ,rs.getString("BLOGONID"             ));
//					param.set("employeeno"           ,rs.getString("EMPLOYEENO"           ));
//					param.set("bemployeeno"          ,rs.getString("BEMPLOYEENO"          ));
//					param.set("displayyn"            ,rs.getString("DISPLAYYN"            ));
//					param.set("worktypecode"         ,rs.getString("WORKTYPECODE"         ));
//					param.set("worktypename"         ,rs.getString("WORKTYPENAME"         ));
//					param.set("promotiondt"          ,rs.getString("PROMOTIONDT"          ));
//					param.set("retiredelaydt"        ,rs.getString("RETIREDELAYDT"        ));
//					param.set("givenname_zh"         ,rs.getString("GIVENNAME_ZH"         ));
//					param.set("familyname_zh"        ,rs.getString("FAMILYNAME_ZH"        ));
//					param.set("languagecode"         ,rs.getString("LANGUAGECODE"         ));
//					param.set("languagename"         ,rs.getString("LANGUAGENAME"         ));
//					param.set("countrycode"          ,rs.getString("COUNTRYCODE"          ));
//					param.set("countryname"          ,rs.getString("COUNTRYNAME"          ));
//					param.set("titlecode"            ,rs.getString("TITLECODE"            ));
//					param.set("titlename"            ,rs.getString("TITLENAME"            ));
//					param.set("responsibilitycode"   ,rs.getString("RESPONSIBILITYCODE"   ));
//					param.set("responsibilityname"   ,rs.getString("RESPONSIBILITYNAME"   ));
//					param.set("dutycode"             ,rs.getString("DUTYCODE"             ));
//					param.set("dutyname"             ,rs.getString("DUTYNAME"             ));
//					param.set("teamabbreviation"     ,rs.getString("TEAMABBREVIATION"     ));
//					param.set("teamcodedispatch"     ,rs.getString("TEAMCODEDISPATCH"     ));
//					param.set("teamnamedispatch"     ,rs.getString("TEAMNAMEDISPATCH"     ));
//					param.set("teamdispatch"         ,rs.getString("TEAMDISPATCH"         ));
//					param.set("sitelargeclscode"     ,rs.getString("SITELARGECLSCODE"     ));
//					param.set("sitelargeclsname"     ,rs.getString("SITELARGECLSNAME"     ));
//					param.set("sitesmallclscode"     ,rs.getString("SITESMALLCLSCODE"     ));
//					param.set("sitesmallclsname"     ,rs.getString("SITESMALLCLSNAME"     ));
//					param.set("workarealargeclscode" ,rs.getString("WORKAREALARGECLSCODE" ));
//					param.set("workarealargeclsname" ,rs.getString("WORKAREALARGECLSNAME" ));
//					param.set("workareamiddleclscode",rs.getString("WORKAREAMIDDLECLSCODE"));
//					param.set("workareamiddleclsname",rs.getString("WORKAREAMIDDLECLSNAME"));
//					param.set("workareasmallclscode" ,rs.getString("WORKAREASMALLCLSCODE" ));
//					param.set("workareasmallclsname" ,rs.getString("WORKAREASMALLCLSNAME" ));
//					param.set("faxno"                ,rs.getString("FAXNO"                ));
//					param.set("sex"                  ,rs.getString("SEX"                  ));
//					param.set("birthday"             ,rs.getString("BIRTHDAY"             ));
//					param.set("workareafloor"        ,rs.getString("WORKAREAFLOOR"        ));
//					param.set("workareadetail"       ,rs.getString("WORKAREADETAIL"       ));
//					param.set("workareacode"         ,rs.getString("WORKAREACODE"         ));
//					param.set("workareaname"         ,rs.getString("WORKAREANAME"         ));
//
//					// 최종 값가져온 후 merge 쿼리 실행 : 최종값으로 insert되거나 merge됨
//					try {
//						insertTbUnitedEmployeeexts(param);
//					} catch (Exception e) {
//						duplicateCnt = duplicateCnt + 1;
//						logger.error("HR EMP Daily batch 오류", e);
//					}
//				}
//			} else {
//				// 넘어온 데이터가 없는경우
//				logger.error("HR EMP 인사정보 데이터가 없습니다.");
//			}
//
//			rs.close();
//			pstmt.close();
//			
//			pstmt	= null;
//			rs		= null;
//
//			// 조직 정보 조회
//			sql	= new StringBuffer();
//			sql.append("SELECT GROUP_ID, GROUP_NAME, PARENTGROUP_ID, GROUPORDER_ID FROM if_hr_org ");
//			
//			pstmt	= conn.prepareStatement(sql.toString());              
//			rs		= pstmt.executeQuery();
//	
//			if (rs != null) {
//				
//				// db 깨끗하게 삭제 후 다시 담는 형태로 변경
//				deleteTbUnitedOrganizationexts(null);
//				
//				while(rs.next()){
//		
//					// 가져온 데이터 돌면서 insert 또는 update 하기 merge 쿼리
//
//					batch_cnt = batch_cnt + 1;
//
//					param.set("skcompanycode"       ,rs.getString("SKCOMPANYCODE"       ));
//					param.set("teamcodemain"        ,rs.getString("TEAMCODEMAIN"        ));
//					param.set("teamnamemain"        ,rs.getString("TEAMNAMEMAIN"        ));
//					param.set("skcompanyname"       ,rs.getString("SKCOMPANYNAME"       ));
//					param.set("teamnamemain_ko"     ,rs.getString("TEAMNAMEMAIN_KO"     ));
//					param.set("teamnamemain_en"     ,rs.getString("TEAMNAMEMAIN_EN"     ));
//					param.set("teamnamemain_zh"     ,rs.getString("TEAMNAMEMAIN_ZH"     ));
//					param.set("teamcodeparent"      ,rs.getString("TEAMCODEPARENT"      ));
//					param.set("teamnameparent"      ,rs.getString("TEAMNAMEPARENT"      ));
//					param.set("sortorder"           ,rs.getString("SORTORDER"           ));
//					param.set("createddt"           ,rs.getString("CREATEDDT"           ));
//					param.set("terminateddt"        ,rs.getString("TERMINATEDDT"        ));
//					param.set("languagecode"        ,rs.getString("LANGUAGECODE"        ));
//					param.set("languagename"        ,rs.getString("LANGUAGENAME"        ));
//					param.set("teamchiefempno"      ,rs.getString("TEAMCHIEFEMPNO"      ));
//					param.set("teamchiefelogonid"   ,rs.getString("TEAMCHIEFELOGONID"   ));
//					param.set("teamabbreviation"    ,rs.getString("TEAMABBREVIATION"    ));
//					param.set("teamlevelcode"       ,rs.getString("TEAMLEVELCODE"       ));
//					param.set("teamlevelname"       ,rs.getString("TEAMLEVELNAME"       ));
//					param.set("sitelargeclscode"    ,rs.getString("SITELARGECLSCODE"    ));
//					param.set("sitelargeclsname"    ,rs.getString("SITELARGECLSNAME"    ));
//					param.set("sitesmallclscode"    ,rs.getString("SITESMALLCLSCODE"    ));
//					param.set("sitesmallclsname"    ,rs.getString("SITESMALLCLSNAME"    ));
//					param.set("mastercostcentercode",rs.getString("MASTERCOSTCENTERCODE"));
//					param.set("mastercostcentername",rs.getString("MASTERCOSTCENTERNAME"));
//					param.set("displayyn"           ,rs.getString("DISPLAYYN"           ));
//					param.set("regularityyn"        ,rs.getString("REGULARITYYN"        ));
//
//					// 최종 값가져온 후 merge 쿼리 실행 : 최종값으로 insert되거나 merge됨
//					try {
//						insertTbUnitedOrganizationexts(param);
//					} catch (Exception e) {
//						duplicateCnt = duplicateCnt + 1;
//						logger.error("HR ORG Daily batch 오류", e);
//					}
//				}
//			} else {
//				// 넘어온 데이터가 없는경우
//				logger.error("HR EMP 조직정보 데이터가 없습니다.");
//			}
//				
//
//		} catch (Exception e) {
//			err_chk = e.toString();
//			e.printStackTrace();
//		} finally {
//			if(rs != null) try{rs.close();}catch(SQLException sqle){}            // Resultset 객체 해제
//			if(pstmt != null) try{pstmt.close();}catch(SQLException sqle){}   // PreparedStatement 객체 해제
//			if(conn != null) try{conn.close();}catch(SQLException sqle){}   // Connection 해제
//		}
//		
//		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
//		
//		if (!err_chk.equals("")) {
//			Exception e = new Exception(err_chk);
//			throw e;	 // 예외를 발생시킴
//	    } else {
//	    	logger.info("HR EMP, ORG Daily Batch "+startDt+" ~ "+endDt+" totCnt="+batch_cnt+" dupCnt="+duplicateCnt);
//	    }
//	}

    /*
     * 연동 활성된 스케쥴 목록 조회
     */
	public List<Param> getComSchdInfoList() throws SQLException {
    	Param param = new Param();
    	return session.selectList("com.softworks.springframework.ComSchedule.getComSchdInfoList", param);
    }

    /*
     * ITS정보보안포탈 사용자로 미등록된 인사 정보 수 조회
     */
	public int getUnregisteredUserCnt() throws SQLException {
    	Param param = new Param();
    	return (Integer)session.selectOne("com.softworks.springframework.ComSchedule.getUnregisteredUserCnt", param);
    }

    /*
     * ITS정보보안포탈 사용자로 미등록된 인사 정보  조회하여 사용자로 저장
     */
	@Transactional(readOnly=true)
	public void insertUnregisteredUser(final Param param) {
		session.update("com.softworks.springframework.ComSchedule.insertUnregisteredUser", param);
	}

    /*
     * 금일 등록 사용자의 기본 메뉴권한 등록
     */
	@Transactional(readOnly=true)
	public void inserMenuUserAuthorization(final Param param) {
		session.update("com.softworks.springframework.ComSchedule.inserMenuUserAuthorization", param);
	}

    /*
     * HR 인사 정보 저장
     */
	@Transactional(readOnly=true)
	public void insertTbUnitedEmployeeexts(final Param param) {
		session.insert("com.softworks.springframework.ComSchedule.insertTbUnitedEmployeeexts", param);
	}

    /*
     * HR 인사 Interface Table 비움
     */
	@Transactional(readOnly=true)
	public void deleteTbUnitedEmployeeexts(final Param param) {
		session.delete("com.softworks.springframework.ComSchedule.deleteTbUnitedEmployeeexts", param);
	}

    /*
     * HR 조직 정보 저장
     */
	@Transactional(readOnly=true)
	public void insertTbUnitedOrganizationexts(final Param param) {
		session.insert("com.softworks.springframework.ComSchedule.insertTbUnitedOrganizationexts", param);
	}

    /*
     * HR 조직 Interface Table 비움
     */
	@Transactional(readOnly=true)
	public void deleteTbUnitedOrganizationexts(final Param param) {
		session.delete("com.softworks.springframework.ComSchedule.deleteTbUnitedOrganizationexts", param);
	}
	
	@Transactional(readOnly=true)
	public void appendBatchHistory(final Param param) {
		session.insert("com.softworks.springframework.Schedule.appendBatchHistory", param);
	}
	
	@Transactional(readOnly=true)
	public void updateBatchHistory(final Param param) {
		session.insert("com.softworks.springframework.Schedule.updateBatchHistory", param);
	}
}
