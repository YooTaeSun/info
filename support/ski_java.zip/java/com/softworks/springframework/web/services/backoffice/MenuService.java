package com.softworks.springframework.web.services.backoffice;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;

@Service
public class MenuService extends BaseService {

	@Transactional(readOnly=true)
	public int getListCount(Param param) {
		param.set("pageSize", param.getInt("pageSize", DEFAULT_PAGE_SIZE));
		
		return session.selectOne("com.softworks.springframework.Menu.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(Param param) {
		return session.selectList("com.softworks.springframework.Menu.getList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getAllMenuAuthList(Param param) {
		return session.selectList("com.softworks.springframework.Menu.getAllMenuAuthList", param);
	}

	@Transactional(readOnly=true)
	public Param getInfo(String menu_id) {
		return session.selectOne("com.softworks.springframework.Menu.getInfo", menu_id);
	}
	
	public boolean insert(Param param) throws SQLException {
		return 0 < session.insert("com.softworks.springframework.Menu.insert", param);
	}
	
	public boolean update(Param param) throws SQLException {
		return 0 < session.update("com.softworks.springframework.Menu.update", param);
	}

	public boolean delete(Param param) throws SQLException {
		return 0 < session.update("com.softworks.springframework.Menu.delete", param);
	}

	public boolean inserMenuUserAuthorization(Param param) throws SQLException {
		return 0 < session.update("com.softworks.springframework.Menu.inserMenuUserAuthorization", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getMethodList(String id) {
		return session.selectList("com.softworks.springframework.Menu.getMethodList", id);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void setMenuMethod(Param param) throws Exception {
		String[] type	= param.getValues("type");
		String[] method	= param.getValues("method");
		
		if(type.length != method.length) throw new Exception("type 항목의 개수와 method항목의 개수가 일치하지 않습니다.");

		session.delete("com.softworks.springframework.Menu.clearMenuMethod", param.get("menu_id"));

		Param	info	= new Param();
				info.set("menu_id", param.get("menu_id"));
		for(int i = 0, count = type.length;i < count;i++) {
			if("".equals(method[i])) continue;
			
			info.set("type", type[i]);
			info.set("method", method[i]);
			session.insert("com.softworks.springframework.Menu.insertMenuMethod", info);
		}
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void setGroupMenuAuth(String group, String[] id, String[] auth) throws Exception {
		if(id.length != auth.length) throw new Exception("menu_id 항목의 개수와 menu_auth 항목의 개수가 일치하지 않습니다.");
	
		Param	param	= new Param();
				param.set("group", group);
		
		session.delete("com.softworks.springframework.Menu.deleteGroupAuth", group);

		for(int i = 0, cnt = id.length;i < cnt;i++) {
			param.set("menu_id", id[i]);
			if(auth[i].equals("0"))continue;
			
	//		param.set("umask", Utils.fillCharacter(auth[i], "0", 4, true));
	//		if("0000".equals(param.get("umask"))) continue;

			session.insert("com.softworks.springframework.Menu.insertGroupAuth", param);
		}
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void setUserMenuAuth(String type, String userId, String[] id, String[] auth, String[] old) throws Exception {
		if(id.length != auth.length) throw new Exception("menu_id 항목의 개수와 menu_auth 항목의 개수가 일치하지 않습니다.");
		
		Param	param	= new Param();
		param.set("user_id", userId);
		param.set("type", type);
		
		session.delete("com.softworks.springframework.Menu.deleteUserAuth", param);

		StringBuffer sb = new StringBuffer();
		String selAuth	= "";
		String hanAuth	= "";
		String selOld	= "";
		String hanOld	= "";
		
		for(int i = 0, cnt = id.length;i < cnt;i++) {
			param.set("menu_id", id[i]);
			//param.set("umask", Utils.fillCharacter(auth[i], "0", 4, true));
			param.set("umask", auth[i]);

			selAuth	= auth[i].substring(0, 1);
			hanAuth	= auth[i].substring(1);
			selOld	= old[i].substring(0, 1);
			hanOld	= old[i].substring(1);

			if (!selAuth.equals(selOld)) {
				if (selAuth.equals("S")) {
					sb.append(id[i]).append(" 메뉴 조회 권한 부여.\n");
				} else if (selAuth.equals("N")) {
					sb.append(id[i]).append(" 메뉴 조회 권한 회수.\n");
				}
			}

			if (!hanAuth.equals(hanOld)) {
				if (hanAuth.equals("H")) {
					sb.append(id[i]).append(" 메뉴 처리 권한 부여.\n");
				} else if (hanAuth.equals("N")) {
					sb.append(id[i]).append(" 메뉴 처리 권한 회수.\n");
				}
			}

			if("NN".equals(param.get("umask"))) continue;

			session.insert("com.softworks.springframework.Menu.insertUserAuth", param);
		}

		if (type.equals("B")) {
			param.set("admin_id", userId);
		}

		int seq = (Integer)session.selectOne("com.softworks.springframework.UserAuthChgHist.getSeq", param);
		param.set("seq", seq);
		session.update("com.softworks.springframework.UserAuthChgHist.insert", param);
		param.set("change_cont", sb.toString());
		session.update("com.softworks.springframework.UserAuthChgHist.updateChangeCont", param);
	}

}