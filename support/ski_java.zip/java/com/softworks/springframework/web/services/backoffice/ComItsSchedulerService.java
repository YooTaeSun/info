package com.softworks.springframework.web.services.backoffice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;

@Service
public class ComItsSchedulerService extends BaseService {

	private	final	Logger		logger	= Logger.getLogger(getClass());

	@Autowired
	SchedulerLogService logSvc;

    public void setSession(SqlSessionTemplate session) {
		super.session = session;
		logSvc = new SchedulerLogService();
		logSvc.setSession(session);
	}

    /**
	 * ITS 보안예외정책 처리결과 연계
	 * target table : IF_ITS_OM0071_T, IF_ITS_OM0071, EXCEPT_POLICY_PROC_RESULT
	 * Result : void
     * @throws Exception 
	 */
    public void execIfItsOm0071(final Param schdInfo) throws Exception {
    	int		total_cnt		= 0;
		int 	batch_cnt		= 0;
		int 	result_cnt		= 0;
		int		duplicateCnt	= 0;
		String	err_chk			= "";
		String	rst_msg			= "";

		// start log
		schdInfo.set("BATCH_SEQ", logSvc.newAppendBatchHistory(schdInfo));

		Calendar cal = Calendar.getInstance();
		String endDt	= Utils.getTimeStampString(cal.getTime(),"yyyy-MM-dd HH:mm:ss");

		cal.add(Calendar.HOUR_OF_DAY, -1);
		String startDt	= Utils.getTimeStampString(cal.getTime(),"yyyy-MM-dd HH:mm:ss");

		//startDt = "2019-06-12 08:00:00";

		String ip		= Property.getProperty("if.its.ip").toString();
		String port		= Property.getProperty("if.its.port").toString();
		String sid		= Property.getProperty("if.its.sid").toString();
		String username = Property.getProperty("if.its.id").toString();
		String password = Property.getProperty("if.its.pw").toString();

		String driver	= "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String url		= "jdbc:sqlserver://" + ip + ":" + port + ";databaseName=" + sid;
//		String driver	= "oracle.jdbc.driver.OracleDriver";
//		String url		= "jdbc:oracle:thin:@" + ip + ":" + port + ":" + sid;

//		System.out.println("***********sourceQuery***");
//		System.out.println(driver);
//		System.out.println(url);
//		System.out.println(username);
//		System.out.println(password);
//		System.out.println("***********rs***");

		Connection conn = null;                                        // null로 초기화 한다.
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			Class.forName(driver); 
			conn	= DriverManager.getConnection(url,username,password);

			// 인사 정보 조회
			StringBuffer sql	= new StringBuffer();
			sql.append("SELECT ");
			sql.append("	CUST_CO_CLL_NO         , ");
			sql.append("	CLL_CUST_CO_CD         , ");
			sql.append("	CLL_CUST_CO_BUSI_UNT_CD, ");
			sql.append("	CUST_CO_APV_NO         , ");
			sql.append("	CLL_ENO                , ");
			sql.append("	USE_ENO                , ");
			sql.append("	MNGM_ENO               , ");
			sql.append("	OS_CLL_TP_CD           , ");
			sql.append("	OS_CLL_KIND_CD         , ");
			sql.append("	CLL_DT                 , ");
			sql.append("	HOPE_DT                , ");
			sql.append("	STRT_DT                , ");
			sql.append("	END_DT                 , ");
			sql.append("	ICE_SVC_DS_CD          , ");
			sql.append("	SW_SVC_DS_CD           , ");
			sql.append("	RTRV_EQP_TAG_NO        , ");
			sql.append("	INTL_PLAC_DESC         , ");
			sql.append("	CLL_RSN_BDWN           , ");
			sql.append("	CLL_TITL               , ");
			sql.append("	CLL_CNTN               , ");
			sql.append("	CLL_IF_DTM             , ");
			sql.append("	AGCY_RGS_YN            , ");
			sql.append("	EDMS_FOLDER_ID         , ");
			sql.append("	PRC_YN                 , ");
			sql.append("	OS_CLL_NO              , ");
			sql.append("	RGSR_EMP_ID            , ");
			sql.append("	RGS_DTM                , ");
			sql.append("	LST_UPDR_EMP_ID        , ");
			sql.append("	LST_UPDT_DTM           , ");
			sql.append("	APV_ENO                , ");
			sql.append("	APV_EMP_NM             , ");
			sql.append("	APV_TLNO               , ");
			sql.append("	APV_EML_ADDR           , ");
			sql.append("	PRC_CUST_CO_BUSI_UNT_CD, ");
			sql.append("	PRC_CUST_CO_CD         , ");
			sql.append("	IF_YN                  , ");
			sql.append("	IF_STATUS_CD           , ");
			sql.append("	IF_STATUS_CODE         , ");
			sql.append("	IF_MSG                 , ");
			sql.append("	CREATE_DT              , ");
			sql.append("	UPDATE_DT                ");
			sql.append("FROM VW_SP_IF_OM0071 ");
			sql.append("WHERE CREATE_DT BETWEEN CONVERT(DATETIME, ?) AND CONVERT(DATETIME, ?) ");
			//sql.append("WHERE CREATE_DT BETWEEN TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS') AND TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS') ");
			sql.append("AND IF_YN = 'Y' ");
			sql.append("AND CLL_CNTN LIKE '%App. 코드:%' ");
			sql.append("ORDER BY CREATE_DT ");

			pstmt	= conn.prepareStatement(sql.toString());
			pstmt.setString(1, startDt);
			pstmt.setString(2, endDt);

			rs		= pstmt.executeQuery();

			if (rs != null) {
				while (rs.next()) {
					total_cnt = total_cnt + 1;

					Param	param	= new Param();
					param.set("cust_co_cll_no"         , rs.getString("CUST_CO_CLL_NO"         ));
					param.set("cll_cust_co_cd"         , rs.getString("CLL_CUST_CO_CD"         ));
					param.set("cll_cust_co_busi_unt_cd", rs.getString("CLL_CUST_CO_BUSI_UNT_CD"));
					param.set("cust_co_apv_no"         , rs.getString("CUST_CO_APV_NO"         ));
					param.set("cll_eno"                , rs.getString("CLL_ENO"                ));
					param.set("use_eno"                , rs.getString("USE_ENO"                ));
					param.set("mngm_eno"               , rs.getString("MNGM_ENO"               ));
					param.set("os_cll_tp_cd"           , rs.getString("OS_CLL_TP_CD"           ));
					param.set("os_cll_kind_cd"         , rs.getString("OS_CLL_KIND_CD"         ));
					param.set("cll_dt"                 , rs.getString("CLL_DT"                 ));
					param.set("hope_dt"                , rs.getString("HOPE_DT"                ));
					param.set("strt_dt"                , rs.getString("STRT_DT"                ));
					param.set("end_dt"                 , rs.getString("END_DT"                 ));
					param.set("ice_svc_ds_cd"          , rs.getString("ICE_SVC_DS_CD"          ));
					param.set("sw_svc_ds_cd"           , rs.getString("SW_SVC_DS_CD"           ));
					param.set("rtrv_eqp_tag_no"        , rs.getString("RTRV_EQP_TAG_NO"        ));
					param.set("intl_plac_desc"         , rs.getString("INTL_PLAC_DESC"         ));
					param.set("cll_rsn_bdwn"           , rs.getString("CLL_RSN_BDWN"           ));
					param.set("cll_titl"               , rs.getString("CLL_TITL"               ));
					param.set("cll_cntn"               , rs.getString("CLL_CNTN"               ));
					param.set("cll_if_dtm"             , rs.getString("CLL_IF_DTM"             ));
					param.set("agcy_rgs_yn"            , rs.getString("AGCY_RGS_YN"            ));
					param.set("edms_folder_id"         , rs.getString("EDMS_FOLDER_ID"         ));
					param.set("prc_yn"                 , rs.getString("PRC_YN"                 ));
					param.set("os_cll_no"              , rs.getString("OS_CLL_NO"              ));
					param.set("rgsr_emp_id"            , rs.getString("RGSR_EMP_ID"            ));
					param.set("rgs_dtm"                , rs.getString("RGS_DTM"                ));
					param.set("lst_updr_emp_id"        , rs.getString("LST_UPDR_EMP_ID"        ));
					param.set("lst_updt_dtm"           , rs.getString("LST_UPDT_DTM"           ));
					param.set("apv_eno"                , rs.getString("APV_ENO"                ));
					param.set("apv_emp_nm"             , rs.getString("APV_EMP_NM"             ));
					param.set("apv_tlno"               , rs.getString("APV_TLNO"               ));
					param.set("apv_eml_addr"           , rs.getString("APV_EML_ADDR"           ));
					param.set("prc_cust_co_busi_unt_cd", rs.getString("PRC_CUST_CO_BUSI_UNT_CD"));
					param.set("prc_cust_co_cd"         , rs.getString("PRC_CUST_CO_CD"         ));
					param.set("if_yn"                  , rs.getString("IF_YN"                  ));
					param.set("if_status_cd"           , rs.getString("IF_STATUS_CD"           ));
					param.set("if_status_code"         , rs.getString("IF_STATUS_CODE"         ));
					param.set("if_msg"                 , rs.getString("IF_MSG"                 ));
					param.set("create_dt"              , rs.getString("CREATE_DT"              ));
					param.set("update_dt"              , rs.getString("UPDATE_DT"              ));
					param.set("if_dt"                  , endDt);

					String	cll_cntn	= rs.getString("CLL_CNTN");
					int		idx1		= cll_cntn.indexOf("App. 코드:") + 8;
					//int		idx2		= cll_cntn.indexOf("\r\n", idx1);
					int		idx2		= cll_cntn.indexOf("\n", idx1);
					//logger.info("------------------cll_cntn : "+ cll_cntn);
					//logger.info("------------------idx1 : "+ idx1 + ", idx2 : "+ idx2);

					if (idx1 > 0 && idx2 > idx1) {
						param.set("secu_app_no", cll_cntn.substring(idx1, idx2));
					} else {
						param.set("secu_app_no", "-");
					}
					//logger.info("------------------param : "+ param.toString());

					try {
						insertTemp(param);
					} catch (Exception e) {
						e.printStackTrace();
						duplicateCnt = duplicateCnt + 1;
					}
				}

				Param	param	= new Param();
				param.set("if_dt", endDt);
				
				batch_cnt	= insert(param);
				
				result_cnt	= insertResult(param);
			} else {
				// 넘어온 데이터가 없는경우
				logger.info("ITS VW_SP_IF_OM0071 데이터가 없습니다.");
			}

			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		} finally {
			if(rs != null) try{rs.close();}catch(SQLException sqle){}         // Resultset 객체 해제
			if(pstmt != null) try{pstmt.close();}catch(SQLException sqle){}   // PreparedStatement 객체 해제
			if(conn != null) try{conn.close();}catch(SQLException sqle){}     // Connection 해제
		}
		
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		if (!err_chk.equals("")) {
			schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "N");
			schdInfo.set("BATCH_MSG", err_chk);
			logSvc.updateBatchHistory(schdInfo);
			
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
	    	if(batch_cnt > 0){
	    		rst_msg = "VW_SP_IF_OM0071 총 "+total_cnt + "건 중 연계 " + batch_cnt + "건, 처리결과 " + result_cnt + "건, 중복 " + duplicateCnt + "건이 처리 되었습니다.";
	    	}else{
	    		rst_msg = "가져올 VW_SP_IF_OM0071 데이터가 없습니다.";
	    	}
	    	schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "Y");
			schdInfo.set("BATCH_MSG", rst_msg);
			logSvc.updateBatchHistory(schdInfo);
			
	    	logger.info("VW_SP_IF_OM0071 Daily Batch totCnt="+batch_cnt);
	    }
    }

    /**
	 * ITS 기초 데이터 연계
	 * Result : void
     * @throws Exception 
	 */
    public void execIfItsInterface(final Param schdInfo) throws Exception {
    	execIfItsSkeHwinventory(schdInfo);
    	execIfItsSkeSwview(schdInfo);
    	execIfItsMstAppl(schdInfo);
    	execIfItsMstApplDetail(schdInfo);
    	execIfItsMstApplSecurity(schdInfo);
    	execIfItsEamIntfcAmsMaster(schdInfo);
    }

    /**
	 * ITS 기초 데이터 연계
	 * target table : IF_ITS_SKE_HWINVENTORY
	 * Result : void
     * @throws Exception 
	 */
    public void execIfItsSkeHwinventory(final Param schdInfo) throws Exception {
		int 	batch_cnt	= 0;
		int 	fail_cnt	= 0;
		String	err_chk		= "";
		String	rst_msg		= "";

		// start log
		schdInfo.set("BATCH_SEQ", logSvc.newAppendBatchHistory(schdInfo));

		Calendar cal = Calendar.getInstance();
		String ifDt	= Utils.getTimeStampString(cal.getTime(),"yyyy-MM-dd HH:mm:ss");

		String ip		= Property.getProperty("if.its.ip").toString();
		String port		= Property.getProperty("if.its.port").toString();
		String sid		= Property.getProperty("if.its.sid").toString();
		String username = Property.getProperty("if.its.id").toString();
		String password = Property.getProperty("if.its.pw").toString();

		String driver	= "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String url		= "jdbc:sqlserver://" + ip + ":" + port + ";databaseName=" + sid;

		Connection conn = null;                                        // null로 초기화 한다.
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			Class.forName(driver); 
			conn	= DriverManager.getConnection(url,username,password);

			StringBuffer sql	= new StringBuffer();
			sql.append("SELECT ");
			sql.append("	TAGNO    , ");
			sql.append("	ADMINID  , ");
			sql.append("	OA       , ");
			sql.append("	USERNAME , ");
			sql.append("	MODELNAME  ");
			sql.append("FROM VW_SP_SKE_HWINVENTORY ");
			sql.append("ORDER BY TAGNO ");

			pstmt	= conn.prepareStatement(sql.toString());
			rs		= pstmt.executeQuery();

			if (rs != null) {
				// 기존 데이터 Truncate
				deleteIstgSkeHwinventory(null);

				List<Param> dataList = new ArrayList<Param>();

				while (rs.next()) {
					batch_cnt = batch_cnt + 1;

					Param	param	= new Param();
					param.set("tagno"    , rs.getString("TAGNO"    ));
					param.set("adminid"  , rs.getString("ADMINID"  ));
					param.set("oa"       , rs.getString("OA"       ));
					param.set("username" , rs.getString("USERNAME" ));
					param.set("modelname", rs.getString("MODELNAME"));
					param.set("if_dt"    , ifDt);

					if ((batch_cnt % 2000) > 0) {
						dataList.add(param);
					} else {
						try {
							Param inParam = new Param();
							inParam.set("dataList", dataList);

							insertIstgSkeHwinventory(inParam);
						} catch (Exception e) {
							e.printStackTrace();
							fail_cnt = fail_cnt + dataList.size();
						}

						dataList = new ArrayList<Param>();
					}
				}

				if (dataList != null && dataList.size() > 0) {
					try {
						Param inParam = new Param();
						inParam.set("dataList", dataList);

						insertIstgSkeHwinventory(inParam);
					} catch (Exception e) {
						e.printStackTrace();
						fail_cnt = fail_cnt + dataList.size();
					}
				}
			} else {
				// 넘어온 데이터가 없는경우
				logger.info("ITS VW_SP_SKE_HWINVENTORY 데이터가 없습니다.");
			}

			rs.close();
			pstmt.close();

			// 임시 저장소에 저장된 데이타가 있는 테입ㄹ만 실테이블로 데이터 이동
			int cnt = getIstgHwinventoryTotalCnt(null);

			if (cnt > 0) {
				deleteSkeHwinventory(null);
				insertSkeHwinventory(null);
			}

		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		} finally {
			if(rs != null) try{rs.close();}catch(SQLException sqle){}         // Resultset 객체 해제
			if(pstmt != null) try{pstmt.close();}catch(SQLException sqle){}   // PreparedStatement 객체 해제
			if(conn != null) try{conn.close();}catch(SQLException sqle){}     // Connection 해제
		}
		
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		if (!err_chk.equals("")) {
			schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "N");
			schdInfo.set("BATCH_MSG", err_chk);
			logSvc.updateBatchHistory(schdInfo);
			
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
			if(batch_cnt > 0){
	    		rst_msg = "VW_SP_SKE_HWINVENTORY 연계 총 " + batch_cnt + " (실패:" + fail_cnt + ")건이 처리 되었습니다.";
	    	}else{
	    		rst_msg = "가져올 VW_SP_SKE_HWINVENTORY 데이터가 없습니다.";
	    	}
	    	schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "Y");
			schdInfo.set("BATCH_MSG", rst_msg);
			logSvc.updateBatchHistory(schdInfo);
			
	    	logger.info("ITS VW_SP_SKE_HWINVENTORY Daily Batch totCnt="+batch_cnt);
	    }
    }

    /**
	 * ITS 기초 데이터 연계
	 * target table : IF_ITS_SKE_SWVIEW
	 * Result : void
     * @throws Exception 
	 */
    public void execIfItsSkeSwview(final Param schdInfo) throws Exception {
		int 	batch_cnt	= 0;
		int 	fail_cnt	= 0;
		String	err_chk		= "";
		String	rst_msg		= "";

		// start log
		schdInfo.set("BATCH_SEQ", logSvc.newAppendBatchHistory(schdInfo));

		Calendar cal = Calendar.getInstance();
		String ifDt	= Utils.getTimeStampString(cal.getTime(),"yyyy-MM-dd HH:mm:ss");

		String ip		= Property.getProperty("if.its.ip").toString();
		String port		= Property.getProperty("if.its.port").toString();
		String sid		= Property.getProperty("if.its.sid").toString();
		String username = Property.getProperty("if.its.id").toString();
		String password = Property.getProperty("if.its.pw").toString();

		String driver	= "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String url		= "jdbc:sqlserver://" + ip + ":" + port + ";databaseName=" + sid;

		Connection conn = null;                                        // null로 초기화 한다.
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			Class.forName(driver); 
			conn	= DriverManager.getConnection(url,username,password);

			StringBuffer sql	= new StringBuffer();
			sql.append("SELECT ");
			sql.append("	TAGNO     , ");
			sql.append("	ADMINID   , ");
			sql.append("	TCOADMINID, ");
			sql.append("	SWUNI_NAME, ");
			sql.append("	CERTIFY     ");
			sql.append("FROM VW_SP_SKE_SWVIEW ");
			sql.append("ORDER BY TAGNO ");

			pstmt	= conn.prepareStatement(sql.toString());
			rs		= pstmt.executeQuery();

			if (rs != null) {
				// 기존 데이터 Truncate
				deleteIstgSkeSwview(null);

				List<Param> dataList = new ArrayList<Param>();

				while (rs.next()) {
					batch_cnt = batch_cnt + 1;

					Param	param	= new Param();
					param.set("tagno"     , rs.getString("TAGNO"     ));
					param.set("adminid"   , rs.getString("ADMINID"   ));
					param.set("tcoadminid", rs.getString("TCOADMINID"));
					param.set("swuni_name", rs.getString("SWUNI_NAME"));
					param.set("certify"   , rs.getString("CERTIFY"   ));
					param.set("if_dt"     , ifDt);

					if ((batch_cnt % 2000) > 0) {
						dataList.add(param);
					} else {
						try {
							Param inParam = new Param();
							inParam.set("dataList", dataList);

							insertIstgSkeSwview(inParam);
						} catch (Exception e) {
							e.printStackTrace();
							fail_cnt = fail_cnt + dataList.size();
						}

						dataList = new ArrayList<Param>();
					}
				}

				if (dataList != null && dataList.size() > 0) {
					try {
						Param inParam = new Param();
						inParam.set("dataList", dataList);

						insertIstgSkeSwview(inParam);
					} catch (Exception e) {
						e.printStackTrace();
						fail_cnt = fail_cnt + dataList.size();
					}
				}
			} else {
				// 넘어온 데이터가 없는경우
				logger.info("ITS VW_SP_SKE_SWVIEW 데이터가 없습니다.");
			}

			rs.close();
			pstmt.close();

			// 임시 저장소에 저장된 데이타가 있는 테입ㄹ만 실테이블로 데이터 이동
			int cnt = getIstgSwviewTotalCnt(null);

			if (cnt > 0) {
				deleteSkeSwview(null);
				insertSkeSwview(null);
			}

		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		} finally {
			if(rs != null) try{rs.close();}catch(SQLException sqle){}         // Resultset 객체 해제
			if(pstmt != null) try{pstmt.close();}catch(SQLException sqle){}   // PreparedStatement 객체 해제
			if(conn != null) try{conn.close();}catch(SQLException sqle){}     // Connection 해제
		}
		
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		if (!err_chk.equals("")) {
			schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "N");
			schdInfo.set("BATCH_MSG", err_chk);
			logSvc.updateBatchHistory(schdInfo);
			
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
			if(batch_cnt > 0){
	    		rst_msg = "VW_SP_SKE_SWVIEW 연계 총 " + batch_cnt + " (실패:" + fail_cnt + ")건이 처리 되었습니다.\n";
	    	}else{
	    		rst_msg = "가져올 VW_SP_SKE_SWVIEW 데이터가 없습니다.";
	    	}
	    	schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "Y");
			schdInfo.set("BATCH_MSG", rst_msg);
			logSvc.updateBatchHistory(schdInfo);
			
	    	logger.info("ITS VW_SP_SKE_SWVIEW Daily Batch totCnt="+batch_cnt);
	    }
    }

    /**
	 * ITS 기초 데이터 연계
	 * target table : IF_ITS_MST_APPL
	 * Result : void
     * @throws Exception 
	 */
    public void execIfItsMstAppl(final Param schdInfo) throws Exception {
		int 	batch_cnt	= 0;
		int 	fail_cnt	= 0;
		String	err_chk		= "";
		String	rst_msg		= "";

		// start log
		schdInfo.set("BATCH_SEQ", logSvc.newAppendBatchHistory(schdInfo));

		Calendar cal = Calendar.getInstance();
		String ifDt	= Utils.getTimeStampString(cal.getTime(),"yyyy-MM-dd HH:mm:ss");

		String ip		= Property.getProperty("if.its.ip").toString();
		String port		= Property.getProperty("if.its.port").toString();
		String sid		= Property.getProperty("if.its.sid").toString();
		String username = Property.getProperty("if.its.id").toString();
		String password = Property.getProperty("if.its.pw").toString();

		String driver	= "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String url		= "jdbc:sqlserver://" + ip + ":" + port + ";databaseName=" + sid;

		Connection conn = null;                                        // null로 초기화 한다.
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			Class.forName(driver); 
			conn	= DriverManager.getConnection(url,username,password);

			StringBuffer sql	= new StringBuffer();
			sql.append("SELECT ");
			sql.append("	SYS_ID      , ");
			sql.append("	COLUMN_NAME , ");
			sql.append("	COLUMN_VALUE, ");
			sql.append("	UPDATEDATE  , ");
			sql.append("	UPDATEUSER    ");
			sql.append("FROM VW_SP_MST_APPLICATION ");
			sql.append("WHERE SYS_ID IS NOT NULL ");
			sql.append("AND SYS_ID != '' ");
			sql.append("AND COLUMN_NAME IS NOT NULL ");
			sql.append("AND COLUMN_NAME != '' ");
			sql.append("ORDER BY SYS_ID, COLUMN_NAME ");

			pstmt	= conn.prepareStatement(sql.toString());
			rs		= pstmt.executeQuery();

			if (rs != null) {
				// 기존 데이터 Truncate
				deleteIstgMstAppl(null);

				List<Param> dataList = new ArrayList<Param>();

				while (rs.next()) {
					batch_cnt = batch_cnt + 1;

					Param	param	= new Param();
					param.set("sys_id"      , rs.getString("SYS_ID"      ));
					param.set("column_name" , rs.getString("COLUMN_NAME" ));
					param.set("column_value", rs.getString("COLUMN_VALUE"));
					param.set("updatedate"  , rs.getString("UPDATEDATE"  ));
					param.set("updateuser"  , rs.getString("UPDATEUSER"  ));
					param.set("if_dt"       , ifDt);

					if ((batch_cnt % 2000) > 0) {
						if (param.get("sys_id") != null && param.get("column_name") != null) {
							dataList.add(param);
						} else {
							batch_cnt--;
						}
					} else {
						try {
							Param inParam = new Param();
							inParam.set("dataList", dataList);

							insertIstgMstAppl(inParam);
						} catch (Exception e) {
							e.printStackTrace();
							fail_cnt = fail_cnt + dataList.size();
						}

						dataList = new ArrayList<Param>();
					}
				}

				if (dataList != null && dataList.size() > 0) {
					try {
						Param inParam = new Param();
						inParam.set("dataList", dataList);

						insertIstgMstAppl(inParam);
					} catch (Exception e) {
						e.printStackTrace();
						fail_cnt = fail_cnt + dataList.size();
					}
				}
			} else {
				// 넘어온 데이터가 없는경우
				logger.info("ITS VW_SP_MST_APPLICATION 데이터가 없습니다.");
			}

			rs.close();
			pstmt.close();

			// 임시 저장소에 저장된 데이타가 있는 테입ㄹ만 실테이블로 데이터 이동
			int cnt = getIstgApplTotalCnt(null);

			if (cnt > 0) {
				deleteMstAppl(null);
				insertMstAppl(null);
				updateCodeName(null);
			}

		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		} finally {
			if(rs != null) try{rs.close();}catch(SQLException sqle){}         // Resultset 객체 해제
			if(pstmt != null) try{pstmt.close();}catch(SQLException sqle){}   // PreparedStatement 객체 해제
			if(conn != null) try{conn.close();}catch(SQLException sqle){}     // Connection 해제
		}
		
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		if (!err_chk.equals("")) {
			schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "N");
			schdInfo.set("BATCH_MSG", err_chk);
			logSvc.updateBatchHistory(schdInfo);
			
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
			if(batch_cnt > 0){
	    		rst_msg = "VW_SP_MST_APPLICATION 연계 총 " + batch_cnt + " (실패:" + fail_cnt + ")건이 처리 되었습니다.\n";
	    	}else{
	    		rst_msg = "가져올 VW_SP_MST_APPLICATION 데이터가 없습니다.";
	    	}
	    	schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "Y");
			schdInfo.set("BATCH_MSG", rst_msg);
			logSvc.updateBatchHistory(schdInfo);
			
	    	logger.info("ITS VW_SP_MST_APPLICATION Daily Batch totCnt="+batch_cnt);
	    }
    }

    /**
	 * ITS 기초 데이터 연계
	 * target table : IF_ITS_MST_APPL_DETAIL
	 * Result : void
     * @throws Exception 
	 */
    public void execIfItsMstApplDetail(final Param schdInfo) throws Exception {
		int 	batch_cnt	= 0;
		int 	fail_cnt	= 0;
		String	err_chk		= "";
		String	rst_msg		= "";

		// start log
		schdInfo.set("BATCH_SEQ", logSvc.newAppendBatchHistory(schdInfo));

		Calendar cal = Calendar.getInstance();
		String ifDt	= Utils.getTimeStampString(cal.getTime(),"yyyy-MM-dd HH:mm:ss");

		String ip		= Property.getProperty("if.its.ip").toString();
		String port		= Property.getProperty("if.its.port").toString();
		String sid		= Property.getProperty("if.its.sid").toString();
		String username = Property.getProperty("if.its.id").toString();
		String password = Property.getProperty("if.its.pw").toString();

		String driver	= "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String url		= "jdbc:sqlserver://" + ip + ":" + port + ";databaseName=" + sid;

		Connection conn = null;                                        // null로 초기화 한다.
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			Class.forName(driver); 
			conn	= DriverManager.getConnection(url,username,password);

			StringBuffer sql	= new StringBuffer();
			sql.append("SELECT ");
			sql.append("	SYS_ID      , ");
			sql.append("	GOBUN       , ");
			sql.append("	SEQ         , ");
			sql.append("	COLUMN_NAME , ");
			sql.append("	COLUMN_VALUE, ");
			sql.append("	UPDATEDATE  , ");
			sql.append("	UPDATEUSER    ");
			sql.append("FROM VW_SP_MST_APPLICATION_DETAIL ");
			sql.append("WHERE SYS_ID IS NOT NULL ");
			sql.append("AND SYS_ID != '' ");
			sql.append("AND GOBUN IS NOT NULL ");
			sql.append("AND GOBUN != '' ");
			sql.append("AND SEQ IS NOT NULL ");
			sql.append("AND SEQ != '' ");
			sql.append("AND COLUMN_NAME IS NOT NULL ");
			sql.append("AND COLUMN_NAME != '' ");
			sql.append("ORDER BY SYS_ID, GOBUN, SEQ, COLUMN_NAME ");

			pstmt	= conn.prepareStatement(sql.toString());
			rs		= pstmt.executeQuery();

			if (rs != null) {
				// 기존 데이터 Truncate
				deleteIstgMstApplDetail(null);

				List<Param> dataList = new ArrayList<Param>();

				while (rs.next()) {
					batch_cnt = batch_cnt + 1;

					Param	param	= new Param();
					param.set("sys_id"      , rs.getString("SYS_ID"      ));
					param.set("gobun"       , rs.getString("GOBUN"       ));
					param.set("seq"         , rs.getString("SEQ"         ));
					param.set("column_name" , rs.getString("COLUMN_NAME" ));
					param.set("column_value", rs.getString("COLUMN_VALUE"));
					param.set("updatedate"  , rs.getString("UPDATEDATE"  ));
					param.set("updateuser"  , rs.getString("UPDATEUSER"  ));
					param.set("if_dt"       , ifDt);

					if ((batch_cnt % 2000) > 0) {
						if (param.get("sys_id") != null && param.get("gobun") != null && param.get("seq") != null && param.get("column_name") != null) {
							dataList.add(param);
						} else {
							batch_cnt--;
						}
					} else {
						try {
							Param inParam = new Param();
							inParam.set("dataList", dataList);

							insertIstgMstApplDetail(inParam);
						} catch (Exception e) {
							e.printStackTrace();
							fail_cnt = fail_cnt + dataList.size();
						}

						dataList = new ArrayList<Param>();
					}
				}

				if (dataList != null && dataList.size() > 0) {
					try {
						Param inParam = new Param();
						inParam.set("dataList", dataList);

						insertIstgMstApplDetail(inParam);
					} catch (Exception e) {
						e.printStackTrace();
						fail_cnt = fail_cnt + dataList.size();
					}
				}
			} else {
				// 넘어온 데이터가 없는경우
				logger.info("ITS VW_SP_MST_APPLICATION_DETAIL 데이터가 없습니다.");
			}

			rs.close();
			pstmt.close();

			// 임시 저장소에 저장된 데이타가 있는 테입ㄹ만 실테이블로 데이터 이동
			int cnt = getIstgApplDetailTotalCnt(null);

			if (cnt > 0) {
				deleteMstApplDetail(null);
				insertMstApplDetail(null);
			}

		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		} finally {
			if(rs != null) try{rs.close();}catch(SQLException sqle){}         // Resultset 객체 해제
			if(pstmt != null) try{pstmt.close();}catch(SQLException sqle){}   // PreparedStatement 객체 해제
			if(conn != null) try{conn.close();}catch(SQLException sqle){}     // Connection 해제
		}
		
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		if (!err_chk.equals("")) {
			schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "N");
			schdInfo.set("BATCH_MSG", err_chk);
			logSvc.updateBatchHistory(schdInfo);
			
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
			if(batch_cnt > 0){
	    		rst_msg = "VW_SP_MST_APPLICATION_DETAIL 연계 총 " + batch_cnt + " (실패:" + fail_cnt + ")건이 처리 되었습니다.\n";
	    	}else{
	    		rst_msg = "가져올 VW_SP_MST_APPLICATION_DETAIL 데이터가 없습니다.";
	    	}
	    	schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "Y");
			schdInfo.set("BATCH_MSG", rst_msg);
			logSvc.updateBatchHistory(schdInfo);
			
	    	logger.info("ITS VW_SP_MST_APPLICATION_DETAIL Daily Batch totCnt="+batch_cnt);
	    }
    }

    /**
	 * ITS 기초 데이터 연계
	 * target table : IF_ITS_MST_APPL_SECURITY
	 * Result : void
     * @throws Exception 
	 */
    public void execIfItsMstApplSecurity(final Param schdInfo) throws Exception {
		int 	batch_cnt	= 0;
		int 	fail_cnt	= 0;
		String	err_chk		= "";
		String	rst_msg		= "";

		// start log
		schdInfo.set("BATCH_SEQ", logSvc.newAppendBatchHistory(schdInfo));

		Calendar cal = Calendar.getInstance();
		String ifDt	= Utils.getTimeStampString(cal.getTime(),"yyyy-MM-dd HH:mm:ss");

		String ip		= Property.getProperty("if.its.ip").toString();
		String port		= Property.getProperty("if.its.port").toString();
		String sid		= Property.getProperty("if.its.sid").toString();
		String username = Property.getProperty("if.its.id").toString();
		String password = Property.getProperty("if.its.pw").toString();

		String driver	= "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String url		= "jdbc:sqlserver://" + ip + ":" + port + ";databaseName=" + sid;

		Connection conn = null;                                        // null로 초기화 한다.
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			Class.forName(driver); 
			conn	= DriverManager.getConnection(url,username,password);

			StringBuffer sql	= new StringBuffer();
			sql.append("SELECT ");
			sql.append("	SYS_ID           , ");
			sql.append("	INFO_TYPE        , ");
			sql.append("	EXCEPT_CNT       , ");
			sql.append("	OVERLAP_CNT      , ");
			sql.append("	RESIDENT_YN      , ");
			sql.append("	FOREIGN_YN       , ");
			sql.append("	PASSPORT_YN      , ");
			sql.append("	DRIVER_YN        , ");
			sql.append("	ACCOUNT_YN       , ");
			sql.append("	CREDIT_YN        , ");
			sql.append("	CREDITINFO_YN    , ");
			sql.append("	HEALTH_YN        , ");
			sql.append("	UNION_YN         , ");
			sql.append("	FINGERPRT_YN     , ");
			sql.append("	IRIS_VEIN_YN     , ");
			sql.append("	LOCATION_YN      , ");
			sql.append("	NAME_YN          , ");
			sql.append("	BIRTH_YN         , ");
			sql.append("	GENDER_YN        , ");
			sql.append("	ADDRESS_YN       , ");
			sql.append("	LEGAL_DOMICILE_YN, ");
			sql.append("	MOBILE_NO_YN     , ");
			sql.append("	TEL_NO_YN        , ");
			sql.append("	OFFICE_NO_YN     , ");
			sql.append("	FAX_NO_YN        , ");
			sql.append("	WEB_EMAIL_YN     , ");
			sql.append("	OFFICE_EMAIL_YN  , ");
			sql.append("	ACADEMIC_YN      , ");
			sql.append("	LICENSE_YN       , ");
			sql.append("	MILITARY_YN      , ");
			sql.append("	USER_ID_YN       , ");
			sql.append("	PASSWORD_YN      , ");
			sql.append("	EMPLOYEE_NUM_YN  , ");
			sql.append("	DEPT_YN          , ");
			sql.append("	POSITION_YN      , ");
			sql.append("	CCTV_YN          , ");
			sql.append("	IP_YN            , ");
			sql.append("	VEHICLE_NUM_YN   , ");
			sql.append("	ETC              , ");
			sql.append("	\"DESC\"           ");
			sql.append("FROM VW_SP_MST_APPLICATION_SECURITY ");
			sql.append("WHERE SYS_ID IS NOT NULL ");
			sql.append("AND SYS_ID != '' ");
			sql.append("AND INFO_TYPE IS NOT NULL ");
			sql.append("AND INFO_TYPE != '' ");
			sql.append("ORDER BY SYS_ID, INFO_TYPE ");

			pstmt	= conn.prepareStatement(sql.toString());
			rs		= pstmt.executeQuery();

			if (rs != null) {
				// 기존 데이터 Truncate
				deleteIstgMstApplSecurity(null);

				List<Param> dataList = new ArrayList<Param>();

				while (rs.next()) {
					batch_cnt = batch_cnt + 1;

					Param	param	= new Param();
					param.set("sys_id"           , rs.getString("SYS_ID"           ));
					param.set("info_type"        , rs.getString("INFO_TYPE"        ));
					param.set("except_cnt"       , rs.getString("EXCEPT_CNT"       ));
					param.set("overlap_cnt"      , rs.getString("OVERLAP_CNT"      ));
					param.set("resident_yn"      , rs.getString("RESIDENT_YN"      ));
					param.set("foreign_yn"       , rs.getString("FOREIGN_YN"       ));
					param.set("passport_yn"      , rs.getString("PASSPORT_YN"      ));
					param.set("driver_yn"        , rs.getString("DRIVER_YN"        ));
					param.set("account_yn"       , rs.getString("ACCOUNT_YN"       ));
					param.set("credit_yn"        , rs.getString("CREDIT_YN"        ));
					param.set("creditinfo_yn"    , rs.getString("CREDITINFO_YN"    ));
					param.set("health_yn"        , rs.getString("HEALTH_YN"        ));
					param.set("union_yn"         , rs.getString("UNION_YN"         ));
					param.set("fingerprt_yn"     , rs.getString("FINGERPRT_YN"     ));
					param.set("iris_vein_yn"     , rs.getString("IRIS_VEIN_YN"     ));
					param.set("location_yn"      , rs.getString("LOCATION_YN"      ));
					param.set("name_yn"          , rs.getString("NAME_YN"          ));
					param.set("birth_yn"         , rs.getString("BIRTH_YN"         ));
					param.set("gender_yn"        , rs.getString("GENDER_YN"        ));
					param.set("address_yn"       , rs.getString("ADDRESS_YN"       ));
					param.set("legal_domicile_yn", rs.getString("LEGAL_DOMICILE_YN"));
					param.set("mobile_no_yn"     , rs.getString("MOBILE_NO_YN"     ));
					param.set("tel_no_yn"        , rs.getString("TEL_NO_YN"        ));
					param.set("office_no_yn"     , rs.getString("OFFICE_NO_YN"     ));
					param.set("fax_no_yn"        , rs.getString("FAX_NO_YN"        ));
					param.set("web_email_yn"     , rs.getString("WEB_EMAIL_YN"     ));
					param.set("office_email_yn"  , rs.getString("OFFICE_EMAIL_YN"  ));
					param.set("academic_yn"      , rs.getString("ACADEMIC_YN"      ));
					param.set("license_yn"       , rs.getString("LICENSE_YN"       ));
					param.set("military_yn"      , rs.getString("MILITARY_YN"      ));
					param.set("user_id_yn"       , rs.getString("USER_ID_YN"       ));
					param.set("password_yn"      , rs.getString("PASSWORD_YN"      ));
					param.set("employee_num_yn"  , rs.getString("EMPLOYEE_NUM_YN"  ));
					param.set("dept_yn"          , rs.getString("DEPT_YN"          ));
					param.set("position_yn"      , rs.getString("POSITION_YN"      ));
					param.set("cctv_yn"          , rs.getString("CCTV_YN"          ));
					param.set("ip_yn"            , rs.getString("IP_YN"            ));
					param.set("vehicle_num_yn"   , rs.getString("VEHICLE_NUM_YN"   ));
					param.set("etc"              , rs.getString("ETC"              ));
					param.set("desc"             , rs.getString("DESC"             ));
					param.set("if_dt"            , ifDt);

					if ((batch_cnt % 2000) > 0) {
						if (param.get("sys_id") != null && param.get("info_type") != null) {
							dataList.add(param);
						} else {
							batch_cnt--;
						}
					} else {
						try {
							Param inParam = new Param();
							inParam.set("dataList", dataList);

							insertIstgMstApplSecurity(inParam);
						} catch (Exception e) {
							e.printStackTrace();
							fail_cnt = fail_cnt + dataList.size();
						}

						dataList = new ArrayList<Param>();
					}
				}

				if (dataList != null && dataList.size() > 0) {
					try {
						Param inParam = new Param();
						inParam.set("dataList", dataList);

						insertIstgMstApplSecurity(inParam);
					} catch (Exception e) {
						e.printStackTrace();
						fail_cnt = fail_cnt + dataList.size();
					}
				}
			} else {
				// 넘어온 데이터가 없는경우
				logger.info("ITS VW_SP_MST_APPLICATION_SECURITY 데이터가 없습니다.");
			}

			rs.close();
			pstmt.close();

			// 임시 저장소에 저장된 데이타가 있는 테입ㄹ만 실테이블로 데이터 이동
			int cnt = getIstgApplSecurityTotalCnt(null);

			if (cnt > 0) {
				deleteMstApplSecurity(null);
				insertMstApplSecurity(null);
			}

		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		} finally {
			if(rs != null) try{rs.close();}catch(SQLException sqle){}         // Resultset 객체 해제
			if(pstmt != null) try{pstmt.close();}catch(SQLException sqle){}   // PreparedStatement 객체 해제
			if(conn != null) try{conn.close();}catch(SQLException sqle){}     // Connection 해제
		}
		
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		if (!err_chk.equals("")) {
			schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "N");
			schdInfo.set("BATCH_MSG", err_chk);
			logSvc.updateBatchHistory(schdInfo);
			
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
			if(batch_cnt > 0){
	    		rst_msg = "VW_SP_MST_APPLICATION_SECURITY 연계 총 " + batch_cnt + " (실패:" + fail_cnt + ")건이 처리 되었습니다.\n";
	    	}else{
	    		rst_msg = "가져올 VW_SP_MST_APPLICATION_SECURITY 데이터가 없습니다.";
	    	}
	    	schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "Y");
			schdInfo.set("BATCH_MSG", rst_msg);
			logSvc.updateBatchHistory(schdInfo);
			
	    	logger.info("ITS VW_SP_MST_APPLICATION_SECURITY Daily Batch totCnt="+batch_cnt);
	    }
    }

    /**
	 * ITS 기초 데이터 연계
	 * target table : IF_ITS_EAM_INTFC_AMS_MASTER
	 * Result : void
     * @throws Exception 
	 */
    public void execIfItsEamIntfcAmsMaster(final Param schdInfo) throws Exception {
		int 	batch_cnt	= 0;
		int 	fail_cnt	= 0;
		String	err_chk		= "";
		String	rst_msg		= "";

		// start log
		schdInfo.set("BATCH_SEQ", logSvc.newAppendBatchHistory(schdInfo));

		Calendar cal = Calendar.getInstance();
		String ifDt	= Utils.getTimeStampString(cal.getTime(),"yyyy-MM-dd HH:mm:ss");

		String ip		= Property.getProperty("if.its.ip").toString();
		String port		= Property.getProperty("if.its.port").toString();
		String sid		= Property.getProperty("if.its.sid").toString();
		String username = Property.getProperty("if.its.id").toString();
		String password = Property.getProperty("if.its.pw").toString();

		String driver	= "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String url		= "jdbc:sqlserver://" + ip + ":" + port + ";databaseName=" + sid;

		Connection conn = null;                                        // null로 초기화 한다.
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			Class.forName(driver); 
			conn	= DriverManager.getConnection(url,username,password);

			StringBuffer sql	= new StringBuffer();
			sql.append("SELECT ");
			sql.append("	CONF_ID                , ");
			sql.append("	ASSET_MGMT_NO          , ");
			sql.append("	TOWER_CLFC             , ");
			sql.append("	CUST_CD                , ");
			sql.append("	CUST_NM                , ");
			sql.append("	ASSET_CLFC_TOP_CD      , ");
			sql.append("	ASSET_CLFC_TOP_NM      , ");
			sql.append("	ASSET_CLFC_MID_CD      , ");
			sql.append("	ASSET_CLFC_MID_NM      , ");
			sql.append("	ASSET_CLFC_BOT_CD      , ");
			sql.append("	ASSET_CLFC_BOT_NM      , ");
			sql.append("	ASSET_CLFC_BBOT_CD     , ");
			sql.append("	ASSET_CLFC_BBOT_NM     , ");
			sql.append("	MAKER_NM               , ");
			sql.append("	MODEL_NM               , ");
			sql.append("	WARR_PRD               , ");
			sql.append("	MODEL_DESC             , ");
			sql.append("	SERIAL_NO              , ");
			sql.append("	EQUIP_USE              , ");
			sql.append("	ASSET_STAT             , ");
			sql.append("	INSTL_DT               , ");
			sql.append("	DEV_OPR_CLFC           , ");
			sql.append("	DEV_OPR_CLFC_NM        , ");
			sql.append("	LOCA_CD                , ");
			sql.append("	LOCA_NM                , ");
			sql.append("	LOCA_ADDR              , ");
			sql.append("	OPR_DEPT_CD            , ");
			sql.append("	OPR_DEPT_NM            , ");
			sql.append("	OPR_1_EMP_NO           , ");
			sql.append("	OPR_1_EMP_NM           , ");
			sql.append("	OPR_2_EMP_NO           , ");
			sql.append("	OPR_2_EMP_NM           , ");
			sql.append("	USE_DEPT_CD            , ");
			sql.append("	USE_DEPT_NM            , ");
			sql.append("	USE_1_EMP_NO           , ");
			sql.append("	USE_1_EMP_NM           , ");
			sql.append("	USE_2_EMP_NO           , ");
			sql.append("	USE_2_EMP_NM           , ");
			sql.append("	HOST_NM                , ");
			sql.append("	HOST_NICK_NM           , ");
			sql.append("	SUP_SVC_CD             , ");
			sql.append("	SUP_SVC_NM             , ");
			sql.append("	OS_NM                  , ");
			sql.append("	OS_VER                 , ");
			sql.append("	HA_YN                  , ");
			sql.append("	HA_SVR_CONF_ID         , ");
			sql.append("	HA_ASSET_MGMT_NO       , ");
			sql.append("	HA_REL_CD              , ");
			sql.append("	IP_ADDR                , ");
			sql.append("	SVR_USE                , ");
			sql.append("	SVR_TYPE               , ");
			sql.append("	SVR_TYPE_NM            , ");
			sql.append("	PARTI_YN               , ");
			sql.append("	HW_GR_CD               , ");
			sql.append("	CPU_TOT_CAPA           , ");
			sql.append("	CPU_BIT                , ");
			sql.append("	CPU_MAKER_CD           , ");
			sql.append("	CPU_MAKER_NM           , ");
			sql.append("	CPU_TYPE               , ");
			sql.append("	CPU_CACHE              , ");
			sql.append("	CPU_INSTL_MAX_AVAIL_CNT, ");
			sql.append("	MEM_TOT_CAPA           , ");
			sql.append("	MEM_MAX_SLOT           , ");
			sql.append("	INT_DISK_TOT_CAPA      , ");
			sql.append("	DISK_SLOT_MAX_AVAIL_CNT, ");
			sql.append("	DISK_CTLR_MODEL        , ");
			sql.append("	EXT_DISK_TOT_CAPA      , ");
			sql.append("	CONTR_NO               , ");
			sql.append("	ASSET_OWNER_CD         , ");
			sql.append("	ASSET_OWNER_NM         , ");
			sql.append("	AGRMT_CONTR_NO         , ");
			sql.append("	AGRMT_CONTR_NM         , ");
			sql.append("	AGRMT_LINE_NO          , ");
			sql.append("	PJT_NO                 , ");
			sql.append("	BOX_PUR_PRC            , ");
			sql.append("	FEAT_PUR_PRC           , ");
			sql.append("	TOT_PUR_AMT            , ");
			sql.append("	CUST_PRC               , ");
			sql.append("	ASSET_NO               , ");
			sql.append("	WBS_CD                 , ");
			sql.append("	FREE_STAT_YN           , ");
			sql.append("	ADJ_METH_DESC          , ");
			sql.append("	PO_CNTS                , ");
			sql.append("	SKT_ASSET_NO           , ");
			sql.append("	FST_INSTL_DATE         , ");
			sql.append("	AP_DT                  , ");
			sql.append("	CFM_DT                 , ");
			sql.append("	LOCA_XY                , ");
			sql.append("	INSTL_SITE             , ");
			sql.append("	PARTI_ASSET_MGMT_NO    , ");
			sql.append("	SW_VER                 , ");
			sql.append("	LIC_TYPE               , ");
			sql.append("	LIC_CNT                , ");
			sql.append("	NT_UX_CLFC             , ");
			sql.append("	CPU_SIZE               , ");
			sql.append("	CPU_INSTL_CNT          , ");
			sql.append("	CPU_CORE_CNT           , ");
			sql.append("	CPU_CORE_USE_CNT       , ");
			sql.append("	INT_DISK_SLOT_USE_CNT  , ");
			sql.append("	NODE_NM                , ");
			sql.append("	EQUIP_TYPE             , ");
			sql.append("	NW_OS_VER              , ");
			sql.append("	BOX_MOD_CLFC           , ");
			sql.append("	REP_IP_ADDR            , ");
			sql.append("	SURV_CNTS              , ");
			sql.append("	BOX_ASSET_NO           , ");
			sql.append("	TOT_PORT_CNT           , ");
			sql.append("	USE_PORT_CNT           , ");
			sql.append("	EQUIP_CAPA             , ");
			sql.append("	BATT_SPEC              , ");
			sql.append("	EQUIP_IN_VOLT          , ");
			sql.append("	EQUIP_OUT_VOLT         , ");
			sql.append("	COOL_TYPE              , ");
			sql.append("	WIND_TYPE              , ");
			sql.append("	BAK_DEVC_TOT_CAPA      , ");
			sql.append("	BAK_DEVC_CNT           , ");
			sql.append("	STG_CONF_TYPE          , ");
			sql.append("	STG_TOT_CAPA           , ");
			sql.append("	STG_AVAIL_CAPA           ");
			sql.append("FROM VW_SP_EAM_INTFC_AMS_CO_SKE_MASTER_VW ");
			sql.append("WHERE CONF_ID IS NOT NULL ");
			sql.append("AND CONF_ID != '' ");
			sql.append("ORDER BY CONF_ID ");

			pstmt	= conn.prepareStatement(sql.toString());
			rs		= pstmt.executeQuery();

			if (rs != null) {
				// 기존 데이터 Truncate
				deleteIstgEamIntfcAmsMaster(null);

				List<Param> dataList = new ArrayList<Param>();

				while (rs.next()) {
					batch_cnt = batch_cnt + 1;

					Param	param	= new Param();
					param.set("conf_id"                , rs.getString("CONF_ID"                ));
					param.set("asset_mgmt_no"          , rs.getString("ASSET_MGMT_NO"          ));
					param.set("tower_clfc"             , rs.getString("TOWER_CLFC"             ));
					param.set("cust_cd"                , rs.getString("CUST_CD"                ));
					param.set("cust_nm"                , rs.getString("CUST_NM"                ));
					param.set("asset_clfc_top_cd"      , rs.getString("ASSET_CLFC_TOP_CD"      ));
					param.set("asset_clfc_top_nm"      , rs.getString("ASSET_CLFC_TOP_NM"      ));
					param.set("asset_clfc_mid_cd"      , rs.getString("ASSET_CLFC_MID_CD"      ));
					param.set("asset_clfc_mid_nm"      , rs.getString("ASSET_CLFC_MID_NM"      ));
					param.set("asset_clfc_bot_cd"      , rs.getString("ASSET_CLFC_BOT_CD"      ));
					param.set("asset_clfc_bot_nm"      , rs.getString("ASSET_CLFC_BOT_NM"      ));
					param.set("asset_clfc_bbot_cd"     , rs.getString("ASSET_CLFC_BBOT_CD"     ));
					param.set("asset_clfc_bbot_nm"     , rs.getString("ASSET_CLFC_BBOT_NM"     ));
					param.set("maker_nm"               , rs.getString("MAKER_NM"               ));
					param.set("model_nm"               , rs.getString("MODEL_NM"               ));
					param.set("warr_prd"               , rs.getString("WARR_PRD"               ));
					param.set("model_desc"             , rs.getString("MODEL_DESC"             ));
					param.set("serial_no"              , rs.getString("SERIAL_NO"              ));
					param.set("equip_use"              , rs.getString("EQUIP_USE"              ));
					param.set("asset_stat"             , rs.getString("ASSET_STAT"             ));
					param.set("instl_dt"               , rs.getString("INSTL_DT"               ));
					param.set("dev_opr_clfc"           , rs.getString("DEV_OPR_CLFC"           ));
					param.set("dev_opr_clfc_nm"        , rs.getString("DEV_OPR_CLFC_NM"        ));
					param.set("loca_cd"                , rs.getString("LOCA_CD"                ));
					param.set("loca_nm"                , rs.getString("LOCA_NM"                ));
					param.set("loca_addr"              , rs.getString("LOCA_ADDR"              ));
					param.set("opr_dept_cd"            , rs.getString("OPR_DEPT_CD"            ));
					param.set("opr_dept_nm"            , rs.getString("OPR_DEPT_NM"            ));
					param.set("opr_1_emp_no"           , rs.getString("OPR_1_EMP_NO"           ));
					param.set("opr_1_emp_nm"           , rs.getString("OPR_1_EMP_NM"           ));
					param.set("opr_2_emp_no"           , rs.getString("OPR_2_EMP_NO"           ));
					param.set("opr_2_emp_nm"           , rs.getString("OPR_2_EMP_NM"           ));
					param.set("use_dept_cd"            , rs.getString("USE_DEPT_CD"            ));
					param.set("use_dept_nm"            , rs.getString("USE_DEPT_NM"            ));
					param.set("use_1_emp_no"           , rs.getString("USE_1_EMP_NO"           ));
					param.set("use_1_emp_nm"           , rs.getString("USE_1_EMP_NM"           ));
					param.set("use_2_emp_no"           , rs.getString("USE_2_EMP_NO"           ));
					param.set("use_2_emp_nm"           , rs.getString("USE_2_EMP_NM"           ));
					param.set("host_nm"                , rs.getString("HOST_NM"                ));
					param.set("host_nick_nm"           , rs.getString("HOST_NICK_NM"           ));
					param.set("sup_svc_cd"             , rs.getString("SUP_SVC_CD"             ));
					param.set("sup_svc_nm"             , rs.getString("SUP_SVC_NM"             ));
					param.set("os_nm"                  , rs.getString("OS_NM"                  ));
					param.set("os_ver"                 , rs.getString("OS_VER"                 ));
					param.set("ha_yn"                  , rs.getString("HA_YN"                  ));
					param.set("ha_svr_conf_id"         , rs.getString("HA_SVR_CONF_ID"         ));
					param.set("ha_asset_mgmt_no"       , rs.getString("HA_ASSET_MGMT_NO"       ));
					param.set("ha_rel_cd"              , rs.getString("HA_REL_CD"              ));
					param.set("ip_addr"                , rs.getString("IP_ADDR"                ));
					param.set("svr_use"                , rs.getString("SVR_USE"                ));
					param.set("svr_type"               , rs.getString("SVR_TYPE"               ));
					param.set("svr_type_nm"            , rs.getString("SVR_TYPE_NM"            ));
					param.set("parti_yn"               , rs.getString("PARTI_YN"               ));
					param.set("hw_gr_cd"               , rs.getString("HW_GR_CD"               ));
					param.set("cpu_tot_capa"           , rs.getString("CPU_TOT_CAPA"           ));
					param.set("cpu_bit"                , rs.getString("CPU_BIT"                ));
					param.set("cpu_maker_cd"           , rs.getString("CPU_MAKER_CD"           ));
					param.set("cpu_maker_nm"           , rs.getString("CPU_MAKER_NM"           ));
					param.set("cpu_type"               , rs.getString("CPU_TYPE"               ));
					param.set("cpu_cache"              , rs.getString("CPU_CACHE"              ));
					param.set("cpu_instl_max_avail_cnt", rs.getString("CPU_INSTL_MAX_AVAIL_CNT"));
					param.set("mem_tot_capa"           , rs.getString("MEM_TOT_CAPA"           ));
					param.set("mem_max_slot"           , rs.getString("MEM_MAX_SLOT"           ));
					param.set("int_disk_tot_capa"      , rs.getString("INT_DISK_TOT_CAPA"      ));
					param.set("disk_slot_max_avail_cnt", rs.getString("DISK_SLOT_MAX_AVAIL_CNT"));
					param.set("disk_ctlr_model"        , rs.getString("DISK_CTLR_MODEL"        ));
					param.set("ext_disk_tot_capa"      , rs.getString("EXT_DISK_TOT_CAPA"      ));
					param.set("contr_no"               , rs.getString("CONTR_NO"               ));
					param.set("asset_owner_cd"         , rs.getString("ASSET_OWNER_CD"         ));
					param.set("asset_owner_nm"         , rs.getString("ASSET_OWNER_NM"         ));
					param.set("agrmt_contr_no"         , rs.getString("AGRMT_CONTR_NO"         ));
					param.set("agrmt_contr_nm"         , rs.getString("AGRMT_CONTR_NM"         ));
					param.set("agrmt_line_no"          , rs.getString("AGRMT_LINE_NO"          ));
					param.set("pjt_no"                 , rs.getString("PJT_NO"                 ));
					param.set("box_pur_prc"            , rs.getString("BOX_PUR_PRC"            ));
					param.set("feat_pur_prc"           , rs.getString("FEAT_PUR_PRC"           ));
					param.set("tot_pur_amt"            , rs.getString("TOT_PUR_AMT"            ));
					param.set("cust_prc"               , rs.getString("CUST_PRC"               ));
					param.set("asset_no"               , rs.getString("ASSET_NO"               ));
					param.set("wbs_cd"                 , rs.getString("WBS_CD"                 ));
					param.set("free_stat_yn"           , rs.getString("FREE_STAT_YN"           ));
					param.set("adj_meth_desc"          , rs.getString("ADJ_METH_DESC"          ));
					param.set("po_cnts"                , rs.getString("PO_CNTS"                ));
					param.set("skt_asset_no"           , rs.getString("SKT_ASSET_NO"           ));
					param.set("fst_instl_date"         , rs.getString("FST_INSTL_DATE"         ));
					param.set("ap_dt"                  , rs.getString("AP_DT"                  ));
					param.set("cfm_dt"                 , rs.getString("CFM_DT"                 ));
					param.set("loca_xy"                , rs.getString("LOCA_XY"                ));
					param.set("instl_site"             , rs.getString("INSTL_SITE"             ));
					param.set("parti_asset_mgmt_no"    , rs.getString("PARTI_ASSET_MGMT_NO"    ));
					param.set("sw_ver"                 , rs.getString("SW_VER"                 ));
					param.set("lic_type"               , rs.getString("LIC_TYPE"               ));
					param.set("lic_cnt"                , rs.getString("LIC_CNT"                ));
					param.set("nt_ux_clfc"             , rs.getString("NT_UX_CLFC"             ));
					param.set("cpu_size"               , rs.getString("CPU_SIZE"               ));
					param.set("cpu_instl_cnt"          , rs.getString("CPU_INSTL_CNT"          ));
					param.set("cpu_core_cnt"           , rs.getString("CPU_CORE_CNT"           ));
					param.set("cpu_core_use_cnt"       , rs.getString("CPU_CORE_USE_CNT"       ));
					param.set("int_disk_slot_use_cnt"  , rs.getString("INT_DISK_SLOT_USE_CNT"  ));
					param.set("node_nm"                , rs.getString("NODE_NM"                ));
					param.set("equip_type"             , rs.getString("EQUIP_TYPE"             ));
					param.set("nw_os_ver"              , rs.getString("NW_OS_VER"              ));
					param.set("box_mod_clfc"           , rs.getString("BOX_MOD_CLFC"           ));
					param.set("rep_ip_addr"            , rs.getString("REP_IP_ADDR"            ));
					param.set("surv_cnts"              , rs.getString("SURV_CNTS"              ));
					param.set("box_asset_no"           , rs.getString("BOX_ASSET_NO"           ));
					param.set("tot_port_cnt"           , rs.getString("TOT_PORT_CNT"           ));
					param.set("use_port_cnt"           , rs.getString("USE_PORT_CNT"           ));
					param.set("equip_capa"             , rs.getString("EQUIP_CAPA"             ));
					param.set("batt_spec"              , rs.getString("BATT_SPEC"              ));
					param.set("equip_in_volt"          , rs.getString("EQUIP_IN_VOLT"          ));
					param.set("equip_out_volt"         , rs.getString("EQUIP_OUT_VOLT"         ));
					param.set("cool_type"              , rs.getString("COOL_TYPE"              ));
					param.set("wind_type"              , rs.getString("WIND_TYPE"              ));
					param.set("bak_devc_tot_capa"      , rs.getString("BAK_DEVC_TOT_CAPA"      ));
					param.set("bak_devc_cnt"           , rs.getString("BAK_DEVC_CNT"           ));
					param.set("stg_conf_type"          , rs.getString("STG_CONF_TYPE"          ));
					param.set("stg_tot_capa"           , rs.getString("STG_TOT_CAPA"           ));
					param.set("stg_avail_capa"         , rs.getString("STG_AVAIL_CAPA"         ));
					param.set("if_dt"                  , ifDt);

					if ((batch_cnt % 300) > 0) {
						if (param.get("conf_id") != null) {
							dataList.add(param);
						} else {
							batch_cnt--;
						}
					} else {
						try {
							Param inParam = new Param();
							inParam.set("dataList", dataList);

							insertIstgEamIntfcAmsMaster(inParam);
						} catch (Exception e) {
							e.printStackTrace();
							fail_cnt = fail_cnt + dataList.size();
						}

						dataList = new ArrayList<Param>();
					}
				}

				if (dataList != null && dataList.size() > 0) {
					try {
						Param inParam = new Param();
						inParam.set("dataList", dataList);

						insertIstgEamIntfcAmsMaster(inParam);
					} catch (Exception e) {
						e.printStackTrace();
						fail_cnt = fail_cnt + dataList.size();
					}
				}
			} else {
				// 넘어온 데이터가 없는경우
				logger.info("ITS VW_SP_EAM_INTFC_AMS_CO_SKE_MASTER_VW 데이터가 없습니다.");
			}

			rs.close();
			pstmt.close();

			// 임시 저장소에 저장된 데이타가 있는 테입ㄹ만 실테이블로 데이터 이동
			int cnt = getIstgAmsMasterTotalCnt(null);

			if (cnt > 0) {
				deleteEamIntfcAmsMaster(null);
				insertEamIntfcAmsMaster(null);
			}

		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		} finally {
			if(rs != null) try{rs.close();}catch(SQLException sqle){}         // Resultset 객체 해제
			if(pstmt != null) try{pstmt.close();}catch(SQLException sqle){}   // PreparedStatement 객체 해제
			if(conn != null) try{conn.close();}catch(SQLException sqle){}     // Connection 해제
		}
		
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		if (!err_chk.equals("")) {
			schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "N");
			schdInfo.set("BATCH_MSG", err_chk);
			logSvc.updateBatchHistory(schdInfo);
			
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
			if(batch_cnt > 0){
	    		rst_msg = "VW_SP_EAM_INTFC_AMS_CO_SKE_MASTER_VW 연계 총 " + batch_cnt + " (실패:" + fail_cnt + ")건이 처리 되었습니다.\n";
	    	}else{
	    		rst_msg = "가져올 VW_SP_EAM_INTFC_AMS_CO_SKE_MASTER_VW 데이터가 없습니다.";
	    	}
	    	schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "Y");
			schdInfo.set("BATCH_MSG", rst_msg);
			logSvc.updateBatchHistory(schdInfo);
			
	    	logger.info("ITS VW_SP_EAM_INTFC_AMS_CO_SKE_MASTER_VW Daily Batch totCnt="+batch_cnt);
	    }
    }

	@Transactional(readOnly=true)
	public int getIstgHwinventoryTotalCnt(final Param param) {
		return (Integer)session.selectOne("com.softworks.springframework.IfItsSkeHwinventory.getIstgTotalCnt", param);
	}

	@Transactional(readOnly=true)
	public int getIstgSwviewTotalCnt(final Param param) {
		return (Integer)session.selectOne("com.softworks.springframework.IfItsSkeSwview.getIstgTotalCnt", param);
	}

	@Transactional(readOnly=true)
	public int getIstgApplTotalCnt(final Param param) {
		return (Integer)session.selectOne("com.softworks.springframework.IfItsMstAppl.getIstgTotalCnt", param);
	}

	@Transactional(readOnly=true)
	public int getIstgApplDetailTotalCnt(final Param param) {
		return (Integer)session.selectOne("com.softworks.springframework.IfItsMstApplDetail.getIstgTotalCnt", param);
	}

	@Transactional(readOnly=true)
	public int getIstgApplSecurityTotalCnt(final Param param) {
		return (Integer)session.selectOne("com.softworks.springframework.IfItsMstApplSecurity.getIstgTotalCnt", param);
	}

	@Transactional(readOnly=true)
	public int getIstgAmsMasterTotalCnt(final Param param) {
		return (Integer)session.selectOne("com.softworks.springframework.IfItsEamIntfcAmsMaster.getIstgTotalCnt", param);
	}

    /*
     * ITS VW_SP_IF_OM0071 데이터를 임시 테이블(IF_ITS_OM0071_T)에 저장
     */
	@Transactional(readOnly=true)
	public void insertTemp(final Param param) throws SQLException  {
		session.insert("com.softworks.springframework.IfItsOm0071.insertTemp", param);
	}

    /*
     * 임시 테이블(IF_ITS_OM0071_T) 데이터중 관련 데이터를 연계테이블(IF_ITS_OM0071)에 저장
     */
	@Transactional(readOnly=true)
	public int insert(final Param param) throws SQLException  {
		return session.update("com.softworks.springframework.IfItsOm0071.insert", param);
	}

    /*
     * 연계테이블(IF_ITS_OM0071) 데이터중 관련 데이터를 보안예외정책 처리결과(EXCEPT_POLICY_PROC_RESULT)에 저장
     */
	@Transactional(readOnly=true)
	public int  insertResult(final Param param) throws SQLException  {
		return session.update("com.softworks.springframework.IfItsOm0071.insertResult", param);
	}

    /*
     * ITS VW_SP_SKE_HWINVENTORY 데이터를 ISTG_ITS_SKE_HWINVENTORY에 저장
     */
	@Transactional(readOnly=true)
	public void insertIstgSkeHwinventory(final Param param) throws SQLException  {
		session.update("com.softworks.springframework.IfItsSkeHwinventory.insertIstg", param);
	}

    /*
     * ITS VW_SP_SKE_SWVIEW 데이터를 ISTG_ITS_SKE_SWVIEW에 저장
     */
	@Transactional(readOnly=true)
	public void insertIstgSkeSwview(final Param param) throws SQLException  {
		session.update("com.softworks.springframework.IfItsSkeSwview.insertIstg", param);
	}

    /*
     * ITS VW_SP_MST_APPLICATION 데이터를 ISTG_ITS_MST_APPL에 저장
     */
	@Transactional(readOnly=true)
	public void insertIstgMstAppl(final Param param) throws SQLException  {
		session.update("com.softworks.springframework.IfItsMstAppl.insertIstg", param);
	}

    /*
     * ITS VW_SP_MST_APPLICATION_DETAIL 데이터를 ISTG_ITS_MST_APPL_DETAIL에 저장
     */
	@Transactional(readOnly=true)
	public void insertIstgMstApplDetail(final Param param) throws SQLException  {
		session.update("com.softworks.springframework.IfItsMstApplDetail.insertIstg", param);
	}

    /*
     * ITS VW_SP_MST_APPLICATION_SECURITY 데이터를 ISTG_ITS_MST_APPL_SECURITY에 저장
     */
	@Transactional(readOnly=true)
	public void insertIstgMstApplSecurity(final Param param) throws SQLException  {
		session.update("com.softworks.springframework.IfItsMstApplSecurity.insertIstg", param);
	}

    /*
     * ITS VW_SP_EAM_INTFC_AMS_CO_SKE_MASTER_VW 데이터를 ISTG_ITS_MST_APPL_SECURITY에 저장
     */
	@Transactional(readOnly=true)
	public void insertIstgEamIntfcAmsMaster(final Param param) throws SQLException  {
		session.update("com.softworks.springframework.IfItsEamIntfcAmsMaster.insertIstg", param);
	}

    /*
     * ISTG_ITS_SKE_HWINVENTORY 데이터를 IF_ITS_SKE_HWINVENTORY에 저장
     */
	@Transactional(readOnly=true)
	public void insertSkeHwinventory(final Param param) throws SQLException  {
		session.update("com.softworks.springframework.IfItsSkeHwinventory.insert", param);
	}

    /*
     * ISTG_ITS_SKE_SWVIEW 데이터를 IF_ITS_SKE_SWVIEW에 저장
     */
	@Transactional(readOnly=true)
	public void insertSkeSwview(final Param param) throws SQLException  {
		session.update("com.softworks.springframework.IfItsSkeSwview.insert", param);
	}

    /*
     * ISTG_ITS_MST_APPL 데이터를 IF_ITS_MST_APPL에 저장
     */
	@Transactional(readOnly=true)
	public void insertMstAppl(final Param param) throws SQLException  {
		session.update("com.softworks.springframework.IfItsMstAppl.insert", param);
	}

    /*
     * ISTG_ITS_MST_APPL_DETAIL 데이터를 IF_ITS_MST_APPL_DETAIL에 저장
     */
	@Transactional(readOnly=true)
	public void insertMstApplDetail(final Param param) throws SQLException  {
		session.update("com.softworks.springframework.IfItsMstApplDetail.insert", param);
	}

    /*
     * ISTG_ITS_MST_APPL_SECURITY 데이터를 IF_ITS_MST_APPL_SECURITY에 저장
     */
	@Transactional(readOnly=true)
	public void insertMstApplSecurity(final Param param) throws SQLException  {
		session.update("com.softworks.springframework.IfItsMstApplSecurity.insert", param);
	}

    /*
     * ISTG_ITS_MST_APPL_SECURITY 데이터를 IF_ITS_MST_APPL_SECURITY에 저장
     */
	@Transactional(readOnly=true)
	public void insertEamIntfcAmsMaster(final Param param) throws SQLException  {
		session.update("com.softworks.springframework.IfItsEamIntfcAmsMaster.insert", param);
	}

    /*
     * IF_ITS_MST_APPL에 코드에 대한 코드명을 저장
     */
	@Transactional(readOnly=true)
	public void updateCodeName(final Param param) throws SQLException  {
		session.update("com.softworks.springframework.IfItsMstAppl.updateCodeName", param);
	}

    /*
     * ISTG_ITS_SKE_HWINVENTORY 비움
     */
	@Transactional(readOnly=true)
	public void deleteIstgSkeHwinventory(final Param param) {
		session.update("com.softworks.springframework.IfItsSkeHwinventory.deleteIstg", param);
	}

    /*
     * ISTG_ITS_SKE_SWVIEW에 비움
     */
	@Transactional(readOnly=true)
	public void deleteIstgSkeSwview(final Param param) {
		session.update("com.softworks.springframework.IfItsSkeSwview.deleteIstg", param);
	}

    /*
     * ISTG_ITS_MST_APPL에 비움
     */
	@Transactional(readOnly=true)
	public void deleteIstgMstAppl(final Param param) {
		session.update("com.softworks.springframework.IfItsMstAppl.deleteIstg", param);
	}

    /*
     * ISTG_ITS_MST_APPL_DETAIL에 비움
     */
	@Transactional(readOnly=true)
	public void deleteIstgMstApplDetail(final Param param) {
		session.update("com.softworks.springframework.IfItsMstApplDetail.deleteIstg", param);
	}

    /*
     * ISTG_ITS_MST_APPL_SECURITY에 비움
     */
	@Transactional(readOnly=true)
	public void deleteIstgMstApplSecurity(final Param param) {
		session.update("com.softworks.springframework.IfItsMstApplSecurity.deleteIstg", param);
	}

    /*
     * ISTG_ITS_MST_APPL_SECURITY에 비움
     */
	@Transactional(readOnly=true)
	public void deleteIstgEamIntfcAmsMaster(final Param param) {
		session.update("com.softworks.springframework.IfItsEamIntfcAmsMaster.deleteIstg", param);
	}

    /*
     * IF_ITS_SKE_HWINVENTORY 비움
     */
	@Transactional(readOnly=true)
	public void deleteSkeHwinventory(final Param param) {
		session.update("com.softworks.springframework.IfItsSkeHwinventory.delete", param);
	}

    /*
     * IF_ITS_SKE_SWVIEW에 비움
     */
	@Transactional(readOnly=true)
	public void deleteSkeSwview(final Param param) {
		session.update("com.softworks.springframework.IfItsSkeSwview.delete", param);
	}

    /*
     * IF_ITS_MST_APPL에 비움
     */
	@Transactional(readOnly=true)
	public void deleteMstAppl(final Param param) {
		session.update("com.softworks.springframework.IfItsMstAppl.delete", param);
	}

    /*
     * IF_ITS_MST_APPL_DETAIL에 비움
     */
	@Transactional(readOnly=true)
	public void deleteMstApplDetail(final Param param) {
		session.update("com.softworks.springframework.IfItsMstApplDetail.delete", param);
	}

    /*
     * IF_ITS_MST_APPL_SECURITY에 비움
     */
	@Transactional(readOnly=true)
	public void deleteMstApplSecurity(final Param param) {
		session.update("com.softworks.springframework.IfItsMstApplSecurity.delete", param);
	}

    /*
     * IF_ITS_MST_APPL_SECURITY에 비움
     */
	@Transactional(readOnly=true)
	public void deleteEamIntfcAmsMaster(final Param param) {
		session.update("com.softworks.springframework.IfItsEamIntfcAmsMaster.delete", param);
	}

}
