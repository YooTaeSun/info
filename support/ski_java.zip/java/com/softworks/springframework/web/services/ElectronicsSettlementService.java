package com.softworks.springframework.web.services;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;

@Service
public class ElectronicsSettlementService extends BaseService {

	@Transactional(readOnly=true)
	public int getItemId(Param param) {
		return session.selectOne("com.softworks.springframework.ElectronicsSettlement.getItemId", param);
	}

	public void insertDoc(final Param param) {
		session.insert("com.softworks.springframework.ElectronicsSettlement.insertDoc", param);
	}

	public void insertHist(final Param param) {
		session.insert("com.softworks.springframework.ElectronicsSettlement.insertHist", param);
	}

}
