package com.softworks.springframework.web.services.front;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;

@Service
public class ApplPiiaItemsService extends BaseService {

	@Transactional(readOnly=true)
	public int getListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));

		return session.selectOne("com.softworks.springframework.ApplPiiaItems.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) {
		return session.selectList("com.softworks.springframework.ApplPiiaItems.getList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getAllList(final Param param) {
		return session.selectList("com.softworks.springframework.ApplPiiaItems.getAllList", param);
	}

	@Transactional(readOnly=true)
	public Param getDetail(Param param) {
		return session.selectOne("com.softworks.springframework.ApplPiiaItems.getAllList", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int insert(final Param param) throws SQLException {
		return session.insert("com.softworks.springframework.ApplPiiaItems.insert", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void update(final Param param) throws Exception {
		session.update("com.softworks.springframework.ApplPiiaItems.update", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void delete(final Param param) throws Exception {
		session.delete("com.softworks.springframework.ApplPiiaItems.delete", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void merge(final Param param) throws Exception {
		session.update("com.softworks.springframework.ApplPiiaItems.merge", param);
	}

	@Transactional(readOnly=true)
	public HashMap<String, Object> detailAttr(final Param param) {
		HashMap resultMap = new Param();

		resultMap.put("list", this.getAllList(param));

		param.put("eval_grp_cd", "PIIA");
		resultMap.put("securityEvalList", session.selectList("com.softworks.springframework.ApplPiiaItems.securityEvalList", param));
		resultMap.put("sumCount", session.selectOne("com.softworks.springframework.ApplPiiaItems.getSumCount", param));
		return resultMap;
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void detailAttrRegist(final Param param, List<?> list) throws Exception {

		if(list != null && list.size() > 0 ) {

			String app_no = (String) ((HashMap)list.get(0)).get("app_no");
			String uid = param.get("uid");
			String uname = param.get("uname");
			String eval_day = Utils.getTimeStampString("yyyyMMdd");
			Param insertParam = null;
			HashMap el = null;

				for (int i = 0, len = list.size(); i < len; i++) {
					el = new Param((HashMap)list.get(i));
					insertParam = new Param();
					insertParam.set("app_no", app_no);
					insertParam.set("eval_item_id", el.get("eval_item_id").toString());
					insertParam.set("eval_result_cd", el.get("eval_result_cd").toString());
					insertParam.set("uid", uid);
					insertParam.set("uname", uname);
					insertParam.set("eval_emp_no", uid);
					insertParam.set("eval_emp_nm", uname);
					insertParam.set("eval_day", eval_day);
					this.merge(insertParam);
				}
		}
	}

}
