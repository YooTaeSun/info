package com.softworks.springframework.web.services.backoffice;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class CodeService extends BaseService {

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) {
		return session.selectList("com.softworks.springframework.Code.getList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getCodeList(Param param) {
		return session.selectList("com.softworks.springframework.Code.getCodeList", param);
	}

	@Transactional(readOnly=true)
	public Param getInfo(final String code) {
		return (Param)session.selectOne("com.softworks.springframework.Code.getInfo", code);
	}
	
	public boolean insert(final Param param) throws SQLException {
		return 0 < session.insert("com.softworks.springframework.Code.insert", param);
	}
	
	public boolean update(final Param param) throws SQLException {
		return 0 < session.insert("com.softworks.springframework.Code.update", param);
	}
	
	public boolean delete(final Param param) throws SQLException {
		return 0 < session.insert("com.softworks.springframework.Code.delete", param);
	}
	
}
