package com.softworks.springframework.web.services.backoffice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;
import com.softworks.springframework.web.services.AttachFileService;

@Service
public class MetaSecurityService extends BaseService {
	
	@Autowired
	private	AttachFileService attachFileSvc;
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public String updateFileId(final Param param) throws Exception {
		
		String atchFileId  = attachFileSvc.getAtchFileId();
		
		Param updateParam = new Param();
		updateParam.put("checklist_id", param.get("checklist_id"));
		updateParam.put("atch_file_id", atchFileId);
		
		int resultInt = session.update("com.softworks.springframework.MetaSecurity.updateFileId", updateParam);
		
		return (resultInt > 0 )? atchFileId : "";
	}
	
	@Transactional(readOnly=true)
	public int getCheckListCount(Param param) {
		return session.selectOne("com.softworks.springframework.MetaSecurity.getCheckListCount", param);
	}

//	@Transactional(readOnly=true)
	public List<Param> getCheckList(Param param) {
		return session.selectList("com.softworks.springframework.MetaSecurity.getCheckList", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertCheckList(final Param param) throws Exception {
		session.insert("com.softworks.springframework.MetaSecurity.insertCheckList", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertCheckListHistory(final Param param) throws Exception {
		session.insert("com.softworks.springframework.MetaSecurity.insertCheckListHistory", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertServiceCheckList(final Param param) throws Exception {
		param.set("chg_typ_cd", "C");
		insertCheckList(param);
		insertCheckListHistory(param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateCheckList(final Param param) throws Exception {
		session.update("com.softworks.springframework.MetaSecurity.updateCheckList", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateServiceCheckList(final Param param) throws Exception {
		param.set("chg_typ_cd", "U");
		updateCheckList(param);
		insertCheckListHistory(param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteCheckList(final Param param) throws Exception {
		session.delete("com.softworks.springframework.MetaSecurity.deleteCheckList", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteServiceCheckList(final Param param) throws Exception {
		Param resultOne = getCheckListOne(param);
		param.set("chg_typ_cd", "D");
		param.set("chk_item_cd",     resultOne.get("CHK_ITEM_CD"));
		param.set("checklist_nm",    resultOne.get("CHECKLIST_NM"));
		param.set("checklist_desc",  resultOne.get("CHECKLIST_DESC"));
		param.set("checklist_point", resultOne.get("CHECKLIST_POINT"));
		param.set("aply_start_day",  resultOne.get("APLY_START_DAY"));
		param.set("mng_org_cd",      resultOne.get("MNG_ORG_CD"));
		param.set("repeat_cycle_cd", resultOne.get("REPEAT_CYCLE_CD"));
		param.set("noti_date",       resultOne.get("NOTI_DATE"));
		param.set("noti_property_cd",resultOne.get("NOTI_PROPERTY_CD"));
		param.set("approval_yn",     resultOne.get("APPROVAL_YN"));
		param.set("secu_yn",         resultOne.get("SECU_YN"));
		param.set("legal_term_kor",  resultOne.get("LEGAL_TERM_KOR"));
		param.set("legal_term_eng",  resultOne.get("LEGAL_TERM_ENG"));
		param.set("reg_id",          resultOne.get("REG_ID"));
		insertCheckListHistory(param);
		deleteCheckList(param);
	}
	
	@Transactional(readOnly=true)
	public Param getCheckListOne(Param param) {
		return session.selectOne("com.softworks.springframework.MetaSecurity.getCheckListOne", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getCheckListList(Param param) {
		return session.selectList("com.softworks.springframework.MetaSecurity.getCheckListList", param);
	}
	
	@Transactional(readOnly=true)
	public int getCheckListHistCount(Param param) {
		param.set("pageSize", param.getInt("pageSize", DEFAULT_PAGE_SIZE));
		
		return session.selectOne("com.softworks.springframework.MetaSecurity.getCheckListHistCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getCheckListHistList(Param param) {
		return session.selectList("com.softworks.springframework.MetaSecurity.getCheckListHistList", param);
	}
	
	

}