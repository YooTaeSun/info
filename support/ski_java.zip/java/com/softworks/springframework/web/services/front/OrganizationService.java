package com.softworks.springframework.web.services.front;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class OrganizationService extends BaseService {

//	@Transactional(readOnly=true)
//	public int getListCount(final Param param) {
//		param.set("page", new Integer(param.getInt("page", 1)));
//		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
//
//		return session.selectOne("com.softworks.springframework.Organization.getListCount", param);
//	}

	 
	@Transactional(readOnly=true)
	public List<Param> getComList(final Param param) {
		return session.selectList("com.softworks.springframework.Organization.getComList", param);
	}
	
	
	
	@Transactional(readOnly=true)
	public List<Param> getTopDeptList(final Param param) {
		return session.selectList("com.softworks.springframework.Organization.getTopDeptList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getTreeList(final Param param) {
		return session.selectList("com.softworks.springframework.Organization.getTreeList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) {
		return session.selectList("com.softworks.springframework.Organization.getList", param);
	}

//	@Transactional(readOnly=true)
//	public List<Param> getAllList(final Param param) {
//		return session.selectList("com.softworks.springframework.Organization.getAllList", param);
//	}
//
//	@Transactional(readOnly=true)
//	public Param getDetail(Param param) {
//		return session.selectOne("com.softworks.springframework.Organization.getList", param);
//	}
//
//	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
//	public boolean insert(final Param param) throws SQLException {
//		return 0 < session.insert("com.softworks.springframework.Organization.insert", param);
//	}
//
//	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
//	public void update(final Param param) throws Exception {
//		session.update("com.softworks.springframework.Organization.update", param);
//	}
//
//	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
//	public void delete(final Param param) throws Exception {
//		session.delete("com.softworks.springframework.Organization.delete", param);
//	}

}
