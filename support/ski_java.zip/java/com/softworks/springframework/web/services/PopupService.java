package com.softworks.springframework.web.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class PopupService extends BaseService {

	public int getUserListCountOld(final Param param) throws Exception {
		return (Integer)session.selectOne("com.softworks.springframework.User.getListCount", param);
	}

	public List<Param> getUserListOld(final Param param) throws Exception {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*DEFAULT_PAGE_SIZE));
		
		return session.selectList("com.softworks.springframework.User.getList", param);
	}

	public int getUserListCount(final Param param) throws Exception {
		return (Integer)session.selectOne("com.softworks.springframework.IfHrEmp.getListCount", param);
	}

	public List<Param> getUserList(final Param param) throws Exception {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", 5)));
		param.set("limitSize", new Integer((param.getInt("page") - 1) * 5));
		
		return session.selectList("com.softworks.springframework.IfHrEmp.getList", param);
	}

}
