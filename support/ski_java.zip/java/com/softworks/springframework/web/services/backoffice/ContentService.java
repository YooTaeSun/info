package com.softworks.springframework.web.services.backoffice;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class ContentService extends BaseService {

	@Transactional(readOnly=true)
	public int getListCount(final Param param) throws Exception {
		return (Integer)session.selectOne("com.softworks.springframework.Content.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) throws Exception {
		return session.selectList("com.softworks.springframework.Content.getList", param);
	}

	@Transactional(readOnly=true)
	public Param getInfo(final int seq) throws Exception {
		return (Param)session.selectOne("com.softworks.springframework.Content.getInfo", seq);
	}
	
	public void insert(final Param param) throws Exception {
		session.insert("com.softworks.springframework.Content.insert", param);
	}
	
	public void update(final Param param) throws Exception {
		session.insert("com.softworks.springframework.Content.update", param);
	}
	
	public void delete(final Param param) throws Exception {
		session.insert("com.softworks.springframework.Content.delete", param);
	}

}
