package com.softworks.springframework.web.services.front;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.AttachFileService;
import com.softworks.springframework.web.services.BaseService;

@Service
public class ComplianceService extends BaseService {
	
	@Autowired
	private	SecuManagerDetailService			        secuManagerDetailService;
	
	@Autowired
	private	AttachFileService attachFileSvc;
	
	
	@Transactional(readOnly=true)
	public List<Param> getAreaCdAvgLevelList(final Param param) {
		return session.selectList("com.softworks.springframework.Compliance.getAreaCdAvgLevelList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getAreaCdAvgLevelSubList(final Param param) {
		return session.selectList("com.softworks.springframework.Compliance.getAreaCdAvgLevelSubList", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public String updateFileId(final Param param) throws Exception {
		
		String atchFileId  = attachFileSvc.getAtchFileId();
		
		Param updateParam = new Param();
		updateParam.put("checklist_id", param.get("checklist_id"));
		updateParam.put("atch_file_id", attachFileSvc.getAtchFileId());
		
		attachFileSvc.insert(updateParam);  //파일 시퀀스 저장
		int resultInt = session.update("com.softworks.springframework.Compliance.updateFileId", updateParam);
		
		return (resultInt > 0 )? atchFileId : "";
	}
	
	@Transactional(readOnly=true)
	public List<Param> getCheckListAllList(Param param) {
		return session.selectList("com.softworks.springframework.Compliance.getCheckListAllList", param);
	}
	
	@Transactional(readOnly=true)
	public Param getCheckListOne(Param param) {
		return session.selectOne("com.softworks.springframework.Compliance.getCheckListOne", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getCheckListEvalAllList(Param param) {
		return session.selectList("com.softworks.springframework.Compliance.getCheckListEvalAllList", param);
	}
	
	@Transactional(readOnly=true)
	public Param getCheckListEvalOne(Param param) {
		return session.selectOne("com.softworks.springframework.Compliance.getCheckListEvalOne", param);
	}
	
	@Transactional(readOnly=true)
	public int getCheckListCount(Param param) {
		return session.selectOne("com.softworks.springframework.Compliance.getCheckListCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getCheckList(Param param) {
		return session.selectList("com.softworks.springframework.Compliance.getCheckList", param);
	}
	
	@Transactional(readOnly=true)
	public int getLawCheckListCount(Param param) {
		return session.selectOne("com.softworks.springframework.Compliance.getLawCheckListCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getLawCheckList(Param param) {
		return session.selectList("com.softworks.springframework.Compliance.getLawCheckList", param);
	}
	
	public void updateSecurityChecklistEval(final Param param) throws Exception {
		session.update("com.softworks.springframework.Compliance.updateSecurityChecklistEval", param);
	}
	
	public void updateSecurityChecklistEval1(final Param param) throws Exception {
		session.update("com.softworks.springframework.Compliance.updateSecurityChecklistEval1", param);
	}
	
	public void updateSecurityChecklistEval2(final Param param) throws Exception {
		session.update("com.softworks.springframework.Compliance.updateSecurityChecklistEval2", param);
	}
	
	public List<Param> getComplianceManagerService(Param param)throws Exception {
		Param	getCheckOne = getCheckListOne(param);
		String manager_id = Utils.nvl(getCheckOne.get("MANAGER_ID"));
		List<Param>	managerDetailList = new ArrayList<Param>();
		
		if(!"".equals(manager_id)){
			param.set("manager_id", manager_id);
			managerDetailList = secuManagerDetailService.getAllList(param);
		}
		
		return managerDetailList;
	}
	
	public boolean updateSecurityChecklist(Param param) throws SQLException {
		return 0 < session.update("com.softworks.springframework.Compliance.updateSecurityChecklist", param);
	}
	
	public boolean updateSecurityChecklist1(Param param) throws SQLException {
		return 0 < session.update("com.softworks.springframework.Compliance.updateSecurityChecklist1", param);
	}
	
	@Transactional(readOnly=true)
	public int insertSecurityChecklistManager(Param param)throws Exception {
		int resultInt = 0;
		
		Param	getCheckOne = getCheckListOne(param);
		String manager_id = Utils.nvl(getCheckOne.get("MANAGER_ID"));
		param.set("manager_id", manager_id);
		if("".equals(manager_id)) {
			//----------- sequence manager_id 생성  -----------------
			manager_id = session.selectOne("com.softworks.springframework.SecuManager.getSequence", param);
			param.set("manager_id", manager_id);
			//----------- SECU_MANAGER merge -----------------
			session.insert("com.softworks.springframework.SecuManager.merge", param);
			
			updateSecurityChecklist(param);
		}
		
		param.set("privilege_cd_id", "CHKLIST_PRIVILEGE_CD");//CHKLIST_PRIVILEGE_CD 보안통제항목 권한 구분 코드
		param.set("office_tel_no", "");
		
		Param selectParam = new Param();
		selectParam.put("manager_id", (String)param.get("manager_id"));
		selectParam.put("company_cd", (String)param.get("company_cd"));
		selectParam.put("emp_no", (String)param.get("emp_no"));
		
		List<Param> secuManagerDetailList = session.selectList("com.softworks.springframework.SecuManagerDetail.getAllList", selectParam);
		if(secuManagerDetailList != null && secuManagerDetailList.size() > 0) {
			return 1;
		}

		/*
		if(!"O".equals(param.get("privilege_cd"))){  //책임자, 관리자 일경우에만(D:책임자, M:관리자, O:운영자)
			Param selectParam2 = new Param();
			selectParam2.put("manager_id", (String)param.get("manager_id"));
			selectParam2.put("privilege_cd_id", "CHKLIST_PRIVILEGE_CD");
			selectParam2.put("privilege_cd", (String)param.get("privilege_cd"));
			
			List<Param> secuManagerDetailListPrivilege = session.selectList("com.softworks.springframework.SecuManagerDetail.getAllList", selectParam2);
			if(secuManagerDetailListPrivilege != null && secuManagerDetailListPrivilege.size() > 0) {
				return 2;
			}
		}
		*/
		
		session.insert("com.softworks.springframework.SecuManagerDetail.insert", param);
		
		return resultInt;
	}
	
	@Transactional(readOnly=true)
	public int deleteSecurityChecklistManager(Param param)throws Exception {
		int resultInt = 0;
		
		Param	getCheckOne = getCheckListOne(param);
		String manager_id = Utils.nvl(getCheckOne.get("MANAGER_ID"));
		param.set("manager_id", manager_id);
		
		session.delete("com.softworks.springframework.SecuManagerDetail.delete", param);
		
		return resultInt;
	}
	
	@Transactional(readOnly=true)
	public int updateSecurityChecklistArr(Param param)throws Exception {
		int resultInt = 0;
		
		String goal_level_cd = Utils.nvl(param.get("goal_level_cd"));
		String checklist_id_arr = Utils.nvl(param.get("checklist_id_arr"));
		String checklist_id_arr2 [] = checklist_id_arr.split(",");
		
		Param setParam = new Param();
		setParam.set("goal_level_cd", goal_level_cd);
		setParam.set("upd_id", param.get("upd_id"));
		setParam.set("upd_nm", param.get("upd_nm"));
		for(String checklist_id : checklist_id_arr2){
			setParam.set("checklist_id", checklist_id);	
			updateSecurityChecklistEval2(setParam);
		}
		
		return resultInt;
	}
	
	public void updateSecurityCheckFileReg(final Param param) throws Exception {
		session.update("com.softworks.springframework.Compliance.updateSecurityCheckFileReg", param);
	}
	
	@Transactional(readOnly=true)
    public void getListExcel100(final Param param, final ModelMap model) throws SQLException {

		int[]	 colWidth	= {20, 20, 20, 20, 20, 20, 20, 20};
		model.addAttribute("category", new String[] { "코드", "진단 항목", "ID" , "체크리스트", "부서평가", "진행경과", "자체평가", "목표수준"  
                 });
        
        model.addAttribute("columns", new String[] { "CHK_ITEM_CD", "CHK_ITEM_NM", "CHECKLIST_ID", "CHECKLIST_NM", "DEPT_EVAL_CD", "PROC_RESULT_CD_NM", "SECU_EVAL_CD", "GOAL_LEVEL_CD"
                });
    
        model.addAttribute("columnsWidth", colWidth);
        model.addAttribute("chapter", "진단영역별체크리스트");
        model.addAttribute("filename", "진단영역별체크리스트_"+param.get("code")+"_"+Utils.getTimeStampString("yyyyMMdd"));
           
        model.addAttribute("data", session.selectList("com.softworks.springframework.Compliance.getCheckList", param));
        
    }
	
	@Transactional(readOnly=true)
    public void getListExcel102(final Param param, final ModelMap model) throws SQLException {

		int[]	 colWidth	= {20, 20, 20, 20, 20, 20, 20, 20};
		model.addAttribute("category", new String[] { "ID", "점검 사항", "체크리스트ID" , "체크리스트", "부서평가", "진행경과", "내부평가", "목표수준"  
                 });
        
        model.addAttribute("columns", new String[] { "LS_ITEM_ID", "LS_ITEM_DETAIL", "CHECKLIST_ID", "CHECKLIST_NM", "DEPT_EVAL_CD", "PROC_RESULT_CD_NM", "SECU_EVAL_CD", "GOAL_LEVEL_CD"
                });
    
        model.addAttribute("columnsWidth", colWidth);
        model.addAttribute("chapter", "법_제도별체크리스트"+"_"+param.get("LS_ABBR_NM"));
        model.addAttribute("filename", "법_제도별체크리스트"+"_"+param.get("LS_ABBR_NM")+"_"+Utils.getTimeStampString("yyyyMMdd"));
           
        model.addAttribute("data", session.selectList("com.softworks.springframework.Compliance.getLawCheckList", param));
        
    }
	
}