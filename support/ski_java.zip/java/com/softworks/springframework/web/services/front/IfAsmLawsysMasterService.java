package com.softworks.springframework.web.services.front;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class IfAsmLawsysMasterService extends BaseService {

	@Transactional(readOnly=true)
	public List<Param> getAllList(final Param param) {
		return session.selectList("com.softworks.springframework.IfAsmLawsysMaster.getAllList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getDetail(final Param param) {
		return session.selectList("com.softworks.springframework.IfAsmLawsysMaster.getDetail", param);
	}
}
