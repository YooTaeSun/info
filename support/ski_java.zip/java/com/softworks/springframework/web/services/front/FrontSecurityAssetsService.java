package com.softworks.springframework.web.services.front;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;
import com.softworks.springframework.web.services.backoffice.SecurityAssetsService;

@Service
public class FrontSecurityAssetsService extends BaseService {
	
	@Autowired
	private	SecurityAssetsService			securityAssetsService;
	
	@Transactional(readOnly=true)
	public Param getSecurityAssetsEvalOne(Param param) {
		return session.selectOne("com.softworks.springframework.frontSecurityAssets.getSecurityAssetsEvalOne", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getMetaEvalSecurityAssetsEvalList(Param param) {
		return session.selectList("com.softworks.springframework.frontSecurityAssets.getMetaEvalSecurityAssetsEvalList", param);
	}
	
	@Transactional(readOnly=true)
	public int getSecurityAssetsApplListCount(Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*10));

		return session.selectOne("com.softworks.springframework.frontSecurityAssets.getSecurityAssetsApplListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getSecurityAssetsApplList(Param param) {
		return session.selectList("com.softworks.springframework.frontSecurityAssets.getSecurityAssetsApplList", param);
	}
	
	@Transactional(readOnly=true)
	public int getSecurityAssetsInfraListCount(Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*10));

		return session.selectOne("com.softworks.springframework.frontSecurityAssets.getSecurityAssetsInfraListCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getSecurityAssetsInfraList(Param param) {
		return session.selectList("com.softworks.springframework.frontSecurityAssets.getSecurityAssetsInfraList", param);
	}
	
	@Transactional(readOnly=true)
	public int getSecurityAssetsServerListCount(Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*10));

		return session.selectOne("com.softworks.springframework.frontSecurityAssets.getSecurityAssetsServerListCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getSecurityAssetsServerList(Param param) {
		return session.selectList("com.softworks.springframework.frontSecurityAssets.getSecurityAssetsServerList", param);
	}
	
	@Transactional(readOnly=true)
	public int getSecurityAssetsNetworkListCount(Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*10));

		return session.selectOne("com.softworks.springframework.frontSecurityAssets.getSecurityAssetsNetworkListCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getSecurityAssetsNetworkList(Param param) {
		return session.selectList("com.softworks.springframework.frontSecurityAssets.getSecurityAssetsNetworkList", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertSecurityAssetsEval(Param param) {
		session.insert("com.softworks.springframework.frontSecurityAssets.insertSecurityAssetsEval", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateSecurityAssetsEval(final Param param) throws Exception {
		session.update("com.softworks.springframework.frontSecurityAssets.updateSecurityAssetsEval", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateSecurityAssetsEvalService(Param param) throws Exception {
		
		Param evalOne = getSecurityAssetsEvalOne(param);
		if(evalOne == null){
			if("eval_state_cd".equals(param.get("eval_gubun"))){  //평가상태값
				param.set("eval_emp_no", param.get("reg_id"));
				param.set("eval_emp_nm", param.get("reg_nm"));
			}else{  //점검상태값
				param.set("chk_emp_no", param.get("reg_id"));
				param.set("chk_emp_nm", param.get("reg_nm"));
			}
			insertSecurityAssetsEval(param);
		}else{
			if("eval_state_cd".equals(param.get("eval_gubun"))){  //평가상태값
				param.set("eval_emp_no", param.get("reg_id"));
				param.set("eval_emp_nm", param.get("reg_nm"));
			}else{  //점검상태값
				param.set("chk_emp_no", param.get("reg_id"));
				param.set("chk_emp_nm", param.get("reg_nm"));
			}
			updateSecurityAssetsEval(param);
		}
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertSecurityAssetsEvalList(Param param) {
		session.insert("com.softworks.springframework.frontSecurityAssets.insertSecurityAssetsEvalList", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteSecurityAssetsEvalList(final Param param) throws Exception {
		session.delete("com.softworks.springframework.frontSecurityAssets.deleteSecurityAssetsEvalList", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateSecurityAssetsEvalListService(Param param) throws Exception {
		
		deleteSecurityAssetsEvalList(param);
		
		for(String evalItemid : param.getValues("evalItemid_arr")){
			Param evalListParam = new Param();
			evalListParam.set("asset_seq", param.get("asset_seq"));
			evalListParam.set("eval_grp_cd", param.get("eval_grp_cd"));
			evalListParam.set("eval_item_id", evalItemid);
			evalListParam.set("eval_cd", param.get("eval_cd"));
			evalListParam.set("reg_id", param.get("reg_id"));
			evalListParam.set("reg_nm", param.get("reg_nm"));
			insertSecurityAssetsEvalList(evalListParam);
		}
	}
	
	@Transactional(readOnly=true)
    public void getSecurityAssetsApplListExcel(final Param param, final ModelMap model) throws SQLException {

		List<Param> resultList = session.selectList("com.softworks.springframework.frontSecurityAssets.getSecurityAssetsApplListExcel", param);

		for(Param temp : resultList){
			String app_no = temp.get("APP_NO");
			Param	paramOne	= new Param();
			paramOne.set("app_no", app_no);
			List<Param> ifItsMstApplList = securityAssetsService.getIfItsMstApplList(paramOne);
			for(int i=0; i < ifItsMstApplList.size(); i++){
				Param appl = ifItsMstApplList.get(i);
				String name = appl.get("NAME");
				String column_value = appl.get("COLUMN_VALUE");
				temp.set("name"+i, name);
				temp.set("value"+i, column_value);
			}
			
			String cvalue = "";
			List<Param> vItsApplCompany = securityAssetsService.getVItsApplCompany(paramOne);
			for(int i=0; i < vItsApplCompany.size(); i++){
				Param appl = vItsApplCompany.get(i);
				cvalue = cvalue + appl.get("SKCOMPANYNAME")+"/"+appl.get("TEAMNAMEMAIN");
				if(i != vItsApplCompany.size()-1){
					cvalue = cvalue + ",";
				}
			}
			temp.set("cvalue", cvalue);
		}
		
		int[]	 colWidth	= {20, 20
							 , 20, 20, 20
							 , 20, 20, 20
							 , 20, 20, 20
							 , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20
							 
		};
		model.addAttribute("category", new String[] { "App.번호", "정보시스템명" 
													, "현업", "BA", "운영자"
													, "오픈일자", "폐기일자", "사용여부"
													, "평가상태", "평가일", "점검상태"
													, "약어", "정보시스템명"
													, "App.분류(대)", "App.분류(중)"
													, "App.분류(소)", "오픈일자"
													, "폐기일자", "현업담당자"
													, "BA", "운영자"
													, "ERP담당자", "SLA대상여부"
													, "Portfolio 서비스중요도", "가용시간"
													, "공용/전사/전용", "AM운영형태"
													, "개발형태", "외부망접속가능"
													, "URL", "SSL"
													, "SSO등록여부", "ID신청가능여부"
													, "사용회사/주관부서"
                 });
        
        model.addAttribute("columns", new String[] { "APP_NO", "APP_KOR_NM"
        										   , "WORK_EMP_NM", "BA_EMP_NM", "OP_EMP_NM"
        										   , "OPEN_DAY", "END_DAY", "USE_YN"
        										   , "EVAL_STATE_CD_TEXT", "EVAL_DAY", "EVAL_CHK_CD_TEXT"
        										   , "value0", "value1"
        										   , "value2", "value3"
        										   , "value4", "value5"
        										   , "value6", "value7"
        										   , "value8", "value9"
        										   , "value10", "value11"
        										   , "value12", "value13"
        										   , "value14", "value15"
        										   , "value16", "value17"
        										   , "value18", "value19"
        										   , "value20", "value21"
        										   , "cvalue"
                });
    
        model.addAttribute("columnsWidth", colWidth);
        model.addAttribute("chapter", "정보시스템자산");
        model.addAttribute("filename", "정보시스템자산"+"_"+Utils.getTimeStampString("yyyyMMdd"));
           
        model.addAttribute("data", resultList);
        
    }
	
	@Transactional(readOnly=true)
    public void getSecurityAssetsInfraListExcel(final Param param, final ModelMap model) throws SQLException {

		List<Param> resultList = session.selectList("com.softworks.springframework.frontSecurityAssets.getSecurityAssetsInfraListExcel", param);

		for(Param temp : resultList){
			String conf_id = temp.get("CONF_ID");
			Param	paramOne	= new Param();
			paramOne.set("conf_id", conf_id);
			Param vItsAssetInfraOne = securityAssetsService.getVItsAssetInfraOne(paramOne);
			temp.putAll(vItsAssetInfraOne);
		}
		
		int[]	 colWidth	= { 20, 20, 20, 20
							  , 20, 20, 20
							  , 20, 20, 20
							  , 20, 20, 20, 20
							  , 20, 20, 20
							  , 20, 20
							  , 20, 20, 20
							  , 20, 20, 20
							 };
		model.addAttribute("category", new String[] { "SW구분", "구성ID", "자산관리번호", "App.번호" 
													, "정보시스템명", "운영자", "자산상태"
													, "평가상태", "평가일", "점검상태"
													, "자산분류(대)", "자산분류(중)", "자산분류(소)", "고객사"
													, "자산상태", "도입년도", "모델명"
													, "구성ID", "APP.번호", "자산관리번호"
													, "설치장소", "장비용도"
													, "운영부서", "운영자1", "운영자2"
													, "사용부서", "사용자1", "사용자2"
		});
									
		model.addAttribute("columns", new String[] { "INFRA_SW_TYP", "CONF_ID", "ASSET_MGMT_NO", "APP_NO"
												   , "APP_KOR_NM", "OPR_1_EMP_NM", "ASSET_STAT"
												   , "EVAL_STATE_CD_TEXT", "EVAL_DAY", "EVAL_CHK_CD_TEXT"
												   , "ASSET_TOP_NM", "ASSET_MID_NM", "ASSET_BOT_NM", "CUST_COMPANY_NM"
        										   , "ASSET_STAT", "INTRO_YEAR", "MODEL_NM"
        										   , "CONF_ID", "", "ASSET_MGMT_NO"
        										   , "LOCA_NM", "EQUIP_USE"
        										   , "OPR_DEPT_NM", "OPR_1_EMP_NM", "OPR_2_EMP_NM"
        										   , "USE_DEPT_NM", "USE_1_EMP_NM", "USE_2_EMP_NM"
		});
    
		model.addAttribute("columnsWidth", colWidth);
        model.addAttribute("chapter", "데이터베이스자산");
        model.addAttribute("filename", "데이터베이스자산"+"_"+Utils.getTimeStampString("yyyyMMdd"));
           
        model.addAttribute("data", resultList);
        
    }

	@Transactional(readOnly=true)
    public void getSecurityAssetsServerListExcel(final Param param, final ModelMap model) throws SQLException {

		List<Param> resultList = session.selectList("com.softworks.springframework.frontSecurityAssets.getSecurityAssetsServerListExcel", param);

		for(Param temp : resultList){
			String conf_id = temp.get("CONF_ID");
			Param	paramOne	= new Param();
			paramOne.set("conf_id", conf_id);
			Param vItsAssetServerOne = securityAssetsService.getVItsAssetServerOne(paramOne);
			temp.putAll(vItsAssetServerOne);
		}
		
		int[]	 colWidth	= { 20, 20, 20
							  , 20, 20, 20
							  , 20, 20, 20
							  , 20, 20, 20, 20
							  , 20, 20, 20
							  , 20, 20
							  , 20, 20, 20
							  , 20, 20, 20
							  , 20, 20, 20, 20
							  , 20
							 };
		model.addAttribute("category", new String[] { "구성ID", "자산관리번호", "App.번호" 
													, "정보시스템명", "운영자", "자산상태"
													, "평가상태", "평가일", "점검상태"
													, "자산분류(대)", "자산분류(중)", "자산분류(소)", "고객사"
													, "자산상태", "도입년도", "모델명"
													, "구성ID", "APP.번호", "자산관리번호"
													, "정보시스템명", "장비용도"
													, "운영부서", "운영자1", "운영자2"
													, "사용부서", "사용자1", "사용자2"
													, "설치장소", "Host명", "OS", "OS Version"
													, "IP"
									});
									
		model.addAttribute("columns", new String[] { "CONF_ID", "ASSET_MGMT_NO", "APP_NO"
												   , "APP_KOR_NM", "OPR_1_EMP_NM", "ASSET_STAT"
												   , "EVAL_STATE_CD_TEXT", "EVAL_DAY", "EVAL_CHK_CD_TEXT"
												   , "ASSET_TOP_NM", "ASSET_MID_NM", "ASSET_BOT_NM", "CUST_COMPANY_NM"
        										   , "ASSET_STAT", "INTRO_YEAR", "MODEL_NM"
        										   , "CONF_ID", "", "ASSET_MGMT_NO"
        										   , "","EQUIP_USE"
        										   , "OPR_DEPT_NM", "OPR_1_EMP_NM", "OPR_2_EMP_NM"
        										   , "USE_DEPT_NM", "USE_1_EMP_NM", "USE_2_EMP_NM"
        										   , "LOCA_NM", "HOST_NM", "OS_NM", "OS_VER"
        										   , "IP_ADDR"
		});
    
		model.addAttribute("columnsWidth", colWidth);
        model.addAttribute("chapter", "서버");
        model.addAttribute("filename", "서버자산"+"_"+Utils.getTimeStampString("yyyyMMdd"));
           
        model.addAttribute("data", resultList);
        
    }
	
	@Transactional(readOnly=true)
    public void getSecurityAssetsNetworkListExcel(final Param param, final ModelMap model) throws SQLException {

		List<Param> resultList = session.selectList("com.softworks.springframework.frontSecurityAssets.getSecurityAssetsNetworkListExcel", param);

		for(Param temp : resultList){
			String conf_id = temp.get("CONF_ID");
			Param	paramOne	= new Param();
			paramOne.set("conf_id", conf_id);
			Param vItsAssetNetworkOne = securityAssetsService.getVItsAssetNetworkOne(paramOne);
			temp.putAll(vItsAssetNetworkOne);
		}
		
		int[]	 colWidth	= { 20, 20, 20
							  , 20, 20, 20
							  , 20, 20, 20
							  , 20, 20, 20, 20
							  , 20, 20, 20
							  , 20, 20, 20
							  , 20, 20
							  , 20, 20, 20
							  , 20, 20, 20
		};
		model.addAttribute("category", new String[] { "구성ID", "자산관리번호", "자산분류(소)" 
													, "도입년도", "운영자", "자산상태"
													, "평가상태", "평가일", "점검상태"
													, "자산분류(대)", "자산분류(중)", "자산분류(소)", "고객사"
													, "자산상태", "도입년도", "모델명"
													, "구성ID", "APP.번호", "자산관리번호"
													, "설치장소", "장비용도"
													, "운영부서", "운영자1", "운영자2"
													, "사용부서", "사용자1", "사용자2"
                 });
        
        model.addAttribute("columns", new String[] { "CONF_ID", "ASSET_MGMT_NO", "ASSET_BOT_NM"
        										   , "INTRO_YEAR", "OPR_1_EMP_NM", "ASSET_STAT"
        										   , "EVAL_STATE_CD_TEXT", "EVAL_DAY", "EVAL_CHK_CD_TEXT"
        										   , "ASSET_TOP_NM", "ASSET_MID_NM", "ASSET_BOT_NM", "CUST_COMPANY_NM"
        										   , "ASSET_STAT", "INTRO_YEAR", "MODEL_NM"
        										   , "CONF_ID", "", "ASSET_MGMT_NO"
        										   , "LOCA_NM", "EQUIP_USE"
        										   , "OPR_DEPT_NM", "OPR_1_EMP_NM", "OPR_2_EMP_NM"
        										   , "USE_DEPT_NM", "USE_1_EMP_NM", "USE_2_EMP_NM"
                });
    
        model.addAttribute("columnsWidth", colWidth);
        model.addAttribute("chapter", "네트워크");
        model.addAttribute("filename", "네트워크자산"+"_"+Utils.getTimeStampString("yyyyMMdd"));
           
        model.addAttribute("data", resultList);
        
    }
	
	@Transactional(readOnly=true)
    public void getSecurityAssetsSecuListExcel(final Param param, final ModelMap model) throws SQLException {

		List<Param> resultList = session.selectList("com.softworks.springframework.frontSecurityAssets.getSecurityAssetsApplListExcel", param);

		for(Param temp : resultList){
			String app_no = temp.get("APP_NO");
			Param	paramOne	= new Param();
			paramOne.set("app_no", app_no);
			List<Param> ifItsMstApplList = securityAssetsService.getIfItsMstApplList(paramOne);
			for(int i=0; i < ifItsMstApplList.size(); i++){
				Param appl = ifItsMstApplList.get(i);
				String name = appl.get("NAME");
				String column_value = appl.get("COLUMN_VALUE");
				temp.set("name"+i, name);
				temp.set("value"+i, column_value);
			}
			
			String cvalue = "";
			List<Param> vItsApplCompany = securityAssetsService.getVItsApplCompany(paramOne);
			for(int i=0; i < vItsApplCompany.size(); i++){
				Param appl = vItsApplCompany.get(i);
				cvalue = cvalue + appl.get("SKCOMPANYNAME")+"/"+appl.get("TEAMNAMEMAIN");
				if(i != vItsApplCompany.size()-1){
					cvalue = cvalue + ",";
				}
			}
			temp.set("cvalue", cvalue);
		}
		
		int[]	 colWidth	= {20, 20, 20
							 , 20, 20, 20
							 , 20, 20, 20
							 , 20, 20, 20
							 , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20, 20
				             , 20					 
				             , 20					 
							};
		model.addAttribute("category", new String[] { "App.번호", "정보시스템명", "정보시스템명" 
													, "현업", "BA", "운영자"
													, "오픈일자", "폐기일자", "사용여부"
													, "평가상태", "평가일", "점검상태"
													, "약어", "정보시스템명"
													, "App.분류(대)", "App.분류(중)"
													, "App.분류(소)", "오픈일자"
													, "현업담당자", "운영자"
													, "SSL"
													, "사용회사/주관부서"
									});

		model.addAttribute("columns", new String[] { "APP_NO", "APP_KOR_NM", "APP_LARGE_NM"
												   , "WORK_EMP_NM", "BA_EMP_NM", "OP_EMP_NM"
												   , "OPEN_DAY", "END_DAY", "USE_YN"
												   , "EVAL_STATE_CD_TEXT", "EVAL_DAY", "EVAL_CHK_CD_TEXT"
												   , "value0", "value1"
        										   , "value2", "value3"
        										   , "value4", "value5"
        										   , "value6", "value7"
        										   , "value8"
        										   , "cvalue"
									});
    
		model.addAttribute("columnsWidth", colWidth);
        model.addAttribute("chapter", "보안시스템자산");
        model.addAttribute("filename", "보안시스템자산"+"_"+Utils.getTimeStampString("yyyyMMdd"));
           
        model.addAttribute("data", resultList);
        
    }
	
}