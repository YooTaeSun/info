package com.softworks.springframework.web.services.backoffice;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;

@Service
public class SecurityRewardItemService extends BaseService {

	@Autowired
	private	SecurityRewardIndexService securityRewardIndexSvc;

	@Transactional(readOnly=true)
	public List<Param> getAllList(final Param param) {
		return session.selectList("com.softworks.springframework.SecurityRewardItem.getAllList", param);
	}

	@Transactional(readOnly=true)
	public Param getDetail(Param param) {
		return session.selectOne("com.softworks.springframework.SecurityRewardItem.getList", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int insert(final Param param) throws SQLException {
		return session.insert("com.softworks.springframework.SecurityRewardItem.insert", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void update(final Param param) throws SQLException {
		session.update("com.softworks.springframework.SecurityRewardItem.update", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void delete(final Param param) throws SQLException {
		session.delete("com.softworks.springframework.SecurityRewardItem.delete", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void regist(final Param param) throws SQLException {

		String reward_cd = Utils.nvl(param.get("reward_cd"),"");

		this.insert(param);
		String eval_item_id = param.get("eval_item_id");

		if("SV".equals(reward_cd)) {//보안 위반자
			 reward_cd = Utils.nvl(param.get("reward_cd"),"");

			 HashMap hashparam =  (HashMap)param;
			 List<LinkedHashMap> list =  (List<LinkedHashMap>)hashparam.get("list");

			 for (LinkedHashMap detail : list) {
				 detail.put("eval_item_id", eval_item_id);
				 detail.put("uid", param.get("uid"));
				 detail.put("uname", param.get("uname"));
				 securityRewardIndexSvc.insert(new Param(detail));
			}
		}else {//보안 우수자
			Param detail = new Param();
			detail.put("eval_item_id", eval_item_id);
			detail.put("uid", param.get("uid"));
			detail.put("uname", param.get("uname"));
			detail.put("eval_score", param.get("max_score"));
			detail.put("eval_typ_nm", "N/A");
			detail.put("risk_typ_cd", "N/A");
			securityRewardIndexSvc.insert(detail);
		}
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void standardUpdate(final Param param) throws SQLException {

		String reward_cd = Utils.nvl(param.get("reward_cd"),"");

		this.update(param);
		String eval_item_id = param.get("eval_item_id");

		Param delParam = new Param();
		delParam.put("eval_item_id", eval_item_id);
		securityRewardIndexSvc.delete(delParam);

		if("SV".equals(reward_cd)) {//보안 위반자

			HashMap hashparam =  (HashMap)param;
			List<LinkedHashMap> list =  (List<LinkedHashMap>)hashparam.get("list");

			for (LinkedHashMap detail : list) {
				detail.put("eval_item_id", eval_item_id);
				detail.put("uid", param.get("uid"));
				detail.put("uname", param.get("uname"));
				securityRewardIndexSvc.insert(new Param(detail));
			}
		}else if("SS".equals(reward_cd)) {//보안 우수자
			Param detail = new Param();
			detail.put("eval_item_id", eval_item_id);
			detail.put("uid", param.get("uid"));
			detail.put("uname", param.get("uname"));
			detail.put("eval_score", param.get("max_score"));
			detail.put("eval_typ_nm", "N/A");
			detail.put("risk_typ_cd", "N/A");
			detail.put("eval_typ_id", "N/A");
			securityRewardIndexSvc.insert(detail);
		}
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void standardDelete(final Param param) throws SQLException {
		securityRewardIndexSvc.delete(param);
		this.delete(param);
	}
}
