package com.softworks.springframework.web.services.front;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;

@Service
public class LawsRevHistService extends BaseService {
	
	@Transactional(readOnly=true)
	public Param getLawsRevisionHistOne(Param param) {
		return session.selectOne("com.softworks.springframework.LawsRevHist.getLawsRevisionHistOne", param);
	}
	
	@Transactional(readOnly=true)
	public int getLawsRevisionHistListCount(Param param) {
		return session.selectOne("com.softworks.springframework.LawsRevHist.getLawsRevisionHistListCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getLawsRevisionHistList(Param param) {
		return session.selectList("com.softworks.springframework.LawsRevHist.getLawsRevisionHistList", param);
	}
	
	@Transactional(readOnly=true)
	public int getLawsListCount(Param param) {
		return session.selectOne("com.softworks.springframework.LawsRevHist.getLawsListCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getLawsList(Param param) {
		return session.selectList("com.softworks.springframework.LawsRevHist.getLawsList", param);
	}
	
	@Transactional(readOnly=true)
    public void getLawsRevisionHistListExcel(final Param param, final ModelMap model) throws SQLException {

		int[]	 colWidth	= {20, 20, 20, 20, 20};

		model.addAttribute("category", new String[] { "No", "법령", "개정 구분" , "개정일자", "등록일자" 
                 });
        
        model.addAttribute("columns", new String[] { "RNUM", "NAME", "CHANGE_TYPE", "CHANGE_DT", "IF_DT"
                });
    
        model.addAttribute("columnsWidth", colWidth);
        model.addAttribute("chapter", "국내법규개정이력");
        model.addAttribute("filename", "국내법규개정이력"+"_"+Utils.getTimeStampString("yyyyMMdd"));
           
        model.addAttribute("data", session.selectList("com.softworks.springframework.LawsRevHist.getLawsRevisionHistListExcel", param));
        
    }
	
	@Transactional(readOnly=true)
    public void getLawsListExcel(final Param param, final ModelMap model) throws SQLException {

		int[]	 colWidth	= {20, 20, 20, 20, 20};

		model.addAttribute("category", new String[] { "No", "법령", "개정 구분" , "개정일자", "등록일자" 
                 });
        
        model.addAttribute("columns", new String[] { "RNUM", "NAME", "CHANGE_TYPE", "CHANGE_DT", "IF_DT"
                });
    
        model.addAttribute("columnsWidth", colWidth);
        model.addAttribute("chapter", "국내법규개정이력");
        model.addAttribute("filename", "국내법규개정이력"+"_"+Utils.getTimeStampString("yyyyMMdd"));
           
        model.addAttribute("data", session.selectList("com.softworks.springframework.LawsRevHist.getLawsRevisionHistListExcel", param));
        
    }
	
}