package com.softworks.springframework.web.services.front;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;

@Service
public class BbsService extends BaseService {

	@Transactional(readOnly=true)
	public int getListCount(final Param param) throws SQLException {
		
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*DEFAULT_PAGE_SIZE));
		
		return (Integer)session.selectOne("com.softworks.springframework.Board.getFrontListCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) throws SQLException {
		return session.selectList("com.softworks.springframework.Board.getFrontList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getFaqList(final Param param) throws SQLException {
		return session.selectList("com.softworks.springframework.Board.getFaqList", param);
	}
	
	@Transactional(readOnly=true)
	public Param getInfo(final int seq) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.Board.getFrontInfo", seq);
	}
	
	@Transactional(readOnly=true)
	public Param getQaInfo(final Param param) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.Board.getFrontQaInfo", param);
	}
	
	@Transactional(readOnly=true)
	public boolean isAnswer(final int seq) throws SQLException {
		return null != (String)session.selectOne("com.softworks.springframework.Board.isAnswer", seq);
	}
	
	public void insert(final Param param) throws SQLException {
		session.insert("com.softworks.springframework.Board.qaInsert", param);
	}
	
	public void update(final Param param) throws SQLException {
		session.update("com.softworks.springframework.Board.qaUpdate", param);
	}
	
	public void delete(final int seq, final String uid) throws SQLException {
		Param	param	= new Param();
				param.set("seq", seq);
				param.set("writer", uid);

		session.delete("com.softworks.springframework.Board.qaDelete", param);
	}
	
	public void saveFiles(final Param param, final MultipartFile attach, String uploadPath) throws Exception {
		int seq = param.getInt("seq");
		List<HashMap<String,Object>> fileList = new ArrayList<HashMap<String,Object>>();
		if(null != attach && !attach.isEmpty()){
			HashMap<String,Object> fileMap = new HashMap<String,Object>();
			fileMap.put("board_seq", seq);
			fileMap.put("rgst_id", param.get("writer").toString());
			fileMap.put("add_file_name", attach.getOriginalFilename());
			fileMap.put("file_path", uploadPath);
			fileMap.put("save_file_name", seq + "_attach_1");
			fileList.add(fileMap);
			Utils.saveUploadFile(uploadPath,
					 param.get("seq") + "_attach_1", attach.getBytes(), attach.getSize(), attach.getOriginalFilename(), false);
		}
		if(null != fileList && 0 < fileList.size()){
			param.set("fileList", fileList);
			session.delete("com.softworks.springframework.CommBoard.deleteFiles", param);
			session.insert("com.softworks.springframework.CommBoard.insertBoardFile", param);
		}
		
	}

}
