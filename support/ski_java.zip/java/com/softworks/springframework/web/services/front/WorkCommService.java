package com.softworks.springframework.web.services.front;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class WorkCommService extends BaseService {

    @Transactional(readOnly=true)
    public List<Param> getSvcNoListByDomainCd(final Param param) throws SQLException {
        return session.selectList("com.softworks.springframework.WorkComm.getSvcNoListByDomainCd", param);
    }
    
    @Transactional(readOnly=true)
    public Param getLastTaInfo(final String svcNo) throws SQLException {
        return (Param)session.selectOne("com.softworks.springframework.WorkComm.getLastTaInfoBySvcNo", svcNo);
    }
    
    @Transactional(readOnly=true)
    public List<Param> getConfMasterListBySvcNo(final String svcNo) throws SQLException {
        return session.selectList("com.softworks.springframework.WorkComm.getConfMasterListBySvcNo", svcNo);
    }
    
    @Transactional(readOnly=true)
    public List<Param> getRiskMasterListBySvcNo(final String svcNo) throws SQLException {
        return session.selectList("com.softworks.springframework.WorkComm.getRiskMasterListBySvcNo", svcNo);
    }
    
    @Transactional(readOnly=true)
    public List<Param> getCommMmsLogList(final Param param) throws SQLException {
        return session.selectList("com.softworks.springframework.WorkComm.getCommMmsLogList", param);
    }
 
    @Transactional(readOnly=true)
	public List<Param> getConfMasterSearchList(final Param param) throws SQLException {
		return session.selectList("com.softworks.springframework.WorkComm.getConfMasterSearchList", param);
	}
    
}
