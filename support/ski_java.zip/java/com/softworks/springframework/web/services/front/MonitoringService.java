package com.softworks.springframework.web.services.front;

import java.io.File;
import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.multipart.MultipartFile;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.utils.FileUtil;
import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class MonitoringService extends BaseService {
	
	/*
	 * 보안 수준 현황
	 * */
	@Transactional(readOnly=true)
	public List<Param> getChartDataDiagnosis(final Param param) {
		return session.selectList("com.softworks.springframework.Monitoring.getChartDataDiagnosis", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getMainDataDiagnosis(final Param param) {
		return session.selectList("com.softworks.springframework.Monitoring.getMainDataDiagnosis", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getSubDataDiagnosis(final Param param) {
		return session.selectList("com.softworks.springframework.Monitoring.getSubDataDiagnosis", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getChartDataTask(final Param param) {
		return session.selectList("com.softworks.springframework.Monitoring.getChartDataTask", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getDataTask(final Param param) {
		return session.selectList("com.softworks.springframework.Monitoring.getDataTask", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getChartDataLaws(final Param param) {
		return session.selectList("com.softworks.springframework.Monitoring.getChartDataLaws", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getDataLaws(final Param param) {
		return session.selectList("com.softworks.springframework.Monitoring.getDataLaws", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getChartDataSubside(final Param param) {
		return session.selectList("com.softworks.springframework.Monitoring.getChartDataSubside", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getDataSubside(final Param param) {
		return session.selectList("com.softworks.springframework.Monitoring.getDataSubside", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getDataDomain(final Param param) {
		return session.selectList("com.softworks.springframework.Monitoring.getDataDomain", param);
	}
	
	
	
	
	/*
	 * 보안 구성도
	 * */
	@Transactional(readOnly=true)
	public Param getSecuConfigDiag(final Param param) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.Monitoring.getSecuConfigDiag", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateSecuConfigDiag(final Param param) throws SQLException {
		session.update("com.softworks.springframework.Monitoring.updateSecuConfigDiag", param);
	}
}
