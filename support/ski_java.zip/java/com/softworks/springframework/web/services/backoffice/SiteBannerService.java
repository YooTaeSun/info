package com.softworks.springframework.web.services.backoffice;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class SiteBannerService extends BaseService {
	
	@Transactional(readOnly=true)
	public Param getSiteBannerOne(Param param) {
		return session.selectOne("com.softworks.springframework.siteBanner.getSiteBannerOne", param);
	}
	
	@Transactional(readOnly=true)
	public int getSiteBannerListCount(Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*10));

		return session.selectOne("com.softworks.springframework.siteBanner.getSiteBannerListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getSiteBannerList(Param param) {
		return session.selectList("com.softworks.springframework.siteBanner.getSiteBannerList", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertSiteBanner(final Param param) throws Exception {
		session.insert("com.softworks.springframework.siteBanner.insertSiteBanner", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateSiteBanner(final Param param) throws Exception {
		session.update("com.softworks.springframework.siteBanner.updateSiteBanner", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteSiteBanner(final Param param) throws Exception {
		session.delete("com.softworks.springframework.siteBanner.deleteSiteBanner", param);
	}

}