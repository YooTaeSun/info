package com.softworks.springframework.web.services.backoffice;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class SecurityRewardIndexService extends BaseService {

	@Transactional(readOnly=true)
	public int getListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));

		return session.selectOne("com.softworks.springframework.SecurityRewardIndex.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) {
		return session.selectList("com.softworks.springframework.SecurityRewardIndex.getList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getAllList(final Param param) {
		return session.selectList("com.softworks.springframework.SecurityRewardIndex.getAllList", param);
	}

	@Transactional(readOnly=true)
	public Param getDetail(Param param) {
		return session.selectOne("com.softworks.springframework.SecurityRewardIndex.getList", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int insert(final Param param) throws SQLException {
		return session.insert("com.softworks.springframework.SecurityRewardIndex.insert", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void update(final Param param) throws SQLException {
		session.update("com.softworks.springframework.SecurityRewardIndex.update", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void delete(final Param param) throws SQLException {
		session.delete("com.softworks.springframework.SecurityRewardIndex.delete", param);
	}

}
