package com.softworks.springframework.web.services.backoffice;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class MetaMappingService extends BaseService {
	

	@Transactional(readOnly=true)
	public List<Param> getDistinctCheckListRelatedLawsList(Param param) {
		return session.selectList("com.softworks.springframework.MetaMapping.getDistinctCheckListRelatedLawsList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getCheckListRelatedLawsList(Param param) {
		return session.selectList("com.softworks.springframework.MetaMapping.getCheckListRelatedLawsList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getCheckListRelatedLawsMappingList(Param param) {
		return session.selectList("com.softworks.springframework.MetaMapping.getCheckListRelatedLawsMappingList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getCheckListRelatedLawsMappingGroupList(Param param) {
		return session.selectList("com.softworks.springframework.MetaMapping.getCheckListRelatedLawsMappingGroupList", param);
	}
	
	public boolean insertCheckListRelatedLaws(Param param) throws SQLException {
		return 0 < session.insert("com.softworks.springframework.MetaMapping.insertCheckListRelatedLaws", param);
	}
	
	@Transactional(readOnly=true)
	public void deleteCheckListRelatedLaws(final Param param) throws Exception {
		session.delete("com.softworks.springframework.MetaMapping.deleteCheckListRelatedLaws", param);
	}
	
	@Transactional(readOnly=true)
	public int getCheckListRelatedLawsMappingDupleCount(Param param) {
		return session.selectOne("com.softworks.springframework.MetaMapping.getCheckListRelatedLawsMappingDupleCount", param);
	}
	
	
	
}