package com.softworks.springframework.web.services.backoffice;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;

@Service
public class BoardService extends BaseService {
	
	private void saveAttach(final String uploadPath, final String saveName, final MultipartFile file) throws Exception {
		Utils.saveUploadFile(uploadPath, saveName, file.getBytes(), file.getSize(), file.getOriginalFilename(), false);
	}

	@Transactional(readOnly=true)
	public String getBoardType(final String type) {
		return (String)session.selectOne("com.softworks.springframework.Board.getBoardType", type);
	}

	@Transactional(readOnly=true)
	public int getListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*10));
		
		return (int)session.selectOne("com.softworks.springframework.Board.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) {
		return session.selectList("com.softworks.springframework.Board.getList", param);
	}

	@Transactional(readOnly=true)
	public Param getInfo(final int seq) {
		return (Param)session.selectOne("com.softworks.springframework.Board.getInfo", seq);
	}

	@Transactional(readOnly=true)
	public List<Param> getQAList(final Param param) {
		return session.selectList("com.softworks.springframework.Board.getQAList", param);
	}

	@Transactional(readOnly=true)
	public Param getQAInfo(final int seq) {
		return (Param)session.selectOne("com.softworks.springframework.Board.getQAInfo", seq);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insert(final Param param, final MultipartFile attach1, final MultipartFile attach2, final String uploadPath) throws Exception {
		
		session.insert("com.softworks.springframework.Board.insert", param);
		
		saveFiles(param, attach1, attach2, null, uploadPath);
		
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void answerInsert(final Param param, final MultipartFile attach1, final MultipartFile attach, String uploadPath) throws Exception {
		
		session.insert("com.softworks.springframework.Board.insert", param);

		session.insert("com.softworks.springframework.Board.answerInsert", param);
		saveFiles(param, attach1, null, attach, uploadPath);

	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void update(final Param param, final MultipartFile attach1, final MultipartFile attach2, final String uploadPath) throws Exception {

		session.update("com.softworks.springframework.Board.update", param);
		
		saveFiles(param, attach1, attach2, null,uploadPath);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void answerUpdate(final Param param, final MultipartFile attach1, final MultipartFile attach, String uploadPath) throws Exception {
		
		session.update("com.softworks.springframework.Board.update", param);
		
		session.update("com.softworks.springframework.Board.answerUpdate", param);
		saveFiles(param, attach1, null, attach, uploadPath);

	}
	
	public void delete(final Param param) throws Exception {
		if(!param.isNull("seqList")) param.set("seqList", param.getValues("seqList"));
		
		session.update("com.softworks.springframework.Board.delete", param);
	}
	
	public void answerDelete(final int seq) throws Exception {
		session.update("com.softworks.springframework.Board.answerDelete", seq);
	}
	
	private void saveFiles(final Param param, final MultipartFile attach1, final MultipartFile attach2, final MultipartFile attach_ans, String uploadPath) throws IOException, Exception {
		int seq = param.getInt("seq");
		List<HashMap<String,Object>> fileList = new ArrayList<HashMap<String,Object>>();
		if(null != attach1 && !attach1.isEmpty()){
			HashMap<String,Object> fileMap = new HashMap<String,Object>();
			fileMap.put("board_seq", seq);
			fileMap.put("rgst_id", param.get("writer").toString());
			fileMap.put("add_file_name", attach1.getOriginalFilename());
			fileMap.put("file_path", uploadPath);
			fileMap.put("save_file_name", seq + "_attach_1");
			fileList.add(fileMap);
			saveAttach(uploadPath, seq + "_attach_1", attach1);

		}
		if(null != attach2 && !attach2.isEmpty()){
			HashMap<String,Object> fileMap2 = new HashMap<String,Object>();
			fileMap2.put("board_seq", seq);
			fileMap2.put("rgst_id", param.get("writer").toString());
			fileMap2.put("add_file_name", attach2.getOriginalFilename());
			fileMap2.put("file_path", uploadPath);
			fileMap2.put("save_file_name", seq + "_attach_2");
			fileList.add(fileMap2);
			saveAttach(uploadPath, seq + "_attach_2", attach2);
		}
		if(null != attach_ans && !attach_ans.isEmpty()){
			HashMap<String,Object> ansFileMap = new HashMap<String,Object>();
			ansFileMap.put("board_seq", seq);
			ansFileMap.put("rgst_id", param.get("writer").toString());
			ansFileMap.put("add_file_name", attach_ans.getOriginalFilename());
			ansFileMap.put("file_path", uploadPath);
			ansFileMap.put("save_file_name", seq + "_attach_ans");
			fileList.add(ansFileMap);
			saveAttach(uploadPath, seq + "_attach_ans", attach_ans);
		}
		if(null != fileList && 0 < fileList.size()){
			param.set("fileList", fileList);
			session.delete("com.softworks.springframework.CommBoard.deleteFiles", param);
			session.insert("com.softworks.springframework.CommBoard.insertBoardFile", param);
		}
		
	}

}
