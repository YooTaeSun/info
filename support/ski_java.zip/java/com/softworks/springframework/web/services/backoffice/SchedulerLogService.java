package com.softworks.springframework.web.services.backoffice;

import java.util.Date;

import org.apache.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;

@Service
public class SchedulerLogService extends BaseService {

	private	final	Logger		logger	= Logger.getLogger(getClass());

    public void setSession(SqlSessionTemplate session) {
		super.session = session;
	}
    
	@Transactional(readOnly=true)
	public int newAppendBatchHistory(final Param schdInfo) {
		Param param = setHistStartParam(schdInfo);
		if(param != null)
			session.insert("com.softworks.springframework.Schedule.newAppendBatchHistory", param);
		return param.getInt("next_seq");
	}
	
	@Transactional(readOnly=true)
	public void updateBatchHistory(final Param schdInfo) {
		Param param = setHistEndParam(schdInfo);
		if(param != null)
			session.insert("com.softworks.springframework.Schedule.updateBatchHistory", param);
	}
	
	@Transactional(readOnly=true)
	public int getBatchHistLastNo() {
		return (Integer)session.selectOne("com.softworks.springframework.Schedule.getBatchHistLastNo") + 1;
	}
	
	private Param setHistStartParam(final Param schdInfo) {
		// TODO Auto-generated method stub
		String	histYn = schdInfo.get("HIST_YN");
		Param logParam = null;
		if(histYn.equals("Y")){
			logParam = new Param();
			Date date = new Date();
			String currDate = Utils.getTimeStampString(date);
			logParam.set("batch_cd", schdInfo.get("SCHD_ID"));
			logParam.set("schedule_cd", schdInfo.get("SCHD_ID"));
			logParam.set("schedule_nm", schdInfo.get("SCHD_NM"));
			logParam.set("start_dt", currDate);
		}
		return logParam;
	}
	
	private Param setHistEndParam(final Param schdInfo) {
		// TODO Auto-generated method stub
		String	histYn = schdInfo.get("HIST_YN");
		Param logParam = null;
		if(histYn.equals("Y")){
			logParam = new Param();
			Date date = new Date();
			String currDate = Utils.getTimeStampString(date);
			logParam.set("seq", schdInfo.get("BATCH_SEQ"));
			logParam.set("batch_cnt", schdInfo.get("BATCH_CNT"));
			logParam.set("success_yn", schdInfo.get("SUCCESS_YN"));
			logParam.set("batch_msg", schdInfo.get("BATCH_MSG"));
			logParam.set("end_dt", currDate);
		}
		return logParam;
	}
}
