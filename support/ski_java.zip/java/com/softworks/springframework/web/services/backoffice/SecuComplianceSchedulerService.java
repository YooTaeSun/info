package com.softworks.springframework.web.services.backoffice;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;
import com.softworks.springframework.web.services.CodeLoaderService.CodeInfo;
import com.softworks.springframework.web.services.MailSendService;

@Service
public class SecuComplianceSchedulerService extends BaseService {

	private	final	Logger		logger	= Logger.getLogger(getClass());

	@Autowired
	SchedulerLogService logSvc;

    public void setSession(SqlSessionTemplate session) {
		super.session = session;
		logSvc = new SchedulerLogService();
		logSvc.setSession(session);
	}

    
    /**
	 * [알림] 보안 준수 현황 관리 알림 내역 등록
	 * target table : NOTI_HIST
	 * Result : void
     * @throws Exception 
	 */
    public void sendMailSecuComplianceStatus(final Param schdInfo) throws Exception {
    	int batch_cnt = 0;
    	int total_cnt = 0;
		String	err_chk			= "";
		String	rst_msg			= "";
		List<Param> targetList = null;
		Param contentReplaceParam = null;
		Param mailRtnParam = null;
		
		// start log
		schdInfo.set("BATCH_SEQ", logSvc.newAppendBatchHistory(schdInfo));
		
		MailSendService mm = new MailSendService();
		mm.setSession(session);
		
		try {
			// 대상자 추출 및 noti hist 등록 
			/*
			대상자 추출 배치 쿼리param(2개)
			14,7,3,1,0

			* 년별 *
			반기(전반기, 후반기)
			분기(1/4,2/4,3/4,4/4)
			월별(1,2,3,4,5,6,7,8,9,10,11,12)
			*/
			String noti_id = schdInfo.get("NOTI_ID");
			Param notiInfo = getNotiContentsInfo(noti_id);
			Param pStdDt = new Param();
			// get noti date
			
			List<CodeInfo> notiDate = getUseCodeList("NOTI_DATE");
			for (CodeInfo codeInfo : notiDate) {
				pStdDt.set(codeInfo.getCode(), codeInfo.getName());
			}
					
			Param targetParam = new Param();
			targetParam.set("noti_id", noti_id);
			targetParam.set("noti_typ_cd", notiInfo.get("NOTI_TYP_CD"));
			String notiCn = notiInfo.get("NOTI_CN").replaceAll("#CHECKLIST_ID#", "@CHECKLIST_ID@").replaceAll("#DEADLINE#", "@DEADLINE@");
			targetParam.set("noti_cn", notiCn);
			targetParam.set("noti_menu_url", notiInfo.get("NOTI_MENU_URL"));
			targetParam.set("uid", schdInfo.get("SCHD_ID"));
			targetParam.set("unm", schdInfo.get("SCHD_ID"));
			
			Date date = new Date();
			int curYear = Utils.getYear(date);
			int curMonthInt = Utils.getMonth(date);
			
			SimpleDateFormat ft = new SimpleDateFormat("MM");
			String curMonthStr = ft.format(date.getTime());
			int lastDay = 0;
			
			/*1QUATER	0331
			2QUATER	0630
			3QUATER	0930
			4QUATER	1130
			F_HALF	0630
			S_HALF	1031
			YEAR	1201*/
			
			/*HALF	매반기
			MONTH	매월
			QUARTER	매분기
			YEAR	매년*/
			
			/*
			 * 주기별 알림 대상자 등록 
			 * */
			// 1. 년별 대상자 추출 및 noti hist 등록
			targetParam.set("repeat_cycle_cd", "YEAR");
			targetParam.set("stdDt", ""+curYear+pStdDt.get("YEAR"));
			appendNotiHist(targetParam);
			
			// 2. 반기별 대상자 추출 및 noti hist 등록
			targetParam.set("repeat_cycle_cd", "HALF");
			if(curMonthInt <= 6){
				// before half
				targetParam.set("stdDt", ""+curYear+pStdDt.get("F_HALF"));
			}else{
				// after half
				targetParam.set("stdDt", ""+curYear+pStdDt.get("S_HALF"));
			}
			appendNotiHist(targetParam);
			
			// 3. 분기별 대상자 추출 및 noti hist 등록
			targetParam.set("repeat_cycle_cd", "QUARTER");
			if(curMonthInt <= 3){//1QUATER
				targetParam.set("stdDt", ""+curYear+pStdDt.get("1QUATER"));
			}else if(curMonthInt <= 6){//2QUATER
				targetParam.set("stdDt", ""+curYear+pStdDt.get("2QUATER"));
			}else if(curMonthInt <= 9){//3QUATER
				targetParam.set("stdDt", ""+curYear+pStdDt.get("3QUATER"));
			}else{//4QUATER
				targetParam.set("stdDt", ""+curYear+pStdDt.get("4QUATER"));
			}
			appendNotiHist(targetParam);
			
			// 4. 월별 대상자 추출 및 noti hist 등록
			targetParam.set("repeat_cycle_cd", "MONTH");
			lastDay = Utils.getActualMaximum(Utils.str2Date(curYear+"-"+curMonthStr+"-01"));
			String stdDt = ""+curYear+curMonthStr+lastDay;
			targetParam.set("stdDt", stdDt);
			appendNotiHist(targetParam);
			
			// 알림 noti hist 메일 발송 대상 
			targetList = getSecuComplianceSendMailTarget();
			
			if(targetList != null && targetList.size() > 0){
				total_cnt = targetList.size();
				for (Param target : targetList) {
					//메일 발송 
					contentReplaceParam = new Param();
					int deadlineNum = Integer.parseInt(target.get("DEADLINE_NUM"));
					if(deadlineNum == 0){
						contentReplaceParam.set("#DEADLINE#", "당일");
					}else{
						contentReplaceParam.set("#DEADLINE#", deadlineNum+"일 전");
					}
					mailRtnParam = mm.sendMail2(notiInfo.get("MAIL_ID"),target.get("NOTI_EMP_NO"), contentReplaceParam);
					System.out.println("RESULT_MSG ============> "+mailRtnParam.get("RESULT_MSG"));
					if(Boolean.parseBoolean(mailRtnParam.get("RESULT"))){
						batch_cnt++;
					}
				}
			}
		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		}
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		if (!err_chk.equals("")) {
			schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "N");
			schdInfo.set("BATCH_MSG", err_chk);
			logSvc.updateBatchHistory(schdInfo);
			
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
	    	if(batch_cnt > 0){
	    		rst_msg = "업무 적용 현황 및 자료 등록 마감 대상자 총"+total_cnt+"명 중 "+batch_cnt+"명에게 알림 메일이 발송 되었습니다.";
	    	}else{
	    		rst_msg = "업무 적용 현황 및 자료 등록 마감 대상이 없습니다.";
	    	}
	    	schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "Y");
			schdInfo.set("BATCH_MSG", rst_msg);
			logSvc.updateBatchHistory(schdInfo);
	    	logger.info("User append Daily Batch totCnt="+batch_cnt);
	    }
	}
    
    /**
	 * 보안체크리스트 데이터 등록
	 * target table : NOTI_HIST
	 * Result : void
     * @throws Exception 
	 */
    public void regNewSecuChecklist(final Param schdInfo) throws Exception {
    	int batch_cnt = 0;
    	int total_cnt = 0;
		String	err_chk			= "";
		String	rst_msg			= "";
		Param rtnParam = new Param();
		
		// start log
		schdInfo.set("BATCH_SEQ", logSvc.newAppendBatchHistory(schdInfo));
		
		try {
			// 신규 보안체크리스트 유무 확인
			int rstCnt = getNewChecklistCnt();
			// 신규 보안체크리스트 데이터 등록
			if(rstCnt > 0){
				regChecklistProc(rtnParam,schdInfo);
			}
			total_cnt = batch_cnt = rtnParam.getInt("chk_cnt") + rtnParam.getInt("chk_eval_cnt");
		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		}
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		if (!err_chk.equals("")) {
			schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "N");
			schdInfo.set("BATCH_MSG", err_chk);
			logSvc.updateBatchHistory(schdInfo);
			
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
	    	if(batch_cnt > 0){
	    		rst_msg = "신규 보안 체크리스트 데이터 등록 총"+rtnParam.get("chk_cnt")+"건 등록 / 신규 보안 체크리스트 평가 데이터 총"+rtnParam.get("chk_eval_cnt")+"건이 등록 되었습니다.";
	    	}else{
	    		rst_msg = "신규 보안 체크리스트 데이터가 없습니다.";
	    	}
	    	schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "Y");
			schdInfo.set("BATCH_MSG", rst_msg);
			logSvc.updateBatchHistory(schdInfo);
	    	logger.info("User append Daily Batch totCnt="+batch_cnt);
	    }
	}
    
    @Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
    public Param regChecklistProc(Param rtnParam, final Param schdInfo) throws SQLException {
    	// 체크리스트 등록
    	rtnParam.set("chk_cnt", regNewChecklist(schdInfo));
    	// 체크리스트 평가 등록
    	rtnParam.set("chk_eval_cnt", regNewChecklistEval(schdInfo));
		// TODO Auto-generated method stub
    	return rtnParam;
	} 
    
	@Transactional(readOnly=true)
	public List<Param> getSecuComplianceSendMailTarget() throws SQLException {
		return session.selectList("com.softworks.springframework.SecuComplianceScheduler.getSecuComplianceSendMailTarget");
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public boolean appendNotiHist(final Param param) throws SQLException {
		return 0 < session.update("com.softworks.springframework.SecuComplianceScheduler.appendNotiHist", param);
	}
	
	@Transactional(readOnly=true)
	public Param getNotiContentsInfo(final String noti_id) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.Main.getNotiContentsInfo", noti_id);
	}
	
	@Transactional(readOnly=true)
	public int getNewChecklistCnt() throws SQLException {
		return (Integer)session.selectOne("com.softworks.springframework.SecuComplianceScheduler.getNewChecklistCnt");
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int regNewChecklist(final Param param) throws SQLException {
		return session.update("com.softworks.springframework.SecuComplianceScheduler.regNewChecklist",param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int regNewChecklistEval(final Param param) throws SQLException {
		return session.update("com.softworks.springframework.SecuComplianceScheduler.regNewChecklistEval",param);
	}
}
