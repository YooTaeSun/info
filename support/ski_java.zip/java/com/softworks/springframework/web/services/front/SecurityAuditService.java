package com.softworks.springframework.web.services.front;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.AttachFileService;
import com.softworks.springframework.web.services.BaseService;

@Service
public class SecurityAuditService extends BaseService {

	@Autowired
	SecurityAuditDetailService  securityAuditDetailSvc;

	@Autowired
	AttachFileService  attachFileSvc;

	@Autowired
	SecuManagerService  secuManagerSvc;

	@Autowired
	SecuManagerDetailService  secuManagerDetailSvc;

	/**
	 * 권한
	 */
	public String getSecurityAudioAuth(String uid, String group_id, String manager_id, String reg_id) {
		String menuAuth = "NN";
		//관리자
		if (group_id.equals("Administrator") || group_id.equals("PortalAdmin")) {
			menuAuth = "SH";
		//자기가 작성
		}else if(uid.equals(reg_id)) {
			menuAuth = "SH";
		//업무 담당자로 지정
		}else {
			Param mngParam = new Param();
			mngParam.put("manager_id", manager_id);
			mngParam.put("emp_no", uid);
			mngParam.put("privilege_cd_id", "AUDIT_PRIVILEGE_CD");
			Param secuManagerDetail = secuManagerDetailSvc.getDetail(mngParam);
			String secuAuth =  secuManagerDetail.get("PRIVILEGE_CD");//R:조회  U:처리
			if("R".equals(secuAuth)) {
				menuAuth = "SN";
			}else if("U".equals(secuAuth)) {
				menuAuth = "SH";
			}
		}
		return menuAuth;
	}


	@Transactional(readOnly=true)
	public int getListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		return session.selectOne("com.softworks.springframework.SecurityAudit.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) {
		return session.selectList("com.softworks.springframework.SecurityAudit.getList", param);
	}

	@Transactional(readOnly=true)
	public Param getDetail(final Param param) {
		return session.selectOne("com.softworks.springframework.SecurityAudit.getAllList", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int insert(Param param) throws SQLException {
		return session.insert("com.softworks.springframework.SecurityAudit.insert", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getCompanyBusiSiteAllList(Param param) {
		return session.selectList("com.softworks.springframework.SecurityAudit.getCompanyBusiSiteAllList", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void regist(Param param, List<Param> lawSystemCheckList) throws SQLException {

		String uid = param.get("uid");
		String uname = param.get("uname");

		Param attachParam = new Param();

		//기본정보 첨부파일ID
		attachParam.put("atch_file_id", param.get("basic_atch_file_id"));
		attachFileSvc.insert(attachParam);

		//증빙자료일괄등록 첨부파일ID
		attachParam.put("atch_file_id", param.get("batch_atch_file_id"));
		attachFileSvc.insert(attachParam);

		//기타자료 첨부파일ID
		attachParam.put("atch_file_id", param.get("etc_atch_file_id"));
		attachFileSvc.insert(attachParam);

		//최종증빙파일ID
		attachParam.put("atch_file_id", param.get("end_atch_file_id"));
		attachFileSvc.insert(attachParam);

		//----------- SECURITY_AUDIT insert -----------------
		this.insert(param);

		//----------- SECURITY_AUDIT_DETAIL insert -----------------
		Param lawSystemCheck = null;
		String audit_id = param.get("audit_id");

		for (int i = 0, len = lawSystemCheckList.size(); i < len; i++) {
			lawSystemCheck = lawSystemCheckList.get(i);
			lawSystemCheck.put("audit_id", audit_id);
			lawSystemCheck.put("ls_item_id", lawSystemCheck.get("LS_ITEM_ID"));
			lawSystemCheck.put("uid", uid);
			lawSystemCheck.put("uname", uname);

			securityAuditDetailSvc.insert(lawSystemCheck);

			attachParam.clear();
			attachParam.put("atch_file_id", lawSystemCheck.get("atch_file_id"));
			attachFileSvc.insert(attachParam);
		}
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int update(final Param param) throws SQLException {
		return session.update("com.softworks.springframework.SecurityAudit.update", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void delete(final Param param) throws SQLException {
		session.delete("com.softworks.springframework.SecurityAudit.delete", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int updateState(Param param, List<?> list) throws Exception {

		String uid = param.get("uid");
		String uname = param.get("uname");


		int resultInt = 0;

		Param updateParam = null;
		String chk_state_cd = "";
		for (int i = 0, len = list.size(); i < len; i++) {
			updateParam = new Param((HashMap)list.get(i));
			chk_state_cd = updateParam.get("chk_state_cd");




			if("".equals(chk_state_cd)) {
				updateParam.put("req_day", param.get("req_day").replace("-", ""));
				updateParam.put("proc_end_day", param.get("proc_end_day").replace("-", ""));

			}else if("W".equals(chk_state_cd)) {//작업중
				updateParam.put("chk_emp_no", ""); //점검자 사번
				updateParam.put("chk_emp_nm", "");	//점검자
			}else if("C".equals(chk_state_cd)) {//완료
				updateParam.put("chk_emp_no", uid); //점검자 사번
				updateParam.put("chk_emp_nm", uname);	//점검자
			}

			updateParam.set("uid", uid);
			updateParam.set("uname", uname);
			resultInt +=  securityAuditDetailSvc.update(updateParam);

		}
		return resultInt;
	}


	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteBasic(final Param param) throws Exception {

		Param oneParam =  this.getDetail(param);
		List<Param> detailList =  securityAuditDetailSvc.getAllList(param);

		String uid =param.get("uid");
		String uname = param.get("uname");

		Param detail = null;
		String atch_file_id = "";
		Param fileParam = new Param();
		fileParam.put("use_yn", "N");
		fileParam.put("uid", uid);
		fileParam.put("uname",uname);

		if(detailList != null && detailList.size() > 0) {
			for (int i = 0, len = detailList.size(); i < len; i++) {
				detail = detailList.get(i);
				atch_file_id = Utils.nvl(detail.get("ATCH_FILE_ID"));
				if(!atch_file_id.isEmpty()) {
					fileParam.put("atch_file_id", atch_file_id);
	//				attachFileSvc.removeFile(fileParam);
					attachFileSvc.update(fileParam);
				}

				detail.put("audit_id", detail.get("AUDIT_ID"));
				detail.put("ls_item_id", detail.get("LS_ITEM_ID"));
				securityAuditDetailSvc.delete(detail);//SECURITY_AUDIT_DETAIL 삭제
			}
		}

		String manager_id = Utils.nvl(oneParam.get("MANAGER_ID"));
		if(!manager_id.isEmpty()) {
			oneParam.put("manager_id", manager_id);
			secuManagerDetailSvc.delete(oneParam);//SECU_MANAGER_DETAIL 삭제
			secuManagerSvc.delete(oneParam);//SECU_MANAGER 삭제
		}

		atch_file_id = Utils.nvl(oneParam.get("BASIC_ATCH_FILE_ID"));
		if(!atch_file_id.isEmpty()) {
			fileParam.put("atch_file_id", atch_file_id);
//			attachFileSvc.removeFile(fileParam);
			attachFileSvc.update(fileParam);
		}

		atch_file_id = Utils.nvl(oneParam.get("BATCH_ATCH_FILE_ID"));
		if(!atch_file_id.isEmpty()) {
			fileParam.put("atch_file_id", atch_file_id);
//			attachFileSvc.removeFile(fileParam);
			attachFileSvc.update(fileParam);
		}

		atch_file_id = Utils.nvl(oneParam.get("ETC_ATCH_FILE_ID"));
		if(!atch_file_id.isEmpty()) {
			fileParam.put("atch_file_id", atch_file_id);
//			attachFileSvc.removeFile(fileParam);
			attachFileSvc.update(fileParam);
		}
		this.delete(param);//SECURITY_AUDIT 삭제
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public HashMap<String, Object> updateAuditStateCd(final Param param) throws Exception {

		HashMap resultMap = new Param();

		String audit_state_cd = param.get("audit_state_cd");

		if("C".equals(audit_state_cd)) {//완료
			//일괄 다운로드 zip파일 생성
			String audit_id = param.get("audit_id");
			Param param01 = new Param();
			param01.put("audit_id", audit_id);

			Param detail = this.getDetail(param01);
			String atch_file_id = detail.get("END_ATCH_FILE_ID");

			String uid = param.get("uid");
			String uname = param.get("uname");
			String email = param.get("email");

			Param dataParam = new Param();
			dataParam.put("uid", uid);
			dataParam.put("uname", uname);
			dataParam.put("type", "BATCH");
			dataParam.put("batch_down_kind", "security");
			dataParam.put("email", email);
			dataParam.put("is_send_mail", "N");
			dataParam.put("atch_file_id", atch_file_id);
			dataParam.put("audit_id", audit_id);
			dataParam.put("from", "updateAuditStateCd");

			Param fileInfo = attachFileSvc.batchDownload(dataParam);
			resultMap.put("fileInfo", fileInfo);
		}

		this.update(param);

		return resultMap;
	}



}