package com.softworks.springframework.web.services.backoffice;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
@SuppressWarnings("unchecked")
public class MailSendHistService extends BaseService {

	@Transactional(readOnly=true)
	public int getListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		return session.selectOne("com.softworks.springframework.MailSendHist.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) throws Exception {
		return session.selectList("com.softworks.springframework.MailSendHist.getList", param);
	}
	
	@Transactional(readOnly=true)
	public Param getInfo(final Param param) throws Exception {
		return session.selectOne("com.softworks.springframework.MailSendHist.getInfo", param);
	}
}
