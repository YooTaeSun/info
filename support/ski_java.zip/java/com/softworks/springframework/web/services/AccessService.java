package com.softworks.springframework.web.services;

import java.sql.SQLException;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;

@Service
public class AccessService extends BaseService {

	public void insertLog(final Param param) {
		session.insert("com.softworks.springframework.Access.insertLog", param);
	}

	public void insertConnHist(final Param param) {
		session.insert("com.softworks.springframework.Access.insertConnHist", param);
	}
	
	public void setLastLogin(final String id) {
		session.update("com.softworks.springframework.Access.lastLogin", id);
	}
	
	public void setLastUserLogin(final String id) {
		session.update("com.softworks.springframework.Access.lastUserlogin", id);
	}
	
	@Transactional(readOnly=true)
	public Param getLoginInfo(final Param param) {
		return (Param)session.selectOne("com.softworks.springframework.Access.getLoginInfo", param);
	}
	@Transactional(readOnly=true)
	public Param getUserInfo(final Param param) {
		return (Param)session.selectOne("com.softworks.springframework.Access.getUserInfo", param);
	}
	@Transactional(readOnly=true)
	public Param getAdminInfo(final Param param) {
		return (Param)session.selectOne("com.softworks.springframework.Access.getAdminInfo", param);
	}
	
	@Transactional(readOnly=true)
	public String isManagerLevel(final String group, final String managerGroup) {
		Param	param	= new Param();
				param.set("group", group);
				param.set("managerGroup", managerGroup);
				
		return null == (String)session.selectOne("com.softworks.springframework.Access.isManagerLevel", param) ? "N" : "Y";
	}
	
	@Transactional(readOnly=true)
	public boolean isWatingApproval(final String id) {
		return null != (String)session.selectOne("com.softworks.springframework.Access.isWatingApproval", id);
	}
	
	@Transactional(readOnly=true)
    public boolean isWriteBtn(final Param param) {
        return null != (String)session.selectOne("com.softworks.springframework.Access.isWriteBtn", param);
    }
	
    @Transactional(readOnly=true)
    public Param getLeftRmsCntInfo(final String id) {
        return (Param)session.selectOne("com.softworks.springframework.Access.getLeftRmsCntInfo", id);
    }

    @Transactional(readOnly=true)
    public int getMeasureResultCnt(final Param param) {
        return (Integer)session.selectOne("com.softworks.springframework.Access.getMeasureResultCnt", param);
    }
 	
	/** 기존 AccessService에서 SSO 관련 프로세스 추가 **/
	@Transactional(readOnly=true)
	public Param getSKIUserInfo(final String logonid) {
		return (Param)session.selectOne("com.softworks.springframework.Access.getSKIUserInfo", logonid);
	}
    
	@Transactional(readOnly=true)
	public Param getPortalUserInfo(final Param param) {
		return (Param)session.selectOne("com.softworks.springframework.Access.getPortalUserInfo", param);
	}
	
	public boolean insertPortalUserInfo(final Param param) throws SQLException {
		return 0 < session.insert("com.softworks.springframework.Access.insertPortalUserInfo", param);
	}
	    
	/*
	@Transactional(readOnly=true)
	public boolean isExpireCustomer(final String customer) {
		return null == (String)session.selectOne("com.softworks.springframework.Access.isExpireCustomer", customer);
	}

	public int isExpirePass(final String uid) {
		return (int)session.selectOne("com.softworks.springframework.Access.isExpirePassword", uid);
	}
	*/
}
