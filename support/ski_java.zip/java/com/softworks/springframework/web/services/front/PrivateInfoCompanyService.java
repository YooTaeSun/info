package com.softworks.springframework.web.services.front;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.AttachFileService;
import com.softworks.springframework.web.services.BaseService;

@Service
public class PrivateInfoCompanyService extends BaseService {
	
	@Autowired
	private	AttachFileService attachFileSvc;
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public String updateFileId(final Param param) throws Exception {
		
		String atchFileId  = attachFileSvc.getAtchFileId();
		
		Param updateParam = new Param();
		updateParam.put("company_id", param.get("company_id"));
		updateParam.put("atch_file_id", atchFileId);
		
		int resultInt = session.update("com.softworks.springframework.privateInfoCompany.updateFileId", updateParam);
		
		return (resultInt > 0 )? atchFileId : "";
	}
	
	@Transactional(readOnly=true)
	public Param getPrivateInfoCompanyOne(Param param) {
		return session.selectOne("com.softworks.springframework.privateInfoCompany.getPrivateInfoCompanyOne", param);
	}
	
	@Transactional(readOnly=true)
	public int getPrivateInfoCompanyListCount(Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*10));
		return session.selectOne("com.softworks.springframework.privateInfoCompany.getPrivateInfoCompanyListCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getPrivateInfoCompanyList(Param param) {
		return session.selectList("com.softworks.springframework.privateInfoCompany.getPrivateInfoCompanyList", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertPrivateInfoCompany(Param param)throws Exception {
		session.insert("com.softworks.springframework.privateInfoCompany.insertPrivateInfoCompany", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updatePrivateInfoCompany(final Param param) throws Exception {
		session.update("com.softworks.springframework.privateInfoCompany.updatePrivateInfoCompany", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deletePrivateInfoCompany(Param param)throws Exception {
		session.delete("com.softworks.springframework.privateInfoCompany.deletePrivateInfoCompany", param);
	}
	
	@Transactional(readOnly=true)
    public void getPrivateInfoCompanyListExcel(final Param param, final ModelMap model) throws SQLException {
		
		param.set("provider_typ_cd", "THIRD");
		List<Param> resultList1 = session.selectList("com.softworks.springframework.privateInfoCompany.getPrivateInfoCompanyListExcel", param);
		param.set("provider_typ_cd", "CONSIGN");
		List<Param> resultList2 = session.selectList("com.softworks.springframework.privateInfoCompany.getPrivateInfoCompanyListExcel", param);
		
		for(Param temp : resultList1){
			String ski_company_list1 = temp.get("SKI_COMPANY_LIST");
			String[] ski_company_list = ski_company_list1.split("\\,");
			ArrayList<String> ski_company_list_nm = new ArrayList<String>();
			for(String company : ski_company_list){
				String change = "";
				if("H10".equals(company)){
					change = company.replace("H10", "SK에너지");	
				}else if("H13".equals(company)){
					change = company.replace("H13", "SK트레이딩인터내셔널");
				}else if("H17".equals(company)){
					change = company.replace("H17", "SK인천석유화학");
				}else if("H40".equals(company)){
					change = company.replace("H40", "SK루브리컨츠");
				}else if("H50".equals(company)){
					change = company.replace("H50", "SK종합화학");
				}else if("H60".equals(company)){
					change = company.replace("H60", "SK이노베이션");
				}else if("H63".equals(company)){
					change = company.replace("H63", "SK아이이테크놀로지");
				}
				ski_company_list_nm.add(change);
			}
			temp.set("SKI_COMPANY_LIST_NM", ski_company_list_nm);
		}
		
		for(Param temp : resultList2){
			String ski_company_list1 = temp.get("SKI_COMPANY_LIST");
			String[] ski_company_list = ski_company_list1.split("\\,");
			ArrayList<String> ski_company_list_nm = new ArrayList<String>();
			for(String company : ski_company_list){
				String change = "";
				if("H10".equals(company)){
					change = company.replace("H10", "SK에너지");	
				}else if("H13".equals(company)){
					change = company.replace("H13", "SK트레이딩인터내셔널");
				}else if("H17".equals(company)){
					change = company.replace("H17", "SK인천석유화학");
				}else if("H40".equals(company)){
					change = company.replace("H40", "SK루브리컨츠");
				}else if("H50".equals(company)){
					change = company.replace("H50", "SK종합화학");
				}else if("H60".equals(company)){
					change = company.replace("H60", "SK이노베이션");
				}else if("H63".equals(company)){
					change = company.replace("H63", "SK아이이테크놀로지");
				}
				ski_company_list_nm.add(change);
			}
			temp.set("SKI_COMPANY_LIST_NM", ski_company_list_nm);
		}
		
		String[] category	= {   "No", "업체명", "업무유형" , "업무내용", "업무상세"
								 , "SKI관련계열사목록"
								 , "담당자"
								 ,"개인정보제공목적"
								 ,"개인정보제공항목"
								 ,"개인정보보유/파기기한"
								 ,"관련법근거"
								 ,"개인정보제공건수"
								 ,"개인정보제공방법"
								 ,"비고"
								 ,"갱신확인여부"
								 ,"최종갱신일시"
								 ,"최종갱신자"
								 ,"최종갱신자(ID)"
								 };
		String[] columns	= {  "RNUM", "COMPANY_NM", "BUSI_TYP", "BUSI_INFO", "BUSI_DETAIL"
								, "SKI_COMPANY_LIST_NM"
								, "MANAGER_EMP_NO"
								,"PURPOSE_PROVIDE"
								,"PRIVATE_INFO_LIST"
								,"RETENTION_PERIOD"
								,"REL_LAWS_BASIS"
								,"PROVIDE_NUM"
								,"PROVIDE_METHOD"
								,"NOTE"
								,"UPDATE_YN"
								,"LAST_UPD_DT"
								,"LAST_UPD_EMP_NM"
								,"LAST_UPD_EMP_NO"
								};
		int[]	 colWidth	= {20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20};

		List<Map> list = new ArrayList<Map>();
		
		for (int i = 0; i < 2; i++) {
			Map map = new HashMap();

	        map.put("category", category);
	        map.put("columns", columns);
	        map.put("columnsWidth", colWidth);
	        if(i == 0){
	        	map.put("chapter", "제3자 제공업체");
	        	map.put("data", resultList1);
	        }else{
	        	map.put("chapter", "수탁업체");
	        	map.put("data", resultList2);
	        }

			list.add(map);
		}
		model.addAttribute("filename", "개인정보제공업체현황관리"+"_"+Utils.getTimeStampString("yyyyMMdd"));
		model.addAttribute("multiSheet", list);
    }
	
	@Transactional(readOnly=true)
    public void getPrivateInfoCompanyListExcel1(final Param param, final ModelMap model) throws SQLException {

		int[]	 colWidth	= {20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20};
		
		model.addAttribute("category", new String[] { "No", "업체명", "업무유형" , "업무내용", "업무상세", "SKI관련계열사목록", "담당자"
													 ,"개인정보제공목적"
													 ,"개인정보제공항목"
													 ,"개인정보보유/파기기한"
													 ,"관련법근거"
													 ,"개인정보제공건수"
													 ,"개인정보제공방법"
													 ,"비고"
													 ,"갱신확인여부"
													 ,"최종갱신일시"
                 });
        
        model.addAttribute("columns", new String[] { "RNUM", "COMPANY_NM", "BUSI_TYP", "BUSI_INFO", "BUSI_DETAIL", "SKI_COMPANY_LIST", "MANAGER_EMP_NO"
        											,"PURPOSE_PROVIDE"
        											,"PRIVATE_INFO_LIST"
        											,"RETENTION_PERIOD"
        											,"REL_LAWS_BASIS"
        											,"PROVIDE_NUM"
        											,"PROVIDE_METHOD"
        											,"NOTE"
        											,"UPDATE_YN"
        											,"LAST_UPD_DT"
                });

        model.addAttribute("columnsWidth", colWidth);
    	model.addAttribute("chapter", "제3자 제공업체");
        model.addAttribute("filename", "제3자 제공업체"+"_"+Utils.getTimeStampString("yyyyMMdd"));
           
        model.addAttribute("data", session.selectList("com.softworks.springframework.privateInfoCompany.getPrivateInfoCompanyListExcel", param));
        
    }
	
	@Transactional(readOnly=true)
    public void getPrivateInfoCompanyListExcel2(final Param param, final ModelMap model) throws SQLException {

		int[]	 colWidth	= {20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20};

		model.addAttribute("category", new String[] { "No", "업체명", "업무유형" , "업무내용", "업무상세", "SKI관련계열사목록", "담당자"  
													 ,"업체담당자명"
													 ,"회사전화번호"
													 ,"이동전화번호"
													 ,"이메일주소"
													 ,"지역"
													 ,"주소(업무수행위치)"
													 ,"개인정보제공항목"
													 ,"Bi-OK등록여부"
													 ,"개인정보합의서체결여부"
													 ,"재위탁여부"
													 ,"비고"
													 ,"갱신확인여부"
													 ,"최종갱신일시"
                 });
        
        model.addAttribute("columns", new String[] { "RNUM", "COMPANY_NM", "BUSI_TYP", "BUSI_INFO", "BUSI_DETAIL", "SKI_COMPANY_LIST", "MANAGER_EMP_NO"
									        		,"PROVIDER_MANAGER_NM"
									        		,"OFFICE_TEL_NO"
									        		,"MOBILE_NO"
									        		,"EMAIL"
									        		,"OFFICE_REGION"
									        		,"OFFICE_ADDR"
									        		,"PRIVATE_INFO_LIST"
									        		,"BIOK_REG_YN"
									        		,"PA_SIGN_YN"
									        		,"REISSUE_YN"
									        		,"NOTE"
									        		,"UPDATE_YN"
									        		,"LAST_UPD_DT"
                });

        model.addAttribute("columnsWidth", colWidth);
    	model.addAttribute("chapter", "수탁업체");
        model.addAttribute("filename", "수탁업체"+"_"+Utils.getTimeStampString("yyyyMMdd"));
           
        model.addAttribute("data", session.selectList("com.softworks.springframework.privateInfoCompany.getPrivateInfoCompanyListExcel", param));
        
    }
	
}