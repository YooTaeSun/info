package com.softworks.springframework.web.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.utils.AesUtil;
import com.softworks.springframework.utils.DrmUtil;
import com.softworks.springframework.utils.FileUtil;
import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.utils.ZipUtils;
import com.softworks.springframework.web.services.CodeLoaderService.CodeInfo;
import com.softworks.springframework.web.services.front.FileDownloadHistService;
import com.softworks.springframework.web.services.front.ProofService;
import com.softworks.springframework.web.services.front.SecurityAuditDetailService;
import com.softworks.springframework.web.services.front.SecurityAuditService;

@Service
public class AttachFileService extends BaseService {


	@Autowired
	private	SecurityAuditService securityAuditSvc;

	@Autowired
	private	SecurityAuditDetailService securityAuditDetailSvc;

	@Autowired
	private	AttachFileDetailService attachFileDetailSvc;

	@Autowired
	private	FileDownloadHistService fileDownloadHistSvc;

	@Autowired
	private MailSendService	mailSendSvc;

	@Autowired
	private ExcelService ExcelSvc;

	@Autowired
	private	ProofService proofSvc;

	static String localFlag = Property.getProperty("local.flag");
	final static String fileRootPath	= (localFlag.equals("Y"))? Property.getProperty("file.root.path.win") : Property.getProperty("file.root.path.linux");
	final static String uploadTmpPrefix = Property.getProperty("file.upload.temp");
	final static String batchDownPrefix = Property.getProperty("file.batch.down");
	final static String uploadPrefix = Property.getProperty("file.upload.real");
	final static String dlmt = "/";
	final static String newLine = "\r\n";

	public String getAllowFileExtStr() {
		List<CodeInfo> fileAllowExtList = this.getUseCodeList("FILE_ALLOW_EXT");
		StringBuffer codesSb =  new StringBuffer();
		String allowFileExtStr  = "";
		for (CodeInfo codeInfo : fileAllowExtList) {
			codesSb.append("|" + codeInfo.getCode());
		}

		if(codesSb.length() > 0) {
			allowFileExtStr = codesSb.toString().substring(1);
		}
		return allowFileExtStr;
	}


	@Transactional(readOnly=true)
	public String getAtchFileId() {
		return session.selectOne("com.softworks.springframework.AttachFile.getAtchFileId");
	}

	@Transactional(readOnly=true)
	public int getListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));

		return session.selectOne("com.softworks.springframework.AttachFile.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) {
		return session.selectList("com.softworks.springframework.AttachFile.getList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getAllList(final Param param) {
		return session.selectList("com.softworks.springframework.AttachFile.getAllList", param);
	}

	@Transactional(readOnly=true)
	public Param getDetail(Param param) {
		return session.selectOne("com.softworks.springframework.AttachFile.getAllList", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int insert(final Param param) throws SQLException {
		return session.insert("com.softworks.springframework.AttachFile.insert", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public String insertGetId(final Param param) throws SQLException {
		session.insert("com.softworks.springframework.AttachFile.insertGetId", param);
		return param.get("atch_file_id");
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void update(final Param param) throws Exception {
		session.update("com.softworks.springframework.AttachFile.update", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void delete(final Param param) throws Exception {
		session.delete("com.softworks.springframework.AttachFile.delete", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public List<Param> uploadFile(List<MultipartFile> fileList, Param param) throws Exception {

		String atch_file_id = param.get("atch_file_id");
		String overwrite = Utils.nvl(param.get("overwrite"));
		String uid = param.get("uid");
		String uname = param.get("uname");
		String eval_cd = param.get("eval_cd");
		String zip_pwd = param.get("zip_pwd");
		String busi_site_list = param.get("busi_site_list");
		String proof_seq = param.get("proof_seq");
		String confirm_yn = param.get("confirm_yn");
		String yyyy = param.get("yyyy");

		List<Param> selFileList = new ArrayList<Param>();

		for (MultipartFile uploadFile : fileList) {

			String msg = checkUpload(uploadFile);
			if(!msg.equals("")) {
				throw new Exception(msg);
			}

			String originalFilename = FileUtil.getFileNameExceptExtsn(uploadFile.getOriginalFilename());
			String file_extsn = FileUtil.getFileExtsn(uploadFile.getOriginalFilename());
			logger.debug("originalFilename >> "  + originalFilename + ": file_extsn >> " + file_extsn);

			if(originalFilename.length() > 255) {
				throw new Exception("원본 파일명은 255자 이하 입니다.");
			}

			long size = uploadFile.getSize();
			String filename = FileUtil.createFilename();

			String addImagePath = FileUtil.addPath();
			String fullPath = uploadPrefix + dlmt + addImagePath + dlmt + filename;
			String encFullPath = fullPath;

			File file = new File(FileUtil.createNewFile(fileRootPath + fullPath));

			int timeCnt = 0;
			while (!file.exists() && timeCnt < 25) {//5초
				timeCnt++;
				Thread.sleep(250);
			}

			uploadFile.transferTo(file);

			//drm 암호화
			if(!localFlag.equals("Y")) {

				logger.debug("[uploadFile] fullPath >> " + fullPath);
				encFullPath = FileUtil.getEncFullPath(fullPath);
				logger.debug("[uploadFile] encFullPath  >> " + encFullPath);

				boolean isEncrypt = DrmUtil.encryption(fileRootPath + fullPath, fileRootPath + encFullPath, file_extsn);

				File encFullFile =  new File(fileRootPath + encFullPath);
				timeCnt = 0;
				while (!encFullFile.exists() && timeCnt < 25) {//5초
					timeCnt++;
					Thread.sleep(200);
				}

				if(encFullFile.exists()) {
					logger.debug("[uploadFile] encFullFile exists Yes >> " + encFullFile);
					file.delete();
					logger.debug("[uploadFile] file remove >> " + file.getAbsolutePath());
				}else {
					logger.debug("[uploadFile] encFullPath exists No >> " + encFullPath);
				}
			}

			Param selFileparam = new Param();

			Param insertParam = this.getDetail(param);

			int resultInt = 0;
			if(insertParam == null) {
				insertParam = new Param();
				insertParam.put("atch_file_id", atch_file_id);
				//insert ATTACH_FILE
				resultInt += this.insert(param);
			}

			insertParam.put("atch_file_id", atch_file_id);
			insertParam.put("file_path", encFullPath);
			insertParam.put("src_file_nm", originalFilename);
			insertParam.put("save_file_nm", filename);
			insertParam.put("file_extsn", file_extsn);
			insertParam.put("file_size", String.valueOf(size));
			insertParam.put("reg_id", uid);
			insertParam.put("upd_id", uid);
			insertParam.put("reg_nm", uname);
			insertParam.put("upd_nm", uname);

			if(!eval_cd.isEmpty()) {
				insertParam.put("eval_cd", eval_cd);
			}

			if(!zip_pwd.isEmpty()) {
				insertParam.put("zip_pwd", zip_pwd);
			}

			if(!busi_site_list.isEmpty()) {
				insertParam.put("busi_site_list", busi_site_list);
			}

			if(!proof_seq.isEmpty()) {
				insertParam.put("proof_seq", proof_seq);
			}

			if(!confirm_yn.isEmpty()) {
				insertParam.put("confirm_yn", confirm_yn);
			}

			if(!yyyy.isEmpty()) {
				insertParam.put("yyyy", yyyy);
			}

			resultInt += attachFileDetailSvc.insert(insertParam);

			Param selParam = new Param();
			selParam.put("atch_file_id", atch_file_id);
			selParam.put("file_sn", (String)insertParam.get("file_sn"));
			selFileList.add(attachFileDetailSvc.getDetail(selParam));

			if("Y".equals(overwrite)) {
				Param selOverParam =  new Param();
				selOverParam.put("atch_file_id", atch_file_id);
				selOverParam.put("no_file_sn", insertParam.get("file_sn"));
				selOverParam.put("src_file_nm", originalFilename);
				Param existFile =  attachFileDetailSvc.getDetail(selOverParam);
				//존재하면 지운다
				if(existFile != null) {
					Param removeParam =  new Param();
					removeParam.put("atch_file_id", existFile.get("ATCH_FILE_ID"));
					removeParam.put("file_sn", existFile.get("FILE_SN"));
					this.removeFile(removeParam);
				}
			}

		}
		return selFileList;
	}
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})


	public List<Param> uploadFileToDb(List<MultipartFile> fileList, Param param) throws Exception {

		String atch_file_id = param.get("atch_file_id");
		String uid = param.get("uid");
		String uname = param.get("uname");
		String eval_cd = param.get("eval_cd");
		String zip_pwd = param.get("zip_pwd");
		String busi_site_list = param.get("busi_site_list");
		String proof_seq = param.get("PROOF_SEQ");
		String confirm_yn = param.get("confirm_yn");
		String yyyy = param.get("yyyy");

		List<Param> selFileList = new ArrayList<Param>();

		for (MultipartFile uploadFile : fileList) {

			String msg = checkUpload(uploadFile);
			if(!msg.equals("")) {
				throw new Exception(msg);
			}

			String originalFilename = FileUtil.getFileNameExceptExtsn(uploadFile.getOriginalFilename());
			String file_extsn = FileUtil.getFileExtsn(uploadFile.getOriginalFilename());
			logger.debug("originalFilename >> "  + originalFilename + ": file_extsn >> " + file_extsn);

			if(originalFilename.length() > 255) {
				throw new Exception("원본 파일명은 255자 이하 입니다.");
			}

			long size = uploadFile.getSize();
			String filename = FileUtil.createFilename();
			byte[] bytes = uploadFile.getBytes();

			Param selFileparam = new Param();

			Param insertParam = this.getDetail(param);

			int resultInt = 0;
			if(insertParam == null) {
				insertParam = new Param();
				insertParam.put("atch_file_id", atch_file_id);
				//insert ATTACH_FILE
				resultInt += this.insert(param);
			}

			insertParam.put("atch_file_id", atch_file_id);
			insertParam.put("file_path", "");
			insertParam.put("src_file_nm", originalFilename);
			insertParam.put("save_file_nm", filename);
			insertParam.put("file_extsn", file_extsn);
			insertParam.put("file_size", String.valueOf(size));
			insertParam.put("reg_id", uid);
			insertParam.put("upd_id", uid);
			insertParam.put("reg_nm", uname);
			insertParam.put("upd_nm", uname);
			insertParam.put("src_file_data", bytes);

			if(!eval_cd.isEmpty()) {
				insertParam.put("eval_cd", eval_cd);
			}

			if(!zip_pwd.isEmpty()) {
				insertParam.put("zip_pwd", zip_pwd);
			}

			if(!busi_site_list.isEmpty()) {
				insertParam.put("busi_site_list", busi_site_list);
			}

			if(!proof_seq.isEmpty()) {
				insertParam.put("proof_seq", proof_seq);
			}

			if(!confirm_yn.isEmpty()) {
				insertParam.put("confirm_yn", confirm_yn);
			}

			if(!yyyy.isEmpty()) {
				insertParam.put("yyyy", yyyy);
			}

			resultInt += attachFileDetailSvc.insert(insertParam);

			Param selParam = new Param();
			selParam.put("atch_file_id", atch_file_id);
			selParam.put("file_sn", (String)insertParam.get("file_sn"));
			selFileList.add(attachFileDetailSvc.getDetail(selParam));
		}
		return selFileList;
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public List<Param> removeFile(Param param) throws Exception{

		List<Param> fileList  = attachFileDetailSvc.getAllList(param);

		Param selFile = null;
			if(fileList != null && fileList.size() > 0) {
				String filePath = "";
				String tmnPath = "";

				Param delParam = null;
				for (int i=0, len = fileList.size();  i< len; i++) {
					selFile = fileList.get(i);
					filePath = selFile.get("FILE_PATH");
					FileUtils.deleteQuietly(new File(fileRootPath + filePath));

					delParam = new Param();
					delParam.put("atch_file_id", selFile.get("ATCH_FILE_ID"));
					delParam.put("file_sn", selFile.get("FILE_SN"));
					attachFileDetailSvc.delete(delParam);
				}
			}
		return fileList;
	}


	public void batchUploadResult(Param param) throws Exception {

		try{
			String[] origfilename = param.getValues("orgFileName"); 	// 원본 파일명
			String[] savefilename = param.getValues("saveFileName"); 	// 저장 파일명
			String[] filesize = param.getValues("saveFileSize"); 		// 파일 사이즈

			String atch_file_id = param.get("atch_file_id");

			String newFileName  = "";
			String orgFilePath = "";
			String zipFilePath = "";
			String newZipFileFullPath  = "";

			String uid = param.get("uid");
			String uname = param.get("uname");

			String fileSize = "";
			String fileName = "";
			String file_extsn = "";



			if (origfilename != null){
				for (int i = 0; i < origfilename.length; i++) {
					/* 여기에 업로드 파일 정보를 DB에 입력하는 코드를 작성 합니다. */

					fileSize = filesize[i];
					fileName = origfilename[i];

					newFileName = FileUtil.createFilename();
					orgFilePath = uploadTmpPrefix + dlmt + FileUtil.addPath();
					zipFilePath = uploadPrefix + dlmt + FileUtil.addPath();
					newZipFileFullPath = zipFilePath + dlmt + newFileName;

					param.put("zipFilePath", zipFilePath);
					param.set("newZipFileFullPath", newZipFileFullPath);

					File dir = new File(zipFilePath);

					if(!dir.exists()){
						dir.mkdirs();
					}

					String beforeloc = fileRootPath + orgFilePath + dlmt + savefilename[i];
					String afterloc = fileRootPath + newZipFileFullPath;

					logger.debug("[batchUploadResult] beforeloc >> "+ beforeloc);
					logger.debug("[batchUploadResult] afterloc >> "+ afterloc);

					if(localFlag.equals("Y")) {
						String[] winCmd = {"cmd", "/c","move", beforeloc.replaceAll("\\/", "\\\\"), afterloc.replaceAll("\\/", "\\\\")};
						Runtime runtime = Runtime.getRuntime();
						Process process = runtime.exec(winCmd);
						logger.debug("[batchUploadResult] local cmd move ");
					}else {
						orgFilePath = orgFilePath.replaceAll("\\/", "\\"+dlmt);
						String[] linuxCmd= {"mv", beforeloc, afterloc};
						Process process =Runtime.getRuntime().exec(linuxCmd);
//						process.waitFor();
						logger.debug("[batchUploadResult] server cmd move ");
					}

					File afterFile = new File(afterloc);
					int timeCnt = 0;
					while (!afterFile.exists() && timeCnt < 25) {//5초
						timeCnt++;
						Thread.sleep(200);
					}

					Param insertParam = new Param();
					insertParam.put("atch_file_id", atch_file_id);
					insertParam.put("file_path", zipFilePath + dlmt + newFileName);
					insertParam.put("src_file_nm", FileUtil.getFileNameExceptExtsn(fileName));
					insertParam.put("save_file_nm", newFileName);

					file_extsn = FileUtil.getFileExtsn(fileName);

					insertParam.put("file_extsn", file_extsn);
					insertParam.put("file_size", String.valueOf(fileSize));
					insertParam.put("reg_id", uid);
					insertParam.put("upd_id", uid);
					insertParam.put("reg_nm", uname);
					insertParam.put("upd_nm", uname);

					//zip 파일이면 압축해제
					String reg_log =  "";
					if("zip".equals(file_extsn)) {

						reg_log += this.unZipFile(param);

					}else {
						reg_log += String.format(newLine +"[%s] zip 파일이 아닙니다.", Utils.getTimeStampString("yyyy-MM-dd hh:mm:ss"));
					}
					insertParam.put("reg_log", reg_log);
					logger.debug("[batchUploadResult] reg_log >> "+ reg_log);
					attachFileDetailSvc.insert(insertParam);
				}
			}

		}catch(Exception e){
			//e.printStackTrace();
			logger.error("[batchUploadResult] 001 >> "+ e);
		}
	}

	public String unZipFile(Param param) throws Exception {

		StringBuffer logSb = new StringBuffer(500);

        FileInputStream fis = null;
        ZipInputStream zis = null;
        ZipEntry zipentry = null;

		String audit_id =  param.get("audit_id");
		String uid =  param.get("uid");
		String uname =  param.get("uname");
		String eachFileFolderId = "";
		String atch_file_id =  param.get("atch_file_id");

		Param selParam = new Param();
		selParam.put("audit_id", audit_id);

		//파일
		List<Param> securityAuditDetailList = securityAuditDetailSvc.getAllList(selParam);
		if(securityAuditDetailList == null || securityAuditDetailList.size() == 0) {
			logSb.append(String.format(newLine +"[%s] %s 해당 폴더가  없습니다.", Utils.getTimeStampString("yyyy-MM-dd hh:mm:ss"), ""));
			return "";
		}

		Param directoryMap = new Param();
		for (Param e : securityAuditDetailList) {
			directoryMap.put(e.get("LS_ITEM_ID"), e.get("ATCH_FILE_ID"));
		}

		logger.debug("[unZipFile] directoryMap >> " + directoryMap.toString());

		//파일
		List<Param> regiedFileList = securityAuditDetailSvc.getBatchFileList(selParam);

		String zipFilePath =  param.get("zipFilePath");//zip파일(이름 안 포함)
		String newZipFileFullPath =  param.get("newZipFileFullPath");//새로운 zip파일(이름 포함)

		Param regiedFile = null;
		String onlyfileName = "";
		String srcFileNm = "";
		String folderId = "";
		String fileExtsn = "";
		String atchfileid = "";
		String ext = "";

		try {
			//파일 스트림
			fis = new FileInputStream(fileRootPath + newZipFileFullPath);
			zis = new ZipInputStream(fis,Charset.forName("EUC-KR"));

			String allowFileExtStr = this.getAllowFileExtStr();
			boolean zipNoExistFolder = true;

			while ((zipentry = zis.getNextEntry()) != null) {
				zipNoExistFolder = false;
				String filename = zipentry.getName();
				int fileSparator = filename.lastIndexOf("/");

				if(fileSparator == -1) {//하위 디렉토리가 없다.
					logSb.append(String.format(newLine +"[%s] %s은 저장 할 폴더가 없습니다.", Utils.getTimeStampString("yyyy-MM-dd hh:mm:ss"), filename));
					continue;
				}
				onlyfileName = filename.substring(fileSparator + 1);
				onlyfileName = onlyfileName.replace(" ", "_");

				if(!onlyfileName.isEmpty()) {

					ext = FileUtil.getFileExtsn(onlyfileName);

					if(allowFileExtStr.indexOf(ext) == -1) {
						logSb.append(String.format(newLine +"[%s] %s은(는) 업로드 지원하지 않는 확장자 입니다.", Utils.getTimeStampString("yyyy-MM-dd hh:mm:ss"), filename));
						continue;
					}
				}

				eachFileFolderId = filename.substring(0,fileSparator);
				eachFileFolderId = eachFileFolderId.replace(" ", "_");
				atchfileid = directoryMap.get(eachFileFolderId);

				if(onlyfileName.isEmpty()) {
					if(directoryMap.containsKey(eachFileFolderId)) {
						logSb.append(String.format(newLine +"[%s] %s 존재 하는 폴더 입니다.", Utils.getTimeStampString("yyyy-MM-dd hh:mm:ss"), filename));
					}else {
						logSb.append(String.format(newLine +"[%s] %s 존재 하는 않는 폴더 입니다.", Utils.getTimeStampString("yyyy-MM-dd hh:mm:ss"), filename));
					}
					continue;
				}

				if(fileSparator > 0 ) {

					if(directoryMap.containsKey(eachFileFolderId)) {

						if(regiedFileList != null && regiedFileList.size() > 0) {

							boolean isSameData = false;
							for (int i = 0; i < regiedFileList.size(); i++) {
								regiedFile = regiedFileList.get(i);
								srcFileNm = regiedFile.get("SRC_FILE_NM");
								folderId = regiedFile.get("LS_ITEM_ID");
								fileExtsn = regiedFile.get("FILE_EXTSN");

								if(folderId.equals(eachFileFolderId) && srcFileNm.equals(onlyfileName) && fileExtsn.equals(ext)) {
									//같은 파일 덮어치기
									logSb.append(String.format(newLine +"[%s] %s 같은 파일이 존재해서 덮어쓰기 합니다.", Utils.getTimeStampString("yyyy-MM-dd hh:mm:ss"), filename));

									Param insertParam = insertNewFile(zis, uid, uname, zipFilePath, onlyfileName, atchfileid);
									regiedFileList.remove(i);
									i--;

									//추가한 파일 존재하는 list에 추가
									insertParam.put("SRC_FILE_NM", insertParam.get("src_file_nm"));
									insertParam.put("LS_ITEM_ID", insertParam.get("LS_ITEM_ID"));
									insertParam.put("NO_SAVE_DATA", "Y");
									regiedFileList.add(insertParam);

									//존대하는 파일 지운기
									Param selOverParam =  new Param();
									selOverParam.put("atch_file_id", atchfileid);
									selOverParam.put("no_file_sn", insertParam.get("file_sn"));

									if(srcFileNm.lastIndexOf(".") > -1) {
										selOverParam.put("src_file_nm", srcFileNm.substring(0, srcFileNm.lastIndexOf(".")));
									}else {
										selOverParam.put("src_file_nm", srcFileNm);
									}

									Param existFile =  attachFileDetailSvc.getDetail(selOverParam);
									//존재하면 지운다
									if(existFile != null) {
										Param removeParam =  new Param();
										removeParam.put("atch_file_id", existFile.get("ATCH_FILE_ID"));
										removeParam.put("file_sn", existFile.get("FILE_SN"));
										this.removeFile(removeParam);
									}
									isSameData = true;
									break;
								}
							}
							//같은 데이타가 없으면
							if(!isSameData) {
								//없는 파일추가
								logSb.append(String.format(newLine +"[%s] %s 파일을 추가합니다.", Utils.getTimeStampString("yyyy-MM-dd hh:mm:ss"), filename));

								Param insertParam = insertNewFile(zis, uid, uname, zipFilePath, onlyfileName, atchfileid);

								//추가한 파일 존재하는 list에 추가
								insertParam.put("SRC_FILE_NM", insertParam.get("src_file_nm"));
								insertParam.put("LS_ITEM_ID", insertParam.get("LS_ITEM_ID"));
								insertParam.put("NO_SAVE_DATA", "Y");
								regiedFileList.add(insertParam);
							}

						}else {

							//없는 파일추가
							logSb.append(String.format(newLine +"[%s] %s 파일을 추가합니다.", Utils.getTimeStampString("yyyy-MM-dd hh:mm:ss"), filename));

							Param insertParam = insertNewFile(zis, uid, uname, zipFilePath, onlyfileName, atchfileid);

							//추가한 파일 존재하는 list에 추가
							insertParam.put("SRC_FILE_NM", insertParam.get("src_file_nm"));
							insertParam.put("LS_ITEM_ID", insertParam.get("LS_ITEM_ID"));
							insertParam.put("NO_SAVE_DATA", "Y");
							regiedFileList.add(insertParam);
						}


					}else {
						logSb.append(String.format(newLine +"[%s] %s 해당되는 폴더가 없습니다.", Utils.getTimeStampString("yyyy-MM-dd hh:mm:ss"), filename));
					}
				}else {
					logSb.append(String.format(newLine +"[%s] %s path가 없음", Utils.getTimeStampString("yyyy-MM-dd hh:mm:ss"), filename));
				}
			}

			if(zipNoExistFolder) {
				logSb.append(String.format(newLine +"[%s] 비어 있는 zip 파일.", Utils.getTimeStampString("yyyy-MM-dd hh:mm:ss")));
			}
			logger.debug("[unZipFile] logSb >> " + logSb.toString());

		} catch (Throwable e) {
			logSb.append(String.format(newLine +"[%s] ERROR %s ", Utils.getTimeStampString("yyyy-MM-dd hh:mm:ss"), e));
			throw new RuntimeException(e);
		} finally {
			if (zis != null)
				zis.close();
			if (fis != null)
				fis.close();
		}
		return logSb.toString();
	}

	private Param insertNewFile(ZipInputStream zis, String uid, String uname, String zipFilePath, String onlyfileName, String atchfileid) throws Exception, Throwable, IOException, SQLException {
		String newFileName =FileUtil.createFilename();
		File eachFile = new File(fileRootPath + zipFilePath, newFileName);
		String fullPath = eachFile.getAbsolutePath();
		String encFullPath = zipFilePath + dlmt + newFileName;

		//파일생성
		ZipUtils.createFile(eachFile, zis);

		//drm 암호화
		String fileExtsn = FileUtil.getFileExtsn(onlyfileName);

		if(!localFlag.equals("Y")) {

			logger.debug("[uploadFile] fullPath >> " + fullPath);
			encFullPath = FileUtil.getEncFullPath(fullPath);
			logger.debug("[uploadFile] encFullPath  >> " + encFullPath);

			boolean isEncrypt = DrmUtil.encryption(fullPath, encFullPath, fileExtsn);

			File encFullFile =  new File(fileRootPath + encFullPath);
			int timeCnt = 0;
			while (!encFullFile.exists() && timeCnt < 25) {//5초
				timeCnt++;
				Thread.sleep(200);
			}

			if(encFullFile.exists()) {
				logger.debug("[uploadFile] encFullFile exists Yes >> " + encFullFile);
				eachFile.delete();
				logger.debug("[uploadFile] file remove >> " + eachFile.getAbsolutePath());
			}else {
				logger.debug("[uploadFile] encFullPath exists No >> " + encFullPath);
			}
		}

		Param insertParam = new Param();
		insertParam.put("atch_file_id", atchfileid);
		insertParam.put("file_path", encFullPath.replaceFirst(fileRootPath, ""));
		insertParam.put("src_file_nm", FileUtil.getFileNameExceptExtsn(onlyfileName));
		insertParam.put("save_file_nm", newFileName);
		insertParam.put("file_extsn", fileExtsn);
		insertParam.put("file_size", String.valueOf(eachFile.length()));
		insertParam.put("reg_id", uid);
		insertParam.put("upd_id", uid);
		insertParam.put("reg_nm", uname);
		insertParam.put("upd_nm", uname);
		attachFileDetailSvc.insert(insertParam);
		return insertParam;
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public Param batchDownload(HashMap<String,Object> param) throws Exception {

		String type = Utils.nvl((String)param.get("type"));
		String uid = Utils.nvl((String)param.get("uid"));
		String uname = Utils.nvl((String)param.get("uname"));
		String email = Utils.nvl((String)param.get("email"));
		String is_send_mail = Utils.nvl((String)param.get("is_send_mail"),"Y");
		String src_file_nm = "";
		String zip_root_file_nm = "";

		List<Param> list = null;
		List<Param> folderList = null;

    	String filePath = "";
    	String srcFileNm = "";
    	String folderId = "";
    	String source = "";
    	String target = "";
    	int resultInt = -1;

		switch (type) {
		//여러  파일 압축
		case "BATCH":

			String batch_down_kind = Utils.nvl((String)param.get("batch_down_kind"));

			Param selParam = new Param();
			selParam.put("audit_id", Utils.nvl((String)param.get("audit_id")));
			Param detail = securityAuditSvc.getDetail(selParam);

			//자료 구분 수검/감사 제출용 증빙자료
			if("security".equals(batch_down_kind)) {
				folderList = securityAuditDetailSvc.getAllList(selParam);
				list = securityAuditDetailSvc.getDetailFileList(selParam);
				src_file_nm = FileUtil.sanitizeFileNm((detail.get("AUDIT_NM") + "_대상점검목록_수검감사제출용증빙자료").replace(" ", "_")) + "_" + Utils.getTimeStampString("yyyyMMdd");
			//관련 보안 통제 항목 증빙자료
			}else if("law".equals(batch_down_kind)) {
				folderList = securityAuditDetailSvc.getAllList(selParam);
				selParam.put("ls_id", detail.get("REL_LAWS_ID"));
				selParam.put("data_start_day", detail.get("DATA_START_DAY").replace(".", ""));
				selParam.put("data_end_day", detail.get("DATA_END_DAY").replace(".", ""));
				list = securityAuditDetailSvc.getDetailLawFileList(selParam);
				src_file_nm = FileUtil.sanitizeFileNm((detail.get("AUDIT_NM") + "_대상점검목록_관련보안통제항목증빙자료").replace(" ", "_")) + "_" + Utils.getTimeStampString("yyyyMMdd");
			}
			break;

		// 한 파일 압축
		case "SECU_YN":

			list = new ArrayList<Param>();
			Param fileInfo = (Param) param.get("fileInfo");
			list.add(fileInfo);
			src_file_nm = FileUtil.sanitizeFileNm(fileInfo.get("ORG_FILE_NM").replace(" ", "_")) + "_"+ Utils.getTimeStampString("yyyyMMdd");
			break;

		default:

			break;
		}

    	zip_root_file_nm = FileUtil.sanitizeFileNm(src_file_nm);

    	Param el = null;
    	Param folder = null;
    	String dirName = FileUtil.createFilename();
    	String delDir = batchDownPrefix + dlmt + FileUtil.addPath() + dlmt + dirName;
    	String zipRootFromDir = batchDownPrefix + dlmt + FileUtil.addPath() + dlmt + dirName + dlmt + zip_root_file_nm;
    	String zipRootToDir = uploadPrefix + dlmt + FileUtil.addPath() +  dlmt + dirName;
    	String zipFileFullPath = zipRootToDir + dlmt + zip_root_file_nm;
    	File zipRootDirFile = new File(fileRootPath + zipRootFromDir);
    	zipRootDirFile.mkdirs();
    	File zipRootToDirFile = new File(fileRootPath + zipRootToDir);
    	zipRootToDirFile.mkdirs();

    	if(folderList != null && folderList.size() > 0 ) {
    		for (int fi = 0; fi < folderList.size(); fi++) {
    			folder = folderList.get(fi);
    			folderId = Utils.nvl(folder.get("LS_ITEM_ID"),"") ;
    			File folderFile =  new File(fileRootPath + zipRootFromDir + dlmt + folderId);
    			logger.debug("[batchDownload] folder mkdirs >> " + fileRootPath + zipRootFromDir + dlmt + folderId);
    			folderFile.mkdirs();
    		}
    	}

    	if(list != null && list.size() > 0) {
	    	for (int i = 0; i < list.size(); i++) {
	    		el = list.get(i);
	    		filePath = el.get("FILE_PATH");
	    		srcFileNm = el.get("SRC_FILE_NM");
	    		folderId = Utils.nvl(el.get("LS_ITEM_ID"),"") ;

	    		source = filePath;

	    		if(!folderId.isEmpty()) {
	    			//일괄다운로드시
	    			target = fileRootPath + zipRootFromDir + dlmt + folderId + dlmt + srcFileNm;
	    		}else {
	    			//M_CHECKLIST SECU_YN=Y시
	    			target = fileRootPath + zipRootFromDir + dlmt + srcFileNm;
	    		}

	    		logger.debug("[batchDownload] target >> " + target);

	    		if(!FileUtil.copyFile(fileRootPath + source, FileUtil.createNewFile(target))) {
	    			logger.error("===========	[batchDownload] copy start	==================");
	    			logger.error("[batchDownload]	target >> " + target);
	    			logger.error("[batchDownload]	source >> " + source);
	    			logger.error("===========	batchDownload copy end	==================");
	    			throw new Exception("[batchDownload] copy fail");
	    		}
	    	}
    	}


    	String zip_pwd = RandomStringUtils.random(8,true, true);
    	logger.debug("[batchDownload] zip_pwd >> " + zip_pwd);

    	String zip_pwd_aes = AesUtil.encrypt(zip_pwd);
    	logger.debug("[batchDownload] zip_pwd_aes >> " + zip_pwd_aes);

		if(type.equals("BATCH")) {
			ZipUtils.zipDirEncrypt(zip_pwd, zipRootFromDir, zipFileFullPath);
		}else if(type.equals("SECU_YN")) {
			ZipUtils.zipDirEncrypt(zip_pwd, zipRootFromDir, zipFileFullPath);
		}

    	File zipFile = new File(fileRootPath +  zipFileFullPath);

    	String atch_file_id = Utils.nvl((String)param.get("atch_file_id"));
    	String from = Utils.nvl((String)param.get("from"));//최종증빙파일 만들기

    	Param insertParam = new Param();
    	if(from.equals("updateAuditStateCd")) {
    		insertParam.put("atch_file_id", atch_file_id);
    	}else {
    		atch_file_id = this.getAtchFileId();
    		//DB입력
    		insertParam.put("atch_file_id", atch_file_id);
    		resultInt += this.insert(insertParam);
    	}

		logger.debug("[batchDownload] src_file_nm >> " + src_file_nm);

		insertParam.put("file_path", zipFileFullPath);
		insertParam.put("src_file_nm", src_file_nm);
		insertParam.put("save_file_nm", dirName);
		insertParam.put("file_extsn", "zip");
		insertParam.put("file_size", String.valueOf(zipFile.length()));
		insertParam.put("reg_id", uid);
		insertParam.put("upd_id", uid);
		insertParam.put("reg_nm", uname);
		insertParam.put("upd_nm", uname);
		resultInt += attachFileDetailSvc.insert(insertParam);


		Param insertFileSel = new Param();
		insertFileSel.put("atch_file_id", atch_file_id);
		insertFileSel.put("file_sn", (String)insertParam.get("file_sn"));
		Param insertFileInfo =  attachFileDetailSvc.getDetail(insertFileSel);

		//폴더만 존재시 관리자 보안파일다운로드이력에 no insert
		if(list != null && list.size() > 0) {
			Param insertDownParam = new Param();
			insertDownParam.put("atch_file_id", atch_file_id);
			insertDownParam.put("zip_pwd", zip_pwd_aes);
			insertDownParam.put("req_id", uid);
			insertDownParam.put("req_nm", uname);
			insertDownParam.put("req_mail_addr", email);
			fileDownloadHistSvc.insert(insertDownParam);

			//메일 (일괄다운로드 zip파일 암호 이메일 전송)
			if("Y".equals(is_send_mail)) {//default Y
				Param contentReplaceParam = new Param();
				contentReplaceParam.set("#FILE_NM#", src_file_nm);
				contentReplaceParam.set("#ZIP_PWD#", zip_pwd);
				//EM11	내부사용자	실시간		내부 사용자	[알림] 증빙자료 압축 파일 암호	{FILE_NM},{ZIP_PWD}	"요청하신 증빙자료 압축 파일 암호입니다.
				mailSendSvc.sendMail2("EM11", uid, contentReplaceParam);
			}
		}

		//zip 파일 만들 폴더 삭제
		FileUtil.deleteFile(fileRootPath + delDir);

		return insertFileInfo;
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public Param proofDownload(HashMap<String,Object> param) throws Exception {

		String uid = Utils.nvl((String)param.get("uid"));
		String uname = Utils.nvl((String)param.get("uname"));
		String email = Utils.nvl((String)param.get("email"));
		String is_send_mail = Utils.nvl((String)param.get("is_send_mail"),"Y");
		String src_file_nm = "";
		String zip_root_file_nm = "";

		List<Param> list = null;
		List<Param> folderList = null;

		String filePath = "";
		String srcFileNm = "";
		String folderId = "";
		String source = "";
		String target = "";
		int resultInt = -1;

		Param param01 = new Param(param);

		String start_day = Utils.nvl(param01.get("start_day").toString().replace("-", ""),"");
		String end_day = Utils.nvl(param01.get("end_day").toString().replace("-", ""),"");

		if(!start_day.isEmpty()) {
			param01.put("start_day",start_day + " 000000");
		}

		if(!end_day.isEmpty()) {
			param01.put("end_day",end_day + " 235959");
		}

		folderList = proofSvc.getFolderList(param01);
		list = proofSvc.getFileList(param01);

		src_file_nm = FileUtil.sanitizeFileNm("보안증적관리현황조회_" + Utils.getTimeStampString("yyyyMMdd"));
		zip_root_file_nm = src_file_nm;

		Param el = null;
		Param folder = null;
		String dirName = FileUtil.createFilename();
		String delDir = batchDownPrefix + dlmt + FileUtil.addPath() + dlmt + dirName;
		String zipRootFromDir = batchDownPrefix + dlmt + FileUtil.addPath() + dlmt + dirName + dlmt + zip_root_file_nm;
		String zipRootToDir = uploadPrefix + dlmt + FileUtil.addPath() +  dlmt + dirName;
		String zipFileFullPath = zipRootToDir + dlmt + zip_root_file_nm;
		File zipRootDirFile = new File(fileRootPath + zipRootFromDir);
		zipRootDirFile.mkdirs();
		File zipRootToDirFile = new File(fileRootPath + zipRootToDir);
		zipRootToDirFile.mkdirs();

		if(folderList != null && folderList.size() > 0 ) {
			for (int fi = 0; fi < folderList.size(); fi++) {
				folder = folderList.get(fi);
				folderId = Utils.nvl(folder.get("CHECKLIST_ID"),"") ;
				File folderFile =  new File(fileRootPath + zipRootFromDir + dlmt + folderId);
				logger.debug("[proofDownload] folder mkdirs >> " + fileRootPath + zipRootFromDir + dlmt + folderId);
				folderFile.mkdirs();
			}
		}

		if(list != null && list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				el = list.get(i);
				filePath = el.get("FILE_PATH");
				srcFileNm = el.get("SRC_FILE_NM");
				folderId = Utils.nvl(el.get("CHECKLIST_ID"),"") ;

				source = filePath;
				target = fileRootPath + zipRootFromDir + dlmt + folderId + dlmt + srcFileNm;

				logger.debug("[proofDownload] target >> " + target);

				if(!FileUtil.copyFile(fileRootPath + source, FileUtil.createNewFile(target))) {
					logger.error("===========	[batchDownload] copy start	==================");
					logger.error("[batchDownload]	target >> " + target);
					logger.error("[batchDownload]	source >> " + source);
					logger.error("===========	batchDownload copy end	==================");
					throw new Exception("[proofDownload] copy fail");
				}
			}
		}

		//엑셀 만들기
		String[] category = {
				 "보안 영역","Sub영역","진단 항목","공통ID","Level"
				,"체크리스트","부서평가","내부평가","목표수준"
				};
		String[] columns = {
				"MAIN_AREA_NM","SUB_AREA_NM","CHK_ITEM_NM","CHECKLIST_ID","CHK_LEVEL_CD"
				,"CHECKLIST_NM","DEPT_EVAL_CD","SECU_EVAL_CD","GOAL_LEVEL_CD"
       		};

       int[] colWidth	= { 20, 20, 20, 20, 10,
    		   				50, 10, 10, 10
       				   };

       List<LinkedHashMap<String, String>> searchList =  (ArrayList<LinkedHashMap<String, String>>) ((HashMap)param01).get("searchList");

       LinkedHashMap model = new LinkedHashMap<>();
       model.put("fullPath", zipRootFromDir + dlmt + src_file_nm + ".xls");
       model.put("category", category);
       model.put("columns", columns);
       model.put("columnsWidth", colWidth);
       model.put("chapter", "1");
       model.put("filename", src_file_nm + ".xls");
       model.put("data", proofSvc.getAllList(param01));
       model.put("searchList", searchList);

       List<String> search_data = new ArrayList<String>();

       ExcelSvc.make(model);


		String zip_pwd = RandomStringUtils.random(8,true, true);
		logger.debug("[proofDownload] zip_pwd >> " + zip_pwd);

		String zip_pwd_aes = AesUtil.encrypt(zip_pwd);
		logger.debug("[proofDownload] zip_pwd_aes >> " + zip_pwd_aes);
		ZipUtils.zipDirEncrypt(zip_pwd, zipRootFromDir, zipFileFullPath);

		File zipFile = new File(fileRootPath +  zipFileFullPath);

		String atch_file_id = Utils.nvl((String)param.get("atch_file_id"));
		Param insertParam = new Param();
		if(atch_file_id.isEmpty()) {
			atch_file_id = this.getAtchFileId();
			//DB입력
			insertParam.put("atch_file_id", atch_file_id);
			resultInt += this.insert(insertParam);
		}else {
			insertParam.put("atch_file_id", atch_file_id);
		}

		logger.debug("[proofDownload] src_file_nm >> " + src_file_nm);

		insertParam.put("file_path", zipFileFullPath);
		insertParam.put("src_file_nm", src_file_nm);
		insertParam.put("save_file_nm", dirName);
		insertParam.put("file_extsn", "zip");
		insertParam.put("file_size", String.valueOf(zipFile.length()));
		insertParam.put("reg_id", uid);
		insertParam.put("upd_id", uid);
		insertParam.put("reg_nm", uname);
		insertParam.put("upd_nm", uname);
		resultInt += attachFileDetailSvc.insert(insertParam);

		Param insertFileSel = new Param();
		insertFileSel.put("atch_file_id", atch_file_id);
		insertFileSel.put("file_sn", (String)insertParam.get("file_sn"));
		Param insertFileInfo =  attachFileDetailSvc.getDetail(insertFileSel);

		//폴더만 존재시 관리자 보안파일다운로드이력에 no insert
		if(list != null && list.size() > 0) {
			Param insertDownParam = new Param();
			insertDownParam.put("atch_file_id", atch_file_id);
			insertDownParam.put("zip_pwd", zip_pwd_aes);
			insertDownParam.put("req_id", uid);
			insertDownParam.put("req_nm", uname);
			insertDownParam.put("req_mail_addr", email);
			fileDownloadHistSvc.insert(insertDownParam);

			//메일 (일괄다운로드 zip파일 암호 이메일 전송)
			if("Y".equals(is_send_mail)) {//default Y
				Param contentReplaceParam = new Param();
				contentReplaceParam.set("#FILE_NM#", src_file_nm);
				contentReplaceParam.set("#ZIP_PWD#", zip_pwd);
				//EM11	내부사용자	실시간		내부 사용자	[알림] 증빙자료 압축 파일 암호	{FILE_NM},{ZIP_PWD}	"요청하신 증빙자료 압축 파일 암호입니다.
				mailSendSvc.sendMail2("EM11", uid, contentReplaceParam);
			}
		}

		//zip 파일 만들 폴더 삭제
		FileUtil.deleteFile(fileRootPath + delDir);

		return insertFileInfo;
	}


	public String checkUpload(MultipartFile upload) throws Exception {

		String fileDrmExt = this.getAllowFileExtStr();
		String originalFilename = upload.getOriginalFilename();
		String ext = "";
		String typeStr = "";
		long uploadMaxsize = 50 * 1024 * 1024;

		if(originalFilename.lastIndexOf(".") > -1) {

			ext = FileUtil.getFileExtsn(originalFilename);

			if(fileDrmExt.indexOf(ext) == -1) {
				return ext +"은(는) 지원하지 않는 확장자 입니다.";
			}

		}else {
			return "확장자가 없습니다.";
		}

		if(originalFilename.indexOf(";") > -1 || originalFilename.indexOf("%00") > -1 || originalFilename.indexOf("%zz") > -1) {
			return "파일명에 허용되지 않는 특수문자가 있습니다.";
		}

		 long size = upload.getSize();
		 if(size > uploadMaxsize) {
			 return typeStr + " 용량은 "+(uploadMaxsize/1024/1024)+"메가를 초과할 수 없습니다.";
		 }
		return "";
	}


}
