package com.softworks.springframework.web.services.backoffice;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class SitePopupService extends BaseService {

	@Transactional(readOnly=true)
	public int getListCount(final Param param) throws Exception {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		
		return (Integer)session.selectOne("com.softworks.springframework.SitePopup.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) throws Exception {
		return session.selectList("com.softworks.springframework.SitePopup.getList", param);
	}

	@Transactional(readOnly=true)
	public Param getInfo(final int seq) throws Exception {
		return (Param)session.selectOne("com.softworks.springframework.SitePopup.getInfo", seq);
	}
	
	public void insert(final Param param) throws Exception {
		session.insert("com.softworks.springframework.SitePopup.insert", param);
	}
	
	public void update(final Param param) throws Exception {
		session.insert("com.softworks.springframework.SitePopup.update", param);
	}
	
	public void delete(final Param param) throws Exception {
		session.insert("com.softworks.springframework.SitePopup.delete", param);
	}

}
