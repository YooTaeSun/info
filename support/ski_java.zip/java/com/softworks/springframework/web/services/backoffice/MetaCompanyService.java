package com.softworks.springframework.web.services.backoffice;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class MetaCompanyService extends BaseService {
	
	@Transactional(readOnly=true)
	public Param getCompanyBusiSiteOne(Param param) {
		return session.selectOne("com.softworks.springframework.MetaCompany.getCompanyBusiSiteOne", param);
	}
	
	@Transactional(readOnly=true)
	public int getCompanyBusiSiteListCount(Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*10));
		
		return session.selectOne("com.softworks.springframework.MetaCompany.getCompanyBusiSiteListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getCompanyBusiSiteList(Param param) {
		return session.selectList("com.softworks.springframework.MetaCompany.getCompanyBusiSiteList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getCompanyBusiSiteAllList(Param param) {
		return session.selectList("com.softworks.springframework.MetaCompany.getCompanyBusiSiteAllList", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertCompanyBusiSite(final Param param) throws Exception {
		session.insert("com.softworks.springframework.MetaCompany.insertCompanyBusiSite", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateCompanyBusiSite(final Param param) throws Exception {
		session.update("com.softworks.springframework.MetaCompany.updateCompanyBusiSite", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteCompanyBusiSite(final Param param) throws Exception {
		session.delete("com.softworks.springframework.MetaCompany.deleteCompanyBusiSite", param);
	}
	
	@Transactional(readOnly=true)
	public int isAttachFileDetail(Param param) {
		return session.selectOne("com.softworks.springframework.MetaCompany.isAttachFileDetail", param);
	}
	
	

}