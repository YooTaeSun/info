package com.softworks.springframework.web.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;

@Service
public class MainService extends BaseService {

    @Transactional(readOnly=true)
    public String getAttachFileName(final String type, final String num, final int seq) throws Exception {
        Param    param    = new Param();
                param.set("saveFileName",seq + "_attach_" + num);
                param.set("seq", seq);

        return (String)session.selectOne("com.softworks.springframework.Main.getAttachName", param);
    }

    @Transactional(readOnly=true)
    public List<Param> getNoticeList(final String company) {
        return session.selectList("com.softworks.springframework.Main.getNoticeList", company);
    }

    @Transactional(readOnly=true)
    public List<Param> getQnaList(final String uid) {
        return session.selectList("com.softworks.springframework.Main.getQnaList", uid);
    }

    @Transactional(readOnly=true)
    public List<Param> getPopupList(final String company_id) {
        return session.selectList("com.softworks.springframework.Main.getPopupList", company_id);
    }
    
    @Transactional(readOnly=true)
    public List<Param> getScheduleChartData(final Param param) {
        return session.selectList("com.softworks.springframework.Main.getScheduleChartData", param);
    }
    
    @Transactional(readOnly=true)
    public List<Param> getDignosisChartData(final Param param) {
        return session.selectList("com.softworks.springframework.Main.getDignosisChartData", param);
    }
    
    @Transactional(readOnly=true)
    public List<Param> getBestDignosisProject(final Param param) {
        return session.selectList("com.softworks.springframework.Main.getBestDignosisProject", param);
    }
    
    @Transactional(readOnly=true)
    public List<Param> getTop5LineChartData(final Param param) {
        return session.selectList("com.softworks.springframework.Main.getTop5LineChartData", param);
    }
    
//    @Transactional(readOnly=true)	//ljd
//    public List<Param> getBestUserList(final Param param) {
//		param.set("limitSize", param.getInt("limitSize", DEFAULT_PAGE_SIZE));
//        return session.selectList("com.softworks.springframework.Main.getBestUserList", param);
//    }

    @Transactional(readOnly=true)
    public int getMeasureResultCnt(final Param param) throws Exception {
        return (Integer)session.selectOne("com.softworks.springframework.Main.getMeasureResultCnt", param);
    }

    // 점검계획 목록
    @Transactional(readOnly=true)
    public List<Param> getDiagList(final Param param) {
        return session.selectList("com.softworks.springframework.Main.getDiagList", param);
    }

    // 본부장/팀장/보안담당자 - 점검항목별 위반건수
    @Transactional(readOnly=true)
    public List<Param> getItemViolaterList(final Param param) {
        return session.selectList("com.softworks.springframework.Main.getItemViolaterList", param);
    }

    // 본부장/팀장/보안담당자 - 항목별 이전점검 비교표(graph)
    @Transactional(readOnly=true)
    public List<Param> getItemViolaterCompare(final Param param) {
        return session.selectList("com.softworks.springframework.Main.getItemViolaterCompare", param);
    }

    // 본부장/팀장/보안담당자 - 항목별 이전점검 비교표(table)
    @Transactional(readOnly=true)
    public List<Param> getItemViolaterCompareTable(final Param param) {
        return session.selectList("com.softworks.springframework.Main.getItemViolaterCompareTable", param);
    }

    // 점검자 - 점검항목별 위반건수
    @Transactional(readOnly=true)
    public List<Param> getItemViolaterListOfInspector(final Param param) {
        return session.selectList("com.softworks.springframework.Main.getItemViolaterListOfInspector", param);
    }

    // 점검자 - 본부별 위반건수
    @Transactional(readOnly=true)
    public List<Param> getHqDeptViolaterListOfInspector(final Param param) {
        return session.selectList("com.softworks.springframework.Main.getHqDeptViolaterListOfInspector", param);
    }

    // 점검자 - 본부별 위반자율
    @Transactional(readOnly=true)
    public List<Param> getHqDeptViolaterChartOfInspector(final Param param) {
        return session.selectList("com.softworks.springframework.Main.getHqDeptViolaterChartOfInspector", param);
    }

    // 점검자 - 본부별 위반/조치건수
    @Transactional(readOnly=true)
    public List<Param> getResultItemListOfInspector(final Param param) {
        return session.selectList("com.softworks.springframework.Main.getResultItemListOfInspector", param);
    }
    
    //사이트 배너 
    @Transactional(readOnly=true)
    public List<Param> getSiteBanner(final Param param) {
        return session.selectList("com.softworks.springframework.Main.getSiteBanner", param);
    }
    
    //OA기기 및 SW사용현황 
    @Transactional(readOnly=true)
    public List<Param> getItsSkeHwSw(final Param param) {
        return session.selectList("com.softworks.springframework.Main.getItsSkeHwSw", param);
    }
    
    //To Do List
    @Transactional(readOnly=true)
	public int getNotiHistCount(final Param param) throws SQLException {
		
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*DEFAULT_PAGE_SIZE));
		
		return (Integer)session.selectOne("com.softworks.springframework.Main.getNotiHistCount", param);
	}
    @Transactional(readOnly=true)
    public List<Param> getNotiHist(final Param param) {
        return session.selectList("com.softworks.springframework.Main.getNotiHist", param);
    }
    
    @Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void chkNoti(final Param param) throws Exception {
		session.update("com.softworks.springframework.Main.chkNoti", param);
	}
    
    @Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void chkNotiAll(final Param param) throws Exception {
		session.update("com.softworks.springframework.Main.chkNotiAll", param);
	}
    
    @Transactional(readOnly=true)
	public int getApprvListCount(final Param param) throws SQLException {
		
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*DEFAULT_PAGE_SIZE));
		
		return (Integer)session.selectOne("com.softworks.springframework.Main.getApprvListCount", param);
	}
    
    @Transactional(readOnly=true)
    public List<Param> getApprvList(final Param param) {
        return session.selectList("com.softworks.springframework.Main.getApprvList", param);
    }
    
    @Transactional(readOnly=true)
    public Param getApprvDocInfo(final Param param) {
        return session.selectOne("com.softworks.springframework.Main.getApprvDocInfo", param);
    }
}
