package com.softworks.springframework.web.services.backoffice;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.http.HttpRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;

@Service
public class BbsBackofficeService extends BaseService {
	
	@Transactional(readOnly=true)
	public Param getBbsMasterInfo(final String type) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.Bbs.getBbsMasterInfo", type);
	}

	@Transactional(readOnly=true)
	public int getListCount(final Param param) throws SQLException {
		
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*DEFAULT_PAGE_SIZE));
		
		return (Integer)session.selectOne("com.softworks.springframework.Bbs.getListCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) throws SQLException {
		return session.selectList("com.softworks.springframework.Bbs.getList", param);
	}
	
	@Transactional(readOnly=true)
	public Param getInfo(final Param param) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.Bbs.getInfo", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insert(final Param param) throws SQLException {
		session.insert("com.softworks.springframework.Bbs.insert", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void update(final Param param) throws SQLException {
		session.update("com.softworks.springframework.Bbs.update", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateAnswer(final Param param) throws SQLException {
		session.update("com.softworks.springframework.Bbs.updateAnswer", param);
	}
	
	public void updateViewCnt(final Param param) throws SQLException {
		session.update("com.softworks.springframework.Bbs.updateViewCnt", param);
	}
	
	public void answerUpdate(final Param param) throws SQLException {
		session.update("com.softworks.springframework.Bbs.answerUpdate", param);
	}
	
	public void delete(final int ntt_id, final String type) throws SQLException {
		Param	param	= new Param();
				param.set("ntt_id", ntt_id);
				param.set("type", type);

		session.delete("com.softworks.springframework.Bbs.delete", param);
	}
	
	// bbs campaign
	@Transactional(readOnly=true)
	public List<Param> getBbsCampaignList(final String campaign_id) throws SQLException {
		Param	param	= new Param();
		param.set("campaign_id", campaign_id);
		return session.selectList("com.softworks.springframework.Bbs.getBbsCampaignList", param);
	}
	
	@Transactional(readOnly=true)
	public Param getBbsCampaignInfo(final String campaign_id, final String bbs_id, final String ntt_typ_cd) throws SQLException {
		Param	param	= new Param();
		param.set("campaign_id", campaign_id);
		param.set("bbs_id", bbs_id);
		param.set("ntt_typ_cd", ntt_typ_cd);
		return session.selectOne("com.softworks.springframework.Bbs.getBbsCampaignInfo", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public boolean insertBbsCampaign(final String select_campaign_id, final String new_campaign_id, final String uid, final String uname) throws SQLException {
		List<Param> list = getBbsCampaignList(select_campaign_id);
		for (Param param : list) {
			
			String atch_file_id = (String)session.selectOne("com.softworks.springframework.AttachFile.getAtchFileId");
			param.set("atch_file_id",atch_file_id);
			param.set("campaign_id",new_campaign_id);
			param.set("ntt_id", param.get("NTT_ID"));
			param.set("reg_id", Utils.nvl(uid));
			param.set("reg_nm", Utils.nvl(uname));
			param.set("upd_id", Utils.nvl(uid));
			param.set("upd_nm", Utils.nvl(uname));
			
			session.insert("com.softworks.springframework.Bbs.insertBbsCampaign", param);
			session.insert("com.softworks.springframework.AttachFile.insert", param);
		}
		return true;
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public boolean deleteBbsCampaign(final String campaign_id) throws SQLException {
		Param	param	= new Param();
		param.set("campaign_id", campaign_id);
		session.delete("com.softworks.springframework.Bbs.deleteBbsCampaign", param);
		return true;
	}
	
	@Transactional(readOnly=true)
	public List<Param> getExtFileListAll(final Param param) throws SQLException {
		return session.selectList("com.softworks.springframework.Bbs.getExtFileListAll", param);
	}

}
