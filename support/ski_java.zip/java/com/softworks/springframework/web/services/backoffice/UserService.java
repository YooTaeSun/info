package com.softworks.springframework.web.services.backoffice;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class UserService extends BaseService {

	@Transactional(readOnly=true)
	public int getListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*DEFAULT_PAGE_SIZE));
		
		return (Integer)session.selectOne("com.softworks.springframework.User.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) {
		return session.selectList("com.softworks.springframework.User.getList", param);
	}

	@Transactional(readOnly=true)
	public Param getInfo(final Param param) {
		return (Param)session.selectOne("com.softworks.springframework.User.getInfo", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insert(final Param param) throws Exception {
		session.insert("com.softworks.springframework.User.insert", param);

		param.set("type", param.get("user_typ_cd"));

		session.delete("com.softworks.springframework.Menu.deleteUserAuth", param);
		session.update("com.softworks.springframework.Menu.inserMenuUserAuthorization", param);

		String msg = "";

		if (param.get("acnt_state_cd").equals("ACT")) {
			msg = " 및 계정 활성.";
		} else if (param.get("acnt_state_cd").equals("INACT")) {
			msg = " 및 계정 비활성.";
		}

		param.set("change_cont", "[최초 등록] " + param.get("group_id") + " 그룹권한 부여" + msg);

		int seq = (Integer)session.selectOne("com.softworks.springframework.UserAuthChgHist.getSeq", param);
		param.set("seq", seq);

		session.insert("com.softworks.springframework.UserAuthChgHist.insert", param);
		session.update("com.softworks.springframework.UserAuthChgHist.updateChangeCont", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void update(final Param param) throws Exception {
		session.update("com.softworks.springframework.User.update", param);

		param.set("type", param.get("user_typ_cd"));

		String oldStateCd = param.get("old_acnt_state_cd");
		String newStateCd = param.get("acnt_state_cd");

		if (!oldStateCd.equals(newStateCd)) {
			if (newStateCd.equals("ACT")) {
				param.set("change_cont", "[계정 활성] 메뉴 사용 권한 활성");

				int seq = (Integer)session.selectOne("com.softworks.springframework.UserAuthChgHist.getSeq", param);
				param.set("seq", seq);

				session.insert("com.softworks.springframework.UserAuthChgHist.insert", param);
				session.update("com.softworks.springframework.UserAuthChgHist.updateChangeCont", param);
			} else if (newStateCd.equals("INACT")) {
				param.set("change_cont", "[계정 비활성] 메뉴 사용 권한 비활성");

				int seq = (Integer)session.selectOne("com.softworks.springframework.UserAuthChgHist.getSeq", param);
				param.set("seq", seq);

				session.insert("com.softworks.springframework.UserAuthChgHist.insert", param);
				session.update("com.softworks.springframework.UserAuthChgHist.updateChangeCont", param);
			} else if (newStateCd.equals("LOCK")) {
				param.set("change_cont", "[계정 잠김] 메뉴 사용 권한 잠김");

				int seq = (Integer)session.selectOne("com.softworks.springframework.UserAuthChgHist.getSeq", param);
				param.set("seq", seq);

				session.insert("com.softworks.springframework.UserAuthChgHist.insert", param);
				session.update("com.softworks.springframework.UserAuthChgHist.updateChangeCont", param);
			}
		}
	}
	
	public void setGroupId(final Param param) throws Exception {
		session.update("com.softworks.springframework.User.setGroupId", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void delete(final Param param) throws Exception {
		param.set("type", param.get("user_typ_cd"));
		param.set("change_cont", "[계정 삭제] 모든 메뉴 사용 권한 회수.");

		int seq = (Integer)session.selectOne("com.softworks.springframework.UserAuthChgHist.getSeq", param);
		param.set("seq", seq);

		session.insert("com.softworks.springframework.UserAuthChgHist.insert", param);
		session.update("com.softworks.springframework.UserAuthChgHist.updateChangeCont", param);

		session.delete("com.softworks.springframework.Menu.deleteUserAuth", param);
		session.delete("com.softworks.springframework.User.delete", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateAcntStateCd(final Param param) throws Exception {
		session.update("com.softworks.springframework.User.updateAcntStateCd", param);
	}

//	@Transactional(readOnly=true)
//	public int getMemberListCount(final Param param) {
//		param.set("page", new Integer(param.getInt("page", 1)));
//		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
//		param.set("limitSize", new Integer((param.getInt("page")-1)*DEFAULT_PAGE_SIZE));
//		
//		return (Integer)session.selectOne("com.softworks.springframework.User.getMemberListCount", param);
//	}
//
//	@Transactional(readOnly=true)
//	public List<Param> getMemberList(final Param param) {
//		return session.selectList("com.softworks.springframework.User.getMemberList", param);
//	}
//
//	@Transactional(readOnly=true)
//	public Param getMemberInfo(final String id) {
//		return (Param)session.selectOne("com.softworks.springframework.User.getMemberInfo", id);
//	}
//
//	@Transactional(readOnly=true)
//	public int getMemberReceiptCount(final String id) {
//		return (Integer)session.selectOne("com.softworks.springframework.User.getMemberReceiptCount", id);
//	}
//	
//	@Transactional(readOnly=true)
//	public List<Param> getMemberReceiptList(final String id) {
//		return session.selectList("com.softworks.springframework.User.getMemberReceiptList", id);
//	}
//	
//	public void memberinsert(final Param param) throws Exception {
//		session.insert("com.softworks.springframework.User.memberinsert", param);
//	}
//
//	public void memberupdate(final Param param) throws Exception {
//		session.update("com.softworks.springframework.User.memberupdate", param);
//	}
//	
//	public void memberdelete(final Param param) throws Exception {
//		session.delete("com.softworks.springframework.User.memberdelete", param);
//	}
	
}
