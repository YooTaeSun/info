package com.softworks.springframework.web.services.backoffice;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class AuthGroupService extends BaseService {

	@Transactional(readOnly=true)
	public List<Param> getAuthGroupListOfTyp(String typCd) {
		return session.selectList("com.softworks.springframework.AuthGroup.getAuthGroupListOfTyp", typCd);
	}

	@Transactional(readOnly=true)
	public int getGroupsCount(Param param) {
		param.set("pageSize", param.getInt("pageSize", DEFAULT_PAGE_SIZE));
		
		return session.selectOne("com.softworks.springframework.AuthGroup.getGroupListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getGroupList(Param param) {
		return session.selectList("com.softworks.springframework.AuthGroup.getGroupList", param);
	}

	@Transactional(readOnly=true)
	public Param getGroupInfo(String groupId) {
		return (Param)session.selectOne("com.softworks.springframework.AuthGroup.getGroupInfo", groupId);
	}

	public void insertAuthGroup(Param param) {
		session.insert("com.softworks.springframework.AuthGroup.insertAuthGroup", param);
	}
	
	public void updateAuthGroup(Param param) {
		session.update("com.softworks.springframework.AuthGroup.updateAuthGroup", param);
	}

	public void deleteAuthGroup(String groupId) {
		session.delete("com.softworks.springframework.AuthGroup.deleteAuthGroup", groupId);
	}

	@Transactional(readOnly=true)
	public List<Param> getAllMenuAuthList(Param param) {
		return session.selectList("com.softworks.springframework.AuthGroup.getAllMenuAuthList", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void setTempMenuAuth(String group, String[] id, String[] auth) throws Exception {
		if(id.length != auth.length) throw new Exception("menu_id 항목의 개수와 menu_auth 항목의 개수가 일치하지 않습니다.");
	
		Param	param	= new Param();
				param.set("group", group);
		
		session.delete("com.softworks.springframework.AuthGroup.deleteTempAuth", group);

		for(int i = 0, cnt = id.length;i < cnt;i++) {
			param.set("menu_id", id[i]);
			param.set("umask", auth[i]);
			
			if("NN".equals(param.get("umask"))) continue;

			System.out.println("---------------" + param.toString());
			session.insert("com.softworks.springframework.AuthGroup.insertTempAuth", param);
		}
	}
	
}
