package com.softworks.springframework.web.services.front;

import java.sql.SQLException;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class SecuritySystemOperationService extends BaseService {
	
	public void setSession(SqlSessionTemplate session) {
		super.session = session;
	}
	
	@Transactional(readOnly=true)
	public int getSecuSystemPolicyListCount(final Param param) throws SQLException {
		
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*DEFAULT_PAGE_SIZE));
		
		return (Integer)session.selectOne("com.softworks.springframework.SecuritySystemOperation.getSecuSystemPolicyListCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getSecuSystemPolicyList(final Param param) throws SQLException {
		return session.selectList("com.softworks.springframework.SecuritySystemOperation.getSecuSystemPolicyList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getSecuSystemPolicyListAll(final Param param) throws SQLException {
		return session.selectList("com.softworks.springframework.SecuritySystemOperation.getSecuSystemPolicyListAll", param);
	}
	
	@Transactional(readOnly=true)
	public Param getSecuSystemPolicyInfo(final Param param) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.SecuritySystemOperation.getSecuSystemPolicyInfo", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertSecuSystemPolicy(final Param param) throws SQLException {
		session.insert("com.softworks.springframework.SecuritySystemOperation.insertSecuSystemPolicy", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateSecuSystemPolicy(final Param param) throws SQLException {
		session.update("com.softworks.springframework.SecuritySystemOperation.updateSecuSystemPolicy", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteSecuSystemPolicy(final Param param) throws SQLException {
		session.delete("com.softworks.springframework.SecuritySystemOperation.deleteSecuSystemPolicy", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getSecuSystemPolicyDetailList(final Param param) throws SQLException {
		return session.selectList("com.softworks.springframework.SecuritySystemOperation.getSecuSystemPolicyDetailList", param);
	}
	
	@Transactional(readOnly=true)
	public Param getSecuSystemPolicyDetailInfo(final Param param) throws SQLException {
		return session.selectOne("com.softworks.springframework.SecuritySystemOperation.getSecuSystemPolicyDetailInfo", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertSecuSystemPolicyDetail(final Param param) throws SQLException {
		session.insert("com.softworks.springframework.SecuritySystemOperation.insertSecuSystemPolicyDetail", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateSecuSystemPolicyDetail(final Param param) throws SQLException {
		session.update("com.softworks.springframework.SecuritySystemOperation.updateSecuSystemPolicyDetail", param);
	}
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteSecuSystemPolicyDetail(final Param param) throws SQLException {
		session.delete("com.softworks.springframework.SecuritySystemOperation.deleteSecuSystemPolicyDetail", param);
	}
	
	@Transactional(readOnly=true)
	public int checkAppNo(final Param param) throws SQLException {
		return (Integer)session.selectOne("com.softworks.springframework.SecuritySystemOperation.checkAppNo", param);
	}
	
	@Transactional(readOnly=true)
	public int checkDupAppNo(final Param param) throws SQLException {
		return (Integer)session.selectOne("com.softworks.springframework.SecuritySystemOperation.checkDupAppNo", param);
	}
	
	
	/* 예외 정책 처리 현황 */
	@Transactional(readOnly=true)
	public int getExceptPolicyProcStatusListCount(final Param param) throws SQLException {
		
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*DEFAULT_PAGE_SIZE));
		
		return (Integer)session.selectOne("com.softworks.springframework.SecuritySystemOperation.getExceptPolicyProcStatusListCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getExceptPolicyProcStatusList(final Param param) throws SQLException {
		return session.selectList("com.softworks.springframework.SecuritySystemOperation.getExceptPolicyProcStatusList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getExceptPolicyProcStatusListExcel(final Param param) throws SQLException {
		return session.selectList("com.softworks.springframework.SecuritySystemOperation.getExceptPolicyProcStatusListExcel", param);
	}
	
	@Transactional(readOnly=true)
	public Param getExceptPolicyProcStatusInfo(final Param param) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.SecuritySystemOperation.getExceptPolicyProcStatusInfo", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getExceptPolicyProcDetailList(final Param param) throws SQLException {
		return session.selectList("com.softworks.springframework.SecuritySystemOperation.getExceptPolicyProcDetailList", param);
	}
	
	@Transactional(readOnly=true)
	public Param getExceptPolicyProcDetailInfo(final Param param) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.SecuritySystemOperation.getExceptPolicyProcDetailInfo", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getExceptPolicyApplyToList(final Param param) throws SQLException {
		return session.selectList("com.softworks.springframework.SecuritySystemOperation.getExceptPolicyApplyToList", param);
	}
	
	@Transactional(readOnly=true)
	public Param getExceptPolicyApplyToInfo(final Param param) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.SecuritySystemOperation.getExceptPolicyApplyToInfo", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertExceptPolicyProcResult(final Param param) throws SQLException {
		session.insert("com.softworks.springframework.SecuritySystemOperation.insertExceptPolicyProcResult", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateExceptPolicyProcResult(final Param param) throws SQLException {
		session.update("com.softworks.springframework.SecuritySystemOperation.updateExceptPolicyProcResult", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertExceptPolicyProcDetail(final Param param) throws SQLException {
		session.insert("com.softworks.springframework.SecuritySystemOperation.insertExceptPolicyProcDetail", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateExceptPolicyProcDetail(final Param param) throws SQLException {
		session.update("com.softworks.springframework.SecuritySystemOperation.updateExceptPolicyProcDetail", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertExceptPolicyApplyTo(final Param param) throws SQLException {
		session.insert("com.softworks.springframework.SecuritySystemOperation.insertExceptPolicyApplyTo", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteExceptPolicyProcDetail(final Param param) throws SQLException {
		session.delete("com.softworks.springframework.SecuritySystemOperation.deleteExceptPolicyProcDetail", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteAllExceptPolicyApplyTo(final Param param) throws SQLException {
		session.delete("com.softworks.springframework.SecuritySystemOperation.deleteAllExceptPolicyApplyTo", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateProcResultStatusChange(final Param param) throws SQLException {
		session.update("com.softworks.springframework.SecuritySystemOperation.updateProcResultStatusChange", param);
	}
	
	@Transactional(readOnly=true)
	public Param getApplyEmpInfo(final Param param) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.SecuritySystemOperation.getApplyEmpInfo", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateAttachFileId(final Param param) throws SQLException {
		session.update("com.softworks.springframework.SecuritySystemOperation.updateAttachFileId", param);
	}
	
}
