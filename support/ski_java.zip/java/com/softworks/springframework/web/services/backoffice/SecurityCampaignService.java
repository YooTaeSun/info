package com.softworks.springframework.web.services.backoffice;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;

@Service
public class SecurityCampaignService extends BaseService {
	
	@Autowired
	private	BbsBackofficeService			bbsBackofficeService;
	
	@Transactional(readOnly=true)
	public Param getSecurityCampaignOne(Param param) {
		return session.selectOne("com.softworks.springframework.SecurityCampaign.getSecurityCampaignOne", param);
	}
	
	@Transactional(readOnly=true)
	public String getSecurityCampaignLastId(Param param) {
		return session.selectOne("com.softworks.springframework.SecurityCampaign.getSecurityCampaignLastId", param);
	}
	
	@Transactional(readOnly=true)
	public int getSecurityCampaignAllCount(Param param) {
		return session.selectOne("com.softworks.springframework.SecurityCampaign.getSecurityCampaignAllCount", param);
	}
	
	@Transactional(readOnly=true)
	public int getSecurityCampaignIsYn(Param param) {
		return session.selectOne("com.softworks.springframework.SecurityCampaign.getSecurityCampaignIsYn", param);
	}
	
	@Transactional(readOnly=true)
	public String getSecurityCampaignToday(Param param) {
		return session.selectOne("com.softworks.springframework.SecurityCampaign.getSecurityCampaignToday", param);
	}
	
	@Transactional(readOnly=true)
	public int getSecurityCampaignDupleCount(Param param) {
		return session.selectOne("com.softworks.springframework.SecurityCampaign.getSecurityCampaignDupleCount", param);
	}
	
	@Transactional(readOnly=true)
	public int getSecurityCampaignListCount(Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*10));

		return session.selectOne("com.softworks.springframework.SecurityCampaign.getSecurityCampaignListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getSecurityCampaignList(Param param) {
		return session.selectList("com.softworks.springframework.SecurityCampaign.getSecurityCampaignList", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertSecurityCampaign(final Param param) throws Exception {
		session.insert("com.softworks.springframework.SecurityCampaign.insertSecurityCampaign", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateSecurityCampaign(final Param param) throws Exception {
		session.update("com.softworks.springframework.SecurityCampaign.updateSecurityCampaign", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public boolean updateSecurityCampaignService(final Param param) throws Exception {
		
		boolean result = true;
		
		int cnt = getSecurityCampaignIsYn(param);
		if(cnt == 0){ 
			updateSecurityCampaign(param);

			deleteSecurityCampaignSchedule(param);   //캠페인 스케줄 삭제
			
			String target_day = param.get("target_day");
			param.set("yyyymmdd", target_day);
			param.set("schd_typ_cd", "TARGET");
			param.set("exec_yn", "Y");
			insertSecurityCampaignSchedule(param);  //캠페인 스케줄 등록
			
			ArrayList<String> email_day_arr = (ArrayList<String>) param.getList("email_day_arr");
			
			for(String email_day : email_day_arr){
				String t_email_day    = email_day.replace("-", "");
				
				param.set("yyyymmdd", t_email_day);
				param.set("schd_typ_cd", "MAIL");
				param.set("exec_yn", "Y");
				insertSecurityCampaignSchedule(param);  //캠페인 스케줄 등록
			}
			
		}else{
			result = false;  //시작한 캠페인 수정할수 없음
		}
	
		return result;
		
	}
	
	
	
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteSecurityCampaign(final Param param) throws Exception {
		session.delete("com.softworks.springframework.SecurityCampaign.deleteSecurityCampaign", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getSecurityCampaignAllList(Param param) {
		return session.selectList("com.softworks.springframework.SecurityCampaign.getSecurityCampaignAllList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getSecurityCampaignScheduleAllList(Param param) {
		return session.selectList("com.softworks.springframework.SecurityCampaign.getSecurityCampaignScheduleAllList", param);
	}
	
	@Transactional(readOnly=true)
	public Param getSecurityCampaignDetailOne(Param param) {
		return session.selectOne("com.softworks.springframework.SecurityCampaign.getSecurityCampaignDetailOne", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getSecurityCampaignDetailAllList(Param param) {
		return session.selectList("com.softworks.springframework.SecurityCampaign.getSecurityCampaignDetailAllList", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertSecurityCampaignDetail(final Param param) throws Exception {
		session.insert("com.softworks.springframework.SecurityCampaign.insertSecurityCampaignDetail", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteSecurityCampaignDetail(final Param param) throws Exception {
		session.delete("com.softworks.springframework.SecurityCampaign.deleteSecurityCampaignDetail", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertSecurityCampaignSchedule(final Param param) throws Exception {
		session.insert("com.softworks.springframework.SecurityCampaign.insertSecurityCampaignSchedule", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteSecurityCampaignSchedule(final Param param) throws Exception {
		session.delete("com.softworks.springframework.SecurityCampaign.deleteSecurityCampaignSchedule", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertSecurityCampaignService(final Param param) throws Exception {
		
		String campaign_id = getSecurityCampaignLastId(param);  //최근 캠페인  ID
		
		Param detailParam = new Param();
		detailParam.set("campaign_id", campaign_id);
		List<Param> detailList = getSecurityCampaignAllList(detailParam);  //최근 캠페인 detailList
		
		insertSecurityCampaign(param);  //캠페인등록
		
		//게시물 등록 - 서비스 호출
//		campaign_id, param.get("campaign_id")
		bbsBackofficeService.insertBbsCampaign(campaign_id,param.get("campaign_id"),param.get("reg_id"),param.get("reg_nm"));

		for(Param detailOne : detailList){
			String company_cd    = detailOne.get("COMPANY_CD");
			String regularity_yn = detailOne.get("REGULARITY_YN");
			String bbs_id = "";
			if(regularity_yn.equals("1")){  //정직원
				bbs_id = "BBS00011";
			}else{  //협력업체
				bbs_id = "BBS00012";
			}
			//게시물 조회 (NTT_ID 조회) - 서비스 호출
//			param.get("campaign_id"), BBS00011, SKE / 정직원조회
//			param.get("campaign_id"), BBS00012, SKE / 협력업체조회
			Param bbsInfo = bbsBackofficeService.getBbsCampaignInfo(param.get("campaign_id"),bbs_id,company_cd);
			String ntt_id        = bbsInfo.get("NTT_ID");
			
			param.set("company_cd", company_cd);
			param.set("regularity_yn", regularity_yn);
			param.set("ntt_id", ntt_id);
			insertSecurityCampaignDetail(param);
		}
		
		String target_day = param.get("target_day");
		param.set("yyyymmdd", target_day);
		param.set("schd_typ_cd", "TARGET");
		param.set("exec_yn", "Y");
		insertSecurityCampaignSchedule(param);  //캠페인 스케줄 등록
		
		ArrayList<String> email_day_arr = (ArrayList<String>) param.getList("email_day_arr");
		
		for(String email_day : email_day_arr){
			String t_email_day    = email_day.replace("-", "");
			
			param.set("yyyymmdd", t_email_day);
			param.set("schd_typ_cd", "MAIL");
			param.set("exec_yn", "Y");
			insertSecurityCampaignSchedule(param);  //캠페인 스케줄 등록
		}
		
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public boolean deleteSecurityCampaignService(final Param param) throws Exception {

		boolean result = true;
		
		int cnt = getSecurityCampaignIsYn(param);
		if(cnt == 0){ 
			
			//게시물 삭제
			bbsBackofficeService.deleteBbsCampaign(param.get("campaign_id"));
			deleteSecurityCampaignSchedule(param);  //캠페인 스케줄 삭제
			deleteSecurityCampaignDetail(param);  //캠페인 detail 삭제
			deleteSecurityCampaign(param);  //캠페인 삭제
		}else{
			result = false;  //시작한 캠페인 삭제할수 없음
		}
		
		return result;
	}
	
	@Transactional(readOnly=true)
	public List<Param> getSecurityCampaignDetailTargetAllList(Param param) {
		return session.selectList("com.softworks.springframework.SecurityCampaign.getSecurityCampaignDetailTargetAllList", param);
	}
	
	@Transactional(readOnly=true)
	public Param getSecurityCampaignDetailTargetOne(Param param) {
		return session.selectOne("com.softworks.springframework.SecurityCampaign.getSecurityCampaignDetailTargetOne", param);
	}
	
	
	@Transactional(readOnly=true)
	public int getSecurityCampaignDetailTargetListCount(Param param) {
		return session.selectOne("com.softworks.springframework.SecurityCampaign.getSecurityCampaignDetailTargetListCount", param);
	}
	
	@Transactional(readOnly=true)
	public void getSecurityCampaignDetailTargetListExcel(final Param param, final ModelMap model) throws SQLException {
		
		List<Param> resultList =  session.selectList("com.softworks.springframework.SecurityCampaign.getSecurityCampaignDetailTargetListExcel", param);
		
		int[]	 colWidth	= {20, 20, 20, 20, 20, 20
			             };
		
		model.addAttribute("category", new String[] { "보안캠페인명", "소속회사명", "성명" , "사번", "확인일시", "접속IP" 
		    });
		
		model.addAttribute("columns", new String[] { "CAMPAIGN_NM", "COMPANY_NM", "EMP_NM","EMP_NO","UPD_DT","CONN_IP"
		   });
		model.addAttribute("columnsWidth", colWidth);
		model.addAttribute("chapter", "보안캠페인확인현황");
		model.addAttribute("filename", "보안캠페인확인현황"+"_"+param.get("campaign_nm")+"_"+Utils.getTimeStampString("yyyyMMdd"));
		
		model.addAttribute("data", resultList);
		
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateSecurityCampaignDetailTarget(final Param param) throws Exception {
		session.update("com.softworks.springframework.SecurityCampaign.updateSecurityCampaignDetailTarget", param);
	}
	

}