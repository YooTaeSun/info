package com.softworks.springframework.web.services.backoffice;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class MetaLawService extends BaseService {
	
	@Transactional(readOnly=true)
	public Param getLawSystemOne(Param param) {
		return session.selectOne("com.softworks.springframework.MetaLaw.getLawSystemOne", param);
	}
	
	@Transactional(readOnly=true)
	public int getLawSystemListCount(Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
//		param.set("pageSize", param.getInt("pageSize", DEFAULT_PAGE_SIZE));
		
		
		return session.selectOne("com.softworks.springframework.MetaLaw.getLawSystemListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getLawSystemList(Param param) {
		return session.selectList("com.softworks.springframework.MetaLaw.getLawSystemList", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getLawSystemAllList(Param param) {
		return session.selectList("com.softworks.springframework.MetaLaw.getLawSystemAllList", param);
	}

	public boolean insertLawSystem(Param param) throws SQLException {
		return 0 < session.insert("com.softworks.springframework.MetaLaw.insertLawSystem", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateLawSystem(final Param param) throws Exception {
		session.update("com.softworks.springframework.MetaLaw.updateLawSystem", param);
	}
	
	public void deleteLawSystem(final Param param) throws Exception {
		session.delete("com.softworks.springframework.MetaLaw.deleteLawSystem", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteService524(final Param param) throws Exception {
		deleteLawSystemChk(param);
		deleteLawSystem(param);
	}
	
	@Transactional(readOnly=true)
	public int getLawSystemCheckListCount(Param param) {
		return session.selectOne("com.softworks.springframework.MetaLaw.getLawSystemCheckListCount", param);
	}
	
	@Transactional(readOnly=true)
	public int getLawSystemCheckListDuplicate(Param param) {
		return session.selectOne("com.softworks.springframework.MetaLaw.getLawSystemCheckListDuplicate", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getLawSystemCheckList(Param param) {
		return session.selectList("com.softworks.springframework.MetaLaw.getLawSystemCheckList", param);
	}
	
	public boolean insertLawSystemChk(Param param) throws SQLException {
		return 0 < session.insert("com.softworks.springframework.MetaLaw.insertLawSystemChk", param);
	}
	
	public boolean updateLawSystemChk(Param param) throws SQLException {
		return 0 < session.insert("com.softworks.springframework.MetaLaw.updateLawSystemChk", param);
	}
	
	@Transactional(readOnly=true)
	public Param detailLawSystemChk(Param param) {
		return session.selectOne("com.softworks.springframework.MetaLaw.detailLawSystemChk", param);
	}
	
	@Transactional(readOnly=true)
	public void deleteLawSystemChk(final Param param) throws Exception {
		session.delete("com.softworks.springframework.MetaLaw.deleteLawSystemChk", param);
	}
	
	
	
	
	

}