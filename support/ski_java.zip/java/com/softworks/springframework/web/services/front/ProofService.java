package com.softworks.springframework.web.services.front;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.softworks.springframework.utils.FileUtil;
import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;

@Service
public class ProofService extends BaseService {

//	@Autowired
//	SecuManagerDetailService  secuManagerDetailSvc;


	@Transactional(readOnly=true)
	public int getListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		return session.selectOne("com.softworks.springframework.Proof.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) {
		return session.selectList("com.softworks.springframework.Proof.getList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getAllList(final Param param) {
		return session.selectList("com.softworks.springframework.Proof.getAllList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getFolderList(final Param param) {
		return session.selectList("com.softworks.springframework.Proof.getFolderList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getFileList(final Param param) {
		return session.selectList("com.softworks.springframework.Proof.getFileList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getExcelList(final Param param) {
		return session.selectList("com.softworks.springframework.Proof.getExcelList", param);
	}

	@Transactional(readOnly=true)
    public void getListExcel(final Param param, final ModelMap model) throws SQLException {
		//엑셀 만들기
		String[] category = {
				 "보안 영역","Sub영역","진단 항목","공통ID","Level"
				,"체크리스트","부서평가","내부평가","목표수준"
				};
		String[] columns = {
				"MAIN_AREA_NM","SUB_AREA_NM","CHK_ITEM_NM","CHECKLIST_ID","CHK_LEVEL_CD"
				,"CHECKLIST_NM","DEPT_EVAL_CD","SECU_EVAL_CD","GOAL_LEVEL_CD"
       		};

       int[] colWidth	= { 20, 20, 20, 20, 10,
    		   				50, 10, 10, 10
       				   };


       List<LinkedHashMap<String, String>> searchList =  (ArrayList<LinkedHashMap<String, String>>) ((HashMap)param).get("searchList");

        model.addAttribute("category", category);
        model.addAttribute("columns", columns);
        model.addAttribute("columnsWidth", colWidth);
        String excelName = FileUtil.sanitizeFileNm("보안증적관리현황조회_" + Utils.getTimeStampString("yyyyMMdd"));;
        model.addAttribute("chapter", "1");
        model.addAttribute("filename", excelName);
        model.addAttribute("data", this.getExcelList(param));
        model.put("searchList", searchList);
    }

}