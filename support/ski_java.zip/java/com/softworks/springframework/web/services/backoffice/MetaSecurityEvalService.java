package com.softworks.springframework.web.services.backoffice;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

@Service
public class MetaSecurityEvalService extends BaseService {
	
	@Transactional(readOnly=true)
	public List<Param> getEvalList(Param param) {
		return session.selectList("com.softworks.springframework.MetaSecurityEval.getEvalList", param);
	}
	
	@Transactional(readOnly=true)
	public Param getEvalInfo(Param param) {
		return session.selectOne("com.softworks.springframework.MetaSecurityEval.getEvalInfo", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getCheckItemList(Param param) {
		return session.selectList("com.softworks.springframework.MetaSecurityEval.getCheckItemList", param);
	}
	
	@Transactional(readOnly=true)
	public int getSecurityEvalDupleCount(String eval_grp_cd, String eval_item_id) {
		Param param = new Param();
		param.set("eval_grp_cd", eval_grp_cd);
		param.set("eval_item_id", eval_item_id);
		return session.selectOne("com.softworks.springframework.MetaSecurityEval.getSecurityEvalDupleCount", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertSecurityEvalList(final Param param) throws Exception {
		session.insert("com.softworks.springframework.MetaSecurityEval.insertSecurityEvalList", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insertCustSecurityEvalList(final Param param) throws Exception {
		session.insert("com.softworks.springframework.MetaSecurityEval.insertCustSecurityEvalList", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void updateSecurityEvalList(final Param param) throws Exception {
		session.insert("com.softworks.springframework.MetaSecurityEval.updateSecurityEvalList", param);
	}
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void deleteEval(final Param param) throws Exception {
		session.delete("com.softworks.springframework.MetaSecurityEval.deleteEval", param);
	}
	
}