package com.softworks.springframework.web.services;

import java.util.List;

import org.apache.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.CodeLoaderService.CodeInfo;

@Service
public class BaseService {

	@Autowired
	protected	SqlSessionTemplate	session;

	protected	final	int			DEFAULT_PAGE_SIZE	= 10;
	protected 	final	int 		DEFAULT_PAGE_BLOCK	= 10;
	
	protected	final	Logger		logger				= Logger.getLogger(getClass());

	/*
	 * 사용자의 해당 메뉴 권한 MASK 조회
	 * Param :
	 * 		group_id : 그룹ID
	 * 		menu_id : 메뉴ID
	 * 		user_id : 로그인 사용자ID
	 * Result : String (SH : 조회/처리권한, SN : 조회권한, NN : 권한없음, NULL : 권한없음)
	 */
	@Transactional(readOnly=true)
	public String getUserMenuAuth(Param param) {
		String groupId = param.get("group_id");

		if (groupId.equals("Administrator")) {
			return "SH";
		}

		return (String)session.selectOne("com.softworks.springframework.Menu.getUserMenuAuth", param);
	}

	@Transactional(readOnly=true)
	public List<CodeInfo> getAuthGroupCodeList() {
		return session.selectList("com.softworks.springframework.AuthGroup.getAuthGroupList");
	}

	@Transactional(readOnly=true)
	public List<CodeInfo> getAuthGroupCodeList(Param param) {
		return session.selectList("com.softworks.springframework.AuthGroup.getAuthGroupList", param);
	}
	
	@Transactional(readOnly=true)
	public List<CodeInfo> getAuthGroupCodeWithoutAdminList() {
		return session.selectList("com.softworks.springframework.AuthGroup.getAuthGroupListWithoutAdmin");
	}

	@Transactional(readOnly=true)
	public List<CodeInfo> getUseCodeList(String pcode) {
		return session.selectList("com.softworks.springframework.Code.getUseCodeList", pcode);
	}

	@Transactional(readOnly=true)
	public List<CodeInfo> getCompanyCodeList() {
		return session.selectList("com.softworks.springframework.Customer.getCompanyCodeList");
	}

	@Transactional(readOnly=true)
	public List<CodeInfo> getProjectCodeList(final Param param) {
		return session.selectList("com.softworks.springframework.Project.getProjectCodeList", param);
	}
	
//	@Transactional(readOnly=true)
//	public List<CodeInfo> getUrlCodeList(final Param param) {
//		return session.selectList("com.softworks.springframework.Diagnosis.getMyUrlList", param);
//	}

	@Transactional(readOnly=true)
	public List<CodeInfo> getDaemonCodeList() {
		return session.selectList("com.softworks.springframework.Daemon.getDaemonCodeList");
	}

}