package com.softworks.springframework.web.services.backoffice;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;

@Service
public class AdminService extends BaseService {

	@Transactional(readOnly=true)
	public List<Param> getList(Param param) {
		return session.selectList("com.softworks.springframework.Admin.getList", param);
	}

	@Transactional(readOnly=true)
	public Param getInfo(String admin_id) {
		return session.selectOne("com.softworks.springframework.Admin.getInfo", admin_id);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void insert(final Param param) throws Exception {
		session.insert("com.softworks.springframework.Admin.insert", param);

		param.set("user_id", param.get("admin_id"));
		param.set("type", "B");

		session.delete("com.softworks.springframework.Menu.deleteUserAuth", param);
		session.update("com.softworks.springframework.Menu.inserMenuUserAuthorization", param);

		String msg = "";

		if (param.get("acnt_state_cd").equals("ACT")) {
			msg = " 및 계정 활성.";
		} else if (param.get("acnt_state_cd").equals("INACT")) {
			msg = " 및 계정 비활성.";
		}

		param.set("change_cont", "[최초 등록] " + param.get("group_id") + " 그룹권한 부여" + msg);

		int seq = (Integer)session.selectOne("com.softworks.springframework.UserAuthChgHist.getSeq", param);
		param.set("seq", seq);

		session.insert("com.softworks.springframework.UserAuthChgHist.insert", param);
		session.update("com.softworks.springframework.UserAuthChgHist.updateChangeCont", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void update(final Param param) throws Exception {
		session.update("com.softworks.springframework.Admin.update", param);

		param.set("type", "B");

		String oldStateCd = param.get("old_acnt_state_cd");
		String newStateCd = param.get("acnt_state_cd");

		if (!oldStateCd.equals(newStateCd)) {
			if (newStateCd.equals("ACT")) {
				param.set("change_cont", "[계정 활성] 메뉴 사용 권한 활성");

				int seq = (Integer)session.selectOne("com.softworks.springframework.UserAuthChgHist.getSeq", param);
				param.set("seq", seq);

				session.insert("com.softworks.springframework.UserAuthChgHist.insert", param);
				session.update("com.softworks.springframework.UserAuthChgHist.updateChangeCont", param);
			} else if (newStateCd.equals("INACT")) {
				param.set("change_cont", "[계정 비활성] 메뉴 사용 권한 비활성");

				int seq = (Integer)session.selectOne("com.softworks.springframework.UserAuthChgHist.getSeq", param);
				param.set("seq", seq);

				session.insert("com.softworks.springframework.UserAuthChgHist.insert", param);
				session.update("com.softworks.springframework.UserAuthChgHist.updateChangeCont", param);
			}
		}
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void delete(Param param) throws Exception {
		param.set("user_id", param.get("admin_id"));
		param.set("type", "B");

		param.set("change_cont", "[계정 삭제] 모든 메뉴 사용 권한 회수.");

		int seq = (Integer)session.selectOne("com.softworks.springframework.UserAuthChgHist.getSeq", param);
		param.set("seq", seq);

		session.insert("com.softworks.springframework.UserAuthChgHist.insert", param);
		session.update("com.softworks.springframework.UserAuthChgHist.updateChangeCont", param);

		session.delete("com.softworks.springframework.Menu.deleteUserAuth", param);
		session.delete("com.softworks.springframework.Admin.delete", param);
	}

	@Transactional(readOnly=true)
	public boolean isDuplicateId(String admin_id) {
		return null == (String)session.selectOne("com.softworks.springframework.Admin.isDuplicateId", admin_id) ? false : true;
	}

	@Transactional(readOnly=true)
	public boolean isUnitedEmployeeexts(String admin_id) {
		return null == (String)session.selectOne("com.softworks.springframework.Admin.isUnitedEmployeeexts", admin_id) ? false : true;
	}

}
