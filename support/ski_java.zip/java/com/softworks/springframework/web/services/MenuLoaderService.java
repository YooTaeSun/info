package com.softworks.springframework.web.services;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;

public class MenuLoaderService implements InitializingBean {
	
	@Autowired
	private	SqlSessionFactory	session;

	private static final Logger logger = Logger.getLogger(MenuLoaderService.class);
	
	public	static	List<Menu>				ADMIN_MENU;
	public	static	Map<String, MenuInfo>	ADMIN_MENU_INFO;
	
	public	static	List<Menu>				FRONT_MENU;
	public	static	Map<String, MenuInfo>	FRONT_MENU_INFO;

	public	static	List<Menu>				EXTERNAL_MENU;
	public	static	Map<String, MenuInfo>	EXTERNAL_MENU_INFO;
	
	@Override
	public void afterPropertiesSet() throws Exception {
		try {
			generateMenuLoader();
		} catch(ArrayIndexOutOfBoundsException obe) {
			logger.error("메뉴 적재중 에러", obe);
		} catch(SQLException se) {
			logger.error("메뉴 로딩중 에러", se);
		} catch(Exception e) {
			logger.error("예기치 못한 오류", e);
		}
	}
	
	@Transactional(readOnly=true)
	private synchronized void generateMenuLoader() throws Exception {
		//String[]				mType	= {"B","F","E"};
		String[]				mType	= {"F"};
		Param					row		= null;
		SqlSession				conn	= null;
		List<Menu>				menu	= null;
		Map<String, MenuInfo>	info	= null;
		
		try {
			conn	= session.openSession();

			for(int x = 0, count = mType.length;x < count;x++) {
				menu	= new ArrayList<Menu>();
				info	= new HashMap<String, MenuInfo>();
				
				List<Param>	list	= conn.selectList("com.softworks.springframework.Menu.getAllMenuList", mType[x]);
				
				for(int i = 0, cnt = list.size();i < cnt;i++) {
					row		= list.get(i);
	
					String[] auths = Utils.convertStringArray(conn.selectList("com.softworks.springframework.Menu.getMenuAuthGroupList", row.get("MENU_ID")));
					String[] users = Utils.convertStringArray(conn.selectList("com.softworks.springframework.Menu.getMenuAuthUserList", row.get("MENU_ID")));
					
					info.put(row.get("MENU_ID"), new MenuInfo("Y".equals(row.get("ACTIVE")), "1".equals(row.get("STATUS")), row.get("MENU_NM"), row.get("MENU_ENG_NM"), row.get("MENU_URL"), auths, users));
					
					switch(row.get("MENU_ID").length()) {
						case 3:
							menu.add(new Menu(row.get("MENU_ID"), new ArrayList<Menu>()));
							break;
						case 6:
							menu.get(menu.size() - 1).getSub().add(new Menu(row.get("MENU_ID"), new ArrayList<Menu>()));
							break;
						case 9:
							menu.get(menu.size() - 1).getSub().get(menu.get(menu.size() - 1).getSub().size() - 1).getSub().add(new Menu(row.get("MENU_ID"), null));
							break;
					}
				}
				
				switch(mType[x]) {
					case "B":
						this.ADMIN_MENU			= menu;
						this.ADMIN_MENU_INFO	= info;
						break;
					case "F":
						this.FRONT_MENU			= menu;
						this.FRONT_MENU_INFO	= info;
						break;
					case "E":
						this.EXTERNAL_MENU		= menu;
						this.EXTERNAL_MENU_INFO	= info;
						break;
				}
			}
		} catch(Exception e) {
			logger.error("메뉴 로딩중 에러", e);
			throw e;
		} finally {
			if(null != conn) conn.close();
		}
	}

	public void reload() throws Exception {
		ADMIN_MENU		= null;
		FRONT_MENU		= null;
		EXTERNAL_MENU	= null;
		
		(new Thread() {
			@Override
			public void run() {
				try {
					logger.info("Menu Reloading Start...");
					afterPropertiesSet();
					logger.info("Menu Reloading Complate...");
				} catch(Exception e) {
					logger.error("메뉴 리로딩 에러", e);
				}
			}
		}).run();
	}
	
	public class Menu {
		private	String		id;
		private	List<Menu>	sub;
		
		public Menu(String id, List<Menu> sub) {
			this.id	= id;
			this.sub= sub;
		}
		
		public void setId(String menu_id) {
			this.id		= menu_id;
		}
		
		public void setMenu(List<Menu> menu) {
			this.sub	= menu;
		}
		
		public String getId() {
			return this.id;
		}
		
		public List<Menu> getSub() {
			return this.sub;
		}
		
		@Override
		public String toString() {
			return (new StringBuilder()).append("[id=").append(this.id).append("]")
										.append("[sub=").append(null != this.sub ? Utils.implode(this.sub.toArray(), ",") : "").append("]").toString();
		}
	}
	
	public class MenuInfo {
		private	boolean		active;
		private	boolean		draw;
		private	String		name;
		private String		engName;
		private	String		url;
		private	String[]	auth;
		private	String[]	userAuth;
		
		public MenuInfo(final boolean active, final boolean draw, final String name, final String ename, final String url, final String[] auth, final String[] userAuth) {
			this.active		= active;
			this.draw		= draw;
			this.url		= url;
			this.name		= name;
			this.auth		= auth;
			this.engName	= ename;
			this.userAuth	= userAuth;
		}
		
		public void setActive(final boolean active) {
			this.active	= active;
		}
		
		public void setDraw(final boolean draw) {
			this.draw	= draw;
		}
		
		public void setName(final String name) {
			this.name		= name;
		}
		
		public void setEngName(final String eng_name) {
			this.engName	= eng_name;
		}
		
		public void setUrl(final String url) {
			this.url		= url;
		}
		
		public void setAuth(final String[] auth) {
			this.auth		= auth;
		}
		
		public void setUserAuth(final String[] userAuth) {
			this.userAuth	= userAuth;
		}
		
		public boolean isActive() {
			return this.active;
		}
		
		public boolean isDraw() {
			return this.draw;
		}
		
		public String getName() {
			return this.name;
		}
		
		public String getEngName() {
			return this.engName;
		}
		
		public String getUrl() {
			return this.url;
		}
		
		public String[] getAuth() {
			return this.auth;
		}
		
		public String[] getUserAuth() {
			return this.userAuth;
		}
		
		public boolean isAuth(String group, String userId) {
			return Utils.inArray(this.auth, group) || Utils.inArray(this.userAuth, userId);
		}
		
		@Override
		public String toString() {
			return (new StringBuilder()).append("[name=").append(this.name).append("]")
										.append("[url=").append(this.url).append("]")
										.append("[auth=").append(Utils.implode(this.auth, ",")).append("]")
										.append("[userAuth=").append(Utils.implode(this.userAuth, ",")).append("]").toString();
		}
	}
}
