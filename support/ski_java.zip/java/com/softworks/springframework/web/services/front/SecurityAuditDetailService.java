package com.softworks.springframework.web.services.front;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.AttachFileDetailService;
import com.softworks.springframework.web.services.BaseService;
import com.softworks.springframework.web.services.backoffice.MetaCompanyService;

@Service
public class SecurityAuditDetailService extends BaseService {

	@Autowired
	private	AttachFileDetailService attachFileDetailSvc;

	@Autowired
	private	SecurityAuditService securityAuditSvc;

	@Autowired
	private	MetaCompanyService metaCompanySvc;

	@Transactional(readOnly=true)
	public int getListCount(final Param param) {
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		return session.selectOne("com.softworks.springframework.SecurityAuditDetail.getListCount", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) {
		return session.selectList("com.softworks.springframework.SecurityAuditDetail.getList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getAllList(final Param param) {
		return session.selectList("com.softworks.springframework.SecurityAuditDetail.getAllList", param);
	}

	@Transactional(readOnly=true)
	public Param getDetail(final Param param) {
		return session.selectOne("com.softworks.springframework.SecurityAuditDetail.getAllList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getBatchFileList(final Param param) {
		return session.selectList("com.softworks.springframework.SecurityAuditDetail.getBatchFileList", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int insert(Param param) throws SQLException {
		return session.insert("com.softworks.springframework.SecurityAuditDetail.insert", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int update(final Param param) throws SQLException {
		return session.update("com.softworks.springframework.SecurityAuditDetail.update", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public void delete(final Param param) throws Exception {
		session.delete("com.softworks.springframework.SecurityAuditDetail.delete", param);
	}


	@Transactional(readOnly=true)
	public List<Param> getChecklist(final Param param) {
		return session.selectList("com.softworks.springframework.SecurityAuditDetail.getChecklist", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getDetailFileList(final Param param) {
		return session.selectList("com.softworks.springframework.SecurityAuditDetail.getDetailFileList", param);
	}

	@Transactional(readOnly=true)
	public List<Param> getDetailLawFileList(final Param param) {
		return session.selectList("com.softworks.springframework.SecurityAuditDetail.getDetailLawFileList", param);
	}

	@Transactional(readOnly=true)
	public Param getCheckDetail(final Param param) {
		return session.selectOne("com.softworks.springframework.SecurityAuditDetail.getChecklist", param);
	}


	@Transactional(readOnly=true)
	public List<Param> getLawSystemCheckList(final Param param) {
		return session.selectList("com.softworks.springframework.SecurityAuditDetail.getLawSystemCheckList", param);
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int registManager(Param param) throws Exception {
		int resultInt = 0;
		resultInt += this.update(param);
		return resultInt;
	}


	@Transactional(readOnly=true)
	public HashMap<String, Object> detailItem(final Param param) {
		HashMap resultMap = new Param();

		Param param01 = new Param();
		param01.put("audit_id", param.get("audit_id"));
		Param mainDetail =  securityAuditSvc.getDetail(param01);
		resultMap.put("mainDetail", mainDetail);

		logger.debug("[detailItem] audit_id >> " + param.get("audit_id"));
		logger.debug("[detailItem] ls_item_id >> " + param.get("ls_item_id"));

		Param datail =  session.selectOne("com.softworks.springframework.SecurityAuditDetail.getChecklist", param);
		resultMap.put("detail", datail);

		return resultMap;
	}


	@Transactional(readOnly=true)
	public List<Param> detailItemCheckList(final Param param) {

		Param param01 = new Param();
		param01.put("audit_id", param.get("audit_id"));
		Param datail =  securityAuditSvc.getDetail(param01);

		param.put("ls_id", datail.get("REL_LAWS_ID"));
		param.put("data_start_day", datail.get("DATA_START_DAY").replace("-", ""));
		param.put("data_end_day", datail.get("DATA_END_DAY").replace("-", ""));

		List<Param> lawCheckList = session.selectList("com.softworks.springframework.SecurityAuditDetail.getLawCheckList", param);
		String busiSiteListStr = "";

		if(lawCheckList != null && lawCheckList.size() > 0) {
			for (int i = 0; i < lawCheckList.size(); i++) {
				Param e = lawCheckList.get(i);

				busiSiteListStr = Utils.nvl(e.get("BUSI_SITE_LIST"),"") ;
				if(!busiSiteListStr.isEmpty()) {
					List<String>  p_busiSiteList = Arrays.asList(busiSiteListStr.split(","));
					param.put("busiSiteList", p_busiSiteList);
					List<Param> busiSiteList =  metaCompanySvc.getCompanyBusiSiteAllList(param);
					e.put("busiSiteList", busiSiteList);
				}
			}
		}
		return lawCheckList;

	}


}