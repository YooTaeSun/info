package com.softworks.springframework.web.services;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

import com.softworks.springframework.utils.Param;

public class CodeLoaderService implements InitializingBean {

	@Autowired
	private	SqlSession	session;

	private static final Logger logger = Logger.getLogger(CodeLoaderService.class);
	
	public	static	Map<String, List<CodeInfo>>	CODE	= null;
	
	@Override
	public void afterPropertiesSet() throws Exception {
		try {
			generateCodeLoader();
		} catch(ArrayIndexOutOfBoundsException obe) {
			logger.error("코드 적재중 에러", obe);
		} catch(SQLException se) {
			logger.error("코드 로딩중 에러", se);
		} catch(Exception e) {
			logger.error("예기치 못한 오류", e);
		}
	}
	
	private synchronized void generateCodeLoader() throws Exception {
		List<Param>	list	= session.selectList("com.softworks.springframework.Code.getAllCodeList");
		
		Param			row			= null;
		List<CodeInfo>	info		= null;
		
		String	codeName	= "";
		CODE	= new HashMap<String,List<CodeInfo>>();
		for(int i = 0, cnt = list.size();i < cnt;i++) {
			row	= list.get(i);
			
			if(!codeName.equals(row.get("pcode"))) {
				if(0 < i) CODE.put(codeName, info);
				
				info	= new ArrayList<CodeInfo>();
				codeName= row.get("pcode");
			}
			
			if(codeName.equals(row.get("pcode")))
				info.add(new CodeInfo(row.get("code"), row.get("name")));
		}
		
		CODE.put(codeName, info);
	}

	public void reload() throws Exception {
		CODE	= null;
		
		(new Thread() {
			@Override
			public void run() {
				try {
					logger.info("Code Reloading Start...");
					afterPropertiesSet();
					logger.info("Code Reloading Complate...");
				} catch(Exception e) {
					logger.error("공통코드 리로딩 에러", e);
				}
			}
		}).run();
	}
	
	public static class CodeInfo {
		private	String code;
		private	String name;
		
		public CodeInfo() {}
		
		public CodeInfo(String code, String name) {
			this.code	= code;
			this.name	= name;
		}
		
		public void setCode(String code) {
			this.code	= code;
		}
		
		public void setName(String name) {
			this.name	= name;
		}
		
		public String getCode() {
			return this.code;
		}
		
		public String getName() {
			return this.name;
		}
	}
	
}
