package com.softworks.springframework.web.services.front;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.BaseService;

@Service
public class BbsFrontService extends BaseService {

	@Transactional(readOnly=true)
	public Param getBbsMasterInfo(final String type) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.Bbs.getBbsMasterInfo", type);
	}
	
	@Transactional(readOnly=true)
	public int getListCount(final Param param) throws SQLException {
		
		param.set("page", new Integer(param.getInt("page", 1)));
		param.set("pageSize", new Integer(param.getInt("pageSize", DEFAULT_PAGE_SIZE)));
		param.set("limitSize", new Integer((param.getInt("page")-1)*DEFAULT_PAGE_SIZE));
		
		return (Integer)session.selectOne("com.softworks.springframework.Bbs.getListCount", param);
	}
	
	@Transactional(readOnly=true)
	public List<Param> getList(final Param param) throws SQLException {
		return session.selectList("com.softworks.springframework.Bbs.getList", param);
	}
	
	@Transactional(readOnly=true)
	public Param getInfo(final Param param) throws SQLException {
		return (Param)session.selectOne("com.softworks.springframework.Bbs.getInfo", param);
	}

	public void insert(final Param param) throws SQLException {
		session.insert("com.softworks.springframework.Bbs.insert", param);
	}
	
	public void update(final Param param) throws SQLException {
		session.update("com.softworks.springframework.Bbs.update", param);
	}
	
	public void updateViewCnt(Param	param) throws SQLException {
		session.update("com.softworks.springframework.Bbs.updateViewCnt", param);
	}
	
	public void answerUpdate(final Param param) throws SQLException {
		session.update("com.softworks.springframework.Bbs.answerUpdate", param);
	}
	
	public void delete(final int ntt_id, final String type) throws SQLException {
		Param	param	= new Param();
				param.set("ntt_id", ntt_id);
				param.set("type", type);

		session.delete("com.softworks.springframework.Bbs.delete", param);
	}
	
	public void saveFiles(final Param param, final MultipartFile attach, String uploadPath) throws Exception {
		int seq = param.getInt("seq");
		List<HashMap<String,Object>> fileList = new ArrayList<HashMap<String,Object>>();
		if(null != attach && !attach.isEmpty()){
			HashMap<String,Object> fileMap = new HashMap<String,Object>();
			fileMap.put("Bbs_seq", seq);
			fileMap.put("rgst_id", param.get("writer").toString());
			fileMap.put("add_file_name", attach.getOriginalFilename());
			fileMap.put("file_path", uploadPath);
			fileMap.put("save_file_name", seq + "_attach_1");
			fileList.add(fileMap);
			Utils.saveUploadFile(uploadPath,
					 param.get("seq") + "_attach_1", attach.getBytes(), attach.getSize(), attach.getOriginalFilename(), false);
		}
		if(null != fileList && 0 < fileList.size()){
			param.set("fileList", fileList);
			session.delete("com.softworks.springframework.CommBbs.deleteFiles", param);
			session.insert("com.softworks.springframework.CommBbs.insertBbsFile", param);
		}
		
	}

}
