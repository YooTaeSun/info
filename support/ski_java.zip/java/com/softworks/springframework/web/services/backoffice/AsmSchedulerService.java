package com.softworks.springframework.web.services.backoffice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.BaseService;

enum TB_MAPING {
	VW_DIAG_APPL_MASTER("IF_ASM_APPL_MASTER"),
	VW_DIAG_APPL_RESULT("IF_ASM_APPL_RESULT"),
	VW_DIAG_APPL_SVR_MASTER("IF_ASM_APPL_SVR_MASTER"),
	VW_DIAG_NETWORK_MASTER("IF_ASM_NETWORK_MASTER"),
	VW_DIAG_NETWORK_RESULT("IF_ASM_NETWORK_RESULT"),
	VW_DIAG_OS_MASTER("IF_ASM_OS_MASTER"),
	VW_DIAG_OS_RESULT("IF_ASM_OS_RESULT"),
	VW_DIAG_PJT_MASTER("IF_ASM_PJT_MASTER"),
	VW_DIAG_PJT_OS_MASTER("IF_ASM_PJT_OS_MASTER"),
	VW_DIAG_PJT_OS_RESULT("IF_ASM_PJT_OS_RESULT"),
	VW_DIAG_PJT_SVR_MASTER("IF_ASM_PJT_SVR_MASTER"),
	VW_DIAG_APPL_ST_TOT_SUMMARY("IF_ASM_APPL_ST_TOT_SUMMARY"),
	VW_T_DIAG_PLATFORM("IF_ASM_DIAG_ITEM_CNT");
//	IF_ASM_APPL_MASTER2 		("IF_ASM_APPL_MASTER"),
//	IF_ASM_APPL_RESULT2 		("IF_ASM_APPL_RESULT"),
//	IF_ASM_DIAG_ITEM_CNT2("IF_ASM_DIAG_ITEM_CNT");
     
    final private String name;
     
    private TB_MAPING(String name) { //enum에서 생성자 같은 역할
        this.name = name;
    }
    public String getName() { // 문자를 받아오는 함수
        return name;
    }
}

@Service
public class AsmSchedulerService extends BaseService {

	private	final	Logger		logger	= Logger.getLogger(getClass());
	
	@Autowired
	SchedulerLogService logSvc;
	
	private final int IST_LMT_CNT = 1000;

    public void setSession(SqlSessionTemplate session) {
		super.session = session;
		logSvc = new SchedulerLogService();
		logSvc.setSession(session);
	}
    
    /**
	 * ASM interface 테이블 등록
	 * target table : T_USER, T_CONTENT , T_MAIL_SEND_HIST
	 * Result : void
     * @throws Exception 
	 */
    public void execAsmInterface(final Param schdInfo) throws Exception {
    	int batch_cnt = 0;
    	Param rstParam = new Param();
    	StringBuffer msg = new StringBuffer();
    	String con_tb_nm = "";
    	String tb_nm = "";
    	
    	// start log
    	schdInfo.set("BATCH_SEQ", logSvc.newAppendBatchHistory(schdInfo));
    	
    	try {
    		for(TB_MAPING tb_maping : TB_MAPING.values()){
    			con_tb_nm = tb_maping.toString();
    			tb_nm = tb_maping.getName();
    			rstParam = regAsmInterface(con_tb_nm,tb_nm);
    			msg.append(rstParam.get("BATCH_MSG")).append("\n");
    			batch_cnt += rstParam.getInt("batch_cnt");
    		}
    		schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "Y");
			schdInfo.set("BATCH_MSG", msg.toString());
		} catch (Exception e) {
			schdInfo.set("BATCH_CNT", batch_cnt);
			schdInfo.set("SUCCESS_YN", "N");
			schdInfo.set("BATCH_MSG", e.toString());
		}
    	logSvc.updateBatchHistory(schdInfo);
    }  
    
    /**
	 * ASM interface 테이블 등록
	 * target table : T_USER, T_CONTENT , T_MAIL_SEND_HIST
	 * Result : void
     * @throws Exception 
	 */
    @Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
    public Param regAsmInterface(final String con_tb_nm, final String tb_nm) throws Exception {
    	int		total_cnt		= 0;
		int 	batch_cnt		= 0;
		String	err_chk			= "";
		Param rstParam = new Param();

		String ip		= Property.getProperty("if.asm.ip").toString();
		String port		= Property.getProperty("if.asm.port").toString();
		String sid		= Property.getProperty("if.asm.sid").toString();
		String username = Property.getProperty("if.asm.id").toString();
		String password = Property.getProperty("if.asm.pw").toString();

//		String driver	= "com.microsoft.sqlserver.jdbc.SQLServerDriver";
//		String url		= "jdbc:sqlserver://" + ip + ":" + port + ";databaseName=" + sid;
		String driver	= "oracle.jdbc.driver.OracleDriver";
		String url		= "jdbc:oracle:thin:@" + ip + ":" + port + ":" + sid;

//		System.out.println("***********sourceQuery***");
//		System.out.println(driver);
//		System.out.println(url);
//		System.out.println(username);
//		System.out.println(password);
//		System.out.println("***********rs***");

		Connection conn = null;                                        // null로 초기화 한다.
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			Class.forName(driver); 
			conn	= DriverManager.getConnection(url,username,password);

			// 인사 정보 조회
			String sql = makeQuery(con_tb_nm);
			pstmt	= conn.prepareStatement(sql);
			rs		= pstmt.executeQuery();

			if (rs != null) {
				// delete data
				Param p = new Param();
				p.set("table_nm", tb_nm);
				delete(p);
				
				Map<String, Object> paramMap = new HashMap<String, Object>();
				List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
				Map<String, Object> map;
				
				while (rs.next()) {
					total_cnt = total_cnt + 1;
					map = new HashMap<String, Object>();
                    
                    ResultSetMetaData rsMD= rs.getMetaData();
                    int rsMDCnt = rsMD.getColumnCount();
                    for( int i = 1; i <= rsMDCnt; i++ ) {                   
                        String column = rsMD.getColumnName(i);
                        String value  = rs.getString(column);
                        map.put(column, value);
                    }
                    list.add(map);
                    if(total_cnt % IST_LMT_CNT == 0){
                    	paramMap.put("list", list);
        				batch_cnt += insert(paramMap,tb_nm);
        				list = new ArrayList<Map<String, Object>>();
                    }
				}
				// 1000 개 이하일때 실행
				if(total_cnt % IST_LMT_CNT != 0){
					paramMap.put("list", list);
					batch_cnt = insert(paramMap,tb_nm);
				}
				rstParam.set("batch_cnt", batch_cnt);
			}
			rs.close();
			pstmt.close();
			
		} catch (Exception e) {
			err_chk = e.toString();
			e.printStackTrace();
		} finally {
			if(rs != null) try{rs.close();}catch(SQLException sqle){}         // Resultset 객체 해제
			if(pstmt != null) try{pstmt.close();}catch(SQLException sqle){}   // PreparedStatement 객체 해제
			if(conn != null) try{conn.close();}catch(SQLException sqle){}     // Connection 해제
		}
		
		// try catch 내에서 오류 발생시에는 exception이 생기지 않아서 batch가 성공으로 표시됨. 이를 막기 위한 로직임
		if (!err_chk.equals("")) {
			rstParam.set("BATCH_MSG", "테이블명 : " + tb_nm +" || SUCCESS_YN : N || "+"ERR_MSG : "+ err_chk);
			Exception e = new Exception(err_chk);
			throw e;	 // 예외를 발생시킴
	    } else {
	    	if(batch_cnt > 0){
	    		rstParam.set("BATCH_MSG", "테이블명 : " + tb_nm +" || SUCCESS_YN : Y || "+"총 "+ total_cnt + "건 중 "+ total_cnt + "건 성공.");
	    	}else{
	    		rstParam.set("BATCH_MSG", "테이블명 : " + tb_nm +" || SUCCESS_YN : Y || "+" 데이터가 없습니다.");
	    	}
	    	logger.info(tb_nm + " Daily Batch totCnt="+batch_cnt);
	    	return rstParam;
	    }
    }
    
    public String makeQuery(final String tb_nm) {
    	StringBuffer sql	= new StringBuffer();
		if(tb_nm.equals("VW_T_DIAG_PLATFORM")){
			sql.append(" SELECT											 ");
			sql.append(" 	 TO_CHAR(SYSDATE,'YYYY') AS TARGET_YEAR      ");
			sql.append(" 	,F.DIAG_SECTION_CD                           ");
			sql.append(" 	,F.DIAG_FLATFORM_CD                          ");
			sql.append(" 	,F.DIAG_FLATFORM_NM                          ");
			sql.append(" 	,COUNT(M.DIAG_ITEM_CD)	AS DIAG_ITEM_CNT     ");
			sql.append(" FROM asmadmin.VW_T_DIAG_FLATFORM	F            ");
			sql.append(" 		,asmadmin.VW_T_DIAG_GROUP		G        ");
			sql.append(" 		,asmadmin.VW_T_DIAG_ITEMMASTER	M        ");
			sql.append(" WHERE F.DIAG_SECTION_CD = G.DIAG_SECTION_CD     ");
			sql.append("     AND F.DIAG_FLATFORM_CD = G.DIAG_FLATFORM_CD ");
			sql.append("     AND F.USE_YN = 'Y'                          ");
			sql.append("     AND F.DIAG_SECTION_CD = M.DIAG_SECTION_CD   ");
			sql.append("     AND F.DIAG_FLATFORM_CD = M.DIAG_FLATFORM_CD ");
			sql.append("     AND M.USE_YN = 'Y'                          ");
			sql.append("     AND G.DIAG_GROUP_CD = M.DIAG_GROUP_CD       ");
			sql.append("     AND M.USE_YN = 'Y'                          ");
			sql.append(" GROUP BY F.DIAG_SECTION_CD                      ");
			sql.append(" 				,F.DIAG_FLATFORM_CD              ");
			sql.append(" 				,F.DIAG_FLATFORM_NM              ");
			sql.append(" ORDER BY F.DIAG_SECTION_CD                      ");
			sql.append(" 				,F.DIAG_FLATFORM_CD	             ");
		}else{
			sql.append(" SELECT * FROM asmadmin."+tb_nm+" WHERE TARGET_YEAR = TO_CHAR(SYSDATE,'YYYY') ");
//			sql.append(" SELECT * FROM "+tb_nm+" WHERE TARGET_YEAR = TO_CHAR(SYSDATE,'YYYY') ");
		}
		return sql.toString();
	}
    
    /*
     * 
     */
    @Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int insert(final Map<String, Object> map, final String table_nm) throws SQLException  {
		return session.update("com.softworks.springframework.AsmInterfaceSchedule.insert_"+table_nm.toLowerCase(), map);
	}

    /*
     * 연계테이블(IF_ITS_OM0071) 데이터중 관련 데이터를 보안예외정책 처리결과(EXCEPT_POLICY_PROC_RESULT)에 저장
     */
    @Transactional(readOnly=false, propagation=Propagation.REQUIRED, rollbackFor={Exception.class})
	public int  delete(final Param param) throws SQLException  {
		return session.delete("com.softworks.springframework.AsmInterfaceSchedule.delete_"+param.get("table_nm").toLowerCase().trim(), param);
	}
}
