package com.softworks.springframework.web.controllers.front;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.AttachFileService;
import com.softworks.springframework.web.services.CodeLoaderService.CodeInfo;
import com.softworks.springframework.web.services.backoffice.CodeService;
import com.softworks.springframework.web.services.backoffice.MetaCompanyService;
import com.softworks.springframework.web.services.backoffice.MetaLawService;
import com.softworks.springframework.web.services.front.OrganizationService;
import com.softworks.springframework.web.services.front.SecurityAuditDetailService;
import com.softworks.springframework.web.services.front.SecurityAuditService;

@SuppressWarnings("unchecked")
@Controller
public class SecurityAuditController extends BaseController{

	@Autowired
	private	CodeService codeSvc;

	@Autowired
	private	SecurityAuditService svc;

	@Autowired
	private	SecurityAuditDetailService securityAuditDetailSvc;

	@Autowired
	private	MetaLawService metaLawSvc;

	@Autowired
	private	OrganizationService organizationSvc;

	@Autowired
	private	AttachFileService attachFileSvc;

	@Autowired
	private	MetaCompanyService metaCompanySvc;

	/**
	 * 보안 수검/감사 리스트
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/audit/fis120/list", method=RequestMethod.POST)
	public String list( final HttpServletResponse response, final HttpServletRequest request, final ModelMap model) throws Exception {

		HttpSession	session = request.getSession();

		Param	param	= new Param(request);
		param.put("uid", Utils.nvl((String)session.getAttribute("uid")));
		param.put("auth_group", Utils.nvl((String)session.getAttribute("group")));
		param.put("auth_check", "Y");

		//날짜 변환
		param.put("aply_start_day", Utils.nvl(((String)param.get("aply_start_day")).replace("-", ""), Utils.getTimeStampString("yyyy") +  "0101"));
		param.put("aply_end_day", Utils.nvl(((String)param.get("aply_end_day")).replace("-", ""), Utils.getTimeStampString("yyyy") +  "1231"));
		param.put("audit_nm", ((String)param.get("audit_nm")).trim());

		int	total	= svc.getListCount(param);

		model.addAttribute("total", total);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("list", 0 < total ? svc.getList(param) : null);
		model.addAttribute("auditTypCdList",svc.getUseCodeList("AUDIT_TYP_CD"));//종류

		List<CodeInfo> lawSystemList =  new ArrayList<CodeInfo>();
		for (Param e : metaLawSvc.getLawSystemAllList(param)) {
			CodeInfo codeInfo = new CodeInfo();
			codeInfo.setCode(e.get("LS_ID"));
			codeInfo.setName(e.get("LS_ABBR_NM"));
			lawSystemList.add(codeInfo);
		}
		model.addAttribute("lawSystemList", lawSystemList);//M_LAW_SYSTEM 관련 법/제도 리스트
		model.addAttribute("pageSizeChange", svc.getUseCodeList("PAGE_CHANGE"));
		model.addAttribute("menuAuth", setBtnAuth(request));
		return "securityAudit/securityAuditList.front";
	}

	/**
	 * 보안 수검/감사 등록
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/audit/fis120/regist", method=RequestMethod.POST)
	@ResponseBody
	public String regist(final HttpServletRequest request, final @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();


		try {
			String uid = Utils.nvl((String)session.getAttribute("uid"));
			String uname = Utils.nvl((String)session.getAttribute("uname"));

			Param param = new Param(map);

			//날짜 변환
			param.put("aply_start_day", ((String)param.get("aply_start_day")).replace("-", ""));
			param.put("aply_end_day", ((String)param.get("aply_end_day")).replace("-", ""));
			param.put("data_start_day", ((String)param.get("data_start_day")).replace("-", ""));
			param.put("data_end_day", ((String)param.get("data_end_day")).replace("-", ""));

			//파라미터 추가
			param.set("audit_state_cd", "W");//W 대기, P 진행중, C 완료
			param.set("uid", uid);
			param.set("uname", uname);

//			//기본정보 첨부파일ID
			param.put("basic_atch_file_id", attachFileSvc.getAtchFileId());

//			//증빙자료일괄등록 첨부파일ID
			param.put("batch_atch_file_id", attachFileSvc.getAtchFileId());

//			//기타자료 첨부파일ID
			param.put("etc_atch_file_id", attachFileSvc.getAtchFileId());

//			//최종증빙파일ID
			param.put("end_atch_file_id", attachFileSvc.getAtchFileId());


			List<Param> lawSystemCheckList = securityAuditDetailSvc.getLawSystemCheckList(param);
			Param lawSystemCheck = null;
			for (int i = 0, len = lawSystemCheckList.size(); i < len; i++) {
				lawSystemCheck = lawSystemCheckList.get(i);
				lawSystemCheck.put("atch_file_id", attachFileSvc.getAtchFileId());//detail file Id
			}

			svc.regist(param, lawSystemCheckList);
			jsonObject.put("result", true);

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}

	/**
	 * 보안 수검/감사 상세(기본정보)
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/audit/fis120/detail-basic", method=RequestMethod.POST)
	public String detailBasic( final HttpServletRequest request , final ModelMap model) throws Exception {

		HttpSession	session = request.getSession();
		String uid = Utils.nvl((String)session.getAttribute("uid"));
		String group = Utils.nvl((String)session.getAttribute("group"));

		Param	param	= new Param(request);
		Param detail = svc.getDetail(param);

		String menuAuth = svc.getSecurityAudioAuth(uid, group, detail.get("MANAGER_ID"), detail.get("REG_ID"));

		if("NN".equals(menuAuth)) {
			return "redirect:/error/accessDenied";
		}

		model.addAttribute("menuAuth", menuAuth);
		model.addAttribute("detail", detail);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("auditTypCdList",svc.getUseCodeList("AUDIT_TYP_CD"));//종류
		model.addAttribute("auditStateCdList",svc.getUseCodeList("AUDIT_STATE_CD"));//진행상태

		Param codeParam = new Param(request);
		codeParam.set("pcode", "COMPANY_CD");
		List<Param> codeList = codeSvc.getList(codeParam);
		model.addAttribute("CODE_COMPANY_CD", codeList);
		model.addAttribute("compnayBusiSiteAllList", metaCompanySvc.getCompanyBusiSiteAllList(param));
		return "WEB-INF/views/securityAudit/detailBasicForm";
	}

	/**
	 * 보안 수검/감사 상세(업무담당자)
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/audit/fis120/detail-manager", method=RequestMethod.POST)
	public String detailManager( final HttpServletRequest request , final ModelMap model) throws Exception {

		HttpSession	session = request.getSession();
		String uid = Utils.nvl((String)session.getAttribute("uid"));
		String group = Utils.nvl((String)session.getAttribute("group"));

		Param	param	= new Param(request);
		Param detail = svc.getDetail(param);

		String menuAuth = svc.getSecurityAudioAuth(uid, group, detail.get("MANAGER_ID"), detail.get("REG_ID"));

		if("NN".equals(menuAuth)) {
			return "redirect:/error/accessDenied";
		}

		model.addAttribute("menuAuth", menuAuth);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("detail", detail);
		model.addAttribute("auditPrivilegeCdList",svc.getUseCodeList("AUDIT_PRIVILEGE_CD"));//감사 권한 구분 코드
		model.addAttribute("auditStateCdList",svc.getUseCodeList("AUDIT_STATE_CD"));//진행상태
		List<CodeInfo> lawSystemList =  new ArrayList<CodeInfo>();

		for (Param e : metaLawSvc.getLawSystemAllList(param)) {
			CodeInfo codeInfo = new CodeInfo();
			codeInfo.setCode(e.get("LS_ID"));
			codeInfo.setName(e.get("LS_ABBR_NM"));
			lawSystemList.add(codeInfo);
		}
		model.addAttribute("lawSystemList", lawSystemList);//M_LAW_SYSTEM 관련 법/제도 리스트

		//---------------------- 인사정보  -------------------------------
		String company = Utils.nvl((String)session.getAttribute("company"),"H10");

		//계열사 정보
		model.addAttribute("comList", organizationSvc.getComList(param));
		model.addAttribute("company", company);

		List<CodeInfo> comList =  new ArrayList<CodeInfo>();
		for (Param e : organizationSvc.getComList(param)) {
			CodeInfo codeInfo = new CodeInfo();
			codeInfo.setCode(e.get("SKCOMPANYCODE"));
			codeInfo.setName(e.get("TEAMCODEMAIN"));
			comList.add(codeInfo);
		}
		model.addAttribute("comList", comList);//M_LAW_SYSTEM 관련 법/제도 리스트


		return "WEB-INF/views/securityAudit/detailManagerForm";
	}

	/**
	 * 대상점검목록 조회
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/audit/fis120/detail-checklist", method=RequestMethod.POST)
	public String detailChecklist( final HttpServletRequest request , final ModelMap model) throws Exception {

		HttpSession	session = request.getSession();
		String uid = Utils.nvl((String)session.getAttribute("uid"));
		String group = Utils.nvl((String)session.getAttribute("group"));

		Param	param	= new Param(request);
		Param detail = svc.getDetail(param);
		String menuAuth = svc.getSecurityAudioAuth(uid, group, detail.get("MANAGER_ID"), detail.get("REG_ID"));

		if("NN".equals(menuAuth)) {
			return "redirect:/error/accessDenied";
		}

		model.addAttribute("menuAuth", menuAuth);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("detail", detail);
		model.addAttribute("chkStateCdList",svc.getUseCodeList("CHK_STATE_CD"));//진행상태
		model.addAttribute("auditResultCdList",svc.getUseCodeList("AUDIT_RESULT_CD"));//심사결과
		model.addAttribute("procResultCdList",svc.getUseCodeList("PROC_RESULT_CD"));//조치결과

		model.addAttribute("list", securityAuditDetailSvc.getChecklist(param));
		model.addAttribute("auditPrivilegeCdList",svc.getUseCodeList("AUDIT_PRIVILEGE_CD"));//감사 권한 구분 코드

		return "WEB-INF/views/securityAudit/detailChecklistForm";
	}


	/**
	 * 대상점검목록상세 조회
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/audit/fis120/detail-item", method=RequestMethod.POST)
	public String detailItem( final HttpServletRequest request , final ModelMap model) throws Exception {

		HttpSession	session = request.getSession();
		String uid = Utils.nvl((String)session.getAttribute("uid"));
		String group = Utils.nvl((String)session.getAttribute("group"));

		Param	param	= new Param(request);
		String ls_item_id = param.get("ls_item_id");
		logger.debug("[detailItem] ls_item_id >> " + ls_item_id);

		HashMap resultMap = securityAuditDetailSvc.detailItem(param);

		Param detail = (Param)resultMap.get("detail");
		Param mainDetail = (Param)resultMap.get("mainDetail");

		String menuAuth = svc.getSecurityAudioAuth(uid, group, mainDetail.get("MANAGER_ID"), mainDetail.get("REG_ID"));

		if("NN".equals(menuAuth)) {
			return "redirect:/error/accessDenied";
		}

		model.addAttribute("menuAuth", menuAuth);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("detail", detail);
		model.addAttribute("mainDetail", mainDetail);
		model.addAttribute("list", (List<Param>)resultMap.get("lawCheckList"));
		model.addAttribute("chkStateCdList",svc.getUseCodeList("CHK_STATE_CD"));//진행상태
		model.addAttribute("auditResultCdList",svc.getUseCodeList("AUDIT_RESULT_CD"));//심사결과
		model.addAttribute("procResultCdList",svc.getUseCodeList("PROC_RESULT_CD"));//조치결과
		model.addAttribute("auditPrivilegeCdList",svc.getUseCodeList("AUDIT_PRIVILEGE_CD"));//감사 권한 구분 코드

		Param codeParam = new Param(request);
		codeParam.set("pcode", "COMPANY_CD");
		List<Param> codeList = codeSvc.getList(codeParam);
		model.addAttribute("CODE_COMPANY_CD", codeList);

		return "WEB-INF/views/securityAudit/detailItemForm";
	}

	/**
	 * 대상점검목록상세 조회
	 * @param request
	 * @param model
	 * @return
	 * @throws IOException
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/audit/fis120/detail-item-check-list", method=RequestMethod.POST)
	@ResponseBody
	public String detailItemCheckList(final HttpServletResponse response, final HttpServletRequest request, @RequestBody HashMap<String, Object> map) throws IOException {

		HttpSession	session = request.getSession();
		String uid = Utils.nvl((String)session.getAttribute("uid"));
		String group = Utils.nvl((String)session.getAttribute("group"));
		JSONObject jsonObject = new JSONObject();

		try {

			Param param = new Param(map);
			Param detail = svc.getDetail(param);
			String menuAuth = svc.getSecurityAudioAuth(uid, group, detail.get("MANAGER_ID"), detail.get("REG_ID"));

			if("NN".equals(menuAuth)) {
				response.sendError(403, "페이지 접근권한 없음");
			}

			jsonObject.put("list", securityAuditDetailSvc.detailItemCheckList(param));
			jsonObject.put("result", true);

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}

	/**
	 * 대상점검목록상세 저장
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/audit/fis120/regist-detail-item", method=RequestMethod.POST)
	@ResponseBody
	public String registDetailItem(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();

		String uid = Utils.nvl((String)session.getAttribute("uid"));
		String uname = Utils.nvl((String)session.getAttribute("uname"));


		try {
			Param param = new Param(map);

			String chk_state_cd = param.get("chk_state_cd");//진행상태

			if("".equals(chk_state_cd)) {
				param.put("req_day", param.get("req_day").replace("-", ""));
				param.put("proc_end_day", param.get("proc_end_day").replace("-", ""));

			}else if("W".equals(chk_state_cd)) {//작업중
				param.put("chk_emp_no", ""); //점검자 사번
				param.put("chk_emp_nm", "");	//점검자
			}else if("C".equals(chk_state_cd)) {//완료
				param.put("chk_emp_no", uid); //점검자 사번
				param.put("chk_emp_nm", uname);	//점검자
			}

			//파라미터 추가
			param.set("uid", uid);
			param.set("uname", uname);

			securityAuditDetailSvc.registManager(param);

			jsonObject.put("param", param);
			jsonObject.put("detail", securityAuditDetailSvc.getCheckDetail(param));
			jsonObject.put("result", true);

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}

	/**
	 * 보안 수검/감사 대상 점검 목록 - 진행상태 변경
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/audit/fis120/update-state", method=RequestMethod.POST)
	@ResponseBody
	public String updateState(final HttpServletResponse response, final HttpServletRequest request, final @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", false);

		try {
			String uid = Utils.nvl((String)session.getAttribute("uid"));
			String uname = Utils.nvl((String)session.getAttribute("uname"));
			String group = Utils.nvl((String)session.getAttribute("group"));

			List<?> list =  (List<?>) map.get("list");

			Param param = new Param(map);
			//파라미터 추가
			param.set("uid", uid);
			param.set("uname", uname);


			Param detailParam = new Param();
			detailParam.put("audit_id", param.get("audit_id"));
			Param detail = svc.getDetail(detailParam);
			String menuAuth = svc.getSecurityAudioAuth(uid, group, detail.get("MANAGER_ID"), detail.get("REG_ID"));

			if("NN".equals(menuAuth) || "SN".equals(menuAuth)) {
				response.sendError(403, "페이지 접근권한 없음");
			}else {
//			//기본정보 첨부파일ID
				svc.updateState(param, list);
				jsonObject.put("param", param);
				jsonObject.put("result", true);
			}
		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}

	/**
	 * 증빙자료일괄등록 조회
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/audit/fis120/detail-batch", method=RequestMethod.POST)
	public String detailBatch( final HttpServletRequest request , final ModelMap model) throws Exception {

		HttpSession	session = request.getSession();
		String uid = Utils.nvl((String)session.getAttribute("uid"));
		String group = Utils.nvl((String)session.getAttribute("group"));
		Param	param	= new Param(request);

		Param detail = svc.getDetail(param);
		String menuAuth = svc.getSecurityAudioAuth(uid, group, detail.get("MANAGER_ID"), detail.get("REG_ID"));

		if("NN".equals(menuAuth)) {
			return "redirect:/error/accessDenied";
		}

		model.addAttribute("menuAuth", menuAuth);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("detail", detail);

		return "WEB-INF/views/securityAudit/detailBatchForm";
	}


	/**
	 * 기타 조회
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/audit/fis120/detail-etc", method=RequestMethod.POST)
	public String detailEtc( final HttpServletRequest request , final ModelMap model) throws Exception {

		HttpSession	session = request.getSession();
		String uid = Utils.nvl((String)session.getAttribute("uid"));
		String group = Utils.nvl((String)session.getAttribute("group"));

		Param	param	= new Param(request);
		Param detail = svc.getDetail(param);
		String menuAuth = svc.getSecurityAudioAuth(uid, group, detail.get("MANAGER_ID"), detail.get("REG_ID"));

		if("NN".equals(menuAuth)) {
			return "redirect:/error/accessDenied";
		}

		model.addAttribute("menuAuth", menuAuth);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("detail", detail);
		return "WEB-INF/views/securityAudit/detailEtcForm";
	}


	/**
	 * 보안 수검/감사 수정
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/audit/fis120/update", method=RequestMethod.POST)
	@ResponseBody
	public String update(final HttpServletResponse response, final HttpServletRequest request, final @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", false);

		//날짜 변환
		map.put("aply_start_day", ((String)map.get("aply_start_day")).replace("-", ""));
		map.put("aply_end_day", ((String)map.get("aply_end_day")).replace("-", ""));
		map.put("data_start_day", ((String)map.get("data_start_day")).replace("-", ""));
		map.put("data_end_day", ((String)map.get("data_end_day")).replace("-", ""));

		try {
			String uid = Utils.nvl((String)session.getAttribute("uid"));
			String uname = Utils.nvl((String)session.getAttribute("uname"));
			String group = Utils.nvl((String)session.getAttribute("group"));


			Param param = new Param(map);
			//파라미터 추가
			param.set("uid", uid);
			param.set("uname", uname);
			Param detail = svc.getDetail(param);
			String menuAuth = svc.getSecurityAudioAuth(uid, group, detail.get("MANAGER_ID"), detail.get("REG_ID"));

			if("NN".equals(menuAuth) || "SN".equals(menuAuth)) {
				response.sendError(403, "페이지 접근권한 없음");
			}else {
				svc.update(param);
				jsonObject.put("result", true);
			}


		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}


	/**
	 * 보안 수검/감사 진행 상태 수정
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/audit/fis120/update-audit-state", method=RequestMethod.POST)
	@ResponseBody
	public String updateAuditStateCd(final HttpServletResponse response, final HttpServletRequest request, final @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", false);

		try {
			String uid = Utils.nvl((String)session.getAttribute("uid"));
			String uname = Utils.nvl((String)session.getAttribute("uname"));
			String email = Utils.nvl((String)session.getAttribute("email"));
			String group = Utils.nvl((String)session.getAttribute("group"));

			Param param = new Param(map);
			//파라미터 추가
			param.set("uid", uid);
			param.set("uname", uname);
			param.set("email", email);

			Param detail = svc.getDetail(param);
			String menuAuth = svc.getSecurityAudioAuth(uid, group, detail.get("MANAGER_ID"), detail.get("REG_ID"));

			if("NN".equals(menuAuth) || "SN".equals(menuAuth)) {
				response.sendError(403, "페이지 접근권한 없음");
			}else {
				HashMap<String, Object> resultMap = svc.updateAuditStateCd(param);
				jsonObject.put("fileInfo", resultMap.get("fileInfo"));
				jsonObject.put("param", param);
				jsonObject.put("result", true);
			}

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}


	/**
	 * 보안 수검/감사 수정(증빙 대상 계열사별 사업장 설정)
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/audit/fis120/updateCompany", method=RequestMethod.POST)
	@ResponseBody
	public String updateCompany(final HttpServletResponse response, final HttpServletRequest request, final @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", false);


		try {
			String uid = Utils.nvl((String)session.getAttribute("uid"));
			String uname = Utils.nvl((String)session.getAttribute("uname"));
			String group = Utils.nvl((String)session.getAttribute("group"));

			Param param = new Param(map);
			//파라미터 추가
			param.set("uid", uid);
			param.set("uname", uname);

			Param detail = svc.getDetail(param);
			String menuAuth = svc.getSecurityAudioAuth(uid, group, detail.get("MANAGER_ID"), detail.get("REG_ID"));

			if("NN".equals(menuAuth) || "SN".equals(menuAuth)) {
				response.sendError(403, "페이지 접근권한 없음");
			}else {
				svc.update(param);
				jsonObject.put("result", true);
			}

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}

	/**
	 * 보안 수검/감사 삭제
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/audit/fis120/delete-basic", method=RequestMethod.POST)
	@ResponseBody
	public String deleteBasic(final HttpServletResponse response, final HttpServletRequest request, final @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", false);

		try {
			String uid = Utils.nvl((String)session.getAttribute("uid"));
			String uname = Utils.nvl((String)session.getAttribute("uname"));
			String group = Utils.nvl((String)session.getAttribute("group"));

			Param param = new Param(map);
			//파라미터 추가
			param.set("uid", uid);
			param.set("uname", uname);

			Param detail = svc.getDetail(param);
			String menuAuth = svc.getSecurityAudioAuth(uid, group, detail.get("MANAGER_ID"), detail.get("REG_ID"));

			if("NN".equals(menuAuth) || "SN".equals(menuAuth)) {
				response.sendError(403, "페이지 접근권한 없음");
			}else {
				svc.deleteBasic(param);
				jsonObject.put("result", true);
			}

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}
}
