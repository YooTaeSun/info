package com.softworks.springframework.web.controllers.front;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.CodeLoaderService;
import com.softworks.springframework.web.services.CodeLoaderService.CodeInfo;
import com.softworks.springframework.web.services.AttachFileService;
import com.softworks.springframework.web.services.front.BbsFrontService;

@Controller
public class BbsFrontController extends BaseController {
	
	@Autowired
	private	BbsFrontService	svc;
	
	@Autowired
	private	AttachFileService attachFileSvc;

	private	String list(final Param param, final ModelMap model) throws Exception {
		String sdate = param.get("sdate");
		if(sdate.equals("")){
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			int nYear = calendar.get(Calendar.YEAR);
			String nSdate = nYear+"-01-01";
			String nEdate = nYear+"-12-31";
			param.set("sdate", nSdate);
			param.set("edate", nEdate);
		}
		
		int	total	= svc.getListCount(param);
		
		Param bbsMasterInfo = svc.getBbsMasterInfo(param.get("type"));
		model.addAttribute("total", total);
		model.addAttribute("list", 0 < total ? svc.getList(param) : null);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("pageSizeChange", CodeLoaderService.CODE.get("PAGE_CHANGE"));
		model.addAttribute("nttTypCd",CodeLoaderService.CODE.get(bbsMasterInfo.get("NTT_TYP_CD_ID")));
		return "bbs/"+param.get("type")+"/list.front";
	}
	
	private String info(final Param param, final String query, final ModelMap model, final String type) throws Exception {
		Param bbsMasterInfo = svc.getBbsMasterInfo(type);
		Param info = svc.getInfo(param);
		param.set("type",type);
		if(!info.isEmpty()){
			//update view cnt
			svc.updateViewCnt(param);
		}
		model.addAttribute("hiddenQuery", Utils.base64DecodeHidden(query));
		model.addAttribute("info", info);
		model.addAttribute("nttTypCd",CodeLoaderService.CODE.get(bbsMasterInfo.get("NTT_TYP_CD_ID")));
		model.addAttribute("type",type);
		model.addAttribute("NTT_AUTH_CD",CodeLoaderService.CODE.get("NTT_AUTH_CD"));
		return "WEB-INF/views/bbs/"+type+"/detail";
	}
	
	//BBS 목록 조회
	@RequestMapping(value="/front/internal/bbs/{type}/list", method=RequestMethod.POST)
	public String getList(final HttpServletRequest request, @PathVariable("type") final String type , final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	param	= new Param(request);
				param.set("type", type);
				switch (type) {
					case "BBS00003": 
						break;
					default:
						param.set("ntt_auth_cd", Utils.nvl((String)session.getAttribute("regularity_cd")));
						break;
				}
		return list(param, model);
	}
	//BBS 상세
	@RequestMapping(value="/front/internal/bbs/{type}/detail", method=RequestMethod.POST)
	public String getDetail(final HttpServletRequest request, @PathVariable("type") final String type,
						  	   @RequestParam(value="queryString", required=false) final String query, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	param = new Param(request);
		switch (type) {
			case "BBS00003": 
				break;
			default:
				param.set("ntt_auth_cd", Utils.nvl((String)session.getAttribute("regularity_cd")));
				break;
		}
		return info(param, query, model, type);
	}
	
	//BBS 등록폼
	@RequestMapping(value="/front/internal/bbs/{type}/form", method=RequestMethod.POST)
	public String getForm(final HttpServletRequest request, @PathVariable("type") final String type,
						  	   @RequestParam(value="queryString", required=false) final String query, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	param = new Param(request);
		switch (type) {
			case "BBS00003": 
				break;
			default:
				param.set("ntt_auth_cd", Utils.nvl((String)session.getAttribute("regularity_cd")));
				break;
		}
		Param bbsMasterInfo = svc.getBbsMasterInfo(type);
		model.addAttribute("hiddenQuery", Utils.base64DecodeHidden(query));
		model.addAttribute("info", 0 == Utils.nevl(param.getInt("ntt_id")) ? null : svc.getInfo(param));
		model.addAttribute("NTT_TYP_CD",CodeLoaderService.CODE.get(bbsMasterInfo.get("NTT_TYP_CD_ID")));
		model.addAttribute("type",type);
		model.addAttribute("NTT_AUTH_CD",CodeLoaderService.CODE.get("NTT_AUTH_CD"));
		return "WEB-INF/views/bbs/"+type+"/form";
	}
	
	@ResponseBody
	@RequestMapping(value="/front/internal/bbs/{type}/regist", method=RequestMethod.POST)
	public  String regist(final HttpServletRequest request, @PathVariable("type") final String type, @RequestBody HashMap<String, Object> map) {
		
		HttpSession	session	= request.getSession();
		StringBuilder	json	= new StringBuilder();
		Param	    param	= new Param(map);
		
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		
		try{
			Param bbsMasterInfo = svc.getBbsMasterInfo(type);
			if(!bbsMasterInfo.get("BBS_TYP_CD").equals("C") && bbsMasterInfo.get("NTT_TYP_CD_ID").equals("NA")){
				param.set("ntt_typ_cd", "NA");
			}
			
			if(!param.get("ntt_id").isEmpty()){
				svc.update(param);
			}else{
				//기본정보 첨부파일ID
				param.set("atch_file_id", attachFileSvc.getAtchFileId());
				// 등록
				svc.insert(param);
				attachFileSvc.insert(param);
			}
			
			json.append("{")
			.append("\"result\"").append(":").append(true).append(",")
			.append("\"seq\":").append("\"").append(param.get("ntt_id")).append("\"");
			json.append("}");
			
		} catch(Exception e) {
			logger.error("저장중 에러", e);
			
			json.append("{")
			.append("\"result\"").append(":").append(false);
			json.append("}");
		}
		
		return json.toString();
	}
	
	@ResponseBody
	@RequestMapping(value="/front/internal/bbs/{type}/delete", method=RequestMethod.POST)
	public  String delete(final HttpServletRequest request, @PathVariable("type") final String type, @RequestBody HashMap<String, Object> map) {
		StringBuilder	json	= new StringBuilder();
		Param	    param	= new Param(map);
		boolean result = false;
		
		try{
			if(!param.get("ntt_id").isEmpty()){
				Param info = svc.getInfo(param);
				svc.delete(param.getInt("ntt_id"), type);
				param.set("atch_file_id",info.get("ATCH_FILE_ID"));
				attachFileSvc.delete(param);
				result = true;
			}			
			json.append("{").append("\"result\"").append(":").append(result);
			json.append("}");
			
		} catch(Exception e) {
			logger.error("저장중 에러", e);
			
			json.append("{")
			.append("\"result\"").append(":").append(false);
			json.append("}");
		}
		
		return json.toString();
	}
	
	@RequestMapping(value="/front/internal/bbs/{type}/list/excelDownload")
	public String excelList(final HttpServletRequest request, @PathVariable("type") final String type , final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param param = new Param(request);
		param.set("type", type);
		param.set("ntt_auth_cd", Utils.nvl((String)session.getAttribute("regularity_cd")));
		
		int	total	= svc.getListCount(param);
		
		Param bbsMasterInfo = svc.getBbsMasterInfo(param.get("type"));
		param.set("page", 1);
		param.set("pageSize", total);
		
		List<CodeInfo> codeList = CodeLoaderService.CODE.get(bbsMasterInfo.get("NTT_TYP_CD_ID"));
		
		if(codeList != null && codeList.size() > 0){
			param.set("ntt_typ_cd_id", bbsMasterInfo.get("NTT_TYP_CD_ID"));
		}
		
		if(codeList != null && codeList.size() > 0){
			param.set("ntt_typ_cd_id", bbsMasterInfo.get("NTT_TYP_CD_ID"));
			List<Param> data = svc.getList(param);
			
			String[] category	= {"게시물유형",	"제목", "내용" , "등록자",	"등록자 사번",	"등록일자"};
			String[] columns	= { "NTT_TYP_NM", "NTT_SJ", "NTT_CN", "REG_NM", "REG_ID", "REG_DT"};
			int[]	 colWidth	= {15, 30, 50, 15, 15,  20};
			model.addAttribute("filename", bbsMasterInfo.get("BBS_NM"));
	        model.addAttribute("chapter", bbsMasterInfo.get("BBS_NM"));
	        model.addAttribute("category", category);
	        model.addAttribute("columns", columns);
	        model.addAttribute("columnsWidth", colWidth);
			model.addAttribute("data", data);
			
		}else{
			List<Param> data = svc.getList(param);
			String[] category	= {"제목", "내용" , "등록자",	"등록자 사번",	"등록일자"};
			String[] columns	= {"NTT_SJ", "NTT_CN", "REG_NM", "REG_ID", "REG_DT"};
			int[]	 colWidth	= {30, 50, 15, 15,  20};
			model.addAttribute("filename", bbsMasterInfo.get("BBS_NM"));
	        model.addAttribute("chapter", bbsMasterInfo.get("BBS_NM"));
	        model.addAttribute("category", category);
	        model.addAttribute("columns", columns);
	        model.addAttribute("columnsWidth", colWidth);
			model.addAttribute("data", data);
		}
		
		return "excelDownloadView";
		
	}
}
