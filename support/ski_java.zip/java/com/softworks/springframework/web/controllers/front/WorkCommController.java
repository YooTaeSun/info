package com.softworks.springframework.web.controllers.front;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.CodeLoaderService;
import com.softworks.springframework.web.services.front.WorkCommService;

@Controller
@RequestMapping(value="/comm")
public class WorkCommController extends BaseController {
    
    private final String TIAMS_URL =   "http://"+ Property.getProperty("if.tiams.url");
    
    @Autowired
    WorkCommService    svc;
    
    //자산현황 팝업 
    @RequestMapping(value="/getSvcCdInfo", method=RequestMethod.POST)
    public String getSvcCdInfo(final HttpServletRequest request, ModelMap model) throws Exception {
        Param param   = new Param(request);
        //서비스코드 없고 팝업타입이 S -> 검색가능 
        String svcNo = param.getString("svc_no");
        String searchSvcNo = param.getString("searchSvcNo");
        if((svcNo == null || "".equals(svcNo)) && !(searchSvcNo == null || "".equals(searchSvcNo))){
        	svcNo = searchSvcNo;
        }
        String svc_nm = param.getString("svc_nm");
        String host_nm = param.getString("host_nm");
        String popType = param.getString("pop_type");
        String domainType = param.getString("domain_type");
        
        if(popType.equals("S")) {
              //도메인타입
              model.addAttribute("domainTypeList", CodeLoaderService.CODE.get("TA_DOMAIN"));
              
              if(!domainType.equals("")) {
                  //서비스코드
                  model.addAttribute("svcCdList",svc.getSvcNoListByDomainCd(param));
              }
        }
        //검색어 리스트 추가
        if(!("".equals(svc_nm) && "".equals(host_nm))){
            model.addAttribute("searchResultList",svc.getConfMasterSearchList(param));
        }
        if(!svcNo.equals("")) {
            //TA정보
            model.addAttribute("taInfo",svc.getLastTaInfo(svcNo));
            //자산
            model.addAttribute("confMasterList",svc.getConfMasterListBySvcNo(svcNo));
            //장애이력
            model.addAttribute("rmList",svc.getRiskMasterListBySvcNo(svcNo));
        }
           
        //팝업타입
        model.addAttribute("popType",popType);
        //Tiams url
        model.addAttribute("tiamsUrl",TIAMS_URL);
        
        
        return "WEB-INF/views/popup/svcCdInfo";
    }
    
    //도메인코드에 따른 서비스코드 조회
    @SuppressWarnings("unchecked")
    @RequestMapping(value="/getSvcCdList", method=RequestMethod.POST)
    public @ResponseBody JSONObject getSvcCdList(final HttpServletRequest request) throws Exception {
        Param param   = new Param(request);
        List<Param> svcCdList = svc.getSvcNoListByDomainCd(param);
        
        JSONObject jsonObject = new JSONObject();
        
        jsonObject.put("result", 0 < svcCdList.size() ? true : false);
        jsonObject.put("list", svcCdList);
        
        return jsonObject;
    }
    
  //자산현황 팝업 
    @RequestMapping(value="/getSmsInfo", method=RequestMethod.POST)
    public String getSmsInfo(final HttpServletRequest request, ModelMap model) throws Exception {
        Param param   = new Param(request);
        String sdate = param.getString("sdate");
        
        if(sdate.equals("") || sdate.equals(null)) {
        	param.set("sdate", Utils.date2Str(Utils.getMonthAgo()));
        	param.set("edate", Utils.date2Str(Utils.getToday()));
        }
        
        model.addAttribute("list", svc.getCommMmsLogList(param));

        return "WEB-INF/views/popup/smsInfo";
    }

}
 