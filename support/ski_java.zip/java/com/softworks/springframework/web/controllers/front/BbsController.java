package com.softworks.springframework.web.controllers.front;

import java.io.File;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.front.BbsService;

@Controller
public class BbsController extends BaseController {

	@Autowired
	BbsService	svc;
	//private	final String	BOARD_ATTACH_PATH	= filePath + Property.getProperty("file.board"); //보안점검
	private	final String	BOARD_ATTACH_PATH	= filePath + "/board/";

	private void setDefaultParam(final HttpSession session, final Param param) throws Exception {
		param.set("writer", (String)session.getAttribute("uid"));
		param.set("company", (String)session.getAttribute("company"));
	}

	private	String list(final Param param, final ModelMap model) throws Exception {
		if(isSuper)
			param.set("company", "");
		int	total	= svc.getListCount(param);
		
		model.addAttribute("total", total);
		model.addAttribute("list", 0 < total ? svc.getList(param) : null);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		
		return "bbs/list.front";
	}
	
	private String info(final Integer seq, final String query, final ModelMap model) throws Exception {
		model.addAttribute("hiddenQuery", Utils.base64DecodeHidden(query));
		model.addAttribute("info", 0 == Utils.nevl(seq) ? null : svc.getInfo(seq));
		
		return "bbs/view.front";
	}
	//보안가이드
	@RequestMapping(value="/board/guide", method=RequestMethod.POST)
	public String getGuideList(final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
				param.set("type", "01");

		setDefaultParam(request.getSession(), param);
		
		return list(param, model);
	}
	//보안가이드 상세
	@RequestMapping(value="/board/guide/{seq}", method=RequestMethod.POST)
	public String getGuideInfo(@PathVariable("seq") final int seq,
						  	   @RequestParam(value="queryString", required=false) final String query, final ModelMap model) throws Exception {
		return info(seq, query, model);
	}
	//메뉴얼
	@RequestMapping(value="/board/menual", method=RequestMethod.POST)
	public String getMenualList(final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
				param.set("type", "02");
		
		setDefaultParam(request.getSession(), param);
		
		return list(param, model);
	}
	//메뉴얼 상세
	@RequestMapping(value="/board/menual/{seq}", method=RequestMethod.POST)
	public String getMenualInfo(@PathVariable("seq") final int seq,
						  		@RequestParam(value="queryString", required=false) final String query, final ModelMap model) throws Exception {
		return info(seq, query, model);
	}
	//공지사항
	@RequestMapping(value="/board/notice", method=RequestMethod.POST)
	public String getNoticeList(final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
				param.set("type", "03");
		
		setDefaultParam(request.getSession(), param);
		
		return list(param, model);
	}
	//공지사항 상세
	@RequestMapping(value="/board/notice/{seq}", method=RequestMethod.POST)
	public String getNoticeInfo(@PathVariable("seq") final int seq,
						  		@RequestParam(value="queryString", required=false) final String query, final ModelMap model) throws Exception {
		return info(seq, query, model);
	}
	
	//Q&A 목록
	@RequestMapping(value="/board/qna", method=RequestMethod.POST)
	public String getQnaList(final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
				param.set("type", "04");
				param.set("uid", (String)request.getSession().getAttribute("uid"));
		setDefaultParam(request.getSession(), param);
		System.out.println("####### QALIST");
		System.out.println("####### type ==>"+param.get("type"));

		int	total	= svc.getListCount(param);
		
		model.addAttribute("total", total);
		model.addAttribute("list", 0 < total ? svc.getList(param) : null);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		
		return "bbs/qna.front";
	}
	
	//Q&A 상세화면
	@RequestMapping(value="/board/qna/{seq}", method=RequestMethod.POST)
	public String getQnaInfo(@PathVariable("seq") final int seq,
						  	final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
				param.set("uid", (String)request.getSession().getAttribute("uid"));
				param.set("seq", seq);
		
		model.addAttribute("hiddenQuery", Utils.base64DecodeHidden(param.get("queryString")));
		model.addAttribute("info", svc.getQaInfo(param));
		
		return "bbs/qaInfo.front";
	}
	//Q&A 등록/수정폼
	@RequestMapping(value="/board/qna/modify", method=RequestMethod.POST)
	public String qaForm(@RequestParam(value="seq", required=false) final Integer seq,
						 @RequestParam(value="queryString", required=false) final String query,
						 final ModelMap model) throws Exception {
		info(seq, query, model);
		
		return "bbs/qaForm.front";
	}
	//Q&A 등록액션
	@RequestMapping(value="/board/qna/insert", method=RequestMethod.POST)
	public String qaInsert(final MultipartHttpServletRequest request) {
		Param	param		= null;
		String	uploadPath	= BOARD_ATTACH_PATH+File.separator + "04";
		try {
			MultipartFile	attach	= request.getFile("attach");
			
			param	= new Param(request);
			//param.set("attach", null == attach || attach.isEmpty() ? "" : attach.getOriginalFilename());
			
			setDefaultParam(request.getSession(), param);
			svc.insert(param);
			
			if(null != attach && !attach.isEmpty()){
				svc.saveFiles(param, attach, uploadPath);
			}	
			
			return Utils.sendMessage(request, "질문을 등록 했습니다.", "/board/qna", Utils.base64DecodeHidden(param.get("queryString")));
		} catch(Exception e) {
			logger.error("QA 등록에러 : FRONT", e);
		}
		
		return Utils.sendMessage(request, "질문 등록중 오류가 발생했습니다.");
	}
	//Q&A 수정액션
	@RequestMapping(value="/board/qna/update/{seq}", method=RequestMethod.POST)
	public String qaModify(@PathVariable("seq") final int seq, final MultipartHttpServletRequest request) {
		String	uploadPath	= BOARD_ATTACH_PATH+File.separator + "04";
		Param	param	= null;
		
		try {
			if(svc.isAnswer(seq)) return Utils.sendMessage(request, "답변이 등록된 질문은 수정하실 수 없습니다.", "/board/qna");
			
			MultipartFile	attach	= request.getFile("attach");
			
			param	= new Param(request);
			param.set("seq", seq);
			//param.set("attach", null == attach || attach.isEmpty() ? "" : attach.getOriginalFilename());

			setDefaultParam(request.getSession(), param);
			svc.update(param);

			if(null != attach && !attach.isEmpty()){
				svc.saveFiles(param, attach, uploadPath);
			}
			
			return Utils.sendMessage(request, "질문을 수정 했습니다.", "/board/qna/" + seq , Utils.base64DecodeHidden(param.get("queryString")));
		} catch(Exception e) {
			logger.error("QA 수정에러 : FRONT", e);
		}
		
		return Utils.sendMessage(request, "질문 수정중 오류가 발생했습니다.");
	}
	
	//Q&A 삭제액션
	@RequestMapping(value="/board/qna/delete/{seq}", method=RequestMethod.POST)
	public String qaDelete(@PathVariable("seq") final int seq, final HttpServletRequest request) {
		try {
			svc.delete(seq, (String)request.getSession().getAttribute("uid"));
			
			return Utils.sendMessage(request, "질문을 삭제 했습니다.", "/board/qna", Utils.base64DecodeHidden((String)request.getParameter("queryString")));
		} catch(Exception e) {
			logger.error("질문 삭제중 에러", e);
		}
		
		return Utils.sendMessage(request, "질문 삭제중 오류가 발생 했습니다.");
	}

	//개선사항 목록
	@RequestMapping(value="/board/improve", method=RequestMethod.POST)
	public String getImproveList(final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
				param.set("type", "05");
				param.set("uid", (String)request.getSession().getAttribute("uid"));
		setDefaultParam(request.getSession(), param);
		System.out.println("####### QALIST");
		System.out.println("####### type ==>"+param.get("type"));

		int	total	= svc.getListCount(param);
		
		model.addAttribute("total", total);
		model.addAttribute("list", 0 < total ? svc.getList(param) : null);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		
		return "bbs/improve.front";
	}
	
	//개선사항 상세화면
	@RequestMapping(value="/board/improve/{seq}", method=RequestMethod.POST)
	public String getImproveInfo(@PathVariable("seq") final int seq,
						  	final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
				param.set("uid", (String)request.getSession().getAttribute("uid"));
				param.set("seq", seq);
		
		model.addAttribute("hiddenQuery", Utils.base64DecodeHidden(param.get("queryString")));
		model.addAttribute("info", svc.getQaInfo(param));
		
		return "bbs/improveInfo.front";
	}
	//개선사항 등록/수정폼
	@RequestMapping(value="/board/improve/modify", method=RequestMethod.POST)
	public String improveForm(@RequestParam(value="seq", required=false) final Integer seq,
						 @RequestParam(value="queryString", required=false) final String query,
						 final ModelMap model) throws Exception {
		info(seq, query, model);
		
		return "bbs/improveForm.front";
	}
	//개선사항 등록액션
	@RequestMapping(value="/board/improve/insert", method=RequestMethod.POST)
	public String improveInsert(final MultipartHttpServletRequest request) {
		Param	param		= null;
		String	uploadPath	= BOARD_ATTACH_PATH+File.separator + "05";
		try {
			MultipartFile	attach	= request.getFile("attach");
			
			param	= new Param(request);
			//param.set("attach", null == attach || attach.isEmpty() ? "" : attach.getOriginalFilename());
			
			setDefaultParam(request.getSession(), param);
			svc.insert(param);
			
			if(null != attach && !attach.isEmpty()){
				svc.saveFiles(param, attach, uploadPath);
			}	
			
			return Utils.sendMessage(request, "질문을 등록 했습니다.", "/board/improve", Utils.base64DecodeHidden(param.get("queryString")));
		} catch(Exception e) {
			logger.error("QA 등록에러 : FRONT", e);
		}
		
		return Utils.sendMessage(request, "질문 등록중 오류가 발생했습니다.");
	}
	//개선사항 수정액션
	@RequestMapping(value="/board/improve/update/{seq}", method=RequestMethod.POST)
	public String improveModify(@PathVariable("seq") final int seq, final MultipartHttpServletRequest request) {
		String	uploadPath	= BOARD_ATTACH_PATH+File.separator + "05";
		Param	param	= null;
		
		try {
			if(svc.isAnswer(seq)) return Utils.sendMessage(request, "답변이 등록된 질문은 수정하실 수 없습니다.", "/board/improve");
			
			MultipartFile	attach	= request.getFile("attach");
			
			param	= new Param(request);
			param.set("seq", seq);
			//param.set("attach", null == attach || attach.isEmpty() ? "" : attach.getOriginalFilename());

			setDefaultParam(request.getSession(), param);
			svc.update(param);

			if(null != attach && !attach.isEmpty()){
				svc.saveFiles(param, attach, uploadPath);
			}
			
			return Utils.sendMessage(request, "질문을 수정 했습니다.", "/board/improve/" + seq , Utils.base64DecodeHidden(param.get("queryString")));
		} catch(Exception e) {
			logger.error("QA 수정에러 : FRONT", e);
		}
		
		return Utils.sendMessage(request, "질문 수정중 오류가 발생했습니다.");
	}
	
	//개선사항 삭제액션
	@RequestMapping(value="/board/improve/delete/{seq}", method=RequestMethod.POST)
	public String improveDelete(@PathVariable("seq") final int seq, final HttpServletRequest request) {
		try {
			svc.delete(seq, (String)request.getSession().getAttribute("uid"));
			
			return Utils.sendMessage(request, "질문을 삭제 했습니다.", "/board/improve", Utils.base64DecodeHidden((String)request.getParameter("queryString")));
		} catch(Exception e) {
			logger.error("질문 삭제중 에러", e);
		}
		
		return Utils.sendMessage(request, "질문 삭제중 오류가 발생 했습니다.");
	}
	
//	//FAQ 목록
//	@RequestMapping(value="/board/faq", method=RequestMethod.POST)
//	public String faqList(final HttpServletRequest request, final ModelMap model) throws Exception {
//		Param	param	= new Param(request);
//				param.set("type", "05");
//		
//		setDefaultParam(request.getSession(), param);
//		
//		int	total	= svc.getListCount(param);
//		
//		model.addAttribute("total", total);
//		model.addAttribute("list", 0 < total ? svc.getFaqList(param) : null);
//		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
//		
//		return "bbs/faq.front";
//	}

}
