package com.softworks.springframework.web.controllers.front;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.backoffice.CodeService;
import com.softworks.springframework.web.services.backoffice.MetaCompanyService;
import com.softworks.springframework.web.services.backoffice.SecurityAssetsService;
import com.softworks.springframework.web.services.front.ApplPiiaItemsService;
import com.softworks.springframework.web.services.front.ApplPiiaResultsService;


@Controller
public class ApplPiiaResultsController extends BaseController{

	@Autowired
	private	ApplPiiaResultsService svc;

	@Autowired
	private	ApplPiiaItemsService applPiiaItemsSvc;

	@Autowired
	private	CodeService			       	 	codeService;

	@Autowired
	private	MetaCompanyService				metaCompanyService;

	/**
	 * 정보시스템 개인정보영향평가 항목 리스트
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/applPiiaResults/fis200/list",method=RequestMethod.POST)
	public String list( final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		model.addAttribute("menuAuth", setBtnAuth(request));

		String search_aply_start_day = Utils.nvl((String)param.get("search_aply_start_day"),"");
		if(!search_aply_start_day.isEmpty()) {
			param.put("search_aply_start_day", search_aply_start_day.replace("-", ""));
		}

		String search_aply_end_day = Utils.nvl((String)param.get("search_aply_end_day"),"");
		if(!search_aply_end_day.isEmpty()) {
			param.put("search_aply_end_day", search_aply_end_day.replace("-", ""));
		}

		param.put("search_word", ((String)param.get("search_word")).trim());

		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("pageSizeChange", svc.getUseCodeList("PAGE_CHANGE"));
		model.addAttribute("companyCdList",svc.getUseCodeList("COMPANY_CD"));//계열사
		model.addAttribute("piiaStateCdList",svc.getUseCodeList("PIIA_STATE_CD"));//진행중

		String search_company_cds =Utils.nvl(param.get("search_company_cds"),"") ;
		if(!search_company_cds.isEmpty()) {
			param.put("exist_company", "Y");
			for (String com : search_company_cds.split(",")) {
				param.put(com, "Y");
			}
		}

		int	total	= svc.getListCount(param);
		model.addAttribute("total", total);
		model.addAttribute("list", 0 < total ? svc.getList(param) : null);
		return "applPiiaResults/applPiiaResultsList.front";
	}

	/**
	 * 개인정보영향평가 - 상세화면(기본정보)
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@Autowired
	private	SecurityAssetsService			securityAssetsService;

	@RequestMapping(value="/front/internal/applPiiaResults/fis200/detail-basic", method=RequestMethod.POST)
	public String detailBasic( final HttpServletRequest request , final ModelMap model) throws Exception {
		Param	param	= new Param(request);
//		String app_no = param.get("app_no");
		List<Param> ifItsMstApplList = securityAssetsService.getIfItsMstApplList(param);
		List<Param> vItsApplCompany = securityAssetsService.getVItsApplCompany(param);
		List<Param> vItsApplTech = securityAssetsService.getVItsApplTech(param);
		List<Param> ifItsMstApplDetailList = securityAssetsService.getIfItsMstApplDetailList(param);
		int ifItsMstApplDetailCount = securityAssetsService.getIfItsMstApplDetailCount(param);
		param.set("info_typ_cd", "B2C");
		Param vItsApplSecurityList_B2C = securityAssetsService.getVItsApplSecurityOne(param);
		param.set("info_typ_cd", "B2B");
		Param vItsApplSecurityList_B2B = securityAssetsService.getVItsApplSecurityOne(param);
		param.set("info_typ_cd", "MEMBER");
		Param vItsApplSecurityList_MEMBER = securityAssetsService.getVItsApplSecurityOne(param);
		param.set("info_typ_cd", "MEMBER_ETC");
		Param vItsApplSecurityList_MEMBER_ETC = securityAssetsService.getVItsApplSecurityOne(param);
		param.set("info_typ_cd", "VISITOR ");
		Param vItsApplSecurityList_VISITOR = securityAssetsService.getVItsApplSecurityOne(param);


		Param codeParam = new Param(request);
		codeParam.set("pcode", "COMPANY_CD");
		List<Param> codeList = codeService.getList(codeParam);

		List<Param> compnayBusiSiteAllList = metaCompanyService.getCompanyBusiSiteAllList(param);

		Param securityAssetsOne = securityAssetsService.getSecurityAssetsOne(param);

		if(securityAssetsOne != null){
			String busi_site_list = securityAssetsOne.get("BUSI_SITE_LIST");
			if(!busi_site_list.isEmpty()){
				Param companyParam = new Param(request);
				List<String>  p_busiSiteList = Arrays.asList(busi_site_list.split(","));
				companyParam.set("busiSiteList", p_busiSiteList);

				List<Param> compnayBusiSiteList = metaCompanyService.getCompanyBusiSiteAllList(companyParam);
				model.addAttribute("compnayBusiSiteList", compnayBusiSiteList);
			}
		}

		model.addAttribute("securityAssetsOne", securityAssetsOne);
		model.addAttribute("CODE_COMPANY_CD", codeList);
		model.addAttribute("compnayBusiSiteAllList", compnayBusiSiteAllList);

		model.addAttribute("ifItsMstApplList", ifItsMstApplList);
		model.addAttribute("vItsApplCompany", vItsApplCompany);
		model.addAttribute("vItsApplTech", vItsApplTech);
		model.addAttribute("ifItsMstApplDetailList", ifItsMstApplDetailList);
		model.addAttribute("ifItsMstApplDetailListCount", ifItsMstApplDetailList.size());
		model.addAttribute("ifItsMstApplDetailCount", ifItsMstApplDetailCount);
		model.addAttribute("b2c", vItsApplSecurityList_B2C);
		model.addAttribute("b2b", vItsApplSecurityList_B2B);
		model.addAttribute("member", vItsApplSecurityList_MEMBER);
		model.addAttribute("member_etc", vItsApplSecurityList_MEMBER_ETC);
		model.addAttribute("visitor", vItsApplSecurityList_VISITOR);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		return "WEB-INF/views/applPiiaResults/applPiiaResultslDetailBasic";
	}

	@RequestMapping(value="/front/internal/applPiiaResults/fis200/detail-result", method=RequestMethod.POST)
	public String detailResult( final HttpServletRequest request , final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		model.addAttribute("menuAuth", setBtnAuth(request));
		model.addAttribute("piiaExclTypCdList",svc.getUseCodeList("PIIA_EXCL_TYP_CD"));//영향평가 제외 사유 유형
		model.addAttribute("wgTypCdList",svc.getUseCodeList("WG_TYP_CD"));//WG_TYP_CD	WG 구분 코드
		model.addAttribute("undeLevelCdList",svc.getUseCodeList("UNDE_LEVEL_CD"));//담당자 이해 수준 코드
		model.addAttribute("encryptItemCdList",svc.getUseCodeList("ENCRYPT_ITEM_CD"));//암호화대상 항목
		model.addAttribute("piiaStateCdList",svc.getUseCodeList("PIIA_STATE_CD"));//진행중
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		Param detail = svc.getDetail(param);
		model.addAttribute("detail", detail);
		model.addAttribute("type", (detail == null)? "I":"U");

		return "WEB-INF/views/applPiiaResults/applPiiaDetailResults";
	}

	/**
	 * 정보시스템 개인정보영향평가 항목 등록
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/applPiiaResults/fis200/detail-result-regist", method=RequestMethod.POST)
	@ResponseBody
	public String detailResultRegist(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();

		try {
			String uid = Utils.nvl((String)session.getAttribute("uid"));
			String uname = Utils.nvl((String)session.getAttribute("uname"));

			Param param = new Param(map);

			String first_end_day= Utils.nvl(param.get("first_end_day").replace("-", ""),"");
			if(!first_end_day.isEmpty()) {
				param.put("first_end_day", first_end_day);
			}
			String second_end_day= Utils.nvl(param.get("second_end_day").replace("-", ""),"");
			if(!second_end_day.isEmpty()) {
				param.put("second_end_day", second_end_day);
			}

			param.set("uid", uid);
			param.set("uname", uname);

			svc.detailResultRegist(param);
			jsonObject.put("result", true);

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}

	@RequestMapping(value="/front/internal/applPiiaResults/fis200/detail-attr", method=RequestMethod.POST)
	public String detailAttr( final HttpServletRequest request , final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		model.addAttribute("menuAuth", setBtnAuth(request));
		model.addAttribute("evalResultCdList",svc.getUseCodeList("EVAL_RESULT_CD"));//평가결과

		HashMap<String, Object>  resultMap =  applPiiaItemsSvc.detailAttr(param);

		List<Param> list = (List<Param>)resultMap.get("list");
		model.addAttribute("list", list);

		List<Param> securityEvalList = (List<Param>)resultMap.get("securityEvalList");
		model.addAttribute("securityEvalList", securityEvalList);

		Param sumCount = (Param)resultMap.get("sumCount");
		model.addAttribute("sumCount", sumCount);

		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		return "WEB-INF/views/applPiiaResults/applPiiaResultsDetailAttr";
	}


	/**
	 * 정보시스템 개인정보영향평가 항목 수정
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/applPiiaResults/fis200/detail-attr-regist", method=RequestMethod.POST)
	@ResponseBody
	public String detailAttrRegist(final HttpServletRequest request, final @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();

		try {
			String uid = Utils.nvl((String)session.getAttribute("uid"));
			String uname = Utils.nvl((String)session.getAttribute("uname"));

			List<?> list =  (List<?>) map.get("list");

			Param param = new Param(map);
			//파라미터 추가
			param.set("uid", uid);
			param.set("uname", uname);

//			//기본정보 첨부파일ID
			applPiiaItemsSvc.detailAttrRegist(param, list);
			jsonObject.put("result", true);

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}



	/**
	 * 정보시스템 개인정보영향평가 항목 삭제
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/applPiiaResults/fis200/delete", method=RequestMethod.POST)
	@ResponseBody
	public String delete(final HttpServletRequest request, final @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();

		try {
			String uid = Utils.nvl((String)session.getAttribute("uid"));
			String uname = Utils.nvl((String)session.getAttribute("uname"));

			Param param = new Param(map);
			//파라미터 추가
			param.set("uid", uid);
			param.set("uname", uname);

			svc.delete(param);
			jsonObject.put("result", true);

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}
}
