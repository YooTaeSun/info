package com.softworks.springframework.web.controllers.front;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.front.SecuManagerDetailService;
import com.softworks.springframework.web.services.front.SecuManagerService;
import com.softworks.springframework.web.services.front.SecurityAuditService;


@Controller
public class SecuManagerController extends BaseController{

	@Autowired
	private	SecuManagerService			svc;

	@Autowired
	private	SecuManagerDetailService secuManagerDetailSvc;

	@Autowired
	private	SecurityAuditService securityauditSvc;

	/**
	 * 보안 담당자 등록
	 * @param request
	 * @param map
	 * @return
	 */ 
	@RequestMapping(value="/front/internal/audit/fis120/regist-manager", method=RequestMethod.POST)
	@ResponseBody
	public String registManager(final HttpServletResponse response, final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("result", false);

		try {
			String uid = Utils.nvl((String)session.getAttribute("uid"));
			String uname = Utils.nvl((String)session.getAttribute("uname"));
			String group = Utils.nvl((String)session.getAttribute("group"));

			Param param = new Param(map);

			//파라미터 추가
			param.set("uid", uid);
			param.set("uname", uname);

			Param detail = svc.getDetail(param);
			String menuAuth = securityauditSvc.getSecurityAudioAuth(uid, group, detail.get("MANAGER_ID"), detail.get("REG_ID"));

			if("NN".equals(menuAuth) || "SN".equals(menuAuth)) {
				response.sendError(403, "페이지 접근권한 없음");
			}else {
				if(param.get("emp_no").equals(uid)) {
					throw new RuntimeException("본인은  추가 할 수 없습니다.");
				}

				svc.registManager(param);
				jsonObject.put("result", true);
			}

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}

	/**
	 * 보안 담당자 상세 리스트(json 요청)
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/audit/fis120/detail-managerlist", method=RequestMethod.POST)
	@ResponseBody
	public String detailManagerList(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();

		try {
			String uid = Utils.nvl((String)session.getAttribute("uid"));
			String uname = Utils.nvl((String)session.getAttribute("uname"));

			Param param = new Param(map);
			param.put("privilege_cd_id", "AUDIT_PRIVILEGE_CD");//AUDIT_PRIVILEGE_CD	감사 권한 구분 코드, AUDIT_STATE_CD	수검/감사 상태 코드
			Param detail = securityauditSvc.getDetail(param);

			if(detail != null) {
				String manager_id = Utils.nvl(detail.get("MANAGER_ID"),"");
				if(!manager_id.isEmpty()) {
					param.put("manager_id", manager_id);
					jsonObject.put("list", secuManagerDetailSvc.getAllList(param));
				}
			}
			jsonObject.put("result", true);

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();

	}


	/**
	 * 보안 담당자 상세 리스트(json 요청)
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/audit/fis120/detail-managerlist/excel", method=RequestMethod.POST)
	public String detailManagerListExcel(final HttpServletRequest request, final ModelMap model) throws Exception {

		Param param = new Param(request);
		String retunStr = Utils.sendMessage(request, "해당 조건에 검색된 내역이 없습니다."
				, "/front/internal/audit/fis120/detail-manager", Utils.base64DecodeHidden(Utils.base64Encode(param.toQueryString())));

		param.put("privilege_cd_id", "AUDIT_PRIVILEGE_CD");//AUDIT_PRIVILEGE_CD	감사 권한 구분 코드, AUDIT_STATE_CD	수검/감사 상태 코드
		Param detail = securityauditSvc.getDetail(param);

		if(detail != null) {

			String manager_id = Utils.nvl(detail.get("MANAGER_ID"),"");
			if(!manager_id.isEmpty()) {
				param.put("manager_id", manager_id);
				param.put("audit_nm", detail.get("AUDIT_NM"));

				int	total	= secuManagerDetailSvc.getListCount(param);
				if(total > 0) {
					svc.getListExcel(param, model);
					retunStr = "excelDownloadView";
				}
			}
		}
        return retunStr;
	}

	/**
	 * 보안 담당자 상세 삭제
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/audit/fis120/delete-manager", method=RequestMethod.POST)
	@ResponseBody
	public  String deleteManager(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();

		try {
			String uid = Utils.nvl((String)session.getAttribute("uid"));
			String uname = Utils.nvl((String)session.getAttribute("uname"));

			Param param = new Param(map);
			//파라미터 추가
			param.set("uid", uid);
			param.set("uname", uname);

			secuManagerDetailSvc.deleteManager(param);
			jsonObject.put("result", true);

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}


	/**
	 * 보안 담당자 상세 삭제
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/audit/fis120/update-privilege-manager", method=RequestMethod.POST)
	@ResponseBody
	public  String updatePrivilegeManager(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();

		try {
			String uid = Utils.nvl((String)session.getAttribute("uid"));
			String uname = Utils.nvl((String)session.getAttribute("uname"));

			Param param = new Param(map);
			//파라미터 추가
			param.set("uid", uid);
			param.set("uname", uname);

			secuManagerDetailSvc.updatePrivilegeManager(param);
			jsonObject.put("result", true);

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}
}
