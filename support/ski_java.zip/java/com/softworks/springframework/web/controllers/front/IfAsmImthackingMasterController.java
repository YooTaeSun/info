package com.softworks.springframework.web.controllers.front;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.CodeLoaderService;
import com.softworks.springframework.web.services.front.IfAsmImthackingMasterService;


@Controller
public class IfAsmImthackingMasterController extends BaseController{

	@Autowired
	private	IfAsmImthackingMasterService svc;

	/**
	 * 모의 해킹 리스트
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/diagnosis/imthacking/list",method=RequestMethod.POST)
	public String list( final HttpServletRequest request, final ModelMap model) throws Exception {

		Param	param	= new Param(request);

		param.put("target_year", Utils.nvl(param.get("target_year"), Utils.getTimeStampString("yyyy")));
		param.put("searchName", Utils.nvl(param.get("searchName").trim(), ""));
		model.addAttribute("detail", svc.getDetailTotal(param));

		int	total = svc.getListCount(param);

		model.addAttribute("total", total);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("list", 0 < total ? svc.getList(param) : null);

		model.addAttribute("pageSizeChange", CodeLoaderService.CODE.get("PAGE_CHANGE"));
		return "diagnosis/imthackingList.front";
	}


	@RequestMapping(value="/front/internal/diagnosis/imthacking/{page}/excel",method=RequestMethod.POST)
	public String detailManagerListExcel(@PathVariable String page, final HttpServletRequest request, final ModelMap model) throws Exception {

		Param param = new Param(request);

		String retunStr = "";

		if("list".equals(page)) {
			retunStr = Utils.sendMessage(request, "해당 조건에 검색된 내역이 없습니다."
					, "/front/internal/diagnosis/imthacking/list", Utils.base64DecodeHidden(Utils.base64Encode(param.toQueryString())));
		}else {
			retunStr = Utils.sendMessage(request, "해당 조건에 검색된 내역이 없습니다."
					, "/front/internal/diagnosis/lawsys/detail", Utils.base64DecodeHidden(Utils.base64Encode(param.toQueryString())));
		}

		String type = Utils.nvl(param.get("type"));
		if(!type.isEmpty()) {
			param.put("asset_class_cd", type);

			if(("SECU").equals(type)) {
				param.put("excelName","보안솔루션 진단 현황");
			}else if(("APPL").equals(type)) {
				param.put("excelName","응용프로그램 진단 현황");
			}
		}

		int	total = svc.getListCount(param);

		if(total > 0) {
			svc.getListExcel(param, model);
			retunStr = "excelDownloadView";
		}

        return retunStr;
	}
}
