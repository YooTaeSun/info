package com.softworks.springframework.web.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.PopupService;

@Controller
public class PopupController extends BaseController {

	@Autowired
	PopupService	svc;

	@RequestMapping(value="/popup/userPopup", method=RequestMethod.POST)
	public String userPopup(final HttpServletRequest request, ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param		param	= new Param(request);
		int			total	= svc.getUserListCount(param);
		
		if(!"Y".equals(Utils.nvl((String)session.getAttribute("isSuper"))))
			param.set("company_id", (String)session.getAttribute("company"));
		else
			param.set("company_id", (String)param.get("company"));
			
		String userType = param.get("utp");
		if(userType != null  ){
			if(userType.equals("1")){
				param.set("group_id", "Manager");
			}else{
				param.set("group_id", "User");
			}
		}
		
		model.addAttribute("total", total);
		model.addAttribute("list", 0 < total ? svc.getUserList(param) : null);
		model.addAttribute("companyList", svc.getCompanyCodeList());
		
		return "WEB-INF/views/popup/user";
	}

	@RequestMapping(value="/popup/sUserPopup", method=RequestMethod.POST)
	public String sUserPopup(final HttpServletRequest request, ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param		param	= new Param(request);
		
		String userType = param.get("utp");

		if (userType != null) {
			if (userType.equals("1")) {
				param.set("group_id", "Manager");
			} else {
				param.set("group_id", "User");
			}
		}

		int	total	= svc.getUserListCount(param);
		
		model.addAttribute("total", total);
		model.addAttribute("list", 0 < total ? svc.getUserList(param) : null);
		
		return "WEB-INF/views/popup/singleUser";
	}

	@RequestMapping(value="/popup/mUserPopup", method=RequestMethod.POST)
	public String mUserPopup(final HttpServletRequest request, ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param		param	= new Param(request);
		
		String userType = param.get("utp");

		if (userType != null) {
			if (userType.equals("1")) {
				param.set("group_id", "Manager");
			} else {
				param.set("group_id", "User");
			}
		}

		int	total	= svc.getUserListCount(param);
		
		model.addAttribute("total", total);
		model.addAttribute("list", 0 < total ? svc.getUserList(param) : null);
		
		return "WEB-INF/views/popup/multiUser";
	}

}
