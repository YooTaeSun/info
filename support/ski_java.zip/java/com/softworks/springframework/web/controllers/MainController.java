package com.softworks.springframework.web.controllers;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.CodeLoaderService;
import com.softworks.springframework.web.services.MainService;
import com.softworks.springframework.web.services.front.BbsFrontService;
//import com.softworks.springframework.web.services.front.InterfaceViewService;
import com.softworks.springframework.web.services.front.MyService;
import com.softworks.springframework.web.services.front.SecuritySystemOperationService;

@Controller
public class MainController extends BaseController {

	@Autowired
	private	MainService	svc;
	
	@Autowired
	private	MyService mySvc;
	
	@Autowired
    private BbsFrontService bbsSvc;
	
	@Autowired
	private	SecuritySystemOperationService			secuSvc;

	@RequestMapping(value="/sendMessage")
	public String sendMessage() {
		return "sendMessage";
	}
	
	@RequestMapping(value="/main")
//	public ModelAndView main(final HttpServletRequest request, final HttpServletResponse response, final ModelMap model) throws Exception {
	public String main(final HttpServletRequest request, final HttpServletResponse response, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	param	= new Param(request);
		param.set("page", 1);
		param.set("main_display_yn", "Y");
		param.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		
		// 보안 letter
		param.set("type", "BBS00001");
		param.set("ntt_auth_cd", Utils.nvl((String)session.getAttribute("regularity_cd")));
		Param bbsMasterInfo = bbsSvc.getBbsMasterInfo(param.get("type"));
		int	total	= bbsSvc.getListCount(param);
		param.set("page", 1);
		param.set("pageSize", total);
		
		model.addAttribute("letterBbsList", 0 < total ? bbsSvc.getList(param) : null);
		model.addAttribute("letterBbsTotal",total);
		model.addAttribute("letterNttTypCd",CodeLoaderService.CODE.get(bbsMasterInfo.get("NTT_TYP_CD_ID")));
		model.addAttribute("letterBbsMasterInfo",bbsMasterInfo);
		
		// 보안 qna 
		param.set("type", "BBS00003");
		param.set("ntt_auth_cd", "");
		bbsMasterInfo = bbsSvc.getBbsMasterInfo(param.get("type"));
		total	= bbsSvc.getListCount(param);
		param.set("page", 1);
		param.set("pageSize", total);
		
		model.addAttribute("qnaBbsList", 0 < total ? bbsSvc.getList(param) : null);
		model.addAttribute("qnaBbsTotal",total);
		model.addAttribute("qnaNttTypCd",CodeLoaderService.CODE.get(bbsMasterInfo.get("NTT_TYP_CD_ID")));
		model.addAttribute("qnaBbsMasterInfo",bbsMasterInfo);
		
		// 보안 자료실
		param.set("type", "BBS00005");
		param.set("ntt_auth_cd", Utils.nvl((String)session.getAttribute("regularity_cd")));
		bbsMasterInfo = bbsSvc.getBbsMasterInfo(param.get("type"));
		total	= bbsSvc.getListCount(param);
		param.set("page", 1);
		param.set("pageSize", total);
		
		model.addAttribute("secuBbsList", 0 < total ? bbsSvc.getList(param) : null);
		model.addAttribute("secuBbsTotal", total);
		model.addAttribute("secuNttTypCd",CodeLoaderService.CODE.get(bbsMasterInfo.get("NTT_TYP_CD_ID")));
		model.addAttribute("secuBbsMasterInfo",bbsMasterInfo);
		
		// 보안예외 정책 신청 / 처리 현황
		param.set("adminIdList", "");
		param.set("mainYn", "Y");
		total =  secuSvc.getExceptPolicyProcStatusListCount(param);
		param.set("page", 1);
		param.set("pageSize", total);
		model.addAttribute("secuSystemTotal", total);
		model.addAttribute("secuSystemList", 0 < total ? secuSvc.getExceptPolicyProcStatusList(param) : null);
		
		// To Do List
		param.set("check_noti_yn", "N");
		total	= svc.getNotiHistCount(param);
		param.set("pageSize", total);
		
		List<Param> notiHistList	= svc.getNotiHist(param);
		model.addAttribute("notiHistTotal", total);
		model.addAttribute("notiHistList", total > 0 ? notiHistList : null);
		
		// site banner
		List<Param> siteBannerList	= svc.getSiteBanner(param);
		total	= siteBannerList.size();
		model.addAttribute("siteBannerTotal", total);
		model.addAttribute("siteBannerList", total > 0 ? siteBannerList : null);
		
		// OA기기 및 SW사용현황
		param.set("uid", Utils.nvl((String)session.getAttribute("uid")));
		List<Param> itsSkeHwSwList	= svc.getItsSkeHwSw(param);
		total	= itsSkeHwSwList.size();
		model.addAttribute("itsSkeHwSwTotal", total);
		model.addAttribute("itsSkeHwSwList", total > 0 ? itsSkeHwSwList : null);
 
		return "main.front";
	}
	
//	@RequestMapping(value="/backoffice/main")
//	public ModelAndView backofficeMain(final HttpServletRequest request, final HttpServletResponse response, final ModelMap model) {
//		return new ModelAndView("main.backoffice", model);
//	}
	@RequestMapping(value="/backoffice/main")
	public String backoffice(final HttpServletRequest request) {
		return "redirect:/backoffice/bbs/BBS00001/list";

	}
	
	@RequestMapping(value="/companyDepartment", method=RequestMethod.POST)
	public @ResponseBody String getCustomerDepartment(final HttpServletRequest request) throws Exception {
		Param			param	= new Param(request);
		List<Param> 	list	= mySvc.getCustomerDepartment(param);
		StringBuilder	json	= new StringBuilder();
		
		json.append("{")
				.append("\"result\":").append(0 < list.size() ? true : false).append(",")
				.append("\"list\":").append(Utils.getListJSON(list))
			.append("}");
		
		return json.toString();
	}
	
	@RequestMapping(value="/attach/download/{type}/{seq}/{num}", method=RequestMethod.POST)
	public String attachDownload(@PathVariable("type") final String type,
								 @PathVariable("seq") final int seq,
								 @PathVariable("num") final String num,
								 final HttpServletRequest request, final ModelMap model) throws Exception {
		try {
			//File	file	= new File(request.getServletContext().getRealPath(filePath + Property.getProperty("file.board") + "/" + type), seq + "_attach_" + num);
			//File	file	= new File(filePath + Property.getProperty("file.board") + File.separator + type, seq + "_attach_" + num); //보안점검
			File	file	= new File(filePath + "/board/" + File.separator + type, seq + "_attach_" + num);

			if(file.exists()) {
				model.addAttribute("file", file);
				model.addAttribute("filename", svc.getAttachFileName(type, num, seq));
				
				return "fileDownloadView";
			} else
				logger.info("게시판 첨부파일 다운로드 경고 : '찾으시는 파일이 존재하지 않습니다.'");
		} catch(Exception e) {
			logger.error("게시판 첨부파일 다운로드 오류", e);
		}
		
		return Utils.sendMessage(request, "찾으시는 파일이 존재하지 않습니다.", "about:blank");
	}
	
	@RequestMapping(value="/attach/download2/")
	public String attachDownload2( final HttpServletRequest request, final ModelMap model) throws Exception {
		try {
			java.io.File	file	= new java.io.File( "\\\\192.168.0.100\\result\\2013-04-25\\test.txt");
			logger.debug("===============================================================================================");
			logger.debug(file);
			logger.debug("===============================================================================================");
			
			if(file.exists()) {
				model.addAttribute("file", file);				
				model.addAttribute("filename", "test.txt");
				return "fileDownloadView";
			} else
				logger.info("첨부파일 다운로드 경고 : '찾으시는 파일이 존재하지 않습니다.'");
		} catch(Exception e) {
			logger.error("첨부파일 다운로드 오류", e);
		}
		
		return Utils.sendMessage(request, "찾으시는 파일이 존재하지 않습니다.", "localhost:8081");
	}
	
	@RequestMapping(value="/attach/downloadPost", method=RequestMethod.POST)
	public String attachDownloadPost( final HttpServletRequest request, final ModelMap model) throws Exception {
		Param param	= new Param(request);
		try {
			java.io.File	file	= new java.io.File(param.getString("filePath") + param.getString("fileName"));
			logger.debug("===============================================================================================");
			logger.debug(file);
			logger.debug("===============================================================================================");
			
			if(file.exists()) {
				model.addAttribute("file", file);				
				model.addAttribute("filename", param.getString("dwName"));
				return "fileDownloadView";
			} else
				logger.info("첨부파일 다운로드 경고 : '찾으시는 파일이 존재하지 않습니다.'");
		} catch(Exception e) {
			logger.error("첨부파일 다운로드 오류", e);
		}
		
		return Utils.sendMessage(request, "찾으시는 파일이 존재하지 않습니다.", "localhost:8081");
	}

	/**
	 * 알림 목록 조회
	 * @param request
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/noti/list", method=RequestMethod.POST)
	public  String getNotiList(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {
		
		HttpSession	session	= request.getSession();
		Param param	= new Param(map);
		JSONObject jsonObject = new JSONObject();
		
		param.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		
		try {
			
			int total	= svc.getNotiHistCount(param);
			List<Param> notiList = svc.getNotiHist(param);
			
			jsonObject.put("total", total);
			jsonObject.put("notiList", Utils.getListJSON(notiList).toString());
			jsonObject.put("param", param);
			jsonObject.put("result", true);
			
		} catch(Exception e) {
			
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}
	
	/**
	 * 알림 미확인 목록 조회
	 * @param request
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/noti/noCheckList", method=RequestMethod.POST)
	public  String getNoCheckNotiList(final HttpServletRequest request) {
		HttpSession	session	= request.getSession();
		Param param	= new Param();
		JSONObject jsonObject = new JSONObject();
		param.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		try {
			param.set("check_noti_yn", "N");
			int noCheckNotiTotal	= svc.getNotiHistCount(param);
			param.set("page", 1);
			param.set("pageSize", noCheckNotiTotal);
			List<Param> noChecNotiHistList	= svc.getNotiHist(param);
			
			jsonObject.put("noChecNotiHistList", Utils.getListJSON(noChecNotiHistList).toString());
			jsonObject.put("noCheckNotiTotal", noCheckNotiTotal);
			jsonObject.put("result", true);
			
		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}
	
	/**
	 * 알림 미확인 목록 조회
	 * @param request
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/noti/chkNoti", method=RequestMethod.POST)
	public  String chkNoti(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {
		HttpSession	session	= request.getSession();
		Param param	= new Param(map);
		JSONObject jsonObject = new JSONObject();
		param.set("uid", Utils.nvl((String)session.getAttribute("uid")));
		param.set("uname", Utils.nvl((String)session.getAttribute("uname")));
		try {
			String noti_seq = param.get("noti_seq");
			if(noti_seq.equals("all")){
				svc.chkNotiAll(param);
			}else{
				svc.chkNoti(param);
			}
			jsonObject.put("result", true);
		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}
	
	/**
	 * 결재 내역 목록 조회
	 * @param request
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/apprv/list", method=RequestMethod.POST)
	public  String getApprvList(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {
		
		HttpSession	session	= request.getSession();
		Param param	= new Param(map);
		JSONObject jsonObject = new JSONObject();
		
		param.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		
		try {
			
			int total	= svc.getApprvListCount(param);
			List<Param> apprvList = svc.getApprvList(param);
			
			jsonObject.put("total", total);
			jsonObject.put("apprvList", Utils.getListJSON(apprvList).toString());
			jsonObject.put("param", param);
			jsonObject.put("result", true);
			
		} catch(Exception e) {
			
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}
	
	/**
	 * 결재 내역 상세 조회
	 * @param request
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/apprv/info", method=RequestMethod.POST)
	public  String getApprvDocInfo(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {
		
		HttpSession	session	= request.getSession();
		Param param	= new Param(map);
		JSONObject jsonObject = new JSONObject();
		param.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		try {
			
			Param apprvInfo = svc.getApprvDocInfo(param);
			String contents = apprvInfo.get("CONTENTS");
			
			jsonObject.put("contents", contents == null ? null : contents);
			jsonObject.put("param", param);
			jsonObject.put("result", true);
			
		} catch(Exception e) {
			
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}
}


