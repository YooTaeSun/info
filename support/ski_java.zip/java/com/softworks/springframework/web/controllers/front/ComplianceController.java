package com.softworks.springframework.web.controllers.front;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.MailSendService;
import com.softworks.springframework.web.services.CodeLoaderService.CodeInfo;
import com.softworks.springframework.web.services.backoffice.CodeService;
import com.softworks.springframework.web.services.backoffice.MetaCheckService;
import com.softworks.springframework.web.services.backoffice.MetaCompanyService;
import com.softworks.springframework.web.services.backoffice.MetaLawService;
import com.softworks.springframework.web.services.backoffice.MetaMappingService;
import com.softworks.springframework.web.services.backoffice.MetaSecurityService;
import com.softworks.springframework.web.services.front.ComplianceService;
import com.softworks.springframework.web.services.front.MonitoringService;
import com.softworks.springframework.web.services.front.SecuManagerDetailService;


@Controller
public class ComplianceController extends BaseController{
	
	@Autowired
	private	CodeService			        codeService;
	
	@Autowired
	private	MetaCheckService			metaCheckService;
	
	@Autowired
	private	MetaSecurityService			metaSecurityService;
	
	@Autowired
	private	MetaLawService			    metaLawService;
	
	@Autowired
	private	MetaMappingService			metaMappingService;
	
	@Autowired
	private	ComplianceService			complianceService;
	
	@Autowired
	private	SecuManagerDetailService	secuManagerDetailService;
	
	@Autowired
	private MailSendService				mailSendService ;
	
	@Autowired
	private	MetaCompanyService			metaCompanyService;
	
	
	/**
	 * 진단영역별 체크리스트 화면
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/compliance/fis100/list", method=RequestMethod.POST)
	public String list100( final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		String regId = Utils.nvl((String)session.getAttribute("uid"));
		String group = Utils.nvl((String)session.getAttribute("group"));
		
		Param	param	= new Param(request);
//		param.set("pcode", "SUB_AREA_CD");
		if(param.get("code") == null || param.get("code").equals("")){
			param.set("code", "A");
		}
		
		String levelSub_arr = Utils.nvl(param.get("levelSub_arr"));
		String[] levelSub_arr2 = null;
		if(!levelSub_arr.equals("")){
			levelSub_arr2 = levelSub_arr.split("\\,");
		}
		
		String subAreaCd_arr = Utils.nvl(param.get("subAreaCd_arr"));
		String[] subAreaCd_arr2 = null;
		if(!subAreaCd_arr.equals("")){
			subAreaCd_arr2 = subAreaCd_arr.split("\\,");
		}
		
		String checkEvalCd = Utils.nvl(param.get("checkEvalCd"));
		String evalCd1 = Utils.nvl(param.get("evalCd1"));
		String evalCd2 = Utils.nvl(param.get("evalCd2"));
		String mng_org_cd = Utils.nvl(param.get("mng_org_cd"));
		String mng_org_cd1 = Utils.nvl(param.get("mng_org_cd1"));
		String manager_nm = Utils.nvl(param.get("manager_nm"));
		String manager_nm1 = Utils.nvl(param.get("manager_nm1"));
		String checklist_nm = Utils.nvl(param.get("checklist_nm"));
		String checklist_nm1 = Utils.nvl(param.get("checklist_nm1"));
		
		Param searchParam = new Param();
		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		int nYear = calendar.get(Calendar.YEAR);
		searchParam.set("year", nYear);
		searchParam.set("code", param.get("code"));
		searchParam.set("levelSub_arr", levelSub_arr2);
		searchParam.set("subAreaCd_arr", subAreaCd_arr2);
		if("true".equals(checkEvalCd)){
			searchParam.set(evalCd1, evalCd2);
		}
		if("true".equals(mng_org_cd)){
			searchParam.set("mng_org_cd", mng_org_cd1);
		}
		if("true".equals(manager_nm)){
			
			Param managerParam = new Param();
			managerParam.set("privilege_cd_id", "CHKLIST_PRIVILEGE_CD");
			managerParam.set("manager_nm", manager_nm1);
			
			if(!"PortalAdmin".equals(group)){
				managerParam.set("emp_no", regId);
			}
			List<Param> managerList = secuManagerDetailService.getAllList(managerParam);
			ArrayList<String> manager_id_arr = new ArrayList<String>();
			for(Param managerOne :  managerList){
				String manager_id = managerOne.get("MANAGER_ID");
				manager_id_arr.add(manager_id);
			}
			if(managerList.size() == 0){
				String manager_id = "00000000000000000000";//임의값 설정(검색된 값이 없을경우 데이터가 나오지 않아야한다)
				manager_id_arr.add(manager_id);
			}
			searchParam.set("manager_check", "true");
			searchParam.set("manager_id_arr", manager_id_arr);
		}else{
			
			if(!"PortalAdmin".equals(group)){
				Param managerParam = new Param();
				managerParam.set("privilege_cd_id", "CHKLIST_PRIVILEGE_CD");
				managerParam.set("emp_no", regId);
				List<Param> managerList = secuManagerDetailService.getAllList(managerParam);
				ArrayList<String> manager_id_arr = new ArrayList<String>();
				for(Param managerOne :  managerList){
					String manager_id = managerOne.get("MANAGER_ID");
					manager_id_arr.add(manager_id);
				}
				if(managerList.size() == 0){
					String manager_id = "00000000000000000000";//임의값 설정(검색된 값이 없을경우 데이터가 나오지 않아야한다)
					manager_id_arr.add(manager_id);
				}
				searchParam.set("manager_check", "true");
				searchParam.set("manager_id_arr", manager_id_arr);
			}else{
				searchParam.set("manager_check", "");
			}
			
		}
		if("true".equals(checklist_nm)){
			searchParam.set("checklist_nm", checklist_nm1);
		}
		
		// get icon
		List<CodeInfo> icon = complianceService.getUseCodeList("SECU_LEVEL_ICON");
		Param iconParam = new Param();
		for (CodeInfo codeInfo : icon) {
			iconParam.set(codeInfo.getCode(),codeInfo.getName());
		}
		searchParam.set("iconParam", iconParam);
		model.addAttribute("iconParam", iconParam);
		
		int	total	= complianceService.getCheckListCount(searchParam);
		
		List<Param> checkList = complianceService.getCheckList(searchParam);
		
		List<Param> avgLevelSubList = complianceService.getAreaCdAvgLevelSubList(searchParam);
		
		model.addAttribute("total", total);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("codeList", codeService.getCodeList(param));
		model.addAttribute("checkList",checkList);
		model.addAttribute("avgLevelSubList",avgLevelSubList);
		model.addAttribute("MAIN_AREA_CD",complianceService.getUseCodeList("MAIN_AREA_CD"));
		model.addAttribute("MAIN_AREA_CD_AVG_LEVEL",complianceService.getAreaCdAvgLevelList(searchParam));
		model.addAttribute("CODE_MNG_ORG_CD",complianceService.getUseCodeList("MNG_ORG_CD"));
		model.addAttribute("GOAL_LEVEL_CD",complianceService.getUseCodeList("GOAL_LEVEL_CD"));
		model.addAttribute("SELECT_CODE",param.get("code"));
		
		
		return "compliance/list.front";
	}
	
	/**
	 * 진단영역별 체크리스트 화면 - 목표수준변경
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/compliance/fis100/change", method=RequestMethod.POST)
	public String change100(final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	    param	= new Param(request);
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		String	hiddenQuery	= null;
		String  msg = "";
		
		try{
			
			complianceService.updateSecurityChecklistArr(param);
			msg = "변경하였습니다";
			
			model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
			return Utils.sendMessage(request, msg, "/front/internal/compliance/fis100/list", hiddenQuery);
		} catch(Exception e) {
			logger.error("변경중 에러", e);
		}
		return Utils.sendMessage(request, "변경중 오류가 발생 했습니다.");
	}
	
	/**
	 * 진단영역별 체크리스트 화면 - 엑셀저장
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/compliance/fis100/list/excel", method=RequestMethod.POST)
	public String excel100(final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		String regId = Utils.nvl((String)session.getAttribute("uid"));
		String group = Utils.nvl((String)session.getAttribute("group"));
		Param param = new Param(request);
//		param.set("code", param.get("code"));
		
		Calendar calendar = new GregorianCalendar(Locale.KOREA);
		int nYear = calendar.get(Calendar.YEAR);
		param.set("year", nYear);
		
		if(!"PortalAdmin".equals(group)){
			Param managerParam = new Param();
			managerParam.set("privilege_cd_id", "CHKLIST_PRIVILEGE_CD");
			managerParam.set("emp_no", regId);
			List<Param> managerList = secuManagerDetailService.getAllList(managerParam);
			ArrayList<String> manager_id_arr = new ArrayList<String>();
			for(Param managerOne :  managerList){
				String manager_id = managerOne.get("MANAGER_ID");
				manager_id_arr.add(manager_id);
			}
			if(managerList.size() == 0){
				String manager_id = "00000000000000000000";//임의값 설정(검색된 값이 없을경우 데이터가 나오지 않아야한다)
				manager_id_arr.add(manager_id);
			}
			param.set("manager_check", "true");
			param.set("manager_id_arr", manager_id_arr);
		}else{
			param.set("manager_check", "");
		}

		int	total	= complianceService.getCheckListCount(param);
        
        String retunStr = Utils.sendMessage(request, "해당 조건에 검색된 내역이 없습니다.", "/front/internal/compliance/fis100/list"
                , Utils.base64DecodeHidden(Utils.base64Encode(param.toQueryString())));
        
        if(total > 0) {
        	
            retunStr = "excelDownloadView";
            complianceService.getListExcel100(param, model);
        }
        
        return retunStr;
	}
	
	/**
	 * 법/제도별 체크리스트 화면
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/compliance/fis102/list", method=RequestMethod.POST)
	public String list102( final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		String regId = Utils.nvl((String)session.getAttribute("uid"));
		String group = Utils.nvl((String)session.getAttribute("group"));
		
		Param	param	= new Param(request);
		String selectCodeLaw = "";
		
		List<Param> lawList= metaLawService.getLawSystemAllList(param);
		if(param.get("selectCodeLaw") == null || param.get("selectCodeLaw").equals("")){
			if(lawList.size() != 0){
				selectCodeLaw = lawList.get(0).get("LS_ID");
			}
		}else{
			 selectCodeLaw = param.get("selectCodeLaw");
		}
		param.set("ls_id", selectCodeLaw);
		
		String checkEvalCd = Utils.nvl(param.get("checkEvalCd"));
		String evalCd1 = Utils.nvl(param.get("evalCd1"));
		String evalCd2 = Utils.nvl(param.get("evalCd2"));
		
		Param searchParam = new Param();
		searchParam.set("ls_id", param.get("ls_id"));
		searchParam.set("search_value", param.get("search_value"));
		if("true".equals(checkEvalCd)){
			searchParam.set(evalCd1, evalCd2);
		}
		
		if(!"PortalAdmin".equals(group)){
			Param managerParam = new Param();
			managerParam.set("privilege_cd_id", "CHKLIST_PRIVILEGE_CD");
			managerParam.set("emp_no", regId);
			List<Param> managerList = secuManagerDetailService.getAllList(managerParam);
			ArrayList<String> manager_id_arr = new ArrayList<String>();
			for(Param managerOne :  managerList){
				String manager_id = managerOne.get("MANAGER_ID");
				manager_id_arr.add(manager_id);
			}
			if(managerList.size() == 0){
				String manager_id = "00000000000000000000";//임의값 설정(검색된 값이 없을경우 데이터가 나오지 않아야한다)
				manager_id_arr.add(manager_id);
			}
			searchParam.set("manager_check", "true");
			searchParam.set("manager_id_arr", manager_id_arr);
		}else{
			searchParam.set("manager_check", "");
		}
		
		int	total	= complianceService.getLawCheckListCount(searchParam);
		
		model.addAttribute("total", total);
		model.addAttribute("checkList", complianceService.getLawCheckList(searchParam));
		model.addAttribute("lawcheckList", metaLawService.getLawSystemCheckList(searchParam));
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("lawList", lawList);
		model.addAttribute("selectCodeLaw",selectCodeLaw);
		
		return "compliance/lawList.front";
	}
	
	/**
	 * 법/제도별 체크리스트 화면 - 엑셀저장
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/compliance/fis102/list/excel", method=RequestMethod.POST)
	public String excel102(final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		String regId = Utils.nvl((String)session.getAttribute("uid"));
		String group = Utils.nvl((String)session.getAttribute("group"));
		
		Param	param	= new Param(request);
		String selectCodeLaw = "";
		
		List<Param> lawList= metaLawService.getLawSystemAllList(param);
		if(param.get("selectCodeLaw") == null || param.get("selectCodeLaw").equals("")){
			if(lawList.size() != 0){
				selectCodeLaw = lawList.get(0).get("LS_ID");
			}
		}else{
			 selectCodeLaw = param.get("selectCodeLaw");
		}
		param.set("ls_id", selectCodeLaw);
		
		Param LawSystemOne = metaLawService.getLawSystemOne(param);
		
		param.set("LS_ABBR_NM", LawSystemOne.get("LS_ABBR_NM"));
		
		if(!"PortalAdmin".equals(group)){
			Param managerParam = new Param();
			managerParam.set("privilege_cd_id", "CHKLIST_PRIVILEGE_CD");
			managerParam.set("emp_no", regId);
			List<Param> managerList = secuManagerDetailService.getAllList(managerParam);
			ArrayList<String> manager_id_arr = new ArrayList<String>();
			for(Param managerOne :  managerList){
				String manager_id = managerOne.get("MANAGER_ID");
				manager_id_arr.add(manager_id);
			}
			if(managerList.size() == 0){
				String manager_id = "00000000000000000000";//임의값 설정(검색된 값이 없을경우 데이터가 나오지 않아야한다)
				manager_id_arr.add(manager_id);
			}
			param.set("manager_check", "true");
			param.set("manager_id_arr", manager_id_arr);
		}else{
			param.set("manager_check", "");
		}

		int	total	= complianceService.getLawCheckListCount(param);
        
        String retunStr = Utils.sendMessage(request, "해당 조건에 검색된 내역이 없습니다.", "/front/internal/compliance/fis102/list"
                , Utils.base64DecodeHidden(Utils.base64Encode(param.toQueryString())));
        
        if(total > 0) {
        	
            retunStr = "excelDownloadView";
            complianceService.getListExcel102(param, model);
        }
        
        return retunStr;
	}
	
	/**
	 * 상세화면(기본정보)
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/compliance/fis103", method=RequestMethod.POST)
	public String form1( final HttpServletRequest request
			               , final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		Param	param2	= new Param(request);
		HttpSession	session	= request.getSession();
		String group = Utils.nvl((String)session.getAttribute("group"));
		
		Param detailCheckList = metaSecurityService.getCheckListOne(param);
		
		param2.set("chk_item_cd", detailCheckList.get("CHK_ITEM_CD"));
		Param detailCheckItem = metaCheckService.getCheckItemOne(param2);
		List<Param> relatedLawsListMapping = metaMappingService.getCheckListRelatedLawsMappingList(param2);
		List<Param> relatedLawsListMappingGroup = metaMappingService.getCheckListRelatedLawsMappingGroupList(param2);
		
		Param	securityDetailCheckList = complianceService.getCheckListOne(param);
		//첨부파일 ID
		if(securityDetailCheckList.get("ATCH_FILE_ID").isEmpty()) {
			complianceService.updateFileId(param);
//			String atch_file_id = complianceService.updateFileId(param);
//			model.addAttribute("atch_file_id", atch_file_id);
		}
		
		List<CodeInfo> notiDateList = metaSecurityService.getUseCodeList("NOTI_DATE");
		List<CodeInfo> yearCode    = new ArrayList();
		List<CodeInfo> halfCode    = new ArrayList();
		List<CodeInfo> quarterCode = new ArrayList();
		for(CodeInfo oldCode : notiDateList){
			if(oldCode.getCode().equals("YEAR")){
				yearCode.add(oldCode);
			}
			if(oldCode.getCode().equals("F_HALF") || oldCode.getCode().equals("S_HALF")){
				halfCode.add(oldCode);
			}
			if(oldCode.getCode().equals("1QUATER") || oldCode.getCode().equals("2QUATER") || oldCode.getCode().equals("3QUATER") || oldCode.getCode().equals("4QUATER")){
				quarterCode.add(oldCode);
			}
		}
		model.addAttribute("CODE_NOTI_DATE_YEAR",yearCode);
		model.addAttribute("CODE_NOTI_DATE_HALF",halfCode);
		model.addAttribute("CODE_NOTI_DATE_QUARTER",quarterCode);
		
		model.addAttribute("group", group);
		model.addAttribute("detailCheckList", detailCheckList);
		model.addAttribute("detailCheckItem", detailCheckItem);
		model.addAttribute("relatedLawsListMappingGroup", relatedLawsListMappingGroup);
		model.addAttribute("relatedLawsListMapping", relatedLawsListMapping);
		model.addAttribute("relatedLawsListMappingSize", relatedLawsListMapping.size());
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));

		return "WEB-INF/views/compliance/formBasic";
	}
	
	/**
	 * 상세화면(담당자)
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/compliance/fis104", method=RequestMethod.POST)
	public String form2( final HttpServletRequest request
			               , final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		HttpSession	session	= request.getSession();
		String regId = Utils.nvl((String)session.getAttribute("uid"));
		String group = Utils.nvl((String)session.getAttribute("group"));

		List<Param>	getComplianceManagerList = complianceService.getComplianceManagerService(param);
		
		String managerAuth = "false";
		if(!"PortalAdmin".equals(group)){
			for(Param temp : getComplianceManagerList){
				String emp_no = temp.get("EMP_NO");
				String privilege_cd = temp.get("PRIVILEGE_CD");
				if(regId.equals(emp_no)){
					if(privilege_cd.equals("M") || privilege_cd.equals("D") ){
						managerAuth = "true";
					}
				}
			}
		}else{
			managerAuth = "true";
		}
		model.addAttribute("managerAuth", managerAuth);
		model.addAttribute("group", group);
		
		model.addAttribute("CHKLIST_PRIVILEGE_CD",complianceService.getUseCodeList("CHKLIST_PRIVILEGE_CD"));
		model.addAttribute("EMAIL_YN",complianceService.getUseCodeList("EMAIL_YN"));

		model.addAttribute("getComplianceManagerList", getComplianceManagerList);
		model.addAttribute("getComplianceManagerListSize", getComplianceManagerList.size());
		
		//권한체크
//		HttpSession	session	= request.getSession();
		Param authParam = new Param();
		authParam.set("menu_id", request.getAttribute("currentMenuId"));
		authParam.set("group_id", Utils.nvl((String)session.getAttribute("group")));
		authParam.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		String menuAuth = complianceService.getUserMenuAuth(authParam);
		model.addAttribute("menuAuth", menuAuth);
		
		return "WEB-INF/views/compliance/formManager";
	}
	
	/**
	 * 상세화면(담당자) - 등록
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/compliance/fis104/regist", method=RequestMethod.POST)
	public String insert104(final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	    param	= new Param(request);
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("uid", Utils.nvl((String)session.getAttribute("uid")));
		param.set("uname", Utils.nvl((String)session.getAttribute("uname")));
		String	hiddenQuery	= null;
		String  msg = "";
		
		try{
			
			int resultCode = complianceService.insertSecurityChecklistManager(param);
			
			//업무 담당자 추가시 권한 추가
			String user_id = param.get("emp_no");
			String privilegeCd = Utils.nvl(param.get("privilege_cd"),"");// D,M
			secuManagerDetailService.addAuthMenu(user_id, "CHKLIST","SH");//보안수검/감사(AUDIT), 증정(CHKLIST), privilegeCd C:조회, U:업무
			
			Param	checkListOne = complianceService.getCheckListOne(param);
			
			//메일서비스
			String recv_emp_no = param.get("emp_no");
			Param contentReplaceParam = new Param();
			contentReplaceParam.set("#CHECKLIST_NM#", checkListOne.get("CHECKLIST_NM"));
			contentReplaceParam.set("#CHECKLIST_ID#", checkListOne.get("CHECKLIST_ID"));
//			Param mailRtnParam = mailSendService.sendMail2("EM02", recv_emp_no, contentReplaceParam);
			
			String noti_id = "C02";
			String schd_id = "C02";
			Param mailRtnParam = mailSendService.setNotiHist(noti_id, recv_emp_no, "Y", schd_id, contentReplaceParam);
			
			if(0 == resultCode){
				msg = "저장하였습니다";
			}else if(1 == resultCode){
				msg = "이미 추가된 사용자 입니다.";
			}else if(2 == resultCode){
				msg = "책임자, 관리자는 각각 1명만 등록가능합니다.";
			}
			
			model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
			hiddenQuery	= "<input type='hidden' name='checklist_id' value='" + param.get("checklist_id") + "' />";	
			return Utils.sendMessage(request, msg, "/front/internal/compliance/fis104", hiddenQuery);
		} catch(Exception e) {
			logger.error("저장중 에러", e);
		}
		return Utils.sendMessage(request, "저장중 오류가 발생 했습니다.");

	}
	
	/**
	 * 상세화면(담당자) - 삭제
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/compliance/fis104/delete", method=RequestMethod.POST)
	public String delete104(final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	    param	= new Param(request);
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		String	hiddenQuery	= null;
		String  msg = "";
		
		try{
			String emp_no = param.get("emp_no");
			
			int resultCode = complianceService.deleteSecurityChecklistManager(param);
			
			//업무 담당자 추가시 권한 삭제
			Param param01 = new Param();
			param01.put("emp_no", emp_no);
			param01.put("privilege_cd_id", "CHKLIST_PRIVILEGE_CD");//AUDIT_PRIVILEGE_CD, CHKLIST_PRIVILEGE_CD
//			param01.put("privilegeCdList", Arrays.asList("P", "R"));

			List<Param> list = secuManagerDetailService.getAllList(param01);

			if(list != null && list.size() == 0) {
				secuManagerDetailService.revmoeAuthMenu(emp_no, "CHKLIST");// searchType (AUDIT , CHKLIST)
			}
			
			Param	checkListOne = complianceService.getCheckListOne(param);
			
			//메일서비스
			String recv_emp_no = param.get("emp_no");
			Param contentReplaceParam = new Param();
			contentReplaceParam.set("#CHECKLIST_NM#", checkListOne.get("CHECKLIST_NM"));
			contentReplaceParam.set("#CHECKLIST_ID#", checkListOne.get("CHECKLIST_ID"));
//			Param mailRtnParam = mailSendService.sendMail2("EM03", recv_emp_no, contentReplaceParam);
			
			String noti_id = "C03";
			String schd_id = "C03";
			Param mailRtnParam = mailSendService.setNotiHist(noti_id, recv_emp_no, "Y", schd_id, contentReplaceParam);
			
			if(0 == resultCode){
				msg = "삭제하였습니다";
			}
			
			model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
			hiddenQuery	= "<input type='hidden' name='checklist_id' value='" + param.get("checklist_id") + "' />";	
			return Utils.sendMessage(request, msg, "/front/internal/compliance/fis104", hiddenQuery);
		} catch(Exception e) {
			logger.error("저장중 에러", e);
		}
		return Utils.sendMessage(request, "저장중 오류가 발생 했습니다.");

	}
	
	/**
	 * 상세화면(증빙자료/평가관리)
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/compliance/fis105", method=RequestMethod.POST)
	public String form3( final HttpServletRequest request
			               , final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		HttpSession	session	= request.getSession();
		String regId = Utils.nvl((String)session.getAttribute("uid"));
		String group = Utils.nvl((String)session.getAttribute("group"));
		
//		String checklist_yyyy = Utils.nvl(param.get("checklist_yyyy"));
//		if("".equals(checklist_yyyy)){
//			Calendar calendar = new GregorianCalendar(Locale.KOREA);
//			int nYear = calendar.get(Calendar.YEAR);
//			param.set("checklist_yyyy", String.valueOf(nYear));
//		}
		List<Param>	getComplianceManagerList = complianceService.getComplianceManagerService(param);
		
		String managerAuth = "false";
		if(!"PortalAdmin".equals(group)){
			for(Param temp : getComplianceManagerList){
				String emp_no = temp.get("EMP_NO");
				String privilege_cd = temp.get("PRIVILEGE_CD");
				if(regId.equals(emp_no)){
					if(privilege_cd.equals("M") || privilege_cd.equals("D") ){
						managerAuth = "true";
					}
				}
			}
		}else{
			managerAuth = "true";
		}
		model.addAttribute("managerAuth", managerAuth);
		model.addAttribute("group", group);
		
//		param2.set("chk_item_cd", detailCheckList.get("CHK_ITEM_CD"));
		Param metaDetailCheckList = metaSecurityService.getCheckListOne(param);
		
		Param	detailCheckList = complianceService.getCheckListOne(param);
		List<Param>	checkListAllList = complianceService.getCheckListAllList(param);
		model.addAttribute("checkListAllList", checkListAllList);
		
		Param codeParam = new Param(request);
		codeParam.set("pcode", "COMPANY_CD");
		List<Param> codeList = codeService.getList(codeParam);
		
		List<Param> compnayBusiSiteAllList = metaCompanyService.getCompanyBusiSiteAllList(param);
		
		model.addAttribute("CODE_COMPANY_CD", codeList);
		model.addAttribute("compnayBusiSiteAllList", compnayBusiSiteAllList);
		model.addAttribute("metaDetailCheckList",metaDetailCheckList);
		model.addAttribute("detailCheckList",detailCheckList);
		model.addAttribute("EVAL_CD",complianceService.getUseCodeList("EVAL_CD"));
		model.addAttribute("PROC_RESULT_CD",complianceService.getUseCodeList("PROC_RESULT_CD"));
		
		//권한체크
//		HttpSession	session	= request.getSession();
		Param authParam = new Param();
		authParam.set("menu_id", request.getAttribute("currentMenuId"));
		authParam.set("group_id", Utils.nvl((String)session.getAttribute("group")));
		authParam.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		String menuAuth = complianceService.getUserMenuAuth(authParam);
		model.addAttribute("menuAuth", menuAuth);

		return "WEB-INF/views/compliance/formProff";
	}
	
	/**
	 * 상세화면(증빙자료/평가관리) - 수정
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/compliance/fis105/update", method=RequestMethod.POST)
	public String update105(final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	    param	= new Param(request);
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		String	hiddenQuery	= null;
		String  msg = "";
		
		try{
			
			String proc_start_day = param.get("proc_start_day").replace("-", "");
			param.set("proc_start_day", proc_start_day);
			
			String proc_end_day = param.get("proc_end_day").replace("-", "");
			param.set("proc_end_day", proc_end_day);
			
			complianceService.updateSecurityChecklist(param);
			msg = "저장하였습니다";
			
			model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
			hiddenQuery	= "<input type='hidden' name='checklist_id' value='" + param.get("checklist_id") + "' />";	
			return Utils.sendMessage(request, msg, "/front/internal/compliance/fis105", hiddenQuery);
		} catch(Exception e) {
			logger.error("저장중 에러", e);
		}
		return Utils.sendMessage(request, "저장중 오류가 발생 했습니다.");
	}
	
	/**
	 * 상세화면(증빙자료/평가관리) - 부서 평가 적용
	 * @param request
	 * @param param
	 * @return
	 */
	@RequestMapping(value="/front/internal/compliance/fis105/change", method=RequestMethod.POST)
	@ResponseBody
	public  String change105(final HttpServletRequest request, @RequestBody Param param) {
		
		HttpSession	    session	= request.getSession();
		StringBuilder	json	= new StringBuilder();
		String          msg     = "";
		
		try {
			param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
			param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
			param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
			param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		
			complianceService.updateSecurityChecklist1(param);

			json.append("{")
				.append("\"result\":").append(true).append(",")
				.append("\"msg\":").append("\"").append(msg).append("\"")
				.append("}");
			
		} catch(Exception e) {
			logger.error("진단항목 등록중 에러", e);
			
			json.append("{")
			.append("\"result\"").append(":").append(false);
			json.append("}");
		}
		
		return json.toString();
	}
	
	/**
	 * 상세화면(증빙자료/평가관리) - 파일등록 성공시 파일최종등록일 수정
	 * @param request
	 * @param param
	 * @return
	 */
	@RequestMapping(value="/front/internal/compliance/fis105/fileRegChange", method=RequestMethod.POST)
	@ResponseBody
	public  String fileRegChange105(final HttpServletRequest request, @RequestBody Param param) {
		
		HttpSession	    session	= request.getSession();
		StringBuilder	json	= new StringBuilder();
		String          msg     = "";
		
		try {
			param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
			param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
			param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
			param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		
			complianceService.updateSecurityCheckFileReg(param);

			json.append("{")
				.append("\"result\":").append(true).append(",")
				.append("\"msg\":").append("\"").append(msg).append("\"")
				.append("}");
			
		} catch(Exception e) {
			logger.error("진단항목 등록중 에러", e);
			
			json.append("{")
			.append("\"result\"").append(":").append(false);
			json.append("}");
		}
		
		return json.toString();
	}
	
	/**
	 * 상세화면(내부평가/목표)
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/compliance/fis106", method=RequestMethod.POST)
	public String form4( final HttpServletRequest request
			               , final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		HttpSession	session	= request.getSession();
		String group = Utils.nvl((String)session.getAttribute("group"));
		
		Param detailCheckListEval = complianceService.getCheckListEvalOne(param);
		
		List<Param>	checkListEvalAllList = complianceService.getCheckListEvalAllList(param);
		model.addAttribute("checkListEvalAllList", checkListEvalAllList);
		
		model.addAttribute("group", group);
		model.addAttribute("detailCheckListEval",detailCheckListEval);
		model.addAttribute("GOAL_LEVEL_CD",complianceService.getUseCodeList("GOAL_LEVEL_CD"));
		model.addAttribute("EVAL_CD",complianceService.getUseCodeList("EVAL_CD"));
		
		//권한체크
//		HttpSession	session	= request.getSession();
		Param authParam = new Param();
		authParam.set("menu_id", request.getAttribute("currentMenuId"));
		authParam.set("group_id", Utils.nvl((String)session.getAttribute("group")));
		authParam.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		String menuAuth = complianceService.getUserMenuAuth(authParam);
		model.addAttribute("menuAuth", menuAuth);
		
		return "WEB-INF/views/compliance/formEval";
	}
	
	/**
	 * 상세화면(자체평가/목표) - 수정
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/compliance/fis106/update", method=RequestMethod.POST)
	public String update106(final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	    param	= new Param(request);
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		String	hiddenQuery	= null;
		String  msg = "";
		
		try{
			
			complianceService.updateSecurityChecklistEval(param);
			msg = "저장하였습니다";
			
			model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
			hiddenQuery	= "<input type='hidden' name='checklist_id' value='" + param.get("checklist_id") + "' />";	
			return Utils.sendMessage(request, msg, "/front/internal/compliance/fis106", hiddenQuery);
		} catch(Exception e) {
			logger.error("저장중 에러", e);
		}
		return Utils.sendMessage(request, "저장중 오류가 발생 했습니다.");
	}
	
	/**
	 * 상세화면(자체평가/목표) - 자체평가 변경
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/compliance/fis106/change1", method=RequestMethod.POST)
	public String change106_1(final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	    param	= new Param(request);
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		String	hiddenQuery	= null;
		String  msg = "";
		
		try{
			
			complianceService.updateSecurityChecklistEval1(param);
			msg = "변경하였습니다";
			
			model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
			hiddenQuery	= "<input type='hidden' name='checklist_id' value='" + param.get("checklist_id") + "' />";	
			return Utils.sendMessage(request, msg, "/front/internal/compliance/fis106", hiddenQuery);
		} catch(Exception e) {
			logger.error("변경중 에러", e);
		}
		return Utils.sendMessage(request, "변경중 오류가 발생 했습니다.");
	}
	
	/**
	 * 상세화면(자체평가/목표) - 목표수준 변경
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/compliance/fis106/change2", method=RequestMethod.POST)
	public String change106_2(final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	    param	= new Param(request);
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		String	hiddenQuery	= null;
		String  msg = "";
		
		try{
			
			complianceService.updateSecurityChecklistEval2(param);
			msg = "변경하였습니다";
			
			model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
			hiddenQuery	= "<input type='hidden' name='checklist_id' value='" + param.get("checklist_id") + "' />";	
			return Utils.sendMessage(request, msg, "/front/internal/compliance/fis106", hiddenQuery);
		} catch(Exception e) {
			logger.error("변경중 에러", e);
		}
		return Utils.sendMessage(request, "변경중 오류가 발생 했습니다.");
	}
	
	
	
}
