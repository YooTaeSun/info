package com.softworks.springframework.web.controllers.front;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.front.LawsRevHistService;


@Controller
public class LawsRevHistController extends BaseController{
	
	@Autowired
	private	LawsRevHistService			lawsRevHistService;

	/**
	 * 국내 법령 개정 이력 화면 - 리스트
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/lawsrevhist/fis110/list", method=RequestMethod.POST)
	public String list110( final HttpServletRequest request, final ModelMap model) throws Exception {
		
		Param	param	= new Param(request);
		param.set("page", param.getInt("page", 1));
		param.set("pageSize", param.getInt("pageSize", 10));
		
		int	total	= lawsRevHistService.getLawsRevisionHistListCount(param);
		
		model.addAttribute("total", total);
		model.addAttribute("lawsRevisionHistList", lawsRevHistService.getLawsRevisionHistList(param));
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("pageSizeChange", lawsRevHistService.getUseCodeList("PAGE_CHANGE"));
		
		return "compliance/lawsRevHistList.front";
	}
	
	/**
	 * 국내 법령 개정 이력 화면 - 상세
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/lawsrevhist/fis110/detail", method=RequestMethod.POST)
	public String detail110( final HttpServletRequest request
			               , final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		
		model.addAttribute("lawsRevisionHistOne", lawsRevHistService.getLawsRevisionHistOne(param));
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		
		return "WEB-INF/views/compliance/lawsRevHistDetail";
	}
	
	/**
	 * 국내 법령 개정 이력 화면 - 엑셀저장
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/lawsrevhist/fis110/excel", method=RequestMethod.POST)
	public String excel110(final HttpServletRequest request, final ModelMap model) throws Exception {

		Param param = new Param(request);

		int	total	= lawsRevHistService.getLawsRevisionHistListCount(param);
        
        String retunStr = Utils.sendMessage(request, "해당 조건에 검색된 내역이 없습니다.", "/front/internal/lawsrevhist/fis110"
                , Utils.base64DecodeHidden(Utils.base64Encode(param.toQueryString())));
        
        if(total > 0) {
        	
            retunStr = "excelDownloadView";
            lawsRevHistService.getLawsRevisionHistListExcel(param, model);
        }
        
        return retunStr;
	}
}
