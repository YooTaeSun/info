package com.softworks.springframework.web.controllers.front;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.MailSendService;
import com.softworks.springframework.web.services.front.PrivateInfoCompanyService;

@Controller
public class PrivateInfoCompanyController extends BaseController{
	
	@Autowired
	private	PrivateInfoCompanyService			privateInfoCompanyService;
	
	@Autowired
	private MailSendService	mailSendService ;

	/**
	 * 개인정보 제공업체 현황 관리 - 리스트
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/privateInfoCompany/fis230/list", method=RequestMethod.POST)
	public String list230( final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	param	= new Param(request);
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		if("PortalAdmin".equals(Utils.nvl((String)session.getAttribute("group")))){
			param.set("admin_yn", "Y");
		}else{
			param.set("admin_yn", "N");
		}
		
		String sdate = param.get("sdate");
		if(sdate.equals("")){
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			int nYear = calendar.get(Calendar.YEAR);
			String nSdate = nYear+"-01-01";
			String nEdate = nYear+"-12-31";
			param.set("sdate", nSdate);
			param.set("edate", nEdate);
		}
		
		String provider_typ_cd_arr = Utils.nvl(param.get("provider_typ_cd_arr"));
		String[] provider_typ_cd_arr2 = null;
		if(!provider_typ_cd_arr.equals("")){
			provider_typ_cd_arr2 = provider_typ_cd_arr.split("\\,");
		}
		param.set("provider_typ_cd_arr", provider_typ_cd_arr2);
		
		int	total	= privateInfoCompanyService.getPrivateInfoCompanyListCount(param);
		
		model.addAttribute("total", total);
		model.addAttribute("privateInfoCompanyOneList", privateInfoCompanyService.getPrivateInfoCompanyList(param));
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("pageSizeChange", privateInfoCompanyService.getUseCodeList("PAGE_CHANGE"));
		
		//권한체크
//		HttpSession	session	= request.getSession();
		Param authParam = new Param();
		authParam.set("menu_id", request.getAttribute("currentMenuId"));
		authParam.set("group_id", Utils.nvl((String)session.getAttribute("group")));
		authParam.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		String menuAuth = privateInfoCompanyService.getUserMenuAuth(authParam);
		model.addAttribute("menuAuth", menuAuth);
		
		return "privateInfoCompany/privateInfoCompanyList.front";
	}
	
	/**
	 * 개인정보 제공업체 현황 관리 - 제3자 제공업체 신규 등록 및 수정 화면
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/privateInfoCompany/fis231/form", method=RequestMethod.POST)
	public String form231( final HttpServletRequest request
			               , final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		
		String company_id = Utils.nvl(param.get("company_id"));
		if(!company_id.equals("")){
			model.addAttribute("privateInfoCompanyOne", privateInfoCompanyService.getPrivateInfoCompanyOne(param));
		}
		model.addAttribute("CODE_COMPANY_CD", privateInfoCompanyService.getUseCodeList("COMPANY_CD"));
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		
		//권한체크
		HttpSession	session	= request.getSession();
		Param authParam = new Param();
		authParam.set("menu_id", request.getAttribute("currentMenuId"));
		authParam.set("group_id", Utils.nvl((String)session.getAttribute("group")));
		authParam.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		String menuAuth = privateInfoCompanyService.getUserMenuAuth(authParam);
		model.addAttribute("menuAuth", menuAuth);
		
		return "WEB-INF/views/privateInfoCompany/privateInfoCompanyForm231";
	}
	
	/**
	 * 개인정보 제공업체 현황 관리 - 수탁업체 신규 등록 및 수정 화면
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/privateInfoCompany/fis232/form", method=RequestMethod.POST)
	public String form232( final HttpServletRequest request
			               , final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		
		String company_id = Utils.nvl(param.get("company_id"));
		if(!company_id.equals("")){
			model.addAttribute("privateInfoCompanyOne", privateInfoCompanyService.getPrivateInfoCompanyOne(param));
		}
		
		model.addAttribute("CODE_COMPANY_CD", privateInfoCompanyService.getUseCodeList("COMPANY_CD"));
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		
		//권한체크
		HttpSession	session	= request.getSession();
		Param authParam = new Param();
		authParam.set("menu_id", request.getAttribute("currentMenuId"));
		authParam.set("group_id", Utils.nvl((String)session.getAttribute("group")));
		authParam.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		String menuAuth = privateInfoCompanyService.getUserMenuAuth(authParam);
		model.addAttribute("menuAuth", menuAuth);
		
		return "WEB-INF/views/privateInfoCompany/privateInfoCompanyForm232";
	}
	
	/**
	 * 개인정보 제공업체 현황 관리 등록
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/privateInfoCompany/fis230/regist", method=RequestMethod.POST)
	@ResponseBody
	public  String insert230(final HttpServletRequest request, @RequestBody Param param) {
		
		HttpSession	    session	= request.getSession();
		StringBuilder	json	= new StringBuilder();
		String          msg     = "";
		
		try {
			param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
			param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
			param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
			param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
			
			privateInfoCompanyService.insertPrivateInfoCompany(param);
			privateInfoCompanyService.updateFileId(param);
			
			//메일서비스
			String recv_emp_no = param.get("manager_emp_no");
			Param contentReplaceParam = new Param();
			contentReplaceParam.set("#COMPANY_NM#", param.get("company_nm"));
//			Param mailRtnParam = mailSendService.sendMail2("EM06", recv_emp_no, contentReplaceParam);
//			System.out.println("RESULT_MSG ============> "+mailRtnParam.get("RESULT_MSG")) ;
			
			String noti_id = "C06";
			String schd_id = "C06";
			Param mailRtnParam = mailSendService.setNotiHist(noti_id, recv_emp_no, "Y", schd_id, contentReplaceParam);
			
			json.append("{")
				.append("\"result\":").append(true).append(",")
				.append("\"msg\":").append("\"").append(msg).append("\"")
				.append("}");
			
		} catch(Exception e) {
			logger.error("진단항목 등록중 에러", e);
			
			json.append("{")
			.append("\"result\"").append(":").append(false);
			json.append("}");
		}
		
		return json.toString();
	}
	
	/**
	 * 개인정보 제공업체 현황 관리 수정
	 * @param request
	 * @param param
	 * @return
	 */
	@RequestMapping(value="/front/internal/privateInfoCompany/fis230/update", method=RequestMethod.POST)
	@ResponseBody
	public  String update230(final HttpServletRequest request, @RequestBody Param param) {
		
		HttpSession	    session	= request.getSession();
		StringBuilder	json	= new StringBuilder();
		try {
			param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
			param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
			param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
			param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
			
			privateInfoCompanyService.updatePrivateInfoCompany(param);
			
			//메일서비스
			String recv_emp_no = param.get("manager_emp_no");
			Param contentReplaceParam = new Param();
			contentReplaceParam.set("#COMPANY_NM#", param.get("company_nm"));
			
			String noti_id = "C06";
			String schd_id = "C06";
			Param mailRtnParam = mailSendService.setNotiHist(noti_id, recv_emp_no, "Y", schd_id, contentReplaceParam);
			
			json.append("{")
				.append("\"result\"").append(":").append(true);
			json.append("}");
			
		} catch(Exception e) {
			logger.error("진단항목 등록중 에러", e);
			
			json.append("{")
			.append("\"result\"").append(":").append(false);
			json.append("}");
		}
		
		return json.toString();
	}
	
	/**
	 * 개인정보 제공업체 현황 관리 삭제
	 * @param request
	 * @param param
	 * @return
	 */
	@RequestMapping(value="/front/internal/privateInfoCompany/fis230/delete", method=RequestMethod.POST)
	@ResponseBody
	public  String delete230(final HttpServletRequest request, @RequestBody Param param) {
		
		HttpSession	    session	= request.getSession();
		StringBuilder	json	= new StringBuilder();
		try {
			param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
			param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
			param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
			param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
			
			privateInfoCompanyService.deletePrivateInfoCompany(param);
			
			json.append("{")
				.append("\"result\"").append(":").append(true);
			json.append("}");
			
		} catch(Exception e) {
			logger.error("진단항목 등록중 에러", e);
			
			json.append("{")
			.append("\"result\"").append(":").append(false);
			json.append("}");
		}
		
		return json.toString();
	}
	
	/**
	 * 진단영역별 체크리스트 화면 - 엑셀저장
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/privateInfoCompany/fis230/list/excel", method=RequestMethod.POST)
	public String excel(final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param param = new Param(request);
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		if("PortalAdmin".equals(Utils.nvl((String)session.getAttribute("group")))){
			param.set("admin_yn", "Y");
		}else{
			param.set("admin_yn", "N");
		}
		
		int	total	= privateInfoCompanyService.getPrivateInfoCompanyListCount(param);
		
        String retunStr = Utils.sendMessage(request, "해당 조건에 검색된 내역이 없습니다.", "/front/internal/privateInfoCompany/fis230/list"
                , Utils.base64DecodeHidden(Utils.base64Encode(param.toQueryString())));
        
        if(total > 0) {
        	
            retunStr = "excelDownloadView";
            
//            String provider_typ_cd = param.get("provider_typ_cd");
//            if("THIRD".equals(provider_typ_cd)){
//                privateInfoCompanyService.getPrivateInfoCompanyListExcel1(param, model);
//            }else{
//                privateInfoCompanyService.getPrivateInfoCompanyListExcel2(param, model);
//            }
            
            privateInfoCompanyService.getPrivateInfoCompanyListExcel(param, model);
            
        }
        
        return retunStr;
	}
}
