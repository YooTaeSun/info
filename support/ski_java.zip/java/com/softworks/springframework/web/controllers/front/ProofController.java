package com.softworks.springframework.web.controllers.front;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.softworks.springframework.tag.PagingTag;
import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.CodeLoaderService.CodeInfo;
import com.softworks.springframework.web.services.backoffice.CodeService;
import com.softworks.springframework.web.services.backoffice.MetaCompanyService;
import com.softworks.springframework.web.services.backoffice.MetaLawService;
import com.softworks.springframework.web.services.front.ProofService;

@SuppressWarnings("unchecked")
@Controller
public class ProofController extends BaseController{

	@Autowired
	private	CodeService codeSvc;

	@Autowired
	private	MetaLawService metaLawSvc;


	@Autowired
	private	MetaCompanyService metaCompanySvc;

	@Autowired
	private	ProofService svc;


	/**
	 * 보안 수검/감사 리스트
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/proof/list", method=RequestMethod.POST)
	public String list( final HttpServletResponse response, final HttpServletRequest request, final ModelMap model) throws Exception {

		HttpSession	session = request.getSession();

		Param	param	= new Param(request);

		List<CodeInfo> lawSystemList =  new ArrayList<CodeInfo>();
		for (Param e : metaLawSvc.getLawSystemAllList(param)) {
			CodeInfo codeInfo = new CodeInfo();
			codeInfo.setCode(e.get("LS_ID"));
			codeInfo.setName(e.get("LS_ABBR_NM"));
			lawSystemList.add(codeInfo);
		}
		model.addAttribute("lawSystemList", lawSystemList);//M_LAW_SYSTEM 관련 법/제도 리스트
		model.addAttribute("mngOrgCdList", svc.getUseCodeList("MNG_ORG_CD"));//수행조직
		model.addAttribute("evalCdList", svc.getUseCodeList("EVAL_CD"));//내부 평가
		model.addAttribute("goalLevelCdList", svc.getUseCodeList("GOAL_LEVEL_CD"));//목표수준
		model.addAttribute("mainAreaCdList", svc.getUseCodeList("MAIN_AREA_CD"));//보안진단 Main 영역
		model.addAttribute("pageSizeChange", svc.getUseCodeList("PAGE_CHANGE"));


		Param param01 = new Param();
		param01.put("pcode", "COMPANY_CD");
		model.addAttribute("companyCdList", codeSvc.getList(param01));

		//게열사/사업장
		List<Param> busiSiteList =  metaCompanySvc.getCompanyBusiSiteAllList(new Param());
		JSONObject jsonObject = new JSONObject();
		Map<String, List<Param>> companyBusiSiteAllMap = busiSiteList.stream().collect(Collectors.groupingBy(x->((Param)x).get("COMPANY_CD")));
		jsonObject.put("companyBusiSiteAllMap", companyBusiSiteAllMap);
		model.addAttribute("jsonData", jsonObject.toString());

		return "proof/proofList.front";
	}

	/**
	 * 보안증적관리현황조회 리스트(json 요청)
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/proof/json-list", method=RequestMethod.POST)
	@ResponseBody
	public String jsonList(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();

		try {
			Param param = new Param(map);

			int	total = svc.getListCount(param);
			jsonObject.put("total", total);
			jsonObject.put("list", svc.getList(param));

			if(total > 0) {
				PagingTag pagingTag = new PagingTag();
				pagingTag.setTotal(total);
				pagingTag.setPageSize(param.get("pageSize"));;
				pagingTag.setPage(param.get("page"));
				String paging = pagingTag.getPaingStr();
				jsonObject.put("paging", paging);
			}

			jsonObject.put("result", true);

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}

	/**
	 * 보안증적관리현황조회 리스트(json 요청)
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/proof/list/excel", method=RequestMethod.POST)
	public String listExcel(final HttpServletRequest request, final ModelMap model) throws Exception {

		Param param = new Param(request);
		String json = param.get("data");
		json = json.replace("^","\"");
		ObjectMapper mapper = new ObjectMapper();
		LinkedHashMap dataHashParam = mapper.readValue(json, new TypeReference<Map<String, Object>>(){});
		Param dataParam = new Param(dataHashParam);

		String retunStr = Utils.sendMessage(request, "해당 조건에 검색된 내역이 없습니다."
				, "/front/internal/proof/list", Utils.base64DecodeHidden(Utils.base64Encode(param.toQueryString())));


		List<Param> searchList =  (List<Param>) dataHashParam.get("searchList");

		int	total	= svc.getListCount(dataParam);
		if(total > 0) {
			svc.getListExcel(dataParam, model);
			retunStr = "excelDownloadView";
		}
        return retunStr;
	}

}
