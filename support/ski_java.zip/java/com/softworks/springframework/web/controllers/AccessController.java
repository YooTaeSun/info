package com.softworks.springframework.web.controllers;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.URLEncoder;
import java.sql.SQLException;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.ShaPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import com.nets.sso.agent.AuthCheck;
import com.nets.sso.agent.AuthCheckLevel;
import com.nets.sso.agent.AuthStatus;
import com.nets.sso.agent.SSOConfig;
import com.nets.sso.agent.Util;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.utils.Param;
//import com.softworks.springframework.utils.SendMail;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.utils.RandomString;
import com.softworks.springframework.web.services.AccessService;
import com.softworks.springframework.web.services.MenuLoaderService;
import com.softworks.springframework.web.services.backoffice.UserService;
import com.softworks.springframework.web.services.front.MyService;
import com.softworks.springframework.web.services.SmsService;

@Controller
public class AccessController extends BaseController {

	@Autowired
	private	AccessService	svc;
	
	@Autowired
	private	UserService		userSvc;
	
	@Autowired
	private	MyService		mySvc;
	
	@Autowired
	private SmsService	sms ;

	@Autowired
	private	MenuLoaderService	menuLoader;

	private	final	String	ADMIN_URL		= Property.getProperty("site.admin.url");
	private	final	String	PASSWORD_SALT	= Property.getProperty("user.password.salt");
	private final	String	ADMIN_GROUP		= Property.getProperty("site.admin.group");
	private	final	String	MANAGER_GROUP	= Property.getProperty("site.manager.group");
//	private	final	String	PM_GROUP		= Property.getProperty("site.pm.group");
//	private	final	String	DEFAULT_GROUP	= Property.getProperty("site.default.group");
	private	final	String	ENCRIPT_FLAG	= Property.getProperty("adminid.encript.flag");
	private	final	String	IP_CHECK		= Property.getProperty("admin.ip.check");
	private final	String 	MAIL_USE		= Property.getProperty("mail.use");
	private final	String 	SMS_USE			= Property.getProperty("sms.use");
	private final	ShaPasswordEncoder	passwordEncoder	= new ShaPasswordEncoder(256);
	
	private	final	String	COMPANY_MANAGER_GROUP	= Property.getProperty("site.compay.group");
	private	final	String	GROUP_MANAGER_GROUP		= Property.getProperty("site.group.group");
	private	final	String	USER_GROUP				= Property.getProperty("site.user.group");
	
	@RequestMapping(value="/logout")
	public String logout(final HttpServletRequest request) throws Exception {
		request.getSession().invalidate();
		
		return "index";
	}

//	@RequestMapping(value="/ssoLogin", params="session_id", method=RequestMethod.POST)
//	public String ssologin(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
//	    System.out.println("==============ssoLogin========================");
//
//		Param	param	= new Param(request);
//		
//		// 이미 세션이 있는경우 main 으로 이동
//		String	login_id	= (String)request.getParameter("session_id");
//
//		System.out.println("========sso login Session id "+login_id);
//
//		param.set("type", "User");
//		param.set("user_id", login_id);
//		
//		boolean	isLogin	= (null == login_id ||  "".equals(login_id)) ? false : true;
//		
//		if(isLogin){
//			
//		// 사용요청중인경우 Tlogin화면으로 이동
//			if(svc.isWatingApproval(login_id)) return Utils.sendMessage(request, "사용자의 사이트사용 요청이 아직 승인되지 않았습니다.","/Tlogin");
//			
//			Param	info	= svc.getUserInfo(param);
//		
//			if(null != info) {
//				svc.setLastUserLogin(info.get("ID"));			
//				setSession(request.getSession(), info);
//				
//				//t_log 저장
//				info.set("actionType", "portal_login");
//				info.set("loginIp", getRealIp(request));
//				svc.insertLog(info);
//	//			if( svc.isExpirePass(info.get("id")) == 0){
//					return "redirect:/main";				
//	//			}else{			
//	//				return Utils.sendMessage(request, "비밀번호는 6개월마다 변경해 주셔야 합니다.\\n비밀번호변경 화면으로 이동합니다.","/mypage/password");
//	//			}			
//			}
//		
//			return "redirect:/error/authenticationFail";
//		} else{					
//			//로그인화면
//			return "Tlogin";
//		}
//	}
	
	/*
	 * SK Innovation sso로그인 프로세스
	 * 2109.05.09
	 * Max Kim
	 * sso Request URL : https://sqm.skinnovation.com/login
	 * 
	 * */
	
	@RequestMapping(value={"/","/login"})
	public String login(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String	id	= (String)request.getSession().getAttribute("uid");  // user_id정보
		logger.debug("======================[Access Session ID]      "+id);
		// 세션 정보가 있을 경우 
	       System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ SSO %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"); 
		if(null != id && !"".equals(id)) {
			return "redirect:/main";   // 성공시 메인화면으로 이동
		}else{
			SSOConfig.request = request;
			
			// SSO 관련 로직 //
			String navigateUrl = "";
			String logonid = "";
			AuthCheck auth = new AuthCheck(request, response);
			String siteDNS = "";
			siteDNS = SSOConfig.siteDomain();
	        String ssositeValue = "&" + SSOConfig.REQUESTSSOSITEPARAM + "=" + siteDNS;
	        navigateUrl = SSOConfig.logoffPage() + "?" + SSOConfig.returnURLTagName() + "=" + Util.uRLEncode(auth.thisURL(), "UTF8") + ssositeValue;
	        logger.debug("ssositeValue========================================  "+ssositeValue);
	        logger.debug("navigateUrl========================================  "+navigateUrl);
	        AuthStatus status = auth.checkLogon(AuthCheckLevel.Medium);
		    // 로컬용 데이터 임시 저장삭제  jgmik 2017 기존 주석 설명대로 적용
	        // *****************************************************  삭제(상용에 올릴경우)
		    //    status = AuthStatus.SSOSuccess;
		    //    logonid = request.getParameter("dev_login_id");
		    // *****************************************************
	        logger.debug("status========================================  "+status);
	        if(status == AuthStatus.SSOFirstAccess)
	        {
	        	logger.debug("SSOFirstAccess========================================  "+status);
	            auth.trySSO();
	        }else if(status == AuthStatus.SSOSuccess)
	        {
	            // 인증 성공
	        	logger.debug("SSOSuccess========================================  "+status);
	        	// *****************************************************  주석해제(상용에 올릴경우)
	        	logonid = auth.getSSODomainCookieValue("empNo");
	        	// *****************************************************
	        	Param	param = new Param();
	        	param.set("user_id", logonid);
	    		param.set("type", "User");
	    		param.set("user_type", "F");
	    		
	        	Param info = svc.getPortalUserInfo(param);
				// 
				if(null != info){
					logger.debug(">>>>>>>>>>>>>>>info           ["+info+"]");
					String serverName = request.getServerName();

					if (serverName.equals("127.0.0.1") || serverName.toLowerCase().equals("localhost")) {
						info.set("serverFlag", "LOCAL");
					} else {
						info.set("serverFlag", "REAL");
					}

					Param admInfo = svc.getAdminInfo(param);

					if (admInfo != null) {
						info.set("isAdmin", "Y");
					} else {
						info.set("isAdmin", "N");
					}

					info.set("loginIp", getRealIp(request));

					if (ENCRIPT_FLAG.equals("Y")) {
						info.set("EID", Utils.encript(info.get("ID")));
					} else {
						info.set("EID", info.get("ID"));
					}

					svc.setLastUserLogin(info.get("ID"));			
					setSession(request.getSession(), info);
					
					// 접속이력 저장
					info.set("reqUrl", request.getRequestURI());

					svc.insertConnHist(info);

					menuLoader.reload();
					
					return "redirect:/main";   // 성공시 메인화면으로 이동
				}else{
					return "error";  // 인증 재처리 할수 있는 화면이동
				}
//	            // SSO에서 받은 사번으로 이노베이션 연동 테이블의 사원 정보 조회
//				Param	param	= svc.getSKIUserInfo(logonid);
//						//svc.getSKLoginInfo(auth.getSSODomainCookieValue("empNo"));
//				logger.debug("param1==========================   ["+param+"]");
//				if(null != param) {
//					// 이노베이션 사원정보로 Portal t_user 정보 조회
//					Param info = svc.getPortalUserInfo(param);
//					// 
//					if(null == info){
//					    // 그외는 조회정보 세션처리
//			            // svc.setLastUserLogin(info.get("user_id"));		// 마지막 로그인 정보 업데이트	
//						// Portal 조회결과 사용자 정보가 없을 경우 등록, 초기 user그룹은 User로 세팅
//						param.set("group","User");  // 임시
//						logger.debug("param2==========================   ["+param+"]");
//						svc.insertPortalUserInfo(param);  
//						//  이노베이션 사원정보로 Porral user정보 조회 
//						info = svc.getPortalUserInfo(param);
//					}
//					logger.debug(">>>>>>>>>>>>>>>info           ["+info+"]");
//					setSession(request.getSession(), info);
//					
//					
//					return "redirect:/main";   // 성공시 메인화면으로 이동
//				}else{
//					return "error";  // 인증 재처리 할수 있는 화면이동
//				}
	        }else{
	        	logger.debug("error number ========================================  " + auth.errorNumber());
	        	logger.debug("error String ========================================  " + auth.errorString());
	        	
	        	return "error";
	        }
			
			return "index";  // 인증 재처리 할수 있는 화면이동
		}
		
	}
	
/*	
// index 를 호출하거나 login페이지 호출시 이동
// 무조건 sso를 타고 오기때문에 세션에 값이 없고 sso 정보가 넘어옴.	
	@RequestMapping(value={"/","/login"}, method=RequestMethod.POST)
	public String login(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		String getUrl = new String(request.getRequestURL());

// 관리자로 로그인한 사용자가 사용자 메인 페이지로 들어오는 경우 사용자페이지 main으로 이동(필요없는 로직일듯)
		System.out.println("========geturl"+getUrl);
		
		if(getUrl.indexOf("backoffice") > -1){
			System.out.println("========geturl"+getUrl);
			return "/main";
		}
		
		String sm_serversession = request.getParameter("authinform");
		String eams_serversessionid = request.getHeader("SM_SERVERSESSIONID");
		String login_id = request.getHeader("SM_USER"); 

		System.out.println("================ sso login id ====>" + login_id);

		Param	param	= new Param(request);
		param.set("type", "User");
		param.set("user_id", login_id);
		
		boolean	isLogin	= (null == login_id ||  "".equals(login_id)) ? false : true;
		
		if(isLogin){
			
		// 사용요청중인경우 Tlogin화면으로 이동
			if(svc.isWatingApproval(login_id)) return Utils.sendMessage(request, "사용자의 사이트사용 요청이 아직 승인되지 않았습니다.","/Tlogin");
			
			Param	info	= svc.getUserInfo(param);

			if(null != info) {
				System.out.println("================ get id ====>" + info.get("id"));

				String  status = info.getString("status");
				//유저정보 유 + 상태값 1 or 4(정상 or 최초접속)
				if("1".equals(status) || "4".equals(status)){
					svc.setLastUserLogin(info.get("id"));			
					setSession(request.getSession(), info);
					
					//t_log 저장
					info.set("actionType", "portal_login");
					info.set("loginIp", getRealIp(request));
					svc.insertLog(info);
				}else if("5".equals(status)){
					return Utils.sendMessage(request, "사용자의 사이트사용 요청이 아직 승인되지 않았습니다.","/Tlogin");
				}
		
		//		if( svc.isExpirePass(info.get("id")) == 0){
		//			return "redirect:/main";				
		//		}else{			
		//			return Utils.sendMessage(request, "비밀번호는 6개월마다 변경해 주셔야 합니다.\\n비밀번호변경 화면으로 이동합니다.","/mypage/password");
		//		}			
		
				
				System.out.println("================ response sendredirect ====>");
//				HttpSession session = request.getSession(false);
//				session.setAttribute("info", info);
				setSession(request.getSession(), info);
// sso login 페이지를 호출해서 url을 변경한 후 세션을 다시 구어주도록 수정
				return "ssologin";
//				response.sendRedirect("http://iw.sktelecom.com/ssoLogin");
//				return (new StringBuilder()).append("redirect:").append(request.getContextPath()).append("/main").toString();
				
			}else{
				//가입신청 화면
				return "Tlogin";
				//return (new StringBuilder()).append("redirect:").append(request.getContextPath()).append("/toUse").toString();

			}

		} else{					
			//로그인화면
			return "Tlogin";
		}

//		return "Tlogin";
	}
*/	
	// (외부Test)index 를 호출하거나 
	@RequestMapping(value={"/Tlogin"})
	public String Tlogin(final HttpServletRequest request) throws Exception {
		String getUrl = new String(request.getRequestURL());
		
		// 이미 세션이 있는경우 main 으로 이동
		String	id	= (String)request.getSession().getAttribute("uid");

		System.out.println("========Tlogin Session id "+id);

		if(null != id && !"".equals(id))
			return (new StringBuilder("redirect:")).append(request.getContextPath()).append("/main").toString();
		
		return "Tlogin";
	}

	// (내부Test)index 를 호출하거나 
	@RequestMapping(value={"/Ilogin"})
	public String Ilogin(final HttpServletRequest request) throws Exception {
		String getUrl = new String(request.getRequestURL());
		
		// 이미 세션이 있는경우 main 으로 이동
		String	id	= (String)request.getSession().getAttribute("uid");

		System.out.println("========Ilogin Session id "+id);

		if(null != id && !"".equals(id))
			return (new StringBuilder("redirect:")).append(request.getContextPath()).append("/main").toString();
		
		return "Ilogin";
	}

	// (관리자Test)index 를 호출하거나 
	@RequestMapping(value="/backoffice/access")
	public String access(final HttpServletRequest request) throws Exception {
		String	id	= (String)request.getSession().getAttribute("uid");

		if(null != id && !"".equals(id)) {
			Param	param	= new Param();
			param.set("type", "Admin");
			param.set("admin_id", id);

			Param	info	= svc.getLoginInfo(param);
			
			if(null != info) {
				String serverName	= request.getServerName();
				String connIp		= getRealIp(request);

				if (serverName.equals("127.0.0.1") || serverName.toLowerCase().equals("localhost")) {
					info.set("serverFlag", "LOCAL");
				} else {
					info.set("serverFlag", "REAL");
				}

				if (IP_CHECK.equals("Y") && !connIp.equals(info.get("ACCEPT_IP"))) {
					return Utils.sendMessage(request, "허용되지 않은 IP에서 접속하셨습니다.");
				}

				info.set("loginIp",connIp);
				info.set("isAdmin", "Y");

				svc.setLastLogin(info.get("ID"));
				setSession(request.getSession(), info);

				// 접속이력 저장
				info.set("reqUrl", request.getRequestURI());

				svc.insertConnHist(info);

				return (new StringBuilder("redirect:")).append(request.getContextPath()).append("/backoffice/main").toString();
			} else {
				return "error";
			}
		} else {
			if (ENCRIPT_FLAG.equals("N")) {
				return "WEB-INF/views/backoffice/login";
			} else {
				return "error";
			}
		}
	}
	
	private void setSession(final HttpSession session, final Param info) {
		session.setAttribute("enc_flag", ENCRIPT_FLAG);							// 관리자ID 암호화여부
		session.setAttribute("man_url", ADMIN_URL);								// 관리자URL
		session.setAttribute("euid", info.get("EID"));							// 사용자ID
		session.setAttribute("uid", info.get("ID"));							// 사용자ID
		session.setAttribute("uname", info.get("NAME"));						// 사용자명
		session.setAttribute("stype", info.get("TYP_CD"));						// 서비스구분코드
		session.setAttribute("group", info.get("GROUP_ID"));					// 권한그룹ID
		session.setAttribute("group_nm", info.get("GROUP_NAME"));				// 권한그룹명
		session.setAttribute("company", info.get("COMPANY_CD", ""));			// 회사코드
		session.setAttribute("company_nm", info.get("COMPANY_NM", ""));			// 회사명
		session.setAttribute("dept_cd", info.get("DEPT_CD", ""));				// 부서
		session.setAttribute("dept_nm", info.get("DEPT_NM", ""));				// 부서명
		session.setAttribute("regularity_cd", info.get("REGULARITY_CD", ""));	// 계약유형코드
		session.setAttribute("regularity_nm", info.get("REGULARITY_NAME", ""));	// 계약유형명
		session.setAttribute("accept_ip", info.get("ACCEPT_IP", ""));			// 접속허용(VDI)IP - 관리자 페이지만 해당
		session.setAttribute("phone", info.get("PHONE", ""));					// 전화번호
		session.setAttribute("mobile", info.get("MOBILE", ""));					// 이동전화번호
		session.setAttribute("email", info.get("EMAIL", ""));					// 이메일주소
		session.setAttribute("last_login", info.get("LAST_LOGIN"));				// 최종로그인일시

		session.setAttribute("isAdmin", info.get("isAdmin"));					// 관리자 여부
		session.setAttribute("isSuper", ADMIN_GROUP.equals(info.get("group")) ? "Y" : "N"); // 사이트 운영자 여부
		//session.setAttribute("isManager", MANAGER_GROUP.equals(info.get("group")) ? "Y" : svc.isManagerLevel(info.get("group"), MANAGER_GROUP));

		session.setAttribute("serverFlag", info.get("serverFlag"));				// 서버구분(REAL, LOCAL)
		session.setAttribute("loginIp", info.get("loginIp"));					// 로그인 IP
		
		/*왼쪽나의할일*/
//		session.setAttribute("isRmsCntFull", MANAGER_GROUP.equals(info.get("group")) ? "Y" : "N");
//		session.setAttribute("mainRmsCnt", 0); // svc.getLeftRmsCntInfo(info.get("id")));

		// 나의 할일 > 조치결과등록 수 조회 - main 호출시 설정
        //session.setAttribute("measureCnt", svc.getMeasureResultCnt(new Param()));
	}
	
	/**
	 * 클라이언트 리얼 아이피 가져오기...환경에 따라 수정이 필요할수있음
	 * @param request
	 * @return
	 */
	private String getRealIp(final HttpServletRequest request) {
		
		String ip = request.getHeader("X-Forwarded-For");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
			ip = request.getHeader("Proxy-Client-IP"); 
		} 
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
			ip = request.getHeader("WL-Proxy-Client-IP"); 
		} 
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
			ip = request.getHeader("HTTP_CLIENT_IP"); 
		} 
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
			ip = request.getHeader("HTTP_X_FORWARDED_FOR"); 
		} 
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
			ip = request.getRemoteAddr();

			if(ip.equalsIgnoreCase("0:0:0:0:0:0:0:1")){
				try {
				    InetAddress inetAddress = InetAddress.getLocalHost();
				    ip = inetAddress.getHostAddress();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		return ip;
	}
	
	// 로그인 페이지에서 아이디 비밀번호를 입력한 후 로그인 한 경우
	@RequestMapping(value="/Tlogin", params="user_id", method=RequestMethod.POST)
	public String loginProcess(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		Param	param	= new Param(request);

		param.set("type", "User");
		param.set("user_type", "F"); // E로 변경
		param.set("passwd", passwordEncoder.encodePassword(param.get("passwd"), PASSWORD_SALT));
		
	    System.out.println("============== Tlogin login process ========================");
		
		if(svc.isWatingApproval(param.get("user_id"))) return Utils.sendMessage(request, "사용자의 사이트사용 요청이 아직 승인되지 않았습니다.");
		
		Param	info	= svc.getLoginInfo(param);
		
		if(null != info) {
			String serverName = request.getServerName();
			if (serverName.equals("127.0.0.1") || serverName.toLowerCase().equals("localhost")) {
				info.set("serverFlag", "LOCAL");
			} else {
				info.set("serverFlag", "REAL");
			}

			info.set("isAdmin", "N");
			info.set("loginIp", getRealIp(request));

			svc.setLastUserLogin(info.get("ID"));			
			setSession(request.getSession(), info);
			
			// 접속이력 저장
//			info.set("actionType", "portal_login");
//			info.set("loginIp", getRealIp(request));
//			svc.insertLog(info);
			info.set("reqUrl", request.getRequestURI());

			svc.insertConnHist(info);
			
//			if( svc.isExpirePass(info.get("id")) == 0){
				return "redirect:/main";				
//			}else{			
//				return Utils.sendMessage(request, "비밀번호는 6개월마다 변경해 주셔야 합니다.\\n비밀번호변경 화면으로 이동합니다.","/mypage/password");
//			}
		}
		
		return "redirect:/error/authenticationFail";
	}

	// 로그인 페이지에서 아이디 비밀번호를 입력한 후 로그인 한 경우
	@RequestMapping(value="/Ilogin", params="user_id", method=RequestMethod.POST)
	public String iloginProcess(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		Param	param	= new Param(request);

		param.set("type", "User");
		param.set("user_type", "F");
		
	    System.out.println("============== Ilogin login process ========================");
		
		Param	info	= svc.getLoginInfo(param);
		
		if(null != info) {
			String serverName = request.getServerName();

			if (serverName.equals("127.0.0.1") || serverName.toLowerCase().equals("localhost")) {
				info.set("serverFlag", "LOCAL");
			} else {
				info.set("serverFlag", "REAL");
			}

			Param admInfo = svc.getAdminInfo(param);

			if (admInfo != null) {
				info.set("isAdmin", "Y");
			} else {
				info.set("isAdmin", "N");
			}

			info.set("loginIp", getRealIp(request));

			if (ENCRIPT_FLAG.equals("Y")) {
				info.set("EID", Utils.encript(info.get("ID")));
			} else {
				info.set("EID", info.get("ID"));
			}

			svc.setLastUserLogin(info.get("ID"));			
			setSession(request.getSession(), info);
			
			// 접속이력 저장
			info.set("reqUrl", request.getRequestURI());

			svc.insertConnHist(info);

			menuLoader.reload();
			
			return "redirect:/main";
		}
		
		return "redirect:/error/authenticationFail";
	}
	
	@RequestMapping(value="/backoffice/access", params="admin_id", method=RequestMethod.POST)
	public String accessProcess(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
		Param	param	= new Param(request);
		param.set("type", "Admin");

		if (ENCRIPT_FLAG.equals("Y")) {
			param.set("admin_id", Utils.decript(param.get("admin_id")));
		}
		
		Param	info	= svc.getLoginInfo(param);
		
		if(null != info) {
			String serverName	= request.getServerName();
			String connIp		= getRealIp(request);
		
			if (serverName.equals("127.0.0.1") || serverName.toLowerCase().equals("localhost")) {
				info.set("serverFlag", "LOCAL");
			} else {
				info.set("serverFlag", "REAL");
			}
		
			if (IP_CHECK.equals("Y") && !connIp.equals(info.get("ACCEPT_IP"))) {
				return Utils.sendMessage(request, "허용되지 않은 IP에서 접속하셨습니다.");
			}
		
			info.set("isAdmin", "Y");
			info.set("loginIp", connIp);
		
			svc.setLastLogin(info.get("ID"));
			setSession(request.getSession(), info);
		
			// 접속이력 저장
			info.set("reqUrl", request.getRequestURI());
		
			svc.insertConnHist(info);
			
			return "redirect:/backoffice/main";
		}
		
		return "redirect:/error/authenticationFail_backoffice";
	}
	
	@RequestMapping(value="/backoffice/switchUser", method=RequestMethod.POST)
	public String sessionUserSwitch(final HttpServletRequest request, final HttpServletResponse response) throws IOException {
		HttpSession	session	= request.getSession();
		
//		if(ADMIN_GROUP.equals((String)session.getAttribute("group"))) {
//			Param	param	= new Param();
//			param.set("user_id", (String)request.getParameter("loginId"));
//			param.set("user_typ_cd", (String)request.getParameter("loginId"));
//
//			Param	info	= userSvc.getInfo(param);
//			
//			if(null != info) {
//				setSession(session, info);
//				return "redirect:/backoffice/main";
//			}
//		}
		
		return "redirect:/error/authenticationError";
	}
	
	@RequestMapping(value="/toUse", method=RequestMethod.GET)
	public String toUseRequest(final HttpServletRequest request, final ModelMap model) throws Exception {
		if(!"".equals(Utils.nvl((String)request.getSession().getAttribute("uid")))) return "redirect:/main";
		
		//model.addAttribute("companyList", svc.getCompanyCodeList());
		model.addAttribute("groupListWithoutAdmin", svc.getAuthGroupCodeWithoutAdminList());
		
		//return "WEB-INF/views/mypage/toUseRequest";
		return "WEB-INF/views/mypage/toUseReq";
	}
	
	@RequestMapping(value="/toUse", method=RequestMethod.POST)
	public String toUseRequestProcess(final HttpServletRequest request) throws Exception {
		Param	param	= new Param(request);
				param.set("passwd", passwordEncoder.encodePassword(param.get("passwd"), PASSWORD_SALT));
		
		try {
			mySvc.toUseRequest(param);
			
			return Utils.sendMessage(request, "사용신청을 완료했습니다.\\n관리자가 사용신청을 허가 하면 사이트를 사용할 수 있습니다.", "Tlogin");
		} catch(Exception e) {
			logger.error("사용요청 처리중 에러", e);
		}
		
		return Utils.sendMessage(request, "사이트 사용신청중 오류가 발생했습니다.");
	}
	
	@RequestMapping(value="/isDuplicateId", params="id", method=RequestMethod.POST)
	public @ResponseBody String isDuplicateId(@RequestParam(value="id", required=true) final String id) throws Exception {
		return String.valueOf(mySvc.isDuplicateId(id));
	}
	
	@RequestMapping(value="/findAccount", method=RequestMethod.GET)
	public String findAccount(final HttpServletRequest request, final ModelMap model) throws Exception {
		if(!"".equals(Utils.nvl((String)request.getSession().getAttribute("uid")))) return "redirect:/main";
		
		model.addAttribute("companyList", svc.getCompanyCodeList());
		
		return "WEB-INF/views/mypage/findAccount";
	}

//	@ResponseBody
//	@RequestMapping(value="/settlement/form/test", method=RequestMethod.POST)
//	public  String getTest(final HttpServletRequest request) {
//		
//		System.out.println("--- jsonData : " + request.getParameter("jsonData"));
//
//		BufferedReader br = null;
//
//		try {
//			br = new BufferedReader(new InputStreamReader(request.getInputStream()));
//
//			String inputLine	= "";
//
//			while ((inputLine = br.readLine()) != null) {
//				System.out.println("--- retValue : " + inputLine);
//			}
//
//			br.close();
//		} catch(Exception e) {
//			e.printStackTrace();
//		} finally {
//			if (br != null) try { br.close(); } catch (Exception e) {}
//		}
//
//		JSONObject jsonObject = new JSONObject();
//		jsonObject.put("Result", "FAILURE");
//		jsonObject.put("Message", "test");
//		jsonObject.put("Detail", "");
//
//		return jsonObject.toString();
//	}
	
//	@RequestMapping(value="/findAccount", method=RequestMethod.POST)
//	public String findAccountProcess(final HttpServletRequest request, final ModelMap model) throws Exception {
//		Param	param	= new Param(request);
//
//		try {
//			if(mySvc.findInfoUser(param)) {
//				/*
//				 * 	임시 패스워드 생성
//				 * 영소대문자 5자리+ 4자리 랜덤 숫자
//				 * 
//				 * */
//				String tempPasswd = "" ;
//				RandomString rndStr = new RandomString();
//				tempPasswd = rndStr.getString(1,"A") + rndStr.getString(4,"a") + rndStr.getString(4,"1"); 														
//				logger.debug("==============================================================================================================");
//				logger.debug(tempPasswd);
//				logger.debug("==============================================================================================================");
//				param.set("tempPasswd", tempPasswd);				
//				param.set("certification", Utils.MD5(UUID.randomUUID().toString()));
//				mySvc.setCertificationKey(param);
//				
//				param.set("host", Property.getProperty("site.url"));
//				String key = Utils.encript("tp=" + Property.getProperty("user.password.find.param") + "&cer=" + param.get("certification") + "&ui=" + param.get("user_id"));
//				System.out.println("key :"+key);
//				String encString = URLEncoder.encode(key,"UTF-8");
//				param.set("key", encString);
//
//				try {
//					logger.debug("메일발송 Arg ::: " + param);
//					String content = "" ;
//					content = "안녕하세요 소스진단 사이트 관리자 입니다." ;
//					content += "<br/><br/>" ;
//					content += "요청하신 소스진단 사이트의 비밀번호를 안내하여 드립니다.<br />" ;
//					content += param.get("name") +" ( "+param.get("user_id")+ ") 님의 임시 비밀번호는 "+param.get("tempPasswd")+" 입니다.";
//					content += "<br/>" ;
//					content += "감사합니다." ;
//					if ( MAIL_USE.equals("Y"))
//					{
//						SendMail	mail	= new SendMail(false);
//						// mail.setFrom();
//						mail.setArgs(param);
//						mail.setSubject("소스진단 사이트 임시비밀번호 요청 인증메일");
//						mail.setRecipient(param.get("email"), param.get("name"));
//						mail.setFrom(Property.getProperty("mail.sender.email"), "소스진단관리");
//						mail.setContent(content) ;
//						// mail.setHtml(new java.io.File(request.getServletContext().getRealPath(Property.getProperty("mail.html.template")), "findAccount.html"));
//						mail.send();
//					}
//					
//					/*
//					 * 	SMS 전송
//					 * 
//					 * SMS 전송은 conf.properties 에서 sms.use = Y일 경우에만 전송
//					 *  		
//					 * */
//					
//					try {
//						String hp = "" ;
//						hp = param.get("tel") ;
//						hp = ( hp == null || hp.equals("")) ? "01026901666" : hp.replaceAll("-", "") ; 
//						content = "" ;
//						content += "소스진단사이트 관리자 입니다." ;
//						content += param.get("name") ;
//						content += " 님의 요청하신 임시비밀번호는 " ;
//						content += param.get("tempPasswd") ;
//						content += "입니다." ;
//						
//						if ( SMS_USE.equals("Y"))
//						{
//							sms.setInterval(0);
//							sms.setRcvTelNo(hp);
//							sms.setSendTelNo("0221045114");
//							sms.setMsg(content);
//							sms.send();
//						}
//					}catch (Exception e) {}
//					
//					return Utils.sendMessage(request, "입력하신 이메일 주소로 비밀번호 변경 인증메일을 발송 했습니다.", "/login");
//				} catch(Exception e) {
//					logger.error("인증메일 발송에러", e);
//
//					return Utils.sendMessage(request, "비밀번호 찾기 인증메일 발송중 오류가 발생했습니다.");
//				}
//			} else
//				return Utils.sendMessage(request, "입력한 정보와 일치하는 사용자가 없습니다.");
//		} catch(Exception e) {
//			logger.error("비밀번호 찾기 오류", e);
//			return Utils.sendMessage(request, "처리중 예기치못한 오류가 발생했습니다.");
//		}
//	}
}
