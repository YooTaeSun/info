package com.softworks.springframework.web.controllers.front;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.CodeLoaderService.CodeInfo;
import com.softworks.springframework.web.services.front.MonitoringService;

@SuppressWarnings("unchecked")
@Controller
public class MonitoringController extends BaseController{

	@Autowired
	private	MonitoringService			svc;
	
	final static String DEFAULT_MAP_ID = "M001";
	final static String IMAGE_PATH = "/images/securitymap/";
	final static String IMAGE_EXTSN = ".png";
	
	/**
	 * 보안 수준 현황 – 진단 영역별 보안 수준
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/monitoring/fis300/info", method=RequestMethod.POST)
	public String info300(final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		
		// get icon
		Param iconParam = getIconParam();
		param.set("iconParam", iconParam);
		model.addAttribute("iconParam", iconParam);
		
		// get chart info
		List<Param> chartInfo = svc.getChartDataDiagnosis(param);
		
		// get Main 진단 영역
		List<Param> mainInfo = svc.getMainDataDiagnosis(param);
		
		// get Sub 진단 영역
		List<Param> subInfo = svc.getSubDataDiagnosis(param);
		model.addAttribute("chartInfo", Utils.getListJSON(chartInfo).toString());
		model.addAttribute("total", mainInfo.size());
		model.addAttribute("mainInfo", mainInfo);
		model.addAttribute("subInfo", subInfo);
		model.addAttribute("subTotal", subInfo.size());
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		
		// set menuAuth
		HttpSession	session	= request.getSession();
		param.set("menu_id", request.getAttribute("currentMenuId"));
		param.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		String menuAuth = svc.getUserMenuAuth(param);
		param.set("menuAuth", menuAuth);
		model.addAttribute("menuAuth", menuAuth);
		
		return "monitoring/info300.front";
	}
	
	/**
	 * 보안 수준 현황 – 업무 영역별 보안 수준
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/monitoring/fis301/info", method=RequestMethod.POST)
	public String info301(final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		
		// get icon
		Param iconParam = getIconParam();
		param.set("iconParam", iconParam);
		model.addAttribute("iconParam", iconParam);
		
		// get chart info
		List<Param> chartInfo = svc.getChartDataTask(param);
		
		// get data info
		List<Param> dataInfo = svc.getDataTask(param);
		
		model.addAttribute("chartInfo", Utils.getListJSON(chartInfo).toString());
		model.addAttribute("dataInfo", dataInfo);
		model.addAttribute("total", dataInfo.size());
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		
		// set menuAuth
		HttpSession	session	= request.getSession();
		param.set("menu_id", request.getAttribute("currentMenuId"));
		param.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		String menuAuth = svc.getUserMenuAuth(param);
		param.set("menuAuth", menuAuth);
		model.addAttribute("menuAuth", menuAuth);
		
		return "monitoring/info301.front";
	}
	
	/**
	 * 보안 수준 현황 – 법/제도별 보안 수준
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/monitoring/fis302/info", method=RequestMethod.POST)
	public String info302(final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		
		// get icon
		Param iconParam = getIconParam();
		param.set("iconParam", iconParam);
		model.addAttribute("iconParam", iconParam);
		
		// get chart info
		List<Param> chartInfo = svc.getChartDataLaws(param);
		
		// get data info
		List<Param> dataInfo = svc.getDataLaws(param);
		
		model.addAttribute("chartInfo", Utils.getListJSON(chartInfo).toString());
		model.addAttribute("dataInfo", dataInfo);
		model.addAttribute("total", dataInfo.size());
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		
		// set menuAuth
		HttpSession	session	= request.getSession();
		param.set("menu_id", request.getAttribute("currentMenuId"));
		param.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		String menuAuth = svc.getUserMenuAuth(param);
		param.set("menuAuth", menuAuth);
		model.addAttribute("menuAuth", menuAuth);
		
		return "monitoring/info302.front";
	}
	
	/**
	 * 보안 수준 현황 – 진단 항목별 보안 수준
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/monitoring/fis303/info", method=RequestMethod.POST)
	public String info303(final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		
		// get icon
		Param iconParam = getIconParam();
		param.set("iconParam", iconParam);
		model.addAttribute("iconParam", iconParam);
		
		// get data info
		List<Param> dataInfo = svc.getDataDomain(param);
		
		model.addAttribute("dataInfo", dataInfo);
		model.addAttribute("total", dataInfo.size());
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		
		// set menuAuth
		HttpSession	session	= request.getSession();
		param.set("menu_id", request.getAttribute("currentMenuId"));
		param.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		String menuAuth = svc.getUserMenuAuth(param);
		param.set("menuAuth", menuAuth);
		model.addAttribute("menuAuth", menuAuth);
		
		return "monitoring/info303.front";
	}
	
	
	
	/**
	 * 보안 구성도 – 국내 보안 구성도
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/monitoring/fis310/info", method=RequestMethod.POST)
	public String info310(final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		return info(request, model ,param);
	}
	
	/**
	 * 보안 구성도 – 국외 보안 구성도
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/monitoring/fis320/info", method=RequestMethod.POST)
	public String info320(final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		param.set("map_id", "M005");
		return info(request, model ,param);
	}
	
	/**
	 * 보안 구성도 – 수탁사 보안 구성도
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/monitoring/fis330/info", method=RequestMethod.POST)
	public String info330(final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		param.set("map_id", "M006");
		return info(request, model ,param);
	}
	
	/**
	 * 보안 구성도 – 국내 보안 구성도
	 * @param request
	 * @param map
	 * @return
	 */
	public String info(final HttpServletRequest request, final ModelMap model, Param param) throws Exception {
		if(param.get("map_id").isEmpty()){
			param.set("map_id",DEFAULT_MAP_ID);
		}
		Param info = svc.getSecuConfigDiag(param);
		
		model.addAttribute("info", info);
		if(!info.get("SAVE_FILE_NM").isEmpty()){
			String imagePath = IMAGE_PATH + info.get("SAVE_FILE_NM") + IMAGE_EXTSN;
			model.addAttribute("imagePath", imagePath);
		}			
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		
		// set menuAuth
		HttpSession	session	= request.getSession();
		param.set("menu_id", request.getAttribute("currentMenuId"));
		param.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		String menuAuth = svc.getUserMenuAuth(param);
		param.set("menuAuth", menuAuth);
		model.addAttribute("menuAuth", menuAuth);
		
		String rtnUrl = "";
		switch (info.get("MAP_ID")) {
		case "M001":
		case "M002":
		case "M003":
		case "M004":
			rtnUrl = "monitoring/info310.front";
			break;
		case "M005":
			rtnUrl = "monitoring/info320.front";
			break;
		case "M006":
			rtnUrl = "monitoring/info330.front";
			break;
		}
		return rtnUrl;
	}
	
	/**
	 * 보안 구성도 – 국내 보안 구성도 업로드
	 * @param model
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/monitoring/fis310/upload")
	@ResponseBody
	public String upload310(MultipartHttpServletRequest response, final HttpServletRequest request, ModelMap model) throws Exception {
		return upload(response, request, model);
	}
	
	/**
	 * 보안 구성도 – 국내 보안 구성도 업로드
	 * @param model
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/monitoring/fis320/upload")
	@ResponseBody
	public String upload320(MultipartHttpServletRequest response, final HttpServletRequest request, ModelMap model) throws Exception {
		return upload(response, request, model);
	}
	
	/**
	 * 보안 구성도 – 국내 보안 구성도 업로드
	 * @param model
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/monitoring/fis330/upload")
	@ResponseBody
	public String upload330(MultipartHttpServletRequest response, final HttpServletRequest request, ModelMap model) throws Exception {
		return upload(response, request, model);
	}
	
	/**
	 * 업로드
	 * @param model
	 * @throws Exception
	 */
	public String upload(MultipartHttpServletRequest response, final HttpServletRequest request, ModelMap model) throws Exception {

		JSONObject jsonObject = new JSONObject();
		HttpSession	session = request.getSession();

		String uid = Utils.nvl((String)session.getAttribute("uid"));
		String uname = Utils.nvl((String)session.getAttribute("uname"));

		try {
			Param param = new Param(response);
			List<MultipartFile> mf = response.getFiles("reqUploadFile");
			byte[] bytes = mf.get(0).getBytes();
			
			param.set("src_file_data", bytes);
			param.set("upd_id", uid);
			param.set("upd_nm", uname);
			svc.updateSecuConfigDiag(param);
			
			jsonObject.put("result", true);
		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}
	@RequestMapping(value="/front/internal/monitoring/fis310/imgView", produces="text/plain;charset=UTF-8")
	public void imgView310(HttpServletRequest request, HttpServletResponse response) throws IOException{
		blobToImgView(request, response);
	}
	@RequestMapping(value="/front/internal/monitoring/fis320/imgView", produces="text/plain;charset=UTF-8")
	public void imgView320(HttpServletRequest request, HttpServletResponse response) throws IOException{
		blobToImgView(request, response);
	}
	@RequestMapping(value="/front/internal/monitoring/fis330/imgView", produces="text/plain;charset=UTF-8")
	public void imgView330(HttpServletRequest request, HttpServletResponse response) throws IOException{
		blobToImgView(request, response);
	}
	
	 public void blobToImgView(HttpServletRequest request, HttpServletResponse response) throws IOException{
		 Param	param	= new Param(request);
		 InputStream is = null;
        
		 try {
			 
        	if(param.get("map_id").isEmpty()){
    			param.set("map_id",DEFAULT_MAP_ID);
    		}
    		HashMap<String, Object> info = svc.getSecuConfigDiag(param);
    		
            String contentType = "image/png";
            response.setContentType(contentType);
            
            Blob blob = (Blob)info.get("SRC_FILE_DATA");
			response.setContentLength((int) blob.length());
			
			is = blob.getBinaryStream();
			
            ServletOutputStream os = response.getOutputStream();
            int binaryRead;
            
            while ((binaryRead = is.read()) != -1)    {
                os.write(binaryRead);
            }
 
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            is.close();
        }
    }
	
	public Param getIconParam(){
		// get level icon 
		List<CodeInfo> icon = svc.getUseCodeList("SECU_LEVEL_ICON");
		Param iconParam = new Param();
		for (CodeInfo codeInfo : icon) {
			iconParam.set(codeInfo.getCode(),codeInfo.getName());
		}
		return iconParam; 
	}
}
