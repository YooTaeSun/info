package com.softworks.springframework.web.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.utils.Utils;

@Controller
public class ErrorController extends BaseController {

	private	final	String	siteAdminTelno	= Property.getProperty("site.admin.telno");
	private	final	String	siteAdminName	= Property.getProperty("site.admin.name");
	
	/**
	 * Error View Message
	 * @param request
	 * @param errorCode
	 * @param errorMessage
	 * @return
	 */
	private String sendError(final HttpServletRequest request, final int errorCode, final String errorMessage) {
		String adminName = siteAdminName;
		try {
//			System.out.println("0 : " + siteAdminName);
//			System.out.println("1 : " + new String(siteAdminName.getBytes(), "UTF-8"));
//			System.out.println("2 : " + new String(siteAdminName.getBytes(), "ISO-8859-1"));
//			System.out.println("3 : " + new String(siteAdminName.getBytes(), "EUC-KR"));
//			System.out.println("4 : " + new String(siteAdminName.getBytes("UTF-8"), "ISO-8859-1"));
//			System.out.println("5 : " + new String(siteAdminName.getBytes("UTF-8"), "EUC-KR"));
//			System.out.println("6 : " + new String(siteAdminName.getBytes("ISO-8859-1"), "UTF-8")); // Local
//			System.out.println("7 : " + new String(siteAdminName.getBytes("ISO-8859-1"), "EUC-KR"));
//			System.out.println("8 : " + new String(siteAdminName.getBytes("EUC-KR"), "UTF-8"));
//			System.out.println("9 : " + new String(siteAdminName.getBytes("EUC-KR"), "ISO-8859-1"));
			adminName = new String(siteAdminName.getBytes("ISO-8859-1"), "UTF-8");
		} catch (Exception e) {}
		request.setAttribute("siteAdminTelno", siteAdminTelno);
		request.setAttribute("siteAdminName", adminName);
		request.setAttribute("errorCode", errorCode);
		request.setAttribute("errorMessage", errorMessage);
		
		return "error";
	}
	
	@RequestMapping(value="/error")
	public String error(final HttpServletRequest request, final HttpServletResponse response, final Throwable t) {
		return sendError(request, response.getStatus(), t.getMessage());
	}

	/**
	 * 203 Error
	 * @param request
	 * @return
	 */	
	@RequestMapping(value="/error/NonContent")
	public String nonContent(final HttpServletRequest request) {
		return sendError(request, 204, "사용자 요청를 처리했지만 전송할 데이터를 찾을수 없습니다.");
	}
	
	/**
	 * 400 Error
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/error/badRequest")
	public String badRequest(final HttpServletRequest request) {
		return sendError(request, 400, "잘못된 요청입니다.");
	}
	
	@RequestMapping(value="/error/wrongApproach")
	public String accessWrongApproach(final HttpServletRequest request) {
		return sendError(request, 405, "잘못된 페이지 접근 요청입니다.");
	}
	
	/**
	 * 404 Error
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/error/pageNotFound")
	public String pageNotFound(final HttpServletRequest request) {
		return sendError(request, 404, "찾으시는 페이지가 존재하지 않습니다.");
	}
	
	/**
	 * 500 Error
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/error/pageError")
	public String pageError(final HttpServletRequest request) {
		return sendError(request, 500, "페이지에 오류가 있습니다.");
	}

	/**
	 * 403 Error
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/error/accessDenied")
	public String accessDenied(final HttpServletRequest request) {
		return sendError(request, 403, "페이지 접근 권한이 없습니다.");
	}
	
	/**
	 * 550 Error
	 */
	@RequestMapping(value="/error/permissionDenied")
	public String permissionDenied(final HttpServletRequest request) {
		return sendError(request, 550, "권한이 불충분 합니다. 로그인 후에 이용해 주세요.");
	}

	/**
	 * Authentication Error
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/error/sessionExpired")
	public String sessionExpired(final HttpServletRequest request) {
		return Utils.sendMessage(request, "세션이 만료되었 습니다.", "/");
	}

	@RequestMapping(value="/error/sessionTimeout")
	public String sessionTimeout(final HttpServletRequest request) {
		return Utils.sendMessage(request, "사용자의 요청이 없어 보안을 위해 자동으로 로그아웃 되었습니다.", "/");
	}

	@RequestMapping(value="/error/authenticationError")
	public String authenticationError(final HttpServletRequest request) {
		return Utils.sendMessage(request, "로그인 요청이 실패했습니다.");
	}

	@RequestMapping(value="/error/authenticationFail")
	public String authenticationFail(final HttpServletRequest request) {
		return Utils.sendMessage(request, "사용자 정보가 일치하지 않습니다.\\n로그인이 거부 되었습니다.", "/");
	}

	@RequestMapping(value="/error/authenticationFail_backoffice")
	public String authenticationFail_backoffice(final HttpServletRequest request) {
		return Utils.sendMessage(request, "사용자 정보가 일치하지 않습니다.\\n로그인이 거부 되었습니다.", "/backoffice/access");
	}

}