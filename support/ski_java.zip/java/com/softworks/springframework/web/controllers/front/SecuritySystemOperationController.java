package com.softworks.springframework.web.controllers.front;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.AttachFileService;
import com.softworks.springframework.web.services.MailSendService;
import com.softworks.springframework.web.services.front.SecuritySystemOperationService;

@SuppressWarnings("unchecked")
@Controller
public class SecuritySystemOperationController extends BaseController{

	@Autowired
	private	SecuritySystemOperationService			svc;
	
	@Autowired
	private MailSendService	mm ;
	
	@Autowired
	private	AttachFileService attachFileSvc;
	
	/**
	 * 보안시스템 정책 관리 목록
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/securitySystemOperation/fis250/list", method=RequestMethod.POST)
	public String list250(final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		int	total	= svc.getSecuSystemPolicyListCount(param);

		model.addAttribute("total", total);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("list", 0 < total ? svc.getSecuSystemPolicyList(param) : null);
		model.addAttribute("auditTypCdList",svc.getUseCodeList("SECU_AREA_CD"));
		model.addAttribute("SECU_AREA_CD",param.get("SECU_AREA_CD"));
		model.addAttribute("pageSizeChange", svc.getUseCodeList("PAGE_CHANGE"));
		
		// set menuAuth
		HttpSession	session	= request.getSession();
		param.set("menu_id", request.getAttribute("currentMenuId"));
		param.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		String menuAuth = svc.getUserMenuAuth(param);
		param.set("menuAuth", menuAuth);
		model.addAttribute("menuAuth", menuAuth);
		
		return "securitySystemOperation/securitySystemPolicyList.front";
	}
	
	/**
	 * 보안시스템 정책 상세
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/securitySystemOperation/fis251/detail", method=RequestMethod.POST)
	public String detail251(final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		
		// get secu system policy
		Param info = svc.getSecuSystemPolicyInfo(param);
		
		// get secu system policy detail
		List<Param> detailList = svc.getSecuSystemPolicyDetailList(param);

		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("info", info);
		model.addAttribute("detailTotal", detailList.isEmpty() ? 0 : detailList.size());
		model.addAttribute("detailList", detailList);
		model.addAttribute("auditTypCdList",svc.getUseCodeList("SECU_AREA_CD"));
		
		// set menuAuth
		HttpSession	session	= request.getSession();
		param.set("menu_id", request.getAttribute("currentMenuId"));
		param.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		String menuAuth = svc.getUserMenuAuth(param);
		param.set("menuAuth", menuAuth);
		model.addAttribute("menuAuth", menuAuth);
		return "WEB-INF/views/securitySystemOperation/securitySystemPolicyDetail";
	}
	
	@ResponseBody
	@RequestMapping(value="/front/internal/securitySystemOperation/fis250/regist", method=RequestMethod.POST)
	public  String regist250(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {
		
		HttpSession	session	= request.getSession();
		StringBuilder	json	= new StringBuilder();
		Param	    param	= new Param(map);
		boolean result = false;
		
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		
		try{
			json.append("{");
			if(!param.get("type").isEmpty() && param.get("type").equals("reg")){
				// check app id 
				if(svc.checkAppNo(param) < 1){
					json.append("\"chkAppNo\":").append("\"").append("Y").append("\"").append(",");
				}
				// check dup app id
				else if(svc.checkDupAppNo(param) > 0){
					json.append("\"dupAppNo\":").append("\"").append("Y").append("\"").append(",");
				}
				else{
					svc.insertSecuSystemPolicy(param);
					result = true;
				}
			}else{
				svc.updateSecuSystemPolicy(param);
				result = true;
			}
			json.append("\"result\"").append(":").append(result);
			json.append("}");
			
		} catch(Exception e) {
			logger.error("저장중 에러", e);
			
			json.append("{")
			.append("\"result\"").append(":").append(false);
			json.append("}");
		}
		
		return json.toString();
	}
	
	@ResponseBody
	@RequestMapping(value="/front/internal/securitySystemOperation/fis251/delete", method=RequestMethod.POST)
	public  String delete251(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {
		StringBuilder	json	= new StringBuilder();
		Param	    param	= new Param(map);
		boolean result = false;
		
		try{
			if(!param.get("secu_app_no").isEmpty()){
				Param info = svc.getSecuSystemPolicyInfo(param);
				
				param.set("policy_no", info.get("POLICY_NO"));
				svc.deleteSecuSystemPolicyDetail(param);
				
				svc.deleteSecuSystemPolicy(param);
				result = true;
			}			
			json.append("{").append("\"result\"").append(":").append(result);
			json.append("}");
		} catch(Exception e) {
			logger.error("저장중 에러", e);
			
			json.append("{")
			.append("\"result\"").append(":").append(false);
			json.append("}");
		}
		
		return json.toString();
	}
	
	@ResponseBody
	@RequestMapping(value="/front/internal/securitySystemOperation/fis252/regist", method=RequestMethod.POST)
	public  String regist252(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {
		
		HttpSession	session	= request.getSession();
		StringBuilder	json	= new StringBuilder();
		Param	    param	= new Param(map);
		
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		
		try{
			if(!param.get("secu_app_no").isEmpty() && !param.get("policy_no").isEmpty()){
				svc.updateSecuSystemPolicyDetail(param);
			}else{
				svc.insertSecuSystemPolicyDetail(param);
			}
			
			json.append("{")
			.append("\"result\"").append(":").append(true);
			json.append("}");
			
		} catch(Exception e) {
			logger.error("저장중 에러", e);
			
			json.append("{")
			.append("\"result\"").append(":").append(false);
			json.append("}");
		}
		
		return json.toString();
	}
	
	
	@ResponseBody
	@RequestMapping(value="/front/internal/securitySystemOperation/fis252/info", method=RequestMethod.POST)
	public  String info252(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {
		StringBuilder	json	= new StringBuilder();
		Param	    param	= new Param(map);
		boolean result = false;
		try{
			Param info = null;
			if(!param.get("secu_app_no").isEmpty()){
				info = svc.getSecuSystemPolicyDetailInfo(param);
				result = true;
			}
			
			json.append("{")
				.append("\"result\"").append(":").append(result);
			if(null != info)
				json.append(",\"info\"").append(":").append(info.toJSON());
			json.append("}");
		} catch(Exception e) {
			logger.error("저장중 에러", e);
			
			json.append("{")
			.append("\"result\"").append(":").append(false);
			json.append("}");
		}
		
		return json.toString();
	}
	
	@ResponseBody
	@RequestMapping(value="/front/internal/securitySystemOperation/fis252/delete", method=RequestMethod.POST)
	public  String delete252(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {
		StringBuilder	json	= new StringBuilder();
		Param	    param	= new Param(map);
		boolean result = false;
		
		try{
			if(!param.get("secu_app_no").isEmpty() && !param.get("policy_no").isEmpty()){
				svc.deleteSecuSystemPolicyDetail(param);
				result = true;
			}			
			json.append("{").append("\"result\"").append(":").append(result);
			json.append("}");
		} catch(Exception e) {
			logger.error("저장중 에러", e);
			
			json.append("{")
			.append("\"result\"").append(":").append(false);
			json.append("}");
		}
		
		return json.toString();
	}
	
	/**
	 * 보안시스템 정책 관리 - 엑셀저장
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/securitySystemOperation/fis250/list/excelDownload", method=RequestMethod.POST)
	public String excel250(final HttpServletRequest request, final ModelMap model) throws Exception {
        Param param = new Param(request);
		String type	= param.get("type");
		logger.info("---- type : " + type);

		int total	= svc.getSecuSystemPolicyListCount(param);

		param.set("page", 1);
		param.set("pageSize", total);

		List<Param> data = svc.getSecuSystemPolicyList(param);

		String[] category	= {"보안 영역",	"APP_NO", "보안시스템",	"기본 정책",	"모니터링 정책",	"로깅 정책",	"계정관리 정책",	"관리대상 여부"};
		String[] columns	= {"SECU_AREA_NM", "SECU_APP_NO", "SECU_APP_NM", "DEFAULT_POLICY", "MONITOR_POLICY", "LOGGING_POLICY", "ACCOUNT_POLICY", "MANAGED_YN"};
		int[]	 colWidth	= {20, 30, 50, 50, 50, 50, 20};

        model.addAttribute("filename", "보안시스템정책관리_"+Utils.getTimeStampString("yyyyMMdd"));
        model.addAttribute("chapter", "보안시스템정책관리");
        model.addAttribute("category", category);
        model.addAttribute("columns", columns);
        model.addAttribute("columnsWidth", colWidth);
		model.addAttribute("data", data);
		
		return "excelDownloadView";
	}
	
	
	
	
	/**
	 * 예외 정책 처리 현황 목록
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/securitySystemOperation/fis260/list", method=RequestMethod.POST)
	public String list260(final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		// set menuAuth
		HttpSession	session	= request.getSession();
		param.set("menu_id", request.getAttribute("currentMenuId"));
		param.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		String menuAuth = svc.getUserMenuAuth(param);
		param.set("menuAuth", menuAuth);
		
		String sdate = param.get("sdate");
		if(sdate.equals("")){
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			int nYear = calendar.get(Calendar.YEAR);
			String nSdate = nYear+"-01-01";
			String nEdate = nYear+"-12-31";
			param.set("sdate", nSdate);
			param.set("edate", nEdate);
		}
		
		if(!param.isNull("proc_result")) param.set("adminIdList", param.getValues("proc_result"));
		int	total	= svc.getExceptPolicyProcStatusListCount(param);
		model.addAttribute("total", total);
//		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("list", 0 < total ? svc.getExceptPolicyProcStatusList(param) : null);
		
		Param p = new Param();
		int totalSecuSystemPolicyListCount = svc.getSecuSystemPolicyListCount(p);
		p.set("page", 1);
		p.set("pageSize", totalSecuSystemPolicyListCount);
		
		model.addAttribute("secuSystemList", svc.getSecuSystemPolicyList(p));
		model.addAttribute("auditTypCdList",svc.getUseCodeList("SECU_AREA_CD"));
		model.addAttribute("pageSizeChange", svc.getUseCodeList("PAGE_CHANGE"));
		model.addAttribute("menuAuth", menuAuth);
		model.addAttribute("param", param);
		return "securitySystemOperation/exceptPolicyList.front";
	}
	
	/**
	 * 예외 정책 처리 현황 상세
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/securitySystemOperation/fis261/detail", method=RequestMethod.POST)
	public String detail261(final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	param	= new Param(request);
		param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		
		// get
		Param info = svc.getExceptPolicyProcStatusInfo(param);
			
		if(info.get("ATCH_FILE_ID").isEmpty() || info.get("ATCH_FILE_ID") == null){
			param.set("atch_file_id", attachFileSvc.getAtchFileId());
			// update attach_file_id
			svc.updateAttachFileId(param);
			attachFileSvc.insert(param);
			
			info = svc.getExceptPolicyProcStatusInfo(param);
		}
		
		// get secu system policy detail
		List<Param> list = svc.getExceptPolicyProcDetailList(param);
		List<Param> detailList = new ArrayList<Param>();
		Param applyParam = new Param();
		for (Param p : list) {
			applyParam.set("its_no", p.get("ITS_NO"));
			applyParam.set("secu_app_no", p.get("SECU_APP_NO"));
			applyParam.set("policy_no", p.get("POLICY_NO"));
			applyParam.set("policy_nm", p.get("POLICY_NM"));
			List<Param> applyEmpList = svc.getExceptPolicyApplyToList(applyParam);
			applyParam.set("applyEmpTotal", applyEmpList.size());
			p.set("applyEmpList", applyEmpList);
			detailList.add(p);
		}
		// get secu system 
		List<Param> secuSystemList = svc.getSecuSystemPolicyListAll(param);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("info", info.isEmpty() ? null : info);
		model.addAttribute("detailList", detailList);
		model.addAttribute("detailTotal", detailList.size());
		model.addAttribute("secuSystemList", secuSystemList);
		
		// set menuAuth
		param.set("menu_id", request.getAttribute("currentMenuId"));
		param.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		String menuAuth = svc.getUserMenuAuth(param);
		param.set("menuAuth", menuAuth);
		model.addAttribute("menuAuth", menuAuth);
		
		return "WEB-INF/views/securitySystemOperation/exceptPolicyDetail";
	}
	
	@ResponseBody
	@RequestMapping(value="/front/internal/securitySystemOperation/fis261/regist", method=RequestMethod.POST)
	public  String regist261(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {
		HttpSession	session	= request.getSession();
		StringBuilder	json	= new StringBuilder();
		Param	    param	= new Param(map);
		boolean result = false;
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		try{
			if(!param.get("its_no").isEmpty()){
				svc.updateExceptPolicyProcResult(param);
				result = true;
			}
			json.append("{").append("\"result\"").append(":").append(result);
			json.append("}");
			
		} catch(Exception e) {
			logger.error("저장중 에러", e);
			
			json.append("{")
			.append("\"result\"").append(":").append(false);
			json.append("}");
		}
		
		return json.toString();
	}
	
	@ResponseBody
	@RequestMapping(value="/front/internal/securitySystemOperation/fis260/delete", method=RequestMethod.POST)
	public  String delete260(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {
		StringBuilder	json	= new StringBuilder();
		Param	    param	= new Param(map);
		boolean result = false;
		
		try{
			if(!param.get("secu_app_no").isEmpty()){
				Param info = svc.getSecuSystemPolicyInfo(param);
				
				param.set("policy_no", info.get("POLICY_NO"));
				svc.deleteSecuSystemPolicyDetail(param);
				
				svc.deleteSecuSystemPolicy(param);
				result = true;
			}			
			json.append("{").append("\"result\"").append(":").append(result);
			json.append("}");
		} catch(Exception e) {
			logger.error("저장중 에러", e);
			
			json.append("{")
			.append("\"result\"").append(":").append(false);
			json.append("}");
		}
		
		return json.toString();
	}
	
	/**
	 * 예외 정책 처리 내역 등록 정보
	 * @param request
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/front/internal/securitySystemOperation/fis262/info", method=RequestMethod.POST)
	public  String info262(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {
		Param param	= new Param(map);
		JSONObject jsonObject = new JSONObject();
		try {
			// get secu system policy detail
			Param info = svc.getExceptPolicyProcDetailInfo(param);
			List<Param> applyEmpList = svc.getExceptPolicyApplyToList(param);
			List<Param> policyList = svc.getSecuSystemPolicyListAll(param);
			List<Param> policyDetailList = svc.getSecuSystemPolicyDetailList(param);
			
			jsonObject.put("param", param);
			jsonObject.put("info", info.toJSON());
			jsonObject.put("applyEmpList", Utils.getListJSON(applyEmpList).toString());
			jsonObject.put("policyList", Utils.getListJSON(policyList).toString());
			jsonObject.put("policyDetailList", Utils.getListJSON(policyDetailList).toString());
			jsonObject.put("result", true);
			
		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}
	
	@ResponseBody
	@RequestMapping(value="/front/internal/securitySystemOperation/fis262/regist", method=RequestMethod.POST)
	public  String regist262(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {
		
		HttpSession	session	= request.getSession();
		Param	    param	= new Param(map);
		JSONObject jsonObject = new JSONObject();
		boolean result = false;
		
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		
		
		try{
			Param secuPolicyDetailInfo  = svc.getSecuSystemPolicyDetailInfo(param);
			param.set("policy_nm",secuPolicyDetailInfo.get("POLICY_NM"));
			
			if(!param.get("type").isEmpty() && param.get("type").equals("reg")){
				Param exceptPolicyProcDetailInfo  = svc.getExceptPolicyProcDetailInfo(param);
				if(exceptPolicyProcDetailInfo != null){
					jsonObject.put("result", false);
					jsonObject.put("boolDup", true);
					return jsonObject.toString();
				}
				svc.insertExceptPolicyProcDetail(param);
			}else{
				svc.updateExceptPolicyProcDetail(param);
			}
			// delete EXCEPT_POLICY_APPLY_TO 
			svc.deleteAllExceptPolicyApplyTo(param);
			// set EXCEPT_POLICY_APPLY_TO
			String[] arrApplyEmpNo = param.get("apply_emp_no").trim().split("\n");
			for (String apply_emp_no : arrApplyEmpNo) {
				param.set("apply_emp_no", apply_emp_no.trim());
				Param empInfo = svc.getApplyEmpInfo(param);
				if(empInfo == null){
					param.set("apply_to_nm", "인사정보불일치");
					param.set("discord_yn", "Y");
				}else{
					param.set("apply_to_nm", empInfo.get("APPLY_TO_NM"));
					param.set("discord_yn", "N");
				}
				svc.insertExceptPolicyApplyTo(param);
				result = true;
			}
			
			jsonObject.put("result", result);
			
		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}
	
	@ResponseBody
	@RequestMapping(value="/front/internal/securitySystemOperation/fis262/delete", method=RequestMethod.POST)
	public  String delete262(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {
		Param	    param	= new Param(map);
		JSONObject jsonObject = new JSONObject();
		boolean result = false;
		try{
			if(!param.get("its_no").isEmpty() && !param.get("secu_app_no").isEmpty() && !param.get("policy_no").isEmpty()){
				svc.deleteExceptPolicyProcDetail(param);
				svc.deleteAllExceptPolicyApplyTo(param);
				result = true;
			}			
			jsonObject.put("result", result);
		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}
	
	@ResponseBody
	@RequestMapping(value="/front/internal/securitySystemOperation/fis261/changeProcResultStatus", method=RequestMethod.POST)
	public  String changeProcResultStatus(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {
		HttpSession	session	= request.getSession();
		Param	    param	= new Param(map);
		JSONObject jsonObject = new JSONObject();
		boolean result = false;
		Param mailRtnParam = null;
		
		try{
			if(!param.get("its_no").isEmpty()){
				
				param.set("proc_emp_no", Utils.nvl((String)session.getAttribute("uid")));
				param.set("proc_emp_nm", Utils.nvl((String)session.getAttribute("uname")));
				svc.updateProcResultStatusChange(param);
				Param info = svc.getExceptPolicyProcStatusInfo(param);
				jsonObject.put("info", info.toJSON());
				result = true;
				
				String proc_result_cd = param.get("proc_result_cd");
				
				// 상태 처리 완료 시 이메일 발송
				if(result && proc_result_cd.equals("C")){
					String recv_emp_no = info.get("REQ_EMP_NO");
					Param contentReplaceParam = new Param();
					contentReplaceParam.set("#ITS_NUM#", info.get("ITS_NO"));
					contentReplaceParam.set("#APLY_START_DAY#", info.get("START_DAY"));
					contentReplaceParam.set("#APLY_END_DAY#", info.get("END_DAY"));
					// get EXCEPT_POLICY_PROC_DETAIL 
					List<Param> exceptPolicyProcDetailList = svc.getExceptPolicyProcDetailList(param);
					
					String apply_cn = "";
					for (Param eList : exceptPolicyProcDetailList) {
						apply_cn += "* 적용 보안시스템 : "+eList.get("SECU_APP_NM")+"</br>";
						apply_cn += "* 적용 내용 : "+eList.get("PROC_DETAIL")+"</br></br>";
					}
					contentReplaceParam.set("#APLY_CN#", apply_cn);
					mailRtnParam = mm.sendMail2("EM08", recv_emp_no, contentReplaceParam);
					System.out.println("RESULT_MSG ============> "+mailRtnParam.get("RESULT_MSG")) ;
				}
			}			
			jsonObject.put("result", result);
		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}
	
	@ResponseBody
	@RequestMapping(value="/front/internal/securitySystemOperation/fis262/getSecuSystemPolicyDetailList", method=RequestMethod.POST)
	public  String getSecuSystemPolicyDetailList(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {
		Param	    param	= new Param(map);
		JSONObject jsonObject = new JSONObject();
		boolean result = false;
		
		try{
			if(!param.get("secu_app_no").isEmpty()){
				List<Param> policyList = svc.getSecuSystemPolicyDetailList(param);
				jsonObject.put("policyList", policyList.isEmpty() ? null : Utils.getListJSON(policyList).toString());
				result = true;
			}			
			jsonObject.put("result", result);
		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}
	
	/**
	 * 예외 정책 처리 현황 - 엑셀저장
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/securitySystemOperation/fis260/list/excelDownload", method=RequestMethod.POST)
	public String excel260(final HttpServletRequest request, final ModelMap model) throws Exception {
        Param param = new Param(request);
		String type	= param.get("type");
		logger.info("---- type : " + type);

		List<Param> data = svc.getExceptPolicyProcStatusListExcel(param);
		
		String[] category	= {"ITS요청번호",	"신청자",	"신청자 사번",	"처리결과",	"처리자",
				"처리일",	"적용시작일",	"적용종료일",	"적용 보안시스템",	"세부 정책명",	"적용 내용",	"대상자 사번",	"대상자명"};
		String[] columns	= { "ITS_NO", "REQ_EMP_NM", "REQ_EMP_NO", "PROC_RESULT_NM", "PROC_EMP_NM", "PROC_DT", "START_DAY", "END_DAY", "SECU_APP_NM", "POLICY_NM", "PROC_DETAIL" , "APPLY_EMP_NO", "APPLY_TO_NM"};
		int[]	 colWidth	= {15, 10, 20, 10, 10, 
				30, 15, 15, 50, 30, 50, 20, 20};

        model.addAttribute("filename", "예외정책처리현황_"+Utils.getTimeStampString("yyyyMMdd"));
        model.addAttribute("chapter", "예외정책처리현황");
        model.addAttribute("category", category);
        model.addAttribute("columns", columns);
        model.addAttribute("columnsWidth", colWidth);
		model.addAttribute("data", data);
		
		return "excelDownloadView";
        
	}
}
