package com.softworks.springframework.web.controllers.front;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.CodeLoaderService.CodeInfo;
import com.softworks.springframework.web.services.backoffice.MetaLawService;
import com.softworks.springframework.web.services.front.IfAsmDbMasterService;
import com.softworks.springframework.web.services.front.IfAsmImthackingMasterService;
import com.softworks.springframework.web.services.front.IfAsmLawsysMasterService;
import com.softworks.springframework.web.services.front.IfAsmNetworkMasterService;
import com.softworks.springframework.web.services.front.IfAsmOsMasterService;
import com.softworks.springframework.web.services.front.IfAsmWasMasterService;
import com.softworks.springframework.web.services.front.IfAsmWebMasterService;


@Controller
public class IfAsmLawsysMasterController extends BaseController{

	@Autowired
	private	IfAsmLawsysMasterService svc;

	@Autowired
	private	MetaLawService metaLawSvc;

	@Autowired
	private	IfAsmOsMasterService IfAsmOsMasterSvc;

	@Autowired
	private	IfAsmWasMasterService IfAsmWasMasterSvc;

	@Autowired
	private	IfAsmWebMasterService IfAsmWebMasterSvc;

	@Autowired
	private	IfAsmDbMasterService IfAsmDbMasterSvc;

	@Autowired
	private	IfAsmImthackingMasterService IfAsmImthackingMasterSvc;

	@Autowired
	private	IfAsmNetworkMasterService IfAsmNetworkMasterSvc;




	/**
	 * 법/제도별 진단 현황  리스트(ajax)
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/diagnosis/lawsys/list",method=RequestMethod.POST)
	public String list( final HttpServletRequest request, final ModelMap model) throws Exception {

		Param	param	= new Param(request);

		param.put("target_year", Utils.nvl(param.get("target_year"), Utils.getTimeStampString("yyyy")));


		List<CodeInfo> lawSystemList =  new ArrayList<CodeInfo>();
		for (Param e : metaLawSvc.getLawSystemAllList(param)) {
			CodeInfo codeInfo = new CodeInfo();
			codeInfo.setCode(e.get("LS_ID"));
			codeInfo.setName(e.get("LS_ABBR_NM"));
			lawSystemList.add(codeInfo);
		}
		model.addAttribute("ls_id", Utils.nvl(param.get("ls_id")));//M_LAW_SYSTEM 관련 법/제도 리스트
		model.addAttribute("lawSystemList", lawSystemList);//M_LAW_SYSTEM 관련 법/제도 리스트

		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		return "diagnosis/lawsyseList.front";
	}

	/**
	 * 법/제도별 진단 현황  리스트(ajax)
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/diagnosis/lawsys/jsonList",method=RequestMethod.POST)
	@ResponseBody
	public String jsonList(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();

		try {
			Param param = new Param(map);

			jsonObject.put("list", svc.getAllList(param));
			jsonObject.put("result", true);

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}

	/**
	 * 법/제도별 진단 os detail 현황
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/diagnosis/lawsys/detail",method=RequestMethod.POST)
	public String osDetail( final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	param	= new Param(request);

		String type = param.get("type");
		String viewName = "";

		switch (type) {
		case "OS":
			model.put("title", "");
			viewName =  "WEB-INF/views/diagnosis/osDetail";
			break;
		case "WEBWAS":
			viewName =  "WEB-INF/views/diagnosis/webDetail";
			break;
		case "DB":
			viewName =  "WEB-INF/views/diagnosis/dbDetail";
			break;
		case "SECU": // 보안 솔루션 imthacking imthacking
			viewName =  "WEB-INF/views/diagnosis/imthackingDetail";
			break;
		case "APPL": // 보안 솔루션 imthacking imthacking
			viewName =  "WEB-INF/views/diagnosis/imthackingDetail";
			break;
		case "NW": // 보안 솔루션 imthacking imthacking
			viewName =  "WEB-INF/views/diagnosis/networkDetail";
			break;
		default:
			viewName =  "";
			break;
		}
		return viewName;

	}


	/**
	 * 법/제도별 진단 현황  상세(ajax)
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/front/internal/diagnosis/lawsys/detailList",method=RequestMethod.POST)
	@ResponseBody
	public String osDetailList(final HttpServletRequest request, @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();

		try {
			Param param = new Param(map);

			jsonObject.put("total", svc.getDetail(param));//통계

			String type = param.get("type");

			if ("OS".endsWith(type)) {
				jsonObject.put("list", IfAsmOsMasterSvc.getAllList(param));
			}else if ("WEBWAS".endsWith(type)) {
				jsonObject.put("list", IfAsmWebMasterSvc.getAllList(param));
			}else if ("DB".endsWith(type)) {
				jsonObject.put("list", IfAsmDbMasterSvc.getAllList(param));
			}else if ("SECU".endsWith(type)) {
				param.put("asset_class_cd", type);
				jsonObject.put("list", IfAsmImthackingMasterSvc.getAllList(param));
			}else if ("APPL".endsWith(type)) {
				param.put("asset_class_cd", type);
				jsonObject.put("list", IfAsmImthackingMasterSvc.getAllList(param));
			}else if ("NW".endsWith(type)) {
				jsonObject.put("list", IfAsmNetworkMasterSvc.getAllList(param));
			}


			jsonObject.put("result", true);

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}
}
