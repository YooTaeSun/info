package com.softworks.springframework.web.controllers.front;

import java.net.URLDecoder;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.ShaPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.front.MyService;

@Controller
public class MyController extends BaseController {

	@Autowired
	MyService	svc;
	
	private final	ShaPasswordEncoder	passwordEncoder	= new ShaPasswordEncoder(256);
	private	final	String				PASSWORD_SALT	= Property.getProperty("user.password.salt");
	
	@RequestMapping(value="/mypage/info", method=RequestMethod.POST)
	public String info(final HttpServletRequest request, final ModelMap model) throws Exception {
		Param	info	= svc.getInfo((String)request.getSession().getAttribute("uid"));
		
		if(null == info) return "redirect:/error/badRequest";
		
		model.addAttribute("info", info);
		model.addAttribute("groupList", svc.getAuthGroupCodeList());
		
		return "mypage/info.front";
	}
	
	@RequestMapping(value="/mypage/updateInfo", method=RequestMethod.POST)
	public String updateInfo(final HttpServletRequest request) {
		try {
			Param	param	= new Param(request);
					param.set("user_id", (String)request.getSession().getAttribute("uid"));
					param.set("passwd", passwordEncoder.encodePassword(param.get("passwd"), PASSWORD_SALT));

			svc.updateInfo(param);
			
			return Utils.sendMessage(request, "개인정보를 수정 했습니다.", "/mypage/info");
		} catch(Exception e) {
			logger.error("개인정보 수정중 오류", e);
		}
		
		return Utils.sendMessage(request, "개인정보 수정중 오류가 발생했습니다.");
	}
	
	@RequestMapping(value="/mypage/password", method=RequestMethod.POST)
	public String password() throws Exception {
		System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		return "mypage/password.front";
	}
	
	@RequestMapping(value="/mypage/updatePassword", method=RequestMethod.POST)
	public String updatePassword(final HttpServletRequest request) {
		try {
			Param	param	= new Param(request);
			/*	
			param.set("user_id", (String)request.getSession().getAttribute("uid"));
			param.set("passwd", passwordEncoder.encodePassword(param.get("passwd"), PASSWORD_SALT));
			param.set("password", passwordEncoder.encodePassword(param.get("password"), PASSWORD_SALT));
			*/
			svc.changePassword((String)request.getSession().getAttribute("uid"), passwordEncoder.encodePassword(param.get("passwd"), PASSWORD_SALT));		
			return Utils.sendMessage(request, "비밀번호를 변경 했습니다.", "/mypage/password");
		} catch(Exception e) {
			logger.error("패스워드 변경중 오류", e);
		}
		
		return Utils.sendMessage(request, "비밀번호 수정중 오류가 발생했습니다.");
	}
	
	@RequestMapping(value="/findAccount/certification", params="p", method=RequestMethod.GET)
	public String findAccountComplate(@RequestParam(value="p", required=true) final String parameter, final HttpServletRequest request) {
		try {
			Param		param	= new Param();

	//		String decString = URLDecoder.decode(parameter,"UTF-8");
			String decString = parameter;
			System.out.println("decString : "+decString);
			String[]	p		= Utils.decript(decString).split("&");
			for(int i = 0, count = p.length;i < count;i++) {
				int idx	= p[i].indexOf("=");
				param.set(p[i].substring(0, idx), p[i].substring(idx + 1));
			}
			
			logger.debug( "비밀번호 찾기 인증 Parameter ::::::: " + param );
			
			if(Property.getProperty("user.password.find.param").equals(param.get("tp"))) {
				param.set("passwd", passwordEncoder.encodePassword(param.get("ui"), PASSWORD_SALT));
				
//				if(svc.isCertificationKey(param))
					return Utils.sendMessage(request, "비밀번호가 초기화 되었습니다.", "/login");
			}
		} catch(Exception e) {
			logger.error("비밀번호 찾기 완료처리중 에러", e);
			return Utils.sendMessage(request, "비밀번호 초기화중 오류가 발생했습니다.");
		}
		
		return "redirect:/error/NonContent";
	}

}
