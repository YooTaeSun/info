package com.softworks.springframework.web.controllers.front;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.softworks.springframework.tag.PagingTag;
import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.CodeLoaderService.CodeInfo;
import com.softworks.springframework.web.services.front.EmployeeService;
import com.softworks.springframework.web.services.front.OrganizationService;


@Controller
public class OrganizationController extends BaseController{

	@Autowired
	private	OrganizationService organizationSvc;

	@Autowired
	private	EmployeeService employeeSvc;

	/**
	 * 조직정보 리스트
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/orgEmp/list",method=RequestMethod.POST)
	public String list( final HttpServletRequest request, final ModelMap model) throws Exception {

		Param	param	= new Param(request);

		model.addAttribute("search_word", Utils.nvl((String)param.get("search_word")));

		HttpSession	session = request.getSession();

//		H57	울산아로마틱스㈜
//		H50	SK 종합화학
//		H13	SK 트레이딩인터내셔널
//		H10	SK 에너지
//		H60	SK 이노베이션
//		H17	SK 인천석유화학
//		H40	SK 루브리컨츠

		List<CodeInfo> comList =  new ArrayList<CodeInfo>();
		for (Param e : organizationSvc.getComList(param)) {
			CodeInfo codeInfo = new CodeInfo();
			codeInfo.setCode(e.get("SKCOMPANYCODE"));
			codeInfo.setName(e.get("SKCOMPANYNAME"));
			comList.add(codeInfo);
		}

		model.addAttribute("comList", comList);//M_LAW_SYSTEM 관련 법/제도 리스트

		String company = Utils.nvl((String)session.getAttribute("company"),"H40");
		//계열사 정보
		model.addAttribute("company", company);

		return "WEB-INF/views/popup/orgEmp";
	}


	/**
	 * 조직정보 리스트
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/orgEmp/orgAllTreeJsonList", method=RequestMethod.POST)
	@ResponseBody
	public String treeList(final HttpServletRequest request, final @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();

		try {
		String uid = Utils.nvl((String)session.getAttribute("uid"));
		String uname = Utils.nvl((String)session.getAttribute("uname"));
		String my_dept = Utils.nvl((String)session.getAttribute("dept_cd"),"");
		String my_com = Utils.nvl((String)session.getAttribute("company"),"");

		Param param = new Param(map);
		//default 자기 부서 , 없으면 sk이노베이션
		param.put("skcompanycode", Utils.nvl((String)param.get("search_company"),"H60"));

		param.put("my_dept", my_dept);
		param.put("my_com", my_com);


		List<Param> comList = organizationSvc.getComList(new Param());
		LinkedHashMap<String, Object> companyMap = new LinkedHashMap<String, Object>();
		LinkedHashMap<String, Object> companyTeamMap = new LinkedHashMap<String, Object>();

		String skcompanycode ="";
		if(comList != null && comList.size() > 0) {

			Param comParam = null;

			for (int ci = 0; ci < comList.size(); ci++) {
				comParam = comList.get(ci);
				skcompanycode = comParam.get("SKCOMPANYCODE");
				param.put("skcompanycode", skcompanycode);
				List<Param> topDeptList =  organizationSvc.getTopDeptList(param);
				param.put("topDeptList", topDeptList);
				//조직도

				List<Param> treeList = organizationSvc.getTreeList(param);
				companyMap.put(skcompanycode, treeList);
				companyTeamMap.put(skcompanycode, treeList.stream().collect(Collectors.groupingBy(x->((Param)x).get("TEAMCODEMAIN"))));
			}
		}
		jsonObject.put("companyMap", companyMap);
		jsonObject.put("companyTeamMap", companyTeamMap);
		jsonObject.put("param", param);
		jsonObject.put("result", true);

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}

	/**
	 * 인사정보 리스트(ajax 요청)
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/orgEmp/employeeList", method=RequestMethod.POST)
	@ResponseBody
	public String employeeList(final HttpServletRequest request, final @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();

		try {
		String uid = Utils.nvl((String)session.getAttribute("uid"));
		String uname = Utils.nvl((String)session.getAttribute("uname"));
		String hq_dept = Utils.nvl((String)session.getAttribute("hq_dept"),"");
		String company = Utils.nvl((String)session.getAttribute("company"),"");

		Param param = new Param(map);

		//인사정보
		int	total	= employeeSvc.getListCount(param);
		List<Param> empList =  employeeSvc.getList(param);
		jsonObject.put("total", total);
		jsonObject.put("list", empList);

		if(total > 0) {
			String teamcodemain = Utils.nvl(param.get("teamcodemain"));
			String skcompanycode = Utils.nvl(param.get("skcompanycode"));

			PagingTag pagingTag = new PagingTag();
			pagingTag.setCallback("fn_empGoPage");
			pagingTag.setTotal(total);
			pagingTag.setPageSize(param.get("pageSize"));;
			pagingTag.setPage(param.get("page"));

			String paging = pagingTag.getPaingStr().replace("fn_empGoPage(", "fn_empGoPage(\""+skcompanycode+"\",\""+teamcodemain+"\",");
			logger.debug("paging >> " + paging);
			jsonObject.put("paging", paging);
		}

		jsonObject.put("result", true);

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}


}
