package com.softworks.springframework.web.controllers.front;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.CodeLoaderService;
import com.softworks.springframework.web.services.front.FrontBoardService;

@Controller
public class FrontBoardController extends BaseController{

	@Autowired
	private FrontBoardService svc;

	//private	final String	BOARD_ATTACH_PATH	= filePath + Property.getProperty("file.board"); //보안점검
	private	final String	BOARD_ATTACH_PATH	= filePath + "/board/";

	private void setDefaultParam(final HttpSession session, final Param param) throws Exception {
		param.set("writer", (String)session.getAttribute("uid"));
		param.set("company", (String)session.getAttribute("company"));
	}


	private String list(final Param param, final ModelMap model) throws Exception {
		int	total	= svc.getListCount(param);

		model.addAttribute("total", total);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("list", 0 < total ? svc.getList(param) : null);
		model.addAttribute("taskList",CodeLoaderService.CODE.get("TA_DOMAIN"));

		return "board/boardList.front";

	}

	@RequestMapping(value="/board/rms", method=RequestMethod.POST)
	public String rmsBoard(final HttpServletRequest request, final ModelMap model) throws Exception {

		HttpSession	session	= request.getSession();

		Param	param	= new Param(request);

		model.addAttribute("type", "rms");
		model.addAttribute("boardType", "RMS");

		param.set("isSuper", Utils.nvl((String)session.getAttribute("isSuper")));
		param.set("loginUser", Utils.nvl((String)session.getAttribute("uid")));
		param.set("boardType", "RMS");

		return list(param, model);
	}

	@RequestMapping(value="/board/rms/excel", method=RequestMethod.POST)
	public String rmsBoardExcel(final HttpServletRequest request, final ModelMap model) throws Exception {

		HttpSession	session	= request.getSession();

		Param param = new Param(request);
		param.set("isSuper", Utils.nvl((String)session.getAttribute("isSuper")));
		param.set("loginUser", Utils.nvl((String)session.getAttribute("uid")));
		param.set("boardType", "RMS");
		int	total	= svc.getListCount(param);

        String retunStr = Utils.sendMessage(request, "해당 조건에 검색된 내역이 없습니다.", "/board/rms"
                , Utils.base64DecodeHidden(Utils.base64Encode(param.toQueryString())));

        if(total > 0) {

            retunStr = "excelDownloadView";
            svc.getListExcel(param, model);
        }

        return retunStr;
	}

	@RequestMapping(value="/board/rms/form", method=RequestMethod.POST)
	public String rmsBoardForm(@RequestParam(value="seq", required=false) final Integer seq,
						 @RequestParam(value="queryString", required=false) final String query,
						 final ModelMap model,final HttpServletRequest request) throws Exception {
		model.addAttribute("hiddenQuery", Utils.base64DecodeHidden(query));
		Param	param	= new Param(request);
		Param boardInfo = null;
		if(0 < Utils.nevl(seq) && "modify".equals(param.getString("boardMode"))){
			boardInfo = svc.getBoardInfo(seq);
			String writer = boardInfo.getString("writer");
			String uid = (String)request.getSession().getAttribute("uid");
			if(!writer.equals(uid)){
				return Utils.sendMessage(request, "게시물 수정 권한이 없습니다.", "/board/rms", ""); //수정 완료후 목록으로 이동  by  2013.02.27 jgmik
			}
		}
		model.addAttribute("info", boardInfo);
		model.addAttribute("fileList",0 == Utils.nevl(seq) ? null :svc.getBoarFileList(seq));
		model.addAttribute("taskList",CodeLoaderService.CODE.get("TA_DOMAIN"));
		model.addAttribute("type", "rms");
		model.addAttribute("boardType", "RMS");
		model.addAttribute("filePath",filePath);
		model.addAttribute("queryString", query);


		return "board/boardForm.front";
	}

	@RequestMapping(value="/board/ta", method=RequestMethod.POST)
	public String taBoard(final HttpServletRequest request, final ModelMap model) throws Exception {

		HttpSession	session	= request.getSession();

		Param	param	= new Param(request);

		model.addAttribute("type", "ta");
		model.addAttribute("boardType", "TA");

		param.set("isSuper", Utils.nvl((String)session.getAttribute("isSuper")));
		param.set("loginUser", Utils.nvl((String)session.getAttribute("uid")));
		param.set("boardType", "TA");

		return list(param, model);
	}

	@RequestMapping(value="/board/ta/excel", method=RequestMethod.POST)
	public String taBoardExcel(final HttpServletRequest request, final ModelMap model) throws Exception {

		HttpSession	session	= request.getSession();

		Param param = new Param(request);
		param.set("isSuper", Utils.nvl((String)session.getAttribute("isSuper")));
		param.set("loginUser", Utils.nvl((String)session.getAttribute("uid")));
		param.set("boardType", "TA");
		int	total	= svc.getListCount(param);

        String retunStr = Utils.sendMessage(request, "해당 조건에 검색된 내역이 없습니다.", "/board/ta"
                , Utils.base64DecodeHidden(Utils.base64Encode(param.toQueryString())));

        if(total > 0) {
        	retunStr = "excelDownloadView";
            svc.getListExcel(param, model);
        }

        return retunStr;
	}

	@RequestMapping(value="/board/ta/form", method=RequestMethod.POST)
	public String taBoardForm(@RequestParam(value="seq", required=false) final Integer seq,
						 @RequestParam(value="queryString", required=false) final String query,
						 final ModelMap model,final HttpServletRequest request) throws Exception {
		model.addAttribute("hiddenQuery", Utils.base64DecodeHidden(query));
		Param	param	= new Param(request);
		Param boardInfo = null;
		if(0 < Utils.nevl(seq) && "modify".equals(param.getString("boardMode"))){
			boardInfo = svc.getBoardInfo(seq);
			String writer = boardInfo.getString("writer");
			String uid = (String)request.getSession().getAttribute("uid");
			if(!writer.equals(uid)){
				return Utils.sendMessage(request, "게시물 수정 권한이 없습니다.", "/board/ta", ""); //수정 완료후 목록으로 이동  by  2013.02.27 jgmik
			}
		}
		model.addAttribute("info", 0 == Utils.nevl(seq) ? null : svc.getBoardInfo(seq));
		model.addAttribute("fileList",0 == Utils.nevl(seq) ? null :svc.getBoarFileList(seq));
		model.addAttribute("taskList",CodeLoaderService.CODE.get("TA_DOMAIN"));
		model.addAttribute("type", "ta");
		model.addAttribute("boardType", "TA");
		model.addAttribute("filePath",filePath);
		model.addAttribute("queryString", query);


		return "board/boardForm.front";
	}

	@RequestMapping(value="/board/etc", method=RequestMethod.POST)
	public String etcBoard(final HttpServletRequest request, final ModelMap model) throws Exception {

		HttpSession	session	= request.getSession();

		Param	param	= new Param(request);

		model.addAttribute("type", "etc");
		model.addAttribute("boardType", "ETC");

		param.set("isSuper", Utils.nvl((String)session.getAttribute("isSuper")));
		param.set("loginUser", Utils.nvl((String)session.getAttribute("uid")));
		param.set("boardType", "ETC");

		return list(param, model);
	}

	@RequestMapping(value="/board/etc/form", method=RequestMethod.POST)
	public String etcBoardForm(@RequestParam(value="seq", required=false) final Integer seq,
						 @RequestParam(value="queryString", required=false) final String query,
						 final ModelMap model) throws Exception {
		model.addAttribute("hiddenQuery", Utils.base64DecodeHidden(query));
		model.addAttribute("info", 0 == Utils.nevl(seq) ? null : svc.getBoardInfo(seq));
		model.addAttribute("fileList",0 == Utils.nevl(seq) ? null :svc.getBoarFileList(seq));
		model.addAttribute("taskList",CodeLoaderService.CODE.get("TA_DOMAIN"));
		model.addAttribute("type", "etc");
		model.addAttribute("boardType", "ETC");
		model.addAttribute("filePath",filePath);
		model.addAttribute("queryString", query);

		return "board/boardForm.front";
	}

	@RequestMapping(value="/board/{type}/doInsert", method=RequestMethod.POST)
	public String boardInsert(@PathVariable("type") final String type, final MultipartHttpServletRequest request) {
		Param	param		= null;
		try {
			List<MultipartFile> files = request.getFiles("files");
			param	= new Param(request);
			setDefaultParam(request.getSession(), param);

			int boardSeq = svc.getBoardSeq();
			param.set("seq", boardSeq);

			svc.insertBoard(param);
			if(null != files && 0 < files.size()){
				saveFiles(files, param);
			}

			return Utils.sendMessage(request, "게시물을 작성 했습니다.", "/board/" + type, Utils.base64DecodeHidden(param.get("queryString")));
		} catch(Exception e) {
			logger.error("게시물 작성중 에러", e);
		}

		return Utils.sendMessage(request, "게시물 작성중 오류가 발생 했습니다.");
	}

	@RequestMapping(value="/board/{type}/doUpdate", method=RequestMethod.POST)
	public String boardUpdate(@PathVariable("type") final String type, final MultipartHttpServletRequest request) {
		Param	param		= null;

		try {
			List<MultipartFile> files = request.getFiles("files");
			param	= new Param(request);
			setDefaultParam(request.getSession(), param);
			if(!authCheck(param.getInt("seq"), param.getString("writer"))){
				return Utils.sendMessage(request, "게시물 수정 권한이 없습니다.", "/board/" + type + "", ""); //수정 완료후 목록으로 이동  by  2013.02.27 jgmik
			}

			String delFiles = param.get("delFileList");
			if(null != delFiles && !"".equals(delFiles)){
				String[] delFileArr = delFiles.split(",");
				param.set("delFileList", delFileArr);
				svc.deleteBoardFile(param);
			}
			svc.updateBoard(param);
			if(null != files && 0 < files.size()){
				saveFiles(files, param);
			}

			return Utils.sendMessage(request, "게시물을 수정했습니다.", "/board/" + type + "", ""); //수정 완료후 목록으로 이동  by  2013.02.27 jgmik
		} catch(Exception e) {
			logger.error("게시물 수정중 에러", e);
		}

		return Utils.sendMessage(request, "게시물 수정중 오류가 발생 했습니다.");
	}

	@RequestMapping(value="/board/{type}/doDelete", method=RequestMethod.POST)
	public String boardDelete(@PathVariable("type") final String type, final HttpServletRequest request) {
		Param	param	= new Param(request);

		try {
			param	= new Param(request);
			setDefaultParam(request.getSession(), param);
			if(!authCheck(param.getInt("seq"), param.getString("writer"))){
				return Utils.sendMessage(request, "게시물 수정 권한이 없습니다.", "/board/" + type + "", ""); //수정 완료후 목록으로 이동  by  2013.02.27 jgmik
			}
			param.set("status", "4");
			svc.deleteBoard(param);

			return Utils.sendMessage(request, "선택된 게시물을 삭제 했습니다.", "/board/" + type);
		} catch(Exception e) {
			logger.error("게시물 삭제중 에러", e);
		}

		return Utils.sendMessage(request, "게시물 삭제중 오류가 발생했습니다.");
	}

	private void saveFiles(List<MultipartFile> files,Param	param) throws IOException, Exception {

		int seq = param.getInt("seq");
		List<HashMap<String,Object>> fileList = new ArrayList<HashMap<String,Object>>();
		for (MultipartFile file : files) {
			HashMap<String,Object> fileMap = new HashMap<String,Object>();
			if(null != file && !file.isEmpty()){
				String saveFileName = UUID.randomUUID().toString().replaceAll("-", "");
				fileMap.put("board_seq", seq);
				fileMap.put("rgst_id", param.get("writer").toString());
				fileMap.put("add_file_name", file.getOriginalFilename());
				//fileMap.put("file_path", Property.getProperty("file.board")); //보안점검
				fileMap.put("file_path", "/board/");
				fileMap.put("save_file_name", saveFileName);
				fileList.add(fileMap);

				Utils.saveUploadFile(BOARD_ATTACH_PATH ,
						saveFileName, file.getBytes(), file.getSize(), file.getOriginalFilename(), false);
			}
		}
		if(null != fileList && 0 < fileList.size()){
			param.set("fileList", fileList);
			svc.insertBoardFile(param);
		}

	}

	private boolean authCheck(int seq,String uId) throws SQLException{
		boolean auth = false;
		Param result = svc.getBoardInfo(seq);
		String writer = result.getString("writer");
		if(null != writer && writer.equals(uId)){
			auth = true;
		}
		return auth;
	}


}
