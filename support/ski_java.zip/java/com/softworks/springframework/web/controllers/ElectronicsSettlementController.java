package com.softworks.springframework.web.controllers;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.JsonNode;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.softworks.springframework.property.Property;
import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.ElectronicsSettlementService;

@Controller
public class ElectronicsSettlementController extends BaseController {

	private	final String	SITE_URL	= Property.getProperty("open.api.settlement.url");
	private	final String	AUTH_TOKEN	= Property.getProperty("open.api.settlement.auth");


	@Autowired
	private	ElectronicsSettlementService	svc;

	/**
	 * 전자결제 내용 입력 popup
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/settlement/form")
	public String form(final HttpServletRequest request, ModelMap model) throws Exception {
		return "WEB-INF/views/settlement/form";
	}

	/**
	 * 전자결제 연계
	 * @param request
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/settlement/form/sendDoc", method=RequestMethod.POST)
	public @ResponseBody String sendDoc(final MultipartHttpServletRequest request) {
		StringBuffer retValue = new StringBuffer();

		HttpSession	session	= request.getSession();
		String uid		= Utils.nvl((String)session.getAttribute("uid"));
		String uname	= Utils.nvl((String)session.getAttribute("uname"));
		String company	= Utils.nvl((String)session.getAttribute("company"));

		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("reg_id", uid);
		map.put("reg_nm", uname);
		map.put("company", company);
		map.put("form_id", request.getParameter("form_id"));
		map.put("doc_title", request.getParameter("doc_title"));
		map.put("doc_content", request.getParameter("doc_content"));

		Param param = null;

//		DataOutputStream	dos = null;
		OutputStream		out	= null;
		BufferedReader		br	= null;;

		try {
			int itemId = svc.getItemId(null);
			map.put("item_id", itemId);

			param = new Param(map);

			svc.insertDoc(param);

			Map<String, MultipartFile> fileMap = request.getFileMap();
			MultipartFile file = fileMap.get("attachFile");
			String jsonData = makeJson(map, file.getOriginalFilename(), file.getBytes());
			System.out.println("jsonData : " + jsonData);

			URL url = new URL(this.SITE_URL);
//			URL url = new URL("http://localhost/settlement/form/test");
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setDoOutput(true);
			con.setDoInput(true);
			con.setRequestMethod("POST");
			con.setRequestProperty("Authorization", this.AUTH_TOKEN);
			con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
			//con.setRequestProperty("Content-Type", "application/json");

//			dos = new DataOutputStream(con.getOutputStream());
//			dos.writeBytes("jsonData=" + jsonData);
//			dos.close();

//			String paramstr = URLEncoder.encode("jsonData") + "=" + URLEncoder.encode(jsonData);
			String paramstr = "jsonData=" + URLEncoder.encode(jsonData);
			out = con.getOutputStream();
			out.write( paramstr.getBytes("UTF-8") );
			out.flush();
			out.close();

			int responseCode = con.getResponseCode();

			if (responseCode == 200) { // 정상 호출
				br = new BufferedReader(new InputStreamReader(con.getInputStream()));
			} else { // 에러 발생
				br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
			}

			String inputLine	= "";
			retValue = new StringBuffer();

			while ((inputLine = br.readLine()) != null) {
				retValue.append(inputLine);
			}

			br.close();
			System.out.println("retValue : " + retValue.toString());

			ObjectMapper mapper = new ObjectMapper();
			Map<String, Object> retMap = mapper.readValue(retValue.toString(), new TypeReference<Map<String, Object>>(){});

			if (retMap.get("Result").equals("SUCCESS")) {
				param.set("doc_id", retMap.get("Message"));
			} else {
				param.set("doc_id", "FAILURE");
			}
		} catch(Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("Result", "FAILURE");
			jsonObject.put("Message", e.getMessage());
			jsonObject.put("Detail", "");
			retValue.append(jsonObject.toString());

			param.set("doc_id", "FAILURE");
		} finally {
//			if (dos != null) try { dos.close(); } catch (Exception e) {}
			if (out != null) try { out.close(); } catch (Exception e) {}
			if (br != null) try { br.close(); } catch (Exception e) {}
		}

		svc.insertHist(param);

		return retValue.toString();
	}

	public String makeJson(HashMap<String, Object> map, String fileName, byte[] fileData) {
		StringBuffer sb = new StringBuffer();
		JSONObject paramJson = new JSONObject();

		paramJson.put("FormID", (String)map.get("form_id"));
		paramJson.put("LegacyItemID", String.valueOf(map.get("item_id")));
		paramJson.put("DocTitle", (String)map.get("doc_title"));
		paramJson.put("AuthorID", (String)map.get("reg_id"));
		paramJson.put("CompanyID", (String)map.get("company"));
		paramJson.put("KeepYear", "Default");
		paramJson.put("SecretLevel", "Default");
		paramJson.put("LangCode", "ko");
		paramJson.put("ContentType", "HTML");
		paramJson.put("Contents", ((String)map.get("doc_content")));
//		paramJson.put("AutoCommit", false);

		JSONArray	appList	= new JSONArray();
		JSONObject	appJson	= new JSONObject();
		appJson.put("TaskName", "emp0");
		appJson.put("UserID", (String)map.get("reg_id"));
		appList.add(appJson);

		paramJson.put("ApproverList", appList);

		JSONArray	attaList	= new JSONArray();

		if (fileName != null && fileName.length() > 0) {
			JSONObject	attaJson	= new JSONObject();
			attaJson.put("FileName", fileName);
			attaJson.put("UploadData", "[[FILE_DATA]]");
			attaList.add(attaJson);
		}

		paramJson.put("AttachList", attaList);

		String jsonStr = paramJson.toJSONString();
		System.out.println("jsonStr : " + jsonStr);
		jsonStr = changeSpecialCharacter(jsonStr);

		if (fileName != null && fileName.length() > 0) {
			String fileVal = new String(Base64.encodeBase64(fileData, false));
			//System.out.println("fileVal : " + fileVal);
			int idx = jsonStr.indexOf("[[FILE_DATA]]");
			sb.append(jsonStr.substring(0, idx));
			sb.append(fileVal);
			sb.append(jsonStr.substring(idx+13));

			return sb.toString();
		} else {
			return jsonStr;
		}
	}

	/*
	 * 전자결제에서 JSON Parsing 에러 발생하는 문자 제거
	 */
	public String changeSpecialCharacter(String strVal) {
		String jsonStr = strVal;

		jsonStr	= jsonStr.replaceAll("\r\n", "");
		jsonStr	= jsonStr.replaceAll("\r", "");
		jsonStr	= jsonStr.replaceAll("\n", "");
		jsonStr	= jsonStr.replaceAll("\\\\r\\\\n", "");
		jsonStr	= jsonStr.replaceAll("\\\\r", "");
		jsonStr	= jsonStr.replaceAll("\\\\n", "");
		jsonStr	= jsonStr.replaceAll("&nbsp;", "");
		jsonStr	= jsonStr.replaceAll("\\\\/", "/"); // JSONObject.toString 할 경우 / => \/ 로 변경되고 있음

		return jsonStr;
	}

//	public String makeJson(HashMap<String, Object> map, String fileName, byte[] fileData) {
//		StringBuffer paramJson = new StringBuffer();
//		paramJson.append("{");
//		paramJson.append("\"FormID\":\"").append(map.get("form_id")).append("\",");
//		paramJson.append("\"LegacyItemID\":\"").append(String.valueOf(map.get("item_id"))).append("\",");
//		paramJson.append("\"DocTitle\":\"").append(map.get("doc_title")).append("\",");
//		paramJson.append("\"AuthorID\":\"").append(map.get("reg_id")).append("\",");
//		paramJson.append("\"CompanyID\":\"").append(map.get("company")).append("\",");
//		paramJson.append("\"KeepYear\":\"Default\",");
//		paramJson.append("\"SecretLevel\":\"Default\",");
//		paramJson.append("\"LangCode\":\"ko\",");
//		paramJson.append("\"ContentType\":\"HTML\",");
//		paramJson.append("\"Contents\":\"").append(map.get("doc_content")).append("\",");
//
//		paramJson.append("\"ApproverList\":[{");
//		paramJson.append("\"TaskName\":\"emp0\",");
//		paramJson.append("\"UserID\":\"").append(map.get("reg_id")).append("\"");
//		paramJson.append("}],");
//
//		paramJson.append("\"AttachList\":[");
//
//		if (fileName != null && fileName.length() > 0) {
//			String fileVal = new String(Base64.encodeBase64(fileData, false));
//			System.out.println("fileVal : " + fileVal);
//			paramJson.append("{");
//			paramJson.append("\"FileName\":\"").append(fileName).append("\",");
//			paramJson.append("\"UploadData\":\"").append(fileVal).append("\"");
//			paramJson.append("}");
//		}
//
//		paramJson.append("]");
//		paramJson.append("}");
//
//		return paramJson.toString();
//	}

//	public String makeJson(HashMap<String, Object> map, String fileName, byte[] fileData) {
//		JSONObject paramJson = new JSONObject();
//		paramJson.put("FormID", map.get("form_id"));
//		paramJson.put("LegacyItemID", String.valueOf(map.get("item_id")));
//		paramJson.put("DocTitle", map.get("doc_title"));
//		paramJson.put("AuthorID", map.get("reg_id"));
//		paramJson.put("CompanyID", map.get("company"));
//		paramJson.put("KeepYear", "Default");
//		paramJson.put("SecretLevel", "Default");
//		paramJson.put("LangCode", "ko");
//		paramJson.put("ContentType", "HTML");
//		paramJson.put("Contents", map.get("doc_content"));
////		paramJson.put("AutoCommit", false);
//
//		JSONArray	appList	= new JSONArray();
//		JSONObject	appJson	= new JSONObject();
//		appJson.put("TaskName", "emp0");
//		appJson.put("UserID", map.get("reg_id"));
//		appList.add(appJson);
//
//		paramJson.put("ApproverList", appList);
//
//		JSONArray	attaList	= new JSONArray();
//
//		if (fileName != null && fileName.length() > 0) {
//			JSONObject	attaJson	= new JSONObject();
//			String fileVal = new String(Base64.encodeBase64(fileData, false));
//			System.out.println("fileVal : " + fileVal);
//			attaJson.put("FileName", fileName);
//			attaJson.put("UploadData", fileVal);
////			attaJson.put("UploadData", Base64.encodeBase64String(fileData));
////			attaJson.put("UploadData", new String(Base64.encodeBase64(fileData, false)));
////			attaJson.put("UploadData", fileData);
//			attaList.add(attaJson);
//		}
//
//		paramJson.put("AttachList", attaList);
//
//		return paramJson.toString();
//	}

//	public String makeJson(Param param, String fileName, byte[] fileData) {
//		JSONObject paramJson = new JSONObject();
//		paramJson.put("FormID", "AI00047");
//		paramJson.put("LegacyItemID", "00001");
//		paramJson.put("DocTitle", param.get("doc_title"));
//		paramJson.put("AuthorID", param.get("uid"));
//		paramJson.put("CompanyID", param.get("company"));
//		paramJson.put("KeepYear", "Default");
//		paramJson.put("SecretLevel", "Default");
//		paramJson.put("LangCode", "ko");
//		paramJson.put("ContentType", "HTML");
//		paramJson.put("Contents", param.get("doc_content"));
//		paramJson.put("AutoCommit", false);
//
//		JSONArray	appList	= new JSONArray();
//		JSONObject	appJson	= new JSONObject();
//		appJson.put("TaskName", "emp0");
//		appJson.put("UserID", param.get("uid"));
//		appList.add(appJson);
//
//		paramJson.put("ApproverList", appList);
//
//		JSONArray	attaList	= new JSONArray();
//		JSONObject	attaJson	= new JSONObject();
//		attaJson.put("FileName", fileName);
//		attaJson.put("UploadData", fileData);
//		attaList.add(attaJson);
//
//		paramJson.put("AttachList", attaList);
//
//		return paramJson.toJSONString();
//	}
//
//	/**
//	 * 전자결제 연계
//	 * @param request
//	 * @param map
//	 * @return
//	 */
//	@ResponseBody
//	@RequestMapping(value="/settlement/form/sendDoc", method=RequestMethod.POST)
//	public String sendDoc(final MultipartHttpServletRequest request) {
//		String retValue = new String();
//
//		HttpSession	session	= request.getSession();
//		String uid		= Utils.nvl((String)session.getAttribute("uid"));
//		String company	= Utils.nvl((String)session.getAttribute("company"));
//
//		HashMap<String, Object> map = new HashMap<String, Object>();
//		map.put("uid", uid);
//		map.put("company", company);
//		map.put("doc_title", request.getParameter("doc_title"));
//		map.put("doc_content", request.getParameter("doc_content"));
//		System.out.println("======================================== ");
//
//		HttpClient httpClient = null;
//
//		try {
//			Map<String, MultipartFile> fileMap = request.getFileMap();
//			MultipartFile file = fileMap.get("attachFile");
//			String jsonData = makeJson(map, file.getOriginalFilename(), file.getBytes());
//			System.out.println("jsonData : " + jsonData);
//
//			httpClient = new DefaultHttpClient();
//
//	        //List<NameValuePair> queryParams = new ArrayList<NameValuePair>();
//	        //queryParams.add(new BasicNameValuePair("jsonData", jsonData));
//			//UrlEncodedFormEntity entity = new UrlEncodedFormEntity(queryParams, "UTF-8");
//
//			HttpParams param = (HttpParams) new BasicHttpParams();
//			param.setParameter("jsonData", jsonData);
//
//			HttpResponse httpResponse;
//			HttpPost httpPost	= new HttpPost(this.SITE_URL);
//
//			httpPost.setHeader("Authorization", this.AUTH_TOKEN);
//			httpPost.setHeader("Content-type", "application/json; charset=utf-8");
//			//httpPost.setEntity(entity);
//			httpPost.setParams(param);;
//
//			httpResponse	= httpClient.execute(httpPost);
//
//			if(httpResponse.getEntity()!=null) {
//				retValue = EntityUtils.toString(httpResponse.getEntity());
//			}
//
//			System.out.println("retValue : " + retValue.toString());
//		} catch(Exception e) {
//			e.printStackTrace();
//			logger.error(e.getMessage());
//			JSONObject jsonObject = new JSONObject();
//			jsonObject.put("Result", "FAILURE");
//			jsonObject.put("Message", e.getMessage());
//			jsonObject.put("Detail", null);
//			retValue = jsonObject.toString();
//		} finally {
//			if (httpClient != null) try { httpClient.getConnectionManager().shutdown(); } catch (Exception e) {}
//		}
//
//		return retValue;
//	}

}
