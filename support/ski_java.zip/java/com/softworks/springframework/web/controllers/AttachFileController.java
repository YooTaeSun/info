package com.softworks.springframework.web.controllers;

import java.io.BufferedReader;
import java.io.EOFException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.SocketTimeoutException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.softworks.springframework.property.Property;
import com.softworks.springframework.utils.FileUtil;
import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.AttachFileDetailService;
import com.softworks.springframework.web.services.AttachFileService;

@SuppressWarnings("unchecked")
@Controller
public class AttachFileController extends BaseController {

	@Autowired
	AttachFileService	svc;

	@Autowired
	AttachFileDetailService	attachFileDetailSvc;

	final static String localFlag = Property.getProperty("local.flag");
	final static String fileRootPath	= (localFlag.equals("Y"))? Property.getProperty("file.root.path.win") : Property.getProperty("file.root.path.linux");
	final static String UPLOAD_LIMIT_SIZE     = Property.getProperty("file.upload.limit.size");//2048
	final static String DEFAULT_STORAGE	= Property.getProperty("file.default.storage");	//2000000000
	final static String uploadTmpPrefix = Property.getProperty("file.upload.temp");
	final static String uploadPrefix = Property.getProperty("file.upload.real");
	final static String dlmt = "/";

	/**
	 * fileupload
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/file/fileUpload", method=RequestMethod.POST)
	public String fileuploadView(ModelMap model) throws Exception {
		model.addAttribute("fileAllowExts", svc.getAllowFileExtStr());
		return "WEB-INF/views/common/fileUpload";
	}

	/**
	 * 첨부파일 업로드
	 * @param model
	 * @throws Exception
	 */
	@RequestMapping(value="/file/fileId")
	@ResponseBody
	public String fileId(MultipartHttpServletRequest response, final HttpServletRequest request, ModelMap model) throws Exception {

		JSONObject jsonObject = new JSONObject();

		try {
			jsonObject.put("atch_file_id", svc.getAtchFileId());
			jsonObject.put("result", true);
		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}

	/**
	 * 첨부파일 업로드
	 * @param model
	 * @throws Exception
	 */
	@RequestMapping(value="/file/uploadFile")
	@ResponseBody
	public String uploadFile(MultipartHttpServletRequest response, final HttpServletRequest request, ModelMap model) throws Exception {

		JSONObject jsonObject = new JSONObject();
		HttpSession	session = request.getSession();

		String uid = Utils.nvl((String)session.getAttribute("uid"));
		String uname = Utils.nvl((String)session.getAttribute("uname"));

		try {
			List<MultipartFile> fileList = response.getMultiFileMap().get("reqUploadFile");

			if(fileList == null || fileList.size() == 0) {
				throw new Exception("no upload file");
			}

			Param param = new Param(response);
			String atch_file_id = (String)param.get("parentId");

			if(atch_file_id.isEmpty()) {
				throw new Exception("no atch_file_id");
			}else {
				param.set("atch_file_id", atch_file_id);
			}
			param.set("uid", uid);
			param.set("uname", uname);

			String storageType = (String)param.get("storageType");
			List<Param> uploadList = null;
			if("DB".equals(storageType)) {
				uploadList = svc.uploadFileToDb(fileList, param);
			}else {
				uploadList = svc.uploadFile(fileList, param);
			}

			jsonObject.put("file", uploadList.get(0));
			jsonObject.put("param", param);
			jsonObject.put("result", true);
		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}

	@RequestMapping(value="/file/removeFile", method=RequestMethod.POST)
	@ResponseBody
	public String removeFile(final HttpServletRequest request, final @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();

		try {
			String uid = Utils.nvl((String)session.getAttribute("uid"));
			String uname = Utils.nvl((String)session.getAttribute("uname"));

			Param param = new Param(map);

			String atch_file_id = param.get("atch_file_id");

			if(atch_file_id.isEmpty()) {
				throw new Exception("no atch_file_id");
			}else {
				param.set("atch_file_id", atch_file_id);
			}

			List<Param> uploadList = svc.removeFile(param);
			jsonObject.put("result", true);

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}


	@RequestMapping(value="/file/updateFile", method=RequestMethod.POST)
	@ResponseBody
	public String updateFile(final HttpServletRequest request, final @RequestBody HashMap<String, Object> map) {

		HttpSession	session = request.getSession();
		JSONObject jsonObject = new JSONObject();

		try {
			String uid = Utils.nvl((String)session.getAttribute("uid"));
			String uname = Utils.nvl((String)session.getAttribute("uname"));

			Param param = new Param(map);
			param.put("uid", uid);
			param.put("uname", uname);

			String atch_file_id = param.get("atch_file_id");
			String file_sn = param.get("file_sn");

			if(atch_file_id.isEmpty()) {
				throw new Exception("no atch_file_id");
			}else if(file_sn.isEmpty()) {
				throw new Exception("no file_sn");
			}

			attachFileDetailSvc.update(param);
			jsonObject.put("result", true);

		} catch(Exception e) {
			logger.error(e.getMessage());
			jsonObject.put("result", false);
			jsonObject.put("msg", e.getMessage());
		}
		return jsonObject.toString();
	}

	/**
	 * 파일다운로드
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/file/download", method=RequestMethod.POST)
	@ResponseBody
	public ModelAndView fileDownload(final HttpServletRequest request, ModelMap model) throws Exception {

		Param param	= new Param(request);
		String type = Utils.nvl(param.get("type"));

		if("LOG".equals(type)) {

			Param fileInfo = attachFileDetailSvc.getDetail(param);

			if(fileInfo == null) {
				logger.error("[fileDownload LOG] 파일 다운로드  에러");
				throw new Exception("[fileDownload LOG] 파일 다운로드  에러");
			}

			model.addAttribute("filename", FileUtil.sanitizeFileNm(fileInfo.get("SRC_FILE_NM"))  + "_LOG.txt");
			model.addAttribute("content", Utils.nvl(fileInfo.get("REG_LOG")));
			return new ModelAndView("textFileDownloadView", model);

		}else if("BATCH".equals(type)) {

			HttpSession session = request.getSession();

			String uid = (String)session.getAttribute("uid");
			String uname = (String)session.getAttribute("uname");
			String email =  Utils.nvl((String)session.getAttribute("email"),"");

			String json = param.get("data");
			json = json.replace("^","\"");
			ObjectMapper mapper = new ObjectMapper();
			LinkedHashMap dataHashParam = mapper.readValue(json, new TypeReference<Map<String, String>>(){});
			Param dataParam = new Param(dataHashParam);

			dataParam.put("type", type);
			dataParam.put("uid", uid);
			dataParam.put("uname", uname);
			dataParam.put("email", email);

			Param fileInfo = svc.batchDownload(new Param(dataParam));

			if(fileInfo == null) {
				logger.error("[fileDownload BATCH] 파일 다운로드  에러");
				throw new Exception("[fileDownload BATCH] 파일 다운로드  에러");
			}

			model.addAttribute("fileRootPath", fileRootPath);
			model.addAttribute("fileInfo", fileInfo);
			return new ModelAndView("fileDownloadView", model);

		//보안증적관리현황 증빙자료 일괄 다운로드
		}else if("PROOF".equals(type)) {

			HttpSession session = request.getSession();

			String uid = (String)session.getAttribute("uid");
			String uname = (String)session.getAttribute("uname");
			String email =  Utils.nvl((String)session.getAttribute("email"),"");

			String json = param.get("data");
			json = json.replace("^","\"");
			ObjectMapper mapper = new ObjectMapper();
			LinkedHashMap dataHashParam = mapper.readValue(json, new TypeReference<Map<String, Object>>(){});
			Param dataParam = new Param(dataHashParam);

			dataParam.put("type", type);
			dataParam.put("uid", uid);
			dataParam.put("uname", uname);
			dataParam.put("email", email);

			Param fileInfo = svc.proofDownload(new Param(dataParam));

			if(fileInfo == null) {
				logger.error("[proofDownload BATCH] 파일 다운로드  에러");
				throw new Exception("[proofDownload BATCH] 파일 다운로드  에러");
			}

			model.addAttribute("fileRootPath", fileRootPath);
			model.addAttribute("fileInfo", fileInfo);
			return new ModelAndView("fileDownloadView", model);

		}else if("NO_HIST".equals(type)) {

			HttpSession session = request.getSession();

			String uid = (String)session.getAttribute("uid");
			String uname = (String)session.getAttribute("uname");
			String req_mail_addr =  Utils.nvl((String)session.getAttribute("req_mail_addr"),"");

			param.put("uid", uid);
			param.put("uname", uname);
			param.put("req_mail_addr", req_mail_addr);

			Param fileInfo = attachFileDetailSvc.getDetail(param);

			if(fileInfo == null) {
				logger.error("[fileDownload] 파일 다운로드  에러");
				throw new Exception("[fileDownload] 파일 다운로드  에러");
			}

			model.addAttribute("fileRootPath", fileRootPath);
			model.addAttribute("fileInfo", fileInfo);
			return new ModelAndView("fileDownloadView", model);

		}else {

			HttpSession session = request.getSession();

			String uid = (String)session.getAttribute("uid");
			String uname = (String)session.getAttribute("uname");
			String req_mail_addr =  Utils.nvl((String)session.getAttribute("req_mail_addr"),"");

			param.put("uid", uid);
			param.put("uname", uname);
			param.put("req_mail_addr", req_mail_addr);

			Param fileInfo = attachFileDetailSvc.getDetailHist(param);

			if(fileInfo == null) {
				logger.error("[fileDownload] 파일 다운로드  에러");
				throw new Exception("[fileDownload] 파일 다운로드  에러");
			}

			model.addAttribute("fileRootPath", fileRootPath);
			model.addAttribute("fileInfo", fileInfo);
			return new ModelAndView("fileDownloadView", model);
		}
	}




	@RequestMapping(value="/file/batch-upload-popup")
	public String batchUploadPopup(		@RequestParam(value="type",defaultValue="1") String type
										,	final HttpServletRequest request
										,	final HttpServletResponse response
										,	final ModelMap model				){
		HttpSession session = request.getSession();
		String user_id = (String)session.getAttribute("uid");

		Param param = new Param(request);

		String message = "" ;
		String changeUrl = "" ;
		String getUrl = new String(request.getRequestURL());

		param.set( "user_id", user_id);
		param.set( "root_id", param.get("parent_id"));

//		Param info= svc.getFolderInfo(param);
		Param info= new Param();

//		Param fileUseInfo	= svc.getFileUsageInfoByUser(param);
		Param arg = new Param();

		arg.set("pcode", "PTS_FILLTER_TYPE");
//		List<Param> list = svc.getList(arg);
//		String filterString = "";
//		for(int i=0; i<list.size(); i++){
//			Param codeInfo = list.get(i);
//
//			filterString += "."+codeInfo.get("name")+";";
//		}

		model.addAttribute("info",info);
		model.addAttribute("type",type);
		model.addAttribute("param",param);

		model.addAttribute("UPLOAD_LIMIT_SIZE",UPLOAD_LIMIT_SIZE);
//		String storageSize = session.getAttribute("storageSize")==null?"":(String)session.getAttribute("storageSize");
//		model.addAttribute("DEFAULT_STORAGE",storageSize.equals("")? DEFAULT_STORAGE: storageSize);
//		model.addAttribute("USE_FILE_SIZE",fileUseInfo.get("TOT_SIZE"));
//		model.addAttribute("FILE_FILTER_LIST",filterString);
////		model.addAttribute("EXTENSION_FILTERING",super.EXTENSION_FILTERING);
//
		return "WEB-INF/views/common/batchUploadPopup";
	}


	@RequestMapping(value="/FileCheck", method=RequestMethod.POST)
	public void FileCheck(final HttpServletRequest request,final HttpServletResponse response, final ModelMap model) throws Exception {

		Param param = new Param(request);
		// TODO Auto-generated method stub
		String ajaxUpdateResult ="";
		BufferedReader br = null;
		br = request.getReader();
		int b = 0;
		String fileKey = "";

		while((b = br.read())>-1){
			fileKey += (char)b;
		}
		br.close();
		String size = null;
		try{
//			String[] enc = new String[]{ "utf-8" , "euc-kr" ,"KSC5601" ,"ISO-8859-1" };
//			for(int i=0; i<enc.length; i++){
//				for(int j=0; j<enc.length; j++){
//					logger.debug("fileKey==>"+new String(fileKey.getBytes(enc[i]),enc[j]));
//				}
//			}

			fileKey = new String(fileKey.getBytes("ISO-8859-1"),"utf-8");
			String[] fileName = fileKey.split("↕");
			ajaxUpdateResult += "[";
			for(int i=0; i<fileName.length; i++){
				String path = uploadTmpPrefix;
				path = fileRootPath + File.separator + path ;
				logger.debug("===>>PATH >> "+path);
				File f = new File(path,fileName[i]);
				ajaxUpdateResult +="{\"name\":\""+fileName[i] + "\",\"size\":" + f.length()+"}";
				if(i != fileName.length-1) ajaxUpdateResult +=",";
			}
			ajaxUpdateResult += "]";

		}catch(Exception e){
			e.printStackTrace();
		}
		response.setCharacterEncoding("utf-8");
		response.setHeader("rsCode", "200");
		response.getWriter().print(ajaxUpdateResult);;
		logger.debug("/fileCheck result ==>"+ajaxUpdateResult);;
	}

	@RequestMapping(value="/file/batch-upload", method=RequestMethod.POST)
	public void batchUpload(final HttpServletRequest request,final HttpServletResponse response, final ModelMap model) throws Exception {

		Param param = new Param(request);
		ServletInputStream sis = null;
		FileOutputStream fos = null;
//        long timeStamp = Calendar.getInstance().getTimeInMillis();

		Calendar cal = Calendar.getInstance();
		String startTime = "";
		String endTime = "";
		long start = 0;
		long end = 0;
		start = cal.getTimeInMillis();

		try{
			startTime += cal.get(Calendar.HOUR_OF_DAY);
			startTime += " ";
			startTime += cal.get(Calendar.MINUTE);
			startTime += " ";
			startTime += cal.get(Calendar.SECOND);
			startTime += " ";
			startTime += cal.get(Calendar.MILLISECOND);

			int length = request.getContentLength();
			String saveFileName = request.getHeader("file-name");
			String hFileSize = request.getHeader("file-size");
			String hStartOffset = request.getHeader("startOffset");
			String hEndOffset = request.getHeader("endOffset");
			long startOffset = 0;
			long endOffset = 0;
			long fileSize = 0;
			try{
				startOffset = Long.parseLong(hStartOffset);
			}catch(Exception e){}
			try{
				endOffset = Long.parseLong(hEndOffset);
			}catch(Exception e){}
			try{
				fileSize = Long.parseLong(hFileSize);
			}catch(Exception e){}

			// hFileName = URLDecoder.decode(hFileName, "UTF-8");
			logger.debug("[batch-upload] hFileSize value = "+hFileSize);
			logger.debug("[batch-upload] startOffset / endOffset / length / fileSize = "+startOffset + " / " + endOffset +" / "+length + " / " + fileSize);;

			String fullPath = uploadTmpPrefix + dlmt + FileUtil.addPath() + dlmt +  saveFileName;
			File file = new File(FileUtil.createNewFile(fileRootPath + fullPath));

			logger.debug("[batch-upload] upload temp >> " + file);
			if(startOffset == 0){
				fos = new FileOutputStream(file);
			}else{
				fos = new FileOutputStream(file,true);
			}
			sis = request.getInputStream();
		//	long test = sis.skip(skipBytes);


			int len = 0;
			int count = 0;
			byte[] buf = new byte[512];
			while( (len = sis.read(buf, 0, 512)) != -1 ){
				fos.write(buf, 0, len);
				count++;
			}
			cal = Calendar.getInstance();
			end = cal.getTimeInMillis();

			if( endOffset == fileSize ){
//				Map<String,List<FileItem>> items = new ServletFileUpload(new DiskFileItemFactory()).parseParameterMap(request);
				String ajaxUpdateResult = saveFileName;
				response.setHeader("rsCode", "200");
				response.getWriter().print(ajaxUpdateResult);
			}else{
//				String ajaxUpdateResult = saveFileName;
				response.setHeader("rsCode", "201");
				long duration = end -start;
				response.setHeader("duration", duration+"");
				response.getWriter().print(endOffset);
			}
			endTime += cal.get(Calendar.HOUR_OF_DAY);
			endTime += " ";
			endTime += cal.get(Calendar.MINUTE);
			endTime += " ";
			endTime += cal.get(Calendar.SECOND);
			endTime += " ";
			endTime += cal.get(Calendar.MILLISECOND);
			logger.debug(" ==> ok "+(end - start) );

		}catch(EOFException eofe){
			response.setHeader("rsCode", "501");
			logger.debug("[batch-upload] pause...");
		}catch(SocketTimeoutException ste){
			response.setHeader("rsCode", "502");
			logger.debug("[batch-upload] socket time out...");
		}catch(Exception e){
			e.printStackTrace();
			response.setHeader("rsCode", "500");
			logger.debug("[batch-upload] error >> " + e.getMessage());
		}finally{
			sis.close();
			fos.flush();
			fos.close();
		}
	}


	 @RequestMapping(value="/file/batch-upload-result")
	 public String batchUploadResult(final HttpServletRequest request , final HttpServletResponse response , final ModelMap model) throws IOException {

		String retMsg = "";
		int errCnt = 0;
		String uploadEndTime = "";
		Date date = new Date();
		uploadEndTime = Utils.getTimeStampString(date);

		HttpSession session = request.getSession();
		String uid = (String)session.getAttribute("uid");
		String uname = (String)session.getAttribute("uname");

		Param param = new Param(request);

		String atch_file_id = param.get("parent_id");
		param.put("uid", uid);
		param.put("uname", uname);
		param.put("atch_file_id", atch_file_id);

		try {
			request.setCharacterEncoding("UTF-8");
			svc.batchUploadResult(param);

			retMsg = "파일 업로드가 완료되었습니다.";

		}catch(Exception e){
			logger.error("[batchUploadResult] >> " + e);
			retMsg = "파일 업로드 실패!";
		}

		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String html = "<html><head><script>alert('"+retMsg+"');opener.selectFolder('"+atch_file_id+"');self.close();</script></head></html>";
		out.println(html);

		return null;
	}	//end uploadResult



		/**
		 * 참부 파일 리스트(json 요청)
		 * @param request
		 * @param model
		 * @return
		 * @throws Exception
		 */
		@RequestMapping(value="/file/list", method=RequestMethod.POST)
		@ResponseBody
		public String list(final HttpServletRequest request, final @RequestBody HashMap<String, Object> map) {

			HttpSession	session = request.getSession();
			JSONObject jsonObject = new JSONObject();

			try {

				Param param = new Param(map);

				String is_site = Utils.nvl(param.get("is_site"),"N");

				//인사정보
				if("Y".equals(is_site)) {
					jsonObject.put("list", attachFileDetailSvc.fileSiteList(param));
				}else {
					jsonObject.put("list", attachFileDetailSvc.getAllList(param));
				}
				jsonObject.put("result", true);

			} catch(Exception e) {
				logger.error(e.getMessage());
				jsonObject.put("result", false);
				jsonObject.put("msg", e.getMessage());
			}
			return jsonObject.toString();
		}
}
