package com.softworks.springframework.web.controllers.front;

import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.backoffice.CodeService;
import com.softworks.springframework.web.services.backoffice.MetaCompanyService;
import com.softworks.springframework.web.services.backoffice.MetaLawService;
import com.softworks.springframework.web.services.backoffice.MetaSecurityEvalService;
import com.softworks.springframework.web.services.backoffice.SecurityAssetsService;
import com.softworks.springframework.web.services.front.FrontSecurityAssetsService;


@Controller
public class FrontAssetSecuController extends BaseController{
	

	@Autowired
	private	CodeService			       	 	codeService;
	
	@Autowired
	private	MetaCompanyService				metaCompanyService;
	
	@Autowired
	private	FrontSecurityAssetsService		frontSecurityAssetsService;
	
	@Autowired
	private	SecurityAssetsService			securityAssetsService;
	

	
	/**
	 * 보안시스템 자산 관리 - 화면(리스트)
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/asset/fis180/list", method=RequestMethod.POST)
	public String list180(final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	param	= new Param(request);
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		if("PortalAdmin".equals(Utils.nvl((String)session.getAttribute("group")))){
			param.set("admin_yn", "Y");
		}else{
			param.set("admin_yn", "N");
		}
		String sdate = param.get("sdate");
		if(sdate.equals("")){
			Calendar calendar = new GregorianCalendar(Locale.KOREA);
			int nYear = calendar.get(Calendar.YEAR);
			String nSdate = nYear+"-01-01";
			String nEdate = nYear+"-12-31";
			param.set("sdate", nSdate);
			param.set("edate", nEdate);
		}
		
		String search_eval_state_cd_arr = Utils.nvl(param.get("search_eval_state_cd_arr"));
		String[] search_eval_state_cd_arr2 = null;
		if(!search_eval_state_cd_arr.equals("")){
			search_eval_state_cd_arr2 = search_eval_state_cd_arr.split("\\,");
		}
		
		String search_eval_chk_cd_arr = Utils.nvl(param.get("search_eval_chk_cd_arr"));
		String[] search_eval_chk_cd_arr2 = null;
		if(!search_eval_chk_cd_arr.equals("")){
			search_eval_chk_cd_arr2 = search_eval_chk_cd_arr.split("\\,");
		}
		
		param.set("search_eval_state_cd_arr", search_eval_state_cd_arr2);
		param.set("search_eval_chk_cd_arr", search_eval_chk_cd_arr2);
		param.set("secu_system_yn","Y");  //  N : 정보시스템, Y : 보안시스템
		int	total	= frontSecurityAssetsService.getSecurityAssetsApplListCount(param);
		List<Param> list = frontSecurityAssetsService.getSecurityAssetsApplList(param);
		model.addAttribute("total", total);
		model.addAttribute("list", list);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		model.addAttribute("pageSizeChange", frontSecurityAssetsService.getUseCodeList("PAGE_CHANGE"));
		
		return "asset/secu/secuList.front";

	}
	
	/**
	 * 정보시스템 자산 관리 - 엑셀저장
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/asset/fis180/list/excel", method=RequestMethod.POST)
	public String excel180(final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param param = new Param(request);
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		if("PortalAdmin".equals(Utils.nvl((String)session.getAttribute("group")))){
			param.set("admin_yn", "Y");
		}else{
			param.set("admin_yn", "N");
		}
		param.set("secu_system_yn","Y");  //  N : 정보시스템, Y : 보안시스템
		int	total	= frontSecurityAssetsService.getSecurityAssetsApplListCount(param);
        
        String retunStr = Utils.sendMessage(request, "해당 조건에 검색된 내역이 없습니다.", "/front/asset/fis180/list"
                , Utils.base64DecodeHidden(Utils.base64Encode(param.toQueryString())));
        
        if(total > 0) {
        	
            retunStr = "excelDownloadView";
            frontSecurityAssetsService.getSecurityAssetsSecuListExcel(param, model);
        }
        
        return retunStr;
	}
	
	
	/**
	 * 정보시스템 자산 관리 - 상세화면(기본정보)
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/asset/fis181", method=RequestMethod.POST)
	public String form1( final HttpServletRequest request
			               , final ModelMap model) throws Exception {
		Param	param	= new Param(request);
//		String app_no = param.get("app_no");
		List<Param> ifItsMstApplList = securityAssetsService.getIfItsMstApplList(param);
		List<Param> vItsApplCompany = securityAssetsService.getVItsApplCompany(param);
		List<Param> vItsApplTech = securityAssetsService.getVItsApplTech(param);
		List<Param> ifItsMstApplDetailList = securityAssetsService.getIfItsMstApplDetailList(param);
		int ifItsMstApplDetailCount = securityAssetsService.getIfItsMstApplDetailCount(param);
		param.set("info_typ_cd", "B2C");
		Param vItsApplSecurityList_B2C = securityAssetsService.getVItsApplSecurityOne(param);
		param.set("info_typ_cd", "B2B");
		Param vItsApplSecurityList_B2B = securityAssetsService.getVItsApplSecurityOne(param);
		param.set("info_typ_cd", "MEMBER");
		Param vItsApplSecurityList_MEMBER = securityAssetsService.getVItsApplSecurityOne(param);
		param.set("info_typ_cd", "MEMBER_ETC");
		Param vItsApplSecurityList_MEMBER_ETC = securityAssetsService.getVItsApplSecurityOne(param);
		param.set("info_typ_cd", "VISITOR ");
		Param vItsApplSecurityList_VISITOR = securityAssetsService.getVItsApplSecurityOne(param);
		
		Param codeParam = new Param(request);
		codeParam.set("pcode", "COMPANY_CD");
		List<Param> codeList = codeService.getList(codeParam);
		
		List<Param> compnayBusiSiteAllList = metaCompanyService.getCompanyBusiSiteAllList(param);
		
		Param securityAssetsOne = securityAssetsService.getSecurityAssetsOne(param);
		
		if(securityAssetsOne != null){
			String busi_site_list = securityAssetsOne.get("BUSI_SITE_LIST");
			if(!busi_site_list.isEmpty()){
				Param companyParam = new Param(request);
				List<String>  p_busiSiteList = Arrays.asList(busi_site_list.split(","));
				companyParam.set("busiSiteList", p_busiSiteList);
				
				List<Param> compnayBusiSiteList = metaCompanyService.getCompanyBusiSiteAllList(companyParam);
				model.addAttribute("compnayBusiSiteList", compnayBusiSiteList);
			}
		}

		model.addAttribute("securityAssetsOne", securityAssetsOne);
		model.addAttribute("CODE_COMPANY_CD", codeList);
		model.addAttribute("compnayBusiSiteAllList", compnayBusiSiteAllList);
		
		model.addAttribute("ifItsMstApplList", ifItsMstApplList);
		model.addAttribute("vItsApplCompany", vItsApplCompany);
		model.addAttribute("vItsApplTech", vItsApplTech);
		model.addAttribute("ifItsMstApplDetailList", ifItsMstApplDetailList);
		model.addAttribute("ifItsMstApplDetailListCount", ifItsMstApplDetailList.size());
		model.addAttribute("ifItsMstApplDetailCount", ifItsMstApplDetailCount);
		model.addAttribute("b2c", vItsApplSecurityList_B2C);
		model.addAttribute("b2b", vItsApplSecurityList_B2B);
		model.addAttribute("member", vItsApplSecurityList_MEMBER);
		model.addAttribute("member_etc", vItsApplSecurityList_MEMBER_ETC);
		model.addAttribute("visitor", vItsApplSecurityList_VISITOR);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		
		//권한체크
		HttpSession	session	= request.getSession();
		Param authParam = new Param();
		authParam.set("menu_id", request.getAttribute("currentMenuId"));
		authParam.set("group_id", Utils.nvl((String)session.getAttribute("group")));
		authParam.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		String menuAuth = frontSecurityAssetsService.getUserMenuAuth(authParam);
		model.addAttribute("menuAuth", menuAuth);

		return "WEB-INF/views/asset/secu/secuBasic";
	}
	
	/**
	 * 자산 사용 회사별 사업장 등록
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/asset/fis181/update", method=RequestMethod.POST)
	public String update1(final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	    param	= new Param(request);
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		String	hiddenQuery	= null;
		String  msg = "";
		
		try{
			
			securityAssetsService.updateSecurityAssetsBusiSiteList(param);
			msg = "저장하였습니다";
			
			model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
			hiddenQuery	= "<input type='hidden' name='app_no' value='" + param.get("app_no") + "' />";	
			return Utils.sendMessage(request, msg, "/front/asset/fis181", hiddenQuery);
		} catch(Exception e) {
			logger.error("저장중 에러", e);
		}
		return Utils.sendMessage(request, "저장중 오류가 발생 했습니다.");
	}
	
	/**
	 * 정보시스템 자산 관리 - 상세화면(보안평가)
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/asset/fis182", method=RequestMethod.POST)
	public String form2( final HttpServletRequest request
			               , final ModelMap model) throws Exception {
		Param	param	= new Param(request);
		String  app_no = param.get("app_no");
		
		Param	paramOne	= new Param();
		paramOne.set("app_no", app_no);
		Param securityAssetsOne = securityAssetsService.getSecurityAssetsOne(paramOne);
		Param	evalParam	= new Param();
		evalParam.set("asset_seq", securityAssetsOne.get("ASSET_SEQ"));
		Param securityAssetsEvalOne = frontSecurityAssetsService.getSecurityAssetsEvalOne(evalParam);
		Param	metaEvalParam	= new Param();
		metaEvalParam.set("eval_grp_cd", securityAssetsOne.get("ASSET_TYP_CD"));
		metaEvalParam.set("asset_seq", securityAssetsOne.get("ASSET_SEQ"));
		List<Param> metaEvalAssetEvalList = frontSecurityAssetsService.getMetaEvalSecurityAssetsEvalList(metaEvalParam);
		
		model.addAttribute("securityAssetsOne", securityAssetsOne);
		model.addAttribute("securityAssetsEvalOne", securityAssetsEvalOne);
		model.addAttribute("metaEvalAssetEvalList", metaEvalAssetEvalList);
		model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
		
		//권한체크
		HttpSession	session	= request.getSession();
		Param authParam = new Param();
		authParam.set("menu_id", request.getAttribute("currentMenuId"));
		authParam.set("group_id", Utils.nvl((String)session.getAttribute("group")));
		authParam.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		String menuAuth = frontSecurityAssetsService.getUserMenuAuth(authParam);
		model.addAttribute("menuAuth", menuAuth);

		return "WEB-INF/views/asset/secu/secuAttr";
	}
	
	/**
	 * 정보시스템 자산 관리 - 상태변경(보안평가)
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/asset/fis182/change", method=RequestMethod.POST)
	public String change182(final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	    param	= new Param(request);
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		String	hiddenQuery	= null;
		String  msg = "";
		
		try{
			
			frontSecurityAssetsService.updateSecurityAssetsEvalService(param);
			msg = "변경하였습니다";
			
			model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
			hiddenQuery	= "<input type='hidden' name='app_no' value='" + param.get("app_no") + "' />";	
			return Utils.sendMessage(request, msg, "/front/asset/fis182", hiddenQuery);
		} catch(Exception e) {
			logger.error("변경중 에러", e);
		}
		return Utils.sendMessage(request, "변경중 오류가 발생 했습니다.");
	}
	
	/**
	 * 정보시스템 자산 관리 - 선택항목평가(보안평가)
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/asset/fis182/changeEval", method=RequestMethod.POST)
	public String changeEval182(final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	    param	= new Param(request);
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		String	hiddenQuery	= null;
		String  msg = "";
		
		try{
			
			String evalItemid_arr = Utils.nvl(param.get("evalItemid_arr"));
			String[] evalItemid_arr2 = null;
			if(!evalItemid_arr.equals("")){
				evalItemid_arr2 = evalItemid_arr.split("\\,");
			}
			param.set("evalItemid_arr", evalItemid_arr2);
			
			frontSecurityAssetsService.updateSecurityAssetsEvalListService(param);
			msg = "평가하였습니다";
			
			model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
			hiddenQuery	= "<input type='hidden' name='app_no' value='" + param.get("app_no") + "' />";	
			return Utils.sendMessage(request, msg, "/front/asset/fis182", hiddenQuery);
		} catch(Exception e) {
			logger.error("평가중 에러", e);
		}
		return Utils.sendMessage(request, "평가중 오류가 발생 했습니다.");
	}
	
}
