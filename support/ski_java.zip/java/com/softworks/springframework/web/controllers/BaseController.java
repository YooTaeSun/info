package com.softworks.springframework.web.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.front.PrivateInfoCompanyService;

public class BaseController {

//	protected final String		filePath	= Property.getProperty("file.dir"); //보안점검
	protected final String		filePath	= "/meta/upload";
	protected final Logger 		logger		= Logger.getLogger(getClass());

	public	static final String	ANALYZE_OPTION_PREFIX	= "ANL_OPTION_";
	public boolean	isManager	= false;
	public boolean	isSuper		=  false;

	@Autowired
	private	PrivateInfoCompanyService privateInfoCompanyService;

	//버튼 권한 조회
	protected String setBtnAuth(final HttpServletRequest request) {
		HttpSession	session	= request.getSession();
		Param authParam = new Param();
		authParam.set("menu_id", request.getAttribute("currentMenuId"));
		authParam.set("group_id", Utils.nvl((String)session.getAttribute("group")));
		authParam.set("user_id", Utils.nvl((String)session.getAttribute("uid")));
		return privateInfoCompanyService.getUserMenuAuth(authParam);
	}
}