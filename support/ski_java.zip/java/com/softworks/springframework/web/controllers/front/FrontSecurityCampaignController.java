package com.softworks.springframework.web.controllers.front;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.softworks.springframework.utils.Param;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.controllers.BaseController;
import com.softworks.springframework.web.services.backoffice.BbsBackofficeService;
import com.softworks.springframework.web.services.backoffice.SecurityCampaignService;


@Controller
public class FrontSecurityCampaignController extends BaseController{
	
	@Autowired
	private	SecurityCampaignService			securityCampaignService;
	
	@Autowired
	private	BbsBackofficeService			bbsBackofficeService;

	
	/**
	 * 보안 캠페인 - 화면
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/campaign/fis130/form", method=RequestMethod.POST)
	public String form130( final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	param	= new Param(request);
		
//		String userRegularityYn   = "1";           //정직원(1), 협력업체(2), 수탁사
//		String userName           = "테스트";        //사용자 이름
//		String userEmpNo          = "sc31579";     //사용자 사번
//		String userCompanyCd      = "H50";         //사용자 회사코드
//		String userBirth          = "1988.01.01";  //사용자 생년월일
		
		String userRegularityYn   = "";     //정직원(1), 협력업체(2), 수탁사
		String userName           = "";     //사용자 이름
		String userEmpNo          = "";     //사용자 사번
		String userCompanyCd      = "";     //사용자 회사코드
		String userBirth          = "1988.01.01";  //사용자 생년월일
		
		userRegularityYn = Utils.nvl((String)session.getAttribute("regularity_cd"));
		userName         = Utils.nvl((String)session.getAttribute("uname"));
		userEmpNo        = Utils.nvl((String)session.getAttribute("uid"));
		userCompanyCd    = Utils.nvl((String)session.getAttribute("company"));
//		userBirth        = Utils.nvl((String)session.getAttribute("uid"));
		
		//오늘날짜로 진행되고있는 캠페인조회
		String campaign_id = securityCampaignService.getSecurityCampaignToday(param);
		
		if(campaign_id != null){
			//게시물번호조회 - 캠페인상세조회
			Param detailParam = new Param();
			detailParam.set("campaign_id", campaign_id);
			detailParam.set("company_cd", userCompanyCd);
			detailParam.set("regularity_yn", userRegularityYn);
			Param detailOne = securityCampaignService.getSecurityCampaignDetailOne(detailParam);
			
			if(detailOne != null){
				//게시물조회
				detailOne.set("ntt_id", detailOne.get("NTT_ID"));
				Param detailBbsOne = bbsBackofficeService.getInfo(detailOne);
				
				//캠페인 확인 조회
				Param detailTargetParam = new Param();
				detailTargetParam.set("campaign_id", campaign_id);
				detailTargetParam.set("emp_no", userEmpNo);
				detailTargetParam.set("company_cd", userCompanyCd);
				detailTargetParam.set("regularity_yn", userRegularityYn);
				Param detailTargetOne = securityCampaignService.getSecurityCampaignDetailTargetOne(detailTargetParam);
				
				model.addAttribute("detailBbsOne",detailBbsOne);
				model.addAttribute("detailTargetOne",detailTargetOne);
				model.addAttribute("userName",userName);
				model.addAttribute("userBirth",userBirth);
			}
		}
		
		return "campaign/form.front";
	}
	
	
	/**
	 * 보안 캠페인 - 확인처리
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/front/internal/campaign/fis130/confirm", method=RequestMethod.POST)
	public String confirm130(final HttpServletRequest request, final ModelMap model) throws Exception {
		HttpSession	session	= request.getSession();
		Param	    param	= new Param(request);
		String      msg = "";
		param.set("reg_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("reg_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("upd_id", Utils.nvl((String)session.getAttribute("uid")));
		param.set("upd_nm", Utils.nvl((String)session.getAttribute("uname")));
		param.set("conn_ip", Utils.nvl((String)session.getAttribute("loginIp")));
		
		try{
			
			Param detailTargetOne = securityCampaignService.getSecurityCampaignDetailTargetOne(param);
			
			if(detailTargetOne == null){
				msg = "사번이 일치하지 않습니다.";
			}else{
				msg = "확인처리 되었습니다.";
				param.set("confirm_yn", "Y");
				securityCampaignService.updateSecurityCampaignDetailTarget(param);
			}

			model.addAttribute("queryString", Utils.base64Encode(param.toQueryString()));
			return Utils.sendMessage(request, msg, "/front/internal/campaign/fis130/form", Utils.base64DecodeHidden(param.get("queryString")));

		} catch(Exception e) {
			logger.error("저장중 에러", e);
		}
		return Utils.sendMessage(request, "확인처리중 오류가 발생 했습니다.");

	}
	
}
