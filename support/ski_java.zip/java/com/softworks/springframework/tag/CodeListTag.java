package com.softworks.springframework.tag;

import java.io.IOException;
import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.apache.log4j.Logger;

import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.CodeLoaderService.CodeInfo;

public class CodeListTag extends SimpleTagSupport {

	private	String			id;
	private	String			type;
	private	String			name;
	private String          htmlClass;
	
    private	List<CodeInfo>	code;

	private	int				width		= 0;
	private	String			select		= "";
	
	private	String			check;
	private	String			mandatory;
	
	public void setId(final String id) {
		this.id			= id;
	}
	
	public void setType(final String type) {
		this.type		= type;
	}
	
	public void setName(final String name) {
		this.name		= name;
	}
	
	public void setHtmlClass(final String htmlClass) {
        this.htmlClass = htmlClass;
    }

	
	public void setCode(final List<CodeInfo> code) {
		this.code		= code;
	}
	
	public void setWidth(final Integer width) {
		this.width		= null != width ? width : width;
	}
	
	public void setSelect(final String select) {
		this.select		= Utils.nvl(select, "");
	}
	
	public void setCheck(final String check) {
		this.check		= check;
	}
	
	public void setMandatory(final String mandatory) {
		this.mandatory	= mandatory;
	}
	
	@Override
    public void doTag() throws JspException, IOException {
		if(null == this.code || 0 >= this.code.size()) return;
		
		StringBuilder	code;
		
		try {
			switch(this.type) {
				case "select":
					code	= selectTypeList();
					break;
				case "selectNotAll":
					code	= selectTypeNotAllList();
					break;
				case "radio":
					code	= radioTypeList();
					break;
				case "checkbox":
					code	= checkTypeList();
					break;
				case "checkboxName":
					code	= checkTypeNameList();
					break;
				default:
					code	= valueTypeList();
			}
			
			getJspContext().getOut().write(code.toString());
		} catch(Exception e) {
			Logger.getLogger(getClass()).error("코드리스트 출력 오류", e);
		}
	}
	
	public StringBuilder selectTypeList() {
		StringBuilder	code	= new StringBuilder();
		
		code.append("<select ").append(null == this.id ? "" : "id=\"" + this.id + "\"").append(this.width <= 0 ? "" : "style=\"width:").append(this.width <= 0 ? "" : this.width+"px;\"").append(" name=\"").append(this.name).append("\" chk=\"").append(this.check)
		.append("\" class=\"").append(this.htmlClass).append("\"")
		.append(null != this.mandatory ? ("if=\"" + this.mandatory + "\"") : "").append(">")
				.append("<option value=\"\">- 선택 -</option>");
		for(int i = 0, count = this.code.size();i < count;i++) {
			CodeInfo	info	= this.code.get(i);
			
			code.append("<option value=\"").append(info.getCode()).append("\" ").append(this.select.equals(info.getCode()) ? "selected" : "").append(">")
					.append(info.getName())
				.append("</option>");
		}
		code.append("</select>");
		
		return code;
	}

	public StringBuilder selectTypeNotAllList() {
		StringBuilder	code	= new StringBuilder();
		
		code.append("<select ").append(null == this.id ? "" : "id=\"" + this.id + "\"").append(this.width <= 0 ? "" : "style=\"width:").append(this.width <= 0 ? "" : this.width+"px;\"").append(" name=\"").append(this.name).append("\" chk=\"").append(this.check)
		.append("\" class=\"").append(this.htmlClass).append("\"")
		.append(null != this.mandatory ? ("if=\"" + this.mandatory + "\"") : "").append(">");
		for(int i = 0, count = this.code.size();i < count;i++) {
			CodeInfo	info	= this.code.get(i);
			
			code.append("<option value=\"").append(info.getCode()).append("\" ").append(this.select.equals(info.getCode()) ? "selected" : "").append(">")
					.append(info.getName())
				.append("</option>");
		}
		code.append("</select>");
		
		return code;
	}
	
	public StringBuilder radioTypeList() {
		StringBuilder	code	= new StringBuilder();
		
		for(int i = 0, count = this.code.size();i < count;i++) {
			CodeInfo	info	= this.code.get(i);
			
			code.append("<label>")
					.append("<input type=\"radio\" class=\"input-ch rdo\" name=\"").append(this.name).append("\" value=\"").append(info.getCode()).append("\" ").append(this.select.equals(info.getCode()) ? "checked" : "").append(" /> ")
					.append(info.getName())
				.append("</label> ");
		}
		
		return code;
	}
	
	public StringBuilder checkTypeList() {
		String[]		select	= null == this.select || "".equals(this.select) ? null : this.select.split(",");
		StringBuilder	code	= new StringBuilder();
		
		for(int i = 0, count = this.code.size();i < count;i++) {
			CodeInfo	info	= this.code.get(i);
			
			code.append("<label>")
					.append("<input type=\"checkbox\" class=\"input-ch chk\" name=\"").append(this.name).append("\" value=\"").append(info.getCode()).append("\" ").append(Utils.inArray(select, info.getCode()) ? "checked" : "").append(" /> ")
					.append(info.getName())
				.append("</label> ");
		}
		
		return code;
	}
	
	public StringBuilder checkTypeNameList() {
		String[]		select	= null == this.select || "".equals(this.select) ? null : this.select.split(",");
		StringBuilder	code	= new StringBuilder();
		
		for(int i = 0, count = this.code.size();i < count;i++) {
			CodeInfo	info	= this.code.get(i);
			
			code.append("<label>")
					.append("<input type=\"checkbox\" class=\"input-ch chk\" name=\"").append(this.name).append("\" value=\"").append(info.getCode()).append("\" ").append(Utils.inArray(select, info.getName()) ? "checked" : "").append(" /> ")
					.append(info.getName())
				.append("</label> ");
		}
		
		return code;
	}
	
	public StringBuilder valueTypeList() {
		String[]		select	= this.select.split(",");
		StringBuilder	code	= new StringBuilder();
		
		for(int i = 0, count = this.code.size();i < count;i++) {
			if(Utils.inArray(select, this.code.get(i).getCode())) code.append(" / ").append(this.code.get(i).getName());
		}
		
		return code.delete(0, 3);
	}

}
