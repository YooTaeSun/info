package com.softworks.springframework.tag;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.tags.RequestContextAwareTag;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.utils.Param;
import com.softworks.springframework.web.services.AccessService;

public class CheckRoleBtnTag extends  RequestContextAwareTag {  
    
    private static final long serialVersionUID = 4575251597373864201L;
    
    private final String ADMIN_GROUP = Property.getProperty("site.admin.group");
    
    private AccessService svc;
    
    private String type;
    
    private String href;
    
    private String htmlClass;
    
    private String id;
    
    private String name;
    
    private String style;

    private String scriptFuncType;
    
    private String scriptFunc;
    
    private String btnText;
    
    private String menuId;
    
    public void setType(final String type) {
        this.type = type;
    }
    
    public void setHref(String href) {
        this.href = href;
    }
    
    public void setHtmlClass(final String htmlClass) {
        this.htmlClass = htmlClass;
    }

    public void setId(final String id) {
        this.id = id;
    }

    public void setName(final String name) {
        this.name = name;
    }
    
    public void setStyle(String style) {
        this.style = style;
    }
    
    public void setScriptFuncType(String scriptFuncType) {
        this.scriptFuncType = scriptFuncType;
    }

    public void setScriptFunc(final String scriptFunc) {
        this.scriptFunc = scriptFunc;
    }

    public void setBtnText(final String btnText) {
        this.btnText = btnText;
    }

    public void setMenuId(final String menuId) {
        this.menuId = menuId;
    }

    @Override
    protected int doStartTagInternal() throws Exception {
        
        if (svc == null) {
            WebApplicationContext ctx = getRequestContext().getWebApplicationContext();
            svc = ctx.getBean(AccessService.class);
            
        }
        
        HttpSession session = pageContext.getSession();
        
        String id = (String)session.getAttribute("uid");
        String group = (String)session.getAttribute("group");
        
        Param param = new Param();
        
        param.set("menuId", this.menuId);
        param.set("id", id);
        param.set("group", group);
        
        StringBuffer button = new StringBuffer();
        
        if(ADMIN_GROUP.equals(group) || svc.isWriteBtn(param) ) {
            
            if(this.type.equals("button")) {
            
                button = makeButtonHtml();
            
            } else  if(this.type.equals("a")) {
                
                button = makeATagHtml();
            
            } else  if(this.type.equals("hidden")) {
                
                button = makeATagHtml();
            
            }
            
        } else if( this.type.equals("hidden") ) {
            
            button = makeHideATagHtml();
        }
        
        pageContext.getOut().write(button.toString());
        
        return SKIP_BODY;
    }
    
    public StringBuffer makeButtonHtml() {
        
        StringBuffer button = new StringBuffer();
        
        button.append("<button type=\"").append(this.type).append("\" ").append(null == this.htmlClass ? "" : " class=\"" + this.htmlClass + "\"")
        .append(null == this.id ? "" : " id=\"" + this.id + "\"").append(null == this.name ? "" : " name=\"" + this.name + "\" ").append(null == this.style ? "" : " style=\"" + this.style + "\"")
        .append((null == this.scriptFuncType && null == this.scriptFunc) ? "" : this.scriptFuncType + "=\"" + this.scriptFunc + "\">")
        .append("<span>").append(this.btnText).append("</span></button>");
        
        return button;
    }
    
    public StringBuffer makeATagHtml() {
        
        StringBuffer aTag = new StringBuffer();
        
        aTag.append("<a ").append(null == this.href ? "" : " href=\"" + this.href + "\"").append(null == this.htmlClass ? "" : " class=\"" + this.htmlClass + "\"")
        .append(null == this.id ? "" : " id=\"" + this.id + "\"").append(null == this.name ? "" : " name=\"" + this.name + "\" ").append(null == this.style ? "" : " style=\"" + this.style + "\"")
        .append((null == this.scriptFuncType && null == this.scriptFunc) ? "" : this.scriptFuncType + "=\"" + this.scriptFunc + "\">")
        .append("<span>").append(this.btnText).append("</span></a>");
        
        return aTag;
    }
    
    public StringBuffer makeHideATagHtml() {
        
        StringBuffer aTag = new StringBuffer();
        
        aTag.append("<a ").append(null == this.href ? "" : " href=\"" + this.href + "\"").append(null == this.htmlClass ? "" : " class=\"" + this.htmlClass + " dn\"")
        .append(null == this.id ? "" : " id=\"" + this.id + "\"").append(null == this.name ? "" : " name=\"" + this.name + "\" ").append(null == this.style ? "" : " style=\"" + this.style + "\"")
        //.append((null == this.scriptFuncType && null == this.scriptFunc) ? "" : this.scriptFuncType + "=\"" + this.scriptFunc + "\">")
        .append("<span>").append(this.btnText).append("</span></a>");
        
        return aTag;
    }
}
