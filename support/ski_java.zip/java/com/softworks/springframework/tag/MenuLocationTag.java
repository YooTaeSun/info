package com.softworks.springframework.tag;

import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.services.MenuLoaderService;
import com.softworks.springframework.web.services.MenuLoaderService.MenuInfo;

public class MenuLocationTag extends SimpleTagSupport {
	
	@Override
    public void doTag() throws JspException, IOException {
    	HttpServletRequest	request	= (HttpServletRequest)getJspContext().getAttribute(PageContext.REQUEST);
    	boolean				isFront	= -1 == request.getRequestURI().indexOf("backoffice");
    	String				menuId	= (String)request.getAttribute("currentMenuId");
    	
    	if(null == menuId) {
    		if(!isFront)
    			getJspContext().getOut().write("<h1>Home</h1>");
    		
    		return;
    	}

    	Map<String, MenuInfo>	info	= isFront ? MenuLoaderService.FRONT_MENU_INFO : MenuLoaderService.ADMIN_MENU_INFO;
    	
    	String[]	menuName	= new String[4];
    	
    	for(int i = 0, cnt = menuId.length() / 3;i < cnt;i++) {
    		String	menu_id	= menuId.substring(0, 3 * (i + 1));

    		menuName[i]	= info.get(menu_id).getName();
//        	System.out.println("======================menuname : "+menuName[i].toString());
    	}
    	setLocation(getJspContext().getOut(), isFront, menuName);
	}
	
	public void setLocation(final JspWriter out, final boolean isFront, final String[] menu) throws JspException, IOException {
		StringBuilder	sb		= new StringBuilder();
		
		if(isFront) {
		    String currentStr = "";
		    
		    if(null != menu[2]) {
		        currentStr = menu[2]; 
		        menu[2] = "<li><a hre=\"#\">" + menu[2] + "</a></li>";
			    menu[1] = "<li><a hre=\"#\">" + menu[1] + "</a></li>";
		    } else if(null != menu[1]) {
		        currentStr = menu[1]; 
		        menu[1] = "<li><a hre=\"#\">" + menu[1] + "</a></li>";
		    } else {
		        currentStr = menu[0];
		    }
		    menu[0] =  "<li><a hre=\"#\">" + menu[0] + "</a></li>";

			sb.append("<div class='cont-tit'>\n")
			  .append("<h3>").append(currentStr).append("</h3>\n")
			  .append("</div><!-- //cont-tit -->\n")
			  .append("<div class='content-inner'>\n")
			  .append("<ul  class='navigation'>\n")
			  .append("<li>").append("<a href='/'>HOME</a></li>\n").append(Utils.implode(menu, " "))
			  .append("</ul>");		    

		} else {
			String currentStr = "";
		    
		    if(null != menu[2]) {
		        currentStr = menu[2]; 
		        menu[2] = "<li><a hre=\"#\">" + menu[2] + "</a></li>\n";
		    } else {
		        currentStr = menu[1];
		    }
		    menu[1] = "<li><a hre=\"#\">" + menu[1] + "</a></li>\n";
		    menu[0] =  "<li><a hre=\"#\">" + menu[0] + "</a></li>";
			
		    
			sb.append("<div class='cont-tit'>\n")
			  .append("<h3>").append(currentStr).append("</h3>\n")
			  .append("</div><!-- //cont-tit -->\n")
			  .append("<div class='content-inner'>\n")
			  .append("<ul  class='navigation'>\n")
			  .append("<li>").append("<a href='/backoffice'>HOME</a></li>\n").append(Utils.implode(menu, " "))
			  .append("</ul>");
		}

//    	System.out.println("======================menu sb : "+sb.toString());
		out.write(sb.toString());
	}

}
