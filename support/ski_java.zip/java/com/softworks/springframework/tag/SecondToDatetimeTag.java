package com.softworks.springframework.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.softworks.springframework.utils.Utils;

public class SecondToDatetimeTag extends SimpleTagSupport {

	private	long	second;
	
	public void setSecond(final String second) {
		if(-1 < second.indexOf(".")) {
			if(5 < Integer.parseInt(second.substring(second.indexOf(".") + 1)))
				this.second	= Long.parseLong(second.substring(0, second.indexOf("."))) + 1;
			else
				this.second	= Long.parseLong(second.substring(0, second.indexOf(".")));
		}
		else
			this.second	= Long.parseLong(second);
	}
	
	public void setSecond(final long second) {
		this.second	= second;
	}
	
	@Override
    public void doTag() throws JspException, IOException {
		getJspContext().getOut().write(Utils.getSecondToDatetime(this.second));
	}

}