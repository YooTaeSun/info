package com.softworks.springframework.tag;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.softworks.springframework.utils.Utils;

public class PagingTag extends SimpleTagSupport {
    private int		page;
	private int		total;
	private int		pageSize	= 10;
	private int		pageBlock	= 10;
    private	String	callback	= "goPage";
    private	boolean	isBackoffice= false;

    public void setIsBackOffice(boolean isBackoffice){
    	this.isBackoffice = isBackoffice;
    }
    public void setPage(final int page) {
    	this.page		= 1 > page ? 1 : page;
    }

    public void setTotal(final int total) {
    	this.total		= total;
    }

    public void setPageSize(final int pageSize) {
    	this.pageSize	= 0 >= pageSize ? this.pageSize : pageSize;
    }

    public void setPageBlock(final int pageBlock) {
    	this.pageBlock	= 0 >= pageBlock ? this.pageBlock : pageBlock;
    }

    public void setPage(final String page) {
    	this.page		= Integer.parseInt(Utils.nvl(page, "1"));
    }

    public void setTotal(final String total) {
    	this.total		= Utils.isNotEmpty(total) ? Integer.parseInt(total) : 0;
    }

    public void setPageSize(final String pageSize) {
    	this.pageSize	= Utils.isNotEmpty(pageSize) ? Integer.parseInt(pageSize) : this.pageSize;
    }

    public void setPageBlock(final String pageBlock) {
    	this.pageBlock	= Utils.isNotEmpty(pageBlock) ? Integer.parseInt(pageBlock) : this.pageBlock;
    }

    public void setCallback(final String method) {
    	this.callback	= Utils.nvl(method, this.callback);
    }

    @Override
    public void doTag() throws JspException, IOException {
    	if(0 >= total) return;

    	HttpServletRequest	request		= (HttpServletRequest)getJspContext().getAttribute(PageContext.REQUEST);
    	this.isBackoffice				= -1 < request.getRequestURI().indexOf("/backoffice");

    	getJspContext().getOut().write(getPaingStr());
    }

	public String getPaingStr() {

		StringBuilder		paging		= new StringBuilder();
    	int	totalPage	= 0 == total - 1 ? 1 : (int)((total - 1) / pageSize) + 1;
    	int	currBlock	= 0 == page - 1 ? 1 : (int)((page - 1) / pageBlock) + 1;
    	int	totalBlock	= 0 == totalPage - 1 ? 1 : (int)((totalPage - 1) / pageBlock) + 1;

    	int	firstPage	= ((currBlock - 1) * pageBlock) + 1;
    	int	lastPage	= currBlock * pageBlock;

    	if(0 == firstPage)
    		firstPage	= 1;
    	if(totalBlock == currBlock)
    		lastPage	= totalPage;


    	//paging.append(" <div class=\"paging\"> ");
    	paging.append(" <div class=\"left\"><span class=\"totals\">총<em>").append(Utils.toNumFormat(total)).append("</em>건</span></div>");
    	paging.append(" <a href='#' onclick='");
    	if(pageBlock < firstPage)
    		paging.append(callback).append("(").append(firstPage - 1).append(");");
    	paging.append("return false;' title=\"이전\" class='first'>").append(getPPImage()).append("</a>");

		paging.append(" <a href='#' title=\"이전\" class='prev' onclick='");
    	if(1 < page)
    		paging.append(callback).append("(").append(page - 1).append(");");
    	paging.append("return false;'>").append(getPImage()).append("</a>");

    	for(int i = firstPage;i <= lastPage;i++) {
    		if(page == i)
    			paging.append(" <a href='#none' class='active'>").append(i).append("</a>");
    		else
    			paging.append(" <a href='#' onclick='").append(callback).append("(").append(i).append("); return false;' >").append(i).append("</a>");
    	}


    	paging.append(" <a href='#' class='next' title=\"다음\" onclick='");
    	if(page < totalPage)
    		paging.append(callback).append("(").append(page + 1).append(");");
    	paging.append("return false;'>").append(getNImage()).append("</a>");

    	paging.append(" <a href='#' onclick='");
    	if(lastPage < totalPage)
    		paging.append(callback).append("(").append(lastPage + 1).append(");");
    	paging.append("return false;' title=\"다음\" class='last'>").append(getNNImage()).append("</a>");
    	//paging.append(" </div> ");
		return paging.toString();
	}

    public String make() throws JspException, IOException {

    	if(0 >= total) return "";

    	StringBuilder		paging		= new StringBuilder();

    	int	totalPage	= 0 == total - 1 ? 1 : (int)((total - 1) / pageSize) + 1;
    	int	currBlock	= 0 == page - 1 ? 1 : (int)((page - 1) / pageBlock) + 1;
    	int	totalBlock	= 0 == totalPage - 1 ? 1 : (int)((totalPage - 1) / pageBlock) + 1;

    	int	firstPage	= ((currBlock - 1) * pageBlock) + 1;
    	int	lastPage	= currBlock * pageBlock;

    	if(0 == firstPage)
    		firstPage	= 1;
    	if(totalBlock == currBlock)
    		lastPage	= totalPage;

    	paging.append("<a href='#' onclick='");
    	if(pageBlock < firstPage)
    		paging.append(callback).append("(").append(firstPage - 1).append(");");
    	paging.append("return false;' class='prev'>").append(getPPImage()).append("</a>");

		paging.append("<a href='#' onclick='");
    	if(1 < page)
    		paging.append(callback).append("(").append(page - 1).append(");");
    	paging.append("return false;'>").append(getPImage()).append("</a>");

    	for(int i = firstPage;i <= lastPage;i++) {
    		if(page == i)
    			paging.append("<strong>").append(i).append("</strong>");
    		else
    			paging.append("<a href='#' onclick='").append(callback).append("(").append(i).append("); return false;'>").append(i).append("</a>");
    	}


    	paging.append("<a href='#' onclick='");
    	if(page < totalPage)
    		paging.append(callback).append("(").append(page + 1).append(");");
    	paging.append("return false;'>").append(getNImage()).append("</a>");

    	paging.append("<a href='#' onclick='");
    	if(lastPage < totalPage)
    		paging.append(callback).append("(").append(lastPage + 1).append(");");
    	paging.append("return false;' class='next'>").append(getNNImage()).append("</a>");

    	return paging.toString();
    }
    public String getPPImage() {
//    	return "&lt;&lt;";
    	return "";
    }

    public String getPImage() {
//    	return "&lt;";
    	return "";
    }

    public String getNImage() {
//    	return "&gt;";
    	return "";
    }

    public String getNNImage() {
//    	return "&gt;&gt;";
    	return "";
    }
}
