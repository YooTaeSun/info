package com.softworks.springframework.tag;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;
import org.apache.log4j.Logger;

import com.softworks.springframework.utils.Utils;

public class DBtoHtmlTag extends SimpleTagSupport {
	
    private String sData ;
    
    public void setsData(String sData) {
		this.sData = sData;
	}

	@Override
    public void doTag() throws JspException, IOException {
		
		if(null == this.sData || 0 >= this.sData.length()) return;
		try {	
			sData = Utils.DBtoHtml(sData);
			getJspContext().getOut().write(sData.toString());
		} catch(Exception e) {
			Logger.getLogger(getClass()).error("Error to DBtoHtml Result", e);
		}	
    }
    
}
