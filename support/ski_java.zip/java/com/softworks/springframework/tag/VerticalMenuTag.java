package com.softworks.springframework.tag;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.apache.log4j.Logger;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.web.services.MenuLoaderService;
import com.softworks.springframework.web.services.MenuLoaderService.Menu;
import com.softworks.springframework.web.services.MenuLoaderService.MenuInfo;

public class VerticalMenuTag extends SimpleTagSupport {
    
    private    final String ADMIN_GROUP    = Property.getProperty("site.admin.group");
    
    @Override
    public void doTag() throws JspException, IOException {
        HttpServletRequest    request    = (HttpServletRequest)getJspContext().getAttribute(PageContext.REQUEST);
        String                menuId    = (String)request.getAttribute("currentMenuId");

        if(null == menuId){
        	menuId = "001";
        	System.out.println("@ front doTag MenuId IS null >>>>>>>>>>");
		} else
			System.out.println("@ front doTag MenuId IS >>>>>>>>>>" + menuId.toString());
//		if(null == menuId) return;

        String	group	= (String)request.getSession().getAttribute("group");
        String	userId	= (String)request.getSession().getAttribute("uid");
        String	svcType	= (String)request.getSession().getAttribute("stype");
        String	uri		= (String)request.getAttribute("javax.servlet.forward.request_uri");
        //boolean    isBack    = -1 < request.getRequestURI().indexOf("/backoffice");
		System.out.println("@ front svcType >>>>>>>>>>" + svcType);
        
        try {
        	if (svcType != null) {
        		if (svcType.equals("B")) {
                    getJspContext().getOut().write(getBackofficeHTML(menuId, group, userId, uri).toString());
        		} else if (svcType.equals("E")) {
                    getJspContext().getOut().write(getExternalHTML(menuId, group, userId).toString());
        		} else {
                    getJspContext().getOut().write(getFrontHTML(menuId, group, userId).toString());
        		} 
        	} else {
                getJspContext().getOut().write(getFrontHTML(menuId, group, userId).toString());
        	}
            //getJspContext().getOut().write((isBack ? getBackofficeHTML(menuId, group, userId, uri) : getFrontHTML(menuId, group, userId)).toString());
        } catch(Exception e) {
            Logger.getLogger(getClass()).error("좌측메뉴 출력 오류", e);
        }
    }
    
    public StringBuilder getFrontHTML(final String menuId, final String group, final String userId) {
        int						show    = 0;
        StringBuilder			menu    = new StringBuilder();
        List<Menu>				list    = MenuLoaderService.FRONT_MENU;
        Map<String, MenuInfo>	info    = MenuLoaderService.FRONT_MENU_INFO;

        if(null == list) return menu;

        menu.append("<ul class='lnb-menu'>");
        for(int i = 0, count = list.size();i < count;i++) {
            String    id    = list.get(i).getId();

            if(!info.get(id).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(id).isAuth(group, userId))) continue;
            
            show++;
            List<Menu> subList    = list.get(i).getSub();

            menu.append("<li").append(menuId.indexOf(id) == 0 ? "  class=\"on\" >" : ">")
                    .append("<a href=\"#\" ").append(menuId.indexOf(id) == 0 ? " class=\"icon0" + (Integer.parseInt(id)-1) + " arrow active\" " : " class=\"icon0"+ (Integer.parseInt(id)-1)) .append(" onclick=\"goMenu('").append(info.get(id).isActive() ? info.get(id).getUrl() : "").append("'); return false;\">").append(info.get(id).getName()).append("</a>\n");

            if(subList != null && 0 < subList.size()) {
//                System.out.println("@@@@@@@@ front menuId >>"+menuId+"<< id >>"+id+"<< subList.size >>"+subList.size());

            	if(null != menuId)
            		menu.append("<ul").append(menuId.indexOf(id) == 0 ? "  style=\"display:block;\" >" : ">");
            	else
            		menu.append("<ul>");

            	for(int j = 0, cnt = subList.size();j < cnt;j++) {
                    id    = subList.get(j).getId();

                    if(!info.get(id).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(id).isAuth(group, userId))) continue;

                    List<Menu> subList1    = subList.get(j).getSub();
                    
                    menu.append("<li>")
                    .append("<a href=\"#\" ").append(menuId.indexOf(id) == 0 ? " class=\"active\"" : "").append(" onclick=\"goMenu('").append(info.get(id).isActive() ? info.get(id).getUrl() : "").append("'); return false;\">").append(info.get(id).getName()).append("</a>\n");
                    
                    if(subList1 != null && 0 < subList1.size()) {

                    	if(null != menuId)
                    		menu.append("<ul").append(menuId.indexOf(id) == 0 ? "  style=\"display:block;\" >" : ">");
                    	else
                    		menu.append("<ul>");
                    	
                        for(int k = 0, cnt1 = subList1.size();k < cnt1;k++) {
                            id    = subList1.get(k).getId();

                            if(!info.get(id).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(id).isAuth(group, userId))) continue;
                            
                            menu.append("<li>")
                            .append("<a href=\"#\" ").append(menuId.equals(id) ? " class=\"active\"" : "").append(" onclick=\"goMenu('").append(info.get(id).isActive() ? info.get(id).getUrl() : "").append("'); return false;\">")
                            .append(info.get(id).getName()).append("</a></li>\n");
                        }
                        menu.append("</ul>\n");
                    }
                    menu.append("</li>\n");
                }
                menu.append("</ul>\n");
            }
        }
        menu.append("</ul>\n");
//        System.out.println("++++++++++++++++++++++++++++++++++ getFrontHTML ++" + menu.toString());
        return menu;
    }
    
    public StringBuilder getBackofficeHTML(final String menuId, final String group, final String userId, final String uri) {
        int						show    = 0;
        StringBuilder			menu    = new StringBuilder();
        List<Menu>				list    = MenuLoaderService.ADMIN_MENU;
        Map<String, MenuInfo>	info    = MenuLoaderService.ADMIN_MENU_INFO;

        if(null == list) return menu;
        
//        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ List : "+list.toString());
/*        
        String    firstMenu    = menuId.substring(0, 3);
        for(int i = 0, cnt = list.size();i < cnt;i++) {
            if(firstMenu.equals(list.get(i).getId())) {
                list = list.get(i).getSub();
                break;
            }
        }
*/        

// 원래 2Depth인 좌측 메뉴를 3Depth로 변경        
        menu.append("<ul class='lnb-menu'>");
        for(int i = 0, count = list.size();i < count;i++) {
            String    id    = list.get(i).getId();

            if(!info.get(id).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(id).isAuth(group, userId))) continue;
            
            show++;
            List<Menu> subList    = list.get(i).getSub();
            
            menu.append("<li>")
                    .append("<a href=\"#\" ").append(" onclick=\"goMenu('").append(info.get(id).isActive() ? info.get(id).getUrl() : "").append("'); return false;\">").append(info.get(id).getName()).append("</a>\n");
            
            if(0 < subList.size()) {

            	menu.append("<ul").append(menuId.indexOf(id) == 0 ? "  style=\"display:block;\" >" : ">");

            	for(int j = 0, cnt = subList.size();j < cnt;j++) {
                    id    = subList.get(j).getId();

                    if(!info.get(id).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(id).isAuth(group, userId))) continue;

                    List<Menu> subList1    = subList.get(j).getSub();
                    
                    menu.append("<li>").append("<a href=\"#\" ");
                    if(subList1.size()==0){
                    	menu.append(menuId.equals(id) ? " class=\"active\"" : "").append(" onclick=\"goMenu('").append(info.get(id).isActive() ? info.get(id).getUrl() : "").append("'); return false;\">").append(info.get(id).getName()).append("</a>\n");
                    	
                    } else {
                    	menu.append(menuId.indexOf(id) == 0 ? " class=\"arrow\"" : "").append(" onclick=\"goMenu('").append(info.get(id).isActive() ? info.get(id).getUrl() : "").append("'); return false;\">").append(info.get(id).getName()).append("</a>\n");
                    }
                    
                    if(0 < subList1.size()) {

                    	menu.append("<ul").append(menuId.indexOf(id) == 0 ? "  style=\"display:block;\" >" : ">");
                        for(int k = 0, cnt1 = subList1.size();k < cnt1;k++) {
                            id    = subList1.get(k).getId();

                            if(!info.get(id).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(id).isAuth(group, userId))) continue;
                            
                            menu.append("<li>")
                            .append("<a href=\"#\" ").append(menuId.equals(id) ? " class=\"active\"" : "").append(" onclick=\"goMenu('").append(info.get(id).isActive() ? info.get(id).getUrl() : "").append("'); return false;\">")
                            .append(info.get(id).getName()).append("</a></li>\n");
                        }
                        menu.append("</ul>\n");
                    }
                    menu.append("</li>\n");
                }
                menu.append("</ul>\n");
            }
        }
            menu.append("</ul>\n");
//            System.out.println("++++++++++++++++++++++++++++++++++ getBackofficeHTML ++" + menu.toString());
            
        if(0 == show) return new StringBuilder();
        else return menu;
    }

    public StringBuilder getExternalHTML(final String menuId, final String group, final String userId) {
        int						show    = 0;
        StringBuilder			menu    = new StringBuilder();
        List<Menu>				list    = MenuLoaderService.EXTERNAL_MENU;
        Map<String, MenuInfo>	info    = MenuLoaderService.EXTERNAL_MENU_INFO;

        if(null == list) return menu;

        menu.append("<ul class='lnb-menu'>");
        for(int i = 0, count = list.size();i < count;i++) {
            String    id    = list.get(i).getId();

            if(!info.get(id).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(id).isAuth(group, userId))) continue;
            
            show++;
            List<Menu> subList    = list.get(i).getSub();

            menu.append("<li").append(menuId.indexOf(id) == 0 ? "  class=\"on\" >" : ">")
                    .append("<a href=\"#\" ").append(menuId.indexOf(id) == 0 ? " class=\"icon0" + (Integer.parseInt(id)-1) + " arrow active\" " : " class=\"icon0"+ (Integer.parseInt(id)-1)) .append(" onclick=\"goMenu('").append(info.get(id).isActive() ? info.get(id).getUrl() : "").append("'); return false;\">").append(info.get(id).getName()).append("</a>\n");

            if(subList != null && 0 < subList.size()) {
//                System.out.println("@@@@@@@@ front menuId >>"+menuId+"<< id >>"+id+"<< subList.size >>"+subList.size());

            	if(null != menuId)
            		menu.append("<ul").append(menuId.indexOf(id) == 0 ? "  style=\"display:block;\" >" : ">");
            	else
            		menu.append("<ul>");

            	for(int j = 0, cnt = subList.size();j < cnt;j++) {
                    id    = subList.get(j).getId();

                    if(!info.get(id).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(id).isAuth(group, userId))) continue;

                    List<Menu> subList1    = subList.get(j).getSub();
                    
                    menu.append("<li>")
                    .append("<a href=\"#\" ").append(menuId.indexOf(id) == 0 ? " class=\"active\"" : "").append(" onclick=\"goMenu('").append(info.get(id).isActive() ? info.get(id).getUrl() : "").append("'); return false;\">").append(info.get(id).getName()).append("</a>\n");
                    
                    if(subList1 != null && 0 < subList1.size()) {

                    	if(null != menuId)
                    		menu.append("<ul").append(menuId.indexOf(id) == 0 ? "  style=\"display:block;\" >" : ">");
                    	else
                    		menu.append("<ul>");
                    	
                        for(int k = 0, cnt1 = subList1.size();k < cnt1;k++) {
                            id    = subList1.get(k).getId();

                            if(!info.get(id).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(id).isAuth(group, userId))) continue;
                            
                            menu.append("<li>")
                            .append("<a href=\"#\" ").append(menuId.equals(id) ? " class=\"active\"" : "").append(" onclick=\"goMenu('").append(info.get(id).isActive() ? info.get(id).getUrl() : "").append("'); return false;\">")
                            .append(info.get(id).getName()).append("</a></li>\n");
                        }
                        menu.append("</ul>\n");
                    }
                    menu.append("</li>\n");
                }
                menu.append("</ul>\n");
            }
        }
        menu.append("</ul>\n");
//        System.out.println("++++++++++++++++++++++++++++++++++ getFrontHTML ++" + menu.toString());
        return menu;
    }
    
}
