package com.softworks.springframework.tag;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.apache.log4j.Logger;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.web.services.MenuLoaderService;
import com.softworks.springframework.web.services.MenuLoaderService.Menu;
import com.softworks.springframework.web.services.MenuLoaderService.MenuInfo;

public class HorizontalMenuTag extends SimpleTagSupport {

    private    final String ADMIN_GROUP    = Property.getProperty("site.admin.group");
    private    final String USER_GROUP    = Property.getProperty("site.user.group");
    
    @Override
    public void doTag() throws JspException, IOException {
        HttpServletRequest        request    = (HttpServletRequest)getJspContext().getAttribute(PageContext.REQUEST);

        String	group	= (String)request.getSession().getAttribute("group");
        String	userId	= (String)request.getSession().getAttribute("uid");
        String	svcType	= (String)request.getSession().getAttribute("stype");
        //boolean        isBackoffice        = -1 < request.getRequestURI().indexOf("/backoffice");
        
        try {
        	if (svcType != null) {
        		if (svcType.equals("B")) {
                    getJspContext().getOut().write(drawbackofficeMenu(group, userId).toString());
        		} else if (svcType.equals("E")) {
                    getJspContext().getOut().write(drawExternalMenu(group, userId).toString());
        		} else {
                    getJspContext().getOut().write(drawfrontMenu(group, userId).toString());
        		} 
        	} else {
                getJspContext().getOut().write(drawfrontMenu(group, userId).toString());
        	}
            //getJspContext().getOut().write((isBackoffice ? drawbackofficeMenu(group, userId) : drawfrontMenu(group, userId)).toString());
        } catch(Exception e) {
            Logger.getLogger(getClass()).error("탑메뉴 출력 오류", e);
        }
    }
    
    public StringBuilder drawfrontMenu(final String group, final String userId) {
        List<Menu>                list    = MenuLoaderService.FRONT_MENU;
        Map<String, MenuInfo>    info    = MenuLoaderService.FRONT_MENU_INFO;
        
        if(null == list) return new StringBuilder();
        
        StringBuilder            menu    = new StringBuilder();

        menu.append("<ul class='sitemap-menu'>");

        for(int i = 0, count = list.size();i < count;i++) {
            String    mid    = list.get(i).getId();
            
            if(!info.get(mid).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(mid).isAuth(group, userId))) continue;
            
            menu.append("<li>")
                    .append("<a href=\"#\" onclick=\"goMenu('").append(info.get(mid).isActive() ? info.get(mid).getUrl() : "").append("'); return false;\">").append(info.get(mid).getName()).append("</a>");
            
            List<Menu> subList    = list.get(i).getSub();
            if(0 < subList.size()) {
                menu.append("<ul>");
                for(int j = 0, cnt = subList.size();j < cnt;j++) {
                    mid    = subList.get(j).getId();
                    if(!info.get(mid).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(mid).isAuth(group, userId))) continue;
                    if(USER_GROUP.equals(group)) continue;
                    menu.append("<li>").append("<a href=\"#\" class='").append(info.get(mid).isActive() ? "" : "no-url").append("' onclick=\"goMenu('").append(info.get(mid).isActive() ? info.get(mid).getUrl() : "").append("'); return false;\">").append(info.get(mid).getName()).append("</a>");
                    List<Menu> lowSubList  = subList.get(j).getSub();
                    if(0 < lowSubList.size()) {
                        menu.append("<ul>");
                        for(int k = 0, lowerCnt = lowSubList.size();k < lowerCnt;k++) {
                            mid = lowSubList.get(k).getId();
                            if(!info.get(mid).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(mid).isAuth(group, userId))) continue;
                            if(USER_GROUP.equals(group)) continue;
                            menu.append("<li>").append("<a href=\"#\" class='").append(info.get(mid).isActive() ? "" : "no-url").append("' onclick=\"goMenu('").append(info.get(mid).isActive() ? info.get(mid).getUrl() : "").append("'); return false;\">").append(info.get(mid).getName()).append("</a></li>");
                        }
                        menu.append("</ul>");
                    }
                    menu.append("</li>");
                }
                menu.append("</ul>");
            }
            menu.append("</li>");
        }
        menu.append("</ul>");
        
//        System.out.println("++++++++++++++++++++++++++++++++++ drawfrontMenu ++" + menu.toString());
        return menu;
    }
    
    public StringBuilder drawbackofficeMenu(final String group, final String userId) {
        List<Menu>                list    = MenuLoaderService.ADMIN_MENU;
        Map<String, MenuInfo>    info    = MenuLoaderService.ADMIN_MENU_INFO;
        
        if(null == list) return new StringBuilder();
        
        StringBuilder            menu    = new StringBuilder();
        menu.append("<ul class='sitemap-menu' >");

        for(int i = 0, count = list.size();i < count;i++) {
            String    mid    = list.get(i).getId();
            
            if(!info.get(mid).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(mid).isAuth(group, userId))) continue;
            
            menu.append("<li>")
                    .append("<a href=\"#\" onclick=\"goMenu('").append(info.get(mid).isActive() ? info.get(mid).getUrl() : "").append("'); return false;\">").append(info.get(mid).getName()).append("</a>");
            
            List<Menu> subList    = list.get(i).getSub();
            if(0 < subList.size()) {
                menu.append("<ul>");
                for(int j = 0, cnt = subList.size();j < cnt;j++) {
                    mid    = subList.get(j).getId();
                    if(!info.get(mid).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(mid).isAuth(group, userId))) continue;
                    if(USER_GROUP.equals(group)) continue;
                    menu.append("<li>").append("<a href=\"#\" onclick=\"goMenu('").append(info.get(mid).isActive() ? info.get(mid).getUrl() : "").append("'); return false;\">").append(info.get(mid).getName()).append("</a>");
                    List<Menu> lowSubList  = subList.get(j).getSub();
                    if(0 < lowSubList.size()) {
                        menu.append("<ul>");
                        for(int k = 0, lowerCnt = lowSubList.size();k < lowerCnt;k++) {
                            mid = lowSubList.get(k).getId();
                            if(!info.get(mid).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(mid).isAuth(group, userId))) continue;
                            if(USER_GROUP.equals(group)) continue;
                            menu.append("<li>").append("<a href=\"#\" onclick=\"goMenu('").append(info.get(mid).isActive() ? info.get(mid).getUrl() : "").append("'); return false;\">").append(info.get(mid).getName()).append("</a></li>\n");
                        }
                        menu.append("</ul>\n");
                    }
                    menu.append("</li>\n");
                }
                menu.append("</ul>\n");
            }
            menu.append("</li>\n");
        }
        menu.append("</ul>\n");

//        System.out.println("++++++++++++++++++++++++++++++++++ drawbackofficeMenu ++" + menu.toString());
        
        return menu;
    }

    public StringBuilder drawExternalMenu(final String group, final String userId) {
        List<Menu>				list	= MenuLoaderService.EXTERNAL_MENU;
        Map<String, MenuInfo>	info	= MenuLoaderService.EXTERNAL_MENU_INFO;
        
        if(null == list) return new StringBuilder();
        
        StringBuilder            menu    = new StringBuilder();

        menu.append("<ul class='sitemap-menu'>");

        for(int i = 0, count = list.size();i < count;i++) {
            String    mid    = list.get(i).getId();
            
            if(!info.get(mid).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(mid).isAuth(group, userId))) continue;
            
            menu.append("<li>")
                    .append("<a href=\"#\" onclick=\"goMenu('").append(info.get(mid).isActive() ? info.get(mid).getUrl() : "").append("'); return false;\">").append(info.get(mid).getName()).append("</a>");
            
            List<Menu> subList    = list.get(i).getSub();
            if(0 < subList.size()) {
                menu.append("<ul>");
                for(int j = 0, cnt = subList.size();j < cnt;j++) {
                    mid    = subList.get(j).getId();
                    if(!info.get(mid).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(mid).isAuth(group, userId))) continue;
                    if(USER_GROUP.equals(group)) continue;
                    menu.append("<li>").append("<a href=\"#\" onclick=\"goMenu('").append(info.get(mid).isActive() ? info.get(mid).getUrl() : "").append("'); return false;\">").append(info.get(mid).getName()).append("</a>");
                    List<Menu> lowSubList  = subList.get(j).getSub();
                    if(0 < lowSubList.size()) {
                        menu.append("<ul>");
                        for(int k = 0, lowerCnt = lowSubList.size();k < lowerCnt;k++) {
                            mid = lowSubList.get(k).getId();
                            if(!info.get(mid).isDraw() || (!ADMIN_GROUP.equals(group) && !info.get(mid).isAuth(group, userId))) continue;
                            if(USER_GROUP.equals(group)) continue;
                            menu.append("<li>").append("<a href=\"#\" onclick=\"goMenu('").append(info.get(mid).isActive() ? info.get(mid).getUrl() : "").append("'); return false;\">").append(info.get(mid).getName()).append("</a></li>");
                        }
                        menu.append("</ul>");
                    }
                    menu.append("</li>");
                }
                menu.append("</ul>");
            }
            menu.append("</li>");
        }
        menu.append("</ul>");
        
        System.out.println("++++++++++++++++++++++++++++++++++ drawfrontMenu ++" + menu.toString());
        return menu;
    }
    
}
