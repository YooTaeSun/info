package com.softworks.springframework.view;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.sql.Blob;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.FileCopyUtils;
import org.springframework.web.servlet.view.AbstractView;

import com.softworks.springframework.utils.Utils;

public class FileDownloadView extends AbstractView {

	public FileDownloadView() {
		setContentType("application/octet-stream; UTF-8");
	}

	@Override
	protected void renderMergedOutputModel(Map<String,Object> model, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ServletOutputStream	out = null;
		FileInputStream		fis	= null;

		String	fileName = "";
		String	srcFileNm = "";
		File	file	= null;

		HashMap<String, Object> fileInfo = (HashMap<String, Object>)model.get("fileInfo");
		String fileRootPath = (String)model.get("fileRootPath");
		String file_path = Utils.nvl((String)fileInfo.get("FILE_PATH"),"");
		srcFileNm = (String)fileInfo.get("SRC_FILE_NM");
		boolean	isIE	= -1 < request.getHeader("User-Agent").indexOf("MSIE") || -1 < request.getHeader("User-Agent").indexOf("Trident/7.0"); //IE11추가
		fileName= isIE ? URLEncoder.encode(srcFileNm, "UTF-8") : new String((srcFileNm).getBytes("UTF-8"),"ISO-8859-1");

		response.setContentType(getContentType());
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\";");

		//파일경로에 파일 저장  다운로드
		if(!file_path.isEmpty()) {
			file = new File(fileRootPath + fileInfo.get("FILE_PATH"));
			response.setContentLength((int)file.length());

			try {
				out	= response.getOutputStream();
				fis = new FileInputStream(file);
				FileCopyUtils.copy(fis, out);
				out.flush();
			} catch(Exception e) {
				logger.error("[FileDownloadView] 파일 다운로드 View 처리중 에러", e);
			} finally {
				if(null != fis) try { fis.close(); } catch(Exception e) {}
				if(null != out) try { out.close(); } catch(Exception e) {}
			}

		//db에 파일 저장 다운로드
		}else {

			Blob blob = (Blob)fileInfo.get("SRC_FILE_DATA");
			response.setContentLength((int) blob.length());

			InputStream  is = blob.getBinaryStream();
			int binaryRead = -1;

			try {
				out	= response.getOutputStream();

				while ((binaryRead = is.read()) != -1)    {
					out.write(binaryRead);
	            }
				out.flush();
			} catch(Exception e) {
				logger.error("[FileDownloadView] 파일 다운로드 View 처리중 에러", e);
			} finally {
				if(null != is) try { is.close(); } catch(Exception e) {}
				if(null != out) try { out.close(); } catch(Exception e) {}
			}
		}
	}

}
