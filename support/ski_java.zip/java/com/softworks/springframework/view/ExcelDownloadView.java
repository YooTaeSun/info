package com.softworks.springframework.view;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.util.Region;
import org.springframework.util.CollectionUtils;
import org.springframework.web.servlet.view.AbstractView;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.utils.DrmUtil;
import com.softworks.springframework.utils.FileUtil;
import com.softworks.springframework.utils.Param;


public class ExcelDownloadView extends AbstractView {

	private	final Logger 		logger		= Logger.getLogger(getClass());

	static String localFlag = Property.getProperty("local.flag");
	final static String fileRootPath	= (localFlag.equals("Y"))? Property.getProperty("file.root.path.win") : Property.getProperty("file.root.path.linux");
	final static String uploadTmpPrefix = Property.getProperty("file.upload.temp");
	final static String batchDownPrefix = Property.getProperty("file.batch.down");
	final static String uploadPrefix = Property.getProperty("file.upload.real");
	final static String dlmt = "/";
	final static String newLine = "\r\n";

	/*
	 * Excel 다운로드
	 * @see org.springframework.web.servlet.view.document.AbstractExcelView#buildExcelDocument(java.util.Map, org.apache.poi.hssf.usermodel.HSSFWorkbook, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 * Paramater
	 * 		multiSheet		: List<Map>				- 복수 sheet 구성용
	 * 		filename		: String				- 생성할 파일명
	 * 		chapter			: String				- 생성할 Sheet명
	 * 		category		: String[]				- 출력할 한글 필드명 목록
	 * 		columns			: String[]				- data Map에 저장한 name 목록
	 * 		columnsWidth	: int[]					- Column width 목록
	 * 		date			: List<Param>			- Excel로 출력할 data 목록
	 * 		multiCategory	: List<String[]>		- 테이블 Header 복수 line 생성용
	 * 		headerMergeInfo	: List<ExcelMergeInfo>	- 테이블 Header 필드 Merge 정보
	 * 		rowMergeInfo	: List<ExcelMergeInfo>	- 테이블 Data의 Row Merge 정보
	 */
	@Override
	protected void renderMergedOutputModel(Map<String,Object> model, HttpServletRequest request, HttpServletResponse response) throws Exception {

		HSSFWorkbook workbook = new HSSFWorkbook();
		List<Map>	multiSheet	= (List<Map>)model.get("multiSheet");

		if (multiSheet != null) {
			buildExcelMultiSheet(multiSheet, workbook, request, response);
		} else {
			buildExcelSingleSheet(model, workbook, request, response);
		}

		String addImagePath = FileUtil.addPath();
		String fullPath = batchDownPrefix + dlmt + addImagePath + dlmt + FileUtil.createFilename();
		String encFullPath = fullPath;

		File file = new File(FileUtil.createNewFile(fileRootPath + fullPath));

		FileOutputStream fos = new FileOutputStream(file);
		workbook.write(fos);
		fos.flush();

		String excelFilename = (String)model.get("filename");
		logger.debug("excelFilename >> " + excelFilename);

		//drm 암호화
		if(!localFlag.equals("Y")) {

			logger.debug("[uploadFile] fullPath >> " + fullPath);
			encFullPath = FileUtil.getEncFullPath(fullPath);
			logger.debug("[uploadFile] encFullPath  >> " + encFullPath);

			boolean isEncrypt = DrmUtil.encryption(fileRootPath + fullPath, fileRootPath + encFullPath, "xls");

			File encFullFile =  new File(fileRootPath + encFullPath);
			int timeCnt = 0;
			while (!encFullFile.exists() && timeCnt < (60 * 3)) {//3 분초
				timeCnt++;
				Thread.sleep(1000);
			}

			if(encFullFile.exists()) {
				logger.debug("[uploadFile] encFullFile exists Yes >> " + encFullFile);
				fos.close();
				file.delete();
				logger.debug("[uploadFile] file remove >> " + file.getAbsolutePath());
				renderOutput(request, response, excelFilename, encFullFile);


			}else {
				logger.debug("[uploadFile] encFullPath exists No >> " + encFullPath);

			}
		}else {
			fos.close();
			renderOutput(request, response, excelFilename, file);
		}


	}

	public void renderOutput(HttpServletRequest request,
										HttpServletResponse response,
										String fileName,
										File file) throws IOException, UnsupportedEncodingException {

		ServletOutputStream	out	= null;

		byte[]	content	= Files.readAllBytes(file.toPath());;
		boolean	isIE	= -1 < request.getHeader("User-Agent").indexOf("MSIE") || -1 < request.getHeader("User-Agent").indexOf("Trident/7.0"); //IE11추가

//		String	excelFilename = isIE ? URLEncoder.encode(fileName, "UTF-8") : new String((fileName).getBytes("UTF-8"));
		String	excelFilename = URLEncoder.encode(fileName, "UTF-8");

		response.setHeader("Content-Disposition", "attachment; filename=" + excelFilename + ".xls");
		response.setHeader("Content-Transfer-Encoding", "binary");
		response.setHeader("Cache-Control", "max-age=0, private, must-revalidate");
		response.setContentType("application/vnd.ms-excel");
//		response.setContentLength(content.length);

		try {
			out	= response.getOutputStream();
			out.write(content);
			out.flush();
		} catch(Exception e) {
			logger.error("excel 파일 다운로드 처리중 에러", e);
		} finally {
			if(null != out) try {
				out.close();
				file.delete();
			} catch(Exception e) {}
		}
	}

	private void buildExcelSingleSheet(Map<String,Object> model, HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response) {
		String[]	category= (String[])model.get("category");
		String[]	columns	= (String[])model.get("columns");
		List<Param>	data	= (List<Param>)model.get("data");

		List<String[]> multiCategory = (List<String[]>)model.get("multiCategory");
		List<ExcelMergeInfo> headerMergeInfo = (List<ExcelMergeInfo>)model.get("headerMergeInfo");
		List<ExcelMergeInfo> rowMergeInfo = (List<ExcelMergeInfo>)model.get("rowMergeInfo");

		if(multiCategory != null){
			if( null == data || null == columns
					|| 0 >= multiCategory.size() || 0 >= columns.length || multiCategory.get(0).length != columns.length
					|| CollectionUtils.isEmpty(data)) return;
		}else{
			if( null == data || null == category || null == columns
					|| 0 >= category.length || 0 >= columns.length || category.length != columns.length
					|| CollectionUtils.isEmpty(data)) return;
		}

		int[] columnsWidth = (int[])model.get("columnsWidth");

		int firstDataRow = 0;

		HSSFCellStyle	headerStyle	= workbook.createCellStyle();
		HSSFCellStyle	rowStyle	= workbook.createCellStyle();
		HSSFFont		headerFont	= workbook.createFont();
		HSSFFont		rowFont	= workbook.createFont();
		HSSFSheet		sheet	= createSheet(workbook, 0, (String)model.get("chapter"));

		headerFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		headerFont.setFontName("돋움");
		headerFont.setFontHeightInPoints((short)9);
		headerStyle.setFont(headerFont);
		headerStyle.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
		headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		headerStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		headerStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
		headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		headerStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);

		rowFont.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
		rowFont.setFontName("돋움");
		rowFont.setFontHeightInPoints((short)10);
		rowStyle.setFont(rowFont);
		rowStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
		rowStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		rowStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
		rowStyle.setWrapText(true);//20190618 줄바꿈

		if(multiCategory != null && multiCategory.size() > 0){
			creatColumn(sheet, multiCategory, headerStyle, headerMergeInfo, columnsWidth);
			firstDataRow = firstDataRow + multiCategory.size();
		}else{

			int searchCellCnt = 0;
			//검색 조건 쓰기 2019.06.17
			if(model.get("searchList") != null) {
				List<LinkedHashMap<String, String>>	searchList	= (List<LinkedHashMap<String, String>>)model.get("searchList");
				searchCellCnt = searchList.size();

				for(int i = 0, count = searchList.size();i < count;i++){
					LinkedHashMap<String, String> searchMap = (LinkedHashMap)searchList.get(i);
					String name = searchMap.get("name");
					String text = searchMap.get("text");


					HSSFRow row = sheet.createRow((short)i);
					HSSFCell cell = row.createCell((short)0);
					if(text.equals("")) {
						cell.setCellValue(name + " : 전체");
					}else {
						cell.setCellValue(name + " : " + text);
					}
					sheet.addMergedRegion(new Region(i, (short)0, i, (short)(category.length-1)));
				}
			}

			creatColumn(sheet, category, headerStyle, columnsWidth, searchCellCnt);
			firstDataRow = firstDataRow + 1  + searchCellCnt;
		}

		for(int i = 0, count = data.size();i < count;i++){
			createRow(sheet, data.get(i), i + firstDataRow, columns, rowStyle, rowMergeInfo, firstDataRow);
		}
	}

	private void buildExcelMultiSheet(List<Map> multiSheet, HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response) {
		for (int i = 0; i < multiSheet.size(); i++) {
			Map info	= multiSheet.get(i);

			String[]	category= (String[])info.get("category");
			String[]	columns	= (String[])info.get("columns");
			List<Param>	data	= (List<Param>)info.get("data");

			List<String[]> multiCategory = (List<String[]>)info.get("multiCategory");
			List<ExcelMergeInfo> headerMergeInfo = (List<ExcelMergeInfo>)info.get("headerMergeInfo");
			List<ExcelMergeInfo> rowMergeInfo = (List<ExcelMergeInfo>)info.get("rowMergeInfo");

			if(multiCategory != null){
				if( null == data || null == columns
						|| 0 >= multiCategory.size() || 0 >= columns.length || multiCategory.get(0).length != columns.length
						|| CollectionUtils.isEmpty(data)) return;
			}else{
				if( null == data || null == category || null == columns
						|| 0 >= category.length || 0 >= columns.length || category.length != columns.length
						|| CollectionUtils.isEmpty(data)) return;
			}

			int[] columnsWidth = (int[])info.get("columnsWidth");

			int firstDataRow = 0;

			HSSFCellStyle	headerStyle	= workbook.createCellStyle();
			HSSFCellStyle	rowStyle	= workbook.createCellStyle();
			HSSFFont		headerFont	= workbook.createFont();
			HSSFFont		rowFont	= workbook.createFont();
			HSSFSheet		sheet	= createSheet(workbook, i, (String)info.get("chapter"));

			headerFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			headerFont.setFontName("돋움");
			headerFont.setFontHeightInPoints((short)9);
			headerStyle.setFont(headerFont);
			headerStyle.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
			headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			headerStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			headerStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
			headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			headerStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);

			rowFont.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
			rowFont.setFontName("돋움");
			rowFont.setFontHeightInPoints((short)10);
			rowStyle.setFont(rowFont);
			rowStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
			rowStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			rowStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			rowStyle.setWrapText(true);//20190618 줄바꿈


			if(multiCategory != null && multiCategory.size() > 0){
				creatColumn(sheet, multiCategory, headerStyle, headerMergeInfo, columnsWidth);
				firstDataRow = firstDataRow + multiCategory.size();
			}else{
				creatColumn(sheet, category, headerStyle, columnsWidth, 0);
				firstDataRow = firstDataRow + 1;
			}

			for(int j = 0; j < data.size(); j++){
				createRow(sheet, data.get(j), j + firstDataRow, columns, rowStyle, rowMergeInfo, firstDataRow);
			}
		}
	}

	private boolean isIE(String userAgent) {
		return -1 < userAgent.indexOf("MSIE");
	}

	private HSSFSheet createSheet(HSSFWorkbook workbook, int sheetNum, String sheetName) {
		HSSFSheet sheet = workbook.createSheet();
		workbook.setSheetName(sheetNum, sheetName);

		return sheet;
	}

	private void creatColumn(HSSFSheet sheet, String[] columns, HSSFCellStyle style, int[] columnsWidth, int headerRowIndex) {
		HSSFRow		header	= sheet.createRow(headerRowIndex);
		HSSFCell	cell	= null;
		header.setHeightInPoints(20);

		boolean customColWidth = false;
		if(columnsWidth != null && columns.length == columnsWidth.length){
			customColWidth = true;
		}

		for (int i = 0, count = columns.length;i < count;i++) {
			cell = header.createCell(i);
			cell.setCellStyle(style);
			cell.setCellValue(columns[i]);

			if(customColWidth){
				cell.getSheet().setColumnWidth(i, columnsWidth[i] * 256);
			}else{
				cell.getSheet().autoSizeColumn(i);
			}
		}
	}

	private void creatColumn(HSSFSheet sheet, List<String[]> columnsList, HSSFCellStyle style, List<ExcelMergeInfo> excelMergeInfo, int[] columnsWidth) {
		int headerRowIndex = 0;
		HSSFRow		header	= null;
		HSSFCell	cell	= null;

		boolean customColWidth = false;
		if(columnsWidth != null && columnsList.get(0).length == columnsWidth.length){
			customColWidth = true;
		}

		for(String[] columns : columnsList){
			header = sheet.createRow(headerRowIndex++);
			header.setHeightInPoints(20);

			for(int i = 0; i < columns.length; i++){
				cell = header.createCell(i);
				cell.setCellStyle(style);
				cell.setCellValue(columns[i]);
				if(customColWidth){
					cell.getSheet().setColumnWidth(i, columnsWidth[i] * 256);
				}else{
					cell.getSheet().autoSizeColumn(i);
				}
			}
		}

		if(excelMergeInfo != null){
			for(ExcelMergeInfo mergeInfo : excelMergeInfo){
				sheet.addMergedRegion(new Region(mergeInfo.getRowFrom(), mergeInfo.getColFrom(), mergeInfo.getRowTo(), mergeInfo.getColTo()));
			}
		}
	}

	private void createRow(HSSFSheet sheet, Param info, int rowNum, String[] columns, HSSFCellStyle style, List<ExcelMergeInfo> excelMergeInfo, int firstDataRow) {
		HSSFRow		row		= sheet.createRow(rowNum);
		HSSFCell	cell	= row.createCell(0);
		row.setHeightInPoints(17);

		for (int i = 0, count = columns.length;i < count;i++) {
			cell	= row.createCell(i);
			cell.setCellStyle(style);
			cell.setCellValue(info.get(columns[i]));
		}

		if(excelMergeInfo != null){
			for(ExcelMergeInfo mergeInfo : excelMergeInfo){
				sheet.addMergedRegion(new Region(mergeInfo.getRowFrom() + firstDataRow, mergeInfo.getColFrom(), mergeInfo.getRowTo() + firstDataRow, mergeInfo.getColTo()));
			}
		}
	}

	public static class ExcelMergeInfo {
		private	int rowFrom;
		private	short colFrom;
		private int rowTo;
		private short colTo;

		public ExcelMergeInfo() {}

		public ExcelMergeInfo(int rowFrom, short colFrom, int rowTo, short colTo){
			this.rowFrom = rowFrom;
			this.colFrom = colFrom;
			this.rowTo = rowTo;
			this.colTo = colTo;
		}

		public int getRowFrom() {
			return rowFrom;
		}

		public short getColFrom() {
			return colFrom;
		}

		public int getRowTo() {
			return rowTo;
		}

		public short getColTo() {
			return colTo;
		}
	}
}