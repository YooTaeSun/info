package com.softworks.springframework.view;

import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.AbstractView;

public class TextFileDownloadView extends AbstractView {

	public TextFileDownloadView() {
		setContentType("text/plain; UTF-8");
	}

	@Override
	protected void renderMergedOutputModel(Map<String,Object> model, HttpServletRequest request, HttpServletResponse response) throws Exception {

//		boolean	isIE	= -1 < request.getHeader("User-Agent").indexOf("MSIE");
//		String	fileName= isIE ? URLEncoder.encode((String)model.get("filename"), "UTF-8") : new String(((String)model.get("filename")).getBytes("UTF-8"));
		String	fileName= URLEncoder.encode((String)model.get("filename"), "UTF-8");

		response.setContentType(getContentType());
//		response.setContentLength(contentByte.length);
		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\";");

		PrintWriter	out = null;

		try {
			out	= response.getWriter();

			String content =  (String)model.get("content");
			if(!content.isEmpty()) {
				String[] contentArray = content.split("\\n");
				if(contentArray != null && contentArray.length > 0) {
					for (int i = 0; i < contentArray.length; i++) {
						out.println(contentArray[i]);
					}
				}
			}
			out.flush();
		} catch(Exception e) {
			logger.error("TEXT 파일 다운로드 View 처리중 에러", e);
		} finally {
			if(null != out) try { out.close(); } catch(Exception e) {}
		}
	}
}
