package com.softworks.springframework.ws;

public class TransFile {
	private String orgFileName = null;
	private String saveFileName = null;
	private String orgFileSize = null;
	private String saveFileSize = null;
	
	public String getOrgFileName() {
		return orgFileName;
	}
	public void setOrgFileName(String orgFileName) {
		this.orgFileName = orgFileName;
	}
	public String getSaveFileName() {
		return saveFileName;
	}
	public void setSaveFileName(String saveFileName) {
		this.saveFileName = saveFileName;
	}
	public String getOrgFileSize() {
		return orgFileSize;
	}
	public void setOrgFileSize(String orgFileSize) {
		this.orgFileSize = orgFileSize;
	}
	public String getSaveFileSize() {
		return saveFileSize;
	}
	public void setSaveFileSize(String saveFileSize) {
		this.saveFileSize = saveFileSize;
	}
	
}
