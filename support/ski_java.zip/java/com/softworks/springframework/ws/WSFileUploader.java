package com.softworks.springframework.ws;

import java.io.BufferedOutputStream;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

import javax.websocket.CloseReason;
import javax.websocket.MessageHandler;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;
import com.softworks.springframework.property.Property;

import java.util.ArrayList;
import java.util.Calendar;
@ServerEndpoint("/upload")
public class WSFileUploader{

    BufferedOutputStream bos;
    //String path = Property.getProperty("file.dir"); //보안점검
    String path = "/meta/upload";
    
    ArrayList<TransFile> fileList = null;
    int index=0;
    private ArrayList<Session> sessionList = null;
    
    public WSFileUploader(){
    	fileList = new ArrayList<TransFile>();
    	System.out.println("########### WS File Server ############");;
    }

    @OnMessage
    public void onMessage(Session session, String msg) {
    	System.out.println("onMessage==>"+msg);;

        session.setMaxBinaryMessageBufferSize(1024*1024);

        if(msg.startsWith("next")){


            String fileName = msg.substring(msg.indexOf(":")+1);
            TransFile transFile = new TransFile();
            long timeStamp = Calendar.getInstance().getTimeInMillis();
            String saveFileName = "softworks_"+session.getId()+"_"+timeStamp;
            transFile.setSaveFileName(saveFileName);
            transFile.setOrgFileName(fileName);
            fileList.add(transFile);
            System.out.println("path ==>"+path);;
            File file = new File(path , saveFileName);

            try {
                bos = new BufferedOutputStream(new FileOutputStream(file));
            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            
        }else if(msg.equals("end")){
        	System.out.println(" result fileList.size ==> "+fileList.size());;
        	
        	try {
				String rs = "";

				for(int i=0; i<fileList.size(); i++){
					TransFile transFile = fileList.get(i);
					rs += rDlmt;
					rs += transFile.getOrgFileName()+cDlmt+ transFile.getSaveFileName() + cDlmt + size;
				}
				size = 0;
				count = 0;
	        	System.out.println("rs ==> "+rs);;
                session.getBasicRemote().sendText("RES999"+rs);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    int count = 0;
    int size = 0;
    String rDlmt = ",";
    String cDlmt = ":";

    @OnMessage
    public void processUpload(ByteBuffer msg, boolean last, Session session) {
//    	System.out.print(msg.getChar() );
    	String log = "";
        try {
        	bos.write( msg.array() );
        } catch (IOException e) {
            e.printStackTrace();
        }

		try{
			size += msg.array().length;
//			System.out.println("==> "+count+" "+msg.array().length +" ( "+size +" ) ");;
			if(last){
                bos.flush();
                bos.close();
				size = 0;
				session.getBasicRemote().sendText("RES200");
			}else{
				session.getBasicRemote().sendText(""+size);
				count++;
			}
		}catch(Exception e){
			e.printStackTrace();
	  	   try{
	  		   session.getBasicRemote().sendText("fail");
	  	   }catch(Exception e2){
	  		   e2.printStackTrace();
	  	   }
  		}
    }

    @OnOpen
    public void open(Session session) {
    	System.out.println("WebSocket File Server Open......");
        String sessionId = session.getId();
        System.out.println("sessionId "+sessionId);
    }

    @OnError
    public void error(Session session, Throwable t) {
        System.out.println("error");
    }

    @OnClose
    public void closedConnection(Session session) {
        System.out.println("closedConnection");
    }

    @Override
    protected void finalize() throws Throwable {
    	// TODO Auto-generated method stub
    	System.out.println("finalize");
    	super.finalize();
    }
}