package com.softworks.springframework.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.util.StringUtils;

import com.softworks.springframework.property.Property;
import com.softworks.springframework.utils.Utils;
import com.softworks.springframework.web.interceptors.AuthorizationInterceptor;

public class AuthenticationFilter implements Filter {
	
	@Override
	public void init(FilterConfig filterconfig) throws ServletException { }
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterchain) throws IOException, ServletException {
		HttpServletRequest	req		= (HttpServletRequest)request;
		HttpServletResponse	res		= (HttpServletResponse)response;
		HttpSession			session	= req.getSession();
		String				language= req.getHeader("Accept-Language");
		
		if(AuthorizationInterceptor.passChecker(req.getRequestURI())) {
			setSessionLocale(language, session);
			filterchain.doFilter(req, res);
			return;
		}

		/* HTTPS 용  jgmik */
//		if(!req.isSecure()) {
//			System.out.println("Secure 포트로 리다이렉트 시킵니다. 접속시도 IP : " + request.getRemoteAddr() + " 접속시도 HOST : " + request.getRemoteHost());
//			res.sendRedirect(Property.getProperty("site.url"));
//			return;
//		}

		if(null == session || "".equals(Utils.nvl((String)session.getAttribute("uid")))) {
			
		    String ajaxCall = (String) req.getHeader("X-Requested-With");
		    
		    //ahax call인 경우 http status code로 체크 
		    if(ajaxCall!=null) {
		        res.sendError(401);
	            return;
		    } else {
		        //req.setAttribute("message", "로그인 후에 이용해 주세요.");
	            req.setAttribute("location", Property.getProperty("site.login.url"));
	            req.getRequestDispatcher("/sendMessage").forward(req, res); 
		    }
		    
		} else {
			filterchain.doFilter(req, res);
			return;
		}
	}
	
	public void setSessionLocale(String language, HttpSession session)  {
		if(null == session.getAttribute(org.springframework.web.servlet.i18n.SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME))
			session.setAttribute(
								 org.springframework.web.servlet.i18n.SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME,
								 StringUtils.parseLocaleString(null == language || language.startsWith("ko") ? "ko" : "en")
								);
	}

	@Override
	public void destroy() { }
	
}