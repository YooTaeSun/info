package com.townsi.support;

import java.util.Properties;
import javax.sql.DataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.aop.framework.autoproxy.BeanNameAutoProxyCreator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.interceptor.TransactionInterceptor;

@Configuration
@Lazy
@EnableTransactionManagement
@MapperScan(basePackages = {"com.townsi.setting.mapper"})
class DefaultDatabaseConfig {

  @Autowired
  private ApplicationContext applicationContext;

  @Autowired
  private Environment environment;

  @Bean(destroyMethod = "close")
  @ConfigurationProperties(prefix = "spring.datasource")
  public DataSource dataSource() {
    return DataSourceBuilder.create().build();
  }

  @Bean
  public PlatformTransactionManager transactionManager() {
    DataSourceTransactionManager transactionManager = new DataSourceTransactionManager(dataSource());
    transactionManager.setGlobalRollbackOnParticipationFailure(false);
    return transactionManager;
  }

  @Bean
  public SqlSessionFactory sqlSessionFactory() throws Exception {
    SqlSessionFactoryBean sessionFactoryBean = new SqlSessionFactoryBean();
    sessionFactoryBean.setDataSource(dataSource());
    sessionFactoryBean.setConfigLocation(applicationContext.getResource("classpath:config/mybatis-config.xml"));
    sessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath:mapper/**/*.xml"));
    return sessionFactoryBean.getObject();
  }

  @Bean(name = "transactionInterceptor")
  public TransactionInterceptor transactionInterceptor(PlatformTransactionManager platformTransactionManager) {
      TransactionInterceptor transactionInterceptor = new TransactionInterceptor();
      transactionInterceptor.setTransactionManager(platformTransactionManager);
      Properties transactionAttributes = new Properties();
      transactionAttributes.setProperty("*", "PROPAGATION_REQUIRED,-Throwable");
      transactionInterceptor.setTransactionAttributes(transactionAttributes);
      return transactionInterceptor;
  }

  @Bean
  public BeanNameAutoProxyCreator transactionAutoProxy() {
      BeanNameAutoProxyCreator transactionAutoProxy = new BeanNameAutoProxyCreator();
      transactionAutoProxy.setProxyTargetClass(true);
      transactionAutoProxy.setBeanNames("*BizImpl");
      transactionAutoProxy.setInterceptorNames("transactionInterceptor");
      return transactionAutoProxy;
  }
}