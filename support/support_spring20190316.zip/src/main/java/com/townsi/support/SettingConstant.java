package com.townsi.support;

public class SettingConstant {
	public static enum Path {

		SITE_WEB_ROOT("E:\\project01\\worspace\\support_spring20181228\\src\\main\\webapp"),
		PROP("E:\\project01\\worspace\\support_spring20181228\\src\\main\\resources\\config\\setting.properties");

		private final String value;

		private Path(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}
	}
}

