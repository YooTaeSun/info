package com.townsi.setting.biz.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.townsi.setting.biz.ISettingBiz;
import com.townsi.setting.mapper.ISettingMapper;
import com.townsi.support.SettingConstant;
import com.townsi.utils.FileUtil;
import com.townsi.utils.ListUtil;
import com.townsi.utils.StrUtil;


/**
* SettingServiceImpl
* @author 유태선
* @since 2016.10.14
* @version 1.0
* @see
* </pre>
*/
@SuppressWarnings({"rawtypes","unchecked","unused"})
@Service
public class SettingBizImpl implements ISettingBiz {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private ISettingMapper mapper;

	public static String READ_LINE = "\n";
	public static String TAB = "\t";
	public static String SLASH = File.separator;// lastIndexOf("/")

	public static boolean IS_MYBATIS = true;
	public static int COLUMN_CNT = 100;

//	public static String replaceTxt  = "#txt#";
	public static String rTxt  = "#{txt}";

	final static String SITE_WEB_ROOT_PATH = SettingConstant.Path.SITE_WEB_ROOT.getValue();

	public List<HashMap> selectTableInfo(HashMap params){

		List<HashMap>  list = null;

		String dbName = nvl((String)params.get("dbName"));
		if("MY_SQL".equals(dbName)) {
		    list = mapper.selectTableInfoByMysql(params);

		    String camelColumnName = "";
		    for (HashMap hashMap : list) {
		    	camelColumnName = StrUtil.toCamelCase((String)hashMap.get("CAMEL_COLUMN_NAME"));
		    	hashMap.put("CAMEL_COLUMN_NAME", camelColumnName);
		    	hashMap.put("MEM_VARI", (String)hashMap.get("MEM_VARI") + " " + camelColumnName + ";");
		    	hashMap.put("SET_GET_COLUMN_NAME",  camelColumnName.substring(0,1).toUpperCase() + camelColumnName.substring(1));
		    }
		  }else if("ORACLE".equals(dbName)) {
			  list = mapper.selectTableInfoByOracle(params);
		  }
		return list;
	}

	public List<HashMap> selectSqlInfo(HashMap params){
		List<HashMap>  list = mapper.selectSqlInfo(params);
//		String camelColumnName = "";
//		for (HashMap hashMap : list) {
//			camelColumnName = StrUtil.toCamelCase((String)hashMap.get("CAMEL_COLUMN_NAME"));
//			hashMap.put("CAMEL_COLUMN_NAME", camelColumnName);
//			hashMap.put("MEM_VARI", (String)hashMap.get("MEM_VARI") + " " + camelColumnName + ";");
//			hashMap.put("SET_GET_COLUMN_NAME",  camelColumnName.substring(0,1).toUpperCase() + camelColumnName.substring(1));
//		}
		return list;
	}


	@Override
	public HashMap<String, Object> source(HashMap params) throws Exception {
		HashMap dataMap = new HashMap();

		String methodName = nvl((String) params.get("methodName"));
		params.put("methodName", methodName);

		String dbName = nvl((String) params.get("dbName"));
		params.put("dbName", dbName);

		String tableName = nvl((String) params.get("tableName"));
		params.put("tableName", tableName);

		String desc = nvl((String) params.get("desc"));
		params.put("desc", desc);

		String modelComment = StringUtils.defaultString((String) params.get("modelComment"));
		params.put("modelComment", modelComment);

		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		params.put("makeGetsetMethodYn", makeGetsetMethodYn);

		String fromSql = StringUtils.defaultString(((String) params.get("fromSql")).trim());

		HashMap voMap = null;
		try {
			if("".equals(fromSql)) {
				voMap = makeModel(params);
			}else {
//				voMap = makeModelBySql(params);
				voMap = makeModel(params);
			}

			dataMap.put("voMap", voMap);
		} catch (Exception e) {e.printStackTrace();}


		try {
		  HashMap sqlMap = null;
		  if(IS_MYBATIS) {
		    sqlMap = makeMybaitisSql(params);
		  }else{
		    sqlMap = makeIbaitisSql(params);
		  }
		  dataMap.put("sqlMap", sqlMap);
		} catch (Exception e) {e.printStackTrace();}


		try {
		  HashMap jsonMap = makeJson(params);
		  dataMap.put("jsonMap", jsonMap);
		} catch (Exception e) {e.printStackTrace();}

//		try {
//			HashMap serviceMap = makeService(params);
//			dataMap.put("serviceMap", serviceMap);
//		} catch (Exception e) {e.printStackTrace();}
//
//		try {
//			HashMap controllerMap = makeController(params);
//			dataMap.put("controllerMap", controllerMap);
//		} catch (Exception e) {e.printStackTrace();}


		return dataMap;
	}


	@Override
	public HashMap<String, Object> makeSetGet(HashMap params) throws Exception {
		HashMap dataMap = new HashMap();

		try {
			HashMap setGetMap = makeSetGetExcute(params);
			dataMap.put("setGetMap", setGetMap);
		} catch (Exception e) {e.printStackTrace();}

		return dataMap;
	}


	public HashMap makeModel(HashMap params) throws Exception {
		HashMap dataMap = new HashMap();
		HashMap replaceMap = new HashMap();
		StringBuilder dtoMemer = new StringBuilder(500);
		StringBuilder dtoMethod = new StringBuilder(500);

		String COLUMN_NAME = "";
		String MEM_VARI = "";
		String COLUMN_COMMENT = "";
		String CAMEL_COLUMN_NAME = "";
		String SET_GET_COLUMN_NAME = "";
		String W_TYPE = "";
		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String upperTableName = "";
		String lowerTableName = "";
		String camelTableName = "";
		String modelComment = (String) params.get("modelComment");
		String makeGetsetMethodYn = (String) params.get("makeGetsetMethodYn");

		if(!StringUtils.isEmpty(tableName)) {
			upperTableName = tableName.toUpperCase();
			lowerTableName = tableName.toLowerCase();
			camelTableName = StrUtil.toCamelCase(upperTableName);
		}

		List<HashMap> list = this.selectTableInfo(params);

		if(ListUtil.isNotEmpty(list)) {

			for (HashMap rs : list) {
				COLUMN_NAME = (String) rs.get("COLUMN_NAME");
				COLUMN_COMMENT = (String) rs.get("COLUMN_COMMENT");
				CAMEL_COLUMN_NAME = (String) rs.get("CAMEL_COLUMN_NAME");
				MEM_VARI = (String) rs.get("MEM_VARI");
				W_TYPE = (String) rs.get("W_TYPE");

				SET_GET_COLUMN_NAME = (String) rs.get("SET_GET_COLUMN_NAME");

				dtoMemer.append(READ_LINE);

				if(!StringUtils.isEmpty(COLUMN_COMMENT)) {
					if(modelComment.equals("Y_NEXT")) {

						if("Date".equals(W_TYPE)) dtoMemer.append("\t@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = \"yyyy-MM-dd HH:mm:ss\")" + READ_LINE);
						dtoMemer.append("\t"+ MEM_VARI);
						dtoMemer.append("\t/* " +COLUMN_COMMENT + " */" + READ_LINE);

					}else if(modelComment.equals("Y_UP")) {

						dtoMemer.append("\t/* " +COLUMN_COMMENT + " */" + READ_LINE);
						if("Date".equals(W_TYPE)) dtoMemer.append("\t@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = \"yyyy-MM-dd HH:mm:ss\")" + READ_LINE);
						dtoMemer.append("\t"+ MEM_VARI + READ_LINE);

					}else if(modelComment.equals("Y_BOTTOM")) {

						dtoMemer.append("\t"+ MEM_VARI + READ_LINE);
						if("Date".equals(W_TYPE)) dtoMemer.append("\t@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = \"yyyy-MM-dd HH:mm:ss\")" + READ_LINE);
						dtoMemer.append("\t/* " +COLUMN_COMMENT + " */" + READ_LINE);

					}else {
						dtoMemer.append("\t"+ MEM_VARI + READ_LINE);
					}
				}else {
					dtoMemer.append("\t"+ MEM_VARI + READ_LINE);
				}

				if(makeGetsetMethodYn.equals("Y")) {
					if("int".equals(W_TYPE) || "Integer".equals(W_TYPE)) {
						dtoMethod.append("\tpublic int get" + SET_GET_COLUMN_NAME + "() {" + READ_LINE + " \t\t return " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
						dtoMethod.append("\tpublic void set" + SET_GET_COLUMN_NAME + "(int " + CAMEL_COLUMN_NAME + ") {" + READ_LINE + " \t\t this." + CAMEL_COLUMN_NAME + " = " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
					}else if("String".equals(W_TYPE)) {
						dtoMethod.append("\tpublic String get" + SET_GET_COLUMN_NAME + "() {" + READ_LINE + " \t\t return " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
						dtoMethod.append("\tpublic void set" + SET_GET_COLUMN_NAME + "(String " + CAMEL_COLUMN_NAME + ") {" + READ_LINE + " \t\t this." + CAMEL_COLUMN_NAME + " = " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
					}else if("Long".equals(W_TYPE)) {
						dtoMethod.append("\tpublic Long get" + SET_GET_COLUMN_NAME + "() {" + READ_LINE + " \t\t return " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
						dtoMethod.append("\tpublic void set" + SET_GET_COLUMN_NAME + "(Long " + CAMEL_COLUMN_NAME + ") {" + READ_LINE + " \t\t this." + CAMEL_COLUMN_NAME + " = " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
					}else if("Date".equals(W_TYPE)) {
						dtoMethod.append("\tpublic Date get" + SET_GET_COLUMN_NAME + "() {" + READ_LINE + " \t\t return " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
						dtoMethod.append("\tpublic void set" + SET_GET_COLUMN_NAME + "(Date " + CAMEL_COLUMN_NAME + ") {" + READ_LINE + " \t\t this." + CAMEL_COLUMN_NAME + " = " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
					}else if("Double".equals(W_TYPE)) {
						dtoMethod.append("\tpublic Double get" + SET_GET_COLUMN_NAME + "() {" + READ_LINE + " \t\t return " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
						dtoMethod.append("\tpublic void set" + SET_GET_COLUMN_NAME + "(Double " + CAMEL_COLUMN_NAME + ") {" + READ_LINE + " \t\t this." + CAMEL_COLUMN_NAME + " = " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
					}
				}
			}
		}

		String dtoContent = dtoMemer.toString() + "\n" + dtoMethod.toString();
		dtoContent = "public class "+upperTableName+"_VO {"+ READ_LINE + dtoContent + READ_LINE +"}";

		String wfullPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\createsource\\"+upperTableName+".java";
		String fullPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\source\\params\\"+upperTableName+".java";
		String wfullPath2 = SITE_WEB_ROOT_PATH + "\\pages\\sample\\createsource\\VO.java";

		FileUtil.writeFile(dtoContent, wfullPath, replaceMap);

		dataMap.put("voStr", dtoContent);
		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}

	public HashMap makeModelBySql(HashMap params) throws Exception {
		HashMap dataMap = new HashMap();
		HashMap replaceMap = new HashMap();
		StringBuilder dtoMemer = new StringBuilder(500);
		StringBuilder dtoMethod = new StringBuilder(500);

		String COLUMN_NAME = "";
		String MEM_VARI = "";
		String COLUMN_COMMENT = "";
		String CAMEL_COLUMN_NAME = "";
		String SET_GET_COLUMN_NAME = "";
		String W_TYPE = "";
		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String upperTableName = "";
		String lowerTableName = "";
		String camelTableName = "";
		String modelComment = (String) params.get("modelComment");
		String makeGetsetMethodYn = (String) params.get("makeGetsetMethodYn");

		if(!StringUtils.isEmpty(tableName)) {
			upperTableName = tableName.toUpperCase();
			lowerTableName = tableName.toLowerCase();
			camelTableName = StrUtil.toCamelCase(upperTableName);
		}

		List<HashMap> list = this.selectSqlInfo(params);

		if(ListUtil.isNotEmpty(list)) {

			for (HashMap rs : list) {


				Iterator it =  rs.entrySet().iterator();

			    while(it.hasNext()) {
			    	Map.Entry entry = (Map.Entry)it.next(); //current entry in a loop
//			        Object value = rs.get(key);
			    	String key = entry.getKey().toString();
			    	String value = entry.getValue().toString();


System.out.println(
		"key >> " + key + " : " + value
		);

			    }



				COLUMN_NAME = (String) rs.get("COLUMN_NAME");
				COLUMN_COMMENT = (String) rs.get("COLUMN_COMMENT");
				CAMEL_COLUMN_NAME = (String) rs.get("CAMEL_COLUMN_NAME");
				MEM_VARI = (String) rs.get("MEM_VARI");
				W_TYPE = (String) rs.get("W_TYPE");

				SET_GET_COLUMN_NAME = (String) rs.get("SET_GET_COLUMN_NAME");

				dtoMemer.append(READ_LINE);

				if(!StringUtils.isEmpty(COLUMN_COMMENT)) {
					if(modelComment.equals("Y_NEXT")) {

						if("Date".equals(W_TYPE)) dtoMemer.append("\t@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = \"yyyy-MM-dd HH:mm:ss\")" + READ_LINE);
						dtoMemer.append("\t"+ MEM_VARI);
						dtoMemer.append("\t/* " +COLUMN_COMMENT + " */" + READ_LINE);

					}else if(modelComment.equals("Y_UP")) {

						dtoMemer.append("\t/* " +COLUMN_COMMENT + " */" + READ_LINE);
						if("Date".equals(W_TYPE)) dtoMemer.append("\t@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = \"yyyy-MM-dd HH:mm:ss\")" + READ_LINE);
						dtoMemer.append("\t"+ MEM_VARI + READ_LINE);

					}else if(modelComment.equals("Y_BOTTOM")) {

						dtoMemer.append("\t"+ MEM_VARI + READ_LINE);
						if("Date".equals(W_TYPE)) dtoMemer.append("\t@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = \"yyyy-MM-dd HH:mm:ss\")" + READ_LINE);
						dtoMemer.append("\t/* " +COLUMN_COMMENT + " */" + READ_LINE);

					}else {
						dtoMemer.append("\t"+ MEM_VARI + READ_LINE);
					}
				}

				if(makeGetsetMethodYn.equals("Y")) {
					if("int".equals(W_TYPE) || "Integer".equals(W_TYPE)) {
						dtoMethod.append("\tpublic int get" + SET_GET_COLUMN_NAME + "() {" + READ_LINE + " \t\t return " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
						dtoMethod.append("\tpublic void set" + SET_GET_COLUMN_NAME + "(int " + CAMEL_COLUMN_NAME + ") {" + READ_LINE + " \t\t this." + CAMEL_COLUMN_NAME + " = " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
					}else if("String".equals(W_TYPE)) {
						dtoMethod.append("\tpublic String get" + SET_GET_COLUMN_NAME + "() {" + READ_LINE + " \t\t return " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
						dtoMethod.append("\tpublic void set" + SET_GET_COLUMN_NAME + "(String " + CAMEL_COLUMN_NAME + ") {" + READ_LINE + " \t\t this." + CAMEL_COLUMN_NAME + " = " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
					}else if("Long".equals(W_TYPE)) {
						dtoMethod.append("\tpublic Long get" + SET_GET_COLUMN_NAME + "() {" + READ_LINE + " \t\t return " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
						dtoMethod.append("\tpublic void set" + SET_GET_COLUMN_NAME + "(Long " + CAMEL_COLUMN_NAME + ") {" + READ_LINE + " \t\t this." + CAMEL_COLUMN_NAME + " = " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
					}else if("Date".equals(W_TYPE)) {
						dtoMethod.append("\tpublic Date get" + SET_GET_COLUMN_NAME + "() {" + READ_LINE + " \t\t return " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
						dtoMethod.append("\tpublic void set" + SET_GET_COLUMN_NAME + "(Date " + CAMEL_COLUMN_NAME + ") {" + READ_LINE + " \t\t this." + CAMEL_COLUMN_NAME + " = " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
					}else if("Double".equals(W_TYPE)) {
						dtoMethod.append("\tpublic Double get" + SET_GET_COLUMN_NAME + "() {" + READ_LINE + " \t\t return " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
						dtoMethod.append("\tpublic void set" + SET_GET_COLUMN_NAME + "(Double " + CAMEL_COLUMN_NAME + ") {" + READ_LINE + " \t\t this." + CAMEL_COLUMN_NAME + " = " + CAMEL_COLUMN_NAME + "; \n \t}" + READ_LINE);
					}
				}
			}
		}

		String dtoContent = dtoMemer.toString() + "\n" + dtoMethod.toString();
		dtoContent = "public class "+upperTableName+"_VO {"+ READ_LINE + dtoContent + READ_LINE +"}";

		String wfullPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\createsource\\"+upperTableName+".java";
		String fullPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\source\\params\\"+upperTableName+".java";
		String wfullPath2 = SITE_WEB_ROOT_PATH + "\\pages\\sample\\createsource\\VO.java";

		FileUtil.writeFile(dtoContent, wfullPath, replaceMap);

		dataMap.put("voStr", dtoContent);
		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}

	public HashMap makeSetGetExcute(HashMap params) throws Exception {
		HashMap dataMap = new HashMap();

		String kind = nvl((String) params.get("kind"));
		String infoSubKind = nvl((String) params.get("infoSubKind"));
		String infoSubKind2 = nvl((String) params.get("infoSubKind2"));
		String onTableName = "";
		String offTableName = "";
		List<HashMap> onlist = null;
		List<HashMap> offlist = null;
		List<HashMap> comlist = new ArrayList<HashMap>();

		String onVoName = "";
		String offVoName = "";

		if(kind.equals("1") && !infoSubKind2.contains(",")) {
			throw new Exception("no table name");
		}else {

			if(kind.equals("1")) {
				String[] tarray = infoSubKind2.split(",");
				onTableName = tarray[0];
				offTableName = tarray[1];
			}else {
				onTableName = nvl((String) params.get("onTableName"));
				offTableName = nvl((String) params.get("offTableName"));
			}

			if(onTableName.startsWith("TB_")) {
//				onVoName = StrUtil.toCamelCase(onTableName.replaceFirst("T_", "")) +  "VO";
				onVoName = StrUtil.toCamelCase(onTableName.replaceFirst("TB_", "")) +  "";
			}
//			offVoName = StrUtil.toCamelCase(offTableName) +  "VO";
			offVoName = StrUtil.toCamelCase(offTableName) +  "";





			params.put("tableName",onTableName);
			onlist = this.selectTableInfo(params);
			params.put("tableName",offTableName);
			try {
				offlist = this.selectTableInfo(params);
			} catch (Exception e) {
				// TODO: handle exception
			}


			HashMap replaceMap = new HashMap();
			StringBuilder dtoMemer = new StringBuilder(500);
			StringBuilder dtoMethod = new StringBuilder(500);

			String COLUMN_NAME = "";
			String COMMENTS = "";
			String MEM_VARI = "";
			String COLUMN_COMMENT = "";
			String OFF_COLUMN_NAME = "";
			String CAMEL_COLUMN_NAME = "";
			String SET_GET_COLUMN_NAME = "";
			String W_TYPE = "";
			String tableName = (String) params.get("tableName");
			String upperTableName = "";
			String lowerTableName = "";
			String camelTableName = "";

			if(!StringUtils.isEmpty(tableName)) {
				upperTableName = tableName.toUpperCase();
				lowerTableName = tableName.toLowerCase();
				camelTableName = StrUtil.toCamelCase(upperTableName);
			}


			HashMap onRs = null;
			HashMap offRs = null;
			boolean isPass = Boolean.FALSE;

			for (int i = 0; i < onlist.size(); i++) {
				onRs = onlist.get(i);
				COLUMN_NAME = (String) onRs.get("COLUMN_NAME");

				if(offlist != null && offlist.size() > 0) {
					for (int j = 0; j < offlist.size(); j++) {
						offRs = offlist.get(j);
						OFF_COLUMN_NAME = (String) offRs.get("COLUMN_NAME");
						if(COLUMN_NAME.equals(OFF_COLUMN_NAME)) {

							comlist.add((HashMap)onRs.clone());

							if(offlist.get(j).equals(onlist.get(i))) {
								offlist.remove(j);
							}else {
								offlist.remove(j);
								onlist.remove(i);
							}
							j--;
							i--;
							break;
						}
					}
				}
			}

			HashMap rs = null;

			String onVoNameFirstUpper = "";
			if(!"".equals(onVoName)) {
				onVoNameFirstUpper = onVoName.substring(0,1).toUpperCase() + onVoName.substring(1);
			}
			String offVoNameFirstlower = "";
			String offVoNameFirstUpper = "";
			if(!"".equals(offVoName)) {
				offVoNameFirstlower = offVoName.substring(0,1).toLowerCase() + offVoName.substring(1);
				offVoNameFirstUpper = offVoName.substring(0,1).toUpperCase() + offVoName.substring(1);
			}


			if(onlist != null && onlist.size() > 0) {
				dtoMethod.append(READ_LINE);
				dtoMethod.append("//------------------------" + onTableName + " 에만 존재  ---------------------" + READ_LINE);
				for (int i = 0; i < onlist.size(); i++) {
					rs = onlist.get(i);
					SET_GET_COLUMN_NAME = (String) rs.get("SET_GET_COLUMN_NAME");
					COLUMN_NAME = (String) rs.get("COLUMN_NAME");
					COMMENTS = (String) rs.get("COMMENTS");
					if(StringUtils.isEmpty(COMMENTS)) {
						COMMENTS = "";
					}else {
						COMMENTS = "/* "+COMMENTS + " */";
					}

//					System.out.println("onlist COLUMN_NAME >> " + COLUMN_NAME);
					dtoMethod.append("\tvo.set" + SET_GET_COLUMN_NAME + "(iVo.get" + SET_GET_COLUMN_NAME + "());\t" + COMMENTS + READ_LINE);
				}
			}

			if(comlist != null && comlist.size() > 0) {
				dtoMethod.append(READ_LINE);
				dtoMethod.append("//------------------------"+onTableName+", "+ offTableName+" 에만 같이  존재  ---------------------" + READ_LINE);
				for (int i = 0; i < comlist.size(); i++) {
					rs = comlist.get(i);
					SET_GET_COLUMN_NAME = (String) rs.get("SET_GET_COLUMN_NAME");
					COLUMN_NAME = (String) rs.get("COLUMN_NAME");
					COMMENTS = (String) rs.get("COMMENTS");
					if(StringUtils.isEmpty(COMMENTS)) {
						COMMENTS = "";
					}else {
						COMMENTS = "/* "+COMMENTS + " */";
					}

//					System.out.println("comlist COLUMN_NAME >> " + COLUMN_NAME);
					dtoMethod.append("\t"+offVoNameFirstlower+".set" + SET_GET_COLUMN_NAME + "(iVo.get" + SET_GET_COLUMN_NAME + "());\t" + COMMENTS + READ_LINE);
				}
			}

			if(offlist != null && offlist.size() > 0) {
				dtoMethod.append(READ_LINE);
				dtoMethod.append("//------------------------" + offTableName + " 에만 존재  ---------------------" + READ_LINE);
				for (int i = 0; i < offlist.size(); i++) {
					rs = offlist.get(i);
					SET_GET_COLUMN_NAME = (String) rs.get("SET_GET_COLUMN_NAME");
					COLUMN_NAME = (String) rs.get("COLUMN_NAME");
					COMMENTS = (String) rs.get("COMMENTS");
					if(StringUtils.isEmpty(COMMENTS)) {
						COMMENTS = "";
					}else {
						COMMENTS = "/* "+COMMENTS + " */";
					}

//					System.out.println("offlist COLUMN_NAME >> " + COLUMN_NAME);
					dtoMethod.append("\t"+offVoNameFirstlower+".set" + SET_GET_COLUMN_NAME + "(iVo.get" + SET_GET_COLUMN_NAME + "());\t" + COMMENTS + READ_LINE);
				}
			}

			String dtoContent = dtoMethod.toString();
//			System.out.println(dtoContent);

			String wfullPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\createsource\\SETGET.java";
			FileUtil.writeFile(dtoContent, wfullPath, replaceMap);
			dataMap.put("set1", dtoContent);
			dataMap.put("fullPath", wfullPath);
		}
		return dataMap;
	}


	public HashMap makeMybaitisSql(HashMap params) throws Exception {

		StringBuilder whereSql = new StringBuilder(500);
		StringBuilder selectSql = new StringBuilder(500);
		StringBuilder insertSql = new StringBuilder(500);
		StringBuilder insertValSql = new StringBuilder(500);
		StringBuilder updateSql = new StringBuilder(500);
		StringBuilder merge_updateSql = new StringBuilder(500);

		HashMap dataMap = new HashMap();
		HashMap replaceMap = new HashMap();

		String COLUMN_NAME = "";
		String COLUMN_COMMENT = "";
		String CAMEL_COLUMN_NAME = "";
		String COLUMNS = "";
		String PK = "";
		String orderByPK = "";
		String W_TYPE = "";
		String pkStr = "";
		String COMMENTS = "";
		String tableName = (String) params.get("tableName");
		String upperTableName = "";
		String lowerTableName = "";
		String camelTableName = "";
		String camelTableName2 = "";
		String camelTableName3 = "";
		if(!StringUtils.isEmpty(tableName)) {
			upperTableName = tableName.toUpperCase();
			lowerTableName = tableName.toLowerCase();
			camelTableName = StrUtil.toCamelCase(upperTableName);
			if(upperTableName.startsWith("T_")) {
				camelTableName2 = StrUtil.toCamelCase(upperTableName.replaceFirst("T_", ""));
				camelTableName3 = camelTableName2.substring(0,1).toUpperCase() + camelTableName2.substring(1);
			}
		}

		HashMap replaceMapperMap = new HashMap();
		replaceMapperMap.put("#tableName#",camelTableName3);
		replaceMapperMap.put("#voName#",camelTableName2);

		List<HashMap> list = this.selectTableInfo(params);

		if(list !=null && list.size() > 0 ) {

			whereSql.append("<trim prefix=\"WHERE\" prefixOverrides=\"AND\">" + READ_LINE);
			updateSql.append("\t\t SET " + READ_LINE);

			merge_updateSql.append("\t\t<trim prefix=\"WHERE\" prefixOverrides=\"AND\">" + READ_LINE);


//			for (HashMap rs : list) {
			for (int i = 0; i < list.size(); i++) {
			    HashMap rs = list.get(i);
				COLUMN_NAME = (String) rs.get("COLUMN_NAME");
				COLUMN_COMMENT = (String) rs.get("COLUMN_COMMENT");
				CAMEL_COLUMN_NAME = (String) rs.get("CAMEL_COLUMN_NAME");
				COLUMNS = (String) rs.get("COLUMNS");
				COMMENTS = (String) rs.get("COMMENTS");
				W_TYPE = (String) rs.get("W_TYPE");
				if(StringUtils.isEmpty(COMMENTS)) {
					COMMENTS = "";
				}else {
					COMMENTS = "/* "+COMMENTS + " */";
				}


				PK = (String) rs.get("PK");
				orderByPK = "";
				if("PK".equals(PK)) {
					pkStr = pkStr + "AND " + COLUMN_NAME + " = " + rTxt.replace("txt", CAMEL_COLUMN_NAME);
					orderByPK += "," + COLUMN_NAME;
				}else {
					merge_updateSql.append("\t\t\t<isNotEmpty property=\""+CAMEL_COLUMN_NAME+"\" prepend=\",\" removeFirstPrepend=\"true\">"+COLUMN_NAME+"= "+rTxt.replace("txt", CAMEL_COLUMN_NAME)+"</isNotEmpty>"  + READ_LINE);
				}

//				whereSql.append("\t\t\t<isNotEmpty property=\""+CAMEL_COLUMN_NAME+"\" prepend=\"AND\">" + READ_LINE);
//				whereSql.append("\t\t\t\tT1."+COLUMN_NAME+" = "+ rTxt.replace("txt", CAMEL_COLUMN_NAME) + READ_LINE);
//				whereSql.append("\t\t\t</isNotEmpty>" + READ_LINE);

//				whereSql.append("\t\t\t<if property=\""+CAMEL_COLUMN_NAME+"\">");
//				whereSql.append(""+COLUMN_NAME+" = "+ rTxt.replace("txt", CAMEL_COLUMN_NAME));
//				whereSql.append("</if>");

	            if("int".equals(W_TYPE) || "Integer".equals(W_TYPE) || "Long".equals(W_TYPE)) {
	              whereSql.append("\t\t\t<if test=\""+CAMEL_COLUMN_NAME+" != null and "+CAMEL_COLUMN_NAME+" != 0\">\n\t\t\t\tAND "+COLUMN_NAME+" = " + rTxt.replace("txt", CAMEL_COLUMN_NAME) +"\n\t\t\t</if>"  + READ_LINE);
	            }else {
	              whereSql.append("\t\t\t<if test=\""+CAMEL_COLUMN_NAME+" != null and "+CAMEL_COLUMN_NAME+" != ''\">\n\t\t\t\tAND "+COLUMN_NAME+" = " + rTxt.replace("txt", CAMEL_COLUMN_NAME) +"\n\t\t\t</if>"  + READ_LINE);
	            }


//				selectSql.append("\t\t\t," + COLUMN_NAME + " AS " + CAMEL_COLUMN_NAME + READ_LINE);
	            if((
	                COLUMN_NAME.equals("UPD_SABUN") ||
                    COLUMN_NAME.equals("UPD_DTM") ||
                    COLUMN_NAME.equals("REG_SABUN") ||
                    COLUMN_NAME.equals("REG_DTM") ||
                    COLUMN_NAME.equals("DEL_YN")
                    ) == false) {
	              selectSql.append("\t\t\t," + COLUMN_NAME + READ_LINE);
	            }

				insertSql.append(", " + COLUMN_NAME);
				insertValSql.append(", " + rTxt.replace("txt", CAMEL_COLUMN_NAME));

				if(i % COLUMN_CNT == 0) {
				  insertSql.append(READ_LINE + "\t\t");
				  insertValSql.append(READ_LINE + "\t\t");
				}else {

				}


				//updateSql.append("\t," + COLUMN_NAME + " = #" + CAMEL_COLUMN_NAME + "#\t\t\t" + COMMENTS + READ_LINE);
//				updateSql.append("\t\t\t<isNotEmpty property=\""+CAMEL_COLUMN_NAME+"\" prepend=\",\" removeFirstPrepend=\"true\">"+COLUMN_NAME+"= " + rTxt.replace("txt", CAMEL_COLUMN_NAME) +"</isNotEmpty>"  + READ_LINE);
				updateSql.append("\t\t\t<if test=\""+CAMEL_COLUMN_NAME+" != null\"> "+COLUMN_NAME+"= " + rTxt.replace("txt", CAMEL_COLUMN_NAME) +",</if>"  + READ_LINE);
			}
			whereSql.append("\t\t</trim>"  + READ_LINE);
			merge_updateSql.append("\t\t</trim>");
		}

		String rfullPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\copy\\sqlSample.xml";
		String wfullPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\source\\sql\\"+upperTableName+".xml";

		replaceMapperMap.put("#camelTableName#",camelTableName);

		String where = whereSql.toString();
		replaceMapperMap.put("#where#",where);


		String pks = "";
		if(!StringUtils.isEmpty(orderByPK)) {
			pks = "\n\t\tORDER BY " + orderByPK.replaceFirst(",", "");
		}

		String select = "\tSELECT " + READ_LINE + selectSql.toString().replaceFirst(",", " ") + "\t\tFROM " + upperTableName + " T1" + READ_LINE + "\t\t<include refid=\"where-"+camelTableName2+"List\"/>" + pks;
		replaceMapperMap.put("#select#", select);

		String selectCount = "\tSELECT " + READ_LINE + "COUNT(*) FROM " + upperTableName + " T1" + READ_LINE + "\t\t<include refid=\"where-"+camelTableName2+"List\"/>";
		replaceMapperMap.put("#selectCount#", selectCount);

		String insert = "INSERT INTO " + upperTableName + " (\n" + insertSql.toString().replaceFirst(",", " ") + "\t\t) "
				+ "" + READ_LINE + insertValSql.toString().replaceFirst(",", " ") + "\t)";
		replaceMapperMap.put("#insert#", insert);

		String update = "\tUPDATE " + upperTableName + READ_LINE +updateSql.toString() + "\n\t\tWHERE 1=1 " + pkStr;
		replaceMapperMap.put("#update#", update);

//		String merge = "\tUPDATE " + upperTableName + READ_LINE +updateSql.toString() + "\n\t\tWHERE 1=1 " + pkStr;
		String merge =    "\tMERGE INTO " + upperTableName + READ_LINE
						+ "\t\tUSING DUAL" + READ_LINE
					    + "\t\t\tON ("+pkStr.replaceFirst("AND ", "")+")" + READ_LINE
						+ "\t\tWHEN MATCHED THEN" + READ_LINE
						+ "\t\t\tUPDATE" + READ_LINE
						+ "" + merge_updateSql.toString() + READ_LINE
						+ "\t\tWHEN NOT MATCHED THEN" + READ_LINE
						+ "\t\t\tINSERT ("+ READ_LINE
						+ insertSql.toString().replaceFirst(",", " ").replace("\t", "\t\t")
						+ "\t\t) values (" + READ_LINE
						+ "\t" + insertValSql.toString().replaceFirst(",", " ").replace("\t", "\t\t")
						+ "\t\t)";
//		System.out.println("");
//		System.out.println(merge);
//		System.out.println("");

		replaceMapperMap.put("#merge#", merge);

//		FileUtil.writeFile("", wfullPath, replaceMapperMap);
		String sqlStr = FileUtil.copyFile(rfullPath, wfullPath, replaceMapperMap);

		dataMap.put("sqlStr", sqlStr);
		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}

	public HashMap makeIbaitisSql(HashMap params) throws Exception {

	  StringBuilder whereSql = new StringBuilder(500);
	  StringBuilder selectSql = new StringBuilder(500);
	  StringBuilder insertSql = new StringBuilder(500);
	  StringBuilder insertValSql = new StringBuilder(500);
	  StringBuilder updateSql = new StringBuilder(500);
	  StringBuilder merge_updateSql = new StringBuilder(500);

	  HashMap dataMap = new HashMap();
	  HashMap replaceMap = new HashMap();

	  String COLUMN_NAME = "";
	  String COLUMN_COMMENT = "";
	  String CAMEL_COLUMN_NAME = "";
	  String COLUMNS = "";
	  String PK = "";
	  String orderByPK = "";
	  String W_TYPE = "";
	  String pkStr = "";
	  String COMMENTS = "";
	  String tableName = (String) params.get("tableName");
	  String upperTableName = "";
	  String lowerTableName = "";
	  String camelTableName = "";
	  String camelTableName2 = "";
	  String camelTableName3 = "";
	  if(!StringUtils.isEmpty(tableName)) {
	    upperTableName = tableName.toUpperCase();
	    lowerTableName = tableName.toLowerCase();
	    camelTableName = StrUtil.toCamelCase(upperTableName);
	    if(upperTableName.startsWith("T_")) {
	      camelTableName2 = StrUtil.toCamelCase(upperTableName.replaceFirst("T_", ""));
	      camelTableName3 = camelTableName2.substring(0,1).toUpperCase() + camelTableName2.substring(1);
	    }
	  }

	  HashMap replaceMapperMap = new HashMap();
	  replaceMapperMap.put("#tableName#",camelTableName3);
	  replaceMapperMap.put("#voName#",camelTableName2);

	  List<HashMap> list = this.selectTableInfo(params);

	  if(list !=null && list.size() > 0 ) {

	    whereSql.append("<sql id=\"where-"+camelTableName2+"List\">" + READ_LINE);
	    whereSql.append("\t\t<dynamic prepend=\"WHERE\">" + READ_LINE);

//			updateSql.append("\t\t<dynamic prepend = \" SET \" >" + READ_LINE);
	    updateSql.append("\t\t SET " + READ_LINE);
	    merge_updateSql.append("\t\t<dynamic prepend = \" SET \" >" + READ_LINE);


//			for (HashMap rs : list) {
	    for (int i = 0; i < list.size(); i++) {
	      HashMap rs = list.get(i);
	      COLUMN_NAME = (String) rs.get("COLUMN_NAME");
	      COLUMN_COMMENT = (String) rs.get("COLUMN_COMMENT");
	      CAMEL_COLUMN_NAME = (String) rs.get("CAMEL_COLUMN_NAME");
	      COLUMNS = (String) rs.get("COLUMNS");
	      COMMENTS = (String) rs.get("COMMENTS");
	      W_TYPE = (String) rs.get("W_TYPE");
	      if(StringUtils.isEmpty(COMMENTS)) {
	        COMMENTS = "";
	      }else {
	        COMMENTS = "/* "+COMMENTS + " */";
	      }


	      PK = (String) rs.get("PK");
	      orderByPK = "";
	      if("PK".equals(PK)) {
	        pkStr = pkStr + "AND " + COLUMN_NAME + " = " + rTxt.replace("txt", CAMEL_COLUMN_NAME);
	        orderByPK += "," + COLUMN_NAME;
	      }else {
	        merge_updateSql.append("\t\t\t<isNotEmpty property=\""+CAMEL_COLUMN_NAME+"\" prepend=\",\" removeFirstPrepend=\"true\">"+COLUMN_NAME+"= "+rTxt.replace("txt", CAMEL_COLUMN_NAME)+"</isNotEmpty>"  + READ_LINE);
	      }

//				whereSql.append("\t\t\t<isNotEmpty property=\""+CAMEL_COLUMN_NAME+"\" prepend=\"AND\">" + READ_LINE);
//				whereSql.append("\t\t\t\tT1."+COLUMN_NAME+" = "+ rTxt.replace("txt", CAMEL_COLUMN_NAME) + READ_LINE);
//				whereSql.append("\t\t\t</isNotEmpty>" + READ_LINE);

//				whereSql.append("\t\t\t<if property=\""+CAMEL_COLUMN_NAME+"\">");
//				whereSql.append(""+COLUMN_NAME+" = "+ rTxt.replace("txt", CAMEL_COLUMN_NAME));
//				whereSql.append("</if>");

	      if("int".equals(W_TYPE) || "Integer".equals(W_TYPE) || "Long".equals(W_TYPE)) {
	        whereSql.append("\t\t\t<if test=\""+CAMEL_COLUMN_NAME+" != null and "+CAMEL_COLUMN_NAME+" != 0\">\n\t\t\t\tAND "+COLUMN_NAME+" = " + rTxt.replace("txt", CAMEL_COLUMN_NAME) +"\n\t\t\t</if>"  + READ_LINE);
	      }else {
	        whereSql.append("\t\t\t<if test=\""+CAMEL_COLUMN_NAME+" != null and "+CAMEL_COLUMN_NAME+" != ''\">\n\t\t\t\tAND "+COLUMN_NAME+" = " + rTxt.replace("txt", CAMEL_COLUMN_NAME) +"\n\t\t\t</if>"  + READ_LINE);
	      }


	      selectSql.append("\t\t\t," + COLUMN_NAME + " AS " + CAMEL_COLUMN_NAME + READ_LINE);

	      insertSql.append(", " + COLUMN_NAME);
	      insertValSql.append(", " + rTxt.replace("txt", CAMEL_COLUMN_NAME));

	      if(i % COLUMN_CNT == 0) {
	        insertSql.append(READ_LINE + "\t\t");
	        insertValSql.append(READ_LINE + "\t\t");
	      }else {

	      }


	      //updateSql.append("\t," + COLUMN_NAME + " = #" + CAMEL_COLUMN_NAME + "#\t\t\t" + COMMENTS + READ_LINE);
//				updateSql.append("\t\t\t<isNotEmpty property=\""+CAMEL_COLUMN_NAME+"\" prepend=\",\" removeFirstPrepend=\"true\">"+COLUMN_NAME+"= " + rTxt.replace("txt", CAMEL_COLUMN_NAME) +"</isNotEmpty>"  + READ_LINE);
	      updateSql.append("\t\t\t<if test=\""+CAMEL_COLUMN_NAME+" != null\"> "+COLUMN_NAME+"= " + rTxt.replace("txt", CAMEL_COLUMN_NAME) +",</if>"  + READ_LINE);
	    }
	    whereSql.append("\t\t</dynamic>"  + READ_LINE);
	    whereSql.append("\t</sql>" + READ_LINE);
//			updateSql.append("\t\t</dynamic>");
	    merge_updateSql.append("\t\t</dynamic>");
	  }

	  String rfullPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\copy\\sqlSample.xml";
	  String wfullPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\source\\sql\\"+upperTableName+".xml";

	  replaceMapperMap.put("#camelTableName#",camelTableName);

	  String where = whereSql.toString();
	  replaceMapperMap.put("#where#",where);


	  String pks = "";
	  if(!StringUtils.isEmpty(orderByPK)) {
	    pks = "\n\t\tORDER BY " + orderByPK.replaceFirst(",", "");
	  }

	  String select = "\tSELECT " + READ_LINE + selectSql.toString().replaceFirst(",", " ") + "\t\tFROM " + upperTableName + " T1" + READ_LINE + "\t\t<include refid=\"where-"+camelTableName2+"List\"/>" + pks;
	  replaceMapperMap.put("#select#", select);

	  String selectCount = "\tSELECT " + READ_LINE + "COUNT(*) FROM " + upperTableName + " T1" + READ_LINE + "\t\t<include refid=\"where-"+camelTableName2+"List\"/>";
	  replaceMapperMap.put("#selectCount#", selectCount);

	  String insert = "INSERT INTO " + upperTableName + " (\n" + insertSql.toString().replaceFirst(",", " ") + "\t\t) "
	      + "" + READ_LINE + insertValSql.toString().replaceFirst(",", " ") + "\t)";
	  replaceMapperMap.put("#insert#", insert);

	  String update = "\tUPDATE " + upperTableName + READ_LINE +updateSql.toString() + "\n\t\tWHERE 1=1 " + pkStr;
	  replaceMapperMap.put("#update#", update);

//		String merge = "\tUPDATE " + upperTableName + READ_LINE +updateSql.toString() + "\n\t\tWHERE 1=1 " + pkStr;
	  String merge =    "\tMERGE INTO " + upperTableName + READ_LINE
	      + "\t\tUSING DUAL" + READ_LINE
	      + "\t\t\tON ("+pkStr.replaceFirst("AND ", "")+")" + READ_LINE
	      + "\t\tWHEN MATCHED THEN" + READ_LINE
	      + "\t\t\tUPDATE" + READ_LINE
	      + "" + merge_updateSql.toString() + READ_LINE
	      + "\t\tWHEN NOT MATCHED THEN" + READ_LINE
	      + "\t\t\tINSERT ("+ READ_LINE
	      + insertSql.toString().replaceFirst(",", " ").replace("\t", "\t\t")
	      + "\t\t) values (" + READ_LINE
	      + "\t" + insertValSql.toString().replaceFirst(",", " ").replace("\t", "\t\t")
	      + "\t\t)";
//		System.out.println("");
//		System.out.println(merge);
//		System.out.println("");

	  replaceMapperMap.put("#merge#", merge);

//		FileUtil.writeFile("", wfullPath, replaceMapperMap);
	  String sqlStr = FileUtil.copyFile(rfullPath, wfullPath, replaceMapperMap);

	  dataMap.put("sqlStr", sqlStr);
	  dataMap.put("fullPath", wfullPath);
	  return dataMap;
	}

	public HashMap makeJson(HashMap params) throws Exception {

	  StringBuilder selectSql = new StringBuilder(500);

	  HashMap dataMap = new HashMap();
	  HashMap replaceMap = new HashMap();

	  String COLUMN_NAME = "";
	  String COLUMN_COMMENT = "";
	  String CAMEL_COLUMN_NAME = "";
	  String COLUMNS = "";
	  String PK = "";
	  String COMMENTS = "";
	  String tableName = (String) params.get("tableName");
	  String upperTableName = "";
	  String lowerTableName = "";
	  String camelTableName = "";
	  String camelTableName2 = "";
	  String camelTableName3 = "";
	  if(!StringUtils.isEmpty(tableName)) {
	    upperTableName = tableName.toUpperCase();
	    lowerTableName = tableName.toLowerCase();
	    camelTableName = StrUtil.toCamelCase(upperTableName);
	    if(upperTableName.startsWith("T_")) {
	      camelTableName2 = StrUtil.toCamelCase(upperTableName.replaceFirst("T_", ""));
	      camelTableName3 = camelTableName2.substring(0,1).toUpperCase() + camelTableName2.substring(1);
	    }
	  }

	  HashMap replaceMapperMap = new HashMap();
	  replaceMapperMap.put("#tableName#",camelTableName3);
	  replaceMapperMap.put("#voName#",camelTableName2);

	  List<HashMap> list = this.selectTableInfo(params);

	  String str = "";
	  if(list !=null && list.size() > 0 ) {

	    selectSql.append("{" + READ_LINE);

	    for (HashMap rs : list) {
	      COLUMN_NAME = (String) rs.get("COLUMN_NAME");
	      COLUMN_COMMENT = (String) rs.get("COLUMN_COMMENT");
	      CAMEL_COLUMN_NAME = (String) rs.get("CAMEL_COLUMN_NAME");
	      COLUMNS = (String) rs.get("COLUMNS");
	      COMMENTS = (String) rs.get("COMMENTS");

	      selectSql.append("\t\"" +CAMEL_COLUMN_NAME+ "\" : \"\"," + READ_LINE);
//	      selectSql.append(",\"" +CAMEL_COLUMN_NAME+ "\" : \"\"" + " /* "+COMMENTS + " */" + READ_LINE);
	    }
	    str = selectSql.toString();
	    str = str.substring(0,str.length()-2) + "\n}";
	  }

	  String wfullPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\source\\json\\"+upperTableName+".json";

	  String sqlStr = FileUtil.writeFile(wfullPath, str);
	  System.out.println(sqlStr);

	  dataMap.put("jsonStr", sqlStr);
	  dataMap.put("fullPath", wfullPath);
	  return dataMap;
	}


	public HashMap makeService(HashMap params) throws Exception {

		HashMap dataMap = new HashMap();
		HashMap replaceMap = new HashMap();

		String tableName = nvl((String) params.get("tableName"));
		String upperTableName = "";
		String lowerTableName = "";
		String camelTableName = "";
		String methodName = (String) params.get("methodName");

		if(!StringUtils.isEmpty(tableName)) {
			upperTableName = tableName.toUpperCase();
			lowerTableName = tableName.toLowerCase();
			camelTableName = StrUtil.toCamelCase(upperTableName);
		}



		String rfullPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\copy\\ServiceSample.java";
		String wfullPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\source\\service\\"+upperTableName+".java";

		String rImplPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\copy\\ServiceImplSample.java";
		String wImplfullPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\source\\service\\impl\\"+upperTableName+".java";

		HashMap replaceMapperMap = new HashMap();

		replaceMapperMap.put("#methodName#",methodName);


		FileUtil.writeFile("", rfullPath, replaceMap);

		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}

public HashMap makeController(HashMap params) throws Exception {

		HashMap dataMap = new HashMap();
		HashMap replaceMap = new HashMap();

		String COLUMN_NAME = "";
		String COLUMN_COMMENT = "";
		String CAMEL_COLUMN_NAME = "";
		String COLUMNS = "";
		String PK = "";
		String orderByPK = "";
		String pkStr = "";
		String COMMENTS = "";
		String tableName = (String) params.get("tableName");
		String upperTableName = "";
		String lowerTableName = "";
		String camelTableName = "";

		if(!StringUtils.isEmpty(tableName)) {
			upperTableName = tableName.toUpperCase();
			lowerTableName = tableName.toLowerCase();
			camelTableName = StrUtil.toCamelCase(upperTableName);
		}

		List<HashMap> list = this.selectTableInfo(params);

		if(list !=null && list.size() > 0 ) {
			for (HashMap rs : list) {
				COLUMN_NAME = (String) rs.get("COLUMN_NAME");
				COLUMN_COMMENT = (String) rs.get("COLUMN_COMMENT");
				CAMEL_COLUMN_NAME = (String) rs.get("CAMEL_COLUMN_NAME");
				COLUMNS = (String) rs.get("COLUMNS");
				COMMENTS = (String) rs.get("COMMENTS");


			}
		}

		String rfullPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\copy\\ServiceSample.java";
		String wfullPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\source\\service\\"+upperTableName+".java";

		String rImplPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\copy\\ServiceImplSample.java";
		String wImplfullPath = SITE_WEB_ROOT_PATH + "\\pages\\sample\\source\\service\\impl\\"+upperTableName+".java";

		HashMap replaceMapperMap = new HashMap();

//		FileUtil.writeFile("", wfullPath, replaceMapperMap);
		String sqlStr = FileUtil.copyFile(rfullPath, wfullPath, replaceMapperMap);

		dataMap.put("sqlStr", sqlStr);
		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}

	private static String nvl(String a, String b) {
		return a == null ? b : a;
	}

	private static String nvl(String a) {
		return a == null ? "" : a;
	}


}