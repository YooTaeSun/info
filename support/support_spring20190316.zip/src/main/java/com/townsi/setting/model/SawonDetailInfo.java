package com.townsi.setting.model;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SawonDetailInfo  {

  @NotNull(message="HqCd null")
  private String hqCd;

  @NotNull(message="deptCd null")
  private String deptCd;

  @NotNull(message="teamCd null")
  private String teamCd;

  @NotNull(message="sabun null")
  private String sabun;

  private String name;

  @NotNull(message="orgLevel null")
  private int orgLevel;

  @NotNull(message="enterCd null")
  private String enterCd;

  @NotNull(message="jikchakCd null")
  private String jikchakCd;

  private String hqName;

  private String deptName;

  private String teamName;

  private String jikgubName;


}
