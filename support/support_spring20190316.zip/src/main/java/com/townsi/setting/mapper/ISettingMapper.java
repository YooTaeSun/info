/*******************************************************************************
*  Project      : BGF Retail Mobile Store Management
*  Program ID   : CommonDAO.java
*  Description  : DAO의 자동화 설정
*
********************************************************************************
*  Program History
*  Date        Author    Description
*  ----------  --------  --------------------------------------------------------
*  2014-08-28  유태선    Created.
*******************************************************************************/

package com.townsi.setting.mapper;


import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public interface ISettingMapper {

    public Object insert(String queryId, Object params);
    public Object update(String queryId, Object params);
    public Object delete(String queryId, Object params);
    public Object selectOne(String queryId, Object params);
    public List selectList(String queryId, Object params);

	public List<HashMap> selectTableInfoByMysql(HashMap params);
	public List<HashMap> selectTableInfoByOracle(HashMap params);
	public List<HashMap> selectSqlInfo(HashMap params);
}