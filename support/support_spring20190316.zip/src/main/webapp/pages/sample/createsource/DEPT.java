public class DEPT_VO {

	private Long deptno;	/* 부서순번 */

	private String dname;	/* 부서이름 */

	private String loc;	/* 지역 */

	public Long getDeptno() {
 		 return deptno; 
 	}
	public void setDeptno(Long deptno) {
 		 this.deptno = deptno; 
 	}
	public String getDname() {
 		 return dname; 
 	}
	public void setDname(String dname) {
 		 this.dname = dname; 
 	}
	public String getLoc() {
 		 return loc; 
 	}
	public void setLoc(String loc) {
 		 this.loc = loc; 
 	}

}