
//------------------------DEPT, DEPT 에만 같이  존재  ---------------------
	dept.setDeptno(iVo.getDeptno());	/* 부서순번 */
	dept.setDname(iVo.getDname());	/* 부서이름 */
	dept.setLoc(iVo.getLoc());	/* 지역 */
