public class TB_APRV_BIZ_VO {

	private Long aprvBizSeq;

	private String untCd;

	private Long bizPlanSeq;

	private Integer hstSeq;

	private String resCd;

	private String resDet;

	private String schedUpdYn;

	private String acpYn;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date acpDtm;

	private String updSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updDtm;

	private String regSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date regDtm;

	private String delYn;


}