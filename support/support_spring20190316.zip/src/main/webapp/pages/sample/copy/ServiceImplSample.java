package kr.co.crewmate.site.service.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import kr.co.crewmate.site.dao.PromotionSendDao;
import kr.co.crewmate.site.model.ListResult;
import kr.co.crewmate.site.model.event.OsEventDetail;
import kr.co.crewmate.site.service.PromotionSendService;

@SuppressWarnings({"rawtypes","unchecked"})
@Service
public class PromotionSendServiceImpl implements PromotionSendService {


	@Inject private PromotionSendDao promotionSendDao;
	
	/**
     * 리스트 
     */
	@Override
	public ListResult get#methodName#List(OsEventDetail param) {
		ListResult listResult = new ListResult();
        listResult.setList(this.promotionSendDao.get#methodName#List(param));
        listResult.setListCount(this.promotionSendDao.get#methodName#ListCount(param));
        return listResult;		
	}
	
	/**
     * 상세 
     */
	@Override
	public OsEventDetail get#methodName#Info(OsEventDetail param) {
		return this.promotionSendDao.get#methodName#Info(param);
	}
	
	/**
     * 저장 
     */
    @Override
    public void insert#methodName#(OsEventDetail param) {
    	this.promotionSendDao.insert#methodName#(param);
    }
    
    /**
     * 수정 
     */
    @Override
    public void update#methodName#(OsEventDetail param) {
    	this.promotionSendDao.update#methodName#(param);
    }
	
}
