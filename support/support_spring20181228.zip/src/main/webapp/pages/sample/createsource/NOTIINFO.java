public class NOTIINFO_VO {


}