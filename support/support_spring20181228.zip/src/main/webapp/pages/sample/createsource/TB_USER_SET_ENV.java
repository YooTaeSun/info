public class TB_USER_SET_ENV_VO {

	private Integer userSetEnvSeq;

	private String untCd;

	private String sabun;

	private String userEnvGrp;

	private String userEnvTyp;

	private String userEnvCd;

	private String updSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updDtm;

	private String regSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date regDtm;

	private String delYn;


}