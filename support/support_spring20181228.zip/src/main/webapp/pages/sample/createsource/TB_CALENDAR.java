public class TB_CALENDAR_VO {

	private Integer id;

	private String dbDate;

	private Integer year;

	private Integer month;

	private Integer day;

	private Integer quarter;

	private Integer week;

	private String dayName;

	private String monthName;

	private String holidayFlag;

	private String weekendFlag;

	private String eventDay;


}