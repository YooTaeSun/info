public class TB_SAWON_INFO_VO {

	private Integer sawonSeq;

	private String enterCd;

	private String sabun;

	private String name;

	private String orgCode;

	private String orgCd;

	private String statusCd;

	private String stateName;

	private String jikchakCd;

	private String jikchakName;

	private String jikgubCd;

	private String jikgubName;

	private String jikgunCd;

	private String jikgunName;

	private String jobCd;

	private String jobNm;

	private String sdate;

	private String edate;

	private String gempYmd;

	private String empYmd;

	private String retYmd;

	private String updSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updDtm;

	private String regSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date regDtm;

	private String delYn;


}