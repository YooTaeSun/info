
//------------------------TB_BIZ_ACT 에만 존재  ---------------------
	vo.setBizActSeq(iVo.getBizActSeq());	/* 일지번호 */
	vo.setBizPlanSeq(iVo.getBizPlanSeq());	/* 업무계획번호 */
	vo.setHstSeq(iVo.getHstSeq());	/* 업무계획이력 */
	vo.setBizDetlPlanSeq(iVo.getBizDetlPlanSeq());	/* 업무상세번호 */
	vo.setUpperActSeq(iVo.getUpperActSeq());	/* 전파자의 활동계획번호 */
	vo.setRelpActSeq(iVo.getRelpActSeq());	/* 한일의 활동계획 SEQ */
	vo.setCoopCd(iVo.getCoopCd());	/* 협업구분 */
	vo.setActDt(iVo.getActDt());	/* 일자 */
	vo.setStartTm(iVo.getStartTm());	/* 시작시간 */
	vo.setEndTm(iVo.getEndTm());	/* 종료시간 */
	vo.setPrjCd(iVo.getPrjCd());	/* 분류 */
	vo.setPrjCdNm(iVo.getPrjCdNm());	/* 분류명 */
	vo.setRes(iVo.getRes());	/* 결과 */
	vo.setScore(iVo.getScore());	/* 점수 */
	vo.setEvalScore(iVo.getEvalScore());	/* 평가점수 */
	vo.setPrjTyp(iVo.getPrjTyp());	/* 업무유형 */
	vo.setDescr(iVo.getDescr());	/* 설명 */
	vo.setCategory(iVo.getCategory());	/* 일정종류 */
	vo.setAttr(iVo.getAttr());	/* 일정속성 */
	vo.setJntSchedSeq(iVo.getJntSchedSeq());	/* 공동일정번호 */
	vo.setLunchIncYn(iVo.getLunchIncYn());	/* 점심포함여부 */

//------------------------TB_BIZ_ACT, TB_BIZ_ACT_CHK 에만 같이  존재  ---------------------
	tbBizActChk.setUntCd(iVo.getUntCd());	/* 법인코드 */
	tbBizActChk.setTyp(iVo.getTyp());	/* 활동유형 */
	tbBizActChk.setSabun(iVo.getSabun());	/* 담당자 */
	tbBizActChk.setName(iVo.getName());	/* 담당자명 */
	tbBizActChk.setUpdSabun(iVo.getUpdSabun());	/* 수정자 */
	tbBizActChk.setUpdDtm(iVo.getUpdDtm());	/* 수정일시 */
	tbBizActChk.setRegSabun(iVo.getRegSabun());	/* 등록자 */
	tbBizActChk.setRegDtm(iVo.getRegDtm());	/* 등록일시 */
	tbBizActChk.setDelYn(iVo.getDelYn());	/* 삭제여부 */

//------------------------TB_BIZ_ACT_CHK 에만 존재  ---------------------
	tbBizActChk.setBizActChkSeq(iVo.getBizActChkSeq());	/* 점검번호 */
	tbBizActChk.setChkDt(iVo.getChkDt());	/* 점검일 */
	tbBizActChk.setOrgCd(iVo.getOrgCd());	/* 부서코드 */
	tbBizActChk.setOrgNm(iVo.getOrgNm());	/* 부서명 */
	tbBizActChk.setSelfChkYn(iVo.getSelfChkYn());	/* 자신의 점검여 */
	tbBizActChk.setSelfChkDtm(iVo.getSelfChkDtm());	/* 자신이 활동계획을 점검 날짜 */
	tbBizActChk.setWeek(iVo.getWeek());	/* 주간점검 */
	tbBizActChk.setOpn(iVo.getOpn());	/* 검토의견 */
	tbBizActChk.setSugg(iVo.getSugg());	/* 건의사항 */
	tbBizActChk.setChkOrgCd(iVo.getChkOrgCd());	/* 점검자부서코드 */
	tbBizActChk.setChkOrgNm(iVo.getChkOrgNm());	/* 점검자부서명 */
	tbBizActChk.setChkSabun(iVo.getChkSabun());	/* 점검자 */
	tbBizActChk.setChkName(iVo.getChkName());	/* 점검자이름 */
	tbBizActChk.setChkYn(iVo.getChkYn());	/* 점검여부 */
	tbBizActChk.setChkDtm(iVo.getChkDtm());	/* 점검일시 */
