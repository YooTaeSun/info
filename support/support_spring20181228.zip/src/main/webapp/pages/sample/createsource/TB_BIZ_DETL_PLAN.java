public class TB_BIZ_DETL_PLAN_VO {

	private Long bizDetlPlanSeq;

	private String untCd;

	private Long bizPlanSeq;

	private Integer hstSeq;

	private Long upperSeq;

	private String upperPrjCd;

	private String prjCd;

	private String prjCdNm;

	private Integer contrProg;

	private Integer prog;

	private String prjPoints;

	private Integer contrPrjRto;

	private Integer prjRto;

	private String startDt;

	private String endDt;

	private String respSabun;

	private String respName;

	private Integer prjImpt;

	private String prjDfclty;

	private String reqCap;

	private String assignRsn;

	private String prjEvalRes;

	private String state;

	private String duration;

	private String reqTm;

	private Long prevSeq;

	private String ord;

	private Integer lvl;

	private String mileYn;

	private String planMark;

	private String planDesc;

	private String cmplYn;

	private String updSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updDtm;

	private String regSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date regDtm;

	private String delYn;


}