public class TB_USER_LOG_INFO_VO {

	private Long userLogSeq;

	private String type;

	private String orgCd;

	private String orgNm;

	private String sabun;

	private String ipAddr;

	private String os;

	private String browser;

	private String name;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date connectDtm;

	private String updSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updDtm;

	private String regSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date regDtm;

	private String delYn;


}