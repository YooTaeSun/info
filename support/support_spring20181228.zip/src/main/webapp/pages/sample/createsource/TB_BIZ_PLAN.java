public class TB_BIZ_PLAN_VO {

	/* 업무계획번호(과제번호) */
	private Integer bizPlanSeq;

	/* 법인코드 */
	private String untCd;

	/* 업무계획이력번호(과제이력번호) */
	private Integer hstSeq;

	/* 업무유형(과제구분) */
	private String prjTyp;

	/* 업무명(과제명) */
	private String prjNm;

	/* 업무정의(요약) */
	private String prjDef;

	/* 업무목표(과제목적) */
	private String prjGoal;

	/* 업무중요도(과제중요도) */
	private String prjImpt;

	/* 업무 난이 */
	private Integer prjDfclty;

	/* 업무중요도기준 */
	private String prjImptStd;

	/* 업무평가결과 */
	private String prjEvalRes;

	/* 업무평기기준 */
	private String prjEvalStd;

	/* 업무총점 */
	private Integer prjTotScr;

	/* 업무계획상태(과제진행상태) */
	private String prjPlanSt;

	/* 업무진행상태 */
	private String prjProgSt;

	/* 업무코드 */
	private String prjCd;

	/* 업무책임자 */
	private String respSabun;

	/* 업무책임자명 */
	private String respName;

	/* 업무담당부서코드 */
	private String respOrgCd;

	/* 업무당부서명 */
	private String respOrgNm;

	/* 주관부서코드 */
	private String supvOrgCd;

	/* 주관부서명 */
	private String supvOrgNm;

	/* 업무정의만으로 승인 여부 */
	private String simpleAprvYn;

	/* 진척율 */
	private Integer prog;

	/* 레이블 색상 */
	private String lblColor;

	/* 변경 내용 */
	private String chgDesc;

	/* 업무시작일(과제시작일) */
	private String startDt;

	/* 완료예상목표일(과제예상종료일) */
	private String endDt;

	/* 승인실행여부 */
	private String aprvYn;

	/* 수정자 */
	private String updSabun;

	/* 수정일시 */
	private DATE updDtm;

	/* 등록자 */
	private String regSabun;

	/* 등록일시 */
	private DATE regDtm;

	/* 삭제여부 */
	private String delYn;


}