public class POSTS_VO {

	/* 아이디 */
	private Integer id;

	/* 제목 */
	private String subject;

	private String content;

	private DATE created;

	private Float userId;

	private String userName;

	private Integer hit;

	private String hitCount;


}