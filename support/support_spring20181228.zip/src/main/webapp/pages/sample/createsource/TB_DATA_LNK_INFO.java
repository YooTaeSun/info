public class TB_DATA_LNK_INFO_VO {

	private Integer dataLnkSeq;

	private Long bizDetlPlanSeq;

	private String untCd;

	private Long bizPlanSeq;

	private Integer hstSeq;

	private String type;

	private Long srcSeq;

	private Long trgtSeq;

	private String updSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updDtm;

	private String regSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date regDtm;

	private String delYn;


}