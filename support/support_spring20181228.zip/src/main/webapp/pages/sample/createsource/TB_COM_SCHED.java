public class TB_COM_SCHED_VO {

	private String comSchedId;

	private String untCd;

	private String typ;

	private String startDt;

	private String startTm;

	private String endDt;

	private String endTm;

	private String title;

	private String descr;

	private String updSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updDtm;

	private String regSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date regDtm;

	private String delYn;


}