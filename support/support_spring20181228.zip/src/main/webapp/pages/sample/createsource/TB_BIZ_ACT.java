public class TB_BIZ_ACT_VO {

	private Long bizActSeq;

	private String untCd;

	private Long bizPlanSeq;

	private Integer hstSeq;

	private Long bizDetlPlanSeq;

	private Long upperActSeq;

	private Long relpActSeq;

	private String typ;

	private String coopCd;

	private String sabun;

	private String name;

	private String actDt;

	private String startTm;

	private String endTm;

	private String prjCd;

	private String prjCdNm;

	private String res;

	private String score;

	private String evalScore;

	private String prjTyp;

	private String descr;

	private String category;

	private String attr;

	private Long jntSchedSeq;

	private String lunchIncYn;

	private String updSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updDtm;

	private String regSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date regDtm;

	private String delYn;


}