public class TB_BIZ_ACT_CHK_VO {

	private Long bizActChkSeq;

	private String sabun;

	private String chkDt;

	private String untCd;

	private String orgCd;

	private String orgNm;

	private String name;

	private String selfChkYn;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date selfChkDtm;

	private String typ;

	private String week;

	private String opn;

	private String sugg;

	private String chkOrgCd;

	private String chkOrgNm;

	private String chkSabun;

	private String chkName;

	private String chkYn;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date chkDtm;

	private String updSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updDtm;

	private String regSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date regDtm;

	private String delYn;


}