public class TB_SYS_CMN_CD_VO {

	private Integer sysCmnCdSeq;

	private String untCd;

	private String cmnCdGrp;

	private String cmnCdTyp;

	private String cmnCd;

	private String cmnCdDesc;

	private String updSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updDtm;

	private String regSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date regDtm;

	private String delYn;


}