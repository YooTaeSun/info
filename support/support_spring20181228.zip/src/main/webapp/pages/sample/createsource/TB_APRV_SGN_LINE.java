public class TB_APRV_SGN_LINE_VO {

	private Long aprvSgnLineSeq;

	private Long aprvBizSeq;

	private String untCd;

	private Long bizPlanSeq;

	private Integer hstSeq;

	private String acpSabun;

	private String acpYn;

	private String opn;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date acpDtm;

	private String updSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updDtm;

	private String regSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date regDtm;

	private String delYn;


}