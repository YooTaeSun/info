public class TB_ORG_INFO_VO {

	private Long orgSeq;

	private String enterCd;

	private String orgCd;

	private String orgName;

	private String orgCode;

	private String orgUpperCd;

	private String sdate;

	private String edate;

	private String base1Cd;

	private Long seq;

	private Integer orgLevel;

	private String updSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updDtm;

	private String regSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date regDtm;

	private String delYn;


}