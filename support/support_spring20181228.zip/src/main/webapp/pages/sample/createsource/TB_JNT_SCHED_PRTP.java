public class TB_JNT_SCHED_PRTP_VO {

	private Long jntSchedPrtpSeq;

	private Long jntSchedSeq;

	private Long bizDetlPlanSeq;

	private String untCd;

	private Long bizPlanSeq;

	private Integer hstSeq;

	private String comSchedId;

	private Long bizActSeq;

	private String sabun;

	private String name;

	private String startDt;

	private String startTm;

	private String endDt;

	private String endTm;

	private String indvTmYn;

	private String attr;

	private String updSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updDtm;

	private String regSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date regDtm;

	private String delYn;


}