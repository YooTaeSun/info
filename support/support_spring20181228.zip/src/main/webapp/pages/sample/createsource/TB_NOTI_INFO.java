public class TB_NOTI_INFO_VO {

	private Long notiInfoSeq;	/* 알림메시지번호 */

	private String type;	/* 알림타입 */

	private String title;	/* 알림제목 */

	private String content;	/* 알림내용 */

	private String lnkContent;	/* 상세링크정보 */

	private String lnkFirst;	/* 첫번째링크정보 */

	private String lnkSecond;	/* 두번째링크정보 */

	private String lnkThird;	/* 세번째링크정보 */

	private String recvSabun;	/* 받는사람사번 */

	private String recvName;	/* 받는사람이름 */

	private String sndName;	/* 보낸사람이름 */

	private String chkYn;	/* 확인여부 */

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date chkDtm;	/* 확인일시 */

	private String updSabun;	/* 수정자 */

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updDtm;	/* 수정일시 */

	private String regSabun;	/* 등록자 */

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date regDtm;	/* 등록일시 */

	private String delYn;	/* 삭제여부 */

	public Long getNotiInfoSeq() {
 		 return notiInfoSeq; 
 	}
	public void setNotiInfoSeq(Long notiInfoSeq) {
 		 this.notiInfoSeq = notiInfoSeq; 
 	}
	public String getType() {
 		 return type; 
 	}
	public void setType(String type) {
 		 this.type = type; 
 	}
	public String getTitle() {
 		 return title; 
 	}
	public void setTitle(String title) {
 		 this.title = title; 
 	}
	public String getContent() {
 		 return content; 
 	}
	public void setContent(String content) {
 		 this.content = content; 
 	}
	public String getLnkContent() {
 		 return lnkContent; 
 	}
	public void setLnkContent(String lnkContent) {
 		 this.lnkContent = lnkContent; 
 	}
	public String getLnkFirst() {
 		 return lnkFirst; 
 	}
	public void setLnkFirst(String lnkFirst) {
 		 this.lnkFirst = lnkFirst; 
 	}
	public String getLnkSecond() {
 		 return lnkSecond; 
 	}
	public void setLnkSecond(String lnkSecond) {
 		 this.lnkSecond = lnkSecond; 
 	}
	public String getLnkThird() {
 		 return lnkThird; 
 	}
	public void setLnkThird(String lnkThird) {
 		 this.lnkThird = lnkThird; 
 	}
	public String getRecvSabun() {
 		 return recvSabun; 
 	}
	public void setRecvSabun(String recvSabun) {
 		 this.recvSabun = recvSabun; 
 	}
	public String getRecvName() {
 		 return recvName; 
 	}
	public void setRecvName(String recvName) {
 		 this.recvName = recvName; 
 	}
	public String getSndName() {
 		 return sndName; 
 	}
	public void setSndName(String sndName) {
 		 this.sndName = sndName; 
 	}
	public String getChkYn() {
 		 return chkYn; 
 	}
	public void setChkYn(String chkYn) {
 		 this.chkYn = chkYn; 
 	}
	public Date getChkDtm() {
 		 return chkDtm; 
 	}
	public void setChkDtm(Date chkDtm) {
 		 this.chkDtm = chkDtm; 
 	}
	public String getUpdSabun() {
 		 return updSabun; 
 	}
	public void setUpdSabun(String updSabun) {
 		 this.updSabun = updSabun; 
 	}
	public Date getUpdDtm() {
 		 return updDtm; 
 	}
	public void setUpdDtm(Date updDtm) {
 		 this.updDtm = updDtm; 
 	}
	public String getRegSabun() {
 		 return regSabun; 
 	}
	public void setRegSabun(String regSabun) {
 		 this.regSabun = regSabun; 
 	}
	public Date getRegDtm() {
 		 return regDtm; 
 	}
	public void setRegDtm(Date regDtm) {
 		 this.regDtm = regDtm; 
 	}
	public String getDelYn() {
 		 return delYn; 
 	}
	public void setDelYn(String delYn) {
 		 this.delYn = delYn; 
 	}

}