public class TB_MGR_INFO_VO {

	private Integer mgrSeq;

	private String enterCd;

	private String orgCd;

	private String sabun;

	private String sdate;

	private String edate;

	private String name;

	private String jikgubCd;

	private String jikweeCd;

	private String jobCd;

	private String jikchakCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date chkdate;

	private String chkid;

	private String ordYmd;

	private Long applySeq;

	private String udGubun;

	private String updSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updDtm;

	private String regSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date regDtm;

	private String delYn;


}