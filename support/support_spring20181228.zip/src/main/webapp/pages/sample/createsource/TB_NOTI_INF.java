public class TB_NOTI_INF_VO {


}