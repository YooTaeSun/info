public class TB_USER_INFO_VO {

	private Integer userSeq;

	private String enterCd;

	private String sabun;

	private String password;

	private String name;

	private String orgCd;

	private String orgName;

	private String imgPath;

	private String updSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updDtm;

	private String regSabun;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date regDtm;

	private String delYn;


}