package kr.co.crewmate.site.dao;

import java.util.List;

import kr.co.crewmate.site.model.event.OsEventDetail;

public interface PromotionSendDao {
	
	List<OsEventDetail> get#methodName#List(OsEventDetail param);
	
	int get#methodName#ListCount(OsEventDetail param);
	
	OsEventDetail get#methodName#Info(OsEventDetail param);
	
	void insert#methodName#(OsEventDetail param);
	
	void update#methodName#(OsEventDetail param);
}
