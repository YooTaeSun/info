package kr.co.crewmate.site.web.controller.SITE;

import java.util.List;

import javax.inject.Inject;

import kr.co.crewmate.site.model.ListResult;
import kr.co.crewmate.site.model.Parameter;
import kr.co.crewmate.site.model.counsel.CustomerCounsel;
import kr.co.crewmate.site.model.counsel.CustomerCounselCriteria;
import kr.co.crewmate.site.model.counsel.CustomerCounselParam;
import kr.co.crewmate.site.model.counsel.InqueryAnswerHistory;
import kr.co.crewmate.site.model.user.UserGroup;
import kr.co.crewmate.site.service.CounselInquiryService;
import kr.co.crewmate.site.service.CustomerCounselService;
import kr.co.crewmate.site.service.MessageService;
import kr.co.crewmate.site.web.controller.SITEController;
import kr.co.crewmate.site.web.security.Access;
import kr.co.crewmate.site.web.taglib.PageHolder;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.json.MappingJacksonJsonView;

@Controller
public class #biz_firstUpper#Controller extends SITEController{
    
    @Inject
    private #biz_firstUpper#Service #biz_firstLower#Service;
    
    @Inject
    private MessageService messageService;
    

    /**
     * 고객상담 접수 폼
     * @param model
     * @param criteria
     * @return
     */
    @Access(value = "000602", auth = "R")
    @RequestMapping("#menuUrl#customerCounselForm")
    public ModelAndView customerCounselForm(ModelMap model, CustomerCounselCriteria criteria) {
        return new ModelAndView("SITE/customerCounsel/editCustomerCounsel");
    }
    
    /**
     * 검색회원 리스트
     * @param model
     * @param criteria
     * @return
     */
    @Access
    @RequestMapping("#menuUrl#userList")
    public ModelAndView userList(ModelMap model, CustomerCounselCriteria criteria, CustomerCounsel customerCounsel) {
        ListResult<CustomerCounsel> listResult = this.customerCounselService.getUserList(criteria);
        ListResult<UserGroup> groupList = this.customerCounselService.getUserGroup(customerCounsel);
        PageHolder pageHolder = new PageHolder(listResult.getListCount(), criteria.getPage(), criteria.getListSize());
        
        model.addAttribute("userList", listResult.getList());
        model.addAttribute("groupList", groupList.getList());
        model.addAttribute("groupListCnt", groupList.getListCount());
        model.addAttribute("pageHolder", pageHolder);
        model.addAttribute("criteria", criteria);
        
        return new ModelAndView("SITE/customerCounsel/listCustomerCounsel");
    }
    
    /**
     * 회원정보 얻어오기
     * @param model
     * @param userId
     * @return
     */
    @Access
    @RequestMapping("#menuUrl#getUserInfo")
    public View getUserInfo(ModelMap model, CustomerCounsel criteria) {
        CustomerCounsel userInfo = this.customerCounselService.getUserInfoDetail(criteria);
        ListResult<UserGroup> groupList = this.customerCounselService.getUserGroup(criteria);
        model.addAttribute("groupList", groupList.getList());
        model.addAttribute("groupListCnt", groupList.getListCount());
        model.addAttribute("userInfo", userInfo);
        return new MappingJacksonJsonView();
    }
    
    /**
     * <pre>
     * 고객상담 내용 및 답변 등록
     * </pre>
     * @param model
     * @param param
     * @param answer
     * @return
     */
    @Access(value = "000602", auth = "W")
    @RequestMapping("#menuUrl#saveCustomerCounsel")
    public View saveCustomerCounsel(ModelMap model, CustomerCounselParam param, InqueryAnswerHistory answer) {
        List<Parameter> errorMessages = param.validate(this.messageService.getMessageHandler());
        answer.setAswrAdminId(this.getAdmin().getId());
        if("03".equals(param.getCnslIngStatCode())){
            answer.setLastAswrYn(true);
        }
        
        boolean save = true;

        if (errorMessages.isEmpty()) {
            int cnslSeq = this.customerCounselService.createCustomerCounsel(param);
            answer.setCnslSeq(cnslSeq);
            this.counselInquiryService.createInqueryAnswer(answer);
        } else {
            save = false;
        }

        model.addAttribute("save", save);
        model.addAttribute(this.errorMessageKey, errorMessages);
        return new MappingJacksonJsonView();
    }
    
}
