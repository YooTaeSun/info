package com.townsi.utils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
public class CompareUtil {
	
	final static Log log = LogFactory.getLog(CompareUtil.class);

	public static enum COMPARE {
		GET_METHOD_ALL("ALL"),
		GET_METHOD_LIST("LIST"),
		GET_METHOD_START_GETNAME_LIST("START_GET_LIST"),
		GET_METHOD_START_NO_GETNAME_LIST("START_NO_GET_LIST");

		private final String value;

		private COMPARE(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}
	}

	
	/**
	 * 데이터를 비교한다.
	 * @throws InvocationTargetException 
	 * @throws IllegalArgumentException 
	 * @throws IllegalAccessException 
	 */
	private static LinkedHashMap<String,String> exceCompareGetVal(COMPARE type, Object o1, Object o2, List<String> compareFieldList, Map<String, String> otherMappingMap, boolean isContinue) {
		
		LinkedHashMap<String, String> differMap = new LinkedHashMap<String, String>(); 
		
		Class<? extends Object> o1Clsss = o1.getClass();
		Class<? extends Object> o2Clsss = o2.getClass();

		Method o1cMethods[] = o1Clsss.getMethods();
		Method o2cMethods[] = o2Clsss.getMethods();

		Object[] paramArgs = null;// param
		Class<?> o1Type = null;
		Class<?> o2Type = null;
		Object o1Val = null;
		Object o2Val = null;
		String o1MethodName = "";
		String o2MethodName = "";

		Map<String, Object> o1cMethodsMap = new HashMap<String, Object>();
		for (int i = 0; i < o1cMethods.length; i++) {
			Method o1Method = o1cMethods[i];
			o1MethodName = o1Method.getName();
			if (o1MethodName.startsWith("get") && !o1MethodName.equals("getClass")) {
				o1cMethodsMap.put(o1MethodName, o1cMethods[i]);
			}
		}

		if (compareFieldList == null) {
			compareFieldList = new ArrayList<String>(o1cMethodsMap.keySet());
		}

		Map<String, Object> o2cMethodsMap = new HashMap<String, Object>();
		for (int i = 0; i < o2cMethods.length; i++) {
			Method o2Method = o2cMethods[i];
			o2MethodName = o2Method.getName();
			if (o2MethodName.startsWith("get") && !o2MethodName.equals("getClass")) {
				o2cMethodsMap.put(o2MethodName, o2cMethods[i]);
			}
		}

		boolean isMapping = Boolean.TRUE;
		if (otherMappingMap == null) {
			isMapping = Boolean.FALSE;
		}

		String getName1 = "";
		String getName2 = "";
		String name1 = "";
		String name2 = "";

		try {
			for (String getMethod : compareFieldList) {
				if (COMPARE.GET_METHOD_START_NO_GETNAME_LIST.getValue().equals(type.getValue())) {
					getName1 = "get" + getMethod.substring(0, 1).toUpperCase() + getMethod.substring(1);
					getName2 = getName1;
					name1 = getMethod;
					name2 = getMethod;
				} else {
					getName1 = getMethod;
					getName2 = getMethod;
					name1 = getMethod.substring(3, 4).toLowerCase() + getMethod.substring(4);
					name2 = name1;
				}
	
				if (isMapping) {
					if (otherMappingMap.containsKey(name1)) {
						name2 = otherMappingMap.get(name1);
						getName2 = "get" + name2.substring(0, 1).toUpperCase() + name2.substring(1);
					}
				}
	
				if (o1cMethodsMap.containsKey(getName1) && o2cMethodsMap.containsKey(getName2)) {
	
					Method o1Method = (Method) o1cMethodsMap.get(getName1);
					o1Val = o1Method.invoke(o1, paramArgs);
					o1Type = o1Method.getReturnType();
	
					Method o2Method = (Method) o2cMethodsMap.get(getName2);
					o2Val = o2Method.invoke(o2, paramArgs);
					o2Type = o2Method.getReturnType();
	
					log.debug("getMethod >> " + getMethod);
					log.debug("o1Val >> " + o1Val);
					log.debug("o2Val >> " + o2Val);
					log.debug("o1Type >> " + o1Type);
					log.debug("o2Type >> " + o2Type);
	
					String result = "";
	
					if (o1Val != null && o2Val != null && o1Val.equals(o2Val) && o1Type.equals(o2Type)) {
						result = "SAME";
	
						log.debug("result >> " + result);
						log.debug("");
						log.debug("----------------------------------");
					} else if (o1Val == null && o2Val == null) {
						result = "NULL SAME";
	
						log.debug("result >> " + result);
						log.debug("");
						log.debug("----------------------------------");
					} else {
						result = "NOT SAME";
						differMap.put(name1, o1Val + " -> " + o2Val);
						log.debug("result >> " + result);
						log.debug("");
						log.debug("----------------------------------");
						if(!isContinue) {
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
		return differMap;
	}


	public static boolean isDifferGetVal(Object o1, Object o2) {
		LinkedHashMap<String, String> differMap = exceCompareGetVal(COMPARE.GET_METHOD_ALL, o1, o2, null, null, false);
		return (differMap.size() == 0)? false : true; 
	}

	public static boolean isDifferGetVal(Object o1, Object o2, COMPARE type) throws Exception{
		LinkedHashMap<String, String> differMap = exceCompareGetVal(type, o1, o2, null, null, false);
		return (differMap.size() == 0)? false : true;  
	}

	public static boolean isDifferGetVal(Object o1, Object o2, COMPARE type, List<String> compareFieldList) {
		if (COMPARE.GET_METHOD_LIST.getValue().equals(type.getValue())) {
			type = COMPARE.GET_METHOD_START_NO_GETNAME_LIST;
		}
		LinkedHashMap<String, String> differMap = exceCompareGetVal(type, o1, o2, compareFieldList, null, false); 
		return (differMap.size() == 0)? false : true;   
	}

	public static boolean isDifferGetVal(Object o1, Object o2, COMPARE type, List<String> compareFieldList, Map<String, String> otherMappingMap) {
		if (COMPARE.GET_METHOD_LIST.getValue().equals(type.getValue())) {
			type = COMPARE.GET_METHOD_START_NO_GETNAME_LIST;
		}
		LinkedHashMap<String, String> differMap = exceCompareGetVal(type, o1, o2, compareFieldList, otherMappingMap ,false);
		return (differMap.size() == 0)? false : true;   
	}
	
	public static LinkedHashMap<String, String> isDifferGetMap(Object o1, Object o2, COMPARE type, List<String> compareFieldList) {
		if (COMPARE.GET_METHOD_LIST.getValue().equals(type.getValue())) {
			type = COMPARE.GET_METHOD_START_NO_GETNAME_LIST;
		}
		return exceCompareGetVal(type, o1, o2, compareFieldList, null, true);  
	}
	
	public static boolean isDiffer(List<?> CompareList, List<?> CompareList2, List<String> compareFieldList) {
		boolean isDiffer =  Boolean.FALSE;
    	
    	if((CompareList == null && CompareList2 == null) || 
    	   (CompareList.size() == 0 && CompareList2.size()== 0)) {
    		isDiffer =  Boolean.FALSE;
    	}else if(CompareList.size() > 0 && CompareList.size() == CompareList2.size()) {
    		for (int i = 0; i < CompareList.size(); i++) {
    			if(CompareUtil.isDifferGetVal(CompareList.get(i), CompareList2.get(i), COMPARE.GET_METHOD_LIST,compareFieldList)) {
    				isDiffer = Boolean.TRUE;
    				break;
    			}
			}
    	}
    	return isDiffer;
	}
	
	public static boolean  isDiffer(Object obj, Object obj2, List<String> compareFieldList) {
		return CompareUtil.isDifferGetVal(obj, obj2, COMPARE.GET_METHOD_LIST,compareFieldList);
	}
	
	//변경된 map정보 리턴
	public static LinkedHashMap<String, String> isDifferMap(Object obj, Object obj2, List<String> compareFieldList) {
		return CompareUtil.isDifferGetMap(obj, obj2, COMPARE.GET_METHOD_LIST, compareFieldList);
	}

//	public static void main(String[] args) {
//		Person o1 = new Person("Korean", "John", 10, "Doctor", "aaaa");
//		Human o2 = new Human("Korean", "John", 10, "Doctor");
//
//		List<String> compareFieldList = new ArrayList<String>();
//		compareFieldList.add("age");
//		compareFieldList.add("name");
//		compareFieldList.add("job");
//		compareFieldList.add("space");
//
//		Map<String, String> otherMappingMap = new HashMap<String, String>();
//		otherMappingMap.put("space2", "name");
//		boolean isSame =  Boolean.TRUE;
//		try {
////			 isSame = isDifferGetVal(o1, o2);// o1기준 get메서드 다 비교
////			 isSame = isDifferGetVal(o1, o2, COMPARE.GET_METHOD_ALL);//get메서드 다 비교
////			 isSame = isDifferGetVal(o1, o2, COMPARE.GET_METHOD_LIST, compareFieldList);
//			 isSame = isDifferGetVal(o1, o2, COMPARE.GET_METHOD_LIST, compareFieldList ,otherMappingMap);
//
//			 log.debug("isSame boolean >> " + isSame);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

}