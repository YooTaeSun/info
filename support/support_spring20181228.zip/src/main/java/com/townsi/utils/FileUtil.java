package com.townsi.utils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

public class FileUtil {
	public static String readFile(String filePath) {
		BufferedReader br = null;
		StringBuilder sb = null;
		try {
			br = new BufferedReader(new FileReader(filePath));
			String line = "";
			sb = new StringBuilder(1000);
			while ((line = br.readLine()) != null)
				sb.append(line + "\r\n");
		} catch (Exception e) {
			e.printStackTrace();

			if (br != null)
				try {
					br.close();
				} catch (IOException localIOException) {
				}
		} finally {
			if (br != null)
				try {
					br.close();
				} catch (IOException localIOException1) {
				}
		}
		return sb.toString();
	}

	public static LinkedHashMap<String, String> readFileMap(String filePath) {
		BufferedReader br = null;
		LinkedHashMap propMap = new LinkedHashMap();
		try {
			br = new BufferedReader(new FileReader(filePath));
			String line = "";
			StringBuilder sb = new StringBuilder(1000);
			StringBuilder sqlSb = null;
			String lineKey = "";
			while ((line = br.readLine()) != null) {
				sb.append(line + "\r\n");
				int equaIndex = line.indexOf("=");

				if ((!line.trim().equals("")) && (!line.startsWith("#")) && (equaIndex >= 0)) {
					lineKey = line.substring(0, line.indexOf("="));
					propMap.put(lineKey, line.substring(line.indexOf("=") + 1, line.length()));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();

			if (br != null)
				try {
					br.close();
				} catch (IOException localIOException) {
				}
		} finally {
			if (br != null)
				try {
					br.close();
				} catch (IOException localIOException1) {
				}
		}
		return propMap;
	}

	public static String changeContent(Reader reader, HashMap<String, String> replaceMap) {
		BufferedReader br = null;
		StringBuilder sb = null;
		try {
			br = new BufferedReader(reader);
			String line = "";
			sb = new StringBuilder(1000);
			String key = "";
			String lineKey = "";
			Iterator it = null;
			boolean isChange = false;
			while ((line = br.readLine()) != null) {
				if ((!line.trim().equals("")) && (!line.startsWith("#"))) {
					lineKey = line.substring(0, line.indexOf("="));
					it = replaceMap.keySet().iterator();
					isChange = false;
					while (it.hasNext()) {
						key = (String) it.next();
						if (lineKey.equals(key)) {
							sb.append(key + "=" + (String) replaceMap.get(key) + "\r\n");
							isChange = true;
							replaceMap.remove(key);
							break;
						}
					}
					if (!isChange)
						sb.append(line + "\r\n");
				} else {
					sb.append(line + "\r\n");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();

			if (br != null)
				try {
					br.close();
				} catch (IOException localIOException) {
				}
		} finally {
			if (br != null)
				try {
					br.close();
				} catch (IOException localIOException1) {
				}
		}
		return sb.toString();
	}

	public static String changeContent(String filePath, HashMap<String, String> replaceMap) throws Exception {
		return changeContent(new FileReader(filePath), replaceMap);
	}

	public static String readBinaryFile(String filePath) {
		DataInputStream dis = null;
		try {
			dis = new DataInputStream(new BufferedInputStream(new FileInputStream(filePath)));

			System.out.println(dis.readInt());
			System.out.println(dis.readUTF());
		} catch (Exception e) {
			e.printStackTrace();

			if (dis != null)
				try {
					dis.close();
				} catch (IOException localIOException) {
				}
		} finally {
			if (dis != null)
				try {
					dis.close();
				} catch (IOException localIOException1) {
				}
		}
		return "";
	}

	public static String writeFile(String filePath, String content) {
		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new FileWriter(filePath));
			bw.write(content);
			bw.flush();
		} catch (IOException e) {
			e.printStackTrace();

			if (bw != null)
				try {
					bw.close();
				} catch (IOException localIOException1) {
				}
		} finally {
			if (bw != null)
				try {
					bw.close();
				} catch (IOException localIOException2) {
				}
		}
		return content;
	}

	public static String writeBinaryFile(String filePath) {
		DataOutputStream dos = null;
		try {
			dos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(filePath)));
			dos.writeInt(1);
			dos.writeUTF("안녕하세요");
			dos.flush();
		} catch (IOException e) {
			e.printStackTrace();

			if (dos != null)
				try {
					dos.close();
				} catch (IOException localIOException1) {
				}
		} finally {
			if (dos != null)
				try {
					dos.close();
				} catch (IOException localIOException2) {
				}
		}
		return "";
	}

	public static String copy(String inFilePath, String outFilePath) {
		FileInputStream input = null;
		FileOutputStream output = null;
		try {
			File file = new File(inFilePath);

			input = new FileInputStream(file);

			output = new FileOutputStream(new File(outFilePath));

			int readBuffer = 0;
			byte[] buffer = new byte[512];
			while ((readBuffer = input.read(buffer)) != -1) {
				output.write(buffer, 0, readBuffer);
			}
			System.out.println("파일이 복사되었습니다.");
		} catch (IOException e) {
			System.out.println(e);
			try {
				input.close();

				output.close();
			} catch (IOException localIOException1) {
			}
		} finally {
			try {
				input.close();

				output.close();
			} catch (IOException localIOException2) {
			}
		}
		return "";
	}

	public static String copyFile(String rControllerFilePath, String wControllerFilePath,
			HashMap<String, String> replaceMap) throws Exception {
		File rfile = new File(rControllerFilePath);
		String rbizFilePath = rfile.getPath();

		if (!rfile.exists()) {
			throw new Exception(rbizFilePath + "읽을 파일이 없습니다.");
		}

		File dic = new File(wControllerFilePath.substring(0, wControllerFilePath.lastIndexOf(File.separator)));
		String dirPath = dic.getPath();

		if (dic.exists()) {
			System.out.println(dirPath + " 디렉토리 있음");
		} else {
			dic.mkdirs();
			System.out.println(dirPath + " 디렉토리 생성");
		}

		File f = new File(wControllerFilePath);
		String bizFilePath = f.getPath();

		if (f.exists())
			System.out.println(bizFilePath + " 파일 덮어쓰기");
		else {
			System.out.println(bizFilePath + " 파일 생성");
		}

		String content = readFile(rControllerFilePath);

		if ((replaceMap != null) && (!replaceMap.isEmpty())) {
			Iterator keys = replaceMap.keySet().iterator();
			String key = "";
			while (keys.hasNext()) {
				key = (String) keys.next();
				content = content.replaceAll(key, (String) replaceMap.get(key));
			}
		}
		writeFile(wControllerFilePath, content);
		return content;
	}


	public static void writeFile(String content, String wControllerFilePath,
			HashMap<String, String> replaceMap) throws Exception {
//		File rfile = new File(rControllerFilePath);
//		String rbizFilePath = rfile.getPath();
//
//		if (!rfile.exists()) {
//			throw new Exception(rbizFilePath + "읽을 파일이 없습니다.");
//		}

		File dic = new File(wControllerFilePath.substring(0, wControllerFilePath.lastIndexOf(File.separator)));
		String dirPath = dic.getPath();

		if (dic.exists()) {
			System.out.println(dirPath + " 디렉토리 있음");
		} else {
			dic.mkdirs();
			System.out.println(dirPath + " 디렉토리 생성");
		}

		File f = new File(wControllerFilePath);
		String bizFilePath = f.getPath();

		if (f.exists())
			System.out.println(bizFilePath + " 파일 덮어쓰기");
		else {
			System.out.println(bizFilePath + " 파일 생성");
		}

		if ((replaceMap != null) && (!replaceMap.isEmpty())) {
			Iterator keys = replaceMap.keySet().iterator();
			String key = "";
			while (keys.hasNext()) {
				key = (String) keys.next();
				content = content.replaceAll(key, (String) replaceMap.get(key));
			}
		}
		writeFile(wControllerFilePath, content);
	}

	public static List<String> fileList(String filePath) throws Exception {
		List fileList = null;
		File jspDir = new File(filePath);
		if (jspDir.isDirectory()) {
			File[] files = jspDir.listFiles();
			if ((files != null) && (files.length > 0)) {
				fileList = new ArrayList();
				for (File f : files) {
					fileList.add(f.getName());
				}
			}

		}

		return fileList;
	}
}