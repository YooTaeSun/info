package com.townsi.support;

public class SettingConstant {
	public static enum Path {

		SITE_WEB_ROOT("D:\\project\\sts_workspace\\support_spring\\src\\main\\webapp"),
		PROP("D:\\project\\sts_workspace\\support_spring\\src\\main\\resources\\config\\setting.properties");

		private final String value;

		private Path(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}
	}
}

