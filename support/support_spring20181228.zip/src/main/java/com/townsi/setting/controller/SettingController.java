package com.townsi.setting.controller;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.townsi.setting.biz.ISettingBiz;
import com.townsi.support.SettingConstant;
import com.townsi.utils.FileUtil;
import com.townsi.utils.StrUtil;

import springfox.documentation.annotations.ApiIgnore;

@ApiIgnore
@Controller
@RequestMapping({ "/setting" })
@SuppressWarnings({"rawtypes","unchecked"})
public class SettingController {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	private LinkedHashMap<String, String> propMap = null;

	@PostConstruct
	@Bean
	public LinkedHashMap<String, String> propMap() {

		propMap = FileUtil.readFileMap(SettingConstant.Path.PROP.getValue());
		return propMap;
	}

	@Autowired
	private ISettingBiz settingBiz;

	@RequestMapping({ "/main" })
	public String main(@RequestParam HashMap params, Model model) throws Exception {
		return "/sample/setting";
	}

	@RequestMapping({ "/info" })
	public ResponseEntity<HashMap> info(@RequestParam HashMap params, Model model) throws Exception {
		LinkedHashMap resultMap = new LinkedHashMap();
		ResponseEntity entity = null;
		try {
			Iterator it = this.propMap.keySet().iterator();
			while (it.hasNext()) {
				String key = (String) it.next();
				resultMap.put(key, this.propMap.get(key));
			}

			resultMap.put("param", params);
			entity = new ResponseEntity(resultMap, HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage());
			resultMap.put("error", e.getMessage());
			entity = new ResponseEntity(resultMap, HttpStatus.NOT_ACCEPTABLE);
		}
		return entity;
	}


	@RequestMapping({ "/save" })
	public ResponseEntity<HashMap> save(HttpServletRequest request, @RequestParam HashMap params, Model model) throws Exception {
		HashMap resultMap = new HashMap();
		ResponseEntity entity = null;
		try {

			StrUtil.addMap(this.propMap, params);
			String content = FileUtil.changeContent(SettingConstant.Path.PROP.getValue(), params);
			FileUtil.writeFile(SettingConstant.Path.PROP.getValue(), content);

			resultMap.put("param", params);
			entity = new ResponseEntity(resultMap, HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage());
			resultMap.put("error", e.getMessage());
			entity = new ResponseEntity(resultMap, HttpStatus.NOT_ACCEPTABLE);
		}
		return entity;
	}


    @RequestMapping("/source")
    public ResponseEntity<HashMap> source(@RequestParam HashMap params, Model model) throws Exception {
    	HashMap resultMap = new HashMap();
    	ResponseEntity entity = null;
		try {
			resultMap.put("data", this.settingBiz.source(params));
			resultMap.put("param", params);
			entity = new ResponseEntity(resultMap, HttpStatus.OK);
			logger.debug("source params : " + params);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			resultMap.put("error", e.getMessage());
			entity = new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return entity;
    }

    @RequestMapping("/makeSetGet")
    public ResponseEntity<HashMap> makeSetGet(@RequestParam HashMap params, Model model) throws Exception {
    	HashMap resultMap = new HashMap();
    	ResponseEntity entity = null;
    	try {
    		params.put("kind", "1");
    		resultMap.put("data", this.settingBiz.makeSetGet(params));
    		resultMap.put("param", params);
    		entity = new ResponseEntity(resultMap, HttpStatus.OK);
    		logger.debug("makeSetGet params : " + params);
    	} catch (Exception e) {
    		e.printStackTrace();
    		logger.error(e.getMessage());
    		resultMap.put("error", e.getMessage());
    		entity = new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    	return entity;
    }

    @RequestMapping("/makeSetGet2")
    public ResponseEntity<HashMap> makeSetGet2(@RequestParam HashMap params, Model model) throws Exception {
    	HashMap resultMap = new HashMap();
    	ResponseEntity entity = null;
    	try {
    		params.put("kind", "2");
    		resultMap.put("data", this.settingBiz.makeSetGet(params));
    		resultMap.put("param", params);
    		entity = new ResponseEntity(resultMap, HttpStatus.OK);
    		logger.debug("makeSetGet2 params : " + params);
    	} catch (Exception e) {
    		e.printStackTrace();
    		logger.error(e.getMessage());
    		resultMap.put("error", e.getMessage());
    		entity = new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    	return entity;
    }

}