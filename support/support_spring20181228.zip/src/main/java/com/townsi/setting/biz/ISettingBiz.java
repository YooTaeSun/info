package com.townsi.setting.biz;

import java.util.HashMap;

public interface ISettingBiz {
	public abstract HashMap<String, Object> source(HashMap paramHashMap) throws Exception;

	HashMap<String, Object> makeSetGet(HashMap vo) throws Exception;

//	public abstract HashMap<String, Object> list(HashMap paramHashMap) throws Exception;
}