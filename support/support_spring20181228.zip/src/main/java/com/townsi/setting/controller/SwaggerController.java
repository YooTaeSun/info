package com.townsi.setting.controller;

import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.townsi.setting.model.Swagger;
import com.townsi.setting.model.SwaggerCondition;

import io.swagger.annotations.ApiOperation;

@CrossOrigin
@RestController
@RequestMapping(value = "/api", produces = MediaType.APPLICATION_JSON_VALUE)
public class SwaggerController {

  private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

  @ApiOperation(value="swagger 조회", notes="SwaggerCondition 을 파리미터로 swagger을 조회한다.")
  @PatchMapping("/swagger")
  public List<Swagger> getSwaggerList(@RequestBody SwaggerCondition params, Model model, HttpServletRequest request, Locale locale) throws Exception {
    return null;
  }


  @ApiOperation(value="swagger 입력", notes="swagger 입력한다.")
  @PostMapping("/swagger")
  public int createSwagger(@Valid @RequestBody Swagger params, BindingResult bindingResult, Model model,
      HttpServletRequest request, Locale locale) throws Exception {

    if (bindingResult.hasErrors()) {
      String errorMsg = bindingResult.getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.joining(". "));
      logger.error(errorMsg);
      throw new RuntimeException("TEST");
    } else {
    }
    return 1;
  }


  @ApiOperation(value="활동계획한일  수정", notes="pkSeq번호를 이용하여 swagger 수정한다.")
  @PutMapping("/swagger/{pkSeq}")
  public int updateSwagger(@PathVariable("pkSeq") Long pkSeq, @RequestBody Swagger params, Model model, HttpServletRequest request, Locale locale) throws Exception {
    params.setPkSeq(pkSeq);
    return 1;
  }


  @ApiOperation(value="swagger 삭제", notes="pkSeq번호를 이용하여 swagger 삭제한다.")
  @DeleteMapping("/swagger/{pkSeq}")
  public int deleteSwagger(@PathVariable("pkSeq") Long pkSeq, Model model, HttpServletRequest request, Locale locale) throws Exception {

    SwaggerCondition params = new SwaggerCondition();
    params.setPkSeq(pkSeq);

    return 1;
  }

}
