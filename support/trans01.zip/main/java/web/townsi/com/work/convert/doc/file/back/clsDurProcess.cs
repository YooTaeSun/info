using System;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.BusinessControls
{
    public class clsDurProcess
    {
        private clsORCommon m_OrCommon = new clsORCommon();

        // DUR 사용유무
        bool m_DUR_YN = false;
        private string m_HPTL_RGNO_CD = string.Empty;

        public bool DUR_YN
        {
            get { return m_DUR_YN; }
            set { m_DUR_YN = value; }
        }

        HiraDur.IHIRAClient DurClient = null;
        HiraDur.IHIRAPrescription DurPrescription = null;
        HiraDur.IHIRAResultSet DurResultSet = null;

        private bool DurRun(string path)
        {
            try
            {
                ConfigService.Load();

                ProcessStartInfo durapp = new ProcessStartInfo();
                durapp.UseShellExecute = true;
                durapp.FileName = path;
                Process.Start(durapp);

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
        }

        private bool DurObjectCreate(ref string errmsg)
        {

            try
            {
                //if (DurClient == null || DurPrescription == null || DurResultSet == null)
                //{
                    // 인터페이스 선언
                    DurClient = default(HiraDur.IHIRAClient);
                    DurPrescription = default(HiraDur.IHIRAPrescription);
                    DurResultSet = default(HiraDur.IHIRAResultSet);

                    System.Type DurClient_t = System.Type.GetTypeFromProgID("HiraDur.Client", true);
                    DurClient = (HiraDur.IHIRAClient)System.Activator.CreateInstance(DurClient_t, true);

                    System.Type DurPrescription_t = System.Type.GetTypeFromProgID("HiraDur.Prescription", true);
                    DurPrescription = (HiraDur.IHIRAPrescription)System.Activator.CreateInstance(DurPrescription_t, true);

                    System.Type DurResultSet_t = System.Type.GetTypeFromProgID("HiraDur.ResultSet", true);
                    DurResultSet = (HiraDur.IHIRAResultSet)System.Activator.CreateInstance(DurResultSet_t, true);

                    DurClient.AdminCode = m_HPTL_RGNO_CD; // 처방기관기호 설정

                //}
                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                errmsg = ex.Message;
                return false;
            }
        }

        private void DurDownLoad()
        {

        }

        private bool DurProcessCheck()
        {
            Process[] process = Process.GetProcesses();

            for (int i = 0; i < process.Length; i++)
            {
                if (process[i].ProcessName.ToString().IndexOf("IHiraDur") >= 0)
                    return true;
            }

            return false;
        }

        public bool DurExecute(string strPrscAdmSym)
        {
            try
            {
                if (m_DUR_YN)
                {
                    string chng_rgno_cd = ConfigService.GetConfigValueString("%", "DUR_CONFIG", "CHNG_RGNO_CD", "*");

                    if (!string.IsNullOrWhiteSpace(chng_rgno_cd) && chng_rgno_cd != "*")
                        strPrscAdmSym = chng_rgno_cd;

                    m_HPTL_RGNO_CD = strPrscAdmSym;

                    string durrunpath = ClientEnvironment.SolutionPath + "\\Lib\\DUR\\IHiraDur.exe";

                    // DUR이 실행되지 않은 상태일 때 실행
                    if (!DurProcessCheck())
                    {
                        //Ftp 확인 후 최신버전이 아닐 때 다운로드, 최신버전일 때 실행
                        //DurDownLoad

                        if (!DurRun(durrunpath))
                        {
                            LxMessage.Show("DUR 실행 시 오류가 발생했습니다.[Class/clsDurProcess/DurExecute]", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return false;
                        }
                    }

                    //// DUR 인터페이스 선언
                    //if (!DurObjectCreate())
                    //{
                    //    LxMessage.Show("DUR 필요 정보 생성 중 오류가 발생했습니다.[Class/clsDurProcess/DurExecute]", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //    return false;
                    //}
                }
                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
        }

        delegate bool DelegateDurCreate(ref string str);
        delegate bool DelegateDur(ref string str);

        public bool CheckParticularDisease(string rrn, string pt_nm, string hptl_rgno_cd, string hspt_nm, string mdcr_dd, string edi_prmt_no, ref string errmsg)
        {
            string skip_code = string.Empty;
            int durreturn = 0;

            try
            {
                if (m_DUR_YN)
                {
                    DelegateDurCreate create = new DelegateDurCreate(DurObjectCreate);
                    IAsyncResult res = create.BeginInvoke(ref errmsg, null, "");
                    while (!res.IsCompleted) { }

                    if (!create.EndInvoke(ref errmsg, res))
                    {
                        errmsg = errmsg + "\r\nDUR 필요 정보 생성 중 오류가 발생했습니다.[Class/clsDurProcess/DurExecute]";
                        return true;
                    }

                    //if (!DurObjectCreate(ref errmsg))
                    //{
                    //    errmsg = errmsg + "\r\nDUR 필요 정보 생성 중 오류가 발생했습니다.[Class/clsDurProcess/DurExecute]";
                    //    return false;
                    //}

                    DelegateDur gdi = delegate (ref string strr)
                    {
                        DurPrescription.ClearMedicine();
                        DurPrescription.AdminType = "M";                    // 처방조제구분
                        DurPrescription.JuminNo = rrn;                      // 수진자주민번호
                        DurPrescription.PatNm = pt_nm;                      // 수진자성명
                        DurPrescription.MprscIssueAdmin = hptl_rgno_cd;     // 처방기관기호
                        DurPrescription.PrscAdminName = hspt_nm;            // 처방기관명
                        DurPrescription.PrscPresDt = mdcr_dd;               // 처방일자
                        DurPrescription.AppIssueAdmin = hptl_rgno_cd;       // 청구소프트웨어 업체코드
                        DurPrescription.AppIssueCode = edi_prmt_no;         // 인증코드

                        DurResultSet.ClearResult();

                        durreturn = DurClient.ParticularDiseaseCheck(DurPrescription, DurResultSet);

                        if (durreturn != 0)
                        {
                            skip_code = DBService.ExecuteScalar(SQL.Function.SelectFN_BI_READ_BICDINDT(), "DUR_ERR_SKIPCD"
                                                                                                        , durreturn.ToString()
                                                                                                        , mdcr_dd
                                                                                                        , "ITNL_USE_CD").ToString();

                            if (string.IsNullOrWhiteSpace(skip_code))
                                skip_code = "N";

                            if (skip_code == "N")
                            {
                                strr = "DUR 특정질병 확인 정보 조회\r\n" +
                                         "점검결과 에러코드 : " + durreturn.ToString();
                                return true;
                            }
                        }

                        return true;
                    };

                    IAsyncResult ress = gdi.BeginInvoke(ref errmsg, null, "");
                    while (!ress.IsCompleted) { }

                    if (!gdi.EndInvoke(ref errmsg, ress))
                    {
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return true;
            }

            return true;
        }

        /// <summary>
        /// 처방한 약품정보를 입력한다.
        /// </summary>
        /// <param name="rrn">주민번호</param>
        /// <param name="pt_nm">환자이름</param>
        /// <param name="InsurerType">수진자보험자구분</param>
        /// <param name="PregWmnYN">수진자임부여부</param>
        /// <param name="hptl_rgno_cd">요양기관번호</param>
        /// <param name="dur_grnt_no">처방전교부번호</param>
        /// <param name="hspt_nm">병원명</param>
        /// <param name="tel">전화번호</param>
        /// <param name="fax_no">팩스번호</param>
        /// <param name="mdcr_dd">진료일자</param>
        /// <param name="prsc_time">진료시간</param>
        /// <param name="PrscLicType">처방면허종별</param>
        /// <param name="lcno">의사 면허번호</param>
        /// <param name="user_nm">사용자이름</param>
        /// <param name="dept_cd">진료과목코드</param>
        /// <param name="PrscClCode">처방조제유형코드</param>
        /// <param name="edi_prmt_no">인증코드</param>
        /// <param name="dur_dvcd">DUR처방여부</param>
        /// <param name="set_prscType">DUR분류유형코드</param>
        /// <param name="edi_cd">EDI코드</param>
        /// <param name="mefe_hnm">수가한글명</param>
        /// <param name="main_ingr_cd">주성분코드</param>
        /// <param name="ontm_qty">1회량</param>
        /// <param name="notm">횟수</param>
        /// <param name="nody">일수</param>
        /// <param name="insudmdtype">DUR보험적용구분</param>
        /// <param name="ioHsp">원외원내구분</param>
        /// <param name="aomd_mthd_cd">용법</param>
        /// <param name="errmsg">에러메세지</param>
        /// <returns></returns>
        private bool SetAddMedicine(string admintype, string rrn, string pt_nm, string InsurerType, string PregWmnYN, string hptl_rgno_cd, string dur_grnt_no, string hspt_nm, string tel, string fax_no,
                                   string mdcr_dd, string prsc_time, string PrscLicType, string lcno, string user_nm, string dept_cd, string PrscClCode, string edi_prmt_no, string dur_dvcd,
                                   string set_prscType, string edi_cd, string mefe_hnm, string main_ingr_cd, string ontm_qty, string notm, string nody, string insudmdtype, string ioHsp, string aomd_mthd_cd,
                                   string ilns_cd, ref string errmsg)
        {
            HiraDur.PrscType prscType = default(HiraDur.PrscType);
            string skip_code = string.Empty;
            int durreturn = 0;

            try
            {
                if (m_DUR_YN)
                {
                    DurPrescription.AdminType = admintype;          // 처방조제구분
                    DurPrescription.JuminNo = rrn;                  // 수진자주민번호
                    DurPrescription.PatNm = pt_nm;                  // 수진자성명
                    DurPrescription.InsurerType = InsurerType;      // 수진자보험자구분
                    DurPrescription.PregWmnYN = PregWmnYN;          // 수진자임부여부
                    DurPrescription.MprscIssueAdmin = hptl_rgno_cd; // 처방기관기호
                    DurPrescription.mprscGrantNo = dur_grnt_no;     // 처방전교부번호
                    DurPrescription.PrscAdminName = hspt_nm;        // 처방기관명
                    DurPrescription.PrscTel = tel;                  // 처방기관전화번호
                    DurPrescription.PrscFax = fax_no;               // 처방기관팩스번호
                    DurPrescription.PrscPresDt = mdcr_dd;           // 처방일자
                    DurPrescription.PrscPresTm = prsc_time;         // 처방시간
                    DurPrescription.PrscLicType = PrscLicType;      // 처방면허종별
                    DurPrescription.DrLicNo = lcno;                 // 의사면허번호
                    DurPrescription.PrscName = user_nm;             // 처방의료인성명

                    if (ConfigService.GetConfigValueDirect("OR", "DUR_USE", "SET_DEPT_CD") == "Y")
                        DurPrescription.Dsbjt = dept_cd;                // 진료과목코드

                    DurPrescription.PrscClCode = PrscClCode;        // 처방조제유형코드
                    DurPrescription.AppIssueAdmin = hptl_rgno_cd;   // 청구소프트웨어 업체코드
                    // 개발포트일 때 시 DUR 인증진행중일 때는 인증코드를 넘기지 않고
                    // 개발포트일 때 시 DUR 인증진행중이 아닐 때는 인증코드를 요양기관번호 + 0(22개)
                    // 그 외 인증코드로 넘김
                    if (ConfigService.GetConfigValueBool("OR", "DUR_USE", "CONFIRM_YN") && ConfigService.GetConfigValueString("%", "DUR_CONFIG", "Server:Port2") == "9301")
                        DurPrescription.AppIssueCode = "";     // 인증코드
                    else if (!ConfigService.GetConfigValueBool("OR", "DUR_USE", "CONFIRM_YN") && ConfigService.GetConfigValueString("%", "DUR_CONFIG", "Server:Port2") == "9301")
                        DurPrescription.AppIssueCode = hptl_rgno_cd + "0000000000000000000000";     // 인증코드
                    else
                        DurPrescription.AppIssueCode = edi_prmt_no;     // 인증코드
                    DurPrescription.PrscYN = dur_dvcd;              // 처방여부
                    DurPrescription.MakerIssueAdmin = hptl_rgno_cd; // 처방기관기호
                    DurPrescription.MakerAdminName = hspt_nm;      // 처방기관명
                    DurPrescription.MakerTel = tel;          // 처방기관전화번호 
                    DurPrescription.MakerDate = mdcr_dd;      // 처방일자
                    DurPrescription.MakerTime = prsc_time;    // 처방시간
                    DurPrescription.MainSick = ilns_cd;       // 주상병코드

                    // 수가일 때
                    if (set_prscType == "1")
                        prscType = HiraDur.PrscType.durPrscSuga;
                    // 약가일 때
                    else if (set_prscType == "3")
                        prscType = HiraDur.PrscType.durPrscYakga;
                    // 원료-성분
                    else if (set_prscType == "5")
                        prscType = HiraDur.PrscType.durPrscWonRyo;
                    // 재료
                    else if (set_prscType == "8")
                        prscType = HiraDur.PrscType.durPrscJaeRyo;


                    durreturn = DurPrescription.AddMedicine(prscType, edi_cd, mefe_hnm, main_ingr_cd, "", float.Parse(ontm_qty), float.Parse(notm), int.Parse(nody), insudmdtype, ioHsp, aomd_mthd_cd);

                    if (durreturn != 0)
                    {
                        errmsg = "DUR 설정 중 오류가 발생했습니다.[Class/clsDurProcess/SetAddMedicine]\r\n" +
                                 "Error Code : " + durreturn.ToString() + DurClient.LastErrorMsg;
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                errmsg = "DUR 설정 중 오류가 발생했습니다.[Class/clsDurProcess/SetAddMedicine]";
                return false;
            }

            return true;
        }

        /// <summary>
        /// DUR 전송할 처방을 확인한다.
        /// </summary>
        /// <param name="order">처방정보</param>
        /// <param name="work_dvcd">[I]입력,[D]삭제</param>
        /// <param name="pid">환자번호</param>
        /// <param name="pt_cmhs_no">내원번호</param>
        /// <param name="mdcr_dd">처방일자</param>
        /// <param name="otpt_amds_dvcd">외입정보</param>
        /// <param name="oo_dur_dvcd">[N]새로전송, [M]수정전송, [Z]취소, [C]아무것도 하지 않음</param>
        /// <param name="oi_dur_dvcd">[N]새로전송, [M]수정전송, [Z]취소, [C]아무것도 하지 않음</param>
        /// <param name="i_dur_dvcd">[N]새로전송, [M]수정전송, [Z]취소, [C]아무것도 하지 않음</param>
        /// <param name="t_dur_dvcd">[N]새로전송, [M]수정전송, [Z]취소, [C]아무것도 하지 않음</param>
        public void CheckTransData(string work_dvcd, string pid, string pt_cmhs_no, string mdcr_dd, string otpt_amds_dvcd, ref string oo_dur_dvcd, ref string oi_dur_dvcd, ref string i_dur_dvcd, ref string t_dur_dvcd)
        {
            string prsc_lcls_cd = string.Empty;
            string prsc_dvcd = string.Empty;
            string sql = string.Empty;
            int dur_trans_count = 0;
            int order_count = 0;               // 등록된 처방개수

            oo_dur_dvcd = "C";
            oi_dur_dvcd = "C";
            i_dur_dvcd = "C";
            t_dur_dvcd = "C";

            //for(int i = 0; i < order.Rows.Count; i++)
            //{
            //    prsc_lcls_cd = order.Rows[i]["PRSC_LCLS_CD"].ToString();
            //    prsc_dvcd    = order.Rows[i]["prsc_dvcd"].ToString();

            //    if(prsc_lcls_cd == "20" || prsc_lcls_cd == "30")
            //    {
            //        if (prsc_dvcd == "T")
            //            t_order_count++;                                    // 약/주사 건수(퇴원약)
            //        else
            //        {
            //            if (prsc_dvcd != "S" || prsc_dvcd == "P")
            //                i_order_count++;                                // 약/주사 건수
            //        }
            //    }
            //}

            // 등록
            if (work_dvcd == "I")
            {
                // DUR 구분 설정
                if (otpt_amds_dvcd == "O")
                {
                    sql = " AND A.EXCP_RESN_CD = 'NO' ";

                    // DUR 전송을 위한 외래 원외 처방정보를 읽는다.
                    dur_trans_count = DBService.ExecuteInteger(SQL.OR.Sql.SelectCountDurORDRRSIF() + sql, pid
                                                                                                        , pt_cmhs_no
                                                                                                        , otpt_amds_dvcd
                                                                                                        , mdcr_dd);

                    // 외래 DUR 최초 전송
                    if (dur_trans_count <= 0)
                        oo_dur_dvcd = "N";
                    else
                        oo_dur_dvcd = "M";

                    sql = " AND A.EXCP_RESN_CD <> 'NO' ";

                    // DUR 전송을 위한 외래 원내 처방정보를 읽는다.
                    dur_trans_count = DBService.ExecuteInteger(SQL.OR.Sql.SelectCountDurORDRRSIF() + sql, pid
                                                                                                        , pt_cmhs_no
                                                                                                        , otpt_amds_dvcd
                                                                                                        , mdcr_dd);

                    // 외래 DUR 최초 전송
                    if (dur_trans_count <= 0)
                        oi_dur_dvcd = "N";
                    else
                        oi_dur_dvcd = "M";
                }
                else
                {
                    // DUR 전송을 위한 입원 처방정보를 읽는다.
                    dur_trans_count = DBService.ExecuteInteger(SQL.OR.Sql.SelectCountIDurORDRRSIF(), pid
                                                                                                   , pt_cmhs_no
                                                                                                   , otpt_amds_dvcd
                                                                                                   , mdcr_dd);

                    // 입원 DUR 최초 전송(이미 저장되어 있는 오더도 존재하지 않고 신규 약,주사 오더만 존재하는 경우)
                    if (dur_trans_count <= 0)
                        i_dur_dvcd = "N";
                    else
                        i_dur_dvcd = "M";

                    // DUR 전송을 위한 퇴원 처방정보를 읽는다.
                    dur_trans_count = DBService.ExecuteInteger(SQL.OR.Sql.SelectCountTDurORDRRSIF(), pid
                                                                                                   , pt_cmhs_no
                                                                                                   , otpt_amds_dvcd
                                                                                                   , mdcr_dd
                                                                                                   , "T");

                    // 퇴원 DUR 최초 전송(이미 저장되어 있는 오더도 존재하지 않고 신규 약,주사 오더만 존재하는 경우)
                    if (dur_trans_count <= 0)
                        t_dur_dvcd = "N";
                    else
                        t_dur_dvcd = "M";
                }
            }
            // 삭제
            else if (work_dvcd == "D")
            {
                if (otpt_amds_dvcd == "O")
                {
                    sql = " AND A.EXCP_RESN_CD = 'NO' ";

                    // DUR 전송을 위한 외래 원외 처방정보를 읽는다.
                    dur_trans_count = DBService.ExecuteInteger(SQL.OR.Sql.SelectCountDurORDRRSIF() + sql, pid
                                                                                                        , pt_cmhs_no
                                                                                                        , otpt_amds_dvcd
                                                                                                        , mdcr_dd);

                    // 외래 처방정보를 읽는다.
                    order_count = DBService.ExecuteInteger(SQL.OR.Sql.SelectCountOrderMedInj() + sql, pid
                                                                                                    , pt_cmhs_no
                                                                                                    , mdcr_dd);

                    if (dur_trans_count <= 0)
                        oo_dur_dvcd = "N";
                    else
                    {
                        // 현재 처방에 약주사가 없을 때
                        if (order_count <= 0)
                            oo_dur_dvcd = "Z";
                        else
                            oo_dur_dvcd = "M";
                    }

                    sql = " AND A.EXCP_RESN_CD <> 'NO' ";

                    // DUR 전송을 위한 외래 원내 처방정보를 읽는다.
                    dur_trans_count = DBService.ExecuteInteger(SQL.OR.Sql.SelectCountDurORDRRSIF() + sql, pid
                                                                                                        , pt_cmhs_no
                                                                                                        , otpt_amds_dvcd
                                                                                                        , mdcr_dd);

                    // 외래 처방정보를 읽는다.
                    order_count = DBService.ExecuteInteger(SQL.OR.Sql.SelectCountOrderMedInj() + sql, pid
                                                                                                    , pt_cmhs_no
                                                                                                    , mdcr_dd);

                    if (dur_trans_count <= 0)
                        oi_dur_dvcd = "N";
                    else
                    {
                        // 현재 처방에 약주사가 없을 때
                        if (order_count <= 0)
                            oi_dur_dvcd = "Z";
                        else
                            oi_dur_dvcd = "M";
                    }
                }
                else
                {
                    //----------------------------------------------------------------------입원
                    // DUR 전송을 위한 입원 처방정보를 읽는다.
                    dur_trans_count = DBService.ExecuteInteger(SQL.OR.Sql.SelectCountDurORDRRSIF(), pid
                                                                                                  , pt_cmhs_no
                                                                                                  , "I"
                                                                                                  , mdcr_dd);

                    // DUR 구분을 설정한다.
                    if (dur_trans_count <= 0)
                        i_dur_dvcd = "N";
                    else
                    {
                        // DUR개수를 조회한다.
                        order_count = DBService.ExecuteInteger(SQL.OR.Sql.SelectCountIOrderMedInj(), pid
                                                                                                   , pt_cmhs_no
                                                                                                   , mdcr_dd);

                        // 현재 처방에 약주사가 없을 때 
                        if (order_count <= 0)
                            i_dur_dvcd = "Z";
                        else
                            i_dur_dvcd = "M";
                    }

                    //----------------------------------------------------------------------퇴원
                    // DUR 전송을 위한 퇴원 처방정보를 읽는다.
                    dur_trans_count = DBService.ExecuteInteger(SQL.OR.Sql.SelectCountDurORDRRSIF(), pid
                                                                                                  , pt_cmhs_no
                                                                                                  , "T"
                                                                                                  , mdcr_dd);

                    // DUR 구분을 설정한다.
                    if (dur_trans_count <= 0)
                        t_dur_dvcd = "N";
                    else
                    {
                        // DUR개수를 조회한다.
                        order_count = DBService.ExecuteInteger(SQL.OR.Sql.SelectCountTOrderMedInj(), pid
                                                                                                   , pt_cmhs_no
                                                                                                   , mdcr_dd);

                        // 현재 처방에 약주사가 없을 때
                        if (order_count <= 0)
                            t_dur_dvcd = "Z";
                        else
                            t_dur_dvcd = "M";
                    }
                }
            }
        }

        /// <summary>
        /// DUR 전송할 처방을 확인한다.(입원당일)
        /// </summary>
        /// <param name="order">처방정보</param>
        /// <param name="work_dvcd">[I]입력,[D]삭제</param>
        /// <param name="pid">환자번호</param>
        /// <param name="pt_cmhs_no">내원번호</param>
        /// <param name="mdcr_dd">처방일자</param>
        /// <param name="otpt_amds_dvcd">외입정보</param>
        /// <param name="oo_dur_dvcd">[N]새로전송, [M]수정전송, [Z]취소, [C]아무것도 하지 않음</param>
        /// <param name="oi_dur_dvcd">[N]새로전송, [M]수정전송, [Z]취소, [C]아무것도 하지 않음</param>
        /// <param name="i_dur_dvcd">[N]새로전송, [M]수정전송, [Z]취소, [C]아무것도 하지 않음</param>
        /// <param name="t_dur_dvcd">[N]새로전송, [M]수정전송, [Z]취소, [C]아무것도 하지 않음</param>
        public bool CheckTransData(string pid, string pt_cmhs_no, string mdcr_dd, ref string oo_dur_dvcd, ref string oi_dur_dvcd, ref string i_dur_dvcd, ref string t_dur_dvcd)
        {
            string prsc_dvcd = string.Empty;
            string sql = string.Empty;
            DataTable dt = new DataTable();

            i_dur_dvcd = "C";
            t_dur_dvcd = "C";

            DBService.ExecuteDataTable(SQL.OR.Sql.SelectCountDurTrans(), ref dt
                                                                       , pid
                                                                       , pt_cmhs_no
                                                                       , mdcr_dd);

            if (dt.Rows.Count <= 0)
                return false;

            // 입원처방과 퇴원처방이 없으면 전송하지 않는다.
            if (int.Parse(dt.Rows[0]["OO_DUR"].ToString()) <= 0 && int.Parse(dt.Rows[0]["OI_DUR"].ToString()) <= 0 && int.Parse(dt.Rows[0]["I_DUR"].ToString()) <= 0 && int.Parse(dt.Rows[0]["T_DUR"].ToString()) <= 0)
            {
                oo_dur_dvcd = "X";
                oi_dur_dvcd = "X";
                i_dur_dvcd = "X";
                t_dur_dvcd = "X";

                return false;
            }

            //----------------------------------------------------------------------원외
            // DUR 전송을 위한 원외 처방정보를 읽는다.
            if (int.Parse(dt.Rows[0]["OO_DUR"].ToString()) > 0)
            {
                if (int.Parse(dt.Rows[0]["NOT_TRANS_OO_DUR"].ToString()) == 0)
                    oo_dur_dvcd = "X";
                else if (int.Parse(dt.Rows[0]["OO_DUR"].ToString()) == int.Parse(dt.Rows[0]["NOT_TRANS_OO_DUR"].ToString()))
                    oo_dur_dvcd = "N";
                else
                    oo_dur_dvcd = "M";
            }
            else
                oo_dur_dvcd = "X";

            //----------------------------------------------------------------------원내
            // DUR 전송을 위한 입원 처방정보를 읽는다.
            if (int.Parse(dt.Rows[0]["OI_DUR"].ToString()) > 0)
            {
                if (int.Parse(dt.Rows[0]["NOT_TRANS_OI_DUR"].ToString()) == 0)
                    oi_dur_dvcd = "X";
                else if (int.Parse(dt.Rows[0]["OI_DUR"].ToString()) == int.Parse(dt.Rows[0]["NOT_TRANS_OI_DUR"].ToString()))
                    oi_dur_dvcd = "N";
                else
                    oi_dur_dvcd = "M";
            }
            else
                oi_dur_dvcd = "X";

            //----------------------------------------------------------------------입원
            // DUR 전송을 위한 입원 처방정보를 읽는다.
            if (int.Parse(dt.Rows[0]["I_DUR"].ToString()) > 0)
            {
                if (int.Parse(dt.Rows[0]["NOT_TRANS_I_DUR"].ToString()) == 0)
                    i_dur_dvcd = "X";
                else if (int.Parse(dt.Rows[0]["I_DUR"].ToString()) == int.Parse(dt.Rows[0]["NOT_TRANS_I_DUR"].ToString()))
                    i_dur_dvcd = "N";
                else
                    i_dur_dvcd = "M";
            }
            else
                i_dur_dvcd = "X";

            //----------------------------------------------------------------------퇴원
            // DUR 전송을 위한 퇴원 처방정보를 읽는다.
            if (int.Parse(dt.Rows[0]["T_DUR"].ToString()) > 0)
            {
                if (int.Parse(dt.Rows[0]["NOT_TRANS_T_DUR"].ToString()) == 0)
                    t_dur_dvcd = "X";
                else if (int.Parse(dt.Rows[0]["T_DUR"].ToString()) == int.Parse(dt.Rows[0]["NOT_TRANS_T_DUR"].ToString()))
                    t_dur_dvcd = "N";
                else
                    t_dur_dvcd = "M";
            }
            else
                t_dur_dvcd = "X";

            return true;
        }

        /// <summary>
        /// DUR을 전송한다.
        /// </summary>
        /// <param name="spr">처방스프레드</param>
        /// <param name="otpt_adms_dvcd">외입구분([O]외래/[I]입원/[T]퇴원)</param>
        /// <param name="dur_trans_dvcd">DUR전송구분([OO]외래원외/[OI]외래원내/[I]입원/[T]퇴원)</param>
        /// <param name="pid">환자번호</param>
        /// <param name="pt_cmhs_no">내원번호</param>
        /// <param name="rrn">주민등록번호</param>
        /// <param name="pt_nm">환자명</param>
        /// <param name="insn_tycd">보험유형</param>
        /// <param name="vtrn_pt_yn">보훈환자구분</param>
        /// <param name="femme_pid">임부환자번호</param>
        /// <param name="mdcr_dd">진료일자</param>
        /// <param name="prsc_time">처방시간</param>
        /// <param name="insn_clam_dept_cd">보험청구부서코드</param>
        /// <param name="lcno">면허번호</param>
        /// <param name="user_nm">사용자이름</param>
        /// <param name="dur_dvcd">전송구분([N]최초전송/[M]수정 전송/[Z] 취소)</param>
        /// <param name="HospitalInfo">병원정보</param>
        /// <param name="errmsg">에러메세지</param>
        public bool TransDur(DataTable order, string otpt_adms_dvcd, string dur_trans_dvcd, string pid, string pt_cmhs_no, string rrn, string pt_nm, string insn_tycd, string vtrn_pt_yn, string femme_pid, string mdcr_dd,
                              string prsc_time, string insn_clam_dept_cd, string entry_dr_cd, string dur_dvcd, string ilns_cd, DataRow HospitalInfo, ref string errmsg)
        {
            string skip_code = string.Empty;
            string prsp_grnt_no_1 = string.Empty;
            string prsp_grnt_no_2 = string.Empty;
            string dur_chck_excl_yn = string.Empty;
            string dur_grnt_no = string.Empty;     // 처방전교부번호
            string titlecode = string.Empty;
            string prsc_cd = string.Empty;
            string prsc_uniq_no = string.Empty;
            string prsc_sqno = string.Empty;
            string prsc_dvcd = string.Empty;
            string dc_prsc_dvcd = string.Empty;
            string ontm_qty = string.Empty;
            string notm = string.Empty;
            string nody = string.Empty;
            string chek_ontm_qty = string.Empty;
            string chek_notm = string.Empty;
            string chek_nody = string.Empty;
            string pnpy_dvcd = string.Empty;
            string excp_resn_cd = string.Empty;
            string aomd_mthd_cd = string.Empty;
            string prsc_lcls_cd = string.Empty;
            string mefe_dvcd = string.Empty;
            string edi_cd = string.Empty;
            string main_ingr_cd = string.Empty;
            string mefe_hnm = string.Empty;
            string prsc_clsf_cd = string.Empty;
            string prsp_grnt_no = string.Empty;
            string lcno = string.Empty;
            string user_nm = string.Empty;
            string prsc_inpt_dvcd = string.Empty;
            string todate = DateTime.Now.ToString("yyyyMMddHHmmss");
            string today = DateTimeService.ConvertDateStringToFormatString(todate, "yyyyMMdd");
            string code_text = string.Empty;
            string sql = string.Empty;
            int ouprgrntno = 0;               // 생성할 처방전교부번호(외래)
            int entry_count = 0;               // 등록된 처방개수
            int durreturn = 0;
            int discharge_order_count = 0;
            DataTable dt = new DataTable();
            DataTable ipadt = new DataTable();
            DataTable disdt = new DataTable();
            DataRow mefeinfo = null;
            ////////////////////////////////////////////////////// DUR정보
            string PrscClCode = string.Empty; // 처방조제유형코드
            string InsurerType = string.Empty; // 수신자보험자구분
            string PregWmnYN = string.Empty; // 수신자임부여부
            string PrscLicType = string.Empty; // 처방면허종별
            string prscType = string.Empty; // 분류유형코드(3:보험등재약,4:원료,조제(제제약),5:보험등재약의 일반,현재 보험등재약, 원료,조제(제제약), 보험등재약의 일반만 처리)
            string insudmdtype = string.Empty; // 보험 적용구분(A:보험, B:비보험, C:100/100, D:약국판매약(조제기관만 해당))
            string ioHsp = string.Empty; // 원외(1)원내(2)구분
            string MainSick = string.Empty; // 주상병코드

            try
            {
                // ** 서울병원 임시코드 **
                if (HospitalConfig.HospitalCode == "SEOUL" && DOPack.HospitalInfo.HPTL_RGNO_CD != "11101351" && new DateTime(2021, 1, 1) > DateTimeService.ConvertDateTime(mdcr_dd))
                    return true;

                if (!ConfigService.GetConfigValueBool("OR", "DUR_USE", "PRSC_USE_YN", true))
                    return true;

                if (m_DUR_YN)
                {
                    // 미래처방일 경우 전송하지 않는다.
                    if (int.Parse(mdcr_dd) > int.Parse(today) && otpt_adms_dvcd != "I")
                        return true;

                    //if (!DurObjectCreate(ref errmsg))
                    //{
                    //    errmsg = errmsg + "\r\nDUR 필요 정보 생성 중 오류가 발생했습니다.[Class/clsDurProcess/TransDur]";
                    //    throw new Exception(errmsg);
                    //}

                    DelegateDurCreate create = new DelegateDurCreate(DurObjectCreate);
                    IAsyncResult res = create.BeginInvoke(ref errmsg, null, "");
                    while (!res.IsCompleted) { }

                    if (!create.EndInvoke(ref errmsg, res))
                    {
                        errmsg = errmsg + "\r\nDUR 필요 정보 생성 중 오류가 발생했습니다.[Class/clsDurProcess/DurExecute]";
                        return true;
                    }

                    //--------------------------------------------------------------------------------DUR에 필요한 교부번호 생성
                    dt.Rows.Clear();

                    // DUR 구분을 조회한다.
                    if (!(DBService.ExecuteDataTable(SQL.OR.Sql.SelectDurInfoORIETCMA(), ref dt
                                                                                        , pid
                                                                                        , pt_cmhs_no
                                                                                        , mdcr_dd)))
                    {
                        errmsg = "DUR 정보 조회 중 오류가 발생했습니다.[Class/clsEntryOrder/TransDur]";
                        return false;
                    }

                    if (dt.Rows.Count > 0)
                    {
                        prsp_grnt_no_1 = dt.Rows[0]["PRSP_GRNT_NO_1"].ToString();
                        prsp_grnt_no_2 = dt.Rows[0]["PRSP_GRNT_NO_2"].ToString();
                        dur_chck_excl_yn = dt.Rows[0]["DUR_CHCK_EXCL_YN"].ToString();
                    }


                    // 강제로 DUR 전송하지 않음
                    if (dur_chck_excl_yn == "Y")
                        return true;

                    if (otpt_adms_dvcd == "O")
                    {
                        // 2019-11-11 김남훈 시바 전날자도 보내 문제생기면 책임안짐
                        // 처방의 종료일자가 현재일자보다 작은 정보가 존재하는 경우 DUR 제외
                        //if (int.Parse(mdcr_dd) < int.Parse(today))
                        //{
                        //    if (DBService.ExecuteInteger(SQL.OR.Sql.SelectCountDurORORDRRT(), pid
                        //                                                                    , pt_cmhs_no
                        //                                                                    , today) >= 1)
                        //        return true;
                        //}
                        // 외래 원외
                        if (dur_trans_dvcd == "OO")
                        {
                            if (string.IsNullOrWhiteSpace(prsp_grnt_no_1))
                                prsp_grnt_no_1 = "N";

                            // 외래 처방교부번호 생성
                            if (prsp_grnt_no_1 == "N")
                            {
                                // 교부번호 발생
                                // 처방교부번호를 생성한다.
                                if (!SQL.Procedure.PR_AD_READ_UNIQSQ("OUPRGRNTNO", DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "yyyy"), DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "MM"), DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "dd"), "N", "N", ref ouprgrntno))
                                {
                                    errmsg = "처방전 교부번호 생성 중 오류가 발생했습니다.";
                                    return false;
                                }

                                prsp_grnt_no_1 = mdcr_dd + string.Format("{0:00000}", ouprgrntno);    // 원외처방저번호 yyyyMMdd + "00001"

                                // 교부번호 저장
                                if (!(m_OrCommon.SaveORIETCMA(pid, pt_cmhs_no, mdcr_dd, "01", prsp_grnt_no_1, prsp_grnt_no_2, "N", "", "", "", "", "", todate, ref errmsg)))
                                {
                                    errmsg = "처방전 교부번호 저장 중 오류가 발생했습니다.";
                                    return false;
                                }
                            }
                        }
                        // 외래 원내
                        else if (dur_trans_dvcd == "OI")
                        {
                            if (string.IsNullOrWhiteSpace(prsp_grnt_no_2))
                                prsp_grnt_no_2 = "N";

                            // 외래 처방교부번호 생성
                            if (prsp_grnt_no_2 == "N")
                            {
                                // 교부번호 발생
                                // 처방교부번호를 생성한다.
                                if (!SQL.Procedure.PR_AD_READ_UNIQSQ("OUPRGRNTNO", DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "yyyy"), DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "MM"), DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "dd"), "N", "N", ref ouprgrntno))
                                {
                                    errmsg = "처방전 교부번호 생성 중 오류가 발생했습니다.";
                                    return false;
                                }

                                prsp_grnt_no_2 = mdcr_dd + string.Format("{0:00000}", ouprgrntno);    // 원외처방저번호 yyyyMMdd + "00001"

                                // 교부번호 저장
                                if (!(m_OrCommon.SaveORIETCMA(pid, pt_cmhs_no, mdcr_dd, "01", prsp_grnt_no_1, prsp_grnt_no_2, "N", "", "", "", "", "", todate, ref errmsg)))
                                {
                                    errmsg = "처방전 교부번호 저장 중 오류가 발생했습니다.";
                                    return false;
                                }
                            }
                        }
                    }
                    else
                    {
                        // 임시 처방전 교부번호 확인
                        if (!(DBService.ExecuteDataTable(SQL.OR.Sql.SelectIpaPrspGrntNo(), ref ipadt
                                                                                        , pid
                                                                                        , pt_cmhs_no
                                                                                        , mdcr_dd
                                                                                        , "01")))
                        {
                            errmsg = "임시 처방전 교부번호 확인 중 오류가 발생했습니다.";
                            return false;
                        }

                        if (ipadt.Rows.Count > 0)
                        {
                            prsp_grnt_no_1 = ipadt.Rows[0]["PRSP_GRNT_NO_1"].ToString();
                            prsp_grnt_no_2 = ipadt.Rows[0]["PRSP_GRNT_NO_2"].ToString();
                        }

                        if (string.IsNullOrWhiteSpace(prsp_grnt_no_1))
                            prsp_grnt_no_1 = "N";

                        if (string.IsNullOrWhiteSpace(prsp_grnt_no_2))
                            prsp_grnt_no_2 = "N";

                        // 발생한 교부번호가 존재하지 않으면 교부번호 저장
                        if (prsp_grnt_no_1 == "N")
                        {
                            // 교부번호 발생
                            // 처방교부번호를 생성한다.
                            if (!SQL.Procedure.PR_AD_READ_UNIQSQ("OUPRGRNTNO", DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "yyyy"), DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "MM"), DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "dd"), "N", "N", ref ouprgrntno))
                            {
                                errmsg = DBService.ErrorMessage + "[" + DBService.ErrorCode + "]";
                                return false;
                            }

                            prsp_grnt_no_1 = mdcr_dd + string.Format("{0:00000}", ouprgrntno);    // 원외처방저번호 yyyyMMdd + "00001"

                            // 입원환자 교부번호 저장
                            if (!(m_OrCommon.SaveORIETCMA(pid, pt_cmhs_no, mdcr_dd, "01", prsp_grnt_no_1, prsp_grnt_no_2, "N", "", "", "", "", "", todate, ref errmsg)))
                            {
                                return false;
                            }
                        }

                        // 처방입력구분이 퇴원인 구분을 찾는다.
                        for (int i = 0; i < order.Rows.Count; i++)
                        {
                            prsc_inpt_dvcd = order.Rows[i]["PRSC_INPT_DVCD"].ToString();

                            if (string.IsNullOrWhiteSpace(order.Rows[i]["PRSC_CD"].ToString()))
                                continue;
                            //if (order.Rows[i]["TITLECODE"].ToString() != "3")
                            //    continue;

                            if (order.Rows[i]["PRSC_DVCD"].ToString() == "T" || prsc_inpt_dvcd == "99")
                                discharge_order_count++;
                        }

                        // Discharge Orders 이고, 퇴원 구분인 경우
                        if (discharge_order_count >= 1)
                        {
                            // 임시 처방전 교부번호 확인
                            ipadt.Rows.Clear();

                            if (!(DBService.ExecuteDataTable(SQL.OR.Sql.SelectIpaPrspGrntNo(), ref ipadt
                                                                                            , pid
                                                                                            , pt_cmhs_no
                                                                                            , mdcr_dd
                                                                                            , "01")))
                            {
                                errmsg = "임시 처방전 교부번호 확인 중 오류가 발생했습니다.";
                                return false;
                            }

                            prsp_grnt_no_1 = ipadt.Rows[0]["PRSP_GRNT_NO_1"].ToString();
                            prsp_grnt_no_2 = ipadt.Rows[0]["PRSP_GRNT_NO_2"].ToString();

                            if (string.IsNullOrWhiteSpace(prsp_grnt_no_1))
                                prsp_grnt_no_1 = "N";

                            if (string.IsNullOrWhiteSpace(prsp_grnt_no_2))
                                prsp_grnt_no_2 = "N";

                            // 발생한 교부번호가 존재하지 않으면 교부번호 저장
                            if (prsp_grnt_no_2 == "N")
                            {
                                // 교부번호 발생
                                // 처방교부번호를 생성한다.
                                if (!SQL.Procedure.PR_AD_READ_UNIQSQ("OUPRGRNTNO", DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "yyyy"), DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "MM"), DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "dd"), "N", "N", ref ouprgrntno))
                                {
                                    errmsg = DBService.ErrorMessage + "[" + DBService.ErrorCode + "]";
                                    return false;
                                }

                                prsp_grnt_no_2 = mdcr_dd + string.Format("{0:00000}", ouprgrntno);    // 원외처방저번호 yyyyMMdd + "00001"

                                // 입원환자 기타관련 저장
                                if (!(m_OrCommon.SaveORIETCMA(pid, pt_cmhs_no, mdcr_dd, "01", prsp_grnt_no_1, prsp_grnt_no_2, "N", "", "", "", "", "", todate, ref errmsg)))
                                {
                                    return false;
                                }
                            }
                        }

                        // 현재 전송한 정보가 존재하는 경우 M으로 치환
                        if (dur_dvcd == "N")
                        {
                            // 2018-11-19 김남훈 추가
                            if (dur_trans_dvcd == "OO")
                                sql = " AND A.EXCP_RESN_CD = 'NO'";
                            else if (dur_trans_dvcd == "OI")
                                sql = " AND A.EXCP_RESN_CD <> 'NO'";
                            else
                                sql = "";


                            if (DBService.ExecuteInteger(SQL.OR.Sql.SelectCountDurORDRRSIF() + sql, pid
                                                                                                  , pt_cmhs_no
                                                                                                  , otpt_adms_dvcd
                                                                                                  , mdcr_dd) >= 1)
                                dur_dvcd = "M";
                        }
                        // 현재 전송한 정보가 존재하지 않는 경우 N으로 치환
                        else
                        {
                            // 2018-11-19 김남훈 추가
                            if (dur_trans_dvcd == "OO")
                                sql = " AND A.EXCP_RESN_CD = 'NO'";
                            else if (dur_trans_dvcd == "OI")
                                sql = " AND A.EXCP_RESN_CD <> 'NO'";
                            else
                                sql = "";

                            if (dur_dvcd == "M")
                            {
                                if (DBService.ExecuteInteger(SQL.OR.Sql.SelectCountDurORDRRSIF() + sql, pid
                                                                                                      , pt_cmhs_no
                                                                                                      , otpt_adms_dvcd
                                                                                                      , mdcr_dd) < 1)
                                    dur_dvcd = "N";
                            }
                        }
                    }

                    if (string.IsNullOrWhiteSpace(ilns_cd))
                    {
                        // 2018-11-16 김남훈 주상병을 불러온다.
                        if (!DBService.ExecuteDataTable(SQL.OR.Sql.SelectMainDisORDISRRT(), ref disdt, pid, pt_cmhs_no))
                        {
                            errmsg = "상병 조회 중 오류가 발생했습니다.\r\n상병을 확인 해 주세요.";
                            return false;
                        }

                        if (disdt.Rows.Count <= 0)
                        {
                            errmsg = "상병 조회 중 오류가 발생했습니다.\r\n상병을 확인 해 주세요.";
                            return false;
                        }

                        MainSick = disdt.Rows[0]["ILNS_CD"].ToString();
                    }
                    else
                        MainSick = ilns_cd;

                    if (dur_dvcd == "N" || dur_dvcd == "M")
                    {
                        // DUR 처방조제유형코드 설정
                        // 2018-11-19 김남훈 외래 원내, 원외 추가
                        if (otpt_adms_dvcd == "I")
                            PrscClCode = "01";
                        else if ((dur_trans_dvcd == "OO" || dur_trans_dvcd == "OI") && int.Parse(today) < int.Parse(mdcr_dd))
                            PrscClCode = "10";
                        else if (dur_trans_dvcd == "OI")
                            PrscClCode = "05";
                        else if (dur_trans_dvcd == "OO")
                            PrscClCode = "02";
                        else if (otpt_adms_dvcd == "T")
                            PrscClCode = "06";
                        else
                            PrscClCode = "08";

                        // DUR 수진자보험자구분 설정 (04)건강보험/(05)의료급여/(07)보훈/(09)일반/(10)산재/(11)자보
                        if (vtrn_pt_yn == "Y")
                            InsurerType = "07";
                        else
                        {
                            switch (insn_tycd)
                            {
                                case "11":
                                    InsurerType = "04";
                                    break;
                                case "21":
                                case "22":
                                    InsurerType = "05";
                                    break;
                                case "51":
                                    InsurerType = "09";
                                    break;
                                case "31":
                                    InsurerType = "10";
                                    break;
                                case "41":
                                    InsurerType = "11";
                                    break;
                            }
                        }

                        // DUR 처방면허종별 설정 (AA)의사/(BB)약사/(CC)치과의사/(DD)한의사
                        if (insn_clam_dept_cd == "55")
                            PrscLicType = "CC";
                        else if (insn_clam_dept_cd == "80")
                            PrscLicType = "DD";
                        else
                            PrscLicType = "AA";

                        // DUR 임부 확인
                        if (string.IsNullOrWhiteSpace(femme_pid))
                            PregWmnYN = "N";
                        else
                            PregWmnYN = "Y";

                        // 외래/입원은 no_1사용, 퇴원은 no_2사용
                        // 2018-11-19 김남훈 외래 원외, 외래 원내 추가
                        if (dur_trans_dvcd == "OO" || otpt_adms_dvcd == "I")
                            dur_grnt_no = prsp_grnt_no_1;
                        else
                            dur_grnt_no = prsp_grnt_no_2;

                        DelegateDur delDur = delegate (ref string str)
                        {
                            // DUR Object 초기화
                            DurPrescription.ClearMedicine();

                            if (otpt_adms_dvcd == "O")
                            {
                                // DUR 전송정보 삭제
                                if (!DBService.ExecuteNonQuery(SQL.OR.Sql.DeleteDurTransORDRTRIF(), pid
                                                                                                  , pt_cmhs_no
                                                                                                  , dur_trans_dvcd))
                                {
                                    str = "점검결과 삭제 중 오류가 발생했습니다.[Class/clsEntryOrder/TransDur]";
                                    return false;
                                }

                                // 2018-11-19 김남훈 등록된 DUR 전송 처방이 있을 때 지운다.
                                if (!DBService.ExecuteNonQuery(SQL.OR.Sql.DeleteDurTransORDRRSIF(), pid
                                                                                                  , pt_cmhs_no
                                                                                                  , dur_trans_dvcd))
                                {
                                    str = "전송처방 삭제 중 오류가 발생했습니다.[Class/clsEntryOrder/TransDur]";
                                    return false;
                                }
                            }

                            for (int i = 0; i < order.Rows.Count; i++)
                            {
                                prsc_cd = order.Rows[i]["PRSC_CD"].ToString();
                                prsc_dvcd = order.Rows[i]["PRSC_DVCD"].ToString();
                                prsc_uniq_no = order.Rows[i]["PRSC_UNIQ_NO"].ToString();
                                prsc_sqno = order.Rows[i]["PRSC_SQNO"].ToString();
                                dc_prsc_dvcd = order.Rows[i]["DC_PRSC_DVCD"].ToString();
                                ontm_qty = order.Rows[i]["ONTM_QTY"].ToString();
                                notm = order.Rows[i]["NOTM"].ToString();
                                nody = order.Rows[i]["NODY"].ToString();
                                pnpy_dvcd = order.Rows[i]["PNPY_DVCD"].ToString();
                                excp_resn_cd = order.Rows[i]["EXCP_RESN_CD"].ToString();
                                aomd_mthd_cd = order.Rows[i]["AOMD_MTHD_CD"].ToString();
                                prsc_lcls_cd = order.Rows[i]["PRSC_LCLS_CD"].ToString();

                                if (string.IsNullOrWhiteSpace(prsc_cd))
                                    continue;

                                // D/C 제외
                                if (dc_prsc_dvcd != "A")
                                    continue;

                                // Self, PRN 제외
                                if (prsc_dvcd == "S" || prsc_dvcd == "P")
                                    continue;

                                // 수가정보를 불러온다.
                                mefeinfo = ORBizCommon.GetMefeInfo(prsc_cd, mdcr_dd, "%", ref str);
                                if (mefeinfo == null)
                                    continue;

                                mefe_dvcd = mefeinfo["MEFE_DVCD"].ToString();
                                edi_cd = mefeinfo["EDI_CD"].ToString();
                                main_ingr_cd = mefeinfo["MAIN_INGR_CD"].ToString();
                                mefe_hnm = mefeinfo["MEFE_HNM"].ToString();
                                prsc_clsf_cd = mefeinfo["PRSC_CLSF_CD"].ToString();

                                if (string.IsNullOrWhiteSpace(main_ingr_cd))
                                    continue;

                                if (string.IsNullOrWhiteSpace(edi_cd))
                                    continue;

                                if (edi_cd.Length <= 6)
                                    continue;

                                if (!new string[] { "20", "30" }.Any(s => s.Equals(prsc_lcls_cd)))
                                    continue;

                                // 약/주사가 아닐 때 제외
                                if (!new string[] { "1", "2", "3", "4" }.Any(s => s.Equals(prsc_clsf_cd)))
                                    continue;

                                // 퇴원약 처방은 퇴원만 가능
                                if (PrscClCode == "06" && prsc_dvcd != "T")
                                    continue;

                                // 입원약 처방은 퇴원약 처방에 포함 X
                                if (otpt_adms_dvcd == "I" && prsc_dvcd == "T")
                                    continue;

                                // 2018-11-19 김남훈 외래 원외일 때 원내처방 제외
                                if (dur_trans_dvcd == "OO" && excp_resn_cd != "NO")
                                    continue;

                                // 2018-11-19 김남훈 외래 원내일 때 원외처방 제외
                                if (dur_trans_dvcd == "OI" && excp_resn_cd == "NO")
                                    continue;

                                // 미산정 Continue
                                // 2019-03-07 김남훈 임상시험처방은 제외한다.
                                if (new string[] { "5", "9" }.Any(s => s.Equals(pnpy_dvcd)))
                                    continue;

                                // DUR 원내외 구분 설정(예외사유 NO = 1, NO 아닐때 >= 2)
                                if (dur_trans_dvcd == "OO")
                                    ioHsp = "1";
                                else
                                    ioHsp = "2";

                                // DUR 분류유형코드 설정 (분류유형이 4일 때 5로 변경)
                                if (mefe_dvcd == "4")
                                    prscType = "5";
                                else
                                    prscType = mefe_dvcd;

                                // DUR 보험 적용구분 설정
                                if (pnpy_dvcd == "1")
                                    insudmdtype = "A";
                                else if (pnpy_dvcd == "4")
                                    insudmdtype = "B";
                                else if (pnpy_dvcd == "2")
                                    insudmdtype = "C";
                                else if (pnpy_dvcd == "3")
                                    insudmdtype = "B";
                                else
                                    insudmdtype = "D";

                                // 2018-11-19 김남훈 전송사유 지우지 않는다.
                                // DUR 전송된 사유정보가 있으면 전송된 사유정보를 지운다
                                if (DBService.ExecuteInteger(SQL.OR.Sql.SelectCountDurTransORDRTRIF(), pid
                                                                                                     , pt_cmhs_no
                                                                                                     , mdcr_dd
                                                                                                     , prsc_sqno
                                                                                                     , edi_cd) >= 1)
                                {
                                    if (!DBService.ExecuteNonQuery(SQL.OR.Sql.DeleteDurTransPrscORDRTRIF(), pid
                                                                                                          , pt_cmhs_no
                                                                                                          , mdcr_dd
                                                                                                          , prsc_sqno
                                                                                                          , edi_cd))
                                    {
                                        str = "점검결과 삭제 중 오류가 발생했습니다.[Class/clsEntryOrder/TransDur]";
                                        return false;
                                    }
                                }

                                // 입력 의사의 면허번호와 이름을 불러온다.
                                lcno = UserList.GetColumnValue(entry_dr_cd, "LCNO").ToString();
                                user_nm = UserList.GetColumnValue(entry_dr_cd, "USER_NM").ToString();

                                // 처방한 약품정보를 입력한다.
                                if (!this.SetAddMedicine("M"
                                                      , rrn
                                                      , pt_nm
                                                      , InsurerType
                                                      , PregWmnYN
                                                      , HospitalInfo["HPTL_RGNO_CD"].ToString()
                                                      , dur_grnt_no
                                                      , HospitalInfo["HSPT_NM"].ToString()
                                                      , HospitalInfo["TEL"].ToString()
                                                      , HospitalInfo["FAX_NO"].ToString()
                                                      , mdcr_dd
                                                      , prsc_time
                                                      , PrscLicType
                                                      , lcno
                                                      , user_nm
                                                      , insn_clam_dept_cd
                                                      , PrscClCode
                                                      , HospitalInfo["EDI_PRMT_NO"].ToString()
                                                      , dur_dvcd
                                                      , prscType
                                                      , edi_cd
                                                      , mefe_hnm
                                                      , main_ingr_cd
                                                      , ontm_qty
                                                      , notm
                                                      , nody
                                                      , insudmdtype
                                                      , ioHsp
                                                      , aomd_mthd_cd
                                                      , MainSick
                                                      , ref str))
                                    throw new Exception(str);

                                entry_count++;
                            }

                            // DUR 전송한 데이터가 있다면
                            if (entry_count >= 1)
                            {
                                // DUR Object 초기화
                                DurResultSet.ClearResult();

                                if (ConfigService.GetConfigValueString("OR", "IPA_DUR_TRANS", "USE_YN").ToString() == "Y")
                                {
                                    // 외래/입원/퇴원약
                                    durreturn = DurClient.Check(DurPrescription, DurResultSet);
                                }
                                else
                                {
                                    // 외래/퇴원약
                                    if (otpt_adms_dvcd == "O" || otpt_adms_dvcd == "T")
                                        durreturn = DurClient.Check(DurPrescription, DurResultSet);
                                    else
                                        durreturn = DurClient.CheckOnlyFirstStep(DurPrescription, DurResultSet);
                                }

                                for (int z = 0; z < order.Rows.Count; z++)
                                {
                                    if (z == 0)
                                        code_text += order.Rows[z]["PRSC_CD"].ToString();
                                    else
                                        code_text += "/" + order.Rows[z]["PRSC_CD"].ToString();
                                }

                                if (string.IsNullOrWhiteSpace(code_text))
                                    code_text = "";

                                LogService.ErrorLog("DUR TRANS\r\n\r\nRETURN : " + durreturn.ToString() + "\r\n" + "PID : " + pid + "\r\nPT_CMHS_NO : " + pt_cmhs_no + "\r\nMDCR_DD : " + mdcr_dd + "\r\nOTPT_ADMS_DVCD : " + otpt_adms_dvcd + "\r\nCODE : " + code_text);

                                // Skip 가능한 코드 확인
                                if (durreturn != 0)
                                {
                                    skip_code = DBService.ExecuteScalar(SQL.Function.SelectFN_BI_READ_BICDINDT(), "DUR_ERR_SKIPCD"
                                                                                                                , durreturn.ToString()
                                                                                                                , mdcr_dd
                                                                                                                , "ITNL_USE_CD").ToString();

                                    if (string.IsNullOrWhiteSpace(skip_code))
                                        skip_code = "N";

                                    if (skip_code == "N")
                                    {
                                        str = "DUR 점검실시 오류 : " + durreturn.ToString() + " : " + DurClient.LastErrorMsg;
                                        throw new Exception(str);
                                    }
                                }

                                if (DurResultSet.Totalcnt > 0)
                                {
                                    DurResultSet.NextResult();
                                    for (int i = 0; i < DurResultSet.Totalcnt; i++)
                                    {
                                        DurResultInfo Resultinfo = new DurResultInfo();

                                        // DUR정보 설정
                                        Resultinfo.Index = DurResultSet.Index;            // 점검순서
                                        Resultinfo.Totalcnt = DurResultSet.Totalcnt;         // 점검결과 수신 시 개수 확인
                                        Resultinfo.Checkcnt = DurResultSet.Checkcnt;         // 점검요청 개수
                                        Resultinfo.Reportcnt = DurResultSet.Reportcnt;        // 사유입력 개수
                                        Resultinfo.ErrorCode = DurResultSet.ErrorCode;        // 에러코드
                                        Resultinfo.Medicnt = DurResultSet.Medicnt;          // 약품갯수
                                        Resultinfo.MedicineSerialNo = DurResultSet.MedicineSerialNo; // 점검시 입력한 약품의 순번
                                        Resultinfo.ExamTypeCD = DurResultSet.ExamTypeCD;       // 점검구분
                                        Resultinfo.MedcCDA = DurResultSet.MedcCDA;          // 처방코드
                                        Resultinfo.MedcNMA = DurResultSet.MedcNMA;          // 처방명칭
                                        Resultinfo.GnlNMCDA = DurResultSet.GnlNMCDA;         // 성분코드
                                        Resultinfo.GnlNMA = DurResultSet.GnlNMA;           // 성분명칭
                                        Resultinfo.Message = DurResultSet.Message;          // 처방이 걸린 DUR 사항 
                                        Resultinfo.DDMqtyFreqA = DurResultSet.DDMqtyFreqA;      // 1회량 
                                        Resultinfo.DDExecFreqA = DurResultSet.DDExecFreqA;      // 투여 횟수
                                        Resultinfo.mdcnExecFreqA = DurResultSet.MdcnExecFreqA;    // 투여 일수
                                        Resultinfo.ReasonCD = DurResultSet.reasonCd;         // 사유코드
                                        Resultinfo.Reason = DurResultSet.Reason;           // 사유 내용
                                        Resultinfo.Type = DurResultSet.Type;             // 점검종류코드
                                        Resultinfo.Level = DurResultSet.Level;            // 점검결과등금
                                        Resultinfo.Notice = DurResultSet.Notice;           // 부작용정보
                                        Resultinfo.DpPrscMake = DurResultSet.DpPrscMake;       // 약품처방조제 구분
                                        Resultinfo.DpPrscYYMMDD = DurResultSet.DpPrscYYMMDD;     // 중복처방 일자
                                        Resultinfo.DpPrscHMMSS = DurResultSet.DpPrscHMMSS;      // 중복처방 시간
                                        Resultinfo.DpPrscAdminCode = DurResultSet.DpPrscAdminCode;  // 중복처방 요양기관번호
                                        Resultinfo.DpPrscGrantNo = DurResultSet.DpPrscGrantNo;    // 중복처방 처방전 교부번호
                                        Resultinfo.DpPrscAdminName = DurResultSet.DpPrscAdminName;  // 중복처방 기관명
                                        Resultinfo.DpPrscTel = DurResultSet.DpPrscTel;        // 중복처방 전화번호 
                                        Resultinfo.DpPrscFax = DurResultSet.DpPrscFax;        // 중복처방 팩스
                                        Resultinfo.DpPrscName = DurResultSet.DpPrscName;       // 중복처방 처방의
                                        Resultinfo.DpPrscLic = DurResultSet.DpPrscLic;        // 중복처방 면허번호
                                        Resultinfo.DpMakeYYMMDD = DurResultSet.DpMakeYYMMDD;     // 중복조제 일자
                                        Resultinfo.DpMakeHMMSS = DurResultSet.DpMakeHMMSS;      // 중복조제 시간
                                        Resultinfo.DpMakeAdminCode = DurResultSet.DpMakeAdminCode;  // 중복조제 요양기관번호
                                        Resultinfo.DpMakeAdminName = DurResultSet.DpMakeAdminName;  // 중복조제 기관명
                                        Resultinfo.DpMakeTel = DurResultSet.DpMakeTel;        // 중복조제 전환번호
                                        Resultinfo.DpMakeName = DurResultSet.DpMakeName;       // 중복조제 약사명
                                        Resultinfo.DpMakeLic = DurResultSet.DpMakeLic;        // 중복조제 약사 면허번호
                                        Resultinfo.MedcCDB = DurResultSet.MedcCDB;          // 중복처방 약품코드
                                        Resultinfo.MedcNMB = DurResultSet.MedcNMB;          // 중복처방 약품명
                                        Resultinfo.GnlNMCDB = DurResultSet.GnlNMCDB;         // 중복처방 성분코드
                                        Resultinfo.GnlNMB = DurResultSet.GnlNMB;           // 중복처방 성분명 
                                        Resultinfo.DDMqtyFreqB = DurResultSet.DDMqtyFreqB;      // 중복처방 1회 투약량
                                        Resultinfo.DDTotalMqtyB = DurResultSet.DDTotalMqtyB;     // 중복처방 1일투여회수
                                        Resultinfo.MdcnExecFreqB = DurResultSet.MdcnExecFreqB;    // 중복처방 총투여 일수

                                        dt.Rows.Clear();

                                        // 같은 EDI코드로 처방이 여러개 나올수 있음으로 체크
                                        if (!DBService.ExecuteDataTable(SQL.OR.Sql.SelectEdiCdMefeCd(), ref dt
                                                                                                    , Resultinfo.MedcCDA
                                                                                                     , mdcr_dd))
                                        {
                                            str = "EDI 코드의 수가정보 조회 중 오류가 발생했습니다.[Class/clsDurProcess/TransDur]";
                                            return false;
                                        }

                                        if (dt.Rows.Count <= 0)
                                        {
                                            continue;
                                            //str = "EDI 코드의 수가정보 조회 중 수가정보가 없습니다.[Class/clsDurProcess/TransDur]";
                                            //return false;
                                        }



                                        for (int j = 0; j < dt.Rows.Count; j++)
                                        {
                                            // 주성분코드 없을 때 종료
                                            if (string.IsNullOrWhiteSpace(dt.Rows[j]["MAIN_INGR_CD"].ToString()))
                                                continue;

                                            // EDI가 없을 때 종료
                                            if (string.IsNullOrWhiteSpace(dt.Rows[j]["EDI_CD"].ToString()))
                                                continue;

                                            prsc_clsf_cd = dt.Rows[j]["PRSC_CLSF_CD"].ToString();

                                            // 약/주사가 아닐 때 제외
                                            if (prsc_clsf_cd != "1" && prsc_clsf_cd != "2" && prsc_clsf_cd != "3" && prsc_clsf_cd != "4")
                                                continue;

                                            for (int z = 0; z < order.Rows.Count; z++)
                                            {
                                                prsc_dvcd = order.Rows[z]["PRSC_DVCD"].ToString();
                                                excp_resn_cd = order.Rows[z]["EXCP_RESN_CD"].ToString();
                                                dc_prsc_dvcd = order.Rows[z]["DC_PRSC_DVCD"].ToString();
                                                prsc_lcls_cd = order.Rows[z]["PRSC_LCLS_CD"].ToString();
                                                pnpy_dvcd = order.Rows[z]["PNPY_DVCD"].ToString();
                                                chek_ontm_qty = order.Rows[z]["ONTM_QTY"].ToString();
                                                chek_notm = order.Rows[z]["NOTM"].ToString();
                                                chek_nody = order.Rows[z]["NODY"].ToString();

                                                if (string.IsNullOrWhiteSpace(chek_ontm_qty))
                                                    continue;
                                                if (string.IsNullOrWhiteSpace(chek_notm))
                                                    continue;
                                                if (string.IsNullOrWhiteSpace(chek_nody))
                                                    continue;

                                                if (dc_prsc_dvcd != "A")
                                                    continue;

                                                if (prsc_dvcd == "S" || prsc_dvcd == "P")
                                                    continue;

                                                // 약주사 아닐 때 종료
                                                if (prsc_lcls_cd != "20" && prsc_lcls_cd != "30")
                                                    continue;

                                                // 퇴원약 처방은 퇴원만 가능
                                                if (PrscClCode == "06" && prsc_dvcd != "T")
                                                    continue;

                                                // 입원약 처방은 퇴원약 처방에 포함 X
                                                if (otpt_adms_dvcd == "I" && prsc_dvcd == "T")
                                                    continue;

                                                // 2018-11-19 김남훈 외래 원외일 때 원내처방 제외
                                                if (dur_trans_dvcd == "OO" && excp_resn_cd != "NO")
                                                    continue;

                                                // 2018-11-19 김남훈 외래 원내일 때 원외처방 제외
                                                if (dur_trans_dvcd == "OI" && excp_resn_cd == "NO")
                                                    continue;

                                                // 미산정 Continue
                                                // 2019-03-07 임상시험처방 제외
                                                if (pnpy_dvcd == "5" || pnpy_dvcd == "9")
                                                    continue;

                                                if (order.Rows[z]["PRSC_CD"].ToString() == dt.Rows[j]["MEFE_CD"].ToString() &&
                                                   float.Parse(chek_ontm_qty) == Resultinfo.DDMqtyFreqA &&
                                                   float.Parse(chek_notm) == Resultinfo.DDExecFreqA &&
                                                   int.Parse(chek_nody) == Resultinfo.mdcnExecFreqA)
                                                {
                                                    prsc_sqno = order.Rows[z]["PRSC_SQNO"].ToString();
                                                    break;
                                                }
                                            }
                                        }

                                        if (!(int.Parse(prsc_sqno) > 0))
                                        {
                                            str = "처방일련번호 설정 중 오류가 발생했습니다.[Class/clsDurProcess/TransDur]";
                                            return false;
                                        }

                                        // 처방정보 설정
                                        Resultinfo.pid = pid;                     // 환자번호
                                        Resultinfo.pt_cmhs_no = int.Parse(pt_cmhs_no);   // 환자내원번호
                                        Resultinfo.otpt_adms_dvcd = otpt_adms_dvcd;          // 외입구분([O]외래/[I]입원/[T]퇴원약
                                        Resultinfo.mdcr_dd = mdcr_dd;                 // 처방일자
                                        Resultinfo.prsc_sqno = int.Parse(prsc_sqno);    // 처방일련번호
                                        Resultinfo.rgst_dt = todate;                  // 등록일시
                                        Resultinfo.rgstr_id = DOPack.UserInfo.USER_CD; // 등록자
                                        Resultinfo.updt_dt = todate;                  // 수정일시
                                        Resultinfo.updtr_id = DOPack.UserInfo.USER_CD; // 수정자
                                        Resultinfo.dur_trans_dvcd = dur_trans_dvcd;     // DUR 전송구분

                                        // 입원약
                                        if (otpt_adms_dvcd == "I")
                                        {
                                            if (ConfigService.GetConfigValueString("OR", "IPA_DUR_TRANS", "USE_YN").ToString() == "Y")
                                            {
                                                // DUR 전송 사유정보를 저장한다.
                                                if (!InsertORDRTRIF(Resultinfo, ref str))
                                                    return false;

                                                // DUR History 정보를 저장한다.
                                                if (!InsertORDURTHS(Resultinfo, ref str))
                                                    return false;
                                            }
                                            //else
                                            //{
                                            //    // 사유 받아야 함
                                            //    popDurReason pop = new popDurReason(Resultinfo);
                                            //    if (pop.ShowDialog() != DialogResult.OK)
                                            //    {
                                            //        str = "점검결과 사유를 입력해야 합니다.";
                                            //        return false;
                                            //    }
                                            //}
                                        }
                                        else
                                        {
                                            // DUR 전송 사유정보를 저장한다.
                                            if (!InsertORDRTRIF(Resultinfo, ref str))
                                                return false;

                                            // DUR History 정보를 저장한다.
                                            if (!InsertORDURTHS(Resultinfo, ref str))
                                                return false;

                                        }

                                        DurResultSet.NextResult();
                                    }
                                }

                                // DUR 처방을 저장한다.
                                if (!InsertORDRRSIF(order, pid, PrscClCode, otpt_adms_dvcd, dur_trans_dvcd, pt_cmhs_no, mdcr_dd, dur_grnt_no, todate, ref str))
                                    return false;

                                // DUR 처방 History을 저장한다.
                                if (!InsertORDRRSHS(order, pid, PrscClCode, otpt_adms_dvcd, dur_trans_dvcd, pt_cmhs_no, mdcr_dd, dur_grnt_no, todate, ref str))
                                    return false;
                            }

                            return true;
                        };

                        IAsyncResult ress = delDur.BeginInvoke(ref errmsg, null, "");
                        while (!ress.IsCompleted) { }

                        if (!delDur.EndInvoke(ref errmsg, ress))
                        {
                            return false;
                        }
                    }
                    else if (dur_dvcd == "Z" && (otpt_adms_dvcd == "O" || otpt_adms_dvcd == "I" || otpt_adms_dvcd == "T"))
                    {
                        string cancel_code = string.Empty;
                        string cancel_reason = string.Empty;

                        // 외래/입원은 no_1사용, 퇴원은 no_2사용
                        // 2018-11-19 김남훈 외래 원외, 외래 원내 추가
                        if (dur_trans_dvcd == "OO" || otpt_adms_dvcd == "I")
                            prsp_grnt_no = prsp_grnt_no_1;
                        else
                            prsp_grnt_no = prsp_grnt_no_2;

                        // 전송한 처방 개수가 있으면 취소요청
                        if (DBService.ExecuteInteger(SQL.OR.Sql.SelectCountPrspGrntNoORDRRSIF(), pid
                                                                                               , pt_cmhs_no
                                                                                               , mdcr_dd
                                                                                               , otpt_adms_dvcd
                                                                                               , prsp_grnt_no) > 0)
                        {
                            if (ConfigService.GetConfigValueString("OR", "DUR_USE", "CANCEL_POPUP_YN").ToString() == "Y")
                            {
                                popDurCancelE pop = new popDurCancelE(pid, pt_cmhs_no, otpt_adms_dvcd, dur_trans_dvcd, pt_nm, rrn, mdcr_dd, m_HPTL_RGNO_CD, prsp_grnt_no);
                                pop.ShowDialog();
                                if (pop.DialogResult == DialogResult.OK)
                                {
                                    cancel_code = pop.reasonCd;
                                    cancel_reason = pop.reasonText;
                                }
                                else
                                {
                                    errmsg = "점검취소 사유를 입력 해 주세요.";
                                    pop.Dispose();
                                    return false;
                                }

                                pop.Dispose();
                            }
                            else
                            {
                                cancel_code = "M5";
                                cancel_reason = "";
                            }

                            // 입원처방 전송할 때
                            if (ConfigService.GetConfigValueString("OR", "IPA_DUR_TRANS", "USE_YN").ToString() == "Y")
                            {
                                // 접수 했을 때 제조 취소
                                if (otpt_adms_dvcd == "I")
                                {
                                    if (DBService.ExecuteInteger(SQL.OR.Sql.SelectCountDrstRcpnYnPMPRRQIF(), pid
                                                                                                           , pt_cmhs_no
                                                                                                           , mdcr_dd
                                                                                                           , otpt_adms_dvcd) > 0)
                                    {
                                        // 점검취소
                                        durreturn = DurClient.MprscCancel("P", rrn, mdcr_dd, HospitalInfo["HPTL_RGNO_CD"].ToString(), prsp_grnt_no, cancel_code, cancel_reason, HospitalInfo["HPTL_RGNO_CD"].ToString());
                                    }
                                }
                            }

                            durreturn = DurClient.MprscCancel("M", rrn, mdcr_dd, HospitalInfo["HPTL_RGNO_CD"].ToString(), prsp_grnt_no, cancel_code, cancel_reason, HospitalInfo["HPTL_RGNO_CD"].ToString());

                            for (int z = 0; z < order.Rows.Count; z++)
                            {
                                if (z == 0)
                                    code_text += order.Rows[z]["PRSC_CD"].ToString();
                                else
                                    code_text += "/" + order.Rows[z]["PRSC_CD"].ToString();
                            }

                            if (string.IsNullOrWhiteSpace(code_text))
                                code_text = "";

                            LogService.ErrorLog("DUR TRANS\r\n\r\nRETURN : " + durreturn.ToString() + "\r\n" + "PID : " + pid + "\r\nPT_CMHS_NO : " + pt_cmhs_no + "\r\nMDCR_DD : " + mdcr_dd + "\r\nOTPT_ADMS_DVCD : " + otpt_adms_dvcd + "\r\nCODE : " + code_text);

                            // 에러 무시 가능 확인
                            if (durreturn != 0)
                            {
                                skip_code = DBService.ExecuteScalar(SQL.Function.SelectFN_BI_READ_BICDINDT(), "DUR_ERR_SKIPCD"
                                                                                                            , durreturn.ToString()
                                                                                                            , mdcr_dd
                                                                                                            , "ITNL_USE_CD").ToString();

                                if (string.IsNullOrWhiteSpace(skip_code))
                                    skip_code = "N";

                                if (skip_code == "N")
                                {
                                    errmsg = "점검취소 중 오류발생\r\n" +
                                             "점검결과 에러코드 : " + durreturn.ToString();
                                    throw new Exception(errmsg);
                                }
                            }

                            // 입원처방 저장 시
                            if (ConfigService.GetConfigValueString("OR", "IPA_DUR_TRANS", "USE_YN").ToString() == "Y")
                            {
                                // 처방전 취소시 해당 처방전에 대한 데이터 모두 삭제
                                if (otpt_adms_dvcd == "O" || otpt_adms_dvcd == "I" || otpt_adms_dvcd == "T")
                                {
                                    // 2018-11-19 김남훈 추가
                                    if (otpt_adms_dvcd == "O")
                                        sql = " AND ( ( NVL(A.ETC_USE_CNTS_1, 'N') = 'N') " +
                                              "    OR ( NVL(A.ETC_USE_CNTS_1, 'N') <> 'N' AND A.ETC_USE_CNTS_1 = '" + dur_trans_dvcd + "') ) ";
                                    else
                                        sql = "";

                                    // DUR 처방정보 삭제
                                    if (!(DBService.ExecuteNonQuery(SQL.OR.Sql.DeleteOrderDur() + sql, pid
                                                                                                     , pt_cmhs_no
                                                                                                     , mdcr_dd
                                                                                                     , otpt_adms_dvcd)))
                                    {
                                        errmsg = "DUR 처방 정보 삭제 중 오류가 발생했습니다.";
                                        return false;
                                    }

                                    // DUR 전송사유 정보 삭제
                                    if (!(DBService.ExecuteNonQuery(SQL.OR.Sql.DeleteOrderDurTrnasData() + sql, pid
                                                                                                              , pt_cmhs_no
                                                                                                              , mdcr_dd
                                                                                                              , otpt_adms_dvcd)))
                                    {
                                        errmsg = "DUR 처방 정보 삭제 중 오류가 발생했습니다.";
                                        return false;
                                    }

                                    //// DUR 전송사유 History 삭제
                                    //if (!(DBService.ExecuteNonQuery(SQL.OR.Sql.DeleteOrderDurTransHistoryData(), pid
                                    //                                                                            , pt_cmhs_no
                                    //                                                                            , mdcr_dd
                                    //                                                                            , otpt_adms_dvcd)))
                                    //{
                                    //    errmsg = "DUR 처방 정보 삭제 중 오류가 발생했습니다.";
                                    //    return false;
                                    //}
                                }
                            }
                            else
                            {
                                // 처방전 취소시 해당 처방전에 대한 데이터 모두 삭제
                                if (otpt_adms_dvcd == "O" || otpt_adms_dvcd == "T")
                                {
                                    // 2018-11-19 김남훈 추가
                                    if (otpt_adms_dvcd == "O")
                                        sql = " AND ( ( NVL(A.ETC_USE_CNTS_1, 'N') = 'N') " +
                                              "    OR ( NVL(A.ETC_USE_CNTS_1, 'N') <> 'N' AND A.ETC_USE_CNTS_1 = '" + dur_trans_dvcd + "') ) ";
                                    else
                                        sql = "";

                                    // DUR 처방정보 삭제
                                    if (!(DBService.ExecuteNonQuery(SQL.OR.Sql.DeleteOrderDur() + sql, pid
                                                                                                     , pt_cmhs_no
                                                                                                     , mdcr_dd
                                                                                                     , otpt_adms_dvcd)))
                                    {
                                        errmsg = "DUR 처방 정보 삭제 중 오류가 발생했습니다.";
                                        return false;
                                    }

                                    // DUR 전송사유 정보 삭제
                                    if (!(DBService.ExecuteNonQuery(SQL.OR.Sql.DeleteOrderDurTrnasData() + sql, pid
                                                                                                              , pt_cmhs_no
                                                                                                              , mdcr_dd
                                                                                                              , otpt_adms_dvcd)))
                                    {
                                        errmsg = "DUR 처방 정보 삭제 중 오류가 발생했습니다.";
                                        return false;
                                    }

                                    //// DUR 전송사유 History 삭제
                                    //if (!(DBService.ExecuteNonQuery(SQL.OR.Sql.DeleteOrderDurTransHistoryData(), pid
                                    //                                                                            , pt_cmhs_no
                                    //                                                                            , mdcr_dd
                                    //                                                                            , otpt_adms_dvcd)))
                                    //{
                                    //    errmsg = "DUR 처방 정보 삭제 중 오류가 발생했습니다.";
                                    //    return false;
                                    //}
                                }
                            }
                        }
                    }
                }

                return true;
            }
            // 전송 관련된 항목은 예외로 처리
            catch (Exception ex)
            {
                // 전송 오류가 났어도 그냥되었다고 한다.
                if (ConfigService.GetConfigValueString("OR", "DUR_USE", "TRANS_SKIP_YN") == "Y")
                {
                    errmsg = ex.StackTrace + "\r\n\r\n" + ex.Message;

                    DBService.ExecuteNonQuery(SQL.OR.Sql.InsertOrSaveADERRLOG(), DateTime.Now.ToString("yyyyMMddHHmmss")
                                                                               , DateTime.Now.ToString("yyyyMMddHHmmss")
                                                                               , "0"
                                                                               , "0"
                                                                               , "DUR TRANS ERR\r\n\r\nRETURN : " + errmsg + "\r\n" + "PID : " + pid + "\r\nPT_CMHS_NO : " + pt_cmhs_no + "\r\nMDCR_DD : " + mdcr_dd + "\r\nOTPT_ADMS_DVCD : " + otpt_adms_dvcd
                                                                               , DOPack.UserInfo.USER_CD
                                                                               , ClientEnvironment.IP
                                                                               , ClientEnvironment.ComputerName
                                                                               , ClientEnvironment.UserName);

                    return true;
                }
                else
                {
                    errmsg = ex.Message;

                    return false;
                }
            }
        }

        /// <summary>
        /// DUR을 전송한다.(조제)
        /// </summary>
        /// <param name="spr">처방스프레드</param>
        /// <param name="otpt_adms_dvcd">외입구분([O]외래/[I]입원/[T]퇴원)</param>
        /// <param name="pid">환자번호</param>
        /// <param name="pt_cmhs_no">내원번호</param>
        /// <param name="rrn">주민등록번호</param>
        /// <param name="pt_nm">환자명</param>
        /// <param name="insn_tycd">보험유형</param>
        /// <param name="vtrn_pt_yn">보훈환자구분</param>
        /// <param name="femme_pid">임부환자번호</param>
        /// <param name="mdcr_dd">진료일자</param>
        /// <param name="prsc_time">처방시간</param>
        /// <param name="insn_clam_dept_cd">보험청구부서코드</param>
        /// <param name="lcno">면허번호</param>
        /// <param name="user_nm">사용자이름</param>
        /// <param name="dur_dvcd">전송구분([N]최초전송/[M]두번째 전송)</param>
        /// <param name="HospitalInfo">병원정보</param>
        /// <param name="errmsg">에러메세지</param>
        public bool TransMedicineDur(DataTable dtMed, string otpt_adms_dvcd, string dur_trans_dvcd, string pid, string pt_cmhs_no, string rrn, string pt_nm, string insn_tycd, string vtrn_pt_yn, string femme_pid, string mdcr_dd,
                                 string prsc_time, string insn_clam_dept_cd, string entry_dr_cd, string dur_dvcd, DataRow HospitalInfo, ref string errmsg)
        {
            string skip_code = string.Empty;
            string prsp_grnt_no_1 = string.Empty;
            string prsp_grnt_no_2 = string.Empty;
            string dur_chck_excl_yn = string.Empty;
            string dur_grnt_no = string.Empty;     // 처방전교부번호
            string titlecode = string.Empty;
            string prsc_cd = string.Empty;
            string prsc_sqno = string.Empty;
            string prsc_dvcd = string.Empty;
            string prsc_uniq_no = string.Empty;
            string dc_prsc_dvcd = string.Empty;
            string ontm_qty = string.Empty;
            string notm = string.Empty;
            string nody = string.Empty;
            string chek_ontm_qty = string.Empty;
            string chek_notm = string.Empty;
            string chek_nody = string.Empty;
            string pnpy_dvcd = string.Empty;
            string excp_resn_cd = string.Empty;
            string aomd_mthd_cd = string.Empty;
            string prsc_lcls_cd = string.Empty;
            string mefe_dvcd = string.Empty;
            string edi_cd = string.Empty;
            string main_ingr_cd = string.Empty;
            string mefe_hnm = string.Empty;
            string prsc_clsf_cd = string.Empty;
            string prsp_grnt_no = string.Empty;
            string lcno = string.Empty;
            string user_nm = string.Empty;
            string todate = DateTime.Now.ToString("yyyyMMddHHmmss");
            string today = DateTimeService.ConvertDateStringToFormatString(todate, "yyyyMMdd");
            int ouprgrntno = 0;               // 생성할 처방전교부번호(외래)
            int entry_count = 0;               // 등록된 처방개수
            int durreturn = 0;
            DataTable dt = new DataTable();
            DataRow mefeinfo = null;
            DataTable disdt = new DataTable();
            CRUD_TYPE rowtype = CRUD_TYPE.Read;
            CRUD_TYPE prsc_inpt_qty_type = CRUD_TYPE.Read;
            CRUD_TYPE notm_type = CRUD_TYPE.Read;
            CRUD_TYPE nody_type = CRUD_TYPE.Read;
            CRUD_TYPE aomd_mthd_cd_type = CRUD_TYPE.Read;
            CRUD_TYPE prsc_dvcd_type = CRUD_TYPE.Read;
            CRUD_TYPE pnpy_dvcd_type = CRUD_TYPE.Read;
            CRUD_TYPE excp_resn_cd_type = CRUD_TYPE.Read;
            ////////////////////////////////////////////////////// DUR정보
            string PrscClCode = string.Empty; // 처방조제유형코드
            string InsurerType = string.Empty; // 수신자보험자구분
            string PregWmnYN = string.Empty; // 수신자임부여부
            string PrscLicType = string.Empty; // 처방면허종별
            string prscType = string.Empty; // 분류유형코드(3:보험등재약,4:원료,조제(제제약),5:보험등재약의 일반,현재 보험등재약, 원료,조제(제제약), 보험등재약의 일반만 처리)
            string insudmdtype = string.Empty; // 보험 적용구분(A:보험, B:비보험, C:100/100, D:약국판매약(조제기관만 해당))
            string ioHsp = string.Empty; // 원외(1)원내(2)구분
            string MainSick = string.Empty; // 주상병코드

            if (dur_dvcd != "N" && dur_dvcd != "M" && dur_dvcd != "Z")
                return true;

            if (m_DUR_YN)
            {
                //if (!DurObjectCreate(ref errmsg))
                //{
                //    errmsg = errmsg + "DUR 필요 정보 생성 중 오류가 발생했습니다.[Class/clsDurProcess/DurExecute]";
                //    return false;
                //}

                DelegateDurCreate create = new DelegateDurCreate(DurObjectCreate);
                IAsyncResult res = create.BeginInvoke(ref errmsg, null, "");
                res.AsyncWaitHandle.WaitOne();
                if (!create.EndInvoke(ref errmsg, res))
                {
                    errmsg = errmsg + "\r\nDUR 필요 정보 생성 중 오류가 발생했습니다.[Class/clsDurProcess/DurExecute]";
                    return true;
                }

                dt.Rows.Clear();

                // DUR 구분을 조회한다.
                if (!(DBService.ExecuteDataTable(SQL.OR.Sql.SelectDurInfoORIETCMA(), ref dt
                                                                                    , pid
                                                                                    , pt_cmhs_no
                                                                                    , mdcr_dd)))
                {
                    errmsg = "DUR 정보 조회 중 오류가 발생했습니다.[Class/clsEntryOrder/TransDur]";
                    return false;
                }

                if (dt.Rows.Count > 0)
                {
                    prsp_grnt_no_1 = dt.Rows[0]["PRSP_GRNT_NO_1"].ToString();
                    prsp_grnt_no_2 = dt.Rows[0]["PRSP_GRNT_NO_2"].ToString();
                    dur_chck_excl_yn = dt.Rows[0]["DUR_CHCK_EXCL_YN"].ToString();
                }

                // 강제로 DUR 전송하지 않음
                if (dur_chck_excl_yn == "Y")
                    return true;

                if (otpt_adms_dvcd == "O")
                {
                    // 처방의 종료일자가 현재일자보다 작은 정보가 존재하는 경우 DUR 제외
                    if (int.Parse(mdcr_dd) < int.Parse(today))
                    {
                        if (DBService.ExecuteInteger(SQL.OR.Sql.SelectCountDurORORDRRT(), pid
                                                                                       , pt_cmhs_no
                                                                                       , today) >= 1)
                            return true;
                    }

                    // 외래 원외
                    if (dur_trans_dvcd == "OO")
                    {
                        if (string.IsNullOrWhiteSpace(prsp_grnt_no_1))
                            prsp_grnt_no_1 = "N";

                        // 외래 처방교부번호 생성
                        if (prsp_grnt_no_1 == "N")
                        {
                            // 교부번호 발생
                            // 처방교부번호를 생성한다.
                            if (!SQL.Procedure.PR_AD_READ_UNIQSQ("OUPRGRNTNO", DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "yyyy"), DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "MM"), DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "dd"), "N", "N", ref ouprgrntno))
                            {
                                errmsg = "처방전 교부번호 생성 중 오류가 발생했습니다.";
                                return false;
                            }

                            prsp_grnt_no_1 = mdcr_dd + string.Format("{0:00000}", ouprgrntno);    // 원외처방저번호 yyyyMMdd + "00001"

                            // 교부번호 저장
                            if (!(m_OrCommon.SaveORIETCMA(pid, pt_cmhs_no, mdcr_dd, "01", prsp_grnt_no_1, prsp_grnt_no_2, "N", "", "", "", "", "", todate, ref errmsg)))
                            {
                                errmsg = "처방전 교부번호 저장 중 오류가 발생했습니다.";
                                return false;
                            }
                        }
                    }
                    // 외래 원내
                    else if (dur_trans_dvcd == "OI")
                    {
                        if (string.IsNullOrWhiteSpace(prsp_grnt_no_2))
                            prsp_grnt_no_2 = "N";

                        // 외래 처방교부번호 생성
                        if (prsp_grnt_no_2 == "N")
                        {
                            // 교부번호 발생
                            // 처방교부번호를 생성한다.
                            if (!SQL.Procedure.PR_AD_READ_UNIQSQ("OUPRGRNTNO", DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "yyyy"), DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "MM"), DateTimeService.ConvertDateStringToFormatString(mdcr_dd, "dd"), "N", "N", ref ouprgrntno))
                            {
                                errmsg = "처방전 교부번호 생성 중 오류가 발생했습니다.";
                                return false;
                            }

                            prsp_grnt_no_2 = mdcr_dd + string.Format("{0:00000}", ouprgrntno);    // 원외처방저번호 yyyyMMdd + "00001"

                            // 교부번호 저장
                            if (!(m_OrCommon.SaveORIETCMA(pid, pt_cmhs_no, mdcr_dd, "01", prsp_grnt_no_1, prsp_grnt_no_2, "N", "", "", "", "", "", todate, ref errmsg)))
                            {
                                errmsg = "처방전 교부번호 저장 중 오류가 발생했습니다.";
                                return false;
                            }
                        }
                    }
                }
                else
                {
                    int medinj_order_count = 0;

                    //if (DBService.ExecuteInteger(SQL.OR.Sql.SelectCountDrstRcpnYnPMPRRQIF(), pid
                    //                                                                      , pt_cmhs_no
                    //                                                                      , mdcr_dd
                    //                                                                      , otpt_adms_dvcd) <= 0)
                    //    dur_dvcd = "N";
                    //else
                    //    dur_dvcd = "M";

                    // DUR개수를 조회한다.
                    medinj_order_count = DBService.ExecuteInteger(SQL.OR.Sql.SelectCountOrderMedInj(), pid
                                                                                                     , pt_cmhs_no
                                                                                                     , mdcr_dd);

                    // 현재 저장된 약주사가 없을 때
                    if (medinj_order_count <= 0)
                        dur_dvcd = "Z";
                }

                // 2018-11-16 김남훈 주상병을 불러온다.
                if (!DBService.ExecuteDataTable(SQL.OR.Sql.SelectMainDisORDISRRT(), ref disdt, pid, pt_cmhs_no))
                {
                    errmsg = "상병 조회 중 오류가 발생했습니다.\r\n상병을 확인 해 주세요.";
                    return false;
                }

                if (disdt.Rows.Count <= 0)
                {
                    errmsg = "상병 조회 중 오류가 발생했습니다.\r\n상병을 확인 해 주세요.";
                    return false;
                }

                MainSick = disdt.Rows[0]["ILNS_CD"].ToString();

                if (dur_dvcd == "N" || dur_dvcd == "M")
                {
                    // DUR 처방조제유형코드 설정
                    // 2018-11-19 김남훈 외래 원내, 원외 추가
                    if (otpt_adms_dvcd == "I")
                        PrscClCode = "01";
                    else if ((dur_trans_dvcd == "OO" || dur_trans_dvcd == "OI") && int.Parse(today) < int.Parse(mdcr_dd))
                        PrscClCode = "10";
                    else if (dur_trans_dvcd == "OI")
                        PrscClCode = "05";
                    else if (dur_trans_dvcd == "OO")
                        PrscClCode = "02";
                    else if (otpt_adms_dvcd == "T")
                        PrscClCode = "06";
                    else
                        PrscClCode = "08";

                    // DUR 수진자보험자구분 설정 (04)건강보험/(05)의료급여/(07)보훈/(09)일반/(10)산재/(11)자보
                    if (vtrn_pt_yn == "Y")
                        InsurerType = "07";
                    else
                    {
                        switch (insn_tycd)
                        {
                            case "11":
                                InsurerType = "04";
                                break;
                            case "21":
                            case "22":
                                InsurerType = "05";
                                break;
                            case "51":
                                InsurerType = "09";
                                break;
                            case "31":
                                InsurerType = "10";
                                break;
                            case "41":
                                InsurerType = "11";
                                break;
                        }
                    }

                    // DUR 처방면허종별 설정 (AA)의사/(BB)약사/(CC)치과의사/(DD)한의사
                    if (insn_clam_dept_cd == "55")
                        PrscLicType = "CC";
                    else if (insn_clam_dept_cd == "80")
                        PrscLicType = "DD";
                    else
                        PrscLicType = "AA";

                    // DUR 임부 확인
                    if (string.IsNullOrWhiteSpace(femme_pid))
                        PregWmnYN = "N";
                    else
                        PregWmnYN = "Y";

                    // 외래/입원은 no_1사용, 퇴원은 no_2사용
                    // 2018-11-19 김남훈 외래 원외, 외래 원내 추가
                    if (dur_trans_dvcd == "OO" || otpt_adms_dvcd == "I")
                        dur_grnt_no = prsp_grnt_no_1;
                    else
                        dur_grnt_no = prsp_grnt_no_2;

                    DelegateDur delDur = delegate (ref string str)
                    {
                        // DUR Object 초기화
                        DurPrescription.ClearMedicine();

                        for (int i = 0; i < dtMed.Rows.Count; i++)
                        {
                            prsc_cd      = dtMed.Rows[i]["PRSC_CD"     ].ToString();
                            prsc_dvcd    = dtMed.Rows[i]["PRSC_DVCD"   ].ToString();
                            prsc_uniq_no = dtMed.Rows[i]["PRSC_UNIQ_NO"].ToString();
                            dc_prsc_dvcd = dtMed.Rows[i]["DC_PRSC_DVCD"].ToString();
                            ontm_qty     = dtMed.Rows[i]["ONTM_QTY"    ].ToString();
                            notm         = dtMed.Rows[i]["NOTM"        ].ToString();
                            nody         = dtMed.Rows[i]["NODY"        ].ToString();
                            pnpy_dvcd    = dtMed.Rows[i]["PNPY_DVCD"   ].ToString();
                            excp_resn_cd = dtMed.Rows[i]["EXCP_RESN_CD"].ToString();
                            aomd_mthd_cd = dtMed.Rows[i]["AOMD_MTHD_CD"].ToString();
                            prsc_lcls_cd = dtMed.Rows[i]["PRSC_LCLS_CD"].ToString();

                            if (string.IsNullOrWhiteSpace(prsc_cd))
                                continue;
                            if (dc_prsc_dvcd != "A")
                                continue;

                            if (prsc_dvcd == "S" || prsc_dvcd == "P")
                                continue;

                            // 수가정보를 불러온다.
                            mefeinfo = ORBizCommon.GetMefeInfo(prsc_cd, mdcr_dd, "%", ref str);
                            if (mefeinfo == null)
                                continue;

                            mefe_dvcd = mefeinfo["MEFE_DVCD"].ToString();
                            edi_cd = mefeinfo["EDI_CD"].ToString();
                            main_ingr_cd = mefeinfo["MAIN_INGR_CD"].ToString();
                            mefe_hnm = mefeinfo["MEFE_HNM"].ToString();
                            prsc_clsf_cd = mefeinfo["PRSC_CLSF_CD"].ToString();

                            if (string.IsNullOrWhiteSpace(main_ingr_cd))
                                continue;
                            else if (string.IsNullOrWhiteSpace(edi_cd))
                                continue;
                            else if (edi_cd.Length <= 6)
                                continue;
                            //else if (prsc_lcls_cd != "20" && prsc_lcls_cd != "30")
                            //continue;

                            // 약/주사가 아닐 때 제외
                            if (prsc_clsf_cd != "1" && prsc_clsf_cd != "2" && prsc_clsf_cd != "3" && prsc_clsf_cd != "4")
                                continue;

                            // 퇴원약 처방은 퇴원만 가능
                            if (PrscClCode == "06" && prsc_dvcd != "T")
                                continue;

                            // 입원약 처방은 퇴원약 처방에 포함 X
                            if (otpt_adms_dvcd == "I" && prsc_dvcd == "T")
                                continue;

                            // 2018-11-19 김남훈 외래 원외일 때 원내처방 제외
                            if (dur_trans_dvcd == "OO" && excp_resn_cd != "NO")
                                continue;

                            // 2018-11-19 김남훈 외래 원내일 때 원외처방 제외
                            if (dur_trans_dvcd == "OI" && excp_resn_cd == "NO")
                                continue;

                            //// 사유점검창 한번 띄우기 위함, 변경된 데이터 없을 때 Continue
                            //if (otpt_adms_dvcd == "I" && rowtype == CRUD_TYPE.Read)
                            //    continue;

                            //// 위 칼럼을 제외한 칼럼이 수정 되었을 때 Continue
                            //if (otpt_adms_dvcd == "I" && rowtype == CRUD_TYPE.Update &&
                            //   prsc_inpt_qty_type != CRUD_TYPE.Update && notm_type != CRUD_TYPE.Update && nody_type != CRUD_TYPE.Update &&
                            //   aomd_mthd_cd_type != CRUD_TYPE.Update && prsc_dvcd_type != CRUD_TYPE.Update && pnpy_dvcd_type != CRUD_TYPE.Update && excp_resn_cd_type != CRUD_TYPE.Update)
                            //    continue;

                            // DUR 원내외 구분 설정(예외사유 NO = 1, NO 아닐때 >= 2)
                            if (dur_trans_dvcd == "OO")
                                ioHsp = "1";
                            else
                                ioHsp = "2";

                            // DUR 분류유형코드 설정 (분류유형이 4일 때 5로 변경)
                            if (mefe_dvcd == "4")
                                prscType = "5";
                            else
                                prscType = mefe_dvcd;

                            // 미산정 Continue
                            if (pnpy_dvcd == "5")
                                continue;

                            // DUR 보험 적용구분 설정
                            if (pnpy_dvcd == "1")
                                insudmdtype = "A";
                            else if (pnpy_dvcd == "4")
                                insudmdtype = "B";
                            else if (pnpy_dvcd == "2")
                                insudmdtype = "C";
                            else if (pnpy_dvcd == "3")
                                insudmdtype = "B";
                            else
                                insudmdtype = "D";

                            entry_count++;

                            // 입력 의사의 면허번호와 이름을 불러온다.
                            lcno = UserList.GetColumnValue(entry_dr_cd, "LCNO").ToString();
                            user_nm = UserList.GetColumnValue(entry_dr_cd, "USER_NM").ToString();

                            // 처방한 약품정보를 입력한다.
                            if (!this.SetAddMedicine("P"
                                                  , rrn
                                                  , pt_nm
                                                  , InsurerType
                                                  , PregWmnYN
                                                  , HospitalInfo["HPTL_RGNO_CD"].ToString()
                                                  , dur_grnt_no
                                                  , HospitalInfo["HSPT_NM"].ToString()
                                                  , HospitalInfo["TEL"].ToString()
                                                  , HospitalInfo["FAX_NO"].ToString()
                                                  , mdcr_dd
                                                  , prsc_time
                                                  , PrscLicType
                                                  , lcno
                                                  , user_nm
                                                  , insn_clam_dept_cd
                                                  , PrscClCode
                                                  , HospitalInfo["EDI_PRMT_NO"].ToString()
                                                  , dur_dvcd
                                                  , prscType
                                                  , edi_cd
                                                  , mefe_hnm
                                                  , main_ingr_cd
                                                  , ontm_qty
                                                  , notm
                                                  , nody
                                                  , insudmdtype
                                                  , ioHsp
                                                  , aomd_mthd_cd
                                                  , MainSick
                                                  , ref str))
                                return false;
                        }

                        // DUR 전송한 데이터가 있다면
                        if (entry_count >= 1)
                        {
                            // DUR Object 초기화
                            DurResultSet.ClearResult();

                            durreturn = DurClient.Check(DurPrescription, DurResultSet);

                            // Skip 가능한 코드 확인
                            if (durreturn != 0)
                            {
                                skip_code = DBService.ExecuteScalar(SQL.Function.SelectFN_BI_READ_BICDINDT(), "DUR_ERR_SKIPCD"
                                                                                                            , durreturn.ToString()
                                                                                                            , mdcr_dd
                                                                                                            , "ITNL_USE_CD").ToString();

                                if (string.IsNullOrWhiteSpace(skip_code))
                                    skip_code = "N";

                                if (skip_code == "N")
                                {
                                    str = "DUR 점검실시 오류 : " + durreturn.ToString() + " : " + DurClient.LastErrorMsg;
                                    return false;
                                }
                            }
                        }

                        return true;
                    };

                    IAsyncResult ress = delDur.BeginInvoke(ref errmsg, null, "");
                    ress.AsyncWaitHandle.WaitOne();
                    if (!delDur.EndInvoke(ref errmsg, ress))
                        return false;
                }
                else if (dur_dvcd == "Z" && (otpt_adms_dvcd == "O" || otpt_adms_dvcd == "T"))
                {
                    // 외래/입원은 no_1사용, 퇴원은 no_2사용
                    // 2018-11-19 김남훈 외래 원외, 외래 원내 추가
                    if (dur_trans_dvcd == "OO" || otpt_adms_dvcd == "I")
                        prsp_grnt_no = prsp_grnt_no_1;
                    else
                        prsp_grnt_no = prsp_grnt_no_2;

                    // 전송한 처방 개수가 있으면 취소요청
                    if (DBService.ExecuteInteger(SQL.OR.Sql.SelectCountPrspGrntNoORDRRSIF(), pid
                                                                                            , pt_cmhs_no
                                                                                            , mdcr_dd
                                                                                            , otpt_adms_dvcd
                                                                                            , prsp_grnt_no) > 0)
                    {
                        // 점검취소
                        durreturn = DurClient.MprscCancel("M", rrn, mdcr_dd, HospitalInfo["HPTL_RGNO_CD"].ToString(), prsp_grnt_no, "M5", "", "");

                        // 에러 무시 가능 확인
                        if (durreturn != 0)
                        {
                            skip_code = DBService.ExecuteScalar(SQL.Function.SelectFN_BI_READ_BICDINDT(), "DUR_ERR_SKIPCD"
                                                                                                        , durreturn.ToString()
                                                                                                        , mdcr_dd
                                                                                                        , "ITNL_USE_CD").ToString();

                            if (string.IsNullOrWhiteSpace(skip_code))
                                skip_code = "N";

                            if (skip_code == "N")
                            {
                                errmsg = "점검취소 중 오류발생\r\n" +
                                         "점검결과 에러코드 : " + durreturn.ToString();
                                return false;
                            }
                        }
                    }
                }
            }

            return true;
        }

        /// <summary>
        /// DUR 처방정보를 저장한다.
        /// </summary>
        /// <param name="resultinfo">DUR정보</param>
        /// <param name="errmsg">에러메세지</param>
        /// <returns></returns>
        public bool InsertORDRRSIF(DataTable dt, string pid, string prsc_dvcd, string otpt_adms_dvcd, string dur_trans_dvcd, string pt_cmhs_no, string mdcr_dd, string dur_grnt_no, string todate, ref string errmsg)
        {
            string prsc_cd = string.Empty;
            string prsc_sqno = string.Empty;
            string prsc_lcls_cd = string.Empty;
            string dc_prsc_dvcd = string.Empty;
            string chek_prsc_dvcd = string.Empty;
            string prsc_mcls_cd = string.Empty;
            string prsc_nm = string.Empty;
            string prsc_inpt_qty = string.Empty;
            string aply_ontm_qty = string.Empty;
            string ontm_qty = string.Empty;
            string notm = string.Empty;
            string nody = string.Empty;
            string aomd_itvl_valu = string.Empty;
            string aomd_vlct_valu = string.Empty;
            string aomd_unit_valu = string.Empty;
            string aomd_mthd_cd = string.Empty;
            string mix_yn = string.Empty;
            string excp_resn_cd = string.Empty;
            string pnpy_dvcd = string.Empty;
            string prv_actg_yn = string.Empty;
            string prsc_pcft = string.Empty;
            string rcpt_yn = string.Empty;
            string prsc_clsf_cd = string.Empty;
            string main_ingr_cd = string.Empty;
            string edi_cd = string.Empty;
            string prsc_uniq_no = string.Empty;

            if (m_DUR_YN)
            {

                //prsc_uniq_no = DBService.ExecuteInteger(SQL.OR.Sql.SelectMaxPrscUniqNoORDRRSIF(), pid
                //                                                                                , pt_cmhs_no
                //                                                                                , mdcr_dd
                //                                                                                , otpt_adms_dvcd);

                //if(prsc_uniq_no <= 0)
                //{
                //    errmsg = "DUR 처방정보 처방횟수 조회 중 오류가 발생했습니다.[Class/clsDurProcess/InsertORDRRSIF]";
                //    return false;
                //}

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    prsc_cd = dt.Rows[i]["PRSC_CD"].ToString();
                    prsc_uniq_no = dt.Rows[i]["PRSC_UNIQ_NO"].ToString();
                    main_ingr_cd = dt.Rows[i]["MAIN_INGR_CD"].ToString() == "*" ? "" : dt.Rows[i]["MAIN_INGR_CD"].ToString();

                    if (string.IsNullOrWhiteSpace(prsc_cd))
                        continue;

                    if (dur_grnt_no == "NO")
                        continue;

                    prsc_sqno = dt.Rows[i]["PRSC_SQNO"].ToString();
                    prsc_lcls_cd = dt.Rows[i]["PRSC_LCLS_CD"].ToString();

                    if (prsc_lcls_cd != "20" && prsc_lcls_cd != "30")
                        continue;

                    dc_prsc_dvcd = dt.Rows[i]["DC_PRSC_DVCD"].ToString();
                    chek_prsc_dvcd = dt.Rows[i]["PRSC_DVCD"].ToString();

                    if (chek_prsc_dvcd == "S" || chek_prsc_dvcd == "P")
                        continue;

                    prsc_mcls_cd = dt.Rows[i]["PRSC_MCLS_CD"].ToString();
                    prsc_nm = dt.Rows[i]["PRSC_NM"].ToString();
                    prsc_inpt_qty = dt.Rows[i]["PRSC_INPT_QTY"].ToString();
                    aply_ontm_qty = dt.Rows[i]["APLY_ONTM_QTY"].ToString();
                    ontm_qty = dt.Rows[i]["ONTM_QTY"].ToString();
                    notm = dt.Rows[i]["NOTM"].ToString();
                    nody = dt.Rows[i]["NODY"].ToString();
                    aomd_itvl_valu = dt.Rows[i]["AOMD_ITVL_VALU"].ToString();
                    aomd_vlct_valu = dt.Rows[i]["AOMD_VLCT_VALU"].ToString();
                    aomd_unit_valu = dt.Rows[i]["AOMD_UNIT_VALU"].ToString();
                    aomd_mthd_cd = dt.Rows[i]["AOMD_MTHD_CD"].ToString();
                    mix_yn = dt.Rows[i]["MIX_YN"].ToString();
                    excp_resn_cd = dt.Rows[i]["EXCP_RESN_CD"].ToString();
                    pnpy_dvcd = dt.Rows[i]["PNPY_DVCD"].ToString();
                    prv_actg_yn = dt.Rows[i]["PRV_ACTG_YN"].ToString();
                    prsc_pcft = dt.Rows[i]["PRSC_PCFT"].ToString();
                    rcpt_yn = dt.Rows[i]["RCPT_YN"].ToString();
                    prsc_clsf_cd = dt.Rows[i]["PRSC_CLSF_CD"].ToString();

                    if (string.IsNullOrWhiteSpace(main_ingr_cd))
                        continue;

                    // 약, 주사 아닐 경우 제외
                    if (!new string[] { "20", "30" }.Any(s => s.Equals(prsc_lcls_cd)))
                        continue;

                    // 분류코드 내복, 외용, 기타약품, 주사 아닐 경우 제외
                    if (!new string[] { "1", "2", "3", "4" }.Any(s => s.Equals(prsc_clsf_cd)))
                        continue;

                    if (string.IsNullOrWhiteSpace(dur_grnt_no))
                        dur_grnt_no = "NO";

                    // 퇴원약은 퇴원약 처방만
                    if (prsc_dvcd == "06" && chek_prsc_dvcd != "T")
                        continue;

                    // 입원약 처방은 퇴원약 처방을 포함시키면 안된다.
                    if (otpt_adms_dvcd == "I" && chek_prsc_dvcd == "T")
                        continue;

                    // 2018-11-19 김남훈 외래 원외일 때 원내처방 제외
                    if (dur_trans_dvcd == "OO" && excp_resn_cd != "NO")
                        continue;

                    // 2018-11-19 김남훈 외래 원외일 때 원내처방 제외 
                    if (dur_trans_dvcd == "OI" && excp_resn_cd == "NO")
                        continue;

                    // 2019-03-07, 임상시험처방은 제외
                    // 2020-05-18, +@ 미정산 제외 / 상위 메소드 조건과 동일하게
                    if (new string[] { "5", "9" }.Any(s => s.Equals(pnpy_dvcd)))
                        continue;

                    edi_cd = DBService.ExecuteScalar(SQL.OR.Sql.SelectMefeCdEdiCd(), prsc_cd
                                                                                   , mdcr_dd).ToString();

                    if (string.IsNullOrWhiteSpace(edi_cd))
                        continue;

                    if (edi_cd.Length <= 6)
                        continue;

                    aply_ontm_qty = ontm_qty;

                    if (!DBService.ExecuteNonQuery(SQL.OR.Sql.DeleteDurTransPrscORDRRSIF(), pid, pt_cmhs_no, mdcr_dd, prsc_uniq_no, prsc_sqno))
                    {
                        errmsg = "전송처방 삭제 중 오류가 발생했습니다.[Class/clsEntryOrder/TransDur]";
                        return false;
                    }

                    if (!DBService.ExecuteNonQuery(SQL.OR.BaseSql.Insert.ORDRRSIF(), pid
                                                                                  , pt_cmhs_no
                                                                                  , mdcr_dd
                                                                                  , prsc_uniq_no
                                                                                  , prsc_sqno
                                                                                  , otpt_adms_dvcd
                                                                                  , prsc_lcls_cd
                                                                                  , prsc_mcls_cd
                                                                                  , prsc_cd
                                                                                  , prsc_nm
                                                                                  , prsc_inpt_qty
                                                                                  , aply_ontm_qty
                                                                                  , ontm_qty
                                                                                  , notm
                                                                                  , nody
                                                                                  , aomd_itvl_valu
                                                                                  , aomd_vlct_valu
                                                                                  , aomd_unit_valu
                                                                                  , aomd_mthd_cd
                                                                                  , mix_yn
                                                                                  , excp_resn_cd
                                                                                  , dur_grnt_no
                                                                                  , pnpy_dvcd
                                                                                  , prv_actg_yn
                                                                                  , prsc_pcft
                                                                                  , rcpt_yn
                                                                                  , prsc_clsf_cd
                                                                                  , main_ingr_cd
                                                                                  , edi_cd
                                                                                  , dur_trans_dvcd
                                                                                  , ""
                                                                                  , ""
                                                                                  , ""
                                                                                  , ""
                                                                                  , todate
                                                                                  , DOPack.UserInfo.USER_CD
                                                                                  , todate
                                                                                  , DOPack.UserInfo.USER_CD))
                    {
                        errmsg = "DUR 처방정보 저장 중 오류가 발생했습니다.[Class/clsDurProcess/InsertORDRRSIF]";
                        return false;
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// DUR 처방정보 History를 저장한다.
        /// </summary>
        /// <param name="resultinfo">DUR정보</param>
        /// <param name="errmsg">에러메세지</param>
        /// <returns></returns>
        public bool InsertORDRRSHS(DataTable dt, string pid, string prsc_dvcd, string otpt_adms_dvcd, string dur_trans_dvcd, string pt_cmhs_no, string mdcr_dd, string dur_grnt_no, string todate, ref string errmsg)
        {
            string prsc_cd = string.Empty;
            string prsc_sqno = string.Empty;
            string prsc_lcls_cd = string.Empty;
            string dc_prsc_dvcd = string.Empty;
            string chek_prsc_dvcd = string.Empty;
            string prsc_mcls_cd = string.Empty;
            string prsc_nm = string.Empty;
            string prsc_inpt_qty = string.Empty;
            string aply_ontm_qty = string.Empty;
            string ontm_qty = string.Empty;
            string notm = string.Empty;
            string nody = string.Empty;
            string aomd_itvl_valu = string.Empty;
            string aomd_vlct_valu = string.Empty;
            string aomd_unit_valu = string.Empty;
            string aomd_mthd_cd = string.Empty;
            string mix_yn = string.Empty;
            string excp_resn_cd = string.Empty;
            string pnpy_dvcd = string.Empty;
            string prv_actg_yn = string.Empty;
            string prsc_pcft = string.Empty;
            string rcpt_yn = string.Empty;
            string prsc_clsf_cd = string.Empty;
            string main_ingr_cd = string.Empty;
            string edi_cd = string.Empty;
            string prsc_uniq_no = string.Empty;
            int sqno = 0;

            if (m_DUR_YN)
            {
                sqno = DBService.ExecuteInteger(SQL.OR.Sql.SelectMaxSqnoORDRRSHS(), pid
                                                                                  , pt_cmhs_no
                                                                                  , mdcr_dd);

                if (sqno <= 0)
                {
                    errmsg = "DUR 처방 History 일련번호 조회 중 오류가 발생했습니다.[Class/clsDurProcess/InsertORDRRSHS]";
                    return false;
                }

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    prsc_cd = dt.Rows[i]["PRSC_CD"].ToString();
                    prsc_uniq_no = dt.Rows[i]["PRSC_UNIQ_NO"].ToString();

                    if (string.IsNullOrWhiteSpace(prsc_cd))
                        continue;

                    if (dur_grnt_no == "NO")
                        continue;

                    prsc_sqno = dt.Rows[i]["PRSC_SQNO"].ToString();
                    prsc_lcls_cd = dt.Rows[i]["PRSC_LCLS_CD"].ToString();
                    main_ingr_cd = dt.Rows[i]["MAIN_INGR_CD"].ToString() == "*" ? "" : dt.Rows[i]["MAIN_INGR_CD"].ToString();

                    if (prsc_lcls_cd != "20" && prsc_lcls_cd != "30")
                        continue;

                    dc_prsc_dvcd = dt.Rows[i]["DC_PRSC_DVCD"].ToString();
                    chek_prsc_dvcd = dt.Rows[i]["PRSC_DVCD"].ToString();

                    if (chek_prsc_dvcd == "S" || chek_prsc_dvcd == "P")
                        continue;

                    prsc_mcls_cd = dt.Rows[i]["PRSC_MCLS_CD"].ToString();
                    prsc_nm = dt.Rows[i]["PRSC_NM"].ToString();
                    prsc_inpt_qty = dt.Rows[i]["PRSC_INPT_QTY"].ToString();
                    aply_ontm_qty = dt.Rows[i]["APLY_ONTM_QTY"].ToString();
                    ontm_qty = dt.Rows[i]["ONTM_QTY"].ToString();
                    notm = dt.Rows[i]["NOTM"].ToString();
                    nody = dt.Rows[i]["NODY"].ToString();
                    aomd_itvl_valu = dt.Rows[i]["AOMD_ITVL_VALU"].ToString();
                    aomd_vlct_valu = dt.Rows[i]["AOMD_VLCT_VALU"].ToString();
                    aomd_unit_valu = dt.Rows[i]["AOMD_UNIT_VALU"].ToString();
                    aomd_mthd_cd = dt.Rows[i]["AOMD_MTHD_CD"].ToString();
                    mix_yn = dt.Rows[i]["MIX_YN"].ToString();
                    excp_resn_cd = dt.Rows[i]["EXCP_RESN_CD"].ToString();
                    pnpy_dvcd = dt.Rows[i]["PNPY_DVCD"].ToString();
                    prv_actg_yn = dt.Rows[i]["PRV_ACTG_YN"].ToString();
                    prsc_pcft = dt.Rows[i]["PRSC_PCFT"].ToString();
                    rcpt_yn = dt.Rows[i]["RCPT_YN"].ToString();
                    prsc_clsf_cd = dt.Rows[i]["PRSC_CLSF_CD"].ToString();

                    if (string.IsNullOrWhiteSpace(main_ingr_cd))
                        continue;

                    else if (prsc_lcls_cd != "20" && prsc_lcls_cd != "30")
                        continue;

                    if (string.IsNullOrWhiteSpace(dur_grnt_no))
                        dur_grnt_no = "NO";

                    // 퇴원약은 퇴원약 처방만
                    if (prsc_dvcd == "06" && chek_prsc_dvcd != "T")
                        continue;

                    // 입원약 처방은 퇴원약 처방을 포함시키면 안된다.
                    if (otpt_adms_dvcd == "I" && chek_prsc_dvcd == "T")
                        continue;

                    // 2018-11-19 김남훈 외래 원외일 때 원내처방 제외
                    if (dur_trans_dvcd == "OO" && excp_resn_cd != "NO")
                        continue;

                    // 2018-11-19 김남훈 외래 원외일 때 원내처방 제외
                    if (dur_trans_dvcd == "OI" && excp_resn_cd == "NO")
                        continue;

                    // 2019-03-07 임상시험 처방은 제외
                    if (pnpy_dvcd == "9")
                        continue;

                    edi_cd = DBService.ExecuteScalar(SQL.OR.Sql.SelectMefeCdEdiCd(), prsc_cd
                                                                                   , mdcr_dd).ToString();

                    aply_ontm_qty = ontm_qty;

                    if (!DBService.ExecuteNonQuery(SQL.OR.BaseSql.Insert.ORDRRSHS(), pid
                                                                                  , pt_cmhs_no
                                                                                  , mdcr_dd
                                                                                  , prsc_uniq_no
                                                                                  , prsc_sqno
                                                                                  , sqno.ToString()
                                                                                  , otpt_adms_dvcd
                                                                                  , prsc_lcls_cd
                                                                                  , prsc_mcls_cd
                                                                                  , prsc_cd
                                                                                  , prsc_nm
                                                                                  , prsc_inpt_qty
                                                                                  , aply_ontm_qty
                                                                                  , ontm_qty
                                                                                  , notm
                                                                                  , nody
                                                                                  , aomd_itvl_valu
                                                                                  , aomd_vlct_valu
                                                                                  , aomd_unit_valu
                                                                                  , aomd_mthd_cd
                                                                                  , mix_yn
                                                                                  , excp_resn_cd
                                                                                  , dur_grnt_no
                                                                                  , pnpy_dvcd
                                                                                  , prv_actg_yn
                                                                                  , prsc_pcft
                                                                                  , rcpt_yn
                                                                                  , prsc_clsf_cd
                                                                                  , main_ingr_cd
                                                                                  , edi_cd
                                                                                  , dur_trans_dvcd
                                                                                  , ""
                                                                                  , ""
                                                                                  , ""
                                                                                  , ""
                                                                                  , todate
                                                                                  , DOPack.UserInfo.USER_CD
                                                                                  , todate
                                                                                  , DOPack.UserInfo.USER_CD))
                    {
                        errmsg = "DUR 처방정보 저장 중 오류가 발생했습니다.[Class/clsDurProcess/InsertORDRRSHS]";
                        return false;
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// DUR 전송 사유정보를 저장한다.
        /// </summary>
        /// <param name="resultinfo">DUR정보</param>
        /// <param name="errmsg">에러메세지</param>
        /// <returns></returns>
        public bool InsertORDRTRIF(DurResultInfo resultinfo, ref string errmsg)
        {
            if (m_DUR_YN)
            {
                if (!DBService.ExecuteNonQuery(SQL.OR.BaseSql.Insert.ORDRTRIF(), resultinfo.pid
                                                                               , resultinfo.pt_cmhs_no.ToString()
                                                                               , resultinfo.mdcr_dd
                                                                               , resultinfo.prsc_sqno.ToString()
                                                                               , resultinfo.Index.ToString()
                                                                               , resultinfo.otpt_adms_dvcd
                                                                               , resultinfo.Totalcnt.ToString()
                                                                               , resultinfo.Checkcnt.ToString()
                                                                               , resultinfo.Reportcnt.ToString()
                                                                               , resultinfo.ErrorCode.ToString()
                                                                               , resultinfo.Medicnt.ToString()
                                                                               , resultinfo.MedicineSerialNo.ToString()
                                                                               , (resultinfo.ExamTypeCD == null ? "" : resultinfo.ExamTypeCD)
                                                                               , (resultinfo.MedcCDA == null ? "" : resultinfo.MedcCDA)
                                                                               , (resultinfo.MedcNMA == null ? "" : resultinfo.MedcNMA)
                                                                               , (resultinfo.GnlNMCDA == null ? "" : resultinfo.GnlNMCDA)
                                                                               , (resultinfo.GnlNMA == null ? "" : resultinfo.GnlNMA)
                                                                               , (resultinfo.Message == null ? "" : resultinfo.Message)
                                                                               , resultinfo.DDMqtyFreqA.ToString()
                                                                               , resultinfo.DDExecFreqA.ToString()
                                                                               , resultinfo.mdcnExecFreqA.ToString()
                                                                               , (resultinfo.ReasonCD == null ? "" : resultinfo.ReasonCD)
                                                                               , (resultinfo.Reason == null ? "" : resultinfo.Reason)
                                                                               , resultinfo.Type.ToString()
                                                                               , resultinfo.Level.ToString()
                                                                               , (resultinfo.Notice == null ? "" : resultinfo.Notice)
                                                                               , (resultinfo.DpPrscMake == null ? "" : resultinfo.DpPrscMake)
                                                                               , (resultinfo.DpPrscYYMMDD == null ? "" : resultinfo.DpPrscYYMMDD)
                                                                               , (resultinfo.DpPrscHMMSS == null ? "" : resultinfo.DpPrscHMMSS)
                                                                               , (resultinfo.DpPrscAdminCode == null ? "" : resultinfo.DpPrscAdminCode)
                                                                               , (resultinfo.DpPrscGrantNo == null ? "" : resultinfo.DpPrscGrantNo)
                                                                               , (resultinfo.DpPrscAdminName == null ? "" : resultinfo.DpPrscAdminName)
                                                                               , (resultinfo.DpPrscTel == null ? "" : resultinfo.DpPrscTel)
                                                                               , (resultinfo.DpPrscFax == null ? "" : resultinfo.DpPrscFax)
                                                                               , (resultinfo.DpPrscName == null ? "" : resultinfo.DpPrscName)
                                                                               , (resultinfo.DpPrscLic == null ? "" : resultinfo.DpPrscLic)
                                                                               , (resultinfo.DpMakeYYMMDD == null ? "" : resultinfo.DpMakeYYMMDD)
                                                                               , (resultinfo.DpMakeHMMSS == null ? "" : resultinfo.DpMakeHMMSS)
                                                                               , (resultinfo.DpMakeAdminCode == null ? "" : resultinfo.DpMakeAdminCode)
                                                                               , (resultinfo.DpMakeAdminName == null ? "" : resultinfo.DpMakeAdminName)
                                                                               , (resultinfo.DpMakeTel == null ? "" : resultinfo.DpMakeTel)
                                                                               , (resultinfo.DpMakeName == null ? "" : resultinfo.DpMakeName)
                                                                               , (resultinfo.DpMakeLic == null ? "" : resultinfo.DpMakeLic)
                                                                               , (resultinfo.MedcCDB == null ? "" : resultinfo.MedcCDB)
                                                                               , (resultinfo.MedcNMB == null ? "" : resultinfo.MedcNMB)
                                                                               , (resultinfo.GnlNMCDB == null ? "" : resultinfo.GnlNMCDB)
                                                                               , (resultinfo.GnlNMB == null ? "" : resultinfo.GnlNMB)
                                                                               , resultinfo.DDMqtyFreqB.ToString()
                                                                               , resultinfo.DDTotalMqtyB.ToString()
                                                                               , resultinfo.MdcnExecFreqB.ToString()
                                                                               , resultinfo.dur_trans_dvcd
                                                                               , ""
                                                                               , ""
                                                                               , ""
                                                                               , ""
                                                                               , resultinfo.rgst_dt
                                                                               , resultinfo.rgstr_id
                                                                               , resultinfo.updt_dt
                                                                               , resultinfo.updtr_id))
                {
                    errmsg = "DUR 전송 사유정보 저장 중 오류가 발생했습니다.[Class/clsDurProcess/InsertORDRTRIF]";
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// DUR History정보를 저장한다.
        /// </summary>
        /// <param name="resultinfo">DUR정보</param>
        /// <param name="errmsg">에러메세지</param>
        /// <returns></returns>
        public bool InsertORDURTHS(DurResultInfo resultinfo, ref string errmsg)
        {
            int maxsqno = 0;

            if (m_DUR_YN)
            {
                maxsqno = DBService.ExecuteInteger(SQL.OR.Sql.SelectMaxSqnoORDURTHS(), resultinfo.pid
                                                                                     , resultinfo.pt_cmhs_no.ToString()
                                                                                     , resultinfo.mdcr_dd
                                                                                     , resultinfo.prsc_sqno.ToString()
                                                                                     , resultinfo.Index.ToString());
                if (maxsqno <= 0)
                {
                    errmsg = "DUR History 일련번호 조회 중 오류가 발생했습니다.[Class/clsDurProcess/InsertORDURTHS]";
                    return false;
                }

                if (!DBService.ExecuteNonQuery(SQL.OR.BaseSql.Insert.ORDURTHS(), resultinfo.pid
                                                                               , resultinfo.pt_cmhs_no.ToString()
                                                                               , resultinfo.mdcr_dd
                                                                               , resultinfo.prsc_sqno.ToString()
                                                                               , maxsqno.ToString()
                                                                               , resultinfo.Index.ToString()
                                                                               , resultinfo.otpt_adms_dvcd
                                                                               , resultinfo.Totalcnt.ToString()
                                                                               , resultinfo.Checkcnt.ToString()
                                                                               , resultinfo.Reportcnt.ToString()
                                                                               , resultinfo.ErrorCode.ToString()
                                                                               , resultinfo.Medicnt.ToString()
                                                                               , resultinfo.MedicineSerialNo.ToString()
                                                                               , (resultinfo.ExamTypeCD == null ? "" : resultinfo.ExamTypeCD)
                                                                               , (resultinfo.MedcCDA == null ? "" : resultinfo.MedcCDA)
                                                                               , (resultinfo.MedcNMA == null ? "" : resultinfo.MedcNMA)
                                                                               , (resultinfo.GnlNMCDA == null ? "" : resultinfo.GnlNMCDA)
                                                                               , (resultinfo.GnlNMA == null ? "" : resultinfo.GnlNMA)
                                                                               , (resultinfo.Message == null ? "" : resultinfo.Message)
                                                                               , resultinfo.DDMqtyFreqA.ToString()
                                                                               , resultinfo.DDExecFreqA.ToString()
                                                                               , resultinfo.mdcnExecFreqA.ToString()
                                                                               , (resultinfo.ReasonCD == null ? "" : resultinfo.ReasonCD)
                                                                               , (resultinfo.Reason == null ? "" : resultinfo.Reason)
                                                                               , resultinfo.Type.ToString()
                                                                               , resultinfo.Level.ToString()
                                                                               , (resultinfo.Notice == null ? "" : resultinfo.Notice)
                                                                               , (resultinfo.DpPrscMake == null ? "" : resultinfo.DpPrscMake)
                                                                               , (resultinfo.DpPrscYYMMDD == null ? "" : resultinfo.DpPrscYYMMDD)
                                                                               , (resultinfo.DpPrscHMMSS == null ? "" : resultinfo.DpPrscHMMSS)
                                                                               , (resultinfo.DpPrscAdminCode == null ? "" : resultinfo.DpPrscAdminCode)
                                                                               , (resultinfo.DpPrscGrantNo == null ? "" : resultinfo.DpPrscGrantNo)
                                                                               , (resultinfo.DpPrscAdminName == null ? "" : resultinfo.DpPrscAdminName)
                                                                               , (resultinfo.DpPrscTel == null ? "" : resultinfo.DpPrscTel)
                                                                               , (resultinfo.DpPrscFax == null ? "" : resultinfo.DpPrscFax)
                                                                               , (resultinfo.DpPrscName == null ? "" : resultinfo.DpPrscName)
                                                                               , (resultinfo.DpPrscLic == null ? "" : resultinfo.DpPrscLic)
                                                                               , (resultinfo.DpMakeYYMMDD == null ? "" : resultinfo.DpMakeYYMMDD)
                                                                               , (resultinfo.DpMakeHMMSS == null ? "" : resultinfo.DpMakeHMMSS)
                                                                               , (resultinfo.DpMakeAdminCode == null ? "" : resultinfo.DpMakeAdminCode)
                                                                               , (resultinfo.DpMakeAdminName == null ? "" : resultinfo.DpMakeAdminName)
                                                                               , (resultinfo.DpMakeTel == null ? "" : resultinfo.DpMakeTel)
                                                                               , (resultinfo.DpMakeName == null ? "" : resultinfo.DpMakeName)
                                                                               , (resultinfo.DpMakeLic == null ? "" : resultinfo.DpMakeLic)
                                                                               , (resultinfo.MedcCDB == null ? "" : resultinfo.MedcCDB)
                                                                               , (resultinfo.MedcNMB == null ? "" : resultinfo.MedcNMB)
                                                                               , (resultinfo.GnlNMCDB == null ? "" : resultinfo.GnlNMCDB)
                                                                               , (resultinfo.GnlNMB == null ? "" : resultinfo.GnlNMB)
                                                                               , resultinfo.DDMqtyFreqB.ToString()
                                                                               , resultinfo.DDTotalMqtyB.ToString()
                                                                               , resultinfo.MdcnExecFreqB.ToString()
                                                                               , resultinfo.dur_trans_dvcd
                                                                               , ""
                                                                               , ""
                                                                               , ""
                                                                               , ""
                                                                               , resultinfo.rgst_dt
                                                                               , resultinfo.rgstr_id
                                                                               , resultinfo.updt_dt
                                                                               , resultinfo.updtr_id))
                {
                    errmsg = "DUR History 정보 저장 중 오류가 발생했습니다.[Class/clsDurProcess/InsertORDURTHS]";
                    return false;
                }
            }
            return true;
        }

        public void TestMprscCancel()
        {
            DurClient.MprscCancel("M", "7610111111111", "20180322", "34202102", "2018032200005", "M5", "", "");
        }

    }

    public class DurResultInfo
    {
        // 처방정보
        public string pid = string.Empty;            // 환자번호
        public int pt_cmhs_no = 0;                       // 환자내원번호
        public string otpt_adms_dvcd = string.Empty;            // 외입구분([O]외래/[I]입원/[T]퇴원약
        public string mdcr_dd = string.Empty;            // 처방일자
        public int prsc_sqno = 0;                       // 처방일련번호
        public string rgst_dt = string.Empty;            // 등록일시
        public string rgstr_id = string.Empty;            // 등록자
        public string updt_dt = string.Empty;            // 수정일시
        public string updtr_id = string.Empty;            // 수정자
        public string dur_trans_dvcd = string.Empty;            // DUR 전송구분

        // DUR 정보
        public int Index = 0;                       // 점검순서
        public int Totalcnt = 0;                       // 점검결과 수신 시 개수 확인
        public int Checkcnt = 0;                       // 점검요청 개수
        public int Reportcnt = 0;                       // 사유입력 개수
        public int ErrorCode = 0;                       // 에러코드
        public int Medicnt = 0;                       // 약품갯수
        public int MedicineSerialNo = 0;                       // 점검시 입력한 약품의 순번
        public string ExamTypeCD = string.Empty;            // 점검구분
        public string MedcCDA = string.Empty;            // 처방코드
        public string MedcNMA = string.Empty;            // 처방명칭
        public string GnlNMCDA = string.Empty;            // 성분코드
        public string GnlNMA = string.Empty;            // 성분명칭
        public string Message = string.Empty;            // 처방이 걸린 DUR 사항 
        public float DDMqtyFreqA = 0;                       // 1회량 
        public float DDExecFreqA = 0;                       // 투여 횟수
        public int mdcnExecFreqA = 0;                       // 투여 일수
        public string ReasonCD = string.Empty;            // 사유코드
        public string Reason = string.Empty;            // 사유 내용
        public int Type = 0;                       // 점검종류코드
        public int Level = 0;                       // 점검결과등금
        public string Notice = string.Empty;            // 부작용정보
        public string DpPrscMake = string.Empty;            // 약품처방조제 구분
        public string DpPrscYYMMDD = string.Empty;            // 중복처방 일자
        public string DpPrscHMMSS = string.Empty;            // 중복처방 시간
        public string DpPrscAdminCode = string.Empty;            // 중복처방 요양기관번호
        public string DpPrscGrantNo = string.Empty;            // 중복처방 처방전 교부번호
        public string DpPrscAdminName = string.Empty;            // 중복처방 기관명
        public string DpPrscTel = string.Empty;            // 중복처방 전화번호 
        public string DpPrscFax = string.Empty;            // 중복처방 팩스
        public string DpPrscName = string.Empty;            // 중복처방 처방의
        public string DpPrscLic = string.Empty;            // 중복처방 면허번호
        public string DpMakeYYMMDD = string.Empty;            // 중복조제 일자
        public string DpMakeHMMSS = string.Empty;            // 중복조제 시간
        public string DpMakeAdminCode = string.Empty;            // 중복조제 요양기관번호
        public string DpMakeAdminName = string.Empty;            // 중복조제 기관명
        public string DpMakeTel = string.Empty;            // 중복조제 전환번호
        public string DpMakeName = string.Empty;            // 중복조제 약사명
        public string DpMakeLic = string.Empty;            // 중복조제 약사 면허번호
        public string MedcCDB = string.Empty;            // 중복처방 약품코드
        public string MedcNMB = string.Empty;            // 중복처방 약품명
        public string GnlNMCDB = string.Empty;            // 중복처방 성분코드
        public string GnlNMB = string.Empty;            // 중복처방 성분명 
        public float DDMqtyFreqB = 0;                       // 중복처방 1회 투약량
        public float DDTotalMqtyB = 0;                       // 중복처방 1일투여회수
        public int MdcnExecFreqB = 0;                       // 중복처방 총투여 일수
    }
}
