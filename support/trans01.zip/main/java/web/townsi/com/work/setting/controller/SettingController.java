package web.townsi.com.work.setting.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import web.townsi.com.framework.fixed.AppConst;
import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;
import web.townsi.com.utils.StrUtil;
import web.townsi.com.work.setting.biz.SettingBiz;

@Controller
@RequestMapping("/setting")
public class SettingController {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private LinkedHashMap<String, String> propMap;

	@Autowired
	private SettingBiz settingBiz;

	public static LinkedHashMap<String, String> tableMap = new LinkedHashMap<>();

	@RequestMapping("/main")
	public String main(@RequestParam HashMap params, Model model) {
		return "setting/main";
	}

	@RequestMapping("/main_sams")
	public String mainSams(@RequestParam HashMap params, Model model) {
		return "setting/main_sams";
	}

	@RequestMapping("/main_sams_hidden")
	public String mainSamsHidden(@RequestParam HashMap params, Model model) {
		return "setting/main_sams_hidden";
	}

	@RequestMapping("/info")
	public ResponseEntity<HashMap> info(@RequestParam HashMap params) {
		HashMap resultMap = new HashMap();
		try {
			resultMap.putAll(propMap);
			resultMap.put("param", params);
			return ResponseEntity.ok(resultMap);
		} catch (Exception e) {
			logger.error("info error", e);
			resultMap.put("error", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resultMap);
		}
	}

	@RequestMapping("/save")
	public ResponseEntity<HashMap> save(HttpServletRequest request, @RequestParam HashMap params) {
		HashMap resultMap = new HashMap();
		try {
			StrUtil.addMap(propMap, params);
			String content = FileUtil.changeContent(AppConst.settingProp, params);
			FileUtil.writeFile(AppConst.settingProp, content);
			resultMap.put("param", params);
			return ResponseEntity.ok(resultMap);
		} catch (Exception e) {
			logger.error("save error", e);
			resultMap.put("error", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resultMap);
		}
	}

	@RequestMapping("/comment")
	public ResponseEntity<HashMap> comment(@RequestParam HashMap params) {
		HashMap resultMap = new HashMap();
		try {
			String comment = settingBiz.takeComment(params);
			HashMap dataMap = new HashMap();
			dataMap.put("comment", comment);
			resultMap.put("data", dataMap);
			resultMap.put("param", params);
			logger.debug("comment params: {}", params);
			return ResponseEntity.ok(resultMap);
		} catch (Exception e) {
			logger.error("comment error", e);
			resultMap.put("error", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resultMap);
		}
	}

	@RequestMapping("/allSourceS2")
	public ResponseEntity<HashMap> allSourceS2(@RequestParam HashMap params, Model model) throws InterruptedException {
		return processAllSources(params, model, false);
	}

	@RequestMapping("/allSourceS3")
	public ResponseEntity<HashMap> allSourceS3(@RequestParam HashMap params, Model model) throws InterruptedException {
		return processAllSources(params, model, true);
	}

	@RequestMapping("/allSamsSource")
	public ResponseEntity<HashMap> allSamsSource(@RequestParam HashMap params, Model model)
			throws InterruptedException {
		HashMap resultMap = new HashMap();
		try {
			if ("SALES".equals(params.get("task"))) {
				params.put("task", "SALES");
			}

			List<HashMap> tableList = settingBiz.selectTableList(params);
			int count = 0;

			for (HashMap table : tableList) {
				String tableName = (String) table.get("TABLE_NAME");
				String desc = (String) table.get("TABLE_COMMENT");

				String tableNewNn = tableMap.get(tableName);
				params.put("tableName", tableName);
				params.put("tableNewNn", tableNewNn);
				params.put("taskName", tableNewNn);
				params.put("desc", desc);

				source(params, model);
				Thread.sleep(200);
				count++;
			}

			return ResponseEntity.ok(resultMap);
		} catch (Exception e) {
			logger.error("allSamsSource error", e);
			resultMap.put("error", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resultMap);
		}
	}

	@RequestMapping("/source")
	public ResponseEntity<HashMap> source(@RequestParam HashMap params, Model model) {
		HashMap resultMap = new HashMap();
		try {
			HashMap dataMap = settingBiz.source(params);
			resultMap.put("data", dataMap);
			resultMap.put("param", params);
			logger.debug("source params: {}", params);
			return ResponseEntity.ok(resultMap);
		} catch (Exception e) {
			logger.error("source error", e);
			resultMap.put("error", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resultMap);
		}
	}

	private ResponseEntity<HashMap> processAllSources(HashMap params, Model model, boolean breakAfterOne)
			throws InterruptedException {
		HashMap resultMap = new HashMap();
		try {
			params.put("owner", "ows");
			List<HashMap> tableList = settingBiz.selectTableList(params);

			for (HashMap table : tableList) {
				String tableName = (String) table.get("TABLE_NAME");
				params.put("tableName", tableName);
				params.put("tableSchema", "ows");
				params.put("ifcase", "if");

				source(params, model);
				Thread.sleep(200);

				if (breakAfterOne)
					break;
			}

			return ResponseEntity.ok(resultMap);
		} catch (Exception e) {
			logger.error("processAllSources error", e);
			resultMap.put("error", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resultMap);
		}
	}
}
