namespace Lime.BusinessControls
{
    partial class popPatientInfoMod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(popPatientInfoMod));
            this.ucPatientInfoModE1 = new Lime.BusinessControls.ucPatientInfoModE();
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ucPatientInfoModE1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBase
            // 
            this.pnlBase.Location = new System.Drawing.Point(1, 31);
            this.pnlBase.Size = new System.Drawing.Size(910, 356);
            // 
            // ucPatientInfoModE1
            // 
            this.ucPatientInfoModE1.BackColor = System.Drawing.Color.White;
            this.ucPatientInfoModE1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucPatientInfoModE1.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.ucPatientInfoModE1.Icon = null;
            this.ucPatientInfoModE1.Location = new System.Drawing.Point(1, 31);
            this.ucPatientInfoModE1.Name = "ucPatientInfoModE1";
            this.ucPatientInfoModE1.Size = new System.Drawing.Size(910, 356);
            this.ucPatientInfoModE1.TabIndex = 4;
            // 
            // popPatientInfoMod
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Caption = "환자기본정보관리";
            this.ClientSize = new System.Drawing.Size(912, 388);
            this.Controls.Add(this.ucPatientInfoModE1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "popPatientInfoMod";
            this.Padding = new System.Windows.Forms.Padding(0);
            this.Text = "환자기본정보관리";
            this.Controls.SetChildIndex(this.pnlBase, 0);
            this.Controls.SetChildIndex(this.ucPatientInfoModE1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ucPatientInfoModE1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ucPatientInfoModE ucPatientInfoModE1;
    }
}