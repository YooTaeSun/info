//********************************************************************
// Class 명 : ucOactLst
// 역    할 : 환자수납처방, 수익집계내역, 처방내역, 영수내역, 내원내역을 보여주는 User Control
// 작 성 자 : PGH
// 작 성 일 : 2017-09-22
//********************************************************************
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public partial class ucOutReceiptBD : UserControl
    {
        #region Define : Event
        public delegate void PrscRetrievedEventHandler(object sender, PrscEventArgs e);
        public event PrscRetrievedEventHandler PrscRetrieved;

        public delegate void NotSave(string CheckDvcd, string NotSaveYn);
        public event NotSave OnNotSave;

        public delegate void PatRegSelected(string pid, string ptcmhsno, string mdcrdd);
        public event PatRegSelected OnPatRegSelected;
        #endregion

        #region Define : Member

        private enum TAB
        {
            PAOPRATP_0, // 수익집계내역
            PAORECTP_1, // 계산처방내역
            ORORDRRT_2, // 처방내역
            PAORECBD_3, // 이전계산처방
            PAOBILBD_4, // 영수리스트
            PAOPATRT_5, // 내원리스트
        }

        private enum COL
        {
            PRFT_CDNM         ,    // 수익명 
            CHANGE_FLAG       ,    // 변경flag
            MEFE_CD           ,    // 처방코드
            MEFE_NM           ,    // 처방명
            PRSC_INPT_QTY     ,    // 입력수량
            ONTM_QTY          ,    // 1회량
            NOTM              ,    // 횟수
            TOTL_AOMD_QTY     ,    // !총투여량
            NODY              ,    // 일수
            EXCP_RESN_CD      ,    // 예외
            PAY_NOPY_DVCD     ,    // 급비
            CLCL_AMT          ,    // 계산금액
            ADTN_CMPT_AMT     ,    // 산정금액
            BYKN_ADTN_AMT     ,    // 종별금액
            UNPR              ,    // 단가
                                   // 
            SMCR_AMT          ,    // !선별진료
            CMPT_CD           ,    // 산정코드
            CMPT_CD_EXPL      ,    // 산정코드명
            PRSC_PCFT         ,    // 특이사항
            PAY_USCH_AMT      ,    // 급여본인
            PAY_CLAM_AMT      ,    // 급여공단
            SCNG_PAY_USCH_AMT ,    // 선별급여본인
            SCNG_PAY_CLAM_AMT ,    // 선별급여공단
            ADED_VALU_TAX_AMT ,    // 부가세
            OUPR_GRNT_NO      ,    // 원외처방교부번호
            DLVR_DEPT_CD      ,    // !전달부서
            CLCL_DVCD         ,    // !코드구분
            CLUS_DVCD         ,    // !항
            SBIT_DVCD         ,    // !목
            MDCR_DD           ,    // !처방일자
            PRSC_SQNO         ,    // !처방일련번호
        }

        public string m_PayYn = String.Empty;
        public string m_InsnTycd = String.Empty;
        public string m_AsstTycd = String.Empty;
        public string m_UschAplyCd = String.Empty;
        public int m_RcptSqno = 0;

        public string m_OuprYn = "N";   //원외처방전발생여부
        public string m_FrtmOuprYn = "N";   //기원외처방전발생여부
        public string m_OuprGrntNo = "NO";
        public string m_InMedYn = String.Empty; // 미수납 원내약처방 존재 여부

        private DataTable m_DtPAORECTP = new DataTable();

        private clsOutReceiptBreakDown m_OutRecBD = new clsOutReceiptBreakDown();

        private string m_PID = string.Empty;
        private string m_PtCmhsNo = string.Empty;
        private string m_MdcrDd = string.Empty;

        private FarPoint.Win.LineBorder m_Border = new FarPoint.Win.LineBorder(System.Drawing.Color.Gray, 1, false, true, false, false);

        #endregion Define : Member

        #region Define : Member Property
        public clsOutReceiptBreakDown OutRecBD
        {
            get { return m_OutRecBD; }
            set { m_OutRecBD = value; }
        }
        #endregion Define : Member Property

        #region Construction
        public ucOutReceiptBD()
        {
            InitializeComponent();
        }
        #endregion

        #region Screen Load
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode)
                return;

            InitializeSpread();
            InitializeEvent();
            InitializeSpreadCombo();
        }
        #endregion

        #region Method : Initialize

        private void InitializeSpreadCombo()
        {
            // 예약구분코드
            sprPAOPATRT.SetComboItems("APNT_PATH_DVCD", clsPACommon.GetDtBICDINDT("APNT_PATH_DVCD", "N", DateTime.Now.ToString("yyyyMMdd")), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            // 진료과목코드
            sprPAOPATRT.SetComboItems("MDCR_DEPT_CD", clsPACommon.GetDtCbo("DEPT_CD", "1", DateTime.Now.ToString("yyyyMMdd")), "DEPT_CD", "DEPT_HNM");
            // 진료의사
            sprPAOPATRT.SetComboItems("MDCR_DR_CD", DoctorList.GetDataList(), "USER_CD", "USER_NM");
            // 초재구분코드
            sprPAOPATRT.SetComboItems("FRVS_RVST_DVCD", clsPACommon.GetDtBICDINDT("FRVS_RVST_DVCD", "N", DateTime.Now.ToString("yyyyMMdd")), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            // 보험유형코드
            sprPAOPATRT.SetComboItems("INSN_TYCD", clsPACommon.GetDtBICDINDT("INSN_TYCD", "N", DateTime.Now.ToString("yyyyMMdd")), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            // 보조유형코드
            sprPAOPATRT.SetComboItems("ASST_TYCD", clsPACommon.GetDtBICDINDT("ASST_TYCD", "N", DateTime.Now.ToString("yyyyMMdd")), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            // 진찰료산정구분코드
            sprPAOPATRT.SetComboItems("MCCH_CMPT_DVCD", clsPACommon.GetDtBICDINDT("MCCH_CMPT_DVCD", "N", DateTime.Now.ToString("yyyyMMdd")), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            // 내원구분코드
            sprPAOPATRT.SetComboItems("CMHS_DVCD", clsPACommon.GetDtBICDINDT("CMHS_DVCD", "N", DateTime.Now.ToString("yyyyMMdd")), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");

            // 예약경로구분코드
            sprPAOPATRT.SetComboItems("APNT_PATH_DVCD", OverallCodeList.GetDataList("APNT_PATH_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");

            // 급비구분코드
            sprPAORECTP.SetComboItems("PAY_NOPY_DVCD", OverallCodeList.GetDataList("PAY_NOPY_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            sprPAORECBD.SetComboItems("PAY_NOPY_DVCD", OverallCodeList.GetDataList("PAY_NOPY_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");

            // 진료상태구분코드
            sprPAOPATRT.SetComboItems("PT_MDCR_STAT_DVCD", OverallCodeList.GetDataList("PT_MDCR_STAT_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            // 수납자ID
            sprPAOPATRT.SetComboItems("RGSTR_ID", UserList.GetDataList(), "USER_CD", "USER_NM");
        }

        private void InitializeSpread()
        {
            ClearProfitSpread();

            // 변경 Flag
            sprPAORECBD.ActiveSheet.Columns[1].Width = 8.0f;
            sprPAORECTP.ActiveSheet.Columns[1].Width = 8.0f;

            sprPAOBILBD.ActiveSheet.RowHeader.Visible = false;

            sprPAOPRATP.ActiveSheet.Rows[-1].Height = 24;
        }
        private void InitializeEvent()
        {
            tabOutReceipt.SelectedTabChanged += tabOutReceipt_SelectedTabChanged;

            sprPAOPRATP.CellClick += sprProfit_CellClick;

            sprPAOPATRT.CellDoubleClick += sprReg_CellDoubleClick;

            sprPAORECTP.TextTipFetch += Prsc_TextTipFetch;
            sprORORDRRT.TextTipFetch += Prsc_TextTipFetch;
            sprPAORECBD.TextTipFetch += Prsc_TextTipFetch;
        }

        #endregion Method : Initialize

        #region Method : Public Method

        #region Method : SelectData Method

        public void Clear()
        {
            m_OuprYn = "N";   // 원외처방전발생여부
            m_OuprGrntNo = "NO";  // 원외처방번호
            m_FrtmOuprYn = "N";   // 기발행원외처방여부

            m_PayYn = string.Empty;
            m_InsnTycd = string.Empty;
            m_AsstTycd = string.Empty;
            m_UschAplyCd = string.Empty;
            m_RcptSqno = 0;

            sprPAOBILBD.ActiveSheet.Rows.Count = 0;
            sprPAOPRATP.ActiveSheet.Rows.Count = 0;
            sprORORDRRT.ActiveSheet.Rows.Count = 0;
            sprPAORECTP.ActiveSheet.Rows.Count = 0;
            sprPAOPATRT.ActiveSheet.Rows.Count = 0;
            sprPAORECBD.ActiveSheet.Rows.Count = 0;

            tabOutReceipt.Tabs[1].Selected = true;
        }

        public bool SelectORORDRRT(string pid, int ptcmhsno)
        {
            try
            {
                string vistplcecd = String.Empty;
                string vistplcenm = String.Empty;
                string qtyzeroyn = String.Empty;
                string tbrcsuptprscyn = String.Empty;
                string tbrcsuptprsc = String.Empty;
                string hpvsameilns = String.Empty;
                string hpvsameilnsyn = String.Empty;
                string hpvothrilns = String.Empty;
                string hpvothrilnsyn = String.Empty;

                OutRecBD.DtPrsc.Clear();
                sprORORDRRT.Clear();
                m_FrtmOuprYn = string.Empty;

                PrscEventArgs prscargs = new PrscEventArgs();
                DataRow placerow = null;
                prscargs.Dt.Columns.Add(new DataColumn("VIST_PLCE_CD", typeof(string)));
                prscargs.Dt.Columns.Add(new DataColumn("VIST_PLCE_NM", typeof(string)));
                prscargs.Dt.Columns.Add(new DataColumn("RCPT_YN", typeof(string)));

                if (OutRecBD.GetORORDRRT(pid, ptcmhsno))
                {
                    if (OutRecBD.DtPrsc.Rows.Count > 0)
                    {
                        sprORORDRRT.FillDataTag(OutRecBD.DtPrsc);

                        SetSpreadPrsc();

                        tbrcsuptprsc = DBService.ExecuteScalar(SqlPack.Function.SelectFN_AD_READ_ADCONFDT(), "%"
                                                                                                           , "TBRC_SUPT_TRGT_PRSC"
                                                                                                           , "TBRC_SUPT_TRGT_PRSC"
                                                                                                           , DateTimeService.NowDateNoneSeperatorString()).ToString();

                        hpvsameilns = DBService.ExecuteScalar(SqlPack.Function.SelectFN_AD_READ_ADCONFDT(), "%"
                                                                                                          , "HPV_SAME_ILNS_PRSC"
                                                                                                          , "HPV_SAME_ILNS_PRSC"
                                                                                                          , DateTimeService.NowDateNoneSeperatorString()).ToString();

                        hpvothrilns = DBService.ExecuteScalar(SqlPack.Function.SelectFN_AD_READ_ADCONFDT(), "%"
                                                                                                          , "HPV_OTHR_ILNS_PRSC"
                                                                                                          , "HPV_OTHR_ILNS_PRSC"
                                                                                                          , DateTimeService.NowDateNoneSeperatorString()).ToString();
                        prscargs.AllDcPrscDvcd = "D";

                        //방문할 곳을 읽는다.
                        foreach (DataRow row in OutRecBD.DtPrsc.Select("PRSC_CD LIKE  '%'", "VIST_PLCE_CD ASC, PRV_ACTG_YN ASC, PRSC_STOP_DVCD ASC, RCPT_YN DESC"))
                        {

                            if (row["ONTM_QTY"].ToString() == "0" || row["APLY_ONTM_QTY"] == "0")
                                prscargs.QtyZeroYn = "Y";

                            if (row["PRSC_CD"].ToString().Equals(tbrcsuptprsc))
                                prscargs.TbrcSuptTrgtYn = "Y";

                            //HPV지원대상처방여부 주상병등록체크
                            if (row["PRSC_CD"].ToString().Equals(hpvsameilnsyn) && row["DC_PRSC_DVCD"].ToString().Equals("A"))
                                prscargs.HpvSameIlnsYn = "Y";

                            //HPV지원대상처방여부 동일과타상병등록
                            if (row["PRSC_CD"].ToString().Equals(hpvothrilnsyn) && row["DC_PRSC_DVCD"].ToString().Equals("A"))
                                prscargs.HpvOthrIlnsYn = "Y";

                            if (row["DC_PRSC_DVCD"].ToString().Equals("A"))
                                prscargs.AllDcPrscDvcd = "A";

                            // 급여처방이 존재 여부 -> 상병이 없으면 수납을 할 수 없다.
                            if (row["PNPY_DVCD"].ToString().Equals("1"))
                                m_PayYn = "Y";

                            // 미수납 원외처방이 존재하는지 체크한다.
                            if (row["EXCP_RESN_CD"].ToString().Equals("NO") && row["DLVR_DEPT_CD"].ToString().Equals("PMR") && row["OUPR_GRNT_NO"].ToString().Equals("NO") && row["RCPT_YN"].ToString().Equals("N"))
                            {
                                m_OuprYn = "Y";
                            }

                            // 미수납 원내약처방이 존재하는지 체크한다. PRSC_LCLS_CD
                            if (!row["EXCP_RESN_CD"].ToString().Equals("NO") && row["DLVR_DEPT_CD"].ToString().Equals("PMR") &&
                                (row["PRSC_LCLS_CD"].ToString().Equals("20") || row["PRSC_LCLS_CD"].ToString().Equals("30")) &&
                                (row["DC_PRSC_DVCD"].ToString().Equals("A") || row["DC_PRSC_DVCD"].ToString().Equals("D")) && row["RCPT_YN"].ToString().Equals("N"))
                            {
                                m_InMedYn = "Y";
                            }

                            // 원외처방전이 발행되었는지 체크한다.
                            if (!row["OUPR_GRNT_NO"].ToString().Equals("NO"))
                            {
                                m_FrtmOuprYn = "Y";
                                m_OuprGrntNo = row["OUPR_GRNT_NO"].ToString();
                            }

                            if (string.IsNullOrWhiteSpace(row["VIST_PLCE_CD"].ToString()) || row["VIST_PLCE_CD"].ToString() == "*" || row["VIST_PLCE_CD"].ToString() == "00")
                                continue;
                            if (row["DLVR_DEPT_CD"].ToString() == "PMR" && row["EXCP_RESN_CD"].ToString() == "NO")
                                continue;
                            if (row["PRV_ACTG_YN"].ToString() == "Y" || row["PRSC_STOP_DVCD"].ToString() == "Y" || row["RCPT_YN"].ToString() == "Y")
                                continue;

                            if (!row["VIST_PLCE_CD"].ToString().Equals(vistplcecd))
                            {
                                vistplcenm = DBService.ExecuteScalar(SQL.PA.Sql.SelectVisitPlace(), row["VIST_PLCE_CD"].ToString(), DateTimeService.NowDateNoneSeperatorString()).ToString();

                                placerow = prscargs.Dt.NewRow();
                                placerow["VIST_PLCE_CD"] = row["VIST_PLCE_CD"].ToString();
                                placerow["VIST_PLCE_NM"] = vistplcenm;
                                placerow["RCPT_YN"] = row["RCPT_YN"].ToString();
                                prscargs.Dt.Rows.Add(placerow);

                            }

                            vistplcecd = row["VIST_PLCE_CD"].ToString();
                        }

                        OnPrscRetrieved(prscargs);
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[DisplayPrscBD]오류내용 : " + ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /// <summary>
        /// 외래접수이력을 표시한다.
        /// </summary>
        /// <param name="pid"></param>
        public void SelectPAOPATRT(string pid)
        {
            try
            {
                sprPAOPATRT.Clear();
                DataTable dt = new DataTable();

                if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOPATRT(), ref dt, "PID"
                                                                                  , pid
                                                                                  , "0"))
                {
                    if (dt.Rows.Count > 0)
                    {

                        dt.Columns["PRSC_YN"].ReadOnly = false;
                        dt.Columns["RCPT_YN"].ReadOnly = false;

                        if (dt.Rows.Count > 0)
                        {
                            int rowcnt = 0;
                            int prsc_cnt = 0;
                            int rcpt_cnt = 0;
                            foreach (DataRow row in dt.Rows)
                            {
                                rowcnt++;

                                int.TryParse(row["PRSC_CNT"].ToString(), out prsc_cnt);
                                int.TryParse(row["RCPT_CNT"].ToString(), out rcpt_cnt);

                                if (prsc_cnt >= 1)
                                {
                                    row["PRSC_YN"] = "Y";
                                }
                                else
                                {
                                    row["PRSC_YN"] = "N";
                                }

                                if (prsc_cnt.Equals(rcpt_cnt))
                                {
                                    if (rcpt_cnt > 0)
                                        row["RCPT_YN"] = "Y";
                                    else
                                        row["RCPT_YN"] = "N";
                                }
                                else
                                {
                                    row["RCPT_YN"] = "N";
                                }

                            }

                            sprPAOPATRT.FillDataTag(dt);

                            SetSpreadRegColor();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[SetRegistrationListToSpr]오류내용 : " + ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        /// <summary>
        ///수납계산처방발생내역을 보여준다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        public void SelectPAORECTP(string pid, int ptcmhsno)
        {
            try
            {
                int eacount = 0;
                int drgcnt = 0;

                m_DtPAORECTP.Reset();

                sprPAORECTP.ActiveSheet.Rows.Count = 0;
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAORECTP(), ref m_DtPAORECTP, pid, ptcmhsno.ToString()))
                    throw new Exception("수납계산 처방발생내역 조회 중 에러가 발생했습니다.");

                sprPAORECTP.FillDataTag(m_DtPAORECTP);

                if (m_DtPAORECTP.Rows.Count.Equals(0))
                    return;

                string temp = string.Empty;

                for (int i = 0; i < m_DtPAORECTP.Rows.Count; i++)
                {
                    this.SetColorPAORECTPBD(true, sprPAORECTP, m_DtPAORECTP, i);

                    // +++++++++++++++++++++++++++++++++++++++++++++++++++
                    // Validation
                    // +++++++++++++++++++++++++++++++++++++++++++++++++++

                    // 의료급여 보험적용환자이고 본인부담적용코드가 M으로 시작하지 않는 경우
                    if (m_InsnTycd.Substring(0, 1) == "2" && m_AsstTycd != "99" && StringService.IsNvl(m_UschAplyCd, "NO").Substring(0, 1) != "M")
                    {
                        if (m_DtPAORECTP.Rows[i]["CLCL_DVCD"].ToString() == "3" && m_DtPAORECTP.Rows[i]["EXCP_RESN_CD"].ToString() == "NO" && 
                            (m_DtPAORECTP.Rows[i]["CLUS_DVCD"].ToString() == "03" || m_DtPAORECTP.Rows[i]["SBIT_DVCD"].ToString() == "04") && 
                            m_DtPAORECTP.Rows[i]["MEFE_DVCD"].ToString() == "3" && int.Parse(m_DtPAORECTP.Rows[i]["CLCL_AMT"].ToString()) == 0)
                        {
                            if (DBService.ExecuteInteger(SQL.PA.Sql.SelectPAPSDSMA_Count2(), pid, "7", m_DtPAORECTP.Rows[i]["MDCR_DD"].ToString()) > 0)
                            {
                                string message = string.Empty;
                                message += "원외처방에 대해 급여자격이 제한된 환자입니다.\r\n\r\n";
                                message += "원외처방 발행시 전액본인부담으로 발행됩니다.\r\n\r\n";
                                message += "급여 원외처방은 본인100%로 변경하고 수납하세요.";

                                LxMessage.ShowError(message);
                            }
                        }
                    }

                    if (m_InsnTycd.Equals("11") && m_AsstTycd.Equals("00"))
                    {
                        if ((m_DtPAORECTP.Rows[i]["CLUS_DVCD"].ToString().Equals("08") || m_DtPAORECTP.Rows[i]["SBIT_DVCD"].ToString().Equals("T")) && m_DtPAORECTP.Rows[i]["CMPT_DLWT_DVCD_4"].ToString().Equals("4"))
                        {
                            LxMessage.Show("장루요루 장애대상 및 장애 기간 확인이 필요합니다.", "확인");
                        }
                    }

                    if (m_DtPAORECTP.Rows[i]["MEFE_CD"].ToString().Equals("EA001") || m_DtPAORECTP.Rows[i]["MEFE_CD"].ToString().Equals("EA002") ||
                        m_DtPAORECTP.Rows[i]["MEFE_CD"].ToString().Equals("EA003") || m_DtPAORECTP.Rows[i]["MEFE_CD"].ToString().Equals("EA004"))
                    {
                        eacount++;
                    }

                    if (m_DtPAORECTP.Rows[i]["MEFE_CD"].ToString().Equals("DRG01"))
                    {
                        drgcnt++;
                    }
                }

                if (eacount >= 2)
                {
                    //LxMessage.Show("동일 진정내시경 환자관리료가 2번이상 발생되었습니다. \r\n" + Environment.NewLine +
                    //                "진료과에 확인후 수납 하세요. \r\n " + Environment.NewLine +
                    //                "진정내시경 환자관리료는 EA001, EA002, EA003, EA004 이고\r\n" + Environment.NewLine +
                    //                "1일 1회 산정가능합니다.");
                }

                if (drgcnt > 0)
                {
                    // DRG정액수가가 있으면 DRG수가여부 = "Y" 을 전달한다. 외래DRG생성여부 확인용.
                    this.OnNotSave?.Invoke("DRGMEFEYN", "Y");
                }
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        /// <summary>
        /// 이전수납처방내역을 보여준다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        public void SelectPAORECBD(string pid, int ptcmhsno)
        {
            try
            {
                sprPAORECBD.ActiveSheet.Rows.Count = 0;

                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectBeforePAORECBD(), ref dt, pid, ptcmhsno.ToString()))
                    throw new Exception("이전 수납 내역을 조회하는 중 에러가 발생했습니다.");

                sprPAORECBD.FillDataTag(dt);

                if (dt.Rows.Count.Equals(0))
                    return;

                for (int i = 0; i < dt.Rows.Count; i++)
                    this.SetColorPAORECTPBD(false, sprPAORECBD, dt, i);
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        /// <summary>
        /// 외래영수내역 조회
        /// </summary>
        public void SelectPAOBILBD(string pid)
        {
            try
            {
                sprPAOBILBD.ActiveSheet.Rows.Count = 0;

                // 조회기간설정
                int days = ConfigService.GetConfigValueInt("PA", "RECEIPT", "PERIOD", 365);
                string fromDd = DateTime.Now.AddDays(days * -1).ToString("yyyyMMdd");
                string toDd = DateTime.Now.ToString("yyyyMMdd");

                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.GetPAOBILBD(), ref dt, pid, fromDd, toDd, "%", "%"))
                    throw new Exception("외래영수내역 조회 중 에러가 발생했습니다.");

                sprPAOBILBD.FillDataTag(dt);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[SelectBillHistory] 오류내용 : " + ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        /// <summary>
        /// 외래수익코드별집계내역.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        public void SelectPAOPRATP(string pid, int ptcmhsno)
        {
            try
            {
                m_PID = pid;
                m_PtCmhsNo = ptcmhsno.ToString();
                m_MdcrDd = DBService.ExecuteScalar(string.Format("SELECT MDCR_DD FROM PAOPATRT WHERE PID = '{0}' AND PT_CMHS_NO = {1} AND ROW_STAT_DVCD = 'A' ", m_PID, m_PtCmhsNo)).ToString();

                ClearProfitSpread();
                int i = 0;
                int rowcount = sprPAOPRATP.ActiveSheet.RowCount;

                double payamt = 0; // 요양급여총액
                double insn100amt = 0; // 보험100금액
                double nopyamt = 0; // 비급여
                double payuschamt = 0; // 급여본인부담
                double payclamamt = 0; // 급여공단부담
                double scnguschamt = 0; // 선별급여본인
                double scngclamamt = 0; // 선별급여청구

                double totalpayamt = 0; // 요양급여총액 합계
                double totalinsn100amt = 0; // 보험100금액 합계
                double totalnopyamt = 0; // 비급여       합계
                double totalpayuschamt = 0; // 급여본인부담 합계
                double totalpayclamamt = 0; // 급여공단부담 합계
                double totalscnguschamt = 0; // 선별급여본인 합계
                double totalscngclamamt = 0; // 선별급여청구 합계

                DataTable dt = new DataTable();

                if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOPRATP_Profit(), ref dt, pid
                                                                                          , ptcmhsno.ToString()))
                {
                    if (dt.Rows.Count > 0)
                    {
                        string billLctn = "";
                        foreach (DataRow row in dt.Rows)
                        {
                            billLctn = row["BILL_LCTN"].ToString();
                            if (billLctn.Equals("24") || billLctn.Equals("25"))
                                billLctn = "2";

                            i = clsPACommon.FindRowOfBillLctn(sprPAOPRATP, billLctn, rowcount);

                            if (i < 0)
                                continue;

                            double.TryParse(row["PAY_AMT"].ToString(), out payamt);             // 급여본인 + 급여청구 + 선별급여본인 + 선별급여청구
                            double.TryParse(row["INSN_100_AMT"].ToString(), out insn100amt);    // 전액본인부담(보험100%)
                            double.TryParse(row["NOPY_AMT"].ToString(), out nopyamt);           // 비급여
                            double.TryParse(row["PAY_USCH_AMT"].ToString(), out payuschamt);    // 급여본인
                            double.TryParse(row["PAY_CLAM_AMT"].ToString(), out payclamamt);    // 급여청구
                            double.TryParse(row["SCNG_USCH_AMT"].ToString(), out scnguschamt);  // 선별본인
                            double.TryParse(row["SCNG_CLAM_AMT"].ToString(), out scngclamamt);  // 선별청구

                            sprPAOPRATP.SetText(i, "PAY_AMT", string.Format("{0:#,###}", payamt));                // 요양급여
                            sprPAOPRATP.SetText(i, "INSN_100_AMT", string.Format("{0:#,###}", insn100amt));       // 전액본인부담(보험100%)
                            sprPAOPRATP.SetText(i, "NOPY_AMT", string.Format("{0:#,###}", nopyamt));              // 비급여
                            sprPAOPRATP.SetText(i, "PAY_USCH_AMT", string.Format("{0:#,###}", payuschamt));       // 급여본인
                            sprPAOPRATP.SetText(i, "PAY_CLAM_AMT", string.Format("{0:#,###}", payclamamt));       // 급여청구
                            sprPAOPRATP.SetText(i, "SCNG_USCH_AMT", string.Format("{0:#,###}", scnguschamt));     // 선별본인
                            sprPAOPRATP.SetText(i, "SCNG_CLAM_AMT", string.Format("{0:#,###}", scngclamamt));     // 선별청구

                            totalpayamt += Math.Round(payamt, 0);
                            totalinsn100amt += Math.Round(insn100amt, 0);
                            totalnopyamt += Math.Round(nopyamt, 0);
                            totalpayuschamt += Math.Round(payuschamt, 0);
                            totalpayclamamt += Math.Round(payclamamt, 0);
                            totalscnguschamt += Math.Round(scnguschamt, 0);
                            totalscngclamamt += Math.Round(scngclamamt, 0);
                        }

                        sprPAOPRATP.InsertRow(rowcount);
                        FarPoint.Win.LineBorder bordersum = new FarPoint.Win.LineBorder(System.Drawing.Color.Black, 2, false, true, false, false);
                        sprPAOPRATP.ActiveSheet.Rows[rowcount].Border = bordersum;
                        System.Drawing.Font font = new System.Drawing.Font("맑은 고딕", 10, FontStyle.Bold);

                        sprPAOPRATP.Sheets[0].Cells[rowcount, 0, rowcount, sprPAOPRATP.Sheets[0].ColumnCount - 1].Font = font;
                        sprPAOPRATP.SetText(rowcount, "LWRN_OVRL_CDNM", "합 계");
                        sprPAOPRATP.SetText(rowcount, "PAY_AMT", string.Format("{0:#,###}", totalpayamt));
                        sprPAOPRATP.SetText(rowcount, "INSN_100_AMT", string.Format("{0:#,###}", totalinsn100amt));
                        sprPAOPRATP.SetText(rowcount, "NOPY_AMT", string.Format("{0:#,###}", totalnopyamt));
                        //sprProfit.SetText(rowcount, "INSN_100_AMT", string.Format("{0:#,###}", totalinsn100amt));
                        sprPAOPRATP.SetText(rowcount, "PAY_USCH_AMT", string.Format("{0:#,###}", totalpayuschamt));
                        sprPAOPRATP.SetText(rowcount, "PAY_CLAM_AMT", string.Format("{0:#,###}", totalpayclamamt));
                        sprPAOPRATP.SetText(rowcount, "SCNG_USCH_AMT", string.Format("{0:#,###}", totalscnguschamt));
                        sprPAOPRATP.SetText(rowcount, "SCNG_CLAM_AMT", string.Format("{0:#,###}", totalscngclamamt));

                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[SetProfitAmtListToSpr]오류내용 : " + ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public bool GetPid(ref string pid, ref string ptcmhsno, ref string mdcrdd)
        {
            if (tabOutReceipt.SelectedTab.Index == 5)
            {

                if (sprPAOPATRT.ActiveSheet.Rows.Count < 1) return false;

                int activerow = sprPAOPATRT.ActiveSheet.ActiveRowIndex;

                pid = sprPAOPATRT.GetValue(activerow, "PID").ToString();
                ptcmhsno = sprPAOPATRT.GetValue(activerow, "PT_CMHS_NO").ToString();
                mdcrdd = sprPAOPATRT.GetValue(activerow, "MDCR_DD").ToString();
                return true;
            }
            return false;
        }
        #endregion Method : SelectData Method

        #region Method : SaveData

        /// <summary>
        /// 처방등록 UPDATE : 수납여부, 원외처방교부번호, 원무계산적용여부, 원무계산적용일시, 원무계산적용자ID
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public int UpdateRcptYnOfOrOrdrRt(ref string msg)
        {
            string ouprgrntno = "NO";
            DataTable paorectp = sprPAORECTP.ToDataTable();

            foreach (DataRow row in OutRecBD.DtPrsc.Rows)
            {
                if (row["PRSC_STOP_DVCD"].ToString().Equals("Y"))
                    continue;

                if (row["RCPT_YN"].ToString().Equals("Y"))
                    continue;

                ouprgrntno = row["OUPR_GRNT_NO"].ToString();

                if (ouprgrntno.Length < 13)
                    ouprgrntno = "NO";

                // 수납되지 않은 약,주사 중에 원외처방번호가 없으면 수납여부를 N인 채로 둔다.
                if ((row["PRSC_LCLS_CD"].ToString().Equals("20") || row["PRSC_LCLS_CD"].ToString().Equals("30")) &&
                    row["EXCP_RESN_CD"].ToString().Equals("NO") &&
                    row["DLVR_DEPT_CD"].ToString().Equals("PMR") &&
                    row["OUPR_GRNT_NO"].ToString().Equals("NO") &&
                    row["RCPT_YN"].ToString().Equals("N"))
                {
                    // 2019-01-18 PAORECTP 에서 CLUS_DVCD 가 '03', '04' 인 경우에만 원외처방전을 출력한다.
                    paorectp.DefaultView.RowFilter = "";
                    paorectp.DefaultView.RowFilter = string.Format(" MDCR_DD = '{0}' AND PRSC_SQNO = {1} ", row["MDCR_DD"].ToString(), row["PRSC_SQNO"].ToString());

                    // 처방이 변경된 경우는 원외처방전 수납여부를 N으로 한다.
                    if (paorectp.DefaultView.ToTable().Rows.Count > 0)
                    {
                        string clusdvcd = paorectp.DefaultView.ToTable().Rows[0]["CLUS_DVCD"].ToString();

                        if (clusdvcd.Equals("03") || clusdvcd.Equals("04"))
                            continue;
                    }
                }

                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateRcptYnOfOrOrdrRt()
                                             , row["PID"].ToString()
                                             , row["PT_CMHS_NO"].ToString()
                                             , row["MDCR_DD"].ToString()
                                             , row["PRSC_SQNO"].ToString()
                                             , ouprgrntno
                                             , DateTimeService.NowDateTimeNoneSeperatorString()
                                             , DOPack.UserInfo.USER_CD))
                {
                    msg = "  처방 [" + row["PRSC_CD"].ToString() + "] 변경 중 오류가 발생했습니다. \r\n Error Message : " + DBService.ErrorMessage;
                    return -1;
                }

                // 처방의 그룹여부 확인
                if (DBService.ExecuteScalar(SQL.PA.Sql.SelectGrpYnOfBiMfcdMa()
                                          , row["PRSC_CD"].ToString()
                                          , row["MDCR_DD"].ToString()).Equals("G"))
                {

                    if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateRcptYnOfOrOrdgRt()
                                                , row["PID"].ToString()
                                                , row["PT_CMHS_NO"].ToString()
                                                , row["MDCR_DD"].ToString()
                                                , row["PRSC_SQNO"].ToString()))
                    {
                        msg = "  묶음처방변경 중 오류가 발생했습니다. \r\n Error Message : " + DBService.ErrorMessage;
                        return -2;
                    }
                }
            }
            return 1;
        }

        /// <summary>
        /// 수납처방을 저장한다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>

        public bool InsertPaOrecBd(ref string msg)
        {
            //m_OutRecBD.NEW_RCPT_RQNO = m_RcptSqno;
            return m_OutRecBD.InsertPaOrecBd(m_DtPAORECTP, ref msg);
        }

        /// <summary>
        /// 원외처방교부번호를 생성하고 외래처방 및 외래수납처방에 원외처방교부번호를 UPDATE
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public int CreateOuprGrntNo(string mdcrdd, ref string msg)
        {
            string newouprgrntnoyn = "N";
            string ouprgrntno = String.Empty;
            if (m_OuprYn == "Y")
            {
                if (m_FrtmOuprYn == "Y")
                {
                    if (m_InsnTycd.Substring(0, 1).Equals("2") && !m_AsstTycd.Equals("99"))
                    {
                        newouprgrntnoyn = "N";
                    }
                    else
                    {
                        if (LxMessage.ShowQuestion(string.Format("기발행된 원외처방전이 존재합니다.\r\n이전 원외처방교부번호({0})를\r\n사용하시겠습니까?\r\n\r\n[    예    ] 이전 원외처방교부번호 사용\r\n[ 아니오 ] 새번호 발행", m_OuprGrntNo)).Equals(DialogResult.No))
                        {
                            newouprgrntnoyn = "Y";
                        }
                    }
                }
                else
                {
                    newouprgrntnoyn = "Y";
                }
            }

            if (newouprgrntnoyn.Equals("Y"))
            {
                // 원외처방교부번호를 생성한다.
                if (!SqlPack.Procedure.PR_PA_READ_NEWOUPRGRNTNO("O", mdcrdd.Substring(0, 4), mdcrdd, ref ouprgrntno, ref msg))
                {
                    DBService.RollbackTransaction();
                    return -1;
                }
                m_OuprGrntNo = mdcrdd + ouprgrntno;    // 원외처방전번호 yyyyMMdd + "00001"
            }

            if (!m_OuprGrntNo.Equals("NO") && m_OuprYn.Equals("Y"))
            {
                if (SetOuprGrntNoOfOrOrderRt())
                {
                    SetOuprGrntNoOfPaOrecBd();
                }
            }
            return 1;
        }

        public bool InsertORSQTPIF(string pid, string currentdate, ref string dlwtuniqno, ref string msg)
        {
            try
            {
                dlwtuniqno = ORBizCommon.GetDlwtUniqNo(pid, currentdate);

                int sqno = 0;

                foreach (DataRow row in OutRecBD.DtPrsc.Rows)
                {
                    if (row["RCPT_YN"].Equals("Y")) continue;

                    sqno++;

                    if (!ORBizCommon.InsertORSQTPIFSub(row["PID"].ToString(), row["PT_CMHS_NO"].ToString(), row["MDCR_DD"].ToString(), "OUTREC",
                                                         ref dlwtuniqno, sqno.ToString(), row["PRSC_SQNO"].ToString(), currentdate))
                    {
                        msg = "처방SEQTEMP용 저장 중 오류를 발생했습니다.\r\n " +
                              "Method :  [InsertORSQTPIFSub] \r\n " +
                              "오류 메시지 : " + DBService.ErrorMessage;
                        return false;
                    }

                }

            }
            catch (Exception ex)
            {
                msg = "처방SEQTEMP용 저장 중 오류를 발생했습니다.\r\n " +
                      "Method :  [InsertORSQTPIF] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }

            return true;
        }

        #endregion Method : SaveData
        /// <summary>
        /// 이미 조회된 처방과 수납저장시 조회된 처방을 비교하여 변경된 경우 메시지창을 띄워 알린다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="mdcrdd"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public int CheckOrderChange(string pid, int ptcmhsno, string mdcrdd, ref string msg)
        {
            string prsccd = String.Empty;
            double ontmqty = 0;
            int notm = 0;
            int nody = 0;
            string pnpydvcd = String.Empty;
            string excpresncd = String.Empty;
            string prvactgyn = String.Empty;
            string aomdmthdcd = String.Empty;
            string rcptyn = String.Empty;
            string delyn = String.Empty;
            int prscsqno = 0;

            DataTable dt = new DataTable();

            for (int i = 0; i < sprORORDRRT.ActiveSheet.RowCount; i++)
            {
                prscsqno = int.Parse(sprORORDRRT.GetValue(i, "PRSC_SQNO").ToString());
                prsccd = sprORORDRRT.GetValue(i, "PRSC_CD").ToString();
                ontmqty = Convert.ToDouble(sprORORDRRT.GetValue(i, "ONTM_QTY").ToString());
                notm = int.Parse(sprORORDRRT.GetValue(i, "NOTM").ToString());
                nody = int.Parse(sprORORDRRT.GetValue(i, "NODY").ToString());
                pnpydvcd = sprORORDRRT.GetValue(i, "PNPY_DVCD").ToString();
                excpresncd = sprORORDRRT.GetValue(i, "EXCP_RESN_CD").ToString();
                prvactgyn = sprORORDRRT.GetValue(i, "PRV_ACTG_YN").ToString();
                aomdmthdcd = sprORORDRRT.GetValue(i, "AOMD_MTHD_CD").ToString();
                rcptyn = StringService.IsNvl(sprORORDRRT.GetValue(i, "RCPT_YN").ToString(), "N");

                dt.Clear();
                if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectORORDRRTToComparePrsc(), ref dt, pid
                                                                                              , ptcmhsno.ToString()
                                                                                              , mdcrdd
                                                                                              , prscsqno.ToString()))
                {
                    if (dt.Rows.Count > 0)
                    {
                        DataRow row = dt.Rows[0];

                        if (row["DEL_YN"].ToString().Equals("D"))
                        {
                            msg = "삭제된 처방입니다. 다시 조회한 후 수납하세요.";
                            return -20;
                        }

                        if (row["DLVR_DEPT_CD"].ToString().Equals("PMR"))
                        {
                            if (excpresncd != "NO") excpresncd = "99";

                            if (!row["ONTM_QTY"].ToString().Equals(string.Format("{0:N4}", ontmqty)) || !row["NOTM"].ToString().Equals(notm.ToString()) ||
                                !row["NODY"].ToString().Equals(nody.ToString()) || !row["PNPY_DVCD"].ToString().Equals(pnpydvcd) ||
                                !row["EXCP_RESN_CD"].ToString().Equals(excpresncd) || !row["PRV_ACTG_YN"].ToString().Equals(prvactgyn) ||
                                !row["AOMD_MTHD_CD"].ToString().Equals(aomdmthdcd) || !row["RCPT_YN"].ToString().Equals(rcptyn))
                            {
                                msg = prsccd + " 코드의 처방이 변경되었습니다.";
                                return -21;
                            }
                        }
                        else
                        {
                            if (!row["ONTM_QTY"].ToString().Equals(string.Format("{0:N4}", ontmqty)) || !row["NOTM"].ToString().Equals(notm.ToString()) ||
                                !row["NODY"].ToString().Equals(nody.ToString()) || !row["PNPY_DVCD"].ToString().Equals(pnpydvcd))
                            {
                                msg = prsccd + " 코드의 처방이 변경되었습니다.";
                                return -22;
                            }
                        }

                    }
                }
                else
                {
                    msg = DBService.DBError.ErrorMessage;
                    return -10;
                }
            }
            return 1;
        }
        /// <summary>
        /// 원외처방전 교부번호의 중복 발행을 확인한다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="mdcrdd"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public int CheckIsSameOuprGrntNo(string pid, string mdcrdd, ref string msg)
        {
            if (m_OuprGrntNo.Equals("NO"))
                return 0;

            int count = 0;
            if (m_OuprYn.Equals("Y"))
            {
                count = DBService.ExecuteInteger(SQL.PA.Sql.SelectCountOfOuprGrntNo(), pid
                                                                                     , m_OuprGrntNo
                                                                                     , mdcrdd);
                if (count > 0)
                {
                    msg = "원외처방 교부번호가 중복 발행되었습니다. 처방전 번호 : " + m_OuprGrntNo + " \r\n 원외처방전 재발행에서 새로운 처방전을 발행하세요.";
                }
            }
            return count;
        }
        /// <summary>
        /// 원외처방 교부번호가 없는 원외처방을 확인한다
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public int CheckIsNoOuprGrntNo(string pid, int ptcmhsno, ref string msg)
        {
            DataTable orordrrtDt = new DataTable();
            string sqltext = string.Format(@"
SELECT *
  FROM ORORDRRT
 WHERE PID          = '{0}'
   AND PT_CMHS_NO   =  {1}
   AND OUPR_GRNT_NO = 'NO'
   AND EXCP_RESN_CD = 'NO'
   AND DLVR_DEPT_CD = 'PMR'
   AND PRSC_LCLS_CD IN ('20', '30')
   AND DEL_YN       = 'A'
   AND DC_PRSC_DVCD = 'A'
   AND PNPY_DVCD != '9'
  -- AND RCPT_YN      = 'Y' ", pid, ptcmhsno);

            DBService.ExecuteDataTable(sqltext, ref orordrrtDt);

            DataTable paorectp = sprPAORECTP.ToDataTable();

            int count = 0;

            for (int k = 0; k < orordrrtDt.Rows.Count; k++)
            {
                paorectp.DefaultView.RowFilter = "";
                paorectp.DefaultView.RowFilter = string.Format(" MDCR_DD = '{0}' AND PRSC_SQNO = {1} ", orordrrtDt.Rows[k]["MDCR_DD"].ToString(), orordrrtDt.Rows[k]["PRSC_SQNO"].ToString());

                if (paorectp.DefaultView.ToTable().Rows.Count > 0)
                {
                    string clusDvcd = paorectp.DefaultView.ToTable().Rows[0]["CLUS_DVCD"].ToString();
                    if (clusDvcd.Equals("03") || clusDvcd.Equals("04"))
                        count++;
                }
            }

            if (count > 0)
                msg = "원외처방 교부번호가 없는 원외처방이 " + count.ToString() + " 건 있습니다. 확인하세요.";

            return count;
        }
        #endregion Method : Public Method

        #region Method : Private Method

        private void ClearProfitSpread()
        {
            try
            {
                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectBICDINDT_BillLctn(), ref dt))
                    throw new Exception("수익코드 내역을 조회하는 중 에러가 발생했습니다.");

                sprPAOPRATP.FillDataTag(dt);
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        /// <summary>
        /// 원외처방교부번호를 환자의 처방내역에 입력한다.
        /// </summary>
        private bool SetOuprGrntNoOfOrOrderRt()
        {
            bool result = false;

            DataTable paorectp = sprPAORECTP.ToDataTable();

            OutRecBD.DtPrsc.Columns["OUPR_GRNT_NO"].ReadOnly = false;
            foreach (DataRow row in OutRecBD.DtPrsc.Rows)
            {
                if (row["RCPT_YN"].ToString().Equals("Y"))
                    continue;

                if (row["DLVR_DEPT_CD"].ToString().Equals("PMR"))
                {
                    if (row["EXCP_RESN_CD"].ToString().Equals("NO") && row["OUPR_GRNT_NO"].ToString().Equals("NO"))
                    {
                        // 2019-01-18 PAORECTP 에서 CLUS_DVCD 가 '03', '04' 인 경우에만 원외처방전을 출력한다.
                        paorectp.DefaultView.RowFilter = "";
                        paorectp.DefaultView.RowFilter = string.Format(" MDCR_DD = '{0}' AND PRSC_SQNO = {1} ", row["MDCR_DD"].ToString(), row["PRSC_SQNO"].ToString());

                        if (paorectp.DefaultView.ToTable().Rows.Count > 0)
                        {
                            string clusDvcd = paorectp.DefaultView.ToTable().Rows[0]["CLUS_DVCD"].ToString();
                            if (clusDvcd.Equals("03") || clusDvcd.Equals("04"))
                            {
                                row["OUPR_GRNT_NO"] = m_OuprGrntNo;
                                result = true;
                            }
                        }
                    }
                }
                else
                {
                    row["OUPR_GRNT_NO"] = "NO";
                }
            }

            return result;
        }

        private void SetOuprGrntNoOfPaOrecBd()
        {
            string ouprgrntno = "NO";

            m_DtPAORECTP.Columns["OUPR_GRNT_NO"].ReadOnly = false;

            // dtReceiptPrsc : PAORECBD : CLCL_DVCD == '3'  && EXCP_RESN_CD == 'NO' && CLUS_DVCD IN ('03', '04') && MEFE_DVCD IN ('3', '4') && CLCL_AMT == '0'
            foreach (DataRow row in m_DtPAORECTP.Rows)
            {
                ouprgrntno = "NO";
                if (row["CLCL_DVCD"].ToString().Equals("3") && row["EXCP_RESN_CD"].ToString().Equals("NO") &&
                      (row["CLUS_DVCD"].ToString().Equals("03") || row["CLUS_DVCD"].ToString().Equals("04")) &&
                      (row["MEFE_DVCD"].ToString().Equals("3") || row["MEFE_DVCD"].ToString().Equals("4") || row["MEFE_DVCD"].ToString().Equals("5")) && row["CLCL_AMT"].ToString().Equals("0"))
                {
                    foreach (DataRow prsc in OutRecBD.DtPrsc.Select("PRSC_CD = '" + row["MEFE_CD"].ToString() + "' AND DC_PRSC_DVCD = 'A' AND PRSC_SQNO = " + row["PRSC_SQNO"].ToString()))
                    {
                        ouprgrntno = prsc["OUPR_GRNT_NO"].ToString();
                    }
                }

                row["OUPR_GRNT_NO"] = ouprgrntno;
            }

        }

        /// <summary>
        /// 수납계산처방 반복 수익명 안보이게 셋팅
        /// </summary>
        private void SetSpreadRecPrsc()
        {
            for (int row = 0; row < sprPAORECTP.ActiveSheet.Rows.Count; row++)
            {
            }
        }

        private void SetSpreadRegColor()
        {
            for (int i = 0; i < sprPAOPATRT.ActiveSheet.RowCount; i++)
            {
                if (sprPAOPATRT.GetValue(i, "MDCR_DD").ToString().Replace("-", "").Equals(DateTimeService.NowDateNoneSeperatorString()))
                    sprPAOPATRT.ActiveSheet.Rows[i].ForeColor = Color.Blue;

                if (sprPAOPATRT.GetValue(i, "PT_MDCR_STAT_DVNM").Equals("입원"))
                {
                    sprPAOPATRT.GetCell(i, "PT_MDCR_STAT_DVNM").ForeColor = Color.FromArgb(15, 195, 110);
                    sprPAOPATRT.GetCell(i, "PT_MDCR_STAT_DVNM").Font = new Font("맑은 고딕", 9, FontStyle.Bold);
                }
                else if (sprPAOPATRT.GetValue(i, "PT_MDCR_STAT_DVNM").Equals("과취소") || sprPAOPATRT.GetValue(i, "PT_MDCR_STAT_DVNM").Equals("접수취소") ||
                         sprPAOPATRT.GetValue(i, "PT_MDCR_STAT_DVNM").Equals("예약취소"))
                {
                    sprPAOPATRT.GetCell(i, "PT_MDCR_STAT_DVNM").ForeColor = Color.Red;
                    sprPAOPATRT.GetCell(i, "PT_MDCR_STAT_DVNM").Font = new Font("맑은 고딕", 9, FontStyle.Bold);
                }
            }
        }
        /// <summary>
        /// 처방 스프레드 셋팅
        /// </summary>
        private void SetSpreadPrsc()
        {
            int startcol = 0;
            string msg = string.Empty;
            int cnt = 0;

            string dlvrDeptCd = "";
            string dcPrscDvcd = "";
            bool showMessage = false;

            int colRcpnNotYn = sprORORDRRT.GetTagToColumnIndex("RCPN_NOT_YN");
            for (int row = 0; row < sprORORDRRT.ActiveSheet.Rows.Count; row++)
            {
                CheckSpecialPASend(sprORORDRRT.GetText(row, "PRSC_CD"), sprORORDRRT.GetText(row, "MDCR_DD"), ref msg, ref cnt);

                // +++++++++++++++++++++++++++++++++++++++++++++++++++++++
                // DC되지 않았고, 지원부서가 없음 OR 약제과 가 아닌 경우
                dlvrDeptCd = sprORORDRRT.GetValue(row, "DLVR_DEPT_CD").ToString();
                dcPrscDvcd = sprORORDRRT.GetValue(row, "DC_PRSC_DVCD").ToString();

                if (StringService.IsNotNull(dcPrscDvcd) && dcPrscDvcd.Equals("A") &&
                    StringService.IsNotNull(dlvrDeptCd) && !dlvrDeptCd.Equals("ZZZZ") && !dlvrDeptCd.Equals("PMR") && !dlvrDeptCd.Equals("A307"))
                {
                    // 접수여부를 체크한다.
                    if (!sprORORDRRT.GetValue(row, "SUPT_DEPT_RCPN_YN").ToString().Equals("Y"))
                    {
                        sprORORDRRT.ActiveSheet.Cells[row, colRcpnNotYn].Text = "√";

                        if (!showMessage)
                        {
                            showMessage = true;

                            // 메시지는 한번만 보여준다.
                            LxMessage.ShowInformation("지원부서에서 접수되지 않은 처방이 있습니다.\r\n[수납계산상세정보]의 [처방내역]을 확인해 주세요.");
                        }
                    }
                }
                // +++++++++++++++++++++++++++++++++++++++++++++++++++++++

                if (row.Equals(0))
                {
                    // 미수납처방 파란색 설정
                    if (!sprORORDRRT.GetValue(row, "RCPT_YN").Equals("Y"))
                    {
                        sprORORDRRT.Sheets[0].Cells[row, 0, row, sprORORDRRT.Sheets[0].ColumnCount - 1].ForeColor = Color.Blue;
                    }

                    continue;
                }

                if (sprORORDRRT.GetValue(row, "PRSC_LCLS_CD").Equals(sprORORDRRT.GetValue(row - 1, "PRSC_LCLS_CD")))
                {
                    sprORORDRRT.ActiveSheet.Cells[row, 0].ForeColor = Color.Transparent;
                    startcol = 1;
                }
                else
                {
                    FarPoint.Win.LineBorder border = new FarPoint.Win.LineBorder(Color.Gray, 1, false, true, false, false);
                    sprORORDRRT.ActiveSheet.Rows[row].Border = border;
                    startcol = 0;
                }

                if (sprORORDRRT.GetValue(row, "PRSC_LCLS_CD").Equals(sprORORDRRT.GetValue(row - 1, "PRSC_LCLS_CD")) && sprORORDRRT.GetValue(row, "PRSC_MCLS_CD").Equals(sprORORDRRT.GetValue(row - 1, "PRSC_MCLS_CD")))
                {
                    sprORORDRRT.ActiveSheet.Cells[row, 1].ForeColor = Color.Transparent;
                }

                // 미수납처방 파란색 설정
                if (!sprORORDRRT.GetValue(row, "RCPT_YN").Equals("Y"))
                {
                    sprORORDRRT.Sheets[0].Cells[row, startcol, row, sprORORDRRT.Sheets[0].ColumnCount - 1].ForeColor = Color.Blue;
                }
            }

            if (!string.IsNullOrEmpty(msg))
                LxMessage.Show(msg + "(총 " + cnt.ToString() + " 건)", "처방내역확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// 처방내역에 지시형 오더가 있는지 체크하여 알려준다.
        /// </summary>
        /// <param name="prsc_cd"></param>
        /// <param name="mdcr_dd"></param>
        /// <param name="msg"></param>
        /// <param name="order_cnt"></param>        
        private void CheckSpecialPASend(string prsc_cd, string mdcr_dd, ref string msg, ref int order_cnt)
        {
            // 체크코드 확인
            int cnt = DBService.ExecuteInteger(SQL.Function.SelectFN_BI_READ_BISPORDTCNT(), "PARECEIPT", prsc_cd, mdcr_dd);

            if (DBService.HasError)
                throw new Exception("SQL.Function.SelectFN_BI_READ_BISPORDTCNT" + DBService.ErrorMessage + "[" + DBService.ErrorCode + "]");

            if (cnt > 0)
            {
                string msg_matr = DBService.ExecuteScalar(SQL.Function.SelectFN_BI_READ_BISPORDT()
                                                        , "PARECEIPT", prsc_cd, mdcr_dd, "CHEK_MSG_MATR").ToString();

                if (DBService.HasError)
                    throw new Exception("SQL.Function.SelectFN_BI_READ_BISPORDT" + DBService.ErrorMessage + "[" + DBService.ErrorCode + "]");

                //처음 한개만 보여주고, 총 건수로 몇개가 있는지 표시해준다.
                if (string.IsNullOrEmpty(msg))
                    msg += msg_matr;

                order_cnt++;
            }
        }

        private void SetColorPAORECTPBD(bool isRECTP, LxSpread spread, DataTable dt, int i)
        {
            // +++++++++++++++++++++++++++++++++++++++++++++++++++
            // 색깔 세팅
            // +++++++++++++++++++++++++++++++++++++++++++++++++++
            // 급비구분 (보험100:파랑 / 비급여:빨강 / 그 외:검정)
            string temp = dt.Rows[i]["PAY_NOPY_DVCD"].ToString();
            spread.ActiveSheet.Cells[i, (int)COL.PAY_NOPY_DVCD].ForeColor = temp.Equals("2") ? System.Drawing.Color.Blue :
                                                                            temp.Equals("4") ? System.Drawing.Color.Red  : System.Drawing.Color.Black;

            // 변경구분코드 (추가1:파랑 / 변경2:초록 / 삭제3:빨강)
            temp = dt.Rows[i]["ORIG_SQNO"].ToString();
            if (isRECTP)
            {
                // 현재 계산처방내역
                if (temp.Equals("1"))
                    spread.ActiveSheet.Cells[i, (int)COL.CHANGE_FLAG].BackColor = System.Drawing.Color.FromArgb(19, 130, 176);
                else if (temp.Equals("2"))
                    spread.ActiveSheet.Cells[i, (int)COL.CHANGE_FLAG].BackColor = System.Drawing.Color.FromArgb(94, 161, 82);
            }
            else
            {
                // 이전 계산처방내역
                if (temp.Equals("3"))
                    spread.ActiveSheet.Cells[i, (int)COL.CHANGE_FLAG].BackColor = System.Drawing.Color.FromArgb(193, 33, 71);
            }

            // 예외사유구분코드 (원내:빨강)
            if (dt.Rows[i]["EXCP_RESN_CD"].ToString().Equals("01"))
                spread.ActiveSheet.Cells[i, (int)COL.EXCP_RESN_CD].ForeColor = System.Drawing.Color.Red;

            // 원외처방 (교부번호가 NO이고 전달부서가 약국이고 재료대 (투약료/주사료):파랑)
            if (dt.Rows[i]["EXCP_RESN_CD"].ToString().Equals("NO") && dt.Rows[i]["DLVR_DEPT_CD"].ToString().Equals("PMR") &&
                dt.Rows[i]["CLCL_DVCD"].ToString().Equals("3") && (dt.Rows[i]["CLUS_DVCD"].ToString().Equals("03") || dt.Rows[i]["CLUS_DVCD"].ToString().Equals("04")))
            {
                spread.ActiveSheet.Rows[i].ForeColor = Color.Blue;
            }

            // 이하, 이전 행과 비교하여 색깔 세팅하기 때문에 첫번째행은 무시한다.
            if (i.Equals(0))
                return;

            // 수익코드
            if (dt.Rows[i]["PRFT_CDNM"].ToString().Equals(dt.Rows[i - 1]["PRFT_CDNM"].ToString()))
            {
                // 위 아래 수익코드가 같으면 아래 수익코드 글자색을 없애자.
                spread.ActiveSheet.Cells[i, (int)COL.PRFT_CDNM].ForeColor = System.Drawing.Color.Transparent;
            }
            else
            {
                // 위 아래 수익코드가 다르면 구분선을 두자.
                spread.ActiveSheet.Rows[i].Border = m_Border;
            }
        }

        #endregion Method : Private Method

        #region Event : Process Event

        private void tabOutReceipt_SelectedTabChanged(object sender, Infragistics.Win.UltraWinTabControl.SelectedTabChangedEventArgs e)
        {
            switch (e.Tab.Index)
            {
                case 0:
                    this.sprPAOPRATP.ActiveSheetIndex = 0;
                    break;
                case 1:
                    this.sprPAORECTP.ActiveSheetIndex = 1;
                    break;
                case 2:
                    this.sprORORDRRT.ActiveSheetIndex = 2;
                    break;
                case 3:
                    this.sprPAOBILBD.ActiveSheetIndex = 3;
                    break;
                case 4:
                    this.sprPAOPATRT.ActiveSheetIndex = 4;
                    break;
            }
        }

        private void sprProfit_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader) return;
            if (e.RowHeader) return;

            ((LxSpread)sender).MultiCellSelectRowBackColor(e.Row);

            if (e.Column != 0)
                return;

            if (string.IsNullOrWhiteSpace(m_PID) || string.IsNullOrWhiteSpace(m_PtCmhsNo) || string.IsNullOrWhiteSpace(m_MdcrDd))
                return;

            frmProfitReceiptPrscP pop = new frmProfitReceiptPrscP("O", m_PID, m_PtCmhsNo, m_MdcrDd, m_MdcrDd, sprPAOPRATP.GetValue(e.Row, "LWRN_OVRL_CD").ToString());
            pop.ShowDialog(this);
            pop.Dispose();
            pop = null;
        }

        private void sprReg_CellDoubleClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader) return;
            if (e.RowHeader) return;

            if (OnPatRegSelected != null)
            {
                OnPatRegSelected(sprPAOPATRT.GetValue(e.Row, "PID").ToString(), sprPAOPATRT.GetValue(e.Row, "PT_CMHS_NO").ToString(), sprPAOPATRT.GetValue(e.Row, "MDCR_DD").ToString());
            }
        }

        private void Prsc_TextTipFetch(object sender, FarPoint.Win.Spread.TextTipFetchEventArgs e)
        {
            string tag = ((LxSpread)sender).ActiveSheet.Columns.Get(e.Column).Tag.ToString();
            string mefe_cd = String.Empty;
            string mdcr_dd = String.Empty;
            string message = String.Empty;
            int row = 0;

            if (((LxSpread)sender).ActiveSheet.RowCount <= 0)
                return;

            row = e.Row;

            if (tag == "MEFE_CD" || tag == "PRSC_CD")
            {
                if (((LxSpread)sender).Name == "sprPrsc")
                    mefe_cd = ((LxSpread)sender).GetValue(row, "PRSC_CD").ToString();
                else
                    mefe_cd = ((LxSpread)sender).GetValue(row, "MEFE_CD").ToString();

                mdcr_dd = ((LxSpread)sender).GetValue(row, "MDCR_DD").ToString();

                message = DBService.ExecuteScalar(SQL.OR.Sql.SelectBIMFMSMA(), mefe_cd, mdcr_dd).ToString();

                if (!String.IsNullOrWhiteSpace(message))
                {
                    e.ShowTip = true;
                    e.View.TextTipAppearance.Font = new Font("맑은 고딕", 10f, FontStyle.Bold);
                    e.View.TextTipAppearance.ForeColor = Color.Black;
                    e.TipWidth = 500;
                    e.WrapText = true;
                    e.TipText = message;
                }
            }
        }

        #endregion Event : Process Event

        #region Event : Raise Event

        public void OnPrscRetrieved(PrscEventArgs args)
        {
            PrscEventArgs onargs = new PrscEventArgs(args.Dt, args.QtyZeroYn, args.TbrcSuptTrgtYn, args.HpvSameIlnsYn, args.HpvOthrIlnsYn, args.AllDcPrscDvcd);
            if (this.PrscRetrieved != null)
            {
                this.PrscRetrieved(this, onargs);
            }
        }
        #endregion Event : Raise Event

        #region Event : EventArgs
        public class PrscEventArgs : EventArgs
        {
            DataTable m_Dt = new DataTable();
            string m_QtyZeroYn = String.Empty;
            string m_TbrcSuptTrgtYn = String.Empty;
            string m_HpvSameIlnsYn = String.Empty;
            string m_HpvOthrIlnsYn = String.Empty;
            string m_AllDcPrscDvcd = String.Empty;

            public string AllDcPrscDvcd
            {
                get { return m_AllDcPrscDvcd; }
                set { m_AllDcPrscDvcd = value; }
            }

            public string HpvSameIlnsYn
            {
                get { return m_HpvSameIlnsYn; }
                set { m_HpvSameIlnsYn = value; }
            }

            public string HpvOthrIlnsYn
            {
                get { return m_HpvOthrIlnsYn; }
                set { m_HpvOthrIlnsYn = value; }
            }
            public string TbrcSuptTrgtYn
            {
                get { return StringService.IsNvl(m_TbrcSuptTrgtYn, "N"); }
                set { m_TbrcSuptTrgtYn = value; }
            }

            public string QtyZeroYn
            {
                get { return StringService.IsNvl(m_QtyZeroYn, "N"); }
                set { m_QtyZeroYn = value; }
            }

            public DataTable Dt
            {
                get { return m_Dt; }
                set { m_Dt = value; }
            }

            public PrscEventArgs()
            {
                new PrscEventArgs(this.m_Dt, this.m_QtyZeroYn, this.m_TbrcSuptTrgtYn, this.m_HpvSameIlnsYn, this.m_HpvOthrIlnsYn, this.m_AllDcPrscDvcd);
            }

            public PrscEventArgs(DataTable dt, string qtyzeroyn, string tbrcsupttrgtyn, string hpvsameilnsyn, string hpvothrilnsyn, string alldcprscdvcd)
            {
                this.m_Dt = dt;
                this.m_QtyZeroYn = qtyzeroyn;
                this.m_TbrcSuptTrgtYn = tbrcsupttrgtyn;
                this.m_HpvOthrIlnsYn = hpvothrilnsyn;
                this.m_HpvSameIlnsYn = hpvsameilnsyn;
                this.m_AllDcPrscDvcd = alldcprscdvcd;
            }
        }
        #endregion Event : EventArgs

        private void tabOutReceipt_SelectedTabChanged_1(object sender, Infragistics.Win.UltraWinTabControl.SelectedTabChangedEventArgs e)
        {

        }
    }
}
