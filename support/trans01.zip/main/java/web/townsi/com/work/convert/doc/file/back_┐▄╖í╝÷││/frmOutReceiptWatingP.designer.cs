namespace Lime.PA
{
    partial class frmOutReceiptWatingP
    {
    
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ucOutRecWatingList1 = new Lime.PA.ucOutRecWatingList();
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).BeginInit();
            this.pnlBase.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ucOutRecWatingList1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBase
            // 
            this.pnlBase.Controls.Add(this.ucOutRecWatingList1);
            this.pnlBase.Location = new System.Drawing.Point(1, 31);
            this.pnlBase.Size = new System.Drawing.Size(1262, 569);
            // 
            // ucOutRecWatingList1
            // 
            this.ucOutRecWatingList1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.ucOutRecWatingList1.Caption = "";
            this.ucOutRecWatingList1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucOutRecWatingList1.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.ucOutRecWatingList1.Icon = null;
            this.ucOutRecWatingList1.Location = new System.Drawing.Point(0, 0);
            this.ucOutRecWatingList1.Name = "ucOutRecWatingList1";
            this.ucOutRecWatingList1.Size = new System.Drawing.Size(1262, 569);
            this.ucOutRecWatingList1.TabIndex = 0;
            this.ucOutRecWatingList1.WatingType = "P";
            // 
            // frmOutReceiptWatingP
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Caption = "수납대기자";
            this.ClientSize = new System.Drawing.Size(1264, 601);
            this.Name = "frmOutReceiptWatingP";
            this.Padding = new System.Windows.Forms.Padding(0);
            this.Text = "수납대기자";
            this.Controls.SetChildIndex(this.pnlBase, 0);
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).EndInit();
            this.pnlBase.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ucOutRecWatingList1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ucOutRecWatingList ucOutRecWatingList1;
    }
}