using System;
using System.Data;

using SQL = Lime.Framework.DataListService.Sql;

namespace Lime.Framework
{
    //의사 리스트
    public class DoctorList
    {
        #region Define : Member

        private static DataTable m_dtList = new DataTable();
        private static bool m_Initialized = false;

        #endregion

        #region Property : Member Property

        public static DataTable ListTable
        {
            get
            {
                if (!m_Initialized)
                    SelectList();

                return m_dtList;
            }

            set
            {
                m_dtList = value;
            }
        }

        #endregion

        #region Method : Initialize Method

        public static void Clear() {
        
            m_dtList.Clear();

            m_Initialized = false;
        }

        #endregion

        #region Method : Get Data Method

        public static string GetName(string code)
        {
            if (!m_Initialized)
                SelectList();

            foreach (DataRow row in m_dtList.Rows)
            {
                if (row["USER_CD"].ToString().Trim().Equals(code))
                {
                    return row["USER_NM"].ToString().Trim();
                }
            }

            return "";
        }

        public static string GetEName(string code)
        {
            if (!m_Initialized)
                SelectList();

            foreach (DataRow row in m_dtList.Rows)
            {
                if (row["USER_CD"].ToString().Trim().Equals(code))
                    return row["USER_ENM"].ToString().Trim();
            }

            return "";
        }

        public static string GetNameWithDept(string code) {
        
            if (!m_Initialized)
                SelectList();

            foreach (DataRow row in m_dtList.Rows)
            {
                if (row["USER_CD"].ToString().Trim().Equals(code))
                {
                    return row["USER_NM_DEPT"].ToString().Trim();
                }
            }

            return "";
        }

        public static string GetDeptName(string code) {
            if (!m_Initialized)
                SelectList();

            foreach (DataRow row in m_dtList.Rows)
            {
                if (row["USER_CD"].ToString().Trim().Equals(code))
                    return row["DEPT_HNM"].ToString().Trim();
            }

            return "";
        }

        public static string GetDeptEName(string code)
        {
            if (!m_Initialized)
                SelectList();

            foreach (DataRow row in m_dtList.Rows)
            {
                if (row["USER_CD"].ToString().Trim().Equals(code))
                    return row["DEPT_ENM"].ToString().Trim();
            }

            return "";
        }

        public static string GetLicenseNumber(string code)
        {
            if (!m_Initialized)
                SelectList();

            foreach (DataRow row in m_dtList.Rows)
            {
                if (row["USER_CD"].ToString().Trim().Equals(code))
                    return row["LCNO"].ToString().Trim();
            }

            return "";
        }

        public static string GetQualificateNumber(string code)
        {
            if (!m_Initialized)
                SelectList();

            foreach (DataRow row in m_dtList.Rows)
            {
                if (row["USER_CD"].ToString().Trim().Equals(code))
                    return row["QLFC_NO"].ToString().Trim();
            }

            return "";
        }

        public static string GetCode(string name)
        {
            if (!m_Initialized)
                SelectList();

            foreach (DataRow row in m_dtList.Rows)
            {
                if (row["USER_NM"].ToString().Trim().Equals(name) ||
                    row["USER_NM_DEPT"].ToString().Trim().Equals(name))
                {
                    return row["USER_CD"].ToString().Trim();
                }
            }

            return "";
        }

        /// <summary>
        /// 의사 정보중 지정한 컬럼의 정보 조회
        /// </summary>
        /// <param name="code"></param>
        /// <param name="columnname"></param>
        /// <returns>object</returns>
        public static object GetColumnValue(string code, string columnname)
        {
            if (!m_Initialized)
                SelectList();

            foreach (DataRow row in m_dtList.Select("USER_CD = '" + code + "'"))
            {
                return row[columnname];
            }

            return "";
        }

        /// <summary>
        /// 의사 정보중 지정한 컬럼의 정보 조회
        /// </summary>
        /// <param name="code"></param>
        /// <param name="columnname"></param>
        /// <returns>object</returns>
        public static object GetColumnValue(string code, string deptcd, string columnname)
        {
            if (!m_Initialized)
                SelectList();

            foreach (DataRow row in m_dtList.Select("USER_CD = '" + code + "' AND DEPT_CD = '" + deptcd + "'"))
            {
                return row[columnname];
            }

            return "";
        }

        #endregion

        #region Method : Get Data List

        /// <summary>
        /// 의사 목록 조회
        /// </summary>
        /// <param name="additemtype"></param>
        /// <returns></returns>
        public static DataTable GetDataList(COMBO_ADD_ITEM_TYPE additemtype = COMBO_ADD_ITEM_TYPE.None)
        {
            if (!m_Initialized)
                SelectList();

            DataTable dt = m_dtList.Copy();

            if (!additemtype.Equals(COMBO_ADD_ITEM_TYPE.None))
                dt = AddComboItem(dt, additemtype);

            return dt;
        }

        /// <summary>
        /// 해당 진료과에 해당하는 의사 목록 조회
        /// </summary>
        /// <param name="deptcode"></param>
        /// <param name="additemtype"></param>
        /// <returns></returns>
        public static DataTable GetDataList(string deptcode, COMBO_ADD_ITEM_TYPE additemtype = COMBO_ADD_ITEM_TYPE.None)
        {
            if (!m_Initialized)
                SelectList();

            DataTable dt = new DataTable();

            try
            {
                if (m_dtList.Rows.Count > 0)
                {
                    if (StringService.IsNull(deptcode) || deptcode.Equals(DataType.COMBO_ADD_ITEM_TYPE_CODE_ALL))
                    {
                        dt = m_dtList.Copy();
                    }
                    else
                    {
                        dt = m_dtList.Clone();

                        foreach (DataRow row in m_dtList.Select("DEPT_CD = '" + deptcode + "'"))
                        {
                            dt.ImportRow(row);
                        }
                    }

                    if (!additemtype.Equals(COMBO_ADD_ITEM_TYPE.None))
                        dt = AddComboItem(dt, additemtype);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return dt;
        }

        private static DataTable AddComboItem(DataTable dt, COMBO_ADD_ITEM_TYPE additemtype = COMBO_ADD_ITEM_TYPE.None)
        {
            try
            {
                //전체/없음 추가.
                if (!additemtype.Equals(COMBO_ADD_ITEM_TYPE.None))
                {
                    DataRow newrow = dt.NewRow();
                    newrow["USER_CD"] = (additemtype.Equals(COMBO_ADD_ITEM_TYPE.AddAll) ? DataType.COMBO_ADD_ITEM_TYPE_CODE_ALL : DataType.COMBO_ADD_ITEM_TYPE_CODE_NONE);
                    newrow["USER_NM"] = (additemtype.Equals(COMBO_ADD_ITEM_TYPE.AddAll) ? DataType.COMBO_ADD_ITEM_TYPE_STRING_ALL : DataType.COMBO_ADD_ITEM_TYPE_STRING_NONE);
                    newrow["USER_NM_DEPT"] = (additemtype.Equals(COMBO_ADD_ITEM_TYPE.AddAll) ? DataType.COMBO_ADD_ITEM_TYPE_STRING_ALL : DataType.COMBO_ADD_ITEM_TYPE_STRING_NONE);
                    dt.Rows.InsertAt(newrow, 0);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return dt;
        }

        #endregion

        #region Method : Load Data Method

        /// <summary>
        /// Load list
        /// </summary>
        /// <returns></returns>
        public static DataTable LoadList()
        {
            SelectList();

            return m_dtList;
        }

        /// <summary>
        /// Select List
        /// </summary>
        private static void SelectList()
        {
            if (ClientEnvironment.DesignMode)
                return;

            try
            {
                m_dtList = new DataTable();

                //의사목록 조회
                DBService.ExecuteDataTable(SQL.SelectDoctorList(), ref m_dtList);

                m_Initialized = true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        #endregion
    }
}
