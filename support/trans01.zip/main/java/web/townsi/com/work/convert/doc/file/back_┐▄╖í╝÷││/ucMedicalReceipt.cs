using System;
using System.Data;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;

namespace Lime.BusinessControls
{
    public partial class ucMedicalReceipt : BaseUCF_TP
    {
        string m_PID = string.Empty;
        string m_PT_CMHS_NO = string.Empty;

        public ucMedicalReceipt()
        {
            InitializeComponent();
        }

        public void PrintReceipt(string pid, string pt_cmhs_no)
        {
            m_PID = pid;
            m_PT_CMHS_NO = pt_cmhs_no;

            Initialize();
            PrintData();
        }

        public ucMedicalReceipt(string pid, string pt_cmhs_no)
        {
            InitializeComponent();

            m_PID = pid;
            m_PT_CMHS_NO = pt_cmhs_no;

            Initialize();
        }

        //protected override void OnLoad(EventArgs e)
        //{
        //    base.OnLoad(e);
        //}

        private void Initialize()
        {
            SelectMediPrintList();
        }

        private void SelectMediPrintList()
        {
            sprMediList.Clear();

            DataTable dt = new DataTable();
            string sqlText = string.Empty;

            sqlText = @"
SELECT A.APNT_YN
     , B.PID 
     , B.PT_NM 
     , C.LWRN_OVRL_CD 
     , C.LWRN_OVRL_CDNM
     , SUBSTR(B.FRRN, 1, 6) || '-' || SUBSTR(B.SRRN, 1, 7) AS JM_NUMBER
     , DECODE(A.INSN_TYCD, '11', '건강보험', '21', '의료급여1종', '22', '의료급여2종', '31', '산재', '41', '자보', '51', '일반') AS BH_NM
     , SUBSTR(A.MDCR_DD, 1, 4) || '년' || SUBSTR(A.MDCR_DD, 5, 2) || '월' || SUBSTR(A.MDCR_DD, 7, 2) || '일' AS MDCR_DD_NM 
     , SUBSTR(A.MDCR_TIME, 1, 2) || ':' || SUBSTR(A.MDCR_TIME, 3, 2) AS MDCR_TIME_NM 
     , ( SELECT Z.DEPT_HNM
           FROM BIDEPTMA Z
          WHERE Z.USE_YN = 'Y'
            AND A.MDCR_DEPT_CD = Z.DEPT_CD ) AS DEPT_HNAME 
     , ( SELECT Y.USER_NM
           FROM BIUSERMT Y
          WHERE Y.USE_YN = 'Y'
            AND A.MDCR_DR_CD = Y.USER_CD ) AS USER_HNAME 
  FROM PAOPATRT A, PAPATHIN B, BICDINDT C
 WHERE A.ROW_STAT_DVCD = 'A'
   AND A.PID = '{0}'
   AND A.PT_CMHS_NO = {1}   
   AND B.PID = A.PID
   AND C.APLY_STRT_DD <= TO_CHAR(SYSDATE, 'YYYYMMDD')
   AND C.APLY_END_DD  >= TO_CHAR(SYSDATE, 'YYYYMMDD')
   AND C.OVRL_CD = 'MEDI_RECEIPT_PATH_CD'
";
            if (!DBService.ExecuteDataTable(sqlText, ref dt, m_PID, m_PT_CMHS_NO))
            {
                throw new Exception(DBService.ErrorMessage + "[" + DBService.ErrorCode + "]");
            }
            else
                FillData(sprMediList, dt);
        }

        private void FillData(LxSpread spr, DataTable dt, int strtidx = 0)
        {
            if (dt.Rows.Count < 1) return;

            spr.RowCount = strtidx;

            spr.RowCount += dt.Rows.Count * 35;

            // Left Top Right Border (Double)
            FarPoint.Win.ComplexBorder bd_dltr = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None));

            FarPoint.Win.ComplexBorder bd_dltr2 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None));

            FarPoint.Win.ComplexBorder bd_dt = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));

            // Top Right Border (Double)
            FarPoint.Win.ComplexBorder bd_dtr = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None));
            // Left Top Border
            FarPoint.Win.ComplexBorder bd_ltr = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None));
            //Top Right Border
            FarPoint.Win.ComplexBorder bd_tr = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None));

            FarPoint.Win.ComplexBorder bd_tr2 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None));

            // Left Top Bottom Border
            FarPoint.Win.ComplexBorder bd_ltrb = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));
            //Top Right Bottom Border
            FarPoint.Win.ComplexBorder bd_trb = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine));

            FarPoint.Win.ComplexBorder bd_ltrb2 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine));
            //Top Right Bottom Border
            FarPoint.Win.ComplexBorder bd_trb2 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine));

            FarPoint.Win.ComplexBorder bd_lr = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.None));

            FarPoint.Win.ComplexBorder bd_ltrb3 = new FarPoint.Win.ComplexBorder(new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThinLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine)
                                                                               , new FarPoint.Win.ComplexBorderSide(FarPoint.Win.ComplexBorderSideStyle.ThickLine));

            for (int i = 0; i < dt.Rows.Count;)
            {
                //width 세팅
                sprMediList.ActiveSheet.Columns.Get(0).Width = 170;
                sprMediList.ActiveSheet.Columns.Get(1).Width = 170;
                sprMediList.ActiveSheet.Columns.Get(2).Width = 170;
                sprMediList.ActiveSheet.Columns.Get(3).Width = 170;

                sprMediList.ActiveSheet.Rows.Get(0).Height = 50;
                sprMediList.ActiveSheet.Rows.Get(1).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(2).Height = 30;
                sprMediList.ActiveSheet.Rows.Get(3).Height = 30;
                sprMediList.ActiveSheet.Rows.Get(4).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(5).Height = 30;
                sprMediList.ActiveSheet.Rows.Get(6).Height = 30;
                sprMediList.ActiveSheet.Rows.Get(7).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(8).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(9).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(10).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(11).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(12).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(13).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(14).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(15).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(16).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(17).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(18).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(19).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(20).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(21).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(22).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(23).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(24).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(25).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(26).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(27).Height = 35;
                sprMediList.ActiveSheet.Rows.Get(28).Height = 35;


                if (dt.Rows[i]["APNT_YN"].ToString() == "Y")
                {
                    //예약 접수증 TITLE
                    spr.SetValue(strtidx + (i * 35), 0, "예 약  접 수 증");
                    sprMediList.ActiveSheet.Cells.Get(strtidx + (i * 35), 0).ColumnSpan = 4;
                    sprMediList.ActiveSheet.Cells.Get(strtidx + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold);
                    sprMediList.ActiveSheet.Cells.Get(strtidx + (i * 35), 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                    spr.SetValue(strtidx + 1 + (i * 35), 0, "(접수증은 해당 진료과에 제출하여 주십시오.)");
                    sprMediList.ActiveSheet.Cells.Get(strtidx + 1 + (i * 35), 0).ColumnSpan = 4;
                    sprMediList.ActiveSheet.Cells.Get(strtidx + 1 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F, System.Drawing.FontStyle.Bold);
                    sprMediList.ActiveSheet.Cells.Get(strtidx + 1 + (i * 35), 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                }
                else
                {
                    // 진료 접수증 TITLE
                    spr.SetValue(strtidx + (i * 35), 0, "진 료  접 수 증");
                    sprMediList.ActiveSheet.Cells.Get(strtidx + (i * 35), 0).ColumnSpan = 4;
                    sprMediList.ActiveSheet.Cells.Get(strtidx + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold);
                    sprMediList.ActiveSheet.Cells.Get(strtidx + (i * 35), 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                    spr.SetValue(strtidx + 1 + (i * 35), 0, "(접수증은 해당 진료과에 제출하여 주십시오.)");
                    sprMediList.ActiveSheet.Cells.Get(strtidx + 1 + (i * 35), 0).ColumnSpan = 4;
                    sprMediList.ActiveSheet.Cells.Get(strtidx + 1 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F, System.Drawing.FontStyle.Bold);
                    sprMediList.ActiveSheet.Cells.Get(strtidx + 1 + (i * 35), 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                }

                //환자 번호, 성명 세팅
                spr.SetValue(strtidx + 2 + (i * 35), 0, "등 록 번 호");
                spr.SetValue(strtidx + 2 + (i * 35), 1, dt.Rows[i]["PID"].ToString());
                spr.SetValue(strtidx + 2 + (i * 35), 2, "성 명");
                spr.SetValue(strtidx + 2 + (i * 35), 3, dt.Rows[i]["PT_NM"].ToString());
                sprMediList.ActiveSheet.Cells.Get(strtidx + 2 + (i * 35), 0).BackColor = System.Drawing.Color.Gainsboro;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 2 + (i * 35), 2).BackColor = System.Drawing.Color.Gainsboro;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 2 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 2 + (i * 35), 1).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 2 + (i * 35), 2).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 2 + (i * 35), 3).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 2 + (i * 35), 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 2 + (i * 35), 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 2 + (i * 35), 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 2 + (i * 35), 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                //진료일자, 주민번호 세팅
                spr.SetValue(strtidx + 3 + (i * 35), 0, "진 료 일 자");
                spr.SetValue(strtidx + 3 + (i * 35), 1, dt.Rows[i]["MDCR_DD_NM"].ToString());
                spr.SetValue(strtidx + 3 + (i * 35), 2, "주 민 번 호");
                spr.SetValue(strtidx + 3 + (i * 35), 3, dt.Rows[i]["JM_NUMBER"].ToString());
                sprMediList.ActiveSheet.Cells.Get(strtidx + 3 + (i * 35), 0).BackColor = System.Drawing.Color.Gainsboro;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 3 + (i * 35), 2).BackColor = System.Drawing.Color.Gainsboro;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 3 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 3 + (i * 35), 1).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 3 + (i * 35), 2).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 3 + (i * 35), 3).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 3 + (i * 35), 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 3 + (i * 35), 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 3 + (i * 35), 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 3 + (i * 35), 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                // 접수과 안내 TITLE
                spr.SetValue(strtidx + 4 + (i * 35), 0, "▣ 접수과 안내 ▣");
                sprMediList.ActiveSheet.Cells.Get(strtidx + 4 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 4 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 4 + (i * 35), 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                // 접수과, 접수의, 진료시간 
                spr.SetValue(strtidx + 5 + (i * 35), 0, "보 험 정 보");
                spr.SetValue(strtidx + 5 + (i * 35), 1, "접 수 과");
                spr.SetValue(strtidx + 5 + (i * 35), 2, "진 료 의");
                spr.SetValue(strtidx + 5 + (i * 35), 3, "접 수 시 간");
                sprMediList.ActiveSheet.Cells.Get(strtidx + 5 + (i * 35), 0).BackColor = System.Drawing.Color.Gainsboro;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 5 + (i * 35), 1).BackColor = System.Drawing.Color.Gainsboro;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 5 + (i * 35), 2).BackColor = System.Drawing.Color.Gainsboro;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 5 + (i * 35), 3).BackColor = System.Drawing.Color.Gainsboro;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 5 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 5 + (i * 35), 1).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 5 + (i * 35), 2).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 5 + (i * 35), 3).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 5 + (i * 35), 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 5 + (i * 35), 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 5 + (i * 35), 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 5 + (i * 35), 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                // 접수과, 접수의, 진료시간 LWRN_OVRL_CDNM 
                spr.SetValue(strtidx + 6 + (i * 35), 0, dt.Rows[i]["BH_NM"].ToString());
                spr.SetValue(strtidx + 6 + (i * 35), 1, dt.Rows[i]["DEPT_HNAME"].ToString());
                spr.SetValue(strtidx + 6 + (i * 35), 2, dt.Rows[i]["USER_HNAME"].ToString());
                spr.SetValue(strtidx + 6 + (i * 35), 3, dt.Rows[i]["MDCR_TIME_NM"].ToString());
                sprMediList.ActiveSheet.Cells.Get(strtidx + 6 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 6 + (i * 35), 1).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 6 + (i * 35), 2).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 6 + (i * 35), 3).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 6 + (i * 35), 0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 6 + (i * 35), 1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 6 + (i * 35), 2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 6 + (i * 35), 3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                // 오늘 가야 할 곳 세팅
                spr.SetValue(strtidx + 7 + (i * 35), 0, "▣ 오늘 가야 할 곳");
                sprMediList.ActiveSheet.Cells.Get(strtidx + 7 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 7 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold);

                sprMediList.ActiveSheet.Cells.Get(strtidx + 8 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 9 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 10 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 11 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 12 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 13 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 14 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 15 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 16 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 17 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 18 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 19 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 20 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 21 + (i * 35), 0).ColumnSpan = 4;

                sprMediList.ActiveSheet.Cells.Get(strtidx + 8 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 9 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 10 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 11 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 12 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 13 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 14 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 15 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 16 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 17 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 18 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 19 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 20 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);
                sprMediList.ActiveSheet.Cells.Get(strtidx + 21 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);


                for (int j = 0; j < dt.Rows.Count; j++)
                {
                    // 오늘 가야 할 곳 세팅
                    FarPoint.Win.Spread.CellType.RichTextCellType acell = new FarPoint.Win.Spread.CellType.RichTextCellType();
                    sprMediList.ActiveSheet.Cells.Get(strtidx + 8 + j + (i * 35), 0).CellType = acell;
                    acell.Multiline = true;
                    acell.WordWrap = true;
                    spr.SetValue(strtidx + 8 + j + (i * 35), 0, dt.Rows[j]["LWRN_OVRL_CDNM"].ToString());
                }

                // 검사하신 후 (귀가, 외래 재방문)
                spr.SetValue(strtidx + 22 + (i * 35), 0, "▣ 검사하신 후 (수 납   ,  귀 가  ,  외래 재방문)");
                sprMediList.ActiveSheet.Cells.Get(strtidx + 22 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 22 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold);

                spr.SetValue(strtidx + 23 + (i * 35), 0, "▣ 다음 진료일은 2층 접수 창구에서 (당일접수 , 예약) 하십시오.");
                sprMediList.ActiveSheet.Cells.Get(strtidx + 23 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 23 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold);

                spr.SetValue(strtidx + 24 + (i * 35), 0, "진 료 과 : ");
                sprMediList.ActiveSheet.Cells.Get(strtidx + 24 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 24 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);

                spr.SetValue(strtidx + 25 + (i * 35), 0, "예 약 일 :      월    일    (오전    오후)");
                sprMediList.ActiveSheet.Cells.Get(strtidx + 25 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 25 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 13F);

                spr.SetValue(strtidx + 26 + (i * 35), 0, "▣ 메 모");
                sprMediList.ActiveSheet.Cells.Get(strtidx + 26 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 26 + (i * 35), 0).RowSpan = 2;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 26 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold);

                spr.SetValue(strtidx + 28 + (i * 35), 0, "* 검사 결과는 당일 혹은 예약하신 날에 해당 진료과에서 확인 하시면 됩니다.");
                sprMediList.ActiveSheet.Cells.Get(strtidx + 28 + (i * 35), 0).ColumnSpan = 4;
                sprMediList.ActiveSheet.Cells.Get(strtidx + 28 + (i * 35), 0).Font = new System.Drawing.Font("맑은 고딕", 12F);

                // Border 셋팅
                spr.ActiveSheet.Cells[strtidx + (i * 35), 0].Border = bd_dltr;
                spr.ActiveSheet.Cells[strtidx + 1 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 2 + (i * 35), 0].Border = bd_ltr;
                spr.ActiveSheet.Cells[strtidx + 2 + (i * 35), 1].Border = bd_tr;
                spr.ActiveSheet.Cells[strtidx + 2 + (i * 35), 2].Border = bd_tr;
                spr.ActiveSheet.Cells[strtidx + 2 + (i * 35), 3].Border = bd_tr2;
                spr.ActiveSheet.Cells[strtidx + 3 + (i * 35), 0].Border = bd_ltr;
                spr.ActiveSheet.Cells[strtidx + 3 + (i * 35), 1].Border = bd_tr;
                spr.ActiveSheet.Cells[strtidx + 3 + (i * 35), 2].Border = bd_tr;
                spr.ActiveSheet.Cells[strtidx + 3 + (i * 35), 3].Border = bd_tr2;
                spr.ActiveSheet.Cells[strtidx + 4 + (i * 35), 0].Border = bd_dltr2;
                spr.ActiveSheet.Cells[strtidx + 5 + (i * 35), 0].Border = bd_ltr;
                spr.ActiveSheet.Cells[strtidx + 5 + (i * 35), 1].Border = bd_tr;
                spr.ActiveSheet.Cells[strtidx + 5 + (i * 35), 2].Border = bd_tr;
                spr.ActiveSheet.Cells[strtidx + 5 + (i * 35), 3].Border = bd_tr2;
                spr.ActiveSheet.Cells[strtidx + 6 + (i * 35), 0].Border = bd_ltr;
                spr.ActiveSheet.Cells[strtidx + 6 + (i * 35), 1].Border = bd_tr;
                spr.ActiveSheet.Cells[strtidx + 6 + (i * 35), 2].Border = bd_tr;
                spr.ActiveSheet.Cells[strtidx + 6 + (i * 35), 3].Border = bd_tr2;
                spr.ActiveSheet.Cells[strtidx + 7 + (i * 35), 0].Border = bd_dltr2;
                spr.ActiveSheet.Cells[strtidx + 8 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 9 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 10 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 11 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 12 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 13 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 14 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 15 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 16 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 17 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 18 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 19 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 20 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 21 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 22 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 23 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 24 + (i * 35), 0].Border = bd_dltr2;
                spr.ActiveSheet.Cells[strtidx + 25 + (i * 35), 0].Border = bd_lr;
                spr.ActiveSheet.Cells[strtidx + 26 + (i * 35), 0].Border = bd_dltr2;
                spr.ActiveSheet.Cells[strtidx + 28 + (i * 35), 0].Border = bd_ltrb3;

                break;
            }
        }

        //PrintData
        public void PrintData()
        {
            if (sprMediList.RowCount < 1)
            {
                LxMessage.ShowInformation("출력할 데이터가 없습니다.");
                return;
            }

            FarPoint.Win.Spread.PrintInfo info = new FarPoint.Win.Spread.PrintInfo();
            FarPoint.Win.Spread.PrintMargin margin = new FarPoint.Win.Spread.PrintMargin();

            margin.Header = 20;
            margin.Left = 80;
            margin.Right = 10;
            margin.Top = 10;
            margin.Bottom = 10;

            info.ZoomFactor = 0.98f;
            info.Orientation = FarPoint.Win.Spread.PrintOrientation.Portrait;
            //info.Preview = true;
            info.Centering = FarPoint.Win.Spread.Centering.Vertical;
            info.ShowBorder = false;
            info.ShowShadows = false;
            info.ShowRowHeader = FarPoint.Win.Spread.PrintHeader.Hide;
            info.ShowColumnHeader = FarPoint.Win.Spread.PrintHeader.Hide;
            info.Margin = margin;
            info.Printer = PrinterConfig.GetDefaultPrinterName();

            sprMediList.ActiveSheet.PrintInfo = info;
            sprMediList.PrintSheet(sprMediList.ActiveSheet);

            //LxProgressMessage.Show("접수증 출력 중입니다...");
            Application.DoEvents();
            //LxProgressMessage.Hide();
        }
    }
}
