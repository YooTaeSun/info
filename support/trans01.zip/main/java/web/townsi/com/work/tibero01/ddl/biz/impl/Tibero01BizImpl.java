//package web.townsi.com.work.tibero01.ddl.biz.impl;
//
//import java.util.HashMap;
//import java.util.List;
//import java.util.stream.Collectors;
//
//import org.apache.commons.lang3.StringUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.cache.annotation.Cacheable;
//import org.springframework.stereotype.Service;
//
//import web.townsi.com.utils.ListUtil;
//import web.townsi.com.utils.SqlUtil;
//import web.townsi.com.work.oracle.biz.OracleBiz;
//import web.townsi.com.work.tibero01.ddl.biz.Tibero01Biz;
//import web.townsi.com.work.tibero01.ddl.mapper.Tibero01Mapper;
//
//@SuppressWarnings({"rawtypes","unchecked","unused"})
//@Service
//public class Tibero01BizImpl implements Tibero01Biz {
//
//	private Logger logger = LoggerFactory.getLogger(Tibero01BizImpl.class);
//
//	@Autowired
//	private Tibero01Mapper tibero01Mapper;
//	
//	@Autowired
//	private OracleBiz oracleBiz;
//	
//	@Override
//	public HashMap selectTableCountList(HashMap params) {
//		HashMap bizMap = new HashMap();
//		
//		List<HashMap> toList = tibero01Mapper.selectList("selectTableList", params);
//		List<String> tableList = toList.stream().map(o->o.get("objectNameTibero01").toString()).collect(Collectors.toList());
//		
//		
//		params.put("tableList", tableList);
//		
//		List<HashMap> list = tibero01Mapper.selectList("selectTableCountList", params);
//		bizMap.put("list", list);
//		return bizMap;
//	}
//	
//	@Override
//	public int dropTable(HashMap params) {
//		
//		String objectNameTibero01 = StringUtils.defaultString((String)params.get("objectNameTibero01"));
//		HashMap param01 = new HashMap();
//		param01.put("tableNm", objectNameTibero01);
//		int resultInt =  tibero01Mapper.dropTable(param01);
//		return resultInt;
//	}
//
//	@Override
//	@Cacheable(value="tiberoTableInfoCache", key = "{#dbName, #owner, #tableName}")
//	public List<HashMap> selectTableInfo(HashMap params, String dbName, String owner, String tableName){
//		List<HashMap> list = tibero01Mapper.selectTableInfo(params);
//		return list;
//	}
//	
//	@Override
//	public HashMap createTable(HashMap params) {
//		HashMap bizMap = new HashMap();
//		
//		List<HashMap> list = oracleBiz.selectTableInfo(params);
//		if(!ListUtil.isEmpty(list)) {
//			HashMap makeSqlMap  = SqlUtil.makeSql(list, params);
//			String createSql = (String) makeSqlMap.get("create");
//			int resultInt = tibero01Mapper.createTable(createSql);
//		}
//		return bizMap;
//	}
//	
//	@Override
//	public HashMap dropCreateTable(HashMap params) {
//		HashMap bizMap = new HashMap();
//		
//		String ownerTibero01 = StringUtils.defaultString((String)params.get("ownerTibero01")); 
//		String objectNameTibero01 = StringUtils.defaultString((String)params.get("objectNameTibero01"));
//		
//		HashMap tibero01Param = new HashMap();
//		tibero01Param.put("owner", objectNameTibero01);
//		tibero01Param.put("tableNm", objectNameTibero01);
//		
//		String ownerOracle = StringUtils.defaultString((String)params.get("ownerOracle"));
//		String objectNameOracle = StringUtils.defaultString((String)params.get("objectNameOracle"));
//		
//		HashMap oracleParam = new HashMap();
//		oracleParam.put("owner", ownerOracle);
//		oracleParam.put("tableNm", objectNameOracle);
//		
//		if(!ownerTibero01.isEmpty()) {
//			tibero01Mapper.dropTable(tibero01Param);
//		}
//		
//		if(!ownerOracle.isEmpty()) {
//			this.createTable(oracleParam);
//			List<HashMap> createList = tibero01Mapper.selectList("selectTableList", tibero01Param);
//			bizMap.put("createdRow", createList.get(0));
//		}
//		
//		HashMap dataMap01 = this.selectTableCountList(tibero01Param);
//		List deletedList = (List) dataMap01.get("list");
//		bizMap.put("deletedRow", deletedList.get(0));
//		
//		return bizMap;
//	}
//	
//	
//	@Override
//	public HashMap deleteTable(HashMap params) {
//		HashMap bizMap = new HashMap();
//		
//		int resultInt = -1; 
//		String ownerTibero01 = StringUtils.defaultString((String)params.get("ownerTibero01"));
//		String tableNm = StringUtils.defaultString((String) params.get("objectNameTibero01"));
//		String owner = StringUtils.defaultString((String) params.get("ownerTibero01"));
//		
//		HashMap param01 = new HashMap();
//		param01.put("owner", owner);
//		param01.put("tableNm", tableNm);
//		
//		if(!ownerTibero01.isEmpty()) {
//			resultInt = tibero01Mapper.deleteTable(param01);
//		}
//		
//		HashMap dataMap01 = this.selectTableCountList(param01);
//		List deletedList = (List) dataMap01.get("list");
//		bizMap.put("deletedRow", deletedList.get(0));
//		
//		return bizMap;
//	}
//	
//	@Override
//	public HashMap copyData(HashMap params) {
//		HashMap bizMap = new HashMap();
//		
//		String ownerTibero01 = StringUtils.defaultString((String)params.get("ownerTibero01")); 
//		String objectNameTibero01 = StringUtils.defaultString((String)params.get("objectNameTibero01"));
//		
//		HashMap tibero01Param = new HashMap();
//		tibero01Param.put("owner", objectNameTibero01);
//		tibero01Param.put("tableNm", objectNameTibero01);
//		
//		String ownerOracle = StringUtils.defaultString((String)params.get("ownerOracle"));
//		String objectNameOracle = StringUtils.defaultString((String)params.get("objectNameOracle"));
//		
//		HashMap oracleParam = new HashMap();
//		oracleParam.put("owner", ownerOracle);
//		oracleParam.put("tableNm", objectNameOracle);
//		
//		List<HashMap> list = oracleBiz.selectTableInfo(params);
//		
//		
////		if(!ownerTibero01.isEmpty()) {
////			tibero01Mapper.dropTable(tibero01Param);
////		}
////		
////		if(!ownerOracle.isEmpty()) {
////			this.createTable(oracleParam);
////			List<HashMap> createList = tibero01Mapper.selectList("selectTableList", tibero01Param);
////			bizMap.put("createdRow", createList.get(0));
////		}
//		
////		HashMap dataMap01 = this.selectTableCountList(tibero01Param);
////		List deletedList = (List) dataMap01.get("list");
////		bizMap.put("deletedRow", deletedList.get(0));
//		
//		return bizMap;
//	}
//
//}