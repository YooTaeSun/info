using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.BusinessService;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.BusinessControls
{
    public class clsCommon
    {
        public string PID { get; set; }
        public string PT_CMHS_NO { get; set; }
        public string CMPY_DVCD { get; set; }
        public string INSN_TYCD { get; set; }
        public string ASST_TYCD { get; set; }
        public string CMPY_STRT_DD { get; set; }
        public string CMPY_END_DD { get; set; }
        public string ADMS_DD { get; set; }
        public string DSCH_DD { get; set; }
        public string REAL_ADMS_DD { get; set; }
        public string REAL_ADMS_TIME { get; set; }
        public string RealAdmsDateTime { get; set; }
        public string MAIN_SUB_ADMS_DVCD { get; set; }
        public string ASCT_RGNO_CD { get; set; }
        public string SNDT_TGPS_DVCD { get; set; }
        public string DRG_YN { get; set; }
        public int STRT_AGE { get; set; }
        public int END_AGE { get; set; }

        public clsCommon()
        {
            this.ClearParam();
        }

        public void ClearParam()
        {
            PID = string.Empty;
            PT_CMHS_NO = string.Empty;
            CMPY_DVCD = string.Empty;
            INSN_TYCD = string.Empty;
            ASST_TYCD = string.Empty;
            CMPY_STRT_DD = string.Empty;
            CMPY_END_DD = string.Empty;
            ADMS_DD = string.Empty;
            DSCH_DD = string.Empty;
            REAL_ADMS_DD = string.Empty;
            REAL_ADMS_TIME = string.Empty;
            RealAdmsDateTime = string.Empty;
            MAIN_SUB_ADMS_DVCD = string.Empty;
            ASCT_RGNO_CD = string.Empty;
            SNDT_TGPS_DVCD = string.Empty;
            DRG_YN = string.Empty;
            STRT_AGE = 0;
            END_AGE = 0;
        }

        public bool CheckData()
        {
            try
            {
                object RetVal = null;
                DataTable RetTable = new DataTable();

                //****************************************************************************************************
                // 의료급여2종 VA.HIV/ADIS는 외래만 사용가능
                //****************************************************************************************************
                if (INSN_TYCD.Equals("22") && ASST_TYCD.Equals("VA"))
                {
                    LxMessage.Show("VA.HIV/ADIS는 외래에서만 사용하는 유형보조입니다!", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }

                //****************************************************************************************************
                // 16세 미만(소아)일경우 시작일 나이 종료일 나이 다르면 메세지
                //****************************************************************************************************
                if ((STRT_AGE < 16 || END_AGE < 16) && !STRT_AGE.Equals(END_AGE))
                    LxMessage.Show("시작일 기준 나이와 종료일 기준 나이가 다릅니다. 확인 바랍니다!", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);

                //****************************************************************************************************
                // 조합기호코드 가져오기 ( 보험유형 51이 아니면서 !(보험유형11 이면서 (유형보조=99 또는 D9 또는 P9))
                //****************************************************************************************************
                string INSN_TYCD_ASCT_RGNO_CD = "NO";
                if (!INSN_TYCD.Equals("51") && !(INSN_TYCD.Equals("11") && (ASST_TYCD.Equals("99") || ASST_TYCD.Equals("D9") || ASST_TYCD.Equals("P9"))))
                {
                    RetVal = null;
                    RetVal = DBService.ExecuteScalar(SQL.CL.Sql.popJudgePatientList_GetASCT_RGNO_CD(), PID, INSN_TYCD, CMPY_END_DD, CMPY_STRT_DD);

                    if (DBService.HasError)
                        throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                    if (RetVal != null)
                        INSN_TYCD_ASCT_RGNO_CD = RetVal.ToString();
                    else
                        LxMessage.Show("현재 입원변동내역에 환자보험정보가 존재하지 않습니다.\r\n입원변동내역에 보험정보를 확인하십시오.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    if (!INSN_TYCD_ASCT_RGNO_CD.Equals(ASCT_RGNO_CD))
                        LxMessage.Show("현재 입원변동내역의 보험정보와 환자보험정보의 조합기호가 일치하지 않습니다.\r\n입원변동내역에서 보험정보를 확인하십시요!", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                //****************************************************************************************************
                // TODO : MessageBox('알림!', '의료급여 애기환자입니다. 엄마의 시설유무를 확인바랍니다.!')
                //****************************************************************************************************

                //****************************************************************************************************
                // 부입원이면서 DRG 환자인지 체크
                //****************************************************************************************************
                if (MAIN_SUB_ADMS_DVCD.Equals("B") && DRG_YN.Equals("Y"))
                {
                    LxMessage.Show("DRG 부입원 처리할 수 없습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }

                //****************************************************************************************************
                // 틀니보험으로 처리되는 경우
                //****************************************************************************************************
                if (ASST_TYCD.Equals("D0") || ASST_TYCD.Equals("CD") || ASST_TYCD.Equals("ED") || ASST_TYCD.Equals("D9"))
                {
                    if (MAIN_SUB_ADMS_DVCD.Equals("J"))
                    {
                        LxMessage.Show("주입원은 노인틀니로 적용할 수 없습니다!", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return false;
                    }
                    else
                    {
                        // 1.상악 2.하악 3.상하악
                        if (!SNDT_TGPS_DVCD.Equals("1") && !SNDT_TGPS_DVCD.Equals("2") && !SNDT_TGPS_DVCD.Equals("3"))
                        {
                            LxMessage.Show(string.Format("{0}\r\n{1}", "노인틀니 보험유형으로 계산되는 환자인데 입원등록정보에는 노인틀니 대상자로 구분되지 않았습니다.",
                                                                       "[입원접수관리]->[입원 정보변경]에서 입원정보변경 버튼을 눌러 틀니대상자로 정보변경을 하세요."), "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }

                //****************************************************************************************************
                // 임플란트보험으로 처리되는 경우
                //****************************************************************************************************
                if (ASST_TYCD.Equals("P0") || ASST_TYCD.Equals("CP") || ASST_TYCD.Equals("EP") || ASST_TYCD.Equals("P9"))
                {
                    if (MAIN_SUB_ADMS_DVCD.Equals("J"))
                    {
                        LxMessage.Show("주입원은 임플란트로 적용할 수 없습니다!", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return false;
                    }
                    else
                    {
                        // 1.상악 2.하악 3.상하악
                        if (!SNDT_TGPS_DVCD.Equals("1") && !SNDT_TGPS_DVCD.Equals("2") && !SNDT_TGPS_DVCD.Equals("3"))
                        {
                            LxMessage.Show(string.Format("{0}\r\n{1}", "임플란트 보험유형으로 계산되는 환자인데 입원등록정보에는 임플란트 대상자로 구분되지 않았습니다!",
                                                                       "[입원접수관리]->[입원 정보변경]에서 입원정보변경 버튼을 눌러 임플란트대상자로 정보변경을 하세요."), "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }

                //****************************************************************************************************
                // 퇴원예정환자 조회시 퇴원일자나 시간이 입력 안되어 있으면 조회 안됨
                // TODO : 현재 SelectData 안에서 처리함
                // TODO : 리턴처리(진행안함)
                //****************************************************************************************************

                //****************************************************************************************************
                // TODO : 산정특례(개두술,개심술) 적용 30일이 경과하고 정산시 내역변경이 이루어질수 있도록 알림
                // 2011.07.05 서울 보험과 추연하팀장 요청
                //****************************************************************************************************
                if (ASST_TYCD.Equals("E3") || ASST_TYCD.Equals("F3") || ASST_TYCD.Equals("HV") || ASST_TYCD.Equals("V3") || ASST_TYCD.Equals("FF"))
                {
                }

                //****************************************************************************************************
                // 정산구분에 따른 실제 입원일시
                //****************************************************************************************************
                string Max_Cmpy_End_dd = string.Empty;
                DialogResult rst = DialogResult.Abort;

                // 장기입원 환자 여부를 확인한다.
                // +++++++++++++++++++++++++++++++++++++++++++++++
                // 기간내에 일반실외에 입원한 이력이 있으면 분리청구 해야한다.
                // +++++++++++++++++++++++++++++++++++++++++++++++
                if (INSN_TYCD.Equals("11") && ASST_TYCD.Equals("00") && !CMPY_DVCD.Equals("I"))
                {
                    // 격리실 중환자실 등 count
                    string sqltext = $@"
SELECT COUNT(1)
   FROM PAIPATRT A
  INNER JOIN PAIPCHMA B ON B.PID = A.PID AND B.PT_CMHS_NO = A.PT_CMHS_NO AND B.ROOM_DVCD <> '1'
  INNER JOIN (SELECT TO_CHAR(TO_DATE('{CMPY_STRT_DD}') + (LEVEL - 1), 'YYYYMMDD') MDCR_DD
                FROM DUAL CONNECT BY LEVEL <= TO_DATE('{CMPY_END_DD}') - TO_DATE('{CMPY_STRT_DD}') + 1) C ON B.APLY_STRT_DD <= C.MDCR_DD 
                AND B.APLY_END_DD >= C.MDCR_DD AND A.DSCH_DD <> C.MDCR_DD
  WHERE A.PID           = '{PID}'
    AND A.PT_CMHS_NO    =  {PT_CMHS_NO}
    AND A.ROW_STAT_DVCD = 'A' ";

                    int count_1 = DBService.ExecuteInteger(sqltext);

                    // 일반실 count
                    sqltext = $@"
SELECT COUNT(1)
   FROM PAIPATRT A
  INNER JOIN PAIPCHMA B ON B.PID = A.PID AND B.PT_CMHS_NO = A.PT_CMHS_NO AND B.ROOM_DVCD = '1'
  INNER JOIN (SELECT TO_CHAR(TO_DATE('{CMPY_STRT_DD}') + (LEVEL - 1), 'YYYYMMDD') MDCR_DD
                FROM DUAL CONNECT BY LEVEL <= TO_DATE('{CMPY_END_DD}') - TO_DATE('{CMPY_STRT_DD}') + 1) C ON B.APLY_STRT_DD <= C.MDCR_DD 
                AND B.APLY_END_DD >= C.MDCR_DD AND A.DSCH_DD <> C.MDCR_DD
  WHERE A.PID           = '{PID}'
    AND A.PT_CMHS_NO    =  {PT_CMHS_NO}
    AND A.ROW_STAT_DVCD = 'A' ";

                    int count_2 = DBService.ExecuteInteger(sqltext);

                    if (count_1 > 0 && count_2 > 0)
                        LxMessage.ShowError("정산기간내에 일반실 외에 입원한 이력이 있습니다.\r\n청구분리여부를 확인해 주세요!!!!");

                    /*
                    FN_PA_PRC_IBILOPN-- 주상병등 체크
                    FN_PA_READ_STHSNDY-- 입원료 본인부담코드
                    16, 31 값을 넣기위한 조건 */
                }

                if (CMPY_DVCD.Equals("I")) // 재원
                {
                    // 보험심사과일 경우
                    if (DOPack.UserInfo.DEPT_CD.Equals("A104"))
                    {
                        // 중간계산 정보가 한 번도 없었을 경우
                        if (string.IsNullOrWhiteSpace(CMPY_STRT_DD))
                        {
                            // 장기재원 중간정산 정보에서 가장 최종 정산종료일을 가지고 온다.
                            RetVal = null;
                            RetVal = DBService.ExecuteScalar(SQL.CL.Sql.popJudgePatientList_PAAREVMA_MAX_CMPY_END_DD(), PID, PT_CMHS_NO);

                            if (DBService.HasError)
                                throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                            if (RetVal != null)
                                Max_Cmpy_End_dd = RetVal.ToString();

                            if (string.IsNullOrWhiteSpace(Max_Cmpy_End_dd)) Max_Cmpy_End_dd = ADMS_DD;
                        }
                    }
                    // TODO : last_jsdate ? PowerBuilder - w_bil03q01 - dw_pat - ue_key_enter
                    //        ls_jtdate = This.GetItemString(THIS.GetRow(), 'last_jsdate')
                }
                else if (CMPY_DVCD.Equals("J")) // 중간
                {
                    //****************************************************************************************************
                    // 간호평가기록지 입원시간 가져온다
                    //****************************************************************************************************
                    if (string.IsNullOrWhiteSpace(RealAdmsDateTime))
                    {
                        RetVal = null;
                        RetVal = DBService.ExecuteScalar(SQL.CL.Sql.FN_NR_READ_NRINEXIF(), PID, PT_CMHS_NO);
                        if (DBService.HasError)
                            throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                        if (RetVal != null)
                            RealAdmsDateTime = RetVal.ToString();
                    }

                    //if (!REAL_ADMS_DD.Equals("29991231")) 2018-01-12 ??
                    if (string.IsNullOrWhiteSpace(RealAdmsDateTime))
                    {
                        rst = LxMessage.Show(string.Format("{0}\r\n{1}\r\n    - 입원일자 : {2}\r\n    - 입원시간 : {3}\r\n{4}",
                                                           "실제 입원일시가 등록되지 않았습니다.",
                                                           "간호초기평가기록지의 입원일시를 다시 가져올까요?",
                                                           RealAdmsDateTime.Length >= 8 ? RealAdmsDateTime.Substring(0, 8) : string.Empty,
                                                           RealAdmsDateTime.Length >= 12 ? RealAdmsDateTime.Substring(8, 4) : string.Empty,
                                                           "※실입원일시 변경은 원무행정 -> 입원정보변경 -> (버튼)입원정보변경"), "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                        if (rst != DialogResult.Yes)
                        {
                            LxMessage.Show("실제 입원일시가 등록되지 않았습니다.\r\n퇴원심사(마감정산)가 불가능합니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return false;
                        }
                    }

                    //****************************************************************************************************
                    // 실제입원일시를 저장한다
                    //****************************************************************************************************
                    string ErrCode = string.Empty;
                    string ErrMsg = string.Empty;
                    if (!SQL.Procedure.PR_PA_PRC_PAIPATRTCH(PID, PT_CMHS_NO, "REAL_ADMS_DD", RealAdmsDateTime, ref ErrCode, ref ErrMsg))
                    {
                        if (!string.IsNullOrWhiteSpace(ErrCode) || !string.IsNullOrWhiteSpace(ErrMsg))
                            throw new Exception(string.Format("[{0}]\r\n{1}", ErrCode, ErrMsg));

                        if (DBService.HasError)
                            throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                    }

                    REAL_ADMS_DD = RealAdmsDateTime.Length >= 8 ? RealAdmsDateTime.Substring(0, 8) : string.Empty;
                    REAL_ADMS_TIME = RealAdmsDateTime.Length >= 12 ? RealAdmsDateTime.Substring(8, 4) : string.Empty;
                }
                else if (CMPY_DVCD.Equals("T")) // 퇴원
                {

                }
                else if (CMPY_DVCD.Equals("Y")) // 퇴원예정
                {
                    string Msg1 = string.Empty;
                    string Msg2 = string.Empty;

                    this.wf_ent_msg(ADMS_DD, DSCH_DD, ref Msg1, ref Msg2);

                    //****************************************************************************************************
                    // 간호평가기록지 입원시간 가져온다
                    //****************************************************************************************************
                    if (string.IsNullOrWhiteSpace(RealAdmsDateTime))
                    {
                        RetVal = null;
                        RetVal = DBService.ExecuteScalar(SQL.CL.Sql.FN_NR_READ_NRINEXIF(), PID, PT_CMHS_NO);
                        if (DBService.HasError)
                            throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                        if (RetVal != null)
                            RealAdmsDateTime = RetVal.ToString();
                    }

                    //if (!REAL_ADMS_DD.Equals("29991231")) 2018-01-12 ??
                    if (string.IsNullOrWhiteSpace(RealAdmsDateTime))
                    {
                        rst = LxMessage.Show(string.Format("{0}\r\n{1}\r\n    - 입원일자 : {2}\r\n    - 입원시간 : {3}\r\n{4}",
                                                           "실제 입원일시가 등록되지 않았습니다.",
                                                           "간호초기평가기록지의 입원일시를 다시 가져올까요?",
                                                           RealAdmsDateTime.Length >= 8 ? RealAdmsDateTime.Substring(0, 8) : string.Empty,
                                                           RealAdmsDateTime.Length >= 12 ? RealAdmsDateTime.Substring(8, 4) : string.Empty,
                                                           "※실입원일시 변경은 원무행정 -> 입원정보변경 -> (버튼)입원정보변경"), "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                        if (rst != DialogResult.Yes)
                        {
                            LxMessage.Show("실제 입원일시가 등록되지 않았습니다.\r\n퇴원심사(마감정산)가 불가능합니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return false;
                        }
                    }

                    //****************************************************************************************************
                    // 실제입원일시를 저장한다
                    //****************************************************************************************************
                    string ErrCode = string.Empty;
                    string ErrMsg = string.Empty;
                    if (!SQL.Procedure.PR_PA_PRC_PAIPATRTCH(PID, PT_CMHS_NO, "REAL_ADMS_DD", RealAdmsDateTime, ref ErrCode, ref ErrMsg))
                    {
                        if (!string.IsNullOrWhiteSpace(ErrCode) || !string.IsNullOrWhiteSpace(ErrMsg))
                            throw new Exception(string.Format("[{0}]\r\n{1}", ErrCode, ErrMsg));

                        if (DBService.HasError)
                            throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                    }

                    REAL_ADMS_DD = RealAdmsDateTime.Length >= 8 ? RealAdmsDateTime.Substring(0, 8) : string.Empty;
                    REAL_ADMS_TIME = RealAdmsDateTime.Length >= 12 ? RealAdmsDateTime.Substring(8, 4) : string.Empty;
                }
                return true;
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                //LxMessage.ShowError(ex.Message + error);
                return false;
            }
        }

        private void wf_ent_msg(string ADMS_DD, string DSCH_DD, ref string Msg1, ref string Msg2)
        {
            long Sum = 0;
            object RetVal = null;

            // 퇴원기간 내에 외래수납+청구된 자료 있을 경우 ALL
            RetVal = DBService.ExecuteScalar(SQL.CL.Sql.popJudgePatientList_InDate_OutInfo(), PID, ADMS_DD, DSCH_DD);
            if (RetVal != null)
                long.TryParse(RetVal.ToString(), out Sum);

            // 사망환자 퇴원기간 후에 외래수납+청구된 자료 있을 경우 
            // TODO : 사망진단서 테이블 확인 후 작업
        }

        public void ShowPopBatchClosePay(string StatType, string SpecFlag, string SpecStartDate, string CalStartDate, string SpecEndDate, string CalEndDate)
        {
            string ErrCode = string.Empty;
            string ErrMsg = string.Empty;

            string CMPY_DVCD_Param = CMPY_DVCD.Equals("Y") || CMPY_DVCD.Equals("T") ? "T" : "J";
            string StartDate = SpecFlag.Equals("Y") ? SpecStartDate : CalStartDate;
            string EndDate = SpecFlag.Equals("Y") ? SpecEndDate : CalEndDate;
            string REVW_DVCD = StatType;

            if (CMPY_DVCD.Equals("Y") || CMPY_DVCD.Equals("T"))
            {
                CMPY_DVCD_Param = "T";
            }
            else if (CMPY_DVCD.Equals("J"))
            {
                CMPY_DVCD_Param = DateTime.Now.ToString("yyyyMMdd").CompareTo(EndDate) > 0 ? "J" : "N";
            }
            else
            {

            }

            if ((CMPY_DVCD.Equals("J") || CMPY_DVCD.Equals("Y")) && StatType.Equals("J"))
            {
                //****************************************************************************************************
                // 중간/퇴원일 정보에 심사중 표시한다.
                //****************************************************************************************************
                if (!SQL.Procedure.PR_PA_PRC_PAAREBMACH(PID, PT_CMHS_NO, CMPY_DVCD_Param, "REVW", StartDate, REVW_DVCD, DOPack.UserInfo.USER_CD, ref ErrCode, ref ErrMsg))
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
            }
            else
            {
                //****************************************************************************************************
                // TODO : 장기재원 중간정산 입금정보에 심사중으로 표시하자.
                //****************************************************************************************************
                //if (CMPY_DVCD.Equals("I") && PT_CMHS_NO.CompareTo("0") > 0)
                //{
                //    // ls_siflag = 'N'
                //    // ll_rtn = f_accq_accipamid_column_data(ls_patno, ll_patrcno, ll_seqno, 'SIFLAG', ls_siflag, ls_msg)
                //    // IF ll_rtn < 1 THEN
                //    //     ROLLBACK USING SQLCA ;
                //    //     MessageBox('알림!', ls_msg, StopSign!)
                //    //     RETURN
                //    // END IF
                //    // IF ls_siflag <> 'Y' THEN	// 심사완료인 경우는 변경하지 말자.
                //    //     ll_rtn = f_acce_accipamid_update(ls_patno, ll_patrcno, ll_seqno, 'SIFLAG', 'J', ls_msg)
                //    //     IF ll_rtn < 1 THEN
                //    //         ROLLBACK USING SQLCA ;
                //    //         MessageBox('알림!', ls_msg, StopSign!)
                //    //         RETURN
                //    //     END IF
                //    // END IF
                //}
            }

            #region 2018-04-30 변경
            //if ((CMPY_DVCD.Equals("J") || CMPY_DVCD.Equals("Y")) && StatType.Equals("J"))
            //{
            //    //****************************************************************************************************
            //    // 중간/퇴원일 정보에 심사중 표시한다.
            //    //****************************************************************************************************
            //    if (CMPY_DVCD.Equals("Y")) // 퇴원예정
            //    {
            //        if (!SQL.Procedure.PR_PA_PRC_PAAREBMACH(PID, PT_CMHS_NO, CMPY_DVCD.Equals("Y") ? "T" : "J", "REVW", SpecFlag.Equals("Y") ? SpecStartDate : CalStartDate, "T", DOPack.UserInfo.USER_CD, ref ErrCode, ref ErrMsg))
            //            throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
            //    }
            //    else // 중간계산
            //    {
            //        if (!SQL.Procedure.PR_PA_PRC_PAAREBMACH(PID, PT_CMHS_NO, CMPY_DVCD.Equals("Y") ? "T" : "J", "REVW", SpecFlag.Equals("Y") ? SpecStartDate : CalStartDate, "J", DOPack.UserInfo.USER_CD, ref ErrCode, ref ErrMsg))
            //            throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
            //    }
            //}
            //else
            //{
            //    // TODO : 장기재원 중간정산 입금정보에 심사중으로 표시하자.
            //}
            #endregion
        }

        /// <summary>
        /// 일반입원료 증감대상자유무를 위해 주상병, 소견서 작성유무를 확인한다.
        /// </summary>
        /// <param name="admsdate"></param>
        /// <param name="insn_tycd"></param>
        /// <param name="asst_tycd"></param>
        /// <param name="drg_yn"></param>
        /// <param name="vtrn_pt_yn"></param>
        /// <param name="momr_age_dvcd"></param>
        /// <param name="indp_momr_yn"></param>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="ocrr_dvcd">발생구분코드('S: 심사', 'I: 진료/원무')</param>
        /// <returns></returns>
        public string Check_MainDiag_Opinion(DateTime admsdate, string insn_tycd, string asst_tycd, string drg_yn, string vtrn_pt_yn
                                           , string momr_age_dvcd, string indp_momr_yn, string pid, string pt_cmhs_no, string ocrr_dvcd)
        {
            string upcheck = "N";

            if (admsdate >= DateTimeService.ConvertDateTime("20160701") &&
                insn_tycd.Equals("11") &&
                asst_tycd.Equals("00") &&
                !drg_yn.Equals("Y") &&
                !(vtrn_pt_yn.Equals("Y") || momr_age_dvcd.Equals("Y") || indp_momr_yn.Equals("Y")))
            {
                object retval = DBService.ExecuteScalar(SQL.CL.Sql.FN_PA_PRC_IBILOPN(), pid, pt_cmhs_no, ocrr_dvcd);

                upcheck = (retval != null) ? retval.ToString() : string.Empty;
            }

            return upcheck;
        }

        public static bool GetOIList(DataTable DateList, ref Dictionary<string, string> ioList)
        {
            ioList = new Dictionary<string, string>();

            for (int i = 0; i < DateList.Rows.Count; i++)
            {
                string tempPtCmhsNo = DateList.Rows[i]["PT_CMHS_NO"].ToString();
                if (!ioList.ContainsKey(tempPtCmhsNo))
                {
                    string sqltext = string.Format(@"
    SELECT DISTINCT OTPT_ADMS_DVCD
      FROM ( SELECT PID, PT_CMHS_NO, 'O' AS OTPT_ADMS_DVCD
               FROM PAOPATRT
              WHERE PID           = '{0}'
                AND PT_CMHS_NO    = {1}
                AND ROW_STAT_DVCD IN ('A', 'I')
              UNION
             SELECT PID, PT_CMHS_NO, 'I' AS OTPT_ADMS_DVCD
               FROM PAIPATRT
              WHERE PID           = '{0}'
                AND PT_CMHS_NO    = {1}
                AND ROW_STAT_DVCD = 'A'
           ) ", DateList.Rows[i]["PID"].ToString(), tempPtCmhsNo);

                    string getOI = DBService.ExecuteScalar(sqltext).ToString();
                    if (DBService.HasError || StringService.IsNull(getOI))
                    {
                        LxMessage.ShowError("외래입원구분코드 취득 중 에러가 발생했습니다.");
                        return false;
                    }

                    ioList.Add(tempPtCmhsNo, getOI);
                }
            }

            return true;
        }

        /// <summary>
        /// 진료의뢰여부 및 회송여부를 저장한다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="or"></param>
        /// <param name="recall"></param>
        /// <returns></returns>
        public bool SavePATRTEIF_ETC56(string pid, string pt_cmhs_no, string or, string recall)
        {
            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePATRTEIF_ETC56()
                                         , pid, pt_cmhs_no, or, recall))
                return false;

            return true;
        }

        public bool SelectPATRTEIF_ETC56(string pid, string pt_cmhs_no, LxComboBox or_request, LxComboBox recall)
        {
            DataTable dt = new DataTable();

            if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPATRTEIF_ETC56()
                                          , ref dt
                                          , pid, pt_cmhs_no))
                return false;

            if (dt.Rows.Count > 0)
            {
                or_request.SelectedValue = dt.Rows[0]["ETC_USE_CNTS_5"].ToString();
                recall.SelectedValue = dt.Rows[0]["ETC_USE_CNTS_6"].ToString();
            }
            else
            {
                or_request.SelectedValue = "00";
                recall.SelectedValue = "00";
            }

            if (string.IsNullOrEmpty(or_request.SelectedValue))
                or_request.SelectedValue = "00";

            if (string.IsNullOrEmpty(recall.SelectedValue))
                recall.SelectedValue = "00";

            return true;
        }

        public void Visible_OR_RECALL(LxTitleLabel lbl_or_request, LxComboBox cbo_or_request, LxTitleLabel lbl_recall, LxComboBox cbo_recall)
        {
            if (ConfigService.GetConfigValueString("PA", "OR_RECALL", "OR", "N") == "Y")
            {
                lbl_or_request.Visible = true;
                cbo_or_request.Visible = true;
            }
            else
            {
                lbl_or_request.Visible = false;
                cbo_or_request.Visible = false;
            }

            if (ConfigService.GetConfigValueString("PA", "OR_RECALL", "RECALL", "N") == "Y")
            {
                lbl_recall.Visible = true;
                cbo_recall.Visible = true;
            }
            else
            {
                lbl_recall.Visible = false;
                cbo_recall.Visible = false;
            }
        }

        public string SelectOption(string system_cd, string conf_type, string conf_cd)
        {
            return DBService.ExecuteScalar(string.Format(@" SELECT CONF_VAL FROM ADCONFDT WHERE SYSTEM_CD = '{0}' AND CONF_TYPE = '{1}' AND CONF_CD = '{2}' "
                                                                        , system_cd, conf_type, conf_cd)).ToString();
        }

        public void SaveOption(string system_cd, string conf_type, string conf_cd, string conf_cdnm, string conf_val, string val_type)
        {
            try
            {
                string sqltext = string.Empty;
                string old_conf_val = SelectOption(system_cd, conf_type, conf_cd);

                if (string.IsNullOrWhiteSpace(old_conf_val))
                {
                    sqltext = string.Format(@"
    INSERT INTO ADCONFDT ( SYSTEM_CD, CONF_TYPE, CONF_CD, CONF_CDNM, CONF_VAL, 
                           VAL_TYPE, SORT_SEQ, APLY_STRT_DD, RGSTR_ID, UPDTR_ID )
                  VALUES (     '{0}',     '{1}',   '{2}',   '{3}',   '{4}',   
                               '{5}',     '{6}',   '{7}',   '@USCD', '@USCD') ", system_cd
                                                                               , conf_type
                                                                               , conf_cd
                                                                               , conf_cdnm
                                                                               , conf_val
                                                                               , val_type
                                                                               , "0"
                                                                               , "20180101");

                    if (!DBService.ExecuteNonQuery(sqltext))
                        throw new Exception("옵션 저장 중 에러가 발생했습니다. (1)");
                }
                else
                {
                    sqltext = string.Format(@" 
    UPDATE ADCONFDT 
       SET CONF_VAL  = '{3}'
         , UPDTR_ID  = '@USCD'
         , UPDT_DT   = @DT
     WHERE SYSTEM_CD = '{0}' 
       AND CONF_TYPE = '{1}' 
       AND CONF_CD   = '{2}' ", system_cd, conf_type, conf_cd, conf_val);

                    if (!DBService.ExecuteNonQuery(sqltext))
                        throw new Exception("옵션 저장 중 에러가 발생했습니다. (2)");
                }

                bool showMessage = false;
                if (showMessage)
                    LxMessage.ShowInformation("저장 되었습니다.", 2);
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        public static void CheckDyWardYnTime_PAOPATRT(string pid, string pt_cmhs_no, bool isOrderSave)
        {
            try
            {
                // +++++++++++++++++++++++++++++++++++++++++
                // 낮병동 접수내역이 존재하는지 확인한다.
                // +++++++++++++++++++++++++++++++++++++++++
                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOPATRT_DY_WARD_YN(pid, pt_cmhs_no), ref dt))
                    throw new Exception("진료시작일/종료일 조회 중 에러가 발생했습니다.");

                if (dt.Rows.Count.Equals(0))
                    throw new Exception("진료시작일/종료일 조회 중 에러가 발생했습니다.\r\n낮병동 접수 내역이 없습니다.");

                // +++++++++++++++++++++++++++++++++++++++++
                // 진료시간을 가져온다.
                // +++++++++++++++++++++++++++++++++++++++++
                string mdcr_strt_dt = dt.Rows[0]["MDCR_STRT_DT"].ToString();
                string mdcr_end_dt = dt.Rows[0]["MDCR_END_DT"].ToString();

                mdcr_strt_dt = mdcr_strt_dt.Length.Equals(12) ? string.Format("{0}00", mdcr_strt_dt) : mdcr_strt_dt;
                mdcr_end_dt = mdcr_end_dt.Length.Equals(12) ? string.Format("{0}00", mdcr_end_dt) : mdcr_end_dt;

                string mdcr_strt_dt_format = DateTimeService.IsDateTime(mdcr_strt_dt) ? DateTimeService.ConvertDateTime(mdcr_strt_dt).ToString("yyyy-MM-dd HH:mm:ss") : mdcr_strt_dt;
                string mdcr_end_dt_format = DateTimeService.IsDateTime(mdcr_end_dt) ? DateTimeService.ConvertDateTime(mdcr_end_dt).ToString("yyyy-MM-dd HH:mm:ss") : mdcr_end_dt;

                object RetVal = DBService.ExecuteScalar(string.Format(SQL.Function.FN_AD_PRC_MINUTECALC(), "S", mdcr_strt_dt, mdcr_end_dt));

                if (RetVal == null || string.IsNullOrWhiteSpace(RetVal.ToString()))
                    throw new Exception(string.Format("진료 시간을 조회하는 중 에러가 발생했습니다.\r\n\r\n진료시작일시 : {0}\r\n진료종료일시 : {1}", mdcr_strt_dt_format, mdcr_end_dt_format));

                // +++++++++++++++++++++++++++++++++++++++++
                // 360분 미만인 경우는 에러.
                // +++++++++++++++++++++++++++++++++++++++++
                int.TryParse(RetVal.ToString(), out int minute);
                if (minute < 360)
                {
                    dt.Reset();
                    if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectDY_WARD_YN_HOUR_MIN(mdcr_strt_dt, mdcr_end_dt), ref dt))
                        throw new Exception(string.Format("진료 시간을 조회하는 중 에러가 발생했습니다.\r\n(시간/분 계산 실패)\r\n\r\n진료시작일시 : {0}\r\n진료종료일시 : {1}", mdcr_strt_dt_format, mdcr_end_dt_format));

                    if (dt.Rows.Count.Equals(0))
                        throw new Exception(string.Format("진료 시간을 조회하는 중 에러가 발생했습니다.\r\n(시간/분 계산 실패)\r\n\r\n진료시작일시 : {0}\r\n진료종료일시 : {1}", mdcr_strt_dt_format, mdcr_end_dt_format));

                    throw new Exception(string.Format("낮병동 접수된 환자는 진료시간이 6시간이상이어야\r\n합니다.\r\n{4}진료시간을 다시 설정해 주세요.\r\n\r\n진료시작일시 : {0}\r\n진료종료일시 : {1}\r\n현재 진료 시간 : {2}시간 {3}분"
                                            , mdcr_strt_dt_format, mdcr_end_dt_format, dt.Rows[0]["HOUR"].ToString(), dt.Rows[0]["MIN"].ToString(), isOrderSave ? string.Empty : "진료과에 연락하여 "));
                }
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        public static void CheckDyWardYnTime_CLISSPBD(string clam_uniq_no, string pid, string clam_sqno)
        {
            try
            {
                // +++++++++++++++++++++++++++++++++++++++++
                // MS005 가 존재하는 지 확인
                // +++++++++++++++++++++++++++++++++++++++++
                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.CL.Sql.SelectCLISSPBD_MS005(clam_uniq_no, pid, clam_sqno), ref dt))
                    throw new Exception("특정내역(MS005:낮병동/응급센터 재원시간) 조회 중 에러가 발생했습니다.");

                if (dt.Rows.Count.Equals(0))
                    return;

                if (!dt.Rows[0]["SPBD_CNTS"].ToString().Length.Equals(25))
                    throw new Exception(string.Format("특정내역(MS005:낮병동/응급센터 재원시간)이 잘 못 입력되었습니다.\r\n확인해 주세요.\r\n\r\n입력 값 : {0}", dt.Rows[0]["SPBD_CNTS"].ToString()));

                // +++++++++++++++++++++++++++++++++++++++++
                // MS005의 시간을 확인한다.
                // +++++++++++++++++++++++++++++++++++++++++
                string mdcr_strt_dt = dt.Rows[0]["SPBD_CNTS"].ToString().Substring(0, 12);
                string mdcr_end_dt = dt.Rows[0]["SPBD_CNTS"].ToString().Substring(13, 12);

                mdcr_strt_dt = mdcr_strt_dt.Length.Equals(12) ? string.Format("{0}00", mdcr_strt_dt) : mdcr_strt_dt;
                mdcr_end_dt = mdcr_end_dt.Length.Equals(12) ? string.Format("{0}00", mdcr_end_dt) : mdcr_end_dt;

                string mdcr_strt_dt_format = DateTimeService.IsDateTime(mdcr_strt_dt) ? DateTimeService.ConvertDateTime(mdcr_strt_dt).ToString("yyyy-MM-dd HH:mm:ss") : mdcr_strt_dt;
                string mdcr_end_dt_format = DateTimeService.IsDateTime(mdcr_end_dt) ? DateTimeService.ConvertDateTime(mdcr_end_dt).ToString("yyyy-MM-dd HH:mm:ss") : mdcr_end_dt;

                object RetVal = DBService.ExecuteScalar(string.Format(SQL.Function.FN_AD_PRC_MINUTECALC(), "S", mdcr_strt_dt, mdcr_end_dt));
                if (RetVal == null || string.IsNullOrWhiteSpace(RetVal.ToString()))
                    throw new Exception(string.Format("진료 시간을 조회하는 중 에러가 발생했습니다.\r\n\r\n진료시작일시 : {0}\r\n진료종료일시 : {1}", mdcr_strt_dt_format, mdcr_end_dt_format));

                // +++++++++++++++++++++++++++++++++++++++++
                // 360분 미만인 경우는 에러.
                // +++++++++++++++++++++++++++++++++++++++++
                int.TryParse(RetVal.ToString(), out int minute);
                if (minute < 360)
                {
                    // +++++++++++++++++++++++++++++++++++++++++
                    // 낮병동 입원료가 존재하지 않으면 리턴.
                    // +++++++++++++++++++++++++++++++++++++++++
                    int dy_ward_yn_count = DBService.ExecuteInteger(SQL.CL.Sql.SelectCLIPRSBD_DY_WARD_YN(clam_uniq_no, pid, clam_sqno));
                    if (dy_ward_yn_count.Equals(0))
                        return;

                    dt.Reset();
                    if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectDY_WARD_YN_HOUR_MIN(mdcr_strt_dt, mdcr_end_dt), ref dt))
                        throw new Exception(string.Format("진료 시간을 조회하는 중 에러가 발생했습니다.\r\n(시간/분 계산 실패)\r\n\r\n진료시작일시 : {0}\r\n진료종료일시 : {1}", mdcr_strt_dt_format, mdcr_end_dt_format));

                    if (dt.Rows.Count.Equals(0))
                        throw new Exception(string.Format("진료 시간을 조회하는 중 에러가 발생했습니다.\r\n(시간/분 계산 실패)\r\n\r\n진료시작일시 : {0}\r\n진료종료일시 : {1}", mdcr_strt_dt_format, mdcr_end_dt_format));

                    throw new Exception(string.Format("낮병동 접수된 환자는 진료시간이 6시간이상이어야\r\n합니다.\r\n특정내역(MS005)의 진료시간을 다시 입력해 주세요.\r\n\r\n진료시작일시 : {0}\r\n진료종료일시 : {1}\r\n현재 진료 시간 : {2}시간 {3}분", mdcr_strt_dt_format, mdcr_end_dt_format, dt.Rows[0]["HOUR"].ToString(), dt.Rows[0]["MIN"].ToString()));
                }
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        public static List<string> ConvertTextList(string text, int cutByte)
        {
            List<string> list = new List<string>();

            string[] a = text.Split(new char[] { '\r', '\n' }, StringSplitOptions.None);
            foreach (string str in a)
            {
                char[] btChars = str.ToCharArray();

                string addtext = string.Empty;
                int i = -1;

                foreach (byte b in btChars)
                {
                    i++;
                    if (StringService.ByteCount(addtext + btChars[i]) > cutByte)
                    {
                        list.Add(addtext);
                        addtext = string.Empty;
                        addtext += btChars[i];
                    }
                    else
                    {
                        addtext += btChars[i];
                    }
                }

                if (StringService.IsNotNull(addtext))
                    list.Add(addtext);
            }

            return list;
        }

        public static void CheckVCode(string clam_uniq_no, string pid, string clam_sqno)
        {
            // 중증환자 등록번호가 존재하는 지 확인한다.
            int cnt = DBService.ExecuteInteger(SQL.CL.Sql.SelectCountSpbdDvcd(clam_uniq_no, pid, clam_sqno, "MT014"));
            if (cnt.Equals(0))
                return;

            // 제대로 된 중증환자 등록번호인지 체크한다.
            string errorCode = string.Empty;
            string errorMsg = string.Empty;

            if (!SQL.Procedure.PR_CL_READ_CLISSPETCCHEK1(clam_uniq_no, pid, clam_sqno, "MT014", ref errorCode, ref errorMsg))
                throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

            if (errorCode == "9")
                throw new Exception(errorMsg);
        }

        public static void PrintDrug(int drug_sqno, int psyc_sqno_2, string pid, string pt_cmhs_no, string dlwt_uniq_no, bool IsDC, ref string errmsg)
        {
            // 마약 처방전 출력
            if (drug_sqno > 0)
            {
                if (!ORBizCommon.UpdateORSQTPIF_DLWT_YN_Y(pid, pt_cmhs_no, dlwt_uniq_no, "DRUG_PRINT"))
                {
                    errmsg = "마약처방전 출력 중 오류가 발생했습니다.";
                    throw new Exception(errmsg);
                }

                DataTable printdt = ORBizCommon.PrintPrescribeDrug(pid, pt_cmhs_no, dlwt_uniq_no, false, IsDC ? "DC" : string.Empty);
                if (!printdt.Rows.Count.Equals(0))
                {
                    using (clsPrescribeDrug prt = new clsPrescribeDrug())
                        prt.Print(false, printdt, false);
                }
            }

            // 향정 처방전 출력
            if (psyc_sqno_2 > 0)
            {
                if (!ORBizCommon.UpdateORSQTPIF_DLWT_YN_Y(pid, pt_cmhs_no, dlwt_uniq_no, "PSYC_PRINT"))
                {
                    errmsg = "향정처방전 출력 중 오류가 발생했습니다.";
                    throw new Exception(errmsg);
                }

                DataTable printdt2 = ORBizCommon.PrintPrescribePsyco(pid, pt_cmhs_no, dlwt_uniq_no, false, IsDC ? "DC" : string.Empty);
                if (!printdt2.Rows.Count.Equals(0))
                {
                    using (clsPrescribePsyco prt = new clsPrescribePsyco())
                        prt.Print(false, printdt2, false);
                }
            }
        }

        public static void PrintDrug(string pid, string pt_cmhs_no, string dlwtuniqno)
        {
            // 마약처방전 출력
            if (ConfigService.GetConfigValueBool("PM", "PM_PRINT_DRUG_YN", "PM_PRINT_DRUG_YN"))
            {
                DataTable printdt = ORBizCommon.PrintPrescribeDrug(pid, pt_cmhs_no, dlwtuniqno, false, "DC");
                if (!printdt.Rows.Count.Equals(0))
                {
                    using (clsPrescribeDrug prt = new clsPrescribeDrug())
                        prt.Print(false, printdt, false);
                }
            }

            // 향정처방전 출력
            if (ConfigService.GetConfigValueBool("PM", "PM_PRINT_PSYCO_YN", "PM_PRINT_PSYCO_YN"))
            {
                DataTable printdt2 = ORBizCommon.PrintPrescribePsyco(pid, pt_cmhs_no, dlwtuniqno, false, "DC");
                if (!printdt2.Rows.Count.Equals(0))
                {
                    using (clsPrescribePsyco prt = new clsPrescribePsyco())
                        prt.Print(false, printdt2, false);
                }
            }
        }

        public static bool CheckPeriod_IncsDrYn(string pid, string pt_cmhs_no, string cmpy_strt_dd, string cmpy_end_dd, string message_type, ref string message)
        {
            // 계산적용코드관리에서 산재관리의사 지정 적용 여부를 읽는다
            // 2021-01-28 SJH 현재, 오송만 적용됨
            if (!DBService.ExecuteScalar(SQL.Function.SelectFN_BI_READ_BICARAMA(), "INCS_DV_YN", cmpy_strt_dd, "A", "1", "").ToString().Equals("Y"))
                return true;

            // 기간 중에 산재지정의가 포함되어 있는 경우를 체크하자.
            string sqltext = $@"
    SELECT APLY_STRT_DD, APLY_END_DD, MDCR_DR_CD, INSN_TYCD, ASST_TYCD
         , FN_PA_READ_INCSAFFRDVCD(PID, APLY_STRT_DD)    AS INCS_AFFR_PRIZ_CD  -- 산재 or 후유
         , FN_CL_READ_INCSDRYN(APLY_STRT_DD, MDCR_DR_CD) AS INCS_APLY_DVCD     -- 산재지정의 여부
      FROM PAIPCHMA
     WHERE PID           = '{pid}'
       AND PT_CMHS_NO    = {pt_cmhs_no}
       AND ('{cmpy_strt_dd}' BETWEEN APLY_STRT_DD AND APLY_END_DD
         OR '{cmpy_end_dd}' BETWEEN APLY_STRT_DD AND APLY_END_DD) ";

            DataTable dt = new DataTable();
            if (!DBService.ExecuteDataTable(sqltext, ref dt))
                throw new Exception("정산기간내에 산재지정의가 있는지를 조회하는 중 오류가 발생했습니다.");

            if (message_type.Equals("CL_PREV"))
            {
                // 사전심사인 경우, 산재지정의가 맞는지만 확인한다.
                int incs_aply_dvcd_count = dt.AsEnumerable().Where(r => (r["INSN_TYCD"].ToString().Equals("31") && r["ASST_TYCD"].ToString().Equals("00") &&
                                                                         r["INCS_AFFR_PRIZ_CD"].ToString().Equals("S") && r["INCS_APLY_DVCD"].ToString().Equals("Y"))).Count();

                if (incs_aply_dvcd_count > 0)
                    message = "★산재지정의";
            }
            else
            {
                // 입원정보변경내역에 여러건이 있고, 산재지정의가 있는 경우
                if (dt.Rows.Count > 1)
                {
                    int incs_aply_dvcd_count = dt.AsEnumerable().Where(r => (r["INSN_TYCD"].ToString().Equals("31") && r["ASST_TYCD"].ToString().Equals("00") &&
                                                                             r["INCS_AFFR_PRIZ_CD"].ToString().Equals("S") && r["INCS_APLY_DVCD"].ToString().Equals("Y"))).Count();

                    if (incs_aply_dvcd_count > 0 && incs_aply_dvcd_count != dt.Rows.Count)
                    {
                        message = message_type.Equals("PA") ? "해당 기간내에 [산재지정의]가 진료의로 설정된 기간이\r\n존재하여, 기간을 분리하여 생성해야합니다." :
                                  message_type.Equals("DSCH_MAIN") ? "퇴원등록 기간내에 [산재지정의]가 진료의로 설정된 기간이 존재하여, 기간을 분리하여 퇴원등록해야합니다.\r\n원무과에 연락해 주세요." :
                                  message_type.Equals("DSCH_SUB") ? "부입원 퇴원등록 기간내에 [산재지정의]가 진료의로 설정된 기간이 존재하여, 기간을 분리하여 퇴원등록해야합니다.\r\n원무과에 연락해 주세요." :
                                  string.Empty;

                        return false;
                    }
                }
            }

            return true;
        }

        public static bool Is_INCS_DR_YN(string pid, string pt_cmhs_no, string insn_tycd, string asst_tycd, string mdcr_dd, string mdcr_dr_cd)
        {
            // 계산적용코드관리에서 산재관리의사 지정 적용 여부를 읽는다
            // 2021-01-28 SJH 현재, 오송만 적용됨
            if (!DBService.ExecuteScalar(SQL.Function.SelectFN_BI_READ_BICARAMA(), "INCS_DV_YN", mdcr_dd, "A", "1", "").ToString().Equals("Y"))
                return false;

            if (!insn_tycd.Equals("31") || !asst_tycd.Equals("00"))
                return false;

            // 산재or후유 중 산재가 아닌 경우
            if (!DBService.ExecuteScalar(SQL.Function.FN_PA_READ_INCSAFFRDVCD(pid, mdcr_dd)).ToString().Equals("S"))
                return false;

            // 의사가 지정의가 아니면
            if (!DBService.ExecuteScalar(SQL.Function.FN_CL_READ_INCSDRYN(mdcr_dd, mdcr_dr_cd)).ToString().Equals("Y"))
                return false;

            // 관리의사가 아니면
            if (!DBService.ExecuteScalar(SQL.Function.FN_PA_READ_PATRTEIF(), pid, pt_cmhs_no, "ETC_USE_CNTS_23").ToString().Equals("0"))
                return false;

            return true;
        }

        /// <summary>
        /// 미입고내역이 존재하는지 확인한다.
        /// </summary>
        /// <returns></returns>
        private static DataTable m_CheckErpDt = null;
        private static bool m_IsDressingTeam = false;
        public static void CheckNoInputItems_ERP(BaseMDI mdi)
        {
            string conf_cd = $"{mdi.SystemCode}_SHOW_INT_MSG";
            if (!ConfigService.GetConfigValueDirect("%", "STCK_USE_YN", conf_cd, "N").Equals("Y"))
                return;

            string aply_strt_dd = DateTime.Today.AddDays(-1).ToString("yyyyMMdd");
            string aply_end_dd = DateTime.Today.ToString("yyyyMMdd");

            // 미입고내역 조회
            string sqltext = string.Empty;

            if (m_CheckErpDt == null)
            {
                m_CheckErpDt = new DataTable();

                // 드레싱팀인지 체크하자.
                sqltext = $@"
   SELECT COUNT(1) 
     FROM BICDINDT 
    WHERE OVRL_CD      = 'DRES_NURSE_DVCD' 
      AND LWRN_OVRL_CD = '{DOPack.UserInfo.USER_CD}' 
      AND TO_CHAR(SYSDATE, 'YYYYMMDD') BETWEEN APLY_STRT_DD AND APLY_END_DD ";

                var temp = DBService.ExecuteInteger(sqltext);
                m_IsDressingTeam = temp > 0;
            }

            m_CheckErpDt.Reset();

            sqltext = $@"
   SELECT INT_STR_CD
        , (SELECT Z.STR_NM
             FROM EPSTRGMA Z
            WHERE Z.USE_YN = 'Y'
              AND Z.STR_CD = A.INT_STR_CD
              AND Z.SQNO = (SELECT MAX(X.SQNO) FROM EPSTRGMA X WHERE X.STR_CD = Z.STR_CD))   AS INT_STR_NM
        , COUNT(*) AS CNT
     FROM EPOUTRRT A
    WHERE A.OUT_DD BETWEEN '{aply_strt_dd}' AND '{aply_end_dd}'
      AND A.INT_DEPT_CD     = '{(m_IsDressingTeam ? "DRS" : DOPack.UserInfo.DEPT_CD)}'  -- 외래간호의 경우에도, 같은 주사실창고지만 입고부서가 다른 경우가 있기 때문에 이 조건 필요 함 
      AND A.INT_YN          = 'N'
      AND A.DEL_YN          = 'A'
 GROUP BY INT_STR_CD ";

            if (DBService.ExecuteDataTable(sqltext, ref m_CheckErpDt))
            {
                if (m_CheckErpDt.Rows.Count.Equals(0))
                    return;

                string message = string.Empty;
                for (int i = 0; i < m_CheckErpDt.Rows.Count; i++)
                    message += $"\r\n   - [{m_CheckErpDt.Rows[i]["INT_STR_NM"].ToString()}] {m_CheckErpDt.Rows[i]["CNT"].ToString().PadLeft(3, ' ')} 건";

                if (!LxMessage.ShowQuestion($"미입고내역이 존재합니다.{message}\r\n\r\n[부서별 입출고 관리]화면으로 바로 이동하시겠습니까?").Equals(DialogResult.Yes))
                    return;

                ScreenParameters param = new ScreenParameters()
                {
                    { "STR_CD", m_CheckErpDt.Rows[0]["INT_STR_CD"].ToString() },
                    { "APLY_STRT_DD",  aply_strt_dd },
                    { "APLY_END_DD",  aply_end_dd },
                };

                mdi.CallScreen("Lime.BI.dll", "Lime.BI.ucfDeptStorageIOManagerE", "부서별 입출고 관리", param);
            }
        }

        public static void CheckNoRcpnLoss_ERP(BaseMDI mdi)
        {
            try
            {
                if (!ConfigService.GetConfigValueBool("%", "STCK_USE_YN", "STCK_USE_YN"))
                    return;

                DataTable dt = new DataTable();

                if (!DBService.ExecuteDataTable(SQL.BI.Sql.SelectEPLOSSMA_ReqList(), ref dt, DateTime.Now.AddDays(-1).ToString("yyyyMMdd"), DateTime.Now.ToString("yyyyMMdd"), "%", "%", DOPack.UserInfo.DEPT_CD))
                    throw new Exception($"[{DBService.ErrorCode}] {DBService.ErrorMessage}");

                if (dt.Rows.Count <= 0)
                    return;

                string message = string.Empty;
                string strt_dd = string.Empty;
                string end_dd = string.Empty;

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (double.TryParse(dt.Rows[i]["DBT_CNT"].ToString(), out double dbt_cnt) && double.TryParse(dt.Rows[i]["DRST_CNT"].ToString(), out double drst_cnt) && dbt_cnt != drst_cnt)
                    {
                        string occr_dd = dt.Rows[i]["OCCR_DD"].ToString();
                        string occr_dept_nm = dt.Rows[i]["OCCR_DEPT_NM"].ToString();
                        string qi_item_dvnm = dt.Rows[i]["QI_ITEM_DVCDNM"].ToString();

                        if (string.IsNullOrWhiteSpace(strt_dd) || DateTimeService.ConvertDateTime(occr_dd) < DateTimeService.ConvertDateTime(strt_dd))
                            strt_dd = occr_dd;

                        if (string.IsNullOrWhiteSpace(end_dd) || DateTimeService.ConvertDateTime(occr_dd) > DateTimeService.ConvertDateTime(end_dd))
                            end_dd = occr_dd;

                        message += $"\r\n   - [{DateTimeService.ConvertDateStringToFormatString(occr_dd)}] {occr_dept_nm} - {qi_item_dvnm}";
                    }
                }

                if (string.IsNullOrWhiteSpace(message))
                    return;

                if (LxMessage.ShowQuestion($"손망실 미접수내역이 존재합니다.{message}\r\n\r\n[손망실 신청접수] 화면으로 바로 이동하시겠습니까?") != DialogResult.Yes)
                    return;

                ScreenParameters param = new ScreenParameters
            {
                { "APLY_STRT_DD", strt_dd },
                { "APLY_END_DD", end_dd },
            };

                mdi.CallScreen("Lime.BI.dll", "Lime.BI.ucfErpLossReceipt", "손망실 신청접수", param);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        public static bool UpdateADUNIQSQ_ORSEORDT_ORSEDSDT(string table_name, string prst_uniq_no)
        {
            if (!prst_uniq_no.Length.Equals(13))
                return true;

            // 약속테이블의 Max SQNO
            string sqltext = $@"
 SELECT NVL(MAX(SQNO), 0) 
   FROM {table_name} 
  WHERE PRST_UNIQ_NO = '{prst_uniq_no}' ";

            int table_sqno = DBService.ExecuteInteger(sqltext);
            if (table_sqno <= 0)
                return true;

            // 테이블고유번호 생성관리 테이블의 Max SQNO
            sqltext = $@" 
 SELECT DTTB_SQNO 
   FROM ADUNIQSQ 
  WHERE DTTB_PHLW_ID = '{table_name}' 
    AND APLY_CNTS_1  = '{prst_uniq_no.Substring(0, 4)}'  
    AND APLY_CNTS_2  = '{prst_uniq_no.Substring(4, 2)}'  
    AND APLY_CNTS_3  = '{prst_uniq_no.Substring(6, 2)}'  
    AND APLY_CNTS_4  = '{prst_uniq_no.Substring(8, 5)}' ";

            var uniqsq_sqno = DBService.ExecuteInteger(sqltext);

            // 약속테이블의 SQNO 를 테이블고유번호 생성관리 테이블에 저장한다.
            if (uniqsq_sqno.Equals(-1))
            {
                sqltext = $@"
 INSERT INTO ADUNIQSQ
           (DTTB_PHLW_ID, APLY_CNTS_1, APLY_CNTS_2, APLY_CNTS_3, APLY_CNTS_4, APLY_CNTS_5, DTTB_SQNO)
   VALUES  ('{table_name}', '{prst_uniq_no.Substring(0, 4)}', '{prst_uniq_no.Substring(4, 2)}', '{prst_uniq_no.Substring(6, 2)}', '{prst_uniq_no.Substring(8, 5)}', 'N', {table_sqno}) ";
            }
            else if (table_sqno <= uniqsq_sqno)
            {
                return true;
            }
            else
            {
                sqltext = $@"
 UPDATE ADUNIQSQ
    SET DTTB_SQNO = '{table_sqno}'
  WHERE DTTB_PHLW_ID = '{table_name}' 
    AND APLY_CNTS_1  = '{prst_uniq_no.Substring(0, 4)}'  
    AND APLY_CNTS_2  = '{prst_uniq_no.Substring(4, 2)}'  
    AND APLY_CNTS_3  = '{prst_uniq_no.Substring(6, 2)}'  
    AND APLY_CNTS_4  = '{prst_uniq_no.Substring(8, 5)}' ";
            }

            if (!DBService.ExecuteNonQuery(sqltext))
                return false;

            return true;
        }

        public static bool SaveAutoPrscData(bool setTran, string system_cd, string conf_type, string pid, string pt_cmhs_no, string mdcr_dd, ref string msg)
        {
            try
            {
                DataTable dtPrscOption = ConfigService.GetConfigListDirect(system_cd, conf_type);

                if (dtPrscOption.Rows.Count <= 0)
                    return true;

                var prscOptions = dtPrscOption.AsEnumerable();

                if (prscOptions.FirstOrDefault(x => x["CONF_CD"].ToString() == "USE_YN" && x["CONF_VAL"].ToString() == "Y") == null)
                    return true;

                List<string> lstIlns = new List<string>();
                Dictionary<clsBIMFCDMA, string> dicPrsc = new Dictionary<clsBIMFCDMA, string>();

                prscOptions.ToList().ForEach(x =>
                {
                    string conf_cd = x["CONF_CD"].ToString();
                    string conf_val = x["CONF_VAL"].ToString();

                    if (conf_cd.IndexOf("ILNS_CD") == 0 && !lstIlns.Contains(conf_val))
                        lstIlns.Add(conf_val);

                    if (conf_cd.IndexOf("PRSC_CD") == 0)
                    {
                        // 처방 조회
                        if (!clsMefeSearch.SearchMefeCode(MefeSearchType.MEFE_CD, MefeSearchIOType.All, conf_val, mdcr_dd, out clsBIMFCDMA mefe2, out string msgMefe2))
                            throw new Exception(msgMefe2);

                        dicPrsc.Add(mefe2, prscOptions.FirstOrDefault(y => y["CONF_CD"].ToString() == conf_cd.Replace("PRSC_CD", "SPCM_CD"))?["CONF_VAL"]?.ToString() ?? "");
                    }
                });

                if (lstIlns.Count <= 0 && dicPrsc.Count <= 0)
                    throw new Exception($"상병/처방 옵션값이 비어있습니다.");

                string currentDate = DateTime.Now.ToString("yyyyMMddHHmmss");
                string currentTime = DateTime.Now.ToString("HHmmss");

                // 접수정보 조회
                DataTable dtOpa = new DataTable();

                if (!DBService.ExecuteDataTable(SQL.PA.Sql.GetPAOPATRT(), ref dtOpa, pid, pt_cmhs_no))
                    throw new Exception($"접수정보 조회 중 오류가 발생하였습니다.");

                if (dtOpa.Rows.Count <= 0)
                    throw new Exception("조회된 접수정보가 존재하지 않습니다.");

                string covid = DBService.ExecuteScalar(SQL.PA.Sql.SelectPATRTEIF_ETC21(pid, pt_cmhs_no)).ToString();

                string rcpn_sqno = dtOpa.Rows[0]["RCPN_SQNO"].ToString();

                // 상병 조회
                DataTable dtDis = new DataTable();

                if (lstIlns.Count > 0)
                {
                    for (int i = 0; i < lstIlns.Count; i++)
                    {
                        DataTable dtDisTemp = new DataTable();

                        if (!DBService.ExecuteDataTable(SQL.OR.Sql.SelectBIDSCDMA(), ref dtDisTemp, "%", "ILNS_CD", lstIlns[i], mdcr_dd))
                            throw new Exception($"상병 조회 중 오류가 발생하였습니다.");

                        if (dtDisTemp.Rows.Count <= 0)
                            throw new Exception($"{lstIlns[i]} 해당 상병이 존재하지 않습니다.");

                        if (dtDis.Columns.Count <= 0)
                            dtDis = dtDisTemp.Clone();

                        dtDis.Rows.Add(dtDisTemp.Rows[0].ItemArray);
                    }
                }

                // 처방 -> 검체 조회
                if (dicPrsc.Count > 0)
                {
                    foreach (var kvp in dicPrsc)
                    {
                        if (!string.IsNullOrWhiteSpace(kvp.Value))
                        {
                            DataTable dtSpcm = new DataTable();

                            if (!DBService.ExecuteDataTable(SQL.OR.Sql.SelectSpcmlist(), ref dtSpcm, kvp.Key.MEFE_CD, mdcr_dd))
                                throw new Exception($"검체 조회 중 오류가 발생하였습니다");

                            if (dtSpcm.Rows.Count <= 0 || !dtSpcm.AsEnumerable().Any(x => x["SPCM_CD"].ToString() == kvp.Value))
                                throw new Exception($"해당 검체가 존재하지 않습니다.\r\n\r\n처방코드 : {kvp.Key.MEFE_CD}\r\n검체코드 : {kvp.Value}");
                        }
                        else if (new string[] { "40", "41" }.Any(s => s == kvp.Key.PRSC_LCLS_CD))
                            throw new Exception($"{kvp.Key.MEFE_CD} 해당 검사처방의 검체코드 옵션값이 비어있습니다.");
                    }
                }

                if (setTran)
                    DBService.BeginTransaction();

                // 상병 저장
                for (int i = 0; i < dtDis.Rows.Count; i++)
                {
                    string ilns_dvcd = i == 0 && DBService.ExecuteInteger(SQL.OR.Sql.SelectMainDisCount(), pid, pt_cmhs_no, "O") <= 0 ? "1" : "2";
                    string ilns_prsc_sqno = DBService.ExecuteScalar(SQL.OR.Sql.SelectIlnsPrscSqnoORDISRRT(), pid, pt_cmhs_no, mdcr_dd).ToString();

                    if (!DBService.ExecuteNonQuery(SQL.OR.BaseSql.Insert.ORDISRRT()
                        , pid
                        , pt_cmhs_no
                        , mdcr_dd
                        , ilns_prsc_sqno
                        , "O"
                        , ilns_dvcd
                        , dtDis.Rows[i]["ILNS_CD"].ToString()
                        , dtDis.Rows[i]["ILNS_CD_SQNO"].ToString()
                        , dtDis.Rows[i]["ILNS_CD_HNM"].ToString()
                        , dtDis.Rows[i]["ILNS_CD_ENM"].ToString()
                        , dtOpa.Rows[0]["MDCR_DEPT_CD"].ToString()
                        , dtOpa.Rows[0]["MDCR_DR_CD"].ToString()
                        , dtOpa.Rows[0]["REAL_MDCR_DR_CD"].ToString()
                        , "N" //RLOT_YN
                        , "N" //OP_YN
                        , "00000000" // DNFR_RGUP_CNTS
                        , "00000000" // DNFR_LFUP_CNTS
                        , "00000000" // DNFR_RGHT_LOW_CNTS
                        , "00000000" // DNFR_LEFT_LOW_CNTS
                        , dtDis.Rows[i]["CFSC_CD"].ToString()
                        , dtDis.Rows[i]["CHRN_DSSE_YN"].ToString()
                        , "N" // RROB_DSSE_YN
                        , "" // ILNS_SITE_NM
                        , "" // ILNS_TNM_CLSF_BRKD
                        , "" // POA_DVCD
                        , dtDis.Rows[i]["SORT_SEQ"].ToString()
                        , dtDis.Rows[i]["CLAM_ILNS_CD"].ToString()
                        , "" // ADMS_ILNS_YN      
                        , "A"
                        , "", "", "", "", ""
                        , ClientEnvironment.IP
                        , currentDate
                        , dtOpa.Rows[0]["MDCR_DR_CD"].ToString()
                        , currentDate
                        , dtOpa.Rows[0]["MDCR_DR_CD"].ToString()
                        ))
                        throw new Exception($"상병 저장 중 오류가 발생하였습니다.");
                }

                // 처방 저장
                foreach (var kvp in dicPrsc)
                {
                    string prsc_sqno = DBService.ExecuteScalar(SQL.OR.Sql.SelectMaxSqnoORORDRRT(), pid, pt_cmhs_no, mdcr_dd).ToString();
                    string prsc_sort_seq = DBService.ExecuteScalar(SQL.OR.Sql.SelectMaxPrscSortSeqORORDRRT(), pid, pt_cmhs_no, mdcr_dd).ToString();
                    string pnpy_dvcd = string.Empty;
                    string vtrn_pt_yn = dtOpa.Rows[0]["VTRN_PT_YN"].ToString();

                    var mefe = kvp.Key;
                    string spcm_cd = kvp.Value;

                    if (covid == "CVD19")
                        pnpy_dvcd = "1";
                    else if (new string[] { "7001", "7002", "7003", "7004" }.Any(s => s == dtOpa.Rows[0]["MDCR_DEPT_CD"].ToString()))
                        pnpy_dvcd = "5";
                    else
                    {
                        switch (StringService.SubString(dtOpa.Rows[0]["INSN_TYCD"].ToString(), 1))
                        {
                            case "1":
                                if (vtrn_pt_yn == "Y" && mefe.VTRN_APLY_YN == "Y")
                                    pnpy_dvcd = mefe.VTRN_PAY_DVCD;
                                else
                                    pnpy_dvcd = mefe.HLNS_PAY_DVCD;
                                break;

                            case "2":
                                if (vtrn_pt_yn == "Y" && mefe.VTRN_APLY_YN == "Y")
                                    pnpy_dvcd = mefe.VTRN_PAY_DVCD;
                                else
                                    pnpy_dvcd = mefe.MDAD_PAY_DVCD;
                                break;

                            case "3":
                                pnpy_dvcd = mefe.INCS_PAY_DVCD;
                                break;

                            case "4":
                                pnpy_dvcd = mefe.TRAI_PAY_DVCD;
                                break;

                            case "5":
                                if (vtrn_pt_yn == "Y" && mefe.VTRN_APLY_YN == "Y")
                                    pnpy_dvcd = mefe.VTRN_PAY_DVCD;
                                else
                                    pnpy_dvcd = mefe.GNRL_PAY_DVCD;
                                break;

                            default:
                                pnpy_dvcd = mefe.HLNS_PAY_DVCD;
                                break;
                        }
                    }

                    if (!DBService.ExecuteNonQuery(SQL.OR.BaseSql.Insert.ORORDRRT()
                        , pid
                        , pt_cmhs_no
                        , mdcr_dd
                        , prsc_sqno
                        , dtOpa.Rows[0]["MDCR_DEPT_CD"].ToString() == "2400" ? "9" : "00"
                        , prsc_sort_seq
                        , "O"
                        , "O"
                        , currentTime
                        , dtOpa.Rows[0]["MDCR_DEPT_CD"].ToString()
                        , dtOpa.Rows[0]["MDCR_DR_CD"].ToString()
                        , dtOpa.Rows[0]["REAL_MDCR_DR_CD"].ToString()
                        , mefe.DLVR_DEPT_CD
                        , dtOpa.Rows[0]["MDCR_DEPT_CD"].ToString()
                        , mefe.VIST_PLCE_CD
                        , "" // WARD_CD
                        , mefe.PRSC_LCLS_CD
                        , mefe.PRSC_MCLS_CD
                        , mefe.MEFE_CD
                        , mefe.MEFE_HNM
                        , "1"
                        , "1"
                        , "1"
                        , "1"
                        , "1"
                        , "1"
                        , "1"
                        , ""
                        , "1"
                        , "1"
                        , "1"
                        , ""
                        , ""
                        , ""
                        , ""
                        , ""
                        , ""
                        , ""
                        , "N"
                        , "N"
                        , "NO"
                        , "NO"
                        , pnpy_dvcd
                        , "N"
                        , "N"
                        , mdcr_dd
                        , ""
                        , "A"
                        , pt_cmhs_no
                        , mdcr_dd
                        , prsc_sqno
                        , "A"
                        , "N"
                        , "N"
                        , ""
                        , ""
                        , ""
                        , ""
                        , ""
                        , ""
                        , "000"
                        , ""
                        , ""
                        , mefe.PRSC_CLSF_CD
                        , ""
                        , ""
                        , ""
                        , ""
                        , "D"
                        , mefe.MAIN_INGR_CD
                        , spcm_cd
                        , "N"
                        , ""
                        , ""
                        , ""
                        , ""
                        , "N"
                        , ""
                        , ""
                        , ""
                        , "A"
                        , "N"
                        , ""
                        , ""
                        , "N"
                        , ""
                        , ""
                        , "N"
                        , ""
                        , ""
                        , ""
                        , "N"
                        , ""
                        , ""
                        , "N"
                        , ""
                        , ""
                        , "N"
                        , ""
                        , ""
                        , "N"
                        , "N"
                        , "NULL"
                        , "N"
                        , pt_cmhs_no
                        , mdcr_dd
                        , ""
                        , ""
                        , "NULL"
                        , ""
                        , ""
                        , ""
                        , ""
                        , ""
                        , "N"
                        , ""
                        , ""
                        , "N"
                        , ""
                        , "0"
                        , "O"
                        , ""
                        , ""
                        , "0"
                        , ""
                        , ""
                        , "OPAT"
                        , ClientEnvironment.IP
                        , currentDate
                        , dtOpa.Rows[0]["MDCR_DR_CD"].ToString()
                        , currentDate
                        , dtOpa.Rows[0]["MDCR_DR_CD"].ToString()
                        ))
                        throw new Exception($"처방 저장 중 오류가 발생하였습니다.");

                    string prsc_uniq_no = DBService.ExecuteScalar(SQL.OR.Sql.SelectPrscUniqNoORORDRRT(), pid, pt_cmhs_no, mdcr_dd, mefe.MEFE_CD, prsc_sqno).ToString();

                    // ETC10
                    if (!DBService.ExecuteNonQuery(SQL.OR.Sql.UpdateRealEntryUserORADECMA(), pid, prsc_uniq_no, DOPack.UserInfo.USER_CD))
                        throw new Exception($"처방 저장 중 오류가 발생하였습니다.");
                }

                // 접수정보 변경(환자진료상태구분 - 진료완료, 진료종료일시 - 현재일시)
                string dvcd = string.Empty;
                string cnts = string.Empty;

                string pt_mdcr_stat_dvcd = "5";

                if (!SQL.Procedure.PR_PA_PRC_PAOPATRTCH(pid, pt_cmhs_no, rcpn_sqno, "PT_MDCR_STAT_DVCD", pt_mdcr_stat_dvcd, DOPack.UserInfo.USER_CD, ref dvcd, ref cnts))
                    throw new Exception($"접수정보 변경 중 오류가 발생하였습니다.");

                if (!string.IsNullOrWhiteSpace(dvcd))
                    throw new Exception($"접수정보 변경 중 오류가 발생하였습니다.\r\n{cnts}");

                if (!SQL.Procedure.PR_PA_PRC_PAOPATRTCH(pid, pt_cmhs_no, rcpn_sqno, "MDCR_END_DT", currentDate, DOPack.UserInfo.USER_CD, ref dvcd, ref cnts))
                    throw new Exception($"접수정보 변경 중 오류가 발생하였습니다.");

                if (!string.IsNullOrWhiteSpace(dvcd))
                    throw new Exception($"접수정보 변경 중 오류가 발생하였습니다.\r\n{cnts}");

                if (!SQL.Procedure.PR_PA_PRC_PAOPATRTCH(pid, pt_cmhs_no, rcpn_sqno, "PRSC_NOTM", ((int.TryParse(dtOpa.Rows[0]["RCPT_NOTM"].ToString(), out int rcpt_notm) ? rcpt_notm : 0) + 1).ToString(), DOPack.UserInfo.USER_CD, ref dvcd, ref cnts))
                    throw new Exception($"접수정보 변경 중 오류가 발생하였습니다.");

                if (!string.IsNullOrWhiteSpace(dvcd))
                    throw new Exception($"접수정보 변경 중 오류가 발생하였습니다.\r\n{cnts}");

                if (setTran)
                    DBService.CommitTransaction();

                return true;
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                if (setTran)
                    DBService.RollbackTransaction();

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                msg = ex.Message + error;
                return false;
            }
        }

        /// <summary>
        /// ADPRLGIF (작업 로그 내역 (process log)) 저장
        /// </summary>
        /// <param name="log_dvcd"></param>
        /// <param name="log_cnts"></param>
        /// <param name="log_dt"></param>
        public static void SaveADPRLGIF(string log_dvcd, string log_cnts, string log_dt = "")
        {
            string sqltext = $@"
  INSERT INTO ADPRLGIF
  VALUES ({(string.IsNullOrWhiteSpace(log_dt) ? "@DT" : $"'{log_dt}'")}, '{log_dvcd}', '{log_cnts.Replace("'", "''")}', '@USERCD', '@IP')";

            DBService.ExecuteNonQuery(sqltext);
        }

        /// <summary>
        /// 화면 open log 저장 (환자 개인정보 조회내역 저장)
        /// </summary>
        /// <param name="assmfilename"></param>
        /// <param name="screenname"></param>
        /// <param name="type_cd"></param>
        /// <param name="dt"></param>
        public static void SaveADOPSCLG(string assmfilename, string screenname, string type_cd, DataTable dt)
        {
            try
            {
                if (DOPack.MenuInfo.GetMenuPersonalYN(screenname) != "Y")
                    return;

                var pidList = dt.AsEnumerable().Select(r => r["PID"].ToString()).OrderBy(r => r).Distinct().ToList();

                string currentdate = DateTime.Now.ToString("yyyyMMddHHmmss");

                int count = 0;
                string sqltext = string.Empty;

                foreach (var pid in pidList)
                {
                    sqltext += count.Equals(0) ? "INSERT INTO ADOPSCLG ( LOG_DT, USER_CD, PC_IP, ASSM_FILE_NAME, SCR_NAME, TYPE_CD, PC_NM, PC_USER, PID ) " : " UNION ALL ";

                    sqltext += $@"
SELECT '{currentdate}', '{DOPack.UserInfo.USER_CD}', '{ClientService.IP}', '{assmfilename}', '{screenname}', '{type_cd}', '{ClientService.ComputerName}', '{ClientService.UserName}', '{pid}' FROM DUAL ";

                    count++;

                    if (count > 100)
                    {
                        if (!DBService.ExecuteNonQuery(sqltext))
                            throw new Exception("로그 테이블에 데이터를 쌓는 중 에러가 발생했습니다.");

                        count = 0;
                        sqltext = string.Empty;
                    }
                }

                //Open System Log 기록
                if (!count.Equals(0))
                    if (!DBService.ExecuteNonQuery(sqltext))
                        throw new Exception("로그 테이블에 데이터를 쌓는 중 에러가 발생했습니다.");
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        public static void SetErpStorageFromDept(string dept_cd, LxComboBox str_cd)
        {
            try
            {
                str_cd.ResetItems();
                str_cd.Enabled = !dept_cd.Equals("%");

                if (string.IsNullOrWhiteSpace(dept_cd) || dept_cd.Equals("%"))
                    return;

                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.BI.Sql.SelectDeptStorageStock(), ref dt, dept_cd))
                    throw new Exception("선택한 부서의 창고를 조회하는 중 에러가 발생했습니다.");

                if (dt.Rows.Count.Equals(0))
                    return;

                str_cd.SetComboItems(dt, "STR_CD", "STR_NM");
                str_cd.SelectedIndex = -1;
                str_cd.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        public static void SetErpTitle(LxSpread spread, int col, int title_dvcd_col, bool visible_title_row)
        {
            try
            {
                if (spread.ActiveSheet.RowCount < 1)
                    return;

                int idx_L = 0;
                int idx_M = 0;
                int idx_S = 0;
                int idx_SS = 0;

                string title = string.Empty;

                string larg_cd = string.Empty;
                string mid_cd = string.Empty;
                string small_cd = string.Empty;
                string ssmall_cd = string.Empty;

                string larg_nm = string.Empty;
                string mid_nm = string.Empty;
                string small_nm = string.Empty;
                string ssmall_nm = string.Empty;

                for (int i = 0; i < spread.ActiveSheet.RowCount; i++)
                {
                    // 대분류
                    if (spread.GetValue(i, "LARGCD").ToString() != larg_cd && !string.IsNullOrWhiteSpace(spread.GetValue(i, "LARG_CLASSNAME").ToString()))
                    {
                        idx_L++;
                        idx_M = 0;

                        larg_cd = spread.GetValue(i, "LARGCD").ToString();
                        larg_nm = spread.GetValue(i, "LARG_CLASSNAME").ToString();
                        title = $"{idx_L}. {larg_nm}";

                        SetFont(spread, i, title, 20, Color.Blue, col, title_dvcd_col, visible_title_row);
                        i++;
                    }

                    // 중분류
                    if (spread.GetValue(i, "MIDCD").ToString() != mid_cd && !string.IsNullOrWhiteSpace(spread.GetValue(i, "MID_CLASSNAME").ToString()))
                    {
                        idx_M++;
                        idx_S = 0;

                        mid_cd = spread.GetValue(i, "MIDCD").ToString();
                        mid_nm = spread.GetValue(i, "MID_CLASSNAME").ToString();
                        title = $"{idx_L}-{idx_M}. {mid_nm}";

                        SetFont(spread, i, title, 18, Color.Green, col, title_dvcd_col, visible_title_row);
                        i++;
                    }

                    // 소분류
                    if (spread.GetValue(i, "SMALLCD").ToString() != small_cd && !string.IsNullOrWhiteSpace(spread.GetValue(i, "SMALL_CLASSNAME").ToString()))
                    {
                        idx_S++;
                        idx_SS = 0;

                        small_cd = spread.GetValue(i, "SMALLCD").ToString();
                        small_nm = spread.GetValue(i, "SMALL_CLASSNAME").ToString();
                        title = $"{idx_L}-{idx_M}-{idx_S}. {mid_nm}";

                        SetFont(spread, i, title, 16, Color.Purple, col, title_dvcd_col, visible_title_row);
                        i++;
                    }

                    // 상세분류
                    if (spread.GetValue(i, "SSMALLCD").ToString() != ssmall_cd && !string.IsNullOrWhiteSpace(spread.GetValue(i, "SSMALL_CLASSNAME").ToString()))
                    {
                        idx_SS++;

                        ssmall_cd = spread.GetValue(i, "SSMALLCD").ToString();
                        ssmall_nm = spread.GetValue(i, "SSMALL_CLASSNAME").ToString();
                        title = $"{idx_L}-{idx_M}-{idx_S}-{idx_SS}. {mid_nm}";

                        SetFont(spread, i, title, 14, Color.Red, col, title_dvcd_col, visible_title_row);
                        i++;
                    }
                }

                spread.SetActiveRow(0);
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        private static void SetFont(LxSpread spread, int idx, string title, int titleWidth, Color color, int col, int title_dvcd_col, bool visible_title_row)
        {
            int row = spread.InsertRow(idx) - 1;
            spread.ActiveSheet.Cells[row, col].Text = title.PadLeft(titleWidth + title.Length);
            spread.ActiveSheet.Cells[row, col].Font = new Font("맑은 고딕", 10f, FontStyle.Bold);
            spread.ActiveSheet.Cells[row, col].ForeColor = color;
            spread.ActiveSheet.Cells[row, col].ColumnSpan = spread.ActiveSheet.ColumnCount - 1;

            if (title_dvcd_col > -1)
                spread.ActiveSheet.Cells[row, title_dvcd_col].Value = "T";

            spread.ActiveSheet.Rows[row].Visible = visible_title_row;

            spread.SetCRUDToRow(row, CRUD_TYPE.Read);
        }
    }
}
