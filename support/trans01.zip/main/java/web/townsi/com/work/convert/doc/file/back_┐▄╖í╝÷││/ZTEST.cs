using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Lime.Framework
{
    public class ClientEnvironment
    {

		string classname = sheetinfo["SHEETPATH"].ToString();    
        string m_Key;

        public SelectedDataParameters SelectedDataParameters
        {
            get
            {
                return this.m_SelectedDataParameters;
            }
        }

        public string Key
        {
            get
            {
                return this.m_Key;
            }
        }
        
        
        
        
        
        
        
        
        
        
        
        
            
    
        #region Delegate & RaiseEvent
		public string MDCR_DR_CD { get { return m_MDCR_DR_CD; } set { m_MDCR_DR_CD = value; } }    // 진료의사코드                     VARCHAR2(10)        

		/// <summary>
        /// 병원정보 DataObject
        /// </summary>
        public static DOHospitalInfo HospitalInfo { get { return m_HospitalInfo; } set { m_HospitalInfo = value; } }
        /// <summary>
        /// 유저정보 DataObject
        /// </summary>
        public static DOUserInfo UserInfo { get { return m_UserInfo; } set { m_UserInfo = value; } }
        private string m_Key;


        public delegate void TotlMdcrAmt(int totlmdcramt);
        public event TotlMdcrAmt OnTotlMdcrAmt;
        
		private clsNhisM2 GetM2(DataRow M2DataRow)
        {
            this.m_M2.m1_sujinjaJuminNm = M2DataRow["M1_SUJINJAJUMINNM"].ToString();
        }        
        
        void ucfOutReceiptE_ScreenClosed(object sender, EventArgs e)
        {
			string pid = ucOrecRegInf11.txtPid.Text.Trim();
            this.ucOutRecWatingList1.SaveDeptIni();
        }
        
		public static bool UpdateORSQTPIF_DLWT_YN_Y(string pid, string ptcmhsno, string dlwtuniqno, string usedvcd)
	      {
	          if (!DBService.ExecuteNonQuery(SQL_OR.Sql.UpdateORSQTPIF_DLWT_YN_Y(), pid, ptcmhsno, dlwtuniqno, usedvcd))
	              return false;
	          return true;
	      }

        #endregion

        #region Member

		string currentdate = DateTime.Now.ToString("yyyyMMddHHmmss");
		private bool m_VisibleWating = false; // 대기창 보이기
        private bool m_SaveYn = true;  // 수납비활성여부
        private clsORCommon m_OrCommon = new clsORCommon();
		
		public clsOutBillBreakdown m_BillBd = new clsOutBillBreakdown();
        clsOutBillTemp m_BillTp = new clsOutBillTemp();
        clsCardCashPermitInfo m_PermitInfo = new clsCardCashPermitInfo();
        clsTraiLimitInfo m_LimitInfo = new clsTraiLimitInfo();
        clsOutReceiptBreakDown m_OutRecBd = new clsOutReceiptBreakDown();
            
    	private DataTable m_DtPAUNCDMA = null;
    	private bool m_SUCCESS = false;           //승인성공여부
    	private string m_PID = String.Empty;    //환자등록번호                     VARCHAR2(10)
    	private    string   m_PID = String.Empty;    //환자등록번호                     VARCHAR2(10)
        private int m_PT_CMHS_NO = 0;               //환자내원번호                     NUMBER(10, 0)
        private double m_PT_CMHS_NO2 = 0;               //환자내원번호                     NUMBER(10, 0)
        private float m_PT_CMHS_NO3 = 0;               //환자내원번호                     NUMBER(10, 0)
        private double m_PAY_ACTN_USCH_AMT = 0;               //급여행위본인부담금액             NUMBER(10, 0)
        public float DDTotalMqtyB = 0;                       // 중복처방 1일투여회수
        
        /// <summary>
        /// 카드/현금 승인내역의 영수정보 변경한다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool UpdatePACAPEMA(ref string msg)
        {
        	int sqno = 0;
        	long sqno2 = 0;
        	double sqno2 = 0;
        	float sqno3 = 0;
            bool success = true;
            string remarkDvcd = "";
            if (DBService.AffectedRows > 1)
            {
                // 이렇게 하면 안되는데...ㅡㅡ;;;;
                string sqltext = SQL.PA.Sql.UpdatePACAPEMA_DupData(this.PID, this.RCPT_OCRR_UNIQ_NO, ClientService.IP);
            }

            return success;
        }        
        
        public DataTable GetPermitInfo()
        {
        }
        
        
    	Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
    	sprBed.SetComboItems("BED_LCTN_DVCD", OverallCodeList.GetDataList("BED_LCTN_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
    	private clsUnCollectedOcrrInfo m_UnclOcrrInfo = new clsUnCollectedOcrrInfo();	
    	
    	
    	
        /// <summary>
        /// 최종영수증 수납일련번호를 가져온다.
        /// </summary>
        /// <returns></returns>
        public int SelectMaxRcptSqno(out string outmsg)
        {
        	string currentdate = DateTime.Now.ToString("yyyyMMddHHmmss");
        	DataTable m_DtPAUNCDMA = null
            let result:number = 0;
            result = DBService.ExecuteInteger(SQL.PA.Sql.SelectPAOBILBD_MaxRcptSqno(), m_PID, m_PT_CMHS_NO.ToString());
            outmsg = DBService.ErrorMessage;
            return result;
        }
        
        public bool SaveRegistrationRemark(ref string msg)
        {
        }
        
        
        public static void DeleteClientFolder()
        {
        
		    foreach (DataRow row in dt.Rows)
		    {
		        // 이미 입원전환된 상병은 전환하지 않는다.
		        tempSql = string.Format(fixSearchSQL, pid, admsptcmhsno, row["ILNS_CD"].ToString(), row["ILNS_CD_SQNO"].ToString());
		        tempDt.Clear();
		        if (!DBService.ExecuteDataTable(tempSql, ref tempDt))
		            throw new Exception("상병 중복 조회 중 에러가 발생했습니다.");
		
		        if (tempDt.Rows.Count > 0)
		            continue;        
			}        
            FileService.DeleteFolder(m_TempFolder);
            FileService.DeleteFolder(m_MakeChartFolder);
            FileService.DeleteFolder(m_DownChartFolder);
        }
        
        /// <summary>
        /// 미수관련 취소작업을 한다.
        /// </summary>
        /// <param name="pid">환자등록번호</param>
        /// <param name="unclocrrsqno">미수발생일련번호</param>
        /// <param name="unclocrrdvcd">미수발생구분코드</param>
        /// <param name="msg"></param>
        /// <returns></returns>
        private CancelPAUNCOMA(pid:string, unclocrrsqno:string, unclocrrdvcd:string, msg:string)
        {
            
	        clsAdmsIntermediateAmt interamt = new clsAdmsIntermediateAmt();
	
	        // 미수발생일련번호 MAX VALUE
	        int maxunclocrrsqno = SelectMaxUnclOcrrSqno(pid, msg);
	
	        if (maxunclocrrsqno < 0) return false;
	   	 }
        

        #region Define : Member

        private static string m_SolutionPath = "";
        private static string m_ConfigFolder = "Config";
        private static string m_TempFolder = "Temp";

        #endregion

        #region UDP Port

        //Udp Msg Port
        private const int m_UPD_PORT = 15022;

        public static string OSVersion
        {
            get
            {
                return ClientService.OSVersion;
            }
        }

        public static string StartupPath
        {
            get
            {
                return ClientService.StartupPath;
            }
            set
            {
                ClientService.StartupPath = value;
            }
        }
        
        public clsTraiLimitInfo LimitInfo
        {
            get { return m_LimitInfo; }
            set { m_LimitInfo = value; }
        }

        public clsOutReceiptBreakDown OutRecBd
        {
            get { return m_OutRecBd; }
            set { m_OutRecBd = value; }
        }

        public string Old_BillNo
        {
            set { m_old_billno = value; }
        }
        
        
    public class DurResultInfo
    {
        // 처방정보
        public string pid = string.Empty;            // 환자번호
        public int pt_cmhs_no = 0;                       // 환자내원번호
        public string otpt_adms_dvcd = string.Empty;            // 외입구분([O]외래/[I]입원/[T]퇴원약
        public string mdcr_dd = string.Empty;            // 처방일자
        public int prsc_sqno = 0;                       // 처방일련번호
        public string rgst_dt = string.Empty;            // 등록일시
        public string rgstr_id = string.Empty;            // 등록자
        public string updt_dt = string.Empty;            // 수정일시
        public string updtr_id = string.Empty;            // 수정자
        public string dur_trans_dvcd = string.Empty;            // DUR 전송구분

    }        

}
