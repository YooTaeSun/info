//********************************************************************
// Class 명 : ucCardCashPermit
// 역    할 : 신용카드, 현금영수증 승인요청하는 User Control
// 작 성 자 : PGH
// 작 성 일 : 2017-09-27
//********************************************************************
// 수정내역 : 
//********************************************************************

using System;
using System.Windows.Forms;


using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.BusinessControls
{
    public partial class ucOremInf : UserControl
    {
        #region Define : Member

        clsPatientRemark m_Remark = new clsPatientRemark();
        public clsPatientRemark Remark
        {
            get { return m_Remark; }
            set { m_Remark = value; }
        }


        DOPatientInfo m_PatientInfo = new DOPatientInfo();
        public DOPatientInfo PatientInfo
        {
            get { return m_PatientInfo; }
            set { m_PatientInfo = value; }
        }

        /// <summary>
        /// P (환자특이사항) OR R(접수특이사항)을 속성에서 세팅해 주세요...
        /// </summary>
        private string m_RemarkDvcd = "";
        public string RemarkDvcd
        {
            get { return m_RemarkDvcd; }
            set
            {
                m_RemarkDvcd = value;

                if (m_RemarkDvcd.Equals("P"))
                    ttpRemark.TitleText = "환자특이사항[P]";
                else
                    ttpRemark.TitleText = "접수특이사항[R]";
            }
        }

        #endregion

        #region Construction

        public ucOremInf()
        {
            InitializeComponent();
        }

        #endregion

        #region Screen Load

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode)
                return;

            Initialize();
        }

        #endregion

        #region Method : Initialize

        private void Initialize()
        {
            this.btnPtPclrMstr.Click += btnPtPclrMstr_Click;
            this.txtPtPclrMstr.KeyDown += txtPtPclrMstr_KeyDown;
        }

        #endregion

        #region Method : Public Method

        public void Clear()
        {
            txtPtPclrMstr.Text = "";
            Remark.Clear();
            PatientInfo.Clear();
        }

        public void SetPatientRegRemark()
        {
            txtPtPclrMstr.Text = "";
            Remark.OTPT_ADMS_DVCD = "O";
            Remark.PTAF_MDCR_DVCD = "P";
            Remark.Load();

            txtPtPclrMstr.Text = Remark.PT_PCLR_MATR;
        }

        public void SetPatientInfoRemark()
        {
            txtPtPclrMstr.Text = "";
            PatientInfo.Load();
            txtPtPclrMstr.Text = PatientInfo.PT_PCLR_MATR;
        }

        public bool SavePaPathInRemark(ref string msg)
        {
            bool success = true;

            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePtPclrMatr(), PatientInfo.PID
                                                                        , txtPtPclrMstr.Text.Trim()))
            {
                success = false;
                msg = "[" + DBService.ErrorCode + "]" + DBService.ErrorMessage;
                DBService.RollbackTransaction();
            }

            return success;
        }

        public bool SaveRegistrationRemark(ref string msg)
        {
            bool success = true;

            Remark.PT_CMHS_NO = Remark.PT_CMHS_NO;
            Remark.PT_PCLR_MATR = txtPtPclrMstr.Text.Trim();
            Remark.PCLR_MATR_SQNO = Remark.SelectMaxSqno();
            Remark.DEL_YN = "A";
            Remark.RGST_DT = DateTimeService.NowDateTimeNoneSeperatorString();
            Remark.RGSTR_ID = DOPack.UserInfo.USER_CD;
            Remark.UPDT_DT = DateTimeService.NowDateTimeNoneSeperatorString();
            Remark.UPDTR_ID = DOPack.UserInfo.USER_CD;

            if (!Remark.SavePatientRemark(ref msg))
            {
                DBService.RollbackTransaction();
                success = false;
            }

            return success;
        }

        #endregion

        #region Method : Control

        /// <summary>
        /// 메모를 저장한다.
        /// </summary>
        private void SaveMemo()
        {
            try
            {
                string msg = string.Empty;
                string pid = (m_RemarkDvcd == "P" ? PatientInfo.PID : this.m_Remark.PID);

                if (StringService.IsNull(pid))
                {
                    LxMessage.Show("환자가 선택되지 않았습니다", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                DBService.BeginTransaction();

                if (m_RemarkDvcd == "P")
                {
                    if (!SavePaPathInRemark(ref msg))
                        throw new Exception("환자기본정보의 특이사항 저장중 오류가 발생했습니다.\r\n" + msg);
                }
                else
                {
                    if (!SaveRegistrationRemark(ref msg))
                        throw new Exception("환자접수특이사항 저장중 오류가 발생했습니다.\r\n" + msg);
                }

                DBService.CommitTransaction();
                LxMessage.Show("저장되었습니다", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information, 2);
            }
            catch (Exception ex)
            {
                if (DBService.IsTransaction)
                    DBService.RollbackTransaction();

                LxMessage.Show(ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Event : Control

        private void btnPtPclrMstr_Click(object sender, EventArgs e)
        {
            SaveMemo();
        }

        private void txtPtPclrMstr_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.S)
            {
                SaveMemo();
            }
        }

        #endregion
    }
}
