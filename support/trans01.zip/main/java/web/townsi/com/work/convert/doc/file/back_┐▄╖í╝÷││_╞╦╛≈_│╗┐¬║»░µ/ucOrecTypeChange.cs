//********************************************************************************
// Class 명 : ucOrecTypeChange
// 역    할 : 외래 접수 정보를 입력하는 사용자 정의 컨트롤
// 작 성 자 : 박계훈
// 작 성 일 : 2017-08-18
//********************************************************************************
// 추가할내역 : 
// 수정내역   :
//********************************************************************************
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public partial class ucOrecTypeChange : UserControl
    {
        #region Define Event
        public delegate void PatientSelectedEventHandler(object sender, SelectDataEventArgs e);
        public event PatientSelectedEventHandler PatientSelected;

        //부모화면에서 PID 받아 의뢰기관 팝업열기
        public delegate void ShowPop();
        public event ShowPop OnShowPop;

        private string m_DefaultSetting = "N";

        private string m_OriginMdcrDeptCd = string.Empty;
        private string m_OriginRealMdcrDrCd = string.Empty;
        private string m_OriginMdcrDrCd = string.Empty;

        #endregion

        #region Define Variable Member

        public DOPatientInfo m_PatientInfo = new DOPatientInfo();
        private clsOutRegistrationInfo m_OutRegInfo = new clsOutRegistrationInfo();
        private clsPatientRemark m_PatRem = new clsPatientRemark();
        BusinessControls.clsCommon m_clscommon = new BusinessControls.clsCommon();

        #endregion

        #region Member Property
        public DOPatientInfo PatientInfo
        {
            get
            {
                return m_PatientInfo;
            }
            set
            {
                m_PatientInfo = value;
            }
        }

        public clsOutRegistrationInfo OutRegInfo
        {
            get
            {
                return m_OutRegInfo;
            }
            set
            {
                m_OutRegInfo = value;
            }
        }
        public clsPatientRemark PatRem
        {
            get { return m_PatRem; }
            set { m_PatRem = value; }
        }
        #endregion

        #region Initialize
        public ucOrecTypeChange()
        {
            InitializeComponent();

        }
        #endregion

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode)
                return;

            dteMdcrDd.ReadOnly = true;

            lblDisasterSupt.Enabled = cboDisasterSupt.Enabled = ConfigService.GetConfigValueBool("CL", "DISASTER_SUPT", "USE_YN", false);
            DataTable dt = OverallCodeList.GetDataList("DISASTER_SUPT");
            dt = dt.AsEnumerable().Where(r => !r["ETC_USE_CNTS_1"].ToString().Equals("I")).CopyToDataTable();
            cboDisasterSupt.SetComboItems(dt, "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.None, "NO");

            InitializeEvent();
            //SetComboPaOregRt();
            m_DefaultSetting = "Y";

            m_clscommon.Visible_OR_RECALL(lblOR_REQUEST, cboOR_REQUEST, lblRECALL, cboRECALL);

            txtCfscRgnoName.ReadOnly = true;
            txtCfscRgno.ReadOnly = false;
            txtCfscRgno.Enabled = true;
        }

        #region Method : Initialize

        private void InitializeEvent()
        {
            txtCfscRgno.EditorButtonClick += (s, e) => ShowPopupfrmSearchCfscCdP();
            txtCfscRgno.KeyDown += (s, e) =>
            {
                if (e.KeyCode.Equals(Keys.Enter))
                {
                    txtCfscRgno.Text = txtCfscRgno.Text.ToUpper();
                    SetCfscRgNoName();
                }
            };

            txtRefrInstno.EditorButtonClick += txtRefrInstno_EditorButtonClick;
            chkReBurn.CheckedChanged += chkReBurn_CheckedChanged;

            cboInsnTycd.SelectionChangeCommitted += CboInsnAsstTycd_SelectionChangeCommitted;
            cboAsstTycd.SelectionChangeCommitted += CboInsnAsstTycd_SelectionChangeCommitted;

            cboDisasterSupt.SelectionChangeCommitted += CboDisasterSupt_SelectionChangeCommitted;
        }

        private void ShowPopupfrmSearchCfscCdP()
        {
            if (cboAsstTycd.SelectedIndex.Equals(-1))
            {
                LxMessage.ShowInformation("보조유형이 선택되지 않았습니다");
                return;
            }

            using (frmSearchCfscCdP popup = new frmSearchCfscCdP(cboAsstTycd.SelectedValue.ToString()))
            {
                popup.ShowDialog(this);

                if (!popup.DialogResult.Equals(DialogResult.OK))
                    return;

                txtCfscRgno.Text = popup.CfscCd;
                SetCfscRgNoName();
            }
        }

        private void SetCfscRgNoName()
        {
            txtCfscRgnoName.Text = "";

            if (StringService.IsNull(txtCfscRgno.Text))
                return;

            string sqlText = @"
  SELECT * 
    FROM BISCCDMA 
   WHERE CFSC_CD = '{0}'
     AND APLY_STRT_DD <= TO_CHAR(SYSDATE, 'YYYYMMDD')
     AND APLY_END_DD >= TO_CHAR(SYSDATE, 'YYYYMMDD') ";

            DataTable dt = new DataTable();
            DBService.ExecuteDataTable(sqlText, ref dt, txtCfscRgno.Text);
            if (dt.Rows.Count.Equals(0))
                return;

            txtCfscRgnoName.Text = dt.Rows[0]["CFSC_CD_CNTS"].ToString();
        }

        private void CboDisasterSupt_SelectionChangeCommitted(object sender, EventArgs e)
        {
            // 의료급여환자이고 본인100이 아니면
            if (!cboInsnTycd.SelectedValue.Equals("21") && !cboInsnTycd.SelectedValue.Equals("22"))
                return;

            if (cboAsstTycd.SelectedValue.Equals("99"))
                return;

            if (cboDisasterSupt.SelectedValue.Equals("CVD19") && !cboUschAplyCd.SelectedValue.Equals("B099"))
            {
                LxMessage.ShowInformation("본인코드 [B099]로 자동 세팅됩니다.");
                cboUschAplyCd.SelectedValue = "B099";
            }
            else if (!cboDisasterSupt.SelectedValue.Equals("CVD19") && cboUschAplyCd.SelectedValue.Equals("B099"))
            {
                LxMessage.ShowInformation("본인코드 [NO]로 자동 세팅됩니다.");
                cboUschAplyCd.SelectedValue = "NO";
            }
        }

        private void CboInsnAsstTycd_SelectionChangeCommitted(object sender, EventArgs e)
        {
            clsPACommon.SetAutoB099(cboInsnTycd, cboAsstTycd, cboUschAplyCd);
        }

        private void chkReBurn_CheckedChanged(object sender, EventArgs e)
        {
            if (this.chkReBurn.Checked)
                LxMessage.ShowInformation("보조유형 강제적용을 진행합니다.\r\n보조유형과 특례기호를 반드시 확인 해 주세요.");
        }

        #endregion Method : Initialize

        #region Method

        /// <summary>
        /// 외래접수정보 CobmoBox Data Setting
        /// </summary>
        public void SetComboPaOregRt()
        {
            if (this.DesignMode)
                return;

            // TODO : 언젠가 진료일자 기준으로 콤보박스 보이게 바꿔야 함...

            string defaultvalue = String.Empty;

            DateTime now = DateTime.Now;
            dteMdcrDd.DateTime = now;
            mskMdcrTime.Value = now.ToString("HHmm");

            // 예약여부
            if (cboApntYn.Value == null)
                cboApntYn.SelectValue("N");
            // 예약구분코드
            if (cboApntPathDvcd.Value == null)
                cboApntPathDvcd.SetComboItems(clsPACommon.GetDtBICDINDT("APNT_PATH_DVCD", "N", DateTimeService.NowDateNoneSeperatorString(), ref defaultvalue), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.None, defaultvalue);
            // 진료과
            if (cboMdcrDeptCd.Value == null)
                clsPACommon.SetComboPA(cboMdcrDeptCd, "DEPT_CD", "DEPT_HNM", "1", DateTimeService.NowDateNoneSeperatorString());
            // 진료의
            if (cboMdcrDrCd.Value == null)
                clsPACommon.SetComboPA(cboMdcrDrCd, "USER_CD", "USER_NM", (cboMdcrDeptCd.Value != null ? cboMdcrDeptCd.Value.ToString().Trim() : ""), DateTimeService.NowDateNoneSeperatorString());
            // 실진료의
            if (cboRealMdcrDrCd.Value == null)
                clsPACommon.SetComboPA(cboRealMdcrDrCd, "USER_CD", "USER_NM", (cboMdcrDeptCd.Value != null ? cboMdcrDeptCd.Value.ToString().Trim() : ""), DateTimeService.NowDateNoneSeperatorString());

            // 초재구분코드
            if (cboFrvsRvstDvcd.Value == null)
                cboFrvsRvstDvcd.SetComboItems(clsPACommon.GetDtBICDINDT("FRVS_RVST_DVCD", "N", DateTimeService.NowDateNoneSeperatorString(), ref defaultvalue), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.None, defaultvalue);
            // 선택진료여부
            if (cboSmcrYn.Value == null)
                cboSmcrYn.SelectValue("N");
            // 보험유형코드
            if (cboInsnTycd.Value == null)
                cboInsnTycd.SetComboItems(clsPACommon.GetDtBICDINDT("INSN_TYCD", "N", DateTimeService.NowDateNoneSeperatorString(), ref defaultvalue), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.None, defaultvalue);
            // 보조유형
            if (cboAsstTycd.Value == null)
                clsPACommon.SetComboPA(cboAsstTycd, "ASST_TYCD", "LWRN_OVRL_CDNM", cboInsnTycd.Value.ToString().Trim(), DateTimeService.NowDateNoneSeperatorString());
            // 진찰료산정구분코드
            if (cboMcchCmptDvcd.Value == null)
                cboMcchCmptDvcd.SetComboItems(clsPACommon.GetDtBICDINDT("MCCH_CMPT_DVCD", "N", DateTimeService.NowDateNoneSeperatorString(), ref defaultvalue), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.None, defaultvalue);
            // 내원구분코드
            if (cboCmhsDvcd.Value == null)
                cboCmhsDvcd.SetComboItems(clsPACommon.GetDtBICDINDT("CMHS_DVCD", "N", DateTimeService.NowDateNoneSeperatorString(), ref defaultvalue), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.None, defaultvalue);
            // 예외사유코드
            if (cboExcpResnCd.Value == null)
                clsPACommon.SetComboPA(cboExcpResnCd, "EXCP_RESN_CD", "EXCP_RESN_CNTS", "1", DateTimeService.NowDateNoneSeperatorString(), "NO");
            // 본인부담코드 산정특례코드관리
            if (cboUschAplyCd.Value == null)
                clsPACommon.SetComboPA(cboUschAplyCd, "CFSC_CD", "CFSC_CD_NM", "1", DateTimeService.NowDateNoneSeperatorString(), "NO");
            //if (cboCfscRgnoCd.Value == null)
            //{
            //    DataTable cfsc_rgno_dt = new DataTable();
            //    string mdcr_dd = OutRegInfo.MDCR_DD ?? dteMdcrDd.DateTime.ToString("yyyyMMdd");

            //    if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectBISCCDMA_CFSC_RGNO_CD(mdcr_dd), ref cfsc_rgno_dt))
            //    {
            //        cboCfscRgnoCd.SetComboItems(cfsc_rgno_dt, "CFSC_CD", "CFSC_NM");
            //        if (cfsc_rgno_dt.Rows.Count > 0)
            //            cboCfscRgnoCd.SelectedIndex = 0;
            //    }
            //    else
            //    {
            //        clsPACommon.SetComboPA(cboCfscRgnoCd, "CFSC_CD", "CFSC_CD_CNTS", "1", DateTimeService.NowDateNoneSeperatorString(), "NO");
            //    }
            //}
            // 급여자격구분코드
            if (cboPayQlfcDvcd.Value == null)
                cboPayQlfcDvcd.SetComboItems(clsPACommon.GetDtBICDINDT("PAY_QLFC_DVCD", "N", DateTimeService.NowDateNoneSeperatorString(), ref defaultvalue), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.None, defaultvalue);
            // 할인코드
            if (cboDcntRdiaCd.Value == null)
                clsPACommon.SetComboPA(cboDcntRdiaCd, "DCNT_CD", "DCNT_CDNM", "1", DateTimeService.NowDateNoneSeperatorString(), "NO");
            // 내원경로구분코드
            if (cboCmhsMotvDvcd.Value == null)
                cboCmhsMotvDvcd.SetComboItems(clsPACommon.GetDtBICDINDT("CMHS_MOTV_DVCD", "N", DateTimeService.NowDateNoneSeperatorString(), ref defaultvalue), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.AddNone, defaultvalue);
            // 협진여부
            if (cboCnstRefrYn.Value == null)
                cboCnstRefrYn.SelectValue("N");

            // 상해외인코드
            cboEcoiCd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            string sqltext = @"SELECT LWRN_OVRL_CD
                                    , '['||LWRN_OVRL_CD||']'||LWRN_OVRL_CDNM AS LWRN_OVRL_CDNM
                                 FROM BICDINDT 
                                WHERE OVRL_CD = 'CL_ECOI_CD' 
                                  AND APLY_STRT_DD <= TO_CHAR(SYSDATE, 'YYYYMMDD') 
                                  AND TO_CHAR(SYSDATE, 'YYYYMMDD') <= APLY_END_DD";
            DataTable dt = new DataTable();
            DBService.ExecuteDataTable(sqltext, ref dt);
            cboEcoiCd.SetComboItems(dt, "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
        }

        /// <summary>
        /// Control 초기화
        /// </summary>
        public void Clear()
        {
            //btnApntYn.Clear();
            //btnMdcrDrCd.Clear();
            //btnRefrInstno.Clear();
            cboDcntRdiaCd.Clear();
            txtDcntRrdiaEmno.Text = "";
            txtPtPclrMatr.Text = "";
            txtRefrInstno.Text = "";
            cboApntYn.Clear();
            cboApntPathDvcd.Clear();
            cboMdcrDeptCd.Clear();
            cboMdcrDrCd.Clear();
            cboRealMdcrDrCd.Clear();
            cboFrvsRvstDvcd.Clear();
            cboSmcrYn.Clear();
            cboInsnTycd.Clear();
            cboAsstTycd.Clear();
            cboMcchCmptDvcd.Clear();
            cboCmhsDvcd.Clear();
            cboExcpResnCd.Clear();
            cboUschAplyCd.Clear();
            cboFcltAplyYn.Clear();
            cboMtwmYn.Clear();
            cboPayQlfcDvcd.Clear();
            cboCnstRefrYn.Clear();
            cboCmhsMotvDvcd.Clear();
            cboEcoiCd.Clear();

            txtCfscRgno.Text = txtCfscRgnoName.Text = string.Empty;

            this.lblMDCAREHSPTHSPTZYN.Visible = false;

            DateTime now = DateTime.Now;
            dteMdcrDd.DateTime = now;
            mskMdcrTime.Value = now.ToString("HHmm");

            cboOR_REQUEST.SelectedValue = "00"; //진료의뢰
            cboRECALL.SelectedValue = "00";     //회송
        }

        public int ValidateOutRegInfo(ref string msg)
        {
            if (cboMdcrDeptCd.Value != null && string.IsNullOrWhiteSpace(cboMdcrDeptCd.Value.ToString()))
            {
                msg = "진료과목이 누락되었습니다. 입력하여 주시기 바랍니다.";
                return 1;
            }

            if (ClinicList.GetColumnValue((cboMdcrDeptCd.Value == null ? "" : cboMdcrDeptCd.Value.ToString()), "OTPT_RCPN_PSBL_YN").ToString().Equals("N"))
            {
                msg = "외래 접수 가능 부서과목이 아닙니다. 확인하여 주시기 바랍니다.";
                return 1;
            }
            /*
            if (clsPACommon.ReturnValidityOfColumnValue("PAOPATRT", "MDCR_DR_CD", cboMdcrDrCd.Value.ToString(), cboMdcrDeptCd.Value.ToString()) == "N")
            {
                msg = "입력한 의사코드가 유효하지 않는 의사코드입니다. 확인하여 주시기 바랍니다.";
                return 1;
            }
            */
            if (cboMdcrDrCd.Value != null && string.IsNullOrWhiteSpace(cboMdcrDrCd.Value.ToString()))
            {
                msg = "진료의사코드가 누락되었습니다. 입력하여 주시기 바랍니다.";
                return 1;
            }
            /*
            if (clsPACommon.ReturnValidityOfColumnValue("PAOPATRT", "MDCR_DR_CD", cboRealMdcrDrCd.Value.ToString(), cboMdcrDeptCd.Value.ToString()) == "N")
            {
                msg = "입력한 실진료의 의사코드가 유효하지 않는 의사코드입니다. 확인하여 주시기 바랍니다.";
                return 1;
            }
            */
            if (cboRealMdcrDrCd.Value != null && string.IsNullOrWhiteSpace(cboRealMdcrDrCd.Value.ToString()))
            {
                msg = "실진료의 진료의사코드가 누락되었습니다. 입력하여 주시기 바랍니다.";
                return 1;
            }

            if (cboFrvsRvstDvcd.Value != null && string.IsNullOrWhiteSpace(cboFrvsRvstDvcd.Value.ToString()))
            {
                msg = "초진재진구분코드가 누락되었습니다. 입력하여 주시기 바랍니다.";
                return 1;
            }

            if (cboInsnTycd.Value != null && string.IsNullOrWhiteSpace(cboInsnTycd.Value.ToString()))
            {
                msg = "보험유형코드가 누락되었습니다. 입력하여 주시기 바랍니다.";
                return 1;
            }

            if (cboAsstTycd.Value != null && string.IsNullOrWhiteSpace(cboAsstTycd.Value.ToString()))
            {
                msg = "보조유형코드가 누락되었습니다. 입력하여 주시기 바랍니다.";
                return 1;
            }

            if (cboMcchCmptDvcd.Value != null && string.IsNullOrWhiteSpace(cboMcchCmptDvcd.Value.ToString()))
            {
                msg = "진찰료산정구분코드가 누락되었습니다. 입력하여 주시기 바랍니다.";
                return 1;
            }

            if (cboCmhsDvcd.Value != null && string.IsNullOrWhiteSpace(cboCmhsDvcd.Value.ToString()))
            {
                msg = "내원구분코드가 누락되었습니다. 입력하여 주시기 바랍니다.";
                return 1;
            }

            // 의료급여 환자의 경우 
            if ((cboInsnTycd.SelectedValue.Equals("21") || cboInsnTycd.SelectedValue.Equals("22")) && !cboAsstTycd.SelectedValue.Equals("99"))
            {
                if (cboUschAplyCd.SelectedValue.Equals("M001") && txtRefrInstno.Text.Equals(DOPack.HospitalInfo.HPTL_RGNO_CD))
                {
                    msg = "의뢰기관이 우리병원인 경우는 의뢰기관을 입력하지 말고 진행해 주세요.";
                    return 1;
                }
                else if (txtRefrInstno.Text.Length.Equals(8) && !cboUschAplyCd.SelectedValue.Equals("B005") && !cboUschAplyCd.SelectedValue.Equals("B006"))
                {
                    if (!LxMessage.ShowQuestion("진료의뢰 의료급여기관기호를 입력하신 경우에는 본인부담여부에 B005 또는 B006을 입력하셔야 합니다.\r\n\r\n이대로 진행하는 경우 [진료확인번호] 취득에 실패합니다.\r\n\r\n그래도 이대로 진행하시겠습니까?").Equals(DialogResult.Yes))
                    {
                        msg = "저장을 취소하였습니다.";
                        return 1;
                    }
                }
                else if (string.IsNullOrWhiteSpace(txtRefrInstno.Text) && (cboUschAplyCd.SelectedValue.Equals("B005") || cboUschAplyCd.SelectedValue.Equals("B006")))
                {
                    msg = "본인코드 B005 또는 B006 입력시에는 의뢰기관을 반드시 입력해야 합니다.";
                    txtRefrInstno.Focus();
                    return 1;
                }
            }

            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            // 요양병원에 입원중이며 건강보험 or 의료급여1/2종으로 접수한 경우
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            string insn_tycd = this.cboInsnTycd.Value == null ? string.Empty : this.cboInsnTycd.Value.ToString();
            if (this.lblMDCAREHSPTHSPTZYN.Visible && (insn_tycd.Equals("11") || insn_tycd.Equals("21") || insn_tycd.Equals("22")))
            {
                string asst_tycd = this.cboAsstTycd.Value == null ? string.Empty : this.cboAsstTycd.Value.ToString();
                if (asst_tycd.Contains("V") || asst_tycd.Contains("H"))
                {
                    // 산정특례 보조유형이 세팅된 경우, 의뢰기관기호가 존재하는지 확인한다.
                    if (string.IsNullOrWhiteSpace(this.txtRefrInstno.Text))
                    {
                        this.txtRefrInstno.Focus();
                        msg = "요양병원 입원중인 환자입니다.\r\n\r\n[의뢰기관]기호를 입력해 주세요.";
                        return 1;
                    }
                }
                else if (asst_tycd.Equals("99"))
                {
                    // 보조유형 본인100인 경우
                }
                else
                {
                    // 그 외의 보조유형인 경우
                    LxMessage.ShowInformation("요양병원 입원중인 환자입니다.\r\n산정특례인 경우만 급여처리 가능하며,\r\n산정특례가 아닌 경우 본인부담100%로 처리하세요.\r\n(보조유형 강제적용은 가능합니다.)");
                }
            }

            return 0;
        }

        /// <summary>
        /// 내역변경에서 변경할 접수내역을 가져온다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        public void DisplayRegistrationInfo(string pid, int ptcmhsno)
        {
            if (OutRegInfo.Load(pid, ptcmhsno))
            {
                SetDefaultValueToInputCtl();
            }
        }

        public bool CheckRealMdcrDrCd()
        {
            if (cboMdcrDeptCd.SelectedValue == null || cboMdcrDrCd.SelectedValue == null || cboRealMdcrDrCd.SelectedValue == null)
                return true;

            try
            {
                if (m_OriginMdcrDeptCd != cboMdcrDeptCd.SelectedValue)
                    return true;

                if (m_OriginMdcrDrCd != cboMdcrDrCd.SelectedValue && cboRealMdcrDrCd.SelectedValue != cboMdcrDrCd.SelectedValue)
                {
                    DialogResult dr = LxMessage.ShowQuestion("진료의가 변경되었습니다.\r\n실진료의도 같이 변경하겠습니까?\r\n\r\n원외처방의 경우, 실진료의로 면허번호가 표기됩니다.");
                    if (dr.Equals(DialogResult.Yes))
                        cboRealMdcrDrCd.SelectedValue = cboMdcrDrCd.SelectedValue;
                }
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
                return false;
            }

            return true;
        }

        public void SetDefaultValueToInputCtl()
        {
            dteMdcrDd.DateTime = DateTimeService.ConvertDateTime(OutRegInfo.MDCR_DD);           //진료일자
            mskMdcrTime.Value = OutRegInfo.MDCR_TIME;         //진료시간
            cboApntYn.SelectedValue = OutRegInfo.APNT_YN;           //예약여부
            cboApntPathDvcd.Clear();                                        //예약경로구분코드
            cboApntPathDvcd.SelectedValue = OutRegInfo.APNT_PATH_DVCD;
            cboApntPathDvcd.Enabled = false;
            cboMdcrDeptCd.SelectedValue = OutRegInfo.MDCR_DEPT_CD;          //진료부서
            clsPACommon.SetComboPA(cboMdcrDrCd, "USER_CD", "USER_NM", OutRegInfo.MDCR_DEPT_CD, OutRegInfo.MDCR_DD);
            cboMdcrDrCd.SelectedValue = OutRegInfo.MDCR_DR_CD;        //진료의사
            clsPACommon.SetComboPA(cboRealMdcrDrCd, "USER_CD", "USER_NM", OutRegInfo.MDCR_DEPT_CD, OutRegInfo.MDCR_DD);
            cboRealMdcrDrCd.SelectedValue = OutRegInfo.REAL_MDCR_DR_CD;     //실진료의

            m_OriginMdcrDeptCd = OutRegInfo.MDCR_DEPT_CD;
            m_OriginMdcrDrCd = OutRegInfo.MDCR_DR_CD;
            m_OriginRealMdcrDrCd = OutRegInfo.REAL_MDCR_DR_CD;

            cboFrvsRvstDvcd.SelectedValue = OutRegInfo.FRVS_RVST_DVCD;    //초진재진구분
            cboSmcrYn.SelectedValue = OutRegInfo.SMCR_YN;           //선택진료
            cboInsnTycd.SelectValue(OutRegInfo.INSN_TYCD);                  //보험유형

            clsPACommon.SetComboPA(cboAsstTycd, "ASST_TYCD", "LWRN_OVRL_CDNM", OutRegInfo.INSN_TYCD, OutRegInfo.MDCR_DD);
            cboAsstTycd.SelectValue(OutRegInfo.ASST_TYCD);                  //보조유형
            cboMcchCmptDvcd.SelectValue(OutRegInfo.MCCH_CMPT_DVCD);         //진찰료산정구분
            cboCmhsDvcd.SelectValue(OutRegInfo.CMHS_DVCD);                  //내원경로
            cboExcpResnCd.SelectValue(OutRegInfo.EXCP_RESN_CD);             //예외사유
            /*
            cboCfscRgnoCd.SelectValue(OutRegInfo.CFSC_RGNO_CD);             //산정특례코드
            */
            txtCfscRgno.Text = OutRegInfo.CFSC_RGNO_CD;
            SetCfscRgNoName();

            cboUschAplyCd.SelectValue(OutRegInfo.USCH_APLY_CD);             //본인부담코드
            cboPayQlfcDvcd.SelectValue(OutRegInfo.PAY_QLFC_DVCD);           //급여자격구분
            cboCnstRefrYn.SelectValue(OutRegInfo.CNST_REFR_YN);             //협진여부
            cboDcntRdiaCd.SelectValue(OutRegInfo.DCNT_RDIA_CD);             //할인감액여부
            txtDcntRrdiaEmno.Text = OutRegInfo.DCNT_RDIA_EMNO;              //할인감액적용직원번호
            cboCmhsMotvDvcd.SelectValue(OutRegInfo.CMHS_MOTV_DVCD);         //내원경로구분
            cboEcoiCd.SelectedValue = OutRegInfo.ECOI_CD; //상해외인코드

            if (OutRegInfo.DCNT_RDIA_CD != "NO")
                txtDcntRrdiaEmno.Enabled = false;

            txtPtPclrMatr.Text = PatRem.ReturnPtPclrMatr(OutRegInfo.PID, 0, "O", "P");  // 환자특이사항 
            txtRefrInstno.Text = OutRegInfo.REFR_INSTNO; // 의료급여 의뢰기관기호코드
            cboDyntDvcd.SelectValue(OutRegInfo.ETC_USE_CNTS_1);          // 주야공휴구분코드
            //OutRegInfo.Clear();

            m_clscommon.SelectPATRTEIF_ETC56(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), cboOR_REQUEST, cboRECALL);

            string sqltext = $@"
SELECT NVL(ETC_USE_CNTS_21, '0') AS ETC21
  FROM PATRTEIF
 WHERE PID = '{OutRegInfo.PID}'
   AND PT_CMHS_NO = {OutRegInfo.PT_CMHS_NO.ToString()}";

            var temp = DBService.ExecuteScalar(sqltext).ToString();

            cboDisasterSupt.SelectedValue = temp.Equals("0") ? "NO" : temp;

            this.lblMDCAREHSPTHSPTZYN.Visible = Lime.BusinessControls.clsPACommon.SelectMDCAREHSPTHSPTZYN(false, OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString());
        }

        /// <summary>
        /// 입력받은 접수정보를 접수 멤버변수에 담는다.
        /// </summary>
        public bool SetOutRegistrationInfo(string pid, string asct_rgno_cd, string taic_pt_uniq_no, string afrsstatdvcd, string rowstatdvcd, ref string msg)
        {
            try
            {
                int pt_cmhs_no = 0;
                int rcpn_sqno = OutRegInfo.RCPN_SQNO;
                string emrm_dept_cd = string.Empty;

                this.PatientInfo.Load(pid);

                OutRegInfo.PID = pid;
                if (string.IsNullOrWhiteSpace(OutRegInfo.PID))
                    throw new Exception("환자번호가 없습니다.\r\n다시 조회해 주세요.");

                if (!afrsstatdvcd.Equals("6") && !afrsstatdvcd.Equals("4"))
                {
                    SqlPack.Procedure.PR_PA_READ_PTCMHSNO(OutRegInfo.PID, DOPack.UserInfo.USER_CD, ref pt_cmhs_no);
                    // 오류체크하기
                    OutRegInfo.PT_CMHS_NO = pt_cmhs_no;
                }

                OutRegInfo.RCPN_SQNO = clsPACommon.SelectMaxRcpnSqno("O", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO);
                OutRegInfo.MDCR_DD = dteMdcrDd.DateTimeValue.ToString("yyyyMMdd");
                OutRegInfo.APNT_TIME = mskMdcrTime.Value.ToString().Replace(":", "");
                OutRegInfo.MDCR_TIME = mskMdcrTime.Value.ToString().Replace(":", "");

                if (cboMdcrDeptCd.SelectedIndex.Equals(-1))
                    throw new Exception("진료과가 선택되지 않았습니다.");
                OutRegInfo.MDCR_DEPT_CD = cboMdcrDeptCd.Value.ToString();
                OutRegInfo.INSN_CLAM_DEPT_CD = ClinicList.GetColumnValue(OutRegInfo.MDCR_DEPT_CD, "INSN_CLAM_DEPT_CD").ToString();

                // 내역/접수 변경
                if (afrsstatdvcd == "4" || afrsstatdvcd == "6")
                {
                    DataTable dt = new DataTable();

                    // 최신 RCPN_SQNO를 딴다.
                    string sqltext = string.Format(@"SELECT MAX(RCPN_SQNO) FROM PAOPATRT WHERE PID = '{0}' AND PT_CMHS_NO = {1}", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO);
                    object RetVal = DBService.ExecuteScalar(sqltext);
                    if (RetVal == null)
                        throw new Exception("접수 내역을 조회하는 중 에러가 발생했습니다.\r\n(접수일련번호 취득 중 에러 발생)");
                    string orig_rcpn_sqno = RetVal.ToString();

                    // 부서가 변경되었는지 확인
                    if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectMaxMdcrDeptCdOrEmrmMmcdCd(), ref dt
                                                                                               , OutRegInfo.PID
                                                                                               , OutRegInfo.PT_CMHS_NO.ToString()
                                                                                               , orig_rcpn_sqno))
                        throw new Exception("외래접수정보 조회 중 에러가 발생했습니다.");

                    if (dt.Rows.Count.Equals(0))
                        throw new Exception("외래접수정보가 없습니다.");

                    // 부서가 바뀌었을 때
                    if (dt.Rows[0]["MDCR_DEPT_CD"].ToString() != OutRegInfo.MDCR_DEPT_CD)
                    {
                        OutRegInfo.EMRM_MMCD_CD = OutRegInfo.MDCR_DEPT_CD;                  // 응급실주진료부서코드
                        OutRegInfo.ISCL_EMRM_MMCD_CD = OutRegInfo.INSN_CLAM_DEPT_CD;        // 보험청구응급실주진료부서코드

                        // 변경한 부서가 응급실 일때
                        if (OutRegInfo.MDCR_DEPT_CD.Equals("2400"))
                        {
                            // 응급실주진료부서코드 - 옵션에서 읽어서 응급의학과인 경우, 설정된 부서로 접수한다.
                            if (ConfigService.GetConfigValueString("PA", "EMRM_DEFAULT", "EMRM_DEFAULT").Equals("Y"))
                            {
                                emrm_dept_cd = ConfigService.GetConfigValueString("PA", "EMRM_DEFAULT", "EMRM_DEPT_CD");
                                if (!String.IsNullOrWhiteSpace(emrm_dept_cd))
                                {
                                    OutRegInfo.EMRM_MMCD_CD = emrm_dept_cd;
                                    OutRegInfo.ISCL_EMRM_MMCD_CD = DeptList.GetColumnValue(emrm_dept_cd, "INSN_CLAM_DEPT_CD").ToString();
                                }
                            }
                        }
                    }
                }
                else
                {
                    OutRegInfo.EMRM_MMCD_CD = OutRegInfo.MDCR_DEPT_CD;              // 응급실주진료부서코드
                    OutRegInfo.ISCL_EMRM_MMCD_CD = OutRegInfo.INSN_CLAM_DEPT_CD;         // 보험청구응급실주진료부서코드

                    // 응급실주진료부서코드 - 옵션에서 읽어서 응급의학과인 경우, 설정된 부서로 접수한다.
                    if (ConfigService.GetConfigValueString("PA", "EMRM_DEFAULT", "EMRM_DEFAULT").Equals("Y"))
                    {
                        if (cboMdcrDeptCd.SelectedValue.Equals("2400"))
                        {
                            emrm_dept_cd = ConfigService.GetConfigValueString("PA", "EMRM_DEFAULT", "EMRM_DEPT_CD");
                            if (!String.IsNullOrWhiteSpace(emrm_dept_cd))
                            {
                                OutRegInfo.EMRM_MMCD_CD = emrm_dept_cd;
                                OutRegInfo.ISCL_EMRM_MMCD_CD = DeptList.GetColumnValue(emrm_dept_cd, "INSN_CLAM_DEPT_CD").ToString();
                            }
                        }
                    }
                }

                if (cboMdcrDrCd.SelectedIndex.Equals(-1))
                    throw new Exception("진료의가 선택되지 않았습니다.");
                OutRegInfo.MDCR_DR_CD = cboMdcrDrCd.Value.ToString();

                if (cboRealMdcrDrCd.SelectedIndex.Equals(-1))
                    throw new Exception("실진료의가 선택되지 않았습니다.");
                OutRegInfo.REAL_MDCR_DR_CD = cboRealMdcrDrCd.Value.ToString();

                if (cboInsnTycd.SelectedIndex.Equals(-1))
                    throw new Exception("보험유형이 선택되지 않았습니다.");
                OutRegInfo.INSN_TYCD = cboInsnTycd.Value.ToString();

                if (cboAsstTycd.SelectedIndex.Equals(-1))
                    throw new Exception("보조유형이 선택되지 않았습니다.");
                OutRegInfo.ASST_TYCD = cboAsstTycd.Value.ToString();

                OutRegInfo.ASCT_RGNO_CD = asct_rgno_cd;

                if (cboFrvsRvstDvcd.SelectedIndex.Equals(-1))
                    throw new Exception("초재구분이 선택되지 않았습니다.");
                OutRegInfo.FRVS_RVST_DVCD = cboFrvsRvstDvcd.Value.ToString();

                if (cboMcchCmptDvcd.SelectedIndex.Equals(-1))
                    throw new Exception("산정구분이 선택되지 않았습니다.");
                OutRegInfo.MCCH_CMPT_DVCD = cboMcchCmptDvcd.Value.ToString();

                if (cboSmcrYn.SelectedIndex.Equals(-1))
                    throw new Exception("선택진료여부가 선택되지 않았습니다.");
                OutRegInfo.SMCR_YN = cboSmcrYn.Value.ToString();

                if (cboCmhsDvcd.SelectedIndex.Equals(-1))
                    throw new Exception("내원구분이 선택되지 않았습니다.");
                OutRegInfo.CMHS_DVCD = cboCmhsDvcd.Value.ToString();

                if (cboCmhsMotvDvcd.SelectedIndex.Equals(-1))
                    throw new Exception("내원경로가 선택되지 않았습니다.");
                OutRegInfo.CMHS_MOTV_DVCD = cboCmhsMotvDvcd.Value.ToString();

                OutRegInfo.APNT_YN = cboApntYn.Value == null ? "N" : cboApntYn.SelectedValue;
                OutRegInfo.APNT_PATH_DVCD = cboApntPathDvcd.Value == null ? "N" : cboApntPathDvcd.SelectedValue;
                OutRegInfo.EXCP_RESN_CD = cboExcpResnCd == null ? "NO" : cboExcpResnCd.Value.ToString();
                /*
                OutRegInfo.CFSC_RGNO_CD = cboCfscRgnoCd == null ? "NO" : cboCfscRgnoCd.Value.ToString();
                */
                OutRegInfo.CFSC_RGNO_CD = string.IsNullOrWhiteSpace(txtCfscRgno.Text) ? "NO" : txtCfscRgno.Text.ToUpper();
                if (!OutRegInfo.CFSC_RGNO_CD.Equals("NO"))
                {
                    // 존재하는 산정특례기호인지 확인하자.
                    int temp = DBService.ExecuteInteger($@"SELECT COUNT(*) FROM BISCCDMA WHERE CFSC_CD = '{OutRegInfo.CFSC_RGNO_CD}'");
                    if (temp <= 0)
                        throw new Exception($"존재하지 않는 산정특례기호입니다.\r\n => {OutRegInfo.CFSC_RGNO_CD}");
                }

                OutRegInfo.USCH_APLY_CD = cboUschAplyCd == null ? "NO" : cboUschAplyCd.Value.ToString();
                OutRegInfo.REFR_INSTNO = txtRefrInstno.Text;
                OutRegInfo.FCLT_APLY_CD = "NO";
                OutRegInfo.PAY_QLFC_DVCD = cboPayQlfcDvcd.Value == null ? "0" : cboPayQlfcDvcd.Value.ToString();
                OutRegInfo.CNST_REFR_YN = cboCnstRefrYn.Value == null ? "N" : cboCnstRefrYn.Value.ToString();
                OutRegInfo.TAIC_PT_UNIQ_NO = StringService.IsNvl(taic_pt_uniq_no, "NO");
                OutRegInfo.DCNT_RDIA_CD = cboDcntRdiaCd.Value == null ? "NO" : cboDcntRdiaCd.Value.ToString();
                OutRegInfo.DCNT_RDIA_EMNO = txtDcntRrdiaEmno.Text.Trim();
                OutRegInfo.RCPN_AGE = PatientInfo.AGE;
                OutRegInfo.RCPN_ADDR_CD = StringService.IsNvl(PatientInfo.ADDR_BLDG_NO, StringService.IsNvl(PatientInfo.ADDR_CD, "00000"));
                OutRegInfo.DC_DD = OutRegInfo.MDCR_DD;
                OutRegInfo.AFRS_STAT_DVCD = afrsstatdvcd;
                OutRegInfo.ROW_STAT_DVCD = rowstatdvcd;
                OutRegInfo.ECOI_CD = cboEcoiCd.SelectedIndex.Equals(-1) ? "*" : cboEcoiCd.SelectedValue;

                // 일단 정률코드
                OutRegInfo.FXAM_FXRT_DVCD = "9";

                // 상해외인코드가 [E]가 아닌 경우만 정액코드
                if (OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("2") && !OutRegInfo.ASST_TYCD.Equals("99") && !OutRegInfo.ECOI_CD.Equals("E"))
                    OutRegInfo.FXAM_FXRT_DVCD = "0";

                // 주야 구분을 설정한다. 진찰료에 야간 공휴 가산이 설정된 경우 사용자 가산을 변경할 수 있게 변경
                OutRegInfo.ETC_USE_CNTS_1 = cboDyntDvcd.Value == null ? "D" : cboDyntDvcd.SelectedItem.DataValue.ToString();
                OutRegInfo.REBURN = chkReBurn.Checked ? "Y" : "N";
                OutRegInfo.ETC_USE_CNTS_5 = chkReBurn.Checked ? "강제변경:재수상" : "";
                OutRegInfo.RGST_DT = DateTimeService.NowDateTimeNoneSeperatorString();
                OutRegInfo.RGSTR_ID = DOPack.UserInfo.USER_CD;

                return true;
            }
            catch (Exception ex)
            {
                msg = ex.Message;
                return false;
            }
        }

        /// <summary>
        /// 입력한 특이사항을 특이사항 멤버변수에 담는다.
        /// </summary>
        public void SetPatientRemark()
        {
            PatRem.PID = OutRegInfo.PID;
            PatRem.PCLR_MATR_SQNO = PatRem.SelectMaxSqno();
            PatRem.OTPT_ADMS_DVCD = "O";
            PatRem.PTAF_MDCR_DVCD = "P";
            PatRem.PT_CMHS_NO = 0;
            PatRem.WRTN_DD = OutRegInfo.MDCR_DD;
            PatRem.PT_PCLR_MATR = txtPtPclrMatr.Text.Trim();
            PatRem.DEL_YN = "A";
            PatRem.RGST_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            PatRem.RGSTR_ID = DOPack.UserInfo.USER_CD;
            PatRem.UPDT_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            PatRem.UPDTR_ID = DOPack.UserInfo.USER_CD;
        }

        /// <summary>
        /// 진료의뢰여부 및 회송여부를 저장한다. (재난지원 포함)
        /// </summary>
        /// <returns></returns>
        public bool SavePATRTEIF_ETC56()
        {
            if (!m_clscommon.SavePATRTEIF_ETC56(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), cboOR_REQUEST.SelectedValue, cboRECALL.SelectedValue))
                return false;

            // 재난 지원
            string sqltext = @"UPDATE PATRTEIF SET ETC_USE_CNTS_21 = '{2}' WHERE PID = '{0}' AND PT_CMHS_NO = '{1}' ";

            string disaster_supt = cboDisasterSupt.SelectedValue.Contains("CVD") ? cboDisasterSupt.SelectedValue : "0";

            if (!DBService.ExecuteNonQuery(sqltext, OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), disaster_supt))
                return false;

            return true;
        }

        #endregion 

        #region Method : Private Method

        /// <summary>
        /// Master코드의 Sub 코드 Set Combo
        /// </summary>
        /// <param name="ctl"></param>
        private void SetInputValueChanged(Control ctl)
        {
            if (m_DefaultSetting == "N")
                return;

            switch (ctl.Name)
            {
                case "cboInsnTycd":
                    if (cboInsnTycd.Value != null)
                    {
                        OutRegInfo.INSN_TYCD = cboInsnTycd.Value.ToString();
                        // 보조유형 가져오기
                        clsPACommon.SetComboPA(cboAsstTycd, "ASST_TYCD", "LWRN_OVRL_CDNM", cboInsnTycd.Value.ToString().Trim(), dteMdcrDd.DateTimeValue.ToString("yyyyMMdd"));

                        // 선택한 보험유형의 보험정보를 표시한다.
                        OnPatientSelected("INSNTYCD");

                        if (OutRegInfo.INSN_TYCD == "11")
                        {
                            if (DateTime.Today >= DateTimeService.ConvertDateTime("20190101") && PatientInfo.AGE < 1)
                            {
                                OutRegInfo.ASST_TYCD = "W0";
                                cboAsstTycd.SelectValue("W0");
                            }
                            else if (PatientInfo.AGE < 6)
                            {
                                OutRegInfo.ASST_TYCD = "60";
                                cboAsstTycd.SelectValue("60");
                            }
                        }
                        else if (OutRegInfo.INSN_TYCD == "51")
                        {

                        }
                        else
                        {
                            OutRegInfo.ASST_TYCD = "00";
                            cboAsstTycd.SelectValue("00");
                        }

                        // 당일 동일진료과, 보험유형으로 접수된 접수정보 확인해서 진찰료산정구분 설정
                        SetcboMcchCmptDvcd();
                    }
                    break;
                case "cboAsstTycd":
                    // 보험정보 표시하기
                    if (cboInsnTycd.Value != null)
                        OnPatientSelected("ASSTTYCD");
                    break;
                case "cboMdcrDeptCd":

                    if (cboMdcrDeptCd.Value != null)
                    {
                        OutRegInfo.MDCR_DEPT_CD = cboMdcrDeptCd.Value.ToString();
                        // 의사코드조회
                        cboMdcrDrCd.Clear();
                        clsPACommon.SetComboPA(cboMdcrDrCd, "USER_CD", "USER_NM", OutRegInfo.MDCR_DEPT_CD, OutRegInfo.MDCR_DD);
                        // 실진료의
                        cboRealMdcrDrCd.Clear();
                        clsPACommon.SetComboPA(cboRealMdcrDrCd, "USER_CD", "USER_NM", OutRegInfo.MDCR_DEPT_CD, OutRegInfo.MDCR_DD);

                        // 선택진료여부 설정
                        cboSmcrYn.SelectValue(SelectBiUserDtSlctDrYn(OutRegInfo.MDCR_DEPT_CD, cboMdcrDrCd.Value == null ? "NO" : cboMdcrDrCd.Value.ToString(), OutRegInfo.MDCR_DD));

                        // 응급의학과 선택시 내원구분 응급으로 변경
                        if (cboMdcrDeptCd.Value.Equals("2400"))
                        {
                            cboCmhsDvcd.SelectedValue = "2";
                        }

                        // 청구부서 가져온다.
                        string insnclamdeptcd = ClinicList.GetColumnValue(OutRegInfo.MDCR_DEPT_CD, "INSN_CLAM_DEPT_CD").ToString();

                        // 예외사유코드설정
                        switch (insnclamdeptcd)
                        {
                            case "24":
                                cboExcpResnCd.SelectValue("11");
                                break;
                            case "03":
                                cboExcpResnCd.SelectValue("13");
                                break;
                            default:
                                cboExcpResnCd.SelectValue("NO");
                                break;
                        }

                        //진료과목에서 '['와 ']'가 쌍이 맞지 않으면 '대괄호가 누락되었습니다'에러가 뜨므로 추가. YJS
                        if (OutRegInfo.MDCR_DEPT_CD.Contains("[") || OutRegInfo.MDCR_DEPT_CD.Contains("]"))
                            OutRegInfo.MDCR_DEPT_CD = "";

                        // 당일 동일진료과, 보험유형으로 접수된 접수정보 확인해서 진찰료산정구분 설정
                        SetcboMcchCmptDvcd();

                        // 신환이 아닌경우 과거접수정보 확인하여 초진재진구분 설정
                        if (OutRegInfo.NEW_PID_YN != "Y")
                        {
                            string msg = "";
                            string frvsrvstdvcd = "";
                            if (!OutRegInfo.CheckFrvsRvstDvcd(ref msg))
                            {
                                MessageBox.Show(msg + " 초진재진 체크중 오류가 발생헀습니다. ", "초진재진체크", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                return;
                            }

                            cboFrvsRvstDvcd.SelectValue(OutRegInfo.FRVS_RVST_DVCD);
                        }

                        //접수시간, 예약시간설정
                        // 2018-07-23 SEO 불필요로 인한 코멘트아웃
                        /*
                        if (OutRegInfo.MDCR_DD == DateTime.Now.ToString("yyyyMMdd"))
                        {
                            OutRegInfo.MDCR_TIME = DateTime.Now.ToString("HHmm");
                            OutRegInfo.APNT_TIME = DateTime.Now.ToString("HHmm");
                            mskMdcrTime.Text = OutRegInfo.MDCR_TIME;
                        }
                         * */

                        // 의사 진료 일정 확인


                        // 종합검진 또는 일반검진인 경우 보험유형 일반에 내원구분 종검 진찰료 산정안함으로 설정.
                        string mdcrdeptcd = cboMdcrDeptCd.Value.ToString();

                        // 종합검진
                        if (mdcrdeptcd.Equals("7001"))
                        {
                            OutRegInfo.MCCH_CMPT_DVCD = "N";
                            OutRegInfo.CMHS_DVCD = "3";
                            OutRegInfo.INSN_TYCD = "11";
                            OutRegInfo.ASST_TYCD = "99";

                            cboMcchCmptDvcd.Value = "N";
                            cboCmhsDvcd.Value = "3";
                            cboInsnTycd.Value = "11";
                            cboAsstTycd.Value = "99";
                        }
                        // 일반검진
                        else if (mdcrdeptcd.Equals("7002"))
                        {
                            OutRegInfo.MCCH_CMPT_DVCD = "N";
                            OutRegInfo.CMHS_DVCD = "T";
                            OutRegInfo.INSN_TYCD = "11";
                            OutRegInfo.ASST_TYCD = "99";

                            cboMcchCmptDvcd.Value = "N";
                            cboCmhsDvcd.Value = "T";
                            cboInsnTycd.Value = "11";
                            cboAsstTycd.Value = "99";
                        }
                        // 특수검진
                        else if (mdcrdeptcd.Equals("7004"))
                        {
                            OutRegInfo.MCCH_CMPT_DVCD = "N";
                            OutRegInfo.CMHS_DVCD = "E";
                            OutRegInfo.INSN_TYCD = "11";
                            OutRegInfo.ASST_TYCD = "99";

                            cboMcchCmptDvcd.Value = "N";
                            cboCmhsDvcd.Value = "E";
                            cboInsnTycd.Value = "11";
                            cboAsstTycd.Value = "99";
                        }
                    }
                    break;
                case "cboMdcrDrCd":

                    // 선택진료여부 설정
                    OutRegInfo.MDCR_DR_CD = cboMdcrDrCd.SelectedValue;
                    cboSmcrYn.SelectValue(SelectBiUserDtSlctDrYn(OutRegInfo.MDCR_DEPT_CD, OutRegInfo.MDCR_DR_CD, OutRegInfo.MDCR_DD));
                    // 의사 진료 일정 확인
                    break;
                case "cboRealMdcrDrCd":
                    OutRegInfo.REAL_MDCR_DR_CD = cboRealMdcrDrCd.SelectedValue;
                    break;
                case "cboApntYn":           // 예약여부
                    // 진료의 진료일정 보여주기
                    break;
                case "cboFrvsRvstDvcd":     // 초진재진구분코드
                    OutRegInfo.FRVS_RVST_DVCD = cboFrvsRvstDvcd.SelectedValue;  
                    break;
                case "cboCmhsDvcd":         // 내원구분코드
                    OutRegInfo.CMHS_DVCD = cboCmhsDvcd.Value.ToString();
                    switch (OutRegInfo.CMHS_DVCD)
                    {
                        // 내원구분:환자가족처방 => 산정구분:보호자 내원 처방전 수령
                        case "5":
                            OutRegInfo.MCCH_CMPT_DVCD = "O";
                            cboMcchCmptDvcd.SelectValue("O");
                            break;
                        case "3":
                        case "9":
                        case "T":
                        case "E": // 특수검진
                            OutRegInfo.MCCH_CMPT_DVCD = "N";
                            OutRegInfo.INSN_TYCD = "11";
                            OutRegInfo.ASST_TYCD = "99";
                            cboMcchCmptDvcd.SelectValue("N");
                            cboInsnTycd.SelectValue("11");
                            cboAsstTycd.SelectValue("99");

                            SetInputValueChanged((Control)cboInsnTycd);
                            break;
                        case "4": // 진단서발행
                        case "S": // 예방접종
                        case "10": // 레이저
                            OutRegInfo.MCCH_CMPT_DVCD = "N";
                            OutRegInfo.INSN_TYCD = "51";
                            OutRegInfo.ASST_TYCD = "99";
                            cboMcchCmptDvcd.SelectValue("N");
                            cboInsnTycd.SelectValue("51");
                            cboAsstTycd.SelectValue("99");
                            break;
                        case "11": // (산재) 수수료 청구
                            OutRegInfo.MCCH_CMPT_DVCD = "N";
                            OutRegInfo.INSN_TYCD = "31";
                            OutRegInfo.ASST_TYCD = "00";
                            cboMcchCmptDvcd.SelectValue("N");
                            cboInsnTycd.SelectValue("31");
                            cboAsstTycd.SelectValue("00");

                            SetInputValueChanged((Control)cboInsnTycd);
                            break;
                        case "7": //물리치료/주사이면, 산정구분 '병원관리료 재진 50%' 설정
                            OutRegInfo.MCCH_CMPT_DVCD = "P";
                            cboMcchCmptDvcd.SelectValue("P");
                            break;
                        case "R":
                            if (OutRegInfo.FRVS_RVST_DVCD.Equals("3"))
                            {
                                OutRegInfo.FRVS_RVST_DVCD = "2";
                                cboFrvsRvstDvcd.SelectValue("2");
                                LxMessage.ShowInformation("내원구분이 [건강진단결과서]인 경우,\r\n초재구분은 [초진]으로 세팅됩니다.");
                            }
                            break;
                        default:
                            OutRegInfo.MCCH_CMPT_DVCD = "Y";
                            cboMcchCmptDvcd.SelectValue("Y");
                            break;
                    }

                    if (OutRegInfo.CMHS_DVCD != "R")
                    {
                        // 초재구분을 다시 계산해보자. (메시지 없이 자동 세팅)
                        string msg = string.Empty;
                        string frvs_rvst_dvcd = string.Empty;
                        if (SqlPack.Procedure.PR_PA_PRC_FRVSRVSTSET(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO, OutRegInfo.MDCR_DD, OutRegInfo.INSN_CLAM_DEPT_CD, ref frvs_rvst_dvcd, ref msg))
                        {
                            if (cboFrvsRvstDvcd.SelectedValue != frvs_rvst_dvcd)
                            {
                                if (LxMessage.ShowQuestion($"선택된 초재구분과 계산한 초재구분이 다릅니다\r\n계산한 초재구분으로 변경하시겠습니까?\r\n\r\n   - 선택된 초재구분 : {OverallCodeList.GetName("FRVS_RVST_DVCD", cboFrvsRvstDvcd.SelectedValue)}\r\n   - 계산한 초재구분 : {OverallCodeList.GetName("FRVS_RVST_DVCD", frvs_rvst_dvcd)}").Equals(DialogResult.Yes))
                                {
                                    OutRegInfo.FRVS_RVST_DVCD = frvs_rvst_dvcd;
                                    cboFrvsRvstDvcd.SelectValue(frvs_rvst_dvcd);
                                }
                            }
                        }
                    }

                    break;
                    /* 당일 검진을 목적으로 내원한 경우 */
                    // 내원구분
                    switch (OverallCodeList.GetColumnValue("CMHS_DVCD", OutRegInfo.CMHS_DVCD, "ETC_USE_CNTS_2").ToString())
                    {
                        case "2": //영유아검진
                        case "3": //일반검진
                        case "4": //생애전환기
                        case "5": //암검진
                            OutRegInfo.MCCH_CMPT_DVCD = "N";
                            OutRegInfo.INSN_TYCD = "11";
                            OutRegInfo.ASST_TYCD = "99";
                            cboMcchCmptDvcd.SelectValue("N");
                            cboInsnTycd.SelectValue("11");
                            cboAsstTycd.SelectValue("99");
                            break;
                    }
                case "cboDcntRdiaCd":
                    if (cboDcntRdiaCd.Value == null) return;
                    if (cboDcntRdiaCd.Value.ToString().Equals("NO"))
                    {
                        txtDcntRrdiaEmno.Text = String.Empty;
                        cboCmhsMotvDvcd.SelectValue("NO");

                    }
                    else
                    {
                        // TODO : 일단 할인코드가 선택되면 내원경로 지인소개로 변경함..
                        cboCmhsMotvDvcd.SelectValue("02");
                        txtDcntRrdiaEmno.ReadOnly = false;
                    }
                    break;
                case "txtDcntRrdiaEmno":    // 직원번호
                    // 직원번호 확인
                    break;
            }
        }

        /// <summary>
        /// 진찰료산정구분을 세팅한다.
        /// </summary>
        private void SetcboMcchCmptDvcd()
        {
            // 접수
            if (StringService.IsNull(OutRegInfo.PT_CMHS_NO.ToString()))
            {
                // 당일 동일진료과, 보험유형으로 접수된 접수정보 확인해서 진찰료산정구분 설정
                if (DBService.ExecuteInteger(SQL.PA.Sql.SelectPAOPATRT_SAMEDEPT_COUNT(), OutRegInfo.PID
                                                                                       , OutRegInfo.MDCR_DD
                                                                                       , OutRegInfo.MDCR_DEPT_CD
                                                                                       , OutRegInfo.INSN_TYCD) > 0)
                {
                    cboMcchCmptDvcd.SelectValue("N");
                }
                else
                {
                    cboMcchCmptDvcd.SelectValue("Y");
                }
            }
            // 변경
            else
            {
                // 당일 동일진료과, 보험유형으로 접수된 접수정보 확인해서 진찰료산정구분 설정
                if (DBService.ExecuteInteger(SQL.PA.Sql.SelectPAOPATRT_SAMEDEPT_COUNT_Change(), OutRegInfo.PID
                                                                                       , OutRegInfo.MDCR_DD
                                                                                       , OutRegInfo.MDCR_DEPT_CD
                                                                                       , OutRegInfo.INSN_TYCD
                                                                                       , OutRegInfo.PT_CMHS_NO.ToString()) > 0)
                {
                    cboMcchCmptDvcd.SelectValue("N");
                }
                else
                {
                    cboMcchCmptDvcd.SelectValue("Y");
                }
            }
        }

        /// <summary>
        /// 선택진료의사 여부 확인.
        /// </summary>
        /// <param name="mdcrdeptcd"></param>
        /// <param name="mdcrdrcd"></param>
        /// <param name="mdcrdd"></param>
        /// <returns></returns>
        private string SelectBiUserDtSlctDrYn(string mdcrdeptcd, string mdcrdrcd, string mdcrdd)
        {
            string result = "";
            result = ConfigService.GetConfigValueString("PA", "SPCR_OUT", "APLY_YN").ToString();
            if (result == "Y")
            {
                return StringService.IsNvl(DoctorList.GetColumnValue(mdcrdrcd, mdcrdeptcd, "SLCT_DR_YN").ToString(), "N");
            }
            return "N";
        }

        /// <summary>
        /// 의뢰기관 팝업
        /// </summary>
        private void ViewChoosePlace()
        {
            try
            {
                DataTable insn_info = new DataTable();

                DialogResult result = LxMessage.Show("진료의뢰정보를 등록하시겠습니까?\r\n[   예   ]진료의뢰정보등록\r\n[아니오]선택기관만 선택", "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    DOPatientInfo ptinfo = new DOPatientInfo();
                    ptinfo.Load(OutRegInfo.PID);

                    string pid = ptinfo.PID;                                  // 환자번호
                    string ptnm = ptinfo.PT_NM;                               // 환자명
                    string frrn = ptinfo.FRRN;                                // 주민등록번호 앞자리
                    string srrn = ptinfo.SRRN;                                // 주민등록번호 뒷자리
                    string sex = ptinfo.Sex;                                  // 성별
                    string age = ptinfo.Age;                                  // 나이
                    string inpnnm = string.Empty;                             // 피보험자명
                    string inpnfrrn = string.Empty;                           // 피보험자 주민등록번호 앞자리
                    string inpnsrrn = string.Empty;                           // 피보험자 주민등록번호 뒷자리
                    string mdcrdd = OutRegInfo.MDCR_DD;                       // 진료일자
                    string fstdeptcd = OutRegInfo.MDCR_DEPT_CD;               // 진료부서
                    string fstdrcd = OutRegInfo.MDCR_DR_CD;                   // 진료의사
                    string insntycd = OutRegInfo.INSN_TYCD;                   // 보험유형

                    if (StringService.SubString(OutRegInfo.INSN_TYCD, 1) == "1" || StringService.SubString(OutRegInfo.INSN_TYCD, 1) == "2")
                    {
                        DBService.ExecuteDataTable(SQL.PA.Sql.SelectInsnInfo(), ref insn_info, ptinfo.PID, OutRegInfo.INSN_TYCD);

                        if (insn_info.Rows.Count > 0)
                        {
                            inpnnm = insn_info.Rows[0]["HLNS_INPN_NM"].ToString();
                            inpnfrrn = insn_info.Rows[0]["INPN_FRRN"].ToString();
                            inpnsrrn = insn_info.Rows[0]["INPN_SRRN"].ToString();
                        }
                        else
                        {
                            inpnnm = ptnm;
                            inpnfrrn = frrn;
                            inpnsrrn = srrn;
                        }
                    }

                    frmMedReferInfoP popRefer = new frmMedReferInfoP(pid, ptnm, frrn, srrn, sex, age, inpnnm, inpnfrrn, inpnsrrn, mdcrdd, fstdeptcd, fstdrcd, 0);

                    popRefer.ShowDialog(this);
                    popRefer.Dispose();
                }
                else
                {
                    string pid = "";
                    if (OnShowPop != null)
                        OnShowPop();
                }
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }
        #endregion Method : Private Method

        #region Control Events
        private void Control_ValueChanged(object sender, EventArgs e)
        {
            SetInputValueChanged((Control)sender);
        }

        private void txtRefrInstno_EditorButtonClick(object sender, Infragistics.Win.UltraWinEditors.EditorButtonEventArgs e)
        {
            ViewChoosePlace();
        }
        #endregion

        #region Method : Raised Event
        public void OnPatientSelected(string argsValue)
        {
            SelectDataEventArgs args = new SelectDataEventArgs(argsValue);
            if (this.PatientSelected != null)
            {
                this.PatientSelected(this, args);
            }
        }
        #endregion

        #region EventArgs
        public class SelectDataEventArgs : EventArgs
        {
            /*
            private DOPatientInfo m_PatientEventArgs;

            public DOPatientInfo PatientEventArgs
            {
                get { return m_PatientEventArgs; }
                set { m_PatientEventArgs = value; }
            }


            public SelectDataEventArgs(DOPatientInfo patientEventArgs)
            {
                this.m_PatientEventArgs = patientEventArgs;
            }
            */

            private string m_SeletedUserControl = String.Empty;

            public string SeletedUserControl
            {
                get { return m_SeletedUserControl; }
                set { m_SeletedUserControl = value; }
            }
            public SelectDataEventArgs(string SeletedUserControl)
            {
                this.m_SeletedUserControl = SeletedUserControl;
            }

        }
        #endregion
    }
}
