using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public partial class popSetAmtChange : BasePopUp
    {
        string m_PID = String.Empty;
        string m_PT_CMHS_NO = String.Empty;
        string m_MDCR_DD = String.Empty;
        string m_PRSC_SQNO = String.Empty;
        string m_PRICE = String.Empty;
        string m_ONE_PRICE = String.Empty;
        string m_PRSC_UNIQ_NO = String.Empty;

        public popSetAmtChange(string pid, string pt_cmhs_no, string mdcr_dd, string prsc_sqno, string price = "")
        {
            InitializeComponent();

            m_PID = pid;
            m_PT_CMHS_NO = pt_cmhs_no;
            m_MDCR_DD = mdcr_dd;
            m_PRSC_SQNO = prsc_sqno;
            m_PRICE = price;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            Initialize();
            InitializeEvent();
        }

        private void Initialize()
        {
            txtChangePrice.Focus();

            SelectData();
        }

        private void InitializeEvent()
        {
            btnSave.Click += btnSave_Click;
            txtChangePrice.KeyDown += txtChangePrice_KeyDown;
        }

        private void SelectData()
        {
            DataTable prsc = new DataTable();

            if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectAmtChangeORORDRRT(), ref prsc
                                                                               , m_PID
                                                                               , m_PT_CMHS_NO
                                                                               , m_MDCR_DD
                                                                               , m_PRSC_SQNO))
            {
                LxMessage.Show("처방정보 조회 중 오류가 발생했습니다.\r\n처방정보를 확인바랍니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                btnSave.Enabled = false;
                return;
            }

            if (prsc.Rows.Count <= 0)
            {
                LxMessage.Show("처방정보 조회 중 오류가 발생했습니다.\r\n처방정보를 확인바랍니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                btnSave.Enabled = false;
                return;
            }

            lblPrscCd.Text += prsc.Rows[0]["PRSC_CD"].ToString();
            lblPrscNm.Text += prsc.Rows[0]["PRSC_NM"].ToString();
            m_PRSC_UNIQ_NO = prsc.Rows[0]["PRSC_UNIQ_NO"].ToString();
            lblPriceAmt.Text = prsc.Rows[0]["ONE_PRICE"].ToString();
            m_ONE_PRICE = prsc.Rows[0]["ONE_PRICE"].ToString();

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            decimal price = 0;

            if (String.IsNullOrWhiteSpace(txtChangePrice.Text))
            {
                LxMessage.Show("변경할 금액을 입력 해 주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (txtChangePrice.Text == "0")
            {
                LxMessage.Show("금액을 입력 해 주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateAmtChangeORORDRRT(), txtChangePrice.Text.Replace(",", "")
                                                                              , m_PID
                                                                              , m_PRSC_UNIQ_NO))
            {
                LxMessage.Show("저장 중 오류가 발생했습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            //LxMessage.Show("금액변경 하였습니다.", "알림", MessageBoxButtons.OK ,MessageBoxIcon.Information, 2);

            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();

        }

        private void txtChangePrice_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                btnSave.Focus();
        }
    }
}
