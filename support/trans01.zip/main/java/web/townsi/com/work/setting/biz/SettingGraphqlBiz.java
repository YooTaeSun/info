package web.townsi.com.work.setting.biz;

import java.util.HashMap;

public interface SettingGraphqlBiz {
	public abstract HashMap<String, Object> makeGraphql(HashMap paramHashMap) throws Exception;
	public abstract HashMap<String, Object> makeGraphqlService(HashMap paramHashMap) throws Exception;
}