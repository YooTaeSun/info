package web.townsi.com.work.convert.doc;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.simple.JSONObject;

import web.townsi.com.utils.Util;

public class Trans {

	public Trans() {

	}

	public static String TAB_SIZE = "    ";
	public static String IMPORT_START_STR = "// import start";
	public static String rLine = "\r\n";
	public static String strOfLine = "<rEaDlInE>";

	public String convert(JSONObject JSON_OBJECT, String str) {

		String curTime = Util.getCurTime();

		String[] str_araay = str.split("\\r\\n");
		List<String> list = Arrays.asList(str_araay);

		StringBuilder sb = new StringBuilder(16 ^ 5);
		String line = "";
		
		JSONObject langObj = null; 
//		for (String lang : TransExcute.LANGS) {
////			langObj = LANG_MAP.get(lang);
//		}
		
		for (int i = 0; i < list.size(); i++) {
			line = list.get(i);
		
			Pattern p = Pattern.compile("[가-힣]");
			Matcher m = p.matcher(line);
			
			StringBuilder hanSb = new StringBuilder(16 ^ 3);
			while (m.find()) {
//				System.out.println("line >> " + line);
				hanSb.append(m.group());
			}
			
			if (!hanSb.toString().isEmpty()) {
				System.out.println("line >> " + line);
				System.out.println(hanSb.toString());
				System.out.println("");
			}
			
			if(m.find()) {
				System.out.println("line >> " + line);
//				hanSb.append(m.group());
			}
			sb.append(line + "\r\n");
		}
		return sb.toString();
	}

	// 메세드 파라미터
}