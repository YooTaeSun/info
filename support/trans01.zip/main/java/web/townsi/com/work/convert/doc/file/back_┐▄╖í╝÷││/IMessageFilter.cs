#region 어셈블리 System.Windows.Forms, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089
// C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.5\System.Windows.Forms.dll
#endregion


namespace System.Windows.Forms
{
    //
    // 요약:
    //     메시지 필터 인터페이스를 정의합니다.
    public interface IMessageFilter
    {
        //
        // 요약:
        //     메시지가 디스패치되기 전에 필터링합니다.
        //
        // 매개 변수:
        //   m:
        //     디스패치될 메시지입니다. 이 메시지는 수정할 수 없습니다.
        //
        // 반환 값:
        //     메시지를 필터링하고 디스패치되지 않게 하려면 true이고 다음 필터 또는 컨트롤에 계속 사용하려면 false입니다.
        bool PreFilterMessage(ref Message m);
    }
}