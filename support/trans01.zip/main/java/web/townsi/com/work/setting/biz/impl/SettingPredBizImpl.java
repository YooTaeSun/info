package web.townsi.com.work.setting.biz.impl;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;
import web.townsi.com.utils.ListUtil;
import web.townsi.com.work.mapper.SettingMapper;
import web.townsi.com.work.setting.biz.SettingBiz;
import web.townsi.com.work.setting.biz.SettingPredBiz;
import web.townsi.com.work.setting.biz.SqlByMybaitisBiz;
import web.townsi.com.work.setting.biz.SqlByMybaitisSamsBiz;

/**
 * SettingServiceImpl
 *
 * @author 유태선
 * @since 2020.08.31
 * @version 1.0
 * @see
 *      </pre>
 */
@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
@Service
public class SettingPredBizImpl implements SettingPredBiz {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private SettingBiz settingBiz;

	@Autowired
	private SqlByMybaitisBiz sqlByMybaitisBiz;

	@Autowired
	private SqlByMybaitisSamsBiz sqlByMybaitisSamsBiz;

	@Autowired
	private SettingMapper settingMapper;

	public static String READ_LINE = "\n";
	public static String LINE = "\n";
	public static String TAB = "\t";
	public static String SLASH = File.separator;// lastIndexOf("/")
	public static String rTxt = "#{txt}";
	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();
	public static String SPACE_CNT = "    ";


	public static  String WHERE_PARAM_PREFIX = "search";

	
	@Override
	public HashMap<String, Object> makePred(HashMap params) throws Exception {
		
		HashMap dataMap = new HashMap();

		HashMap entityObj = (HashMap) params.get("entityObj");
		
		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String tableSchema = StringUtils.defaultString((String) params.get("tableSchema"));
		String upperTableName = tableName.toUpperCase();
		String lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		String camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		String camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String modelComment = StringUtils.defaultString((String) params.get("modelComment"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String group1 = StringUtils.defaultString((String) params.get("group1"));
		String author = StringUtils.defaultString((String) params.get("author"));
		String desc = StringUtils.defaultString((String) params.get("desc"));
		String today = StringUtils.defaultString((String) params.get("today"));
		String current = StringUtils.defaultString((String) params.get("current"));
		String menu = StringUtils.defaultString((String) params.get("menu"));
		String programId = StringUtils.defaultString((String) params.get("programId"));

		String ifcase = StringUtils.defaultString((String) params.get("ifcase"),"if_package");
		String whereParamPrefix = StringUtils.defaultString((String) params.get("whereParamPrefix"),"");
		String sqlComment = StringUtils.defaultString((String) params.get("sqlComment"),"N");
		String sort = StringUtils.defaultString((String) params.get("sort"));
		String taskName = StringUtils.defaultString((String) params.get("taskName"));
		String taskNameFirstUpperName = StringUtils.defaultString((String) params.get("taskNameFirstUpperName"));
		String packageNm = StringUtils.defaultString((String) params.get("packageNm"));
		String tableNewName = StringUtils.defaultString((String) params.get("tableNewName"));
		String tableNewFirstUpperName = StringUtils.defaultString((String) params.get("tableNewFirstUpperName"));

		
		StringBuilder insertSql = new StringBuilder(500);
		StringBuilder insertValSql = new StringBuilder(500);

		StringBuilder bulkInsertSql = new StringBuilder(500);
		StringBuilder bulkInsertValSql = new StringBuilder(500);

		StringBuilder updateSql = new StringBuilder(500);
		
		StringBuilder selectSql = new StringBuilder(500);
		StringBuilder selectColsSql = new StringBuilder(500);
		
		StringBuilder whereSql = new StringBuilder(500);
		StringBuilder whereVari = new StringBuilder(500);
		

		String column_name = "";
		String column_comment = "";
		String camel_column_name = "";
		String columns = "";
		String pk = "";
		String orderByPK = "";
		String w_type = "";
		String pkStr = "";
		String comments = "";
		String dataType = "";

		boolean isRegId = false;
    	boolean isModId = false;
    	
		HashMap replaceMap = new HashMap();
		replaceMap.put("#tableName#",camelTableFirstUpperName);
		

		List<HashMap> list = settingBiz.selectTableInfo(params,
				  StringUtils.defaultString((String)params.get("dbName"))
				, StringUtils.defaultString((String)params.get("tableSchema"))
			    , StringUtils.defaultString((String)params.get("tableName"))
				);

		if(!ListUtil.isEmpty(list)) {
			
			int cnt = 0; 
			int whereSqlCnt = 0;
			String getNameFirstUpper = "";
			String name = "";
			String type = "";
			
			for (int i = 0; i < list.size(); i++) {
				HashMap rs = list.get(i);
				column_name = (String) rs.get("columnName");
				column_comment = (String) rs.get("columnComment");
				camel_column_name = (String) rs.get("camelColumnName");
				columns = (String) rs.get("columns");
				comments = (String) rs.get("comments");
				
				comments = comments.trim();
				if(comments.length() > 30) {
					if(comments.indexOf(" ") != -1) {
						comments = comments.substring(0, comments.indexOf(" "));
					}
				}
				
				w_type = (String) rs.get("wType");
				dataType = (String) rs.get("dataType");
				
				if(entityObj != null && !entityObj.isEmpty()) {
					HashMap<String, String> map = (HashMap<String, String>) entityObj.get(column_name);
					if(map != null && !map.isEmpty()) {
						name = map.get("name");
						
						if(name.isEmpty()) {
							continue;
						}
						
						getNameFirstUpper = "params.get" + name.substring(0,1).toUpperCase() + name.substring(1) + "()";
						type = map.get("type");
					}
				}
				
				if(!(camel_column_name.equals("prgmId") 
					|| camel_column_name.equals("frstRegrId")
					|| camel_column_name.equals("frstRgstDt")
					|| camel_column_name.equals("lastUpdrId")
					|| camel_column_name.equals("lastUpdtDt")
					|| camel_column_name.equals("lastIfDttm")
					) ) {
					if(!name.isEmpty()) {
						if(w_type.equals("Integer") || w_type.equals("Long") || w_type.equals("FLOAT") || w_type.startsWith("Date")) {
							if(!comments.isEmpty()) {whereSql.append("\t\t /* " + comments+ " */"+ READ_LINE);}
							whereSql.append("\t\tif("+getNameFirstUpper+" != null ) {" + READ_LINE);	
						}else {
							if(!comments.isEmpty()) {whereSql.append("\t\t /* " + comments+ " */"+ READ_LINE);}
							whereSql.append("\t\tif(StringUtils.isNotEmpty("+getNameFirstUpper+")) {" + READ_LINE);	
						}
						whereSql.append("\t\t\tbuilder.and(q"+tableNewFirstUpperName+"."+name+".eq("+getNameFirstUpper+"));" + READ_LINE);
						whereSql.append("\t\t}\n" + READ_LINE);
					}else {
						getNameFirstUpper = "params.get" + camel_column_name.substring(0,1).toUpperCase() + camel_column_name.substring(1) + "()";
						
						if(w_type.equals("Integer") || w_type.equals("Long") || w_type.equals("FLOAT") || w_type.startsWith("Date")) {
							if(!comments.isEmpty()) {whereSql.append("\t\t /* " + comments+ " */"+ READ_LINE);}
							whereSql.append("\t\tif("+getNameFirstUpper+" != null ) {" + READ_LINE);	
						}else {
							if(!comments.isEmpty()) {whereSql.append("\t\t /* " + comments+ " */"+ READ_LINE);}
							whereSql.append("\t\tif(StringUtils.isNotEmpty("+getNameFirstUpper+")) {" + READ_LINE);	
						}
						whereSql.append("\t\t\tbuilder.and(q"+tableNewFirstUpperName+"."+camel_column_name+".eq("+getNameFirstUpper+"));" + READ_LINE);
						whereSql.append("\t\t}\n" + READ_LINE);
					}
					whereSqlCnt++;
				}
				
			}
		} 
		
		replaceMap.put("#taskName#", taskName);
		replaceMap.put("#camelTableName#", camelTableName);
		replaceMap.put("#taskNameFirstUpperName#", taskNameFirstUpperName);
		replaceMap.put("#where#", whereSql.toString().replace("\t", SPACE_CNT));
		replaceMap.put("#select#", selectSql.append("\t\t.fetchOne();"+ "\n").toString().replace("\t", SPACE_CNT));
		replaceMap.put("#desc#", desc);
		replaceMap.put("#author#", author);
		replaceMap.put("#today#", today); 
		replaceMap.put("#packageNm#", packageNm);
		replaceMap.put("#tableNewName#", tableNewName);
		replaceMap.put("#tableNewFirstUpperName#", tableNewFirstUpperName);
		
		String rfullPath = SITE_WEB_ROOT + "/copy/SamplePred.java";
		String wfullPath = "";
		wfullPath = SITE_WEB_ROOT + "/new/" + tableSchema + "/" + tableName+"/"+tableNewFirstUpperName+"Pred.java";
		String str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);

		dataMap.put("str", str);
		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}
}