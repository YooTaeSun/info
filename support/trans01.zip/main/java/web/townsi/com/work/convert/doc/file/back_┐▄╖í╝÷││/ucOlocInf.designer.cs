namespace Lime.PA
{
    partial class ucOlocInf
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucOlocInf));
            FarPoint.Win.Spread.EnhancedScrollBarRenderer enhancedScrollBarRenderer1 = new FarPoint.Win.Spread.EnhancedScrollBarRenderer();
            FarPoint.Win.Spread.EnhancedScrollBarRenderer enhancedScrollBarRenderer2 = new FarPoint.Win.Spread.EnhancedScrollBarRenderer();
            FarPoint.Win.Spread.CellType.TextCellType textCellType1 = new FarPoint.Win.Spread.CellType.TextCellType();
            this.sprVisitPlace = new Lime.Framework.Controls.LxSpread();
            this.sprVisitPlace_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.lxTitlePanel1 = new Lime.Framework.Controls.LxTitlePanel();
            ((System.ComponentModel.ISupportInitialize)(this.sprVisitPlace)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprVisitPlace_Sheet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitlePanel1)).BeginInit();
            this.lxTitlePanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // sprVisitPlace
            // 
            this.sprVisitPlace.AccessibleDescription = "";
            this.sprVisitPlace.AllowUserZoom = false;
            this.sprVisitPlace.BackColor = System.Drawing.Color.White;
            this.sprVisitPlace.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.sprVisitPlace.ButtonDrawMode = FarPoint.Win.Spread.ButtonDrawModes.CurrentCell;
            this.sprVisitPlace.ColumnSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never;
            this.sprVisitPlace.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sprVisitPlace.EditModePermanent = true;
            this.sprVisitPlace.EditModeReplace = true;
            this.sprVisitPlace.FocusRenderer = new FarPoint.Win.Spread.CustomFocusIndicatorRenderer(((System.Drawing.Bitmap)(resources.GetObject("sprVisitPlace.FocusRenderer"))), 2);
            this.sprVisitPlace.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.sprVisitPlace.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.sprVisitPlace.HorizontalScrollBar.Name = "";
            enhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            enhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(190)))), ((int)(((byte)(190)))));
            this.sprVisitPlace.HorizontalScrollBar.Renderer = enhancedScrollBarRenderer1;
            this.sprVisitPlace.HorizontalScrollBar.TabIndex = 4;
            this.sprVisitPlace.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.sprVisitPlace.Location = new System.Drawing.Point(3, 35);
            this.sprVisitPlace.Name = "sprVisitPlace";
            this.sprVisitPlace.RowSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never;
            this.sprVisitPlace.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Both;
            this.sprVisitPlace.ScrollTipPolicy = FarPoint.Win.Spread.ScrollTipPolicy.Both;
            this.sprVisitPlace.SelectionBlockOptions = FarPoint.Win.Spread.SelectionBlockOptions.Rows;
            this.sprVisitPlace.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.sprVisitPlace_Sheet1});
            this.sprVisitPlace.Size = new System.Drawing.Size(394, 270);
            this.sprVisitPlace.TabIndex = 0;
            this.sprVisitPlace.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.sprVisitPlace.VerticalScrollBar.Name = "";
            enhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            enhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(190)))), ((int)(((byte)(190)))));
            this.sprVisitPlace.VerticalScrollBar.Renderer = enhancedScrollBarRenderer2;
            this.sprVisitPlace.VerticalScrollBar.TabIndex = 5;
            this.sprVisitPlace.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            // 
            // sprVisitPlace_Sheet1
            // 
            this.sprVisitPlace_Sheet1.Reset();
            this.sprVisitPlace_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.sprVisitPlace_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.sprVisitPlace_Sheet1.ColumnCount = 3;
            this.sprVisitPlace_Sheet1.RowCount = 0;
            this.sprVisitPlace_Sheet1.ActiveColumnIndex = -1;
            this.sprVisitPlace_Sheet1.ActiveRowIndex = -1;
            this.sprVisitPlace_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "가야할곳";
            this.sprVisitPlace_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "!수납여부";
            this.sprVisitPlace_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "!가야할곳코드";
            this.sprVisitPlace_Sheet1.Columns.Get(0).CellType = textCellType1;
            this.sprVisitPlace_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.sprVisitPlace_Sheet1.Columns.Get(0).Label = "가야할곳";
            this.sprVisitPlace_Sheet1.Columns.Get(0).Locked = true;
            this.sprVisitPlace_Sheet1.Columns.Get(0).Tag = "VIST_PLCE_NM";
            this.sprVisitPlace_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprVisitPlace_Sheet1.Columns.Get(0).Width = 240F;
            this.sprVisitPlace_Sheet1.Columns.Get(1).Label = "!수납여부";
            this.sprVisitPlace_Sheet1.Columns.Get(1).Tag = "RCPT_YN";
            this.sprVisitPlace_Sheet1.Columns.Get(2).Label = "!가야할곳코드";
            this.sprVisitPlace_Sheet1.Columns.Get(2).Tag = "VIST_PLCE_CD";
            this.sprVisitPlace_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.sprVisitPlace_Sheet1.RowHeader.Visible = false;
            this.sprVisitPlace_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // lxTitlePanel1
            // 
            this.lxTitlePanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.lxTitlePanel1.BottomBarVisible = false;
            this.lxTitlePanel1.BottomText = "";
            this.lxTitlePanel1.Controls.Add(this.sprVisitPlace);
            this.lxTitlePanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lxTitlePanel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxTitlePanel1.Location = new System.Drawing.Point(0, 0);
            this.lxTitlePanel1.Name = "lxTitlePanel1";
            this.lxTitlePanel1.Padding = new System.Windows.Forms.Padding(3);
            this.lxTitlePanel1.Size = new System.Drawing.Size(400, 308);
            this.lxTitlePanel1.TabIndex = 1;
            this.lxTitlePanel1.TitleText = "가야할곳";
            // 
            // ucOlocInf
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.lxTitlePanel1);
            this.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.Name = "ucOlocInf";
            this.Size = new System.Drawing.Size(400, 308);
            ((System.ComponentModel.ISupportInitialize)(this.sprVisitPlace)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprVisitPlace_Sheet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitlePanel1)).EndInit();
            this.lxTitlePanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Framework.Controls.LxSpread sprVisitPlace;
        private FarPoint.Win.Spread.SheetView sprVisitPlace_Sheet1;
        private Framework.Controls.LxTitlePanel lxTitlePanel1;
    }
}
