// Class 명 : clsPatientRemark
// 역    할 : 환자특이사항관리 class
// 작 성 자 : PGH
// 작 성 일 : 2017-09-08
//                                                                                
// 수정내역 : 
//                                                                                
using System;
using System.Data;
using Lime.Framework;
using SQL = Lime.SqlPack;


namespace Lime.BusinessControls
{
    public class clsPatientRemark
    {
        #region Define Variable Member
        private string m_PID = string.Empty;    //환자등록번호                     VARCHAR2(10)
        private int m_PCLR_MATR_SQNO = 0;               //특이사항일련번호                 NUMBER(10, 0)
        private string m_OTPT_ADMS_DVCD = string.Empty;    //외래입원구분코드                 VARCHAR2(2)
        private string m_PTAF_MDCR_DVCD = string.Empty;    //원무진료구분코드                 VARCHAR2(2)
        private int m_PT_CMHS_NO = 0;               //환자내원번호                     NUMBER(10, 0)
        private string m_WRTN_DD = string.Empty;    //작성일자                         VARCHAR2(8)
        private string m_PT_PCLR_MATR = string.Empty;    //환자특이사항                     VARCHAR2(1000)
        private string m_DEL_YN = string.Empty;    //삭제여부                         VARCHAR2(1)
        private string m_RGST_DT = string.Empty;    //등록일시                         VARCHAR2(14)
        private string m_RGSTR_ID = string.Empty;    //등록자ID                         VARCHAR2(10)
        private string m_UPDT_DT = string.Empty;    //수정일시                         VARCHAR2(14)
        private string m_UPDTR_ID = string.Empty;    //수정자ID                         VARCHAR2(10)
        #endregion

        #region Define Member Property
        public string PID { get { return m_PID; } set { m_PID = value; } }
        public int PCLR_MATR_SQNO { get { return m_PCLR_MATR_SQNO; } set { m_PCLR_MATR_SQNO = value; } }
        public string OTPT_ADMS_DVCD { get { return m_OTPT_ADMS_DVCD; } set { m_OTPT_ADMS_DVCD = value; } }
        public string PTAF_MDCR_DVCD { get { return m_PTAF_MDCR_DVCD; } set { m_PTAF_MDCR_DVCD = value; } }
        public int PT_CMHS_NO { get { return m_PT_CMHS_NO; } set { m_PT_CMHS_NO = value; } }
        public string WRTN_DD { get { return m_WRTN_DD; } set { m_WRTN_DD = value; } }
        public string PT_PCLR_MATR { get { return m_PT_PCLR_MATR; } set { m_PT_PCLR_MATR = value; } }
        public string DEL_YN { get { return m_DEL_YN; } set { m_DEL_YN = value; } }
        public string RGST_DT { get { return m_RGST_DT; } set { m_RGST_DT = value; } }
        public string RGSTR_ID { get { return m_RGSTR_ID; } set { m_RGSTR_ID = value; } }
        public string UPDT_DT { get { return m_UPDT_DT; } set { m_UPDT_DT = value; } }
        public string UPDTR_ID { get { return m_UPDTR_ID; } set { m_UPDTR_ID = value; } }
        #endregion

        #region Construction
        public clsPatientRemark()
        {
            Clear();
        }
        #endregion Construction

        #region Method : Public Method

        public void Clear()
        {
            m_PID = string.Empty;
            m_PCLR_MATR_SQNO = 0;
            m_OTPT_ADMS_DVCD = string.Empty;
            m_PTAF_MDCR_DVCD = string.Empty;
            m_PT_CMHS_NO = 0;
            m_WRTN_DD = string.Empty;
            m_PT_PCLR_MATR = string.Empty;
            m_DEL_YN = string.Empty;
            m_RGST_DT = string.Empty;
            m_RGSTR_ID = string.Empty;
            m_UPDT_DT = string.Empty;
            m_UPDTR_ID = string.Empty;
        }

        public bool Load()
        {
            return GetPatientRemark(this.PID, this.PT_CMHS_NO, this.OTPT_ADMS_DVCD, this.PTAF_MDCR_DVCD);
        }

        /// <summary>
        /// 환자특이사항저장
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool SavePatientRemark(ref string msg)
        {
            bool success = true;

            //DBService.BeginTransaction();

            if (!UpdatePatientRemark())
            {
                msg = DBService.ErrorMessage + "\r\n 삭제중 오류를 발생하였습니다.";
                DBService.RollbackTransaction();
                success = false;
            }

            if (this.PT_PCLR_MATR.Trim().Length > 0)
            {
                if (!DBService.ExecuteNonQuery(SQL.PA.BaseSql.Insert.PAPREMMA(), this.PID
                                                                               , this.PCLR_MATR_SQNO.ToString()
                                                                               , this.OTPT_ADMS_DVCD
                                                                               , this.PTAF_MDCR_DVCD
                                                                               , this.PT_CMHS_NO.ToString()
                                                                               , this.WRTN_DD
                                                                               , this.PT_PCLR_MATR
                                                                               , this.DEL_YN
                                                                               , this.RGST_DT
                                                                               , this.RGSTR_ID
                                                                               , this.UPDT_DT
                                                                               , this.UPDTR_ID))
                {
                    success = false;
                    msg = DBService.ErrorMessage + " \r\n 환자특이사항 저장중 오류가 발생했습니다.! 전산실에 문의하세요..!!!";
                    DBService.RollbackTransaction();
                }
            }
            return success;
        }
        /// <summary>
        /// 환자특이사항 삭제 : DEL_YN UPDATE  (원무)
        /// 접수 특이사항은 환자별 특이사항을 작성할 것인지 아니면 내원번호별 특이사항을 관리할 것인지 결정? 옵션처리
        /// </summary>
        /// <returns></returns>
        public int SelectMaxSqno()
        {
            int MaxSqno = DBService.ExecuteInteger(SQL.PA.Sql.SelectPAPREMMA_MaxSqno(), this.PID);

            if (MaxSqno <= 0)
            {
                MaxSqno = 0;
            }

            return ++MaxSqno;
        }


        /// <summary>
        /// 환자특이사항 내용을 리턴한다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="otptadmsdvcd"></param>
        /// <param name="ptafmdcrdvcd"></param>
        /// <returns></returns>
        public string ReturnPtPclrMatr(string pid, int ptcmhsno, string otptadmsdvcd, string ptafmdcrdvcd)
        {
            return DBService.ExecuteScalar(SQL.PA.Sql.SelectPAPREMMA_PtPclrMatr(), pid
                                                                                 , ptcmhsno.ToString()
                                                                                 , otptadmsdvcd
                                                                                 , ptafmdcrdvcd).ToString();

        }

        #endregion Method : Public Method

        #region Method : Private Method

        private bool UpdatePatientRemarkPa()
        {
            bool success = true;
            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePAPREMMA(), this.PID
                                                                     , "0"
                                                                     , "O"
                                                                     , "P"))
            {
                success = false;
            }
            return success;
        }

        private bool UpdatePatientRemark()
        {
            bool success = true;
            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePAPREMMA(), this.PID
                                                                      , this.PT_CMHS_NO.ToString()
                                                                      , this.OTPT_ADMS_DVCD
                                                                      , this.PTAF_MDCR_DVCD))
            {
                success = false;
            }
            return success;
        }
        private bool GetPatientRemark(string pid, int ptcmhsno, string otptadmsdvcd, string ptafmdcrdvcd)
        {
            try
            {
                DataTable dtRemark = new DataTable();

                try
                {
                    DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAPREMMA(), ref dtRemark, pid
                                                                                        , ptcmhsno.ToString()
                                                                                        , otptadmsdvcd
                                                                                        , ptafmdcrdvcd);
                }
                catch (Exception ex)
                {
                    LogService.ErrorLog(ex);
                }

                if (dtRemark.Rows.Count > 0)
                {
                    DataRow row = dtRemark.Rows[0];

                    m_PID = row["PID"].ToString();
                    m_PCLR_MATR_SQNO = int.Parse(row["PCLR_MATR_SQNO"].ToString());
                    m_OTPT_ADMS_DVCD = row["OTPT_ADMS_DVCD"].ToString();
                    m_PTAF_MDCR_DVCD = row["PTAF_MDCR_DVCD"].ToString();
                    m_PT_CMHS_NO = int.Parse(row["PT_CMHS_NO"].ToString());
                    m_WRTN_DD = row["WRTN_DD"].ToString();
                    m_PT_PCLR_MATR = row["PT_PCLR_MATR"].ToString();
                    m_DEL_YN = row["DEL_YN"].ToString();
                    m_RGST_DT = row["RGST_DT"].ToString();
                    m_RGSTR_ID = row["RGSTR_ID"].ToString();
                    m_UPDT_DT = row["UPDT_DT"].ToString();
                    m_UPDTR_ID = row["UPDTR_ID"].ToString();

                    return true;
                }
                else
                {
                    LogService.DebugLog(string.Format("Patient Remark not found.({0})", pid));
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return false;
        }
        #endregion

    }
}
