// *******************************************************
// Class 명 : clsOutReceiptBreakDown
// 역    할 : 외래수납처방내역 (PAORECBD)
// 작 성 자 : PGH
// 작 성 일 : 2017-09-14
// *******************************************************

import { DataTable } from "@/app/framework/DataType/DataTable";
import { DBService } from "@/app/framework/DBService/DBService";
import { LogService } from "@/app/framework/CommonService/LogService";
import { Int } from "@/app/utils/Int";
import { clsOutReceiptBreakDown } from "@/modules/n_pa/views/CommonClass/clsOutReceiptBreakDown";


    export class clsOutReceiptBreakDown
    {
        // #region Define Member Property

        m_PID:string = String.Empty;    //환자등록번호                     VARCHAR2(10)
        m_PT_CMHS_NO:number = 0;               //환자내원번호                     NUMBER(10, 0)
        m_RCPT_SQNO:number = 0;               //수납일련번호                     NUMBER(5, 0)
        m_APLY_SQNO:number = 0;               //적용일련번호                     NUMBER(3, 0)
        m_PRSC_SQNO:number = 0;               //처방일련번호                     NUMBER(5, 0)
        m_MDCR_DD:string = String.Empty;    //진료일자                         VARCHAR2(8)
        m_ACTG_DD:string = String.Empty;    //시행일자                         VARCHAR2(8)
        m_CLAM_CRTN_YN:string = String.Empty;    //청구생성여부                     VARCHAR2(1)
        m_REAL_PRDC_CD:string = String.Empty;    //실제처방의코드                   VARCHAR2(10)
        m_PRSC_DVCD:string = String.Empty;    //처방구분코드                     VARCHAR2(2)
        m_BNDL_PRSC_SQNO:number = 0;               //묶음처방일련번호                 NUMBER(3, 0)
        m_BNDL_MEFE_CD:string = String.Empty;    //묶음수가코드                     VARCHAR2(10)
        m_MEFE_CD:string = String.Empty;    //수가코드                         VARCHAR2(10)
        m_MEFE_NM:string = String.Empty;    //수가명                           VARCHAR2(200)
        m_EDI_CD:string = String.Empty;    //EDI코드                          VARCHAR2(10)
        m_PRFT_CD:string = String.Empty;    //수익코드                         VARCHAR2(10)
        m_ONTM_QTY:number = 0;               //1회수량                          NUMBER(10, 4)
        m_NOTM:number = 0;               //횟수                             NUMBER(3, 0)
        m_NODY:number = 0;               //일수                             NUMBER(3, 0)
        m_AOMD_MTHD_CD:string = String.Empty;    //투여방법코드                     VARCHAR2(10)
        m_OUPR_GRNT_NO:string = String.Empty;    //원외처방교부번호                 VARCHAR2(13)
        m_EXCP_RESN_CD:string = String.Empty;    //예외사유코드                     VARCHAR2(2)
        m_DLVR_DEPT_CD:string = String.Empty;    //전달부서코드                     VARCHAR2(10)
        m_ACTG_DEPT_CD:string = String.Empty;    //시행부서코드                     VARCHAR2(10)
        m_CLCL_DVCD:string = String.Empty;    //계산구분코드                     VARCHAR2(2)
        m_ACTN_MATL_DVCD:string = String.Empty;    //행위재료구분코드                 VARCHAR2(2)
        m_CLUS_DVCD:string = String.Empty;    //항구분코드                       VARCHAR2(2)
        m_SBIT_DVCD:string = String.Empty;    //목구분코드                       VARCHAR2(2)
        m_MEFE_DVCD:string = String.Empty;    //수가구분코드                     VARCHAR2(2)
        m_PAY_NOPY_DVCD:string = String.Empty;    //급여비급여구분코드               VARCHAR2(2)
        m_SCNG_PAY_CD:string = String.Empty;    //선별급여코드                     VARCHAR2(10)
        m_CNFR_DVCD:string = String.Empty;    //확인구분코드                     VARCHAR2(2)
        m_CNFR_CD:string = String.Empty;    //확인코드                         VARCHAR2(30)
        m_CMPT_CD:string = String.Empty;    //산정코드                         VARCHAR2(4)
        m_TIME_ADTN_DVCD:string = String.Empty;    //시간가산구분코드                 VARCHAR2(10)
        m_VTRN_PT_YN:string = String.Empty;    //보훈환자여부                     VARCHAR2(1)
        m_UNPR:number = 0;               //단가                             NUMBER(10, 0)
        m_ADTN_CMPT_AMT:number = 0;               //가산산정금액                     NUMBER(10, 0)
        m_BYKN_ADTN_AMT:number = 0;               //종별가산금액                     NUMBER(10, 0)
        m_SMCR_AMT:number = 0;               //선택진료금액                     NUMBER(10, 0)
        m_CLCL_AMT:number = 0;               //계산금액                         NUMBER(10, 0)
        m_ORIG_CLCL_AMT:number = 0;               //원계산금액                       NUMBER(10, 0)
        m_ADED_VALU_TAX_AMT:number = 0;               //부가가치세금액                   NUMBER(10, 0)
        m_PAY_USCH_AMT:number = 0;               //급여본인부담금액                 NUMBER(10, 0)
        m_PAY_CLAM_AMT:number = 0;               //급여청구금액                     NUMBER(10, 0)
        m_SCNG_PAY_USCH_AMT:number = 0;               //선별급여본인부담금액             NUMBER(10, 0)
        m_SCNG_PAY_CLAM_AMT:number = 0;               //선별급여청구금액                 NUMBER(10, 0)
        m_VTRN_TAMT:number = 0;               //보훈총금액                       NUMBER(10, 0)
        m_DCNT_AMT:number = 0;               //할인금액                         NUMBER(10, 0)
        m_ADTN_APLY_TIME:string = String.Empty;    //가산적용시간                     VARCHAR2(4)
        m_CMPT_DLWT_DVCD_1:string = String.Empty;    //산정처리구분코드첫째             VARCHAR2(10)
        m_CMPT_DLWT_DVCD_2:string = String.Empty;    //산정처리구분코드둘째             VARCHAR2(10)
        m_CMPT_DLWT_DVCD_3:string = String.Empty;    //산정처리구분코드셋째             VARCHAR2(10)
        m_CMPT_DLWT_DVCD_4:string = String.Empty;    //산정처리구분코드넷째             VARCHAR2(10)
        m_CNVR_PNT:number = 0;               //환산점수                         NUMBER(10, 2)
        m_GRP_UNPR_APLY_YN:string = String.Empty;    //그룹단가적용여부                 VARCHAR2(1)
        m_DNFR_RGUP_CNTS:string = String.Empty;    //치식우위내용                     VARCHAR2(8)
        m_DNFR_LFUP_CNTS:string = String.Empty;    //치식좌위내용                     VARCHAR2(8)
        m_DNFR_RGHT_LOW_CNTS:string = String.Empty;    //치식우하내용                     VARCHAR2(8)
        m_DNFR_LEFT_LOW_CNTS:string = String.Empty;    //치식좌하내용                     VARCHAR2(8)
        m_HPMD_CLCL_DVCD:string = String.Empty;    //고가약제계산구분코드             VARCHAR2(10)
        m_HPMD_CLCL_QTY:number = 0;               //고가약제계산수량                 NUMBER(10, 4)
        m_ENTS_ENTD_DVCD:string = String.Empty;    //위탁수탁구분코드                 VARCHAR2(2)
        m_ENTS_ENTD_INSTNO:string = String.Empty;    //위탁수탁기관기호                 VARCHAR2(10)
        m_SLCT_MCFE:number = 0;               //선택진료료                       NUMBER(10, 0)
        m_SMCR_RATE:number = 0;               //선택진료율                       NUMBER(7, 2)
        m_FXAM_INCL_YN:string = String.Empty;    //정액포함여부                     VARCHAR2(1)
        m_TOTL_AOMD_QTY:number = 0;               //총투여수량                       NUMBER(10, 4)
        m_ORMD_ANS_DVCD:string = String.Empty;    //한방가감구분코드                 VARCHAR2(2)
        m_ORMD_ANS_ORIG_DVCD:string = String.Empty;    //한방가감원구분코드               VARCHAR2(10)
        m_ORMD_ANS_ORIG_CD:string = String.Empty;    //한방가감원코드                   VARCHAR2(10)
        m_ORMD_SITE_DVCD:string = String.Empty;    //한방부위구분코드                 VARCHAR2(2)
        m_ORMD_SITE_CD:string = String.Empty;    //한방부위코드                     VARCHAR2(10)
        m_MDCN_UPLM_AMT:number = 0;               //약제상한금액                     NUMBER(10, 0)
        m_MDCN_UPLM_DIAM:number = 0;               //약제상한차액                     NUMBER(10, 0)
        m_ORIG_PRSC_SQNO:number = 0;               //원처방일련번호                   NUMBER(5, 0)
        m_ORIG_SQNO:number = 0;               //원일련번호                       NUMBER(3, 0)
        m_PCLR_MATR:string = String.Empty;    //특이사항                         VARCHAR2(200)
        m_AFRS_STAT_DVCD:string = String.Empty;    //업무상태구분코드                 VARCHAR2(2)
        m_ROW_STAT_DVCD:string = String.Empty;    //행상태구분코드                   VARCHAR2(2)
        m_RGST_DT:string = String.Empty;    //등록일시                         VARCHAR2(14)
        m_RGSTR_ID:string = String.Empty;    //등록자ID                         VARCHAR2(10)
        m_NEW_RCPT_RQNO:number = 0;               //새로운 수납일련번호
        m_NEW_ROW_STAT_DVCD:string = String.Empty;

        m_STATVAL1:number = 1;             //행상태구분에 따른 값 ROW_STAT_DVCD = 'D' -> -1, ROW_STAT_DVCD = 'A' -> 1, ROW_STAT_DVCD = 'F' -> 0
        m_STATVAL2:number = 1;             // 0, -1, 1
        m_CLUR_DSBL_DVCD:string = String.Empty;   // 장루요루구분코드 1 : YES, 0 : NO

        let m_DtPrsc:DataTable = new DataTable();

        get PID() { return m_PID; }
        set PID(value: any) { m_PID = value; }
        get PT_CMHS_NO() { return m_PT_CMHS_NO; }
        set PT_CMHS_NO(value: any) { m_PT_CMHS_NO = value; }
        get RCPT_SQNO() { return m_RCPT_SQNO; }
        set RCPT_SQNO(value: any) { m_RCPT_SQNO = value; }
        get APLY_SQNO() { return m_APLY_SQNO; }
        set APLY_SQNO(value: any) { m_APLY_SQNO = value; }
        get PRSC_SQNO() { return m_PRSC_SQNO; }
        set PRSC_SQNO(value: any) { m_PRSC_SQNO = value; }
        get MDCR_DD() { return m_MDCR_DD; }
        set MDCR_DD(value: any) { m_MDCR_DD = value; }
        get ACTG_DD() { return m_ACTG_DD; }
        set ACTG_DD(value: any) { m_ACTG_DD = value; }
        get CLAM_CRTN_YN() { return m_CLAM_CRTN_YN; }
        set CLAM_CRTN_YN(value: any) { m_CLAM_CRTN_YN = value; }
        get REAL_PRDC_CD() { return m_REAL_PRDC_CD; }
        set REAL_PRDC_CD(value: any) { m_REAL_PRDC_CD = value; }
        get PRSC_DVCD() { return m_PRSC_DVCD; }
        set PRSC_DVCD(value: any) { m_PRSC_DVCD = value; }
        get BNDL_PRSC_SQNO() { return m_BNDL_PRSC_SQNO; }
        set BNDL_PRSC_SQNO(value: any) { m_BNDL_PRSC_SQNO = value; }
        get BNDL_MEFE_CD() { return m_BNDL_MEFE_CD; }
        set BNDL_MEFE_CD(value: any) { m_BNDL_MEFE_CD = value; }
        get MEFE_CD() { return m_MEFE_CD; }
        set MEFE_CD(value: any) { m_MEFE_CD = value; }
        get MEFE_NM() { return m_MEFE_NM; }
        set MEFE_NM(value: any) { m_MEFE_NM = value; }
        get EDI_CD() { return m_EDI_CD; }
        set EDI_CD(value: any) { m_EDI_CD = value; }
        get PRFT_CD() { return m_PRFT_CD; }
        set PRFT_CD(value: any) { m_PRFT_CD = value; }
        get ONTM_QTY() { return m_ONTM_QTY; }
        set ONTM_QTY(value: any) { m_ONTM_QTY = value; }
        get NOTM() { return m_NOTM; }
        set NOTM(value: any) { m_NOTM = value; }
        get NODY() { return m_NODY; }
        set NODY(value: any) { m_NODY = value; }
        get AOMD_MTHD_CD() { return m_AOMD_MTHD_CD; }
        set AOMD_MTHD_CD(value: any) { m_AOMD_MTHD_CD = value; }
        get OUPR_GRNT_NO() { return m_OUPR_GRNT_NO; }
        set OUPR_GRNT_NO(value: any) { m_OUPR_GRNT_NO = value; }
        get EXCP_RESN_CD() { return m_EXCP_RESN_CD; }
        set EXCP_RESN_CD(value: any) { m_EXCP_RESN_CD = value; }
        get DLVR_DEPT_CD() { return m_DLVR_DEPT_CD; }
        set DLVR_DEPT_CD(value: any) { m_DLVR_DEPT_CD = value; }
        get ACTG_DEPT_CD() { return m_ACTG_DEPT_CD; }
        set ACTG_DEPT_CD(value: any) { m_ACTG_DEPT_CD = value; }
        get CLCL_DVCD() { return m_CLCL_DVCD; }
        set CLCL_DVCD(value: any) { m_CLCL_DVCD = value; }
        get ACTN_MATL_DVCD() { return m_ACTN_MATL_DVCD; }
        set ACTN_MATL_DVCD(value: any) { m_ACTN_MATL_DVCD = value; }
        get CLUS_DVCD() { return m_CLUS_DVCD; }
        set CLUS_DVCD(value: any) { m_CLUS_DVCD = value; }
        get SBIT_DVCD() { return m_SBIT_DVCD; }
        set SBIT_DVCD(value: any) { m_SBIT_DVCD = value; }
        get MEFE_DVCD() { return m_MEFE_DVCD; }
        set MEFE_DVCD(value: any) { m_MEFE_DVCD = value; }
        get PAY_NOPY_DVCD() { return m_PAY_NOPY_DVCD; }
        set PAY_NOPY_DVCD(value: any) { m_PAY_NOPY_DVCD = value; }
        get SCNG_PAY_CD() { return m_SCNG_PAY_CD; }
        set SCNG_PAY_CD(value: any) { m_SCNG_PAY_CD = value; }
        get CNFR_DVCD() { return m_CNFR_DVCD; }
        set CNFR_DVCD(value: any) { m_CNFR_DVCD = value; }
        get CNFR_CD() { return m_CNFR_CD; }
        set CNFR_CD(value: any) { m_CNFR_CD = value; }
        get CMPT_CD() { return m_CMPT_CD; }
        set CMPT_CD(value: any) { m_CMPT_CD = value; }
        get TIME_ADTN_DVCD() { return m_TIME_ADTN_DVCD; }
        set TIME_ADTN_DVCD(value: any) { m_TIME_ADTN_DVCD = value; }
        get VTRN_PT_YN() { return m_VTRN_PT_YN; }
        set VTRN_PT_YN(value: any) { m_VTRN_PT_YN = value; }
        get UNPR() { return m_UNPR; }
        set UNPR(value: any) { m_UNPR = value; }
        get ADTN_CMPT_AMT() { return m_ADTN_CMPT_AMT; }
        set ADTN_CMPT_AMT(value: any) { m_ADTN_CMPT_AMT = value; }
        get BYKN_ADTN_AMT() { return m_BYKN_ADTN_AMT; }
        set BYKN_ADTN_AMT(value: any) { m_BYKN_ADTN_AMT = value; }
        get SMCR_AMT() { return m_SMCR_AMT; }
        set SMCR_AMT(value: any) { m_SMCR_AMT = value; }
        get CLCL_AMT() { return m_CLCL_AMT; }
        set CLCL_AMT(value: any) { m_CLCL_AMT = value; }
        get ORIG_CLCL_AMT() { return m_ORIG_CLCL_AMT; }
        set ORIG_CLCL_AMT(value: any) { m_ORIG_CLCL_AMT = value; }
        get ADED_VALU_TAX_AMT() { return m_ADED_VALU_TAX_AMT; }
        set ADED_VALU_TAX_AMT(value: any) { m_ADED_VALU_TAX_AMT = value; }
        get PAY_USCH_AMT() { return m_PAY_USCH_AMT; }
        set PAY_USCH_AMT(value: any) { m_PAY_USCH_AMT = value; }
        get PAY_CLAM_AMT() { return m_PAY_CLAM_AMT; }
        set PAY_CLAM_AMT(value: any) { m_PAY_CLAM_AMT = value; }
        get SCNG_PAY_USCH_AMT() { return m_SCNG_PAY_USCH_AMT; }
        set SCNG_PAY_USCH_AMT(value: any) { m_SCNG_PAY_USCH_AMT = value; }
        get SCNG_PAY_CLAM_AMT() { return m_SCNG_PAY_CLAM_AMT; }
        set SCNG_PAY_CLAM_AMT(value: any) { m_SCNG_PAY_CLAM_AMT = value; }
        get VTRN_TAMT() { return m_VTRN_TAMT; }
        set VTRN_TAMT(value: any) { m_VTRN_TAMT = value; }
        get DCNT_AMT() { return m_DCNT_AMT; }
        set DCNT_AMT(value: any) { m_DCNT_AMT = value; }
        get ADTN_APLY_TIME() { return m_ADTN_APLY_TIME; }
        set ADTN_APLY_TIME(value: any) { m_ADTN_APLY_TIME = value; }
        get CMPT_DLWT_DVCD_1() { return m_CMPT_DLWT_DVCD_1; }
        set CMPT_DLWT_DVCD_1(value: any) { m_CMPT_DLWT_DVCD_1 = value; }
        get CMPT_DLWT_DVCD_2() { return m_CMPT_DLWT_DVCD_2; }
        set CMPT_DLWT_DVCD_2(value: any) { m_CMPT_DLWT_DVCD_2 = value; }
        get CMPT_DLWT_DVCD_3() { return m_CMPT_DLWT_DVCD_3; }
        set CMPT_DLWT_DVCD_3(value: any) { m_CMPT_DLWT_DVCD_3 = value; }
        get CMPT_DLWT_DVCD_4() { return m_CMPT_DLWT_DVCD_4; }
        set CMPT_DLWT_DVCD_4(value: any) { m_CMPT_DLWT_DVCD_4 = value; }
        get CNVR_PNT() { return m_CNVR_PNT; }
        set CNVR_PNT(value: any) { m_CNVR_PNT = value; }
        get GRP_UNPR_APLY_YN() { return m_GRP_UNPR_APLY_YN; }
        set GRP_UNPR_APLY_YN(value: any) { m_GRP_UNPR_APLY_YN = value; }
        get DNFR_RGUP_CNTS() { return m_DNFR_RGUP_CNTS; }
        set DNFR_RGUP_CNTS(value: any) { m_DNFR_RGUP_CNTS = value; }
        get DNFR_LFUP_CNTS() { return m_DNFR_LFUP_CNTS; }
        set DNFR_LFUP_CNTS(value: any) { m_DNFR_LFUP_CNTS = value; }
        get DNFR_RGHT_LOW_CNTS() { return m_DNFR_RGHT_LOW_CNTS; }
        set DNFR_RGHT_LOW_CNTS(value: any) { m_DNFR_RGHT_LOW_CNTS = value; }
        get DNFR_LEFT_LOW_CNTS() { return m_DNFR_LEFT_LOW_CNTS; }
        set DNFR_LEFT_LOW_CNTS(value: any) { m_DNFR_LEFT_LOW_CNTS = value; }
        get HPMD_CLCL_DVCD() { return m_HPMD_CLCL_DVCD; }
        set HPMD_CLCL_DVCD(value: any) { m_HPMD_CLCL_DVCD = value; }
        get HPMD_CLCL_QTY() { return m_HPMD_CLCL_QTY; }
        set HPMD_CLCL_QTY(value: any) { m_HPMD_CLCL_QTY = value; }
        get ENTS_ENTD_DVCD() { return m_ENTS_ENTD_DVCD; }
        set ENTS_ENTD_DVCD(value: any) { m_ENTS_ENTD_DVCD = value; }
        get ENTS_ENTD_INSTNO() { return m_ENTS_ENTD_INSTNO; }
        set ENTS_ENTD_INSTNO(value: any) { m_ENTS_ENTD_INSTNO = value; }
        get SLCT_MCFE() { return m_SLCT_MCFE; }
        set SLCT_MCFE(value: any) { m_SLCT_MCFE = value; }
        get SMCR_RATE() { return m_SMCR_RATE; }
        set SMCR_RATE(value: any) { m_SMCR_RATE = value; }
        get FXAM_INCL_YN() { return m_FXAM_INCL_YN; }
        set FXAM_INCL_YN(value: any) { m_FXAM_INCL_YN = value; }
        get TOTL_AOMD_QTY() { return m_TOTL_AOMD_QTY; }
        set TOTL_AOMD_QTY(value: any) { m_TOTL_AOMD_QTY = value; }
        get ORMD_ANS_DVCD() { return m_ORMD_ANS_DVCD; }
        set ORMD_ANS_DVCD(value: any) { m_ORMD_ANS_DVCD = value; }
        get ORMD_ANS_ORIG_DVCD() { return m_ORMD_ANS_ORIG_DVCD; }
        set ORMD_ANS_ORIG_DVCD(value: any) { m_ORMD_ANS_ORIG_DVCD = value; }
        get ORMD_ANS_ORIG_CD() { return m_ORMD_ANS_ORIG_CD; }
        set ORMD_ANS_ORIG_CD(value: any) { m_ORMD_ANS_ORIG_CD = value; }
        get ORMD_SITE_DVCD() { return m_ORMD_SITE_DVCD; }
        set ORMD_SITE_DVCD(value: any) { m_ORMD_SITE_DVCD = value; }
        get ORMD_SITE_CD() { return m_ORMD_SITE_CD; }
        set ORMD_SITE_CD(value: any) { m_ORMD_SITE_CD = value; }
        get MDCN_UPLM_AMT() { return m_MDCN_UPLM_AMT; }
        set MDCN_UPLM_AMT(value: any) { m_MDCN_UPLM_AMT = value; }
        get MDCN_UPLM_DIAM() { return m_MDCN_UPLM_DIAM; }
        set MDCN_UPLM_DIAM(value: any) { m_MDCN_UPLM_DIAM = value; }
        get ORIG_PRSC_SQNO() { return m_ORIG_PRSC_SQNO; }
        set ORIG_PRSC_SQNO(value: any) { m_ORIG_PRSC_SQNO = value; }
        get ORIG_SQNO() { return m_ORIG_SQNO; }
        set ORIG_SQNO(value: any) { m_ORIG_SQNO = value; }
        get PCLR_MATR() { return m_PCLR_MATR; }
        set PCLR_MATR(value: any) { m_PCLR_MATR = value; }
        get AFRS_STAT_DVCD() { return m_AFRS_STAT_DVCD; }
        set AFRS_STAT_DVCD(value: any) { m_AFRS_STAT_DVCD = value; }
        get ROW_STAT_DVCD() { return m_ROW_STAT_DVCD; }
        set ROW_STAT_DVCD(value: any) { m_ROW_STAT_DVCD = value; }
        get RGST_DT() { return m_RGST_DT; }
        set RGST_DT(value: any) { m_RGST_DT = value; }
        get RGSTR_ID() { return m_RGSTR_ID; }
        set RGSTR_ID(value: any) { m_RGSTR_ID = value; }

        get NEW_RCPT_RQNO() { return m_NEW_RCPT_RQNO++; }
        set NEW_RCPT_RQNO(value: any) { m_NEW_RCPT_RQNO = value; }
        get NEW_ROW_STAT_DVCD() { return m_NEW_ROW_STAT_DVCD; }
        set NEW_ROW_STAT_DVCD(value: any) { m_NEW_ROW_STAT_DVCD = value; }

        get STATVAL1() { return m_STATVAL1; }
        set STATVAL1(value: any) { m_STATVAL1 = value; }
        get STATVAL2() { return m_STATVAL2; }
        set STATVAL2(value: any) { m_STATVAL2 = value; }
        get CLUR_DSBL_DVCD() { return m_CLUR_DSBL_DVCD; }
        set CLUR_DSBL_DVCD(value: any) { m_CLUR_DSBL_DVCD = value; }

        get DtPrsc() { return m_DtPrsc; }
        set DtPrsc(value: any) { m_DtPrsc = value; }
        // #endregion

        // #region Constructor

        constructor()
        {
            Clear();
        }

        // #endregion

        // #region Method General

        public Clear()
        {
            m_PID = String.Empty;
            m_PT_CMHS_NO = 0;
            m_RCPT_SQNO = 0;
            m_APLY_SQNO = 0;
            m_PRSC_SQNO = 0;
            m_MDCR_DD = String.Empty;
            m_ACTG_DD = String.Empty;
            m_CLAM_CRTN_YN = String.Empty;
            m_REAL_PRDC_CD = String.Empty;
            m_PRSC_DVCD = String.Empty;
            m_BNDL_PRSC_SQNO = 0;
            m_BNDL_MEFE_CD = String.Empty;
            m_MEFE_CD = String.Empty;
            m_MEFE_NM = String.Empty;
            m_EDI_CD = String.Empty;
            m_PRFT_CD = String.Empty;
            m_ONTM_QTY = 0;
            m_NOTM = 0;
            m_NODY = 0;
            m_AOMD_MTHD_CD = String.Empty;
            m_OUPR_GRNT_NO = String.Empty;
            m_EXCP_RESN_CD = String.Empty;
            m_DLVR_DEPT_CD = String.Empty;
            m_ACTG_DEPT_CD = String.Empty;
            m_CLCL_DVCD = String.Empty;
            m_ACTN_MATL_DVCD = String.Empty;
            m_CLUS_DVCD = String.Empty;
            m_SBIT_DVCD = String.Empty;
            m_MEFE_DVCD = String.Empty;
            m_PAY_NOPY_DVCD = String.Empty;
            m_SCNG_PAY_CD = String.Empty;
            m_CNFR_DVCD = String.Empty;
            m_CNFR_CD = String.Empty;
            m_CMPT_CD = String.Empty;
            m_TIME_ADTN_DVCD = String.Empty;
            m_VTRN_PT_YN = String.Empty;
            m_UNPR = 0;
            m_ADTN_CMPT_AMT = 0;
            m_BYKN_ADTN_AMT = 0;
            m_SMCR_AMT = 0;
            m_CLCL_AMT = 0;
            m_ORIG_CLCL_AMT = 0;
            m_ADED_VALU_TAX_AMT = 0;
            m_PAY_USCH_AMT = 0;
            m_PAY_CLAM_AMT = 0;
            m_SCNG_PAY_USCH_AMT = 0;
            m_SCNG_PAY_CLAM_AMT = 0;
            m_VTRN_TAMT = 0;
            m_DCNT_AMT = 0;
            m_ADTN_APLY_TIME = String.Empty;
            m_CMPT_DLWT_DVCD_1 = String.Empty;
            m_CMPT_DLWT_DVCD_2 = String.Empty;
            m_CMPT_DLWT_DVCD_3 = String.Empty;
            m_CMPT_DLWT_DVCD_4 = String.Empty;
            m_CNVR_PNT = 0;
            m_GRP_UNPR_APLY_YN = String.Empty;
            m_DNFR_RGUP_CNTS = String.Empty;
            m_DNFR_LFUP_CNTS = String.Empty;
            m_DNFR_RGHT_LOW_CNTS = String.Empty;
            m_DNFR_LEFT_LOW_CNTS = String.Empty;
            m_HPMD_CLCL_DVCD = String.Empty;
            m_HPMD_CLCL_QTY = 0;
            m_ENTS_ENTD_DVCD = String.Empty;
            m_ENTS_ENTD_INSTNO = String.Empty;
            m_SLCT_MCFE = 0;
            m_SMCR_RATE = 0;
            m_FXAM_INCL_YN = String.Empty;
            m_TOTL_AOMD_QTY = 0;
            m_ORMD_ANS_DVCD = String.Empty;
            m_ORMD_ANS_ORIG_DVCD = String.Empty;
            m_ORMD_ANS_ORIG_CD = String.Empty;
            m_ORMD_SITE_DVCD = String.Empty;
            m_ORMD_SITE_CD = String.Empty;
            m_MDCN_UPLM_AMT = 0;
            m_MDCN_UPLM_DIAM = 0;
            m_ORIG_PRSC_SQNO = 0;
            m_ORIG_SQNO = 0;
            m_PCLR_MATR = String.Empty;
            m_AFRS_STAT_DVCD = String.Empty;
            m_ROW_STAT_DVCD = String.Empty;
            m_RGST_DT = String.Empty;
            m_RGSTR_ID = String.Empty;
            m_NEW_RCPT_RQNO = 0;
            m_NEW_ROW_STAT_DVCD = String.Empty;

            m_STATVAL1 = 1;
            m_STATVAL2 = 1;

            m_CLUR_DSBL_DVCD = String.Empty;

            m_DtPrsc.Clear();
        }

        // #endregion

        // #region Method : Public Method

        /// <summary>
        /// 외래수납처방내역을 DataTable에 담아서 PaOrecBd Insert.
        /// </summary>
        /// <returns></returns>
        public SavePaOrecBd(msg:string, optionString:string = "")
        {
            try
            {
                let dtPaOrecBd:DataTable = new DataTable();

                // 입원취소에서 A행을 생성할 경우
                if (m_NEW_ROW_STAT_DVCD.Equals("A") && m_AFRS_STAT_DVCD.Equals("9"))
                {
                    await DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAORECBD(true), /*ref*/ dtPaOrecBd, m_PID
                                                                                          , m_PT_CMHS_NO.ToString()
                                                                                          , m_ROW_STAT_DVCD);
                }
                else
                {
                    await DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAORECBD(false), /*ref*/ dtPaOrecBd, m_PID
                                                                                          , m_PT_CMHS_NO.ToString()
                                                                                          , m_RCPT_SQNO.ToString()
                                                                                          , m_ROW_STAT_DVCD);
                }

                if (dtPaOrecBd.Rows.Count > 0)
                {
                    return InsertPaOrecBd(dtPaOrecBd, /*ref*/ msg, optionString);
                }

                return false;
            }
            catch (ex)
            {
                msg = "외래접수내역 취소 중 오류를 발생했습니다.\r\n " +
                      "Method :  [SavePaOrecBd] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }
            return true;
        }

        /// <summary>
        /// 외래수납처방내역을 DataTable에 담아서 PaOrecBd Insert.
        /// </summary>
        /// <returns></returns>
        public SavePaOrecBd_Uncl(msg:string, optionString:string = "")
        {
            try
            {
                let dt:DataTable = new DataTable();
                if (!await DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAORECBD(true), /*ref*/ dt, m_PID, m_PT_CMHS_NO.ToString(), m_ROW_STAT_DVCD))
                    throw new Error("이전 수납처방내역을 조회하는 중 에러가 발생했습니다.");

                if (dt.Rows.Count > 0)
                {
                    return InsertPaOrecBd(dt, /*ref*/ msg, optionString);
                }

                return false;
            }
            catch (ex)
            {
                msg = "외래접수내역 취소 중 오류를 발생했습니다.\r\n " +
                      "Method :  [SavePaOrecBd] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }
            return true;
        }

        /// <summary>
        /// 외래수납처방내역 Insert
        /// </summary>
        /// <param name="dtpaorecdb"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public InsertPaOrecBd(dtpaorecdb:DataTable, /*ref*/ string msg, optionString:string = "")
        {
            try
            {
                let clurdsblcount:number = 0;
                let pid:string = String.Empty;
                let ptcmhsno:string = String.Empty;

                for (const row of dtpaorecdb.Rows)
                {
                    if (optionString.Equals("D"))
                    {
                        // #region 입원등록 D Insert

                        if (!await DBService.ExecuteNonQuery(SQL.PA.BaseSql.Insert.PAORECBD(), row["PID"].ToString()
                                                                                       , row["PT_CMHS_NO"].ToString()
                                                                                       , m_NEW_RCPT_RQNO.ToString()
                                                                                       , row["APLY_SQNO"].ToString()
                                                                                       , row["PRSC_SQNO"].ToString()
                                                                                       , row["MDCR_DD"].ToString()
                                                                                       , row["ACTG_DD"].ToString()
                                                                                       , row["CLAM_CRTN_YN"].ToString()
                                                                                       , row["REAL_PRDC_CD"].ToString()
                                                                                       , row["PRSC_DVCD"].ToString()
                                                                                       , row["BNDL_PRSC_SQNO"].ToString()
                                                                                       , row["BNDL_MEFE_CD"].ToString()
                                                                                       , row["MEFE_CD"].ToString()
                                                                                       , row["MEFE_NM"].ToString()
                                                                                       , row["EDI_CD"].ToString()
                                                                                       , row["PRFT_CD"].ToString()
                                                                                       , row["ONTM_QTY"].ToString()
                                                                                       , row["NOTM"].ToString()
                                                                                       , (Int.Parse(row["NODY"].ToString()) * -1).ToString()            // 일수는 -1곱함
                                                                                       , row["AOMD_MTHD_CD"].ToString()
                                                                                       , row["OUPR_GRNT_NO"].ToString()
                                                                                       , row["EXCP_RESN_CD"].ToString()
                                                                                       , row["DLVR_DEPT_CD"].ToString()
                                                                                       , row["ACTG_DEPT_CD"].ToString()
                                                                                       , row["CLCL_DVCD"].ToString()
                                                                                       , row["ACTN_MATL_DVCD"].ToString()
                                                                                       , row["CLUS_DVCD"].ToString()
                                                                                       , row["SBIT_DVCD"].ToString()
                                                                                       , row["MEFE_DVCD"].ToString()
                                                                                       , row["PAY_NOPY_DVCD"].ToString()
                                                                                       , row["SCNG_PAY_CD"].ToString()
                                                                                       , row["CNFR_DVCD"].ToString()
                                                                                       , row["CNFR_CD"].ToString()
                                                                                       , row["CMPT_CD"].ToString()
                                                                                       , row["TIME_ADTN_DVCD"].ToString()
                                                                                       , row["VTRN_PT_YN"].ToString()
                                                                                       , row["UNPR"].ToString()
                                                                                       , row["ADTN_CMPT_AMT"].ToString()
                                                                                       , row["BYKN_ADTN_AMT"].ToString()
                                                                                       , row["SMCR_AMT"].ToString()
                                                                                       , (Int.Parse(row["CLCL_AMT"].ToString()) * -1).ToString()        // 계산금액도 -1곱함
                                                                                       , row["ORIG_CLCL_AMT"].ToString()
                                                                                       , row["ADED_VALU_TAX_AMT"].ToString()
                                                                                       , row["PAY_USCH_AMT"].ToString()
                                                                                       , row["PAY_CLAM_AMT"].ToString()
                                                                                       , row["SCNG_PAY_USCH_AMT"].ToString()
                                                                                       , row["SCNG_PAY_CLAM_AMT"].ToString()
                                                                                       , row["VTRN_TAMT"].ToString()
                                                                                       , row["DCNT_AMT"].ToString()
                                                                                       , row["ADTN_APLY_TIME"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_1"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_2"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_3"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_4"].ToString()
                                                                                       , row["CNVR_PNT"].ToString()
                                                                                       , row["GRP_UNPR_APLY_YN"].ToString()
                                                                                       , row["DNFR_RGUP_CNTS"].ToString()
                                                                                       , row["DNFR_LFUP_CNTS"].ToString()
                                                                                       , row["DNFR_RGHT_LOW_CNTS"].ToString()
                                                                                       , row["DNFR_LEFT_LOW_CNTS"].ToString()
                                                                                       , row["HPMD_CLCL_DVCD"].ToString()
                                                                                       , row["HPMD_CLCL_QTY"].ToString()
                                                                                       , row["ENTS_ENTD_DVCD"].ToString()
                                                                                       , row["ENTS_ENTD_INSTNO"].ToString()
                                                                                       , row["SLCT_MCFE"].ToString()
                                                                                       , row["SMCR_RATE"].ToString()
                                                                                       , row["FXAM_INCL_YN"].ToString()
                                                                                       , row["TOTL_AOMD_QTY"].ToString()
                                                                                       , row["ORMD_ANS_YN"].ToString()
                                                                                       , row["ORMD_ANS_CD"].ToString()
                                                                                       , row["ORMD_ANS_NM"].ToString()
                                                                                       , row["ORMD_SITE_DVCD"].ToString()
                                                                                       , row["ORMD_SITE_CD"].ToString()
                                                                                       , row["MDCN_UPLM_AMT"].ToString()
                                                                                       , row["MDCN_UPLM_DIAM"].ToString()
                                                                                       , row["ORIG_PRSC_SQNO"].ToString()
                                                                                       , row["ORIG_SQNO"].ToString()
                                                                                       , row["PCLR_MATR"].ToString()
                                                                                       , m_AFRS_STAT_DVCD
                                                                                       , m_NEW_ROW_STAT_DVCD
                                                                                       , m_RGST_DT
                                                                                       , m_RGSTR_ID))
                        {
                            msg = DBService.ErrorMessage + "\r\n 외래수납처방내역 발생중 오류발생[ ROW_STAT_DVCD = " + m_ROW_STAT_DVCD + " ]";
                            // DBService.RollbackTransaction();
                            return false;
                        }
                        // #endregion 입원등록 D Insert
                    }
                    else if (optionString.Equals("F"))
                    {
                        // #region F Insert

                        if (!await DBService.ExecuteNonQuery(SQL.PA.BaseSql.Insert.PAORECBD(), row["PID"].ToString()
                                                                                       , row["PT_CMHS_NO"].ToString()
                                                                                       , m_NEW_RCPT_RQNO.ToString()
                                                                                       , row["APLY_SQNO"].ToString()
                                                                                       , row["PRSC_SQNO"].ToString()
                                                                                       , row["MDCR_DD"].ToString()
                                                                                       , row["ACTG_DD"].ToString()
                                                                                       , row["CLAM_CRTN_YN"].ToString()
                                                                                       , row["REAL_PRDC_CD"].ToString()
                                                                                       , row["PRSC_DVCD"].ToString()
                                                                                       , row["BNDL_PRSC_SQNO"].ToString()
                                                                                       , row["BNDL_MEFE_CD"].ToString()
                                                                                       , row["MEFE_CD"].ToString()
                                                                                       , row["MEFE_NM"].ToString()
                                                                                       , row["EDI_CD"].ToString()
                                                                                       , row["PRFT_CD"].ToString()
                                                                                       , row["ONTM_QTY"].ToString()
                                                                                       , row["NOTM"].ToString()
                                                                                       , row["NODY"].ToString()
                                                                                       , row["AOMD_MTHD_CD"].ToString()
                                                                                       , row["OUPR_GRNT_NO"].ToString()
                                                                                       , row["EXCP_RESN_CD"].ToString()
                                                                                       , row["DLVR_DEPT_CD"].ToString()
                                                                                       , row["ACTG_DEPT_CD"].ToString()
                                                                                       , row["CLCL_DVCD"].ToString()
                                                                                       , row["ACTN_MATL_DVCD"].ToString()
                                                                                       , row["CLUS_DVCD"].ToString()
                                                                                       , row["SBIT_DVCD"].ToString()
                                                                                       , row["MEFE_DVCD"].ToString()
                                                                                       , row["PAY_NOPY_DVCD"].ToString()
                                                                                       , row["SCNG_PAY_CD"].ToString()
                                                                                       , row["CNFR_DVCD"].ToString()
                                                                                       , row["CNFR_CD"].ToString()
                                                                                       , row["CMPT_CD"].ToString()
                                                                                       , row["TIME_ADTN_DVCD"].ToString()
                                                                                       , row["VTRN_PT_YN"].ToString()
                                                                                       , row["UNPR"].ToString()
                                                                                       , row["ADTN_CMPT_AMT"].ToString()
                                                                                       , row["BYKN_ADTN_AMT"].ToString()
                                                                                       , row["SMCR_AMT"].ToString()
                                                                                       , "0"                                        // 계산금액 0 설정
                                                                                       , row["ORIG_CLCL_AMT"].ToString()
                                                                                       , row["ADED_VALU_TAX_AMT"].ToString()
                                                                                       , row["PAY_USCH_AMT"].ToString()
                                                                                       , row["PAY_CLAM_AMT"].ToString()
                                                                                       , row["SCNG_PAY_USCH_AMT"].ToString()
                                                                                       , row["SCNG_PAY_CLAM_AMT"].ToString()
                                                                                       , row["VTRN_TAMT"].ToString()
                                                                                       , row["DCNT_AMT"].ToString()
                                                                                       , row["ADTN_APLY_TIME"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_1"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_2"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_3"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_4"].ToString()
                                                                                       , row["CNVR_PNT"].ToString()
                                                                                       , row["GRP_UNPR_APLY_YN"].ToString()
                                                                                       , row["DNFR_RGUP_CNTS"].ToString()
                                                                                       , row["DNFR_LFUP_CNTS"].ToString()
                                                                                       , row["DNFR_RGHT_LOW_CNTS"].ToString()
                                                                                       , row["DNFR_LEFT_LOW_CNTS"].ToString()
                                                                                       , row["HPMD_CLCL_DVCD"].ToString()
                                                                                       , row["HPMD_CLCL_QTY"].ToString()
                                                                                       , row["ENTS_ENTD_DVCD"].ToString()
                                                                                       , row["ENTS_ENTD_INSTNO"].ToString()
                                                                                       , row["SLCT_MCFE"].ToString()
                                                                                       , row["SMCR_RATE"].ToString()
                                                                                       , row["FXAM_INCL_YN"].ToString()
                                                                                       , row["TOTL_AOMD_QTY"].ToString()
                                                                                       , row["ORMD_ANS_YN"].ToString()
                                                                                       , row["ORMD_ANS_CD"].ToString()
                                                                                       , row["ORMD_ANS_NM"].ToString()
                                                                                       , row["ORMD_SITE_DVCD"].ToString()
                                                                                       , row["ORMD_SITE_CD"].ToString()
                                                                                       , row["MDCN_UPLM_AMT"].ToString()
                                                                                       , row["MDCN_UPLM_DIAM"].ToString()
                                                                                       , row["ORIG_PRSC_SQNO"].ToString()
                                                                                       , row["ORIG_SQNO"].ToString()
                                                                                       , row["PCLR_MATR"].ToString()
                                                                                       , m_AFRS_STAT_DVCD
                                                                                       , m_NEW_ROW_STAT_DVCD
                                                                                       , m_RGST_DT
                                                                                       , m_RGSTR_ID))
                        {
                            msg = DBService.ErrorMessage + "\r\n 외래수납처방내역 발생중 오류발생[ ROW_STAT_DVCD = " + m_ROW_STAT_DVCD + " ]";
                            // DBService.RollbackTransaction();
                            return false;
                        }
                        // #endregion F Insert
                    }
                    else
                    {
                        // #region Default Insert

                        if (!await DBService.ExecuteNonQuery(SQL.PA.BaseSql.Insert.PAORECBD(), row["PID"].ToString()
                                                                                       , row["PT_CMHS_NO"].ToString()
                                                                                       , m_NEW_RCPT_RQNO.ToString()
                                                                                       , row["APLY_SQNO"].ToString()
                                                                                       , row["PRSC_SQNO"].ToString()
                                                                                       , row["MDCR_DD"].ToString()
                                                                                       , row["ACTG_DD"].ToString()
                                                                                       , row["CLAM_CRTN_YN"].ToString()
                                                                                       , row["REAL_PRDC_CD"].ToString()
                                                                                       , row["PRSC_DVCD"].ToString()
                                                                                       , row["BNDL_PRSC_SQNO"].ToString()
                                                                                       , row["BNDL_MEFE_CD"].ToString()
                                                                                       , row["MEFE_CD"].ToString()
                                                                                       , row["MEFE_NM"].ToString()
                                                                                       , row["EDI_CD"].ToString()
                                                                                       , row["PRFT_CD"].ToString()
                                                                                       , row["ONTM_QTY"].ToString()
                                                                                       , row["NOTM"].ToString()
                                                                                       , row["NODY"].ToString()
                                                                                       , row["AOMD_MTHD_CD"].ToString()
                                                                                       , row["OUPR_GRNT_NO"].ToString()
                                                                                       , row["EXCP_RESN_CD"].ToString()
                                                                                       , row["DLVR_DEPT_CD"].ToString()
                                                                                       , row["ACTG_DEPT_CD"].ToString()
                                                                                       , row["CLCL_DVCD"].ToString()
                                                                                       , row["ACTN_MATL_DVCD"].ToString()
                                                                                       , row["CLUS_DVCD"].ToString()
                                                                                       , row["SBIT_DVCD"].ToString()
                                                                                       , row["MEFE_DVCD"].ToString()
                                                                                       , row["PAY_NOPY_DVCD"].ToString()
                                                                                       , row["SCNG_PAY_CD"].ToString()
                                                                                       , row["CNFR_DVCD"].ToString()
                                                                                       , row["CNFR_CD"].ToString()
                                                                                       , row["CMPT_CD"].ToString()
                                                                                       , row["TIME_ADTN_DVCD"].ToString()
                                                                                       , row["VTRN_PT_YN"].ToString()
                                                                                       , row["UNPR"].ToString()
                                                                                       , row["ADTN_CMPT_AMT"].ToString()
                                                                                       , row["BYKN_ADTN_AMT"].ToString()
                                                                                       , row["SMCR_AMT"].ToString()
                                                                                       , row["CLCL_AMT"].ToString()
                                                                                       , row["ORIG_CLCL_AMT"].ToString()
                                                                                       , row["ADED_VALU_TAX_AMT"].ToString()
                                                                                       , row["PAY_USCH_AMT"].ToString()
                                                                                       , row["PAY_CLAM_AMT"].ToString()
                                                                                       , row["SCNG_PAY_USCH_AMT"].ToString()
                                                                                       , row["SCNG_PAY_CLAM_AMT"].ToString()
                                                                                       , row["VTRN_TAMT"].ToString()
                                                                                       , row["DCNT_AMT"].ToString()
                                                                                       , row["ADTN_APLY_TIME"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_1"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_2"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_3"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_4"].ToString()
                                                                                       , row["CNVR_PNT"].ToString()
                                                                                       , row["GRP_UNPR_APLY_YN"].ToString()
                                                                                       , row["DNFR_RGUP_CNTS"].ToString()
                                                                                       , row["DNFR_LFUP_CNTS"].ToString()
                                                                                       , row["DNFR_RGHT_LOW_CNTS"].ToString()
                                                                                       , row["DNFR_LEFT_LOW_CNTS"].ToString()
                                                                                       , row["HPMD_CLCL_DVCD"].ToString()
                                                                                       , row["HPMD_CLCL_QTY"].ToString()
                                                                                       , row["ENTS_ENTD_DVCD"].ToString()
                                                                                       , row["ENTS_ENTD_INSTNO"].ToString()
                                                                                       , row["SLCT_MCFE"].ToString()
                                                                                       , row["SMCR_RATE"].ToString()
                                                                                       , row["FXAM_INCL_YN"].ToString()
                                                                                       , row["TOTL_AOMD_QTY"].ToString()
                                                                                       , row["ORMD_ANS_YN"].ToString()
                                                                                       , row["ORMD_ANS_CD"].ToString()
                                                                                       , row["ORMD_ANS_NM"].ToString()
                                                                                       , row["ORMD_SITE_DVCD"].ToString()
                                                                                       , row["ORMD_SITE_CD"].ToString()
                                                                                       , row["MDCN_UPLM_AMT"].ToString()
                                                                                       , row["MDCN_UPLM_DIAM"].ToString()
                                                                                       , row["ORIG_PRSC_SQNO"].ToString()
                                                                                       , row["ORIG_SQNO"].ToString()
                                                                                       , row["PCLR_MATR"].ToString()
                                                                                       , m_AFRS_STAT_DVCD
                                                                                       , m_NEW_ROW_STAT_DVCD
                                                                                       , m_RGST_DT
                                                                                       , m_RGSTR_ID))
                        {
                            msg = DBService.ErrorMessage + "\r\n 외래수납처방내역 발생중 오류발생[ ROW_STAT_DVCD = " + m_ROW_STAT_DVCD + " ]";
                            // DBService.RollbackTransaction();
                            return false;
                        }
                        // #endregion Default Insert
                    }

                    if (row["CLUS_DVCD"].ToString().Equals("T") && row["SBIT_DVCD"].ToString().Equals("01"))
                    {
                        clurdsblcount++;
                        pid = row["PID"].ToString();
                        ptcmhsno = row["PT_CMHS_NO"].ToString();
                    }

                }
                //this.Clear();
                //장루요루구분코드 변경
                if (clurdsblcount > 0)
                {
                    m_CLUR_DSBL_DVCD = "1";
                }
                else
                {
                    m_CLUR_DSBL_DVCD = "0";
                }

                if (!await DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateClurDsblDvcdOfPAOPATRT(), pid
                                                                                        , ptcmhsno
                                                                                        , m_CLUR_DSBL_DVCD))
                {
                    msg = "외래접수정보 장루요루구분코드 변경중 오류발생 \r\n Error Message : " + DBService.ErrorMessage;
                    // DBService.RollbackTransaction();
                    return false;
                }
            }
            catch (ex)
            {
                msg = "외래수납내역 취소 중 오류를 발생했습니다.\r\n " +
                      "Method :  [InsertPaOrecBd] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }
            return true;
        }

        /// <summary>
        /// 외래수납처방내역의 행상태구분코드 UPDATE
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public UpdateRowStatDvcdOfPaOrecBd(msg:string)
        {
            let success:boolean = true;

            if (!await DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePAORECBD_RowStatDvcd(), this.PID
                                                                                  , this.PT_CMHS_NO.ToString()
                                                                                  , this.ROW_STAT_DVCD
                                                                                  , this.NEW_ROW_STAT_DVCD))
            {
                success = false;
                msg = DBService.ErrorMessage + "\r\n 외래수납처방내역의 행상태구분코드 변경중 오류가 발생하였습니다. 확인하시기 바랍니다.";
                // DBService.RollbackTransaction();
            }
            return success;
        }

        public GetORORDRRT(pid:string, ptcmhsno:number)
        {
            let result:boolean = true;
            try
            {
                result = await DBService.ExecuteDataTable(SQL.PA.Sql.SelectORORDRRT_Receipt(true), /*ref*/ this.m_DtPrsc, pid, ptcmhsno.ToString());
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                result = false;
            }
            return result;
        }

        // #endregion Method : Public Method
    }
