//                                                                                
// Class 명 : clsOutBillTemp
// 역    할 : 외래영수 TEMP
// 작 성 자 : PGH
// 작 성 일 : 2017-09-28
//                                                                                
// 수정내역 : 
//                                                                                
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public class clsOutBillTemp
    {
        #region Define : Member
        private string m_PID = String.Empty;    //환자등록번호                     VARCHAR2(10)
        private int m_PT_CMHS_NO = 0;               //환자내원번호                     NUMBER(10, 0)
        private int m_RCPT_SQNO = 0;               //수납일련번호                     NUMBER(5, 0)
        private string m_MDCR_DD = String.Empty;    //진료일자                         VARCHAR2(8)
        private string m_BILL_NO = String.Empty;    //영수증번호                       VARCHAR2(10)
        private string m_INSN_TYCD = String.Empty;    //보험유형코드                     VARCHAR2(2)
        private string m_ASST_TYCD = String.Empty;    //보조유형코드                     VARCHAR2(2)
        private string m_ASCT_RGNO_CD = String.Empty;    //조합기호코드                     VARCHAR2(20)
        private string m_MDCR_DEPT_CD = String.Empty;    //진료부서코드                     VARCHAR2(10)
        private string m_MDCR_DR_CD = String.Empty;    //진료의사코드                     VARCHAR2(10)
        private int m_TOTL_MDCR_AMT = 0;               //총진료금액                       NUMBER(10, 0)
        private int m_PAY_TAMT = 0;               //급여총금액                       NUMBER(10, 0)
        private int m_INSN_100_TAMT = 0;               //보험100총금액                    NUMBER(10, 0)
        private int m_SCNG_PAY_TAMT = 0;               //선별급여총금액                   NUMBER(10, 0)
        private int m_NOPY_TAMT = 0;               //비급여총금액                     NUMBER(10, 0)
        private int m_CLAM_NOPY_TAMT = 0;               //청구비급여총금액                 NUMBER(10, 0)
        private int m_ADED_VALU_TAX_TAMT = 0;               //부가가치세총금액                 NUMBER(10, 0)
        private int m_VTRN_TAMT = 0;               //보훈총금액                       NUMBER(10, 0)
        private int m_BYKN_ADTN_AMT = 0;               //종별가산금액                     NUMBER(10, 0)
        private int m_SMCR_AMT = 0;               //선택진료금액                     NUMBER(10, 0)
        private int m_PAY_USCH_AMT = 0;               //급여본인부담금액                 NUMBER(10, 0)
        private int m_SCNG_PAY_USCH_AMT = 0;               //선별급여본인부담금액             NUMBER(10, 0)
        private int m_PAY_CLAM_AMT = 0;               //급여청구금액                     NUMBER(10, 0)
        private int m_SCNG_PAY_CLAM_AMT = 0;               //선별급여청구금액                 NUMBER(10, 0)
        private int m_MDCN_UPLM_DIAM = 0;               //약제상한차액                     NUMBER(10, 0)
        private int m_HMPT_PAY_TAMT = 0;               //수진자급여총금액                 NUMBER(10, 0)
        private int m_DSBL_FUND_AMT = 0;               //장애기금금액                     NUMBER(10, 0)
        private int m_PFAN_AMT = 0;               //대불금액                         NUMBER(10, 0)
        private int m_USCH_UPLM_AMT = 0;               //본인부담상한금액                 NUMBER(10, 0)
        private int m_SUPT_AMT = 0;               //지원금액                         NUMBER(10, 0)
        private int m_EMRG_SUPT_AMT = 0;               //긴급지원금액                     NUMBER(10, 0)
        private int m_TBRC_CTCT_SUPT_AMT = 0;               //결핵접촉지원금액                 NUMBER(10, 0)
        private int m_MTWM_CLAM_AMT = 0;               //산모청구금액                     NUMBER(10, 0)
        private int m_MTWM_BLCE = 0;               //산모잔액                         NUMBER(10, 0)
        private int m_MTWM_PAY_CLAM_AMT = 0;               //산모급여청구금액                 NUMBER(10, 0)
        private int m_MTWM_I100_CLAM_AMT = 0;               //산모보험100청구금액              NUMBER(10, 0)
        private int m_MTWM_NOPY_CLAM_AMT = 0;               //산모비급여청구금액               NUMBER(10, 0)
        private int m_MTWM_SCPY_CLAM_AMT = 0;               //산모선별급여청구금액             NUMBER(10, 0)
        private int m_INDP_MOMR_CLAM_AMT = 0;               //독립유공자청구금액               NUMBER(10, 0)
        private int m_VCNT_CLAM_AMT = 0;               //예방접종청구금액                 NUMBER(10, 0)
        private int m_CT_USCH_AMT = 0;               //CT본인부담금액                   NUMBER(10, 0)
        private int m_MRI_USCH_AMT = 0;               //MRI본인부담금액                  NUMBER(10, 0)
        private int m_PET_USCH_AMT = 0;               //PET본인부담금액                  NUMBER(10, 0)
        private int m_FRTM_CARD_RCPT_AMT = 0;               //이전카드수납금액                 NUMBER(10, 0)
        private int m_FRTM_CASH_RCPT_AMT = 0;               //이전현금수납금액                 NUMBER(10, 0)
        private int m_FRTM_BNAC_AMT = 0;               //이전계좌금액                     NUMBER(10, 0)
        private int m_VTRN_RNE_AMT = 0;               //보훈감면금액                     NUMBER(10, 0)
        private string m_DCNT_RDIA_CD = String.Empty;    //할인감액코드                     VARCHAR2(10)
        private string m_DCNT_RDIA_EMNO = String.Empty;    //할인감액직원번호                 VARCHAR2(10)
        private int m_DCNT_RDIA_AMT = 0;               //할인감액금액                     NUMBER(10, 0)
        private int m_FRTM_DCNT_RDIA_AMT = 0;               //이전할인감액금액                 NUMBER(10, 0)
        private string m_BLDN_YN = String.Empty;    //헌혈여부                         VARCHAR2(1)
        private int m_BLOD_RDIA_AMT = 0;               //혈액감액금액                     NUMBER(10, 0)
        private string m_VTRD_APLY_DVCD = String.Empty;    //수직감액적용구분코드             VARCHAR2(2)
        private int m_VTRD_AMT = 0;               //수직감액금액                     NUMBER(10, 0)
        private string m_CTTR_NO_CD = String.Empty;    //계약처번호코드                   VARCHAR2(10)
        private int m_CTTR_UNCL_APLY_AMT = 0;               //계약처미수적용금액               NUMBER(10, 0)
        private int m_CLNC_UNCL_APLY_AMT = 0;               //임상미수적용금액                 NUMBER(10, 0)
        private int m_GURN_CARD_AMT = 0;               //보증카드금액                     NUMBER(10, 0)
        private int m_GURN_BNAC_AMT = 0;               //보증계좌금액                     NUMBER(10, 0)
        private int m_GURN_CASH_AMT = 0;               //보증현금금액                     NUMBER(10, 0)
        private int m_HLLF_MNCS_CLAM_AMT = 0;               //건강생활유지비청구금액           NUMBER(10, 0)
        private int m_HLLF_MNCS_BLCE = 0;               //건강생활유지비잔액               NUMBER(10, 0)
        private int m_PT_SHAR_AMT = 0;               //환자부담금액                     NUMBER(10, 0)
        private int m_TRNC_AMT = 0;               //절사금액                         NUMBER(10, 0)
        private string m_MDAD_PRMT_NO = String.Empty;    //의료급여승인번호                 VARCHAR2(50)
        private int m_FXAM_MCCS = 0;               //정액진료비                       NUMBER(10, 0)
        private int m_FXAM_MCCS_REAL_AMT = 0;               //정액진료비 실금액                NUMBER(10, 0)
        private string m_UNCL_CD = String.Empty;    //미수코드                         VARCHAR2(10)
        private int m_UNCL_AMT = 0;               //미수금액                         NUMBER(10, 0)
        private string m_SPCF_AMT_CLCL_DVCD = String.Empty;    //특정금액계산구분코드             VARCHAR2(10)

        private int m_TOTL_SHAR_AMT = 0;               //총본인부담금액
        private int m_CASH_RCPT_AMT = 0;               //현금수납금액
        private int m_CARD_RCPT_AMT = 0;               //카드수납금액
        private int m_BNAC_RCPT_AMT = 0;               //계좌수납금액
        private int m_SPCL_DCNT_AMT = 0;               //특별할인금액

        private int m_GVRN_CLAM_AMT = 0;    // 공무원공상청구금액

        private string m_CFSC_RGNO_CD = String.Empty;     // 산정특례기호코드
        private string m_USCH_APLY_CD = String.Empty;     // 본인부담적용코드
        private string m_DY_WARD_YN = String.Empty;     // 낮병동여부
        private string m_OTPT_DRG_YN = String.Empty;     // DRG여부
        private string m_VTRN_PT_YN = String.Empty;      // 보훈환자여부
        private string m_MOMR_AGE_DVCD = String.Empty;      // 유공자연령구분코드
        private string m_INDP_MOMR_YN = String.Empty;      // 독립유공자여부
        #endregion

        #region Property : Member Property
        public string PID { get { return m_PID; } set { m_PID = value; } }
        public int PT_CMHS_NO { get { return m_PT_CMHS_NO; } set { m_PT_CMHS_NO = value; } }
        public int RCPT_SQNO { get { return m_RCPT_SQNO; } set { m_RCPT_SQNO = value; } }
        public string MDCR_DD { get { return m_MDCR_DD; } set { m_MDCR_DD = value; } }
        public string BILL_NO { get { return m_BILL_NO; } set { m_BILL_NO = value; } }
        public string INSN_TYCD { get { return m_INSN_TYCD; } set { m_INSN_TYCD = value; } }
        public string ASST_TYCD { get { return m_ASST_TYCD; } set { m_ASST_TYCD = value; } }
        public string ASCT_RGNO_CD { get { return m_ASCT_RGNO_CD; } set { m_ASCT_RGNO_CD = value; } }
        public string MDCR_DEPT_CD { get { return m_MDCR_DEPT_CD; } set { m_MDCR_DEPT_CD = value; } }
        public string MDCR_DR_CD { get { return m_MDCR_DR_CD; } set { m_MDCR_DR_CD = value; } }
        public int TOTL_MDCR_AMT { get { return m_TOTL_MDCR_AMT; } set { m_TOTL_MDCR_AMT = value; } }
        public int PAY_TAMT { get { return m_PAY_TAMT; } set { m_PAY_TAMT = value; } }
        public int INSN_100_TAMT { get { return m_INSN_100_TAMT; } set { m_INSN_100_TAMT = value; } }
        public int SCNG_PAY_TAMT { get { return m_SCNG_PAY_TAMT; } set { m_SCNG_PAY_TAMT = value; } }
        public int NOPY_TAMT { get { return m_NOPY_TAMT; } set { m_NOPY_TAMT = value; } }
        public int CLAM_NOPY_TAMT { get { return m_CLAM_NOPY_TAMT; } set { m_CLAM_NOPY_TAMT = value; } }
        public int ADED_VALU_TAX_TAMT { get { return m_ADED_VALU_TAX_TAMT; } set { m_ADED_VALU_TAX_TAMT = value; } }
        public int VTRN_TAMT { get { return m_VTRN_TAMT; } set { m_VTRN_TAMT = value; } }
        public int BYKN_ADTN_AMT { get { return m_BYKN_ADTN_AMT; } set { m_BYKN_ADTN_AMT = value; } }
        public int SMCR_AMT { get { return m_SMCR_AMT; } set { m_SMCR_AMT = value; } }
        public int PAY_USCH_AMT { get { return m_PAY_USCH_AMT; } set { m_PAY_USCH_AMT = value; } }
        public int SCNG_PAY_USCH_AMT { get { return m_SCNG_PAY_USCH_AMT; } set { m_SCNG_PAY_USCH_AMT = value; } }
        public int PAY_CLAM_AMT { get { return m_PAY_CLAM_AMT; } set { m_PAY_CLAM_AMT = value; } }
        public int SCNG_PAY_CLAM_AMT { get { return m_SCNG_PAY_CLAM_AMT; } set { m_SCNG_PAY_CLAM_AMT = value; } }
        public int MDCN_UPLM_DIAM { get { return m_MDCN_UPLM_DIAM; } set { m_MDCN_UPLM_DIAM = value; } }
        public int HMPT_PAY_TAMT { get { return m_HMPT_PAY_TAMT; } set { m_HMPT_PAY_TAMT = value; } }
        public int DSBL_FUND_AMT { get { return m_DSBL_FUND_AMT; } set { m_DSBL_FUND_AMT = value; } }
        public int PFAN_AMT { get { return m_PFAN_AMT; } set { m_PFAN_AMT = value; } }
        public int USCH_UPLM_AMT { get { return m_USCH_UPLM_AMT; } set { m_USCH_UPLM_AMT = value; } }
        public int SUPT_AMT { get { return m_SUPT_AMT; } set { m_SUPT_AMT = value; } }
        public int EMRG_SUPT_AMT { get { return m_EMRG_SUPT_AMT; } set { m_EMRG_SUPT_AMT = value; } }
        public int TBRC_CTCT_SUPT_AMT { get { return m_TBRC_CTCT_SUPT_AMT; } set { m_TBRC_CTCT_SUPT_AMT = value; } }
        public int MTWM_CLAM_AMT { get { return m_MTWM_CLAM_AMT; } set { m_MTWM_CLAM_AMT = value; } }
        public int MTWM_BLCE { get { return m_MTWM_BLCE; } set { m_MTWM_BLCE = value; } }
        public int MTWM_PAY_CLAM_AMT { get { return m_MTWM_PAY_CLAM_AMT; } set { m_MTWM_PAY_CLAM_AMT = value; } }
        public int MTWM_I100_CLAM_AMT { get { return m_MTWM_I100_CLAM_AMT; } set { m_MTWM_I100_CLAM_AMT = value; } }
        public int MTWM_NOPY_CLAM_AMT { get { return m_MTWM_NOPY_CLAM_AMT; } set { m_MTWM_NOPY_CLAM_AMT = value; } }
        public int MTWM_SCPY_CLAM_AMT { get { return m_MTWM_SCPY_CLAM_AMT; } set { m_MTWM_SCPY_CLAM_AMT = value; } }
        public int INDP_MOMR_CLAM_AMT { get { return m_INDP_MOMR_CLAM_AMT; } set { m_INDP_MOMR_CLAM_AMT = value; } }
        public int VCNT_CLAM_AMT { get { return m_VCNT_CLAM_AMT; } set { m_VCNT_CLAM_AMT = value; } }
        public int CT_USCH_AMT { get { return m_CT_USCH_AMT; } set { m_CT_USCH_AMT = value; } }
        public int MRI_USCH_AMT { get { return m_MRI_USCH_AMT; } set { m_MRI_USCH_AMT = value; } }
        public int PET_USCH_AMT { get { return m_PET_USCH_AMT; } set { m_PET_USCH_AMT = value; } }
        public int FRTM_CARD_RCPT_AMT { get { return m_FRTM_CARD_RCPT_AMT; } set { m_FRTM_CARD_RCPT_AMT = value; } }
        public int FRTM_CASH_RCPT_AMT { get { return m_FRTM_CASH_RCPT_AMT; } set { m_FRTM_CASH_RCPT_AMT = value; } }
        public int FRTM_BNAC_AMT { get { return m_FRTM_BNAC_AMT; } set { m_FRTM_BNAC_AMT = value; } }
        public int VTRN_RNE_AMT { get { return m_VTRN_RNE_AMT; } set { m_VTRN_RNE_AMT = value; } }
        public string DCNT_RDIA_CD { get { return m_DCNT_RDIA_CD; } set { m_DCNT_RDIA_CD = value; } }
        public string DCNT_RDIA_EMNO { get { return m_DCNT_RDIA_EMNO; } set { m_DCNT_RDIA_EMNO = value; } }
        public int DCNT_RDIA_AMT { get { return m_DCNT_RDIA_AMT; } set { m_DCNT_RDIA_AMT = value; } }
        public int FRTM_DCNT_RDIA_AMT { get { return m_FRTM_DCNT_RDIA_AMT; } set { m_FRTM_DCNT_RDIA_AMT = value; } }
        public string BLDN_YN { get { return m_BLDN_YN; } set { m_BLDN_YN = value; } }
        public int BLOD_RDIA_AMT { get { return m_BLOD_RDIA_AMT; } set { m_BLOD_RDIA_AMT = value; } }
        public string VTRD_APLY_DVCD { get { return m_VTRD_APLY_DVCD; } set { m_VTRD_APLY_DVCD = value; } }
        public int VTRD_AMT { get { return m_VTRD_AMT; } set { m_VTRD_AMT = value; } }
        public string CTTR_NO_CD { get { return m_CTTR_NO_CD; } set { m_CTTR_NO_CD = value; } }
        public int CTTR_UNCL_APLY_AMT { get { return m_CTTR_UNCL_APLY_AMT; } set { m_CTTR_UNCL_APLY_AMT = value; } }
        public int CLNC_UNCL_APLY_AMT { get { return m_CLNC_UNCL_APLY_AMT; } set { m_CLNC_UNCL_APLY_AMT = value; } }
        public int GURN_CARD_AMT { get { return m_GURN_CARD_AMT; } set { m_GURN_CARD_AMT = value; } }
        public int GURN_BNAC_AMT { get { return m_GURN_BNAC_AMT; } set { m_GURN_BNAC_AMT = value; } }
        public int GURN_CASH_AMT { get { return m_GURN_CASH_AMT; } set { m_GURN_CASH_AMT = value; } }
        public int HLLF_MNCS_CLAM_AMT { get { return m_HLLF_MNCS_CLAM_AMT; } set { m_HLLF_MNCS_CLAM_AMT = value; } }
        public int HLLF_MNCS_BLCE { get { return m_HLLF_MNCS_BLCE; } set { m_HLLF_MNCS_BLCE = value; } }
        public int PT_SHAR_AMT { get { return m_PT_SHAR_AMT; } set { m_PT_SHAR_AMT = value; } }
        public int TRNC_AMT { get { return m_TRNC_AMT; } set { m_TRNC_AMT = value; } }
        public string MDAD_PRMT_NO { get { return m_MDAD_PRMT_NO; } set { m_MDAD_PRMT_NO = value; } }
        public int FXAM_MCCS { get { return m_FXAM_MCCS; } set { m_FXAM_MCCS = value; } }
        public int FXAM_MCCS_REAL_AMT { get { return m_FXAM_MCCS_REAL_AMT; } set { m_FXAM_MCCS_REAL_AMT = value; } }
        public string UNCL_CD { get { return m_UNCL_CD; } set { m_UNCL_CD = value; } }
        public int UNCL_AMT { get { return m_UNCL_AMT; } set { m_UNCL_AMT = value; } }
        public string SPCF_AMT_CLCL_DVCD { get { return m_SPCF_AMT_CLCL_DVCD; } set { m_SPCF_AMT_CLCL_DVCD = value; } }
        public int TOTL_SHAR_AMT { get { return m_TOTL_SHAR_AMT; } set { m_TOTL_SHAR_AMT = value; } }
        public int CASH_RCPT_AMT { get { return m_CASH_RCPT_AMT; } set { m_CASH_RCPT_AMT = value; } }
        public int CARD_RCPT_AMT { get { return m_CARD_RCPT_AMT; } set { m_CARD_RCPT_AMT = value; } }
        public int BNAC_RCPT_AMT { get { return m_BNAC_RCPT_AMT; } set { m_BNAC_RCPT_AMT = value; } }
        public int SPCL_DCNT_AMT { get { return m_SPCL_DCNT_AMT; } set { m_SPCL_DCNT_AMT = value; } }

        public int GVRN_CLAM_AMT { get { return m_GVRN_CLAM_AMT; } set { m_GVRN_CLAM_AMT = value; } }

        public string CFSC_RGNO_CD { get { return m_CFSC_RGNO_CD; } set { m_CFSC_RGNO_CD = value; } }     // 산정특례기호코드
        public string USCH_APLY_CD { get { return m_USCH_APLY_CD; } set { m_USCH_APLY_CD = value; } }     // 본인부담적용코드
        public string DY_WARD_YN { get { return m_DY_WARD_YN; } set { m_DY_WARD_YN = value; } }     // 낮병동여부
        public string OTPT_DRG_YN { get { return m_OTPT_DRG_YN; } set { m_OTPT_DRG_YN = value; } }     // 낮병동여부
        public string VTRN_PT_YN { get { return m_VTRN_PT_YN; } set { m_VTRN_PT_YN = value; } }      // 보훈환자여부
        public string MOMR_AGE_DVCD { get { return m_MOMR_AGE_DVCD; } set { m_MOMR_AGE_DVCD = value; } }      // 유공자연령구분코드
        public string INDP_MOMR_YN { get { return m_INDP_MOMR_YN; } set { m_INDP_MOMR_YN = value; } }      // 독립유공자여부
        #endregion Property : Member Property

        #region Construction
        public clsOutBillTemp()
        {
            Clear();
        }
        #endregion Construction

        #region Method : Public Method
        public void Clear()
        {
            m_PID = String.Empty;
            m_PT_CMHS_NO = 0;
            m_RCPT_SQNO = 0;
            m_MDCR_DD = String.Empty;
            m_BILL_NO = String.Empty;
            m_INSN_TYCD = String.Empty;
            m_ASST_TYCD = String.Empty;
            m_ASCT_RGNO_CD = String.Empty;
            m_MDCR_DEPT_CD = String.Empty;
            m_MDCR_DR_CD = String.Empty;
            m_TOTL_MDCR_AMT = 0;
            m_PAY_TAMT = 0;
            m_INSN_100_TAMT = 0;
            m_SCNG_PAY_TAMT = 0;
            m_NOPY_TAMT = 0;
            m_CLAM_NOPY_TAMT = 0;
            m_ADED_VALU_TAX_TAMT = 0;
            m_VTRN_TAMT = 0;
            m_BYKN_ADTN_AMT = 0;
            m_SMCR_AMT = 0;
            m_PAY_USCH_AMT = 0;
            m_SCNG_PAY_USCH_AMT = 0;
            m_PAY_CLAM_AMT = 0;
            m_SCNG_PAY_CLAM_AMT = 0;
            m_MDCN_UPLM_DIAM = 0;
            m_HMPT_PAY_TAMT = 0;
            m_DSBL_FUND_AMT = 0;
            m_PFAN_AMT = 0;
            m_USCH_UPLM_AMT = 0;
            m_SUPT_AMT = 0;
            m_EMRG_SUPT_AMT = 0;
            m_TBRC_CTCT_SUPT_AMT = 0;
            m_MTWM_CLAM_AMT = 0;
            m_MTWM_BLCE = 0;
            m_MTWM_PAY_CLAM_AMT = 0;
            m_MTWM_I100_CLAM_AMT = 0;
            m_MTWM_NOPY_CLAM_AMT = 0;
            m_MTWM_SCPY_CLAM_AMT = 0;
            m_INDP_MOMR_CLAM_AMT = 0;
            m_VCNT_CLAM_AMT = 0;
            m_CT_USCH_AMT = 0;
            m_MRI_USCH_AMT = 0;
            m_PET_USCH_AMT = 0;
            m_FRTM_CARD_RCPT_AMT = 0;
            m_FRTM_CASH_RCPT_AMT = 0;
            m_FRTM_BNAC_AMT = 0;
            m_VTRN_RNE_AMT = 0;
            m_DCNT_RDIA_CD = String.Empty;
            m_DCNT_RDIA_EMNO = String.Empty;
            m_DCNT_RDIA_AMT = 0;
            m_FRTM_DCNT_RDIA_AMT = 0;
            m_BLDN_YN = String.Empty;
            m_BLOD_RDIA_AMT = 0;
            m_VTRD_APLY_DVCD = String.Empty;
            m_VTRD_AMT = 0;
            m_CTTR_NO_CD = String.Empty;
            m_CTTR_UNCL_APLY_AMT = 0;
            m_CLNC_UNCL_APLY_AMT = 0;
            m_GURN_CARD_AMT = 0;
            m_GURN_BNAC_AMT = 0;
            m_GURN_CASH_AMT = 0;
            m_HLLF_MNCS_CLAM_AMT = 0;
            m_HLLF_MNCS_BLCE = 0;
            m_PT_SHAR_AMT = 0;
            m_TRNC_AMT = 0;
            m_MDAD_PRMT_NO = String.Empty;
            m_FXAM_MCCS = 0;
            m_FXAM_MCCS_REAL_AMT = 0;
            m_UNCL_CD = String.Empty;
            m_UNCL_AMT = 0;
            m_SPCF_AMT_CLCL_DVCD = String.Empty;

            m_GVRN_CLAM_AMT = 0;

            m_TOTL_SHAR_AMT = 0;
            m_CASH_RCPT_AMT = 0;
            m_CARD_RCPT_AMT = 0;
            m_BNAC_RCPT_AMT = 0;
            m_SPCL_DCNT_AMT = 0;

            m_CFSC_RGNO_CD = String.Empty;
            m_USCH_APLY_CD = String.Empty;
            m_DY_WARD_YN = String.Empty;
            m_OTPT_DRG_YN = String.Empty;
            m_VTRN_PT_YN = String.Empty;
            m_MOMR_AGE_DVCD = String.Empty;
            m_INDP_MOMR_YN = String.Empty;
        }
        #region Method : SelectData Method

        public bool Load(string pid, int ptcmhsno)
        {
            return GetPAOBILTP(pid, ptcmhsno);
        }


        #endregion Method : SelectData Method

        #endregion Method : Public Method

        #region Method : Private Method

        private bool GetPAOBILTP(string pid, int ptcmhsno)
        {

            try
            {
                DataTable dtOutBill = new DataTable();

                try
                {
                    DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOBILTP(), ref dtOutBill, pid
                                                                                         , ptcmhsno.ToString());
                }
                catch (Exception ex)
                {
                    LogService.ErrorLog(ex);
                }

                if (dtOutBill.Rows.Count > 0)
                {
                    DataRow row = dtOutBill.Rows[0];
                    m_PID = row["PID"].ToString();                                                   //환자등록번호
                    m_PT_CMHS_NO = int.Parse(row["PT_CMHS_NO"].ToString());                                 //환자내원번호
                    m_RCPT_SQNO = int.Parse(row["RCPT_SQNO"].ToString());                                  //수납일련번호
                    m_MDCR_DD = row["MDCR_DD"].ToString();                                               //진료일자
                    m_BILL_NO = row["BILL_NO"].ToString();                                               //영수증번호
                    m_INSN_TYCD = row["INSN_TYCD"].ToString();                                             //보험유형코드
                    m_ASST_TYCD = row["ASST_TYCD"].ToString();                                             //보조유형코드
                    m_ASCT_RGNO_CD = row["ASCT_RGNO_CD"].ToString();                                          //조합기호코드
                    m_MDCR_DEPT_CD = row["MDCR_DEPT_CD"].ToString();                                          //진료부서코드
                    m_MDCR_DR_CD = row["MDCR_DR_CD"].ToString();                                            //진료의사코드
                    m_TOTL_MDCR_AMT = int.Parse(row["TOTL_MDCR_AMT"].ToString());                              //총진료금액
                    m_PAY_TAMT = int.Parse(row["PAY_TAMT"].ToString());                                   //급여총금액
                    m_INSN_100_TAMT = int.Parse(row["INSN_100_TAMT"].ToString());                              //보험100총금액
                    m_SCNG_PAY_TAMT = int.Parse(row["SCNG_PAY_TAMT"].ToString());                              //선별급여총금액
                    m_NOPY_TAMT = int.Parse(row["NOPY_TAMT"].ToString());                                  //비급여총금액
                    m_CLAM_NOPY_TAMT = int.Parse(row["CLAM_NOPY_TAMT"].ToString());                             //청구비급여총금액
                    m_ADED_VALU_TAX_TAMT = int.Parse(row["ADED_VALU_TAX_TAMT"].ToString());                         //부가가치세총금액
                    m_VTRN_TAMT = int.Parse(row["VTRN_TAMT"].ToString());                                  //보훈총금액
                    m_BYKN_ADTN_AMT = int.Parse(row["BYKN_ADTN_AMT"].ToString());                              //종별가산금액
                    m_SMCR_AMT = int.Parse(row["SMCR_AMT"].ToString());                                   //선택진료금액
                    m_PAY_USCH_AMT = int.Parse(row["PAY_USCH_AMT"].ToString());                               //급여본인부담금액
                    m_SCNG_PAY_USCH_AMT = int.Parse(row["SCNG_PAY_USCH_AMT"].ToString());                          //선별급여본인부담금액
                    m_PAY_CLAM_AMT = int.Parse(row["PAY_CLAM_AMT"].ToString());                               //급여청구금액
                    m_SCNG_PAY_CLAM_AMT = int.Parse(row["SCNG_PAY_CLAM_AMT"].ToString());                          //선별급여청구금액
                    m_MDCN_UPLM_DIAM = int.Parse(row["MDCN_UPLM_DIAM"].ToString());                             //약제상한차액
                    m_HMPT_PAY_TAMT = int.Parse(row["HMPT_PAY_TAMT"].ToString());                              //수진자급여총금액
                    m_DSBL_FUND_AMT = int.Parse(row["DSBL_FUND_AMT"].ToString());                              //장애기금금액
                    m_PFAN_AMT = int.Parse(row["PFAN_AMT"].ToString());                                   //대불금액
                    m_USCH_UPLM_AMT = int.Parse(row["USCH_UPLM_AMT"].ToString());                              //본인부담상한금액
                    m_SUPT_AMT = int.Parse(row["SUPT_AMT"].ToString());                                   //지원금액
                    m_EMRG_SUPT_AMT = int.Parse(row["EMRG_SUPT_AMT"].ToString());                              //긴급지원금액
                    m_TBRC_CTCT_SUPT_AMT = int.Parse(row["TBRC_CTCT_SUPT_AMT"].ToString());                         //결핵접촉지원금액
                    m_MTWM_CLAM_AMT = int.Parse(row["MTWM_CLAM_AMT"].ToString());                              //산모청구금액
                    m_MTWM_BLCE = int.Parse(row["MTWM_BLCE"].ToString());                                  //산모잔액
                    m_MTWM_PAY_CLAM_AMT = int.Parse(row["MTWM_PAY_CLAM_AMT"].ToString());                          //산모급여청구금액
                    m_MTWM_I100_CLAM_AMT = int.Parse(row["MTWM_I100_CLAM_AMT"].ToString());                         //산모보험100청구금액
                    m_MTWM_NOPY_CLAM_AMT = int.Parse(row["MTWM_NOPY_CLAM_AMT"].ToString());                         //산모비급여청구금액
                    m_MTWM_SCPY_CLAM_AMT = int.Parse(row["MTWM_SCPY_CLAM_AMT"].ToString());                         //산모선별급여청구금액
                    m_INDP_MOMR_CLAM_AMT = int.Parse(row["INDP_MOMR_CLAM_AMT"].ToString());                         //독립유공자청구금액
                    m_VCNT_CLAM_AMT = int.Parse(row["VCNT_CLAM_AMT"].ToString());                              //예방접종청구금액
                    m_CT_USCH_AMT = int.Parse(row["CT_USCH_AMT"].ToString());                                //CT본인부담금액
                    m_MRI_USCH_AMT = int.Parse(row["MRI_USCH_AMT"].ToString());                               //MRI본인부담금액
                    m_PET_USCH_AMT = int.Parse(row["PET_USCH_AMT"].ToString());                               //PET본인부담금액
                    m_FRTM_CARD_RCPT_AMT = int.Parse(row["FRTM_CARD_RCPT_AMT"].ToString());                         //이전카드수납금액
                    m_FRTM_CASH_RCPT_AMT = int.Parse(row["FRTM_CASH_RCPT_AMT"].ToString());                         //이전현금수납금액
                    m_FRTM_BNAC_AMT = int.Parse(row["FRTM_BNAC_AMT"].ToString());                              //이전계좌금액
                    m_VTRN_RNE_AMT = int.Parse(row["VTRN_RNE_AMT"].ToString());                               //보훈감면금액
                    m_DCNT_RDIA_CD = row["DCNT_RDIA_CD"].ToString();                                          //할인감액코드
                    m_DCNT_RDIA_EMNO = row["DCNT_RDIA_EMNO"].ToString();                                        //할인감액직원번호
                    m_DCNT_RDIA_AMT = int.Parse(row["DCNT_RDIA_AMT"].ToString());                              //할인감액금액
                    m_FRTM_DCNT_RDIA_AMT = int.Parse(row["FRTM_DCNT_RDIA_AMT"].ToString());                         //이전할인감액금액
                    m_BLDN_YN = row["BLDN_YN"].ToString();                                               //헌혈여부
                    m_BLOD_RDIA_AMT = int.Parse(row["BLOD_RDIA_AMT"].ToString());                              //혈액감액금액
                    m_VTRD_APLY_DVCD = row["VTRD_APLY_DVCD"].ToString();                                        //수직감액적용구분코드
                    m_VTRD_AMT = int.Parse(row["VTRD_AMT"].ToString());                                   //수직감액금액
                    m_CTTR_NO_CD = row["CTTR_NO_CD"].ToString();                                            //계약처번호코드
                    m_CTTR_UNCL_APLY_AMT = int.Parse(row["CTTR_UNCL_APLY_AMT"].ToString());                         //계약처미수적용금액
                    m_CLNC_UNCL_APLY_AMT = int.Parse(row["CLNC_UNCL_APLY_AMT"].ToString());                         //임상미수적용금액
                    m_GURN_CARD_AMT = int.Parse(row["GURN_CARD_AMT"].ToString());                              //보증카드금액
                    m_GURN_BNAC_AMT = int.Parse(row["GURN_BNAC_AMT"].ToString());                              //보증계좌금액
                    m_GURN_CASH_AMT = int.Parse(row["GURN_CASH_AMT"].ToString());                              //보증현금금액
                    m_HLLF_MNCS_CLAM_AMT = int.Parse(row["HLLF_MNCS_CLAM_AMT"].ToString());                         //건강생활유지비청구금액
                    m_HLLF_MNCS_BLCE = int.Parse(row["HLLF_MNCS_BLCE"].ToString());                             //건강생활유지비잔액
                    m_PT_SHAR_AMT = int.Parse(row["PT_SHAR_AMT"].ToString());                                //환자부담금액
                    m_TRNC_AMT = int.Parse(row["TRNC_AMT"].ToString());                                   //절사금액
                    m_MDAD_PRMT_NO = row["MDAD_PRMT_NO"].ToString();                                          //의료급여승인번호
                    m_FXAM_MCCS = int.Parse(row["FXAM_MCCS"].ToString());                                  //정액진료비
                    m_FXAM_MCCS_REAL_AMT = int.Parse(row["FXAM_MCCS_REAL_AMT"].ToString());                         //정액진료비 실금액
                    m_UNCL_CD = row["UNCL_CD"].ToString();                                               //미수코드
                    m_UNCL_AMT = int.Parse(row["UNCL_AMT"].ToString());                                   //미수금액
                    m_SPCF_AMT_CLCL_DVCD = row["SPCF_AMT_CLCL_DVCD"].ToString();                                    //특정금액계산구분코드
                    m_CASH_RCPT_AMT = int.Parse(row["CASH_RCPT_AMT"].ToString());                              //현금수납금액

                    int.TryParse(row["GVRN_CLAM_AMT"].ToString(), out m_GVRN_CLAM_AMT);

                    return true;
                }
                else
                {
                    LogService.DebugLog(String.Format("Patient Bill Temp not found.({0})", pid));
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return false;
        }

        #endregion Method : Private Method
    }
}
