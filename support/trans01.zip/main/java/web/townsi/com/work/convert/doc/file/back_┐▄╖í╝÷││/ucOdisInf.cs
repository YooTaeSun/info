//********************************************************************
// Class 명 : ucOdisInf
// 역    할 : 환자의 상병을 표시한다.
// 작 성 자 : PGH
// 작 성 일 : 2017-09-29
//********************************************************************
using System;
using System.Data;
using System.Windows.Forms;

using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public partial class ucOdisInf : UserControl
    {
        #region Define : Member

        public string m_AsstTycd = String.Empty;

        private DataTable m_DtDis = new DataTable();

        #endregion  Define : Member

        #region Construction

        public ucOdisInf()
        {
            InitializeComponent();
        }

        #endregion Construction

        #region Screen Load

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode)
                return;

            InitializeControls();
            sprDiseaseInfo.ActiveSheet.ColumnHeader.Columns[3].Width = 340;
            sprDiseaseInfo.ActiveSheet.ColumnHeader.Columns[3].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

            Clear();

            this.sprDiseaseInfo.CellClick += sprDiseaseInfo_CellClick;
        }

        private void InitializeControls()
        {
            sprDiseaseInfo.ActiveSheet.ColumnHeader.Rows[0].Height = 23;
        }

        #endregion Screen Load

        #region Method : Public Method

        public void Clear()
        {
            sprDiseaseInfo.ClearNotDoEvents();
        }

        public void SetPatientIllness(string pid, int ptcmhsno, string payyn, int payclamamt)
        {
            try
            {
                string ValdDd = String.Empty;

                int nopyCount = 0;

                m_DtDis.Reset();

                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectORDISRRT_Receipt(), ref m_DtDis, pid, ptcmhsno.ToString()))
                {
                    LxMessage.ShowError("상병내역 조회 중 에러가 발생했습니다.");
                    return;
                }

                if (m_DtDis.Rows.Count > 0)
                {
                    sprDiseaseInfo.FillDataTag(m_DtDis);

                    foreach (DataRow row in m_DtDis.Rows)
                    {
                        //TODO 비급여상병체크로직구성
                        if (StringService.IsNotNull(OverallCodeList.GetColumnValue("CL_NOT_ILNS_CD", row["ILNS_CD"].ToString(), "LWRN_OVRL_CD").ToString()))
                        {
                            nopyCount++;
                        }

                        // 산정특례코드가 "V193"인 경우 종료일자 체크.
                        if (row["CFSC_CD"].ToString().Equals("V193"))
                        {
                            ValdDd = DBService.ExecuteScalar(SQL.PA.Sql.SelectPAPSDSMA_ValdDd(), pid, "1").ToString();

                            if (!string.IsNullOrWhiteSpace(ValdDd) && DateTimeService.IsDateTime(ValdDd) && DateTimeService.ConvertDateTime(ValdDd) < DateTimeService.ConvertDateTime(row["MDCR_DD"].ToString()))
                            {
                                LxMessage.Show("암등록 종료일자가 " + clsPACommon.ConvertDateFormat(2, ValdDd) + " 입니다. 재 등록이 필요한 환자입니다. ", "확인");
                            }
                        }
                    }

                    if (nopyCount == m_DtDis.Rows.Count && !m_AsstTycd.Equals("99"))
                    {
                        LxMessage.Show("비급여 상병만 존재하므로 유형보조를 보험100%로 변경해야 합니다.", "확인");
                    }

                }
                else
                {
                    //TODO 상병이 존재하지 않을 때 수납 불가
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        /// <summary>
        /// 환자의 상병테이블에서 산정특례코드 V252 or V352 or V100 를 찾는다.
        /// </summary>
        /// <returns></returns>
        public int FindCfscCdOfOrDisrRt()
        {
            int count = 0;
            foreach (DataRow row in m_DtDis.Rows)
            {
                if (row["CFSC_CD"].ToString().Equals("V252") || row["CFSC_CD"].ToString().Equals("V352") || row["CFSC_CD"].ToString().Equals("V100"))
                {
                    count++;
                }
            }

            return count;
        }

        /// <summary>
        /// 수납저장후 상병이 변경되었는지 확인한다.
        /// </summary>
        /// <returns></returns>
        public bool ComparePreToPost(string pid, int ptcmhsno)
        {
            try
            {
                int dtcount = m_DtDis.Rows.Count;
                int discount = DBService.ExecuteInteger(SQL.PA.Sql.SelectCountOfORDISRRT(), pid
                                                                           , ptcmhsno.ToString());

                foreach (DataRow row in m_DtDis.Rows)
                {

                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
            return true;
        }

        public bool SelectAdmsIlnsList(string pid, string ptcmhsno)
        {
            bool result = true;
            string msg = String.Empty;
            try
            {
                DataTable dt = new DataTable();
                sprDiseaseInfo.Clear();
                if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectORDISRRT_Receipt(), ref dt, pid
                                                                                          , ptcmhsno))
                {
                    if (dt.Rows.Count > 0)
                    {
                        sprDiseaseInfo.FillDataTag(dt);
                    }
                }
                else
                {
                    result = false;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                msg = "상병 조회 중 오류를 발생했습니다.\r\n" +
                      "Method : SelectIlnsList \r\n" +
                      "오류 메시지 : " + ex.Message;
                LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                result = false;
            }
            return result;
        }

        #endregion Method : Public Method

        #region Events

        void sprDiseaseInfo_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            ((LxSpread)sender).MultiCellSelectRowBackColor(e.Row);
        }

        #endregion
    }
}
