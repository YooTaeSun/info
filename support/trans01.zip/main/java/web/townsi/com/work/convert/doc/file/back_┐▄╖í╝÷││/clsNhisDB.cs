using System;
using System.Data;
using SQL = Lime.SqlPack.PA;

namespace Lime.Framework.BusinessService
{
    public class clsNhisDB
    {
        #region [ Message1 - Message2 ]

        public static bool SaveM1(clsNhisM1 m1, int UniqNo)
        {
            string sujinjajuminno = m1.sujinjaJuminNo;
            string operatorjuminno = m1.operatorJuminNo;

            if (sujinjajuminno.Length >= 7) sujinjajuminno = sujinjajuminno.Substring(0, 7) + "******";
            if (operatorjuminno.Length >= 7) operatorjuminno = operatorjuminno.Substring(0, 7) + "******";

            if (!DBService.ExecuteNonQuery(SQL.NhisSQL.InsertPANHM1MA(), UniqNo.ToString(),
                                                                         m1.PID,
                                                                         sujinjajuminno,
                                                                         m1.ykiho,
                                                                         m1.sujinjaJuminNm,
                                                                         m1.diagDt,
                                                                         m1.hiCardNo,
                                                                         m1.birthDay,
                                                                         m1.loginId,
                                                                         m1.password,
                                                                         m1.InputDate,
                                                                         m1.status,
                                                                         m1.msgType,
                                                                         m1.clientInfo,
                                                                         operatorjuminno,
                                                                         m1.pgmType,
                                                                         m1.version,
                                                                         m1.dsbldvcd,
                                                                         m1.dlwtdvcd,
                                                                         m1.rgstdt,
                                                                         m1.rgstrid,
                                                                         EncryptionService.Encoding(m1.sujinjaJuminNo),
                                                                         EncryptionService.Encoding(m1.operatorJuminNo)))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("SaveM1");
                return false;
            }
            return true;
        }

        public static DataTable SelectPANHM1MA()
        {
            DataTable ReturnTable = new DataTable();

            if (!DBService.ExecuteDataTable(SQL.NhisSQL.SelectPANHM1MA(), ref ReturnTable))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("SelectPANHM1MA");
            }

            return ReturnTable;
        }

        public static bool SaveM2(clsNhisM2 m2, string UniqNo)
        {
            string sujinjajuminno = m2.sujinjaJuminNo;
            string operatorjuminno = m2.operatorJuminNo;

            if (sujinjajuminno.Length >= 7) sujinjajuminno = sujinjajuminno.Substring(0, 7) + "******";
            if (operatorjuminno.Length >= 7) operatorjuminno = operatorjuminno.Substring(0, 7) + "******";

            if (!DBService.ExecuteNonQuery(SQL.NhisSQL.InsertPANHM2MA(), UniqNo,
                                                                         m2.PID,
                                                                         sujinjajuminno,
                                                                         m2.sujinjaJuminNm,
                                                                         m2.ykiho,
                                                                         m2.qlfType,
                                                                         m2.qlfChwidukDt,
                                                                         m2.sedaejuNm,
                                                                         m2.protAdminSym,
                                                                         m2.asylmSym,
                                                                         m2.payRestricDt,
                                                                         m2.sbrdnType,
                                                                         m2.cfhcRem,
                                                                         m2.ykiho1,
                                                                         m2.ykiho2,
                                                                         m2.ykiho3,
                                                                         m2.ykiho4,
                                                                         m2.yoyangNm1,
                                                                         m2.yoyangNm2,
                                                                         m2.yoyangNm3,
                                                                         m2.yoyangNm4,
                                                                         m2.dprtYn,
                                                                         m2.obstRegDt,
                                                                         m2.disRegPrson1,
                                                                         m2.disRegPrson2,
                                                                         m2.disRegPrson3,
                                                                         m2.disRegPrson4,
                                                                         m2.reqPatInfo,
                                                                         m2.pregRemAmt,
                                                                         m2.disRegPrson5,
                                                                         m2.disRegPrson6,
                                                                         m2.disRegPrson7,
                                                                         m2.dentTop,
                                                                         m2.dentBottom,
                                                                         m2.sangsilProcDt,
                                                                         m2.disRegPrson8,
                                                                         m2.qlfRestrictCd,
                                                                         m2.dentImpl1,
                                                                         m2.dentImpl2,
                                                                         m2.disRegPrson9,
                                                                         m2.obstYn,
                                                                         m2.diabetesCd,
                                                                         m2.disRegPrson10,
                                                                         m2.disRegPrson11,
                                                                         m2.preInfant,
                                                                         m2.disRegPrson12,
                                                                         m2.disRegPrson13,
                                                                         m2.disRegPrson14,
                                                                         m2.disRegPrson15,
                                                                         m2.disRegPrson16,
                                                                         m2.disRegPrson17,
                                                                         m2.InputDate,
                                                                         string.Empty,
                                                                         m2.messageCode,
                                                                         m2.message,
                                                                         m2.msgType,
                                                                         m2.clientInfo,
                                                                         operatorjuminno,
                                                                         m2.pgmType,
                                                                         m2.version,
                                                                         m2.disRegPrson18,
                                                                         m2.disRegPrson19,
                                                                         EncryptionService.Encoding(m2.sujinjaJuminNo),
                                                                         EncryptionService.Encoding(m2.operatorJuminNo),
                                                                         m2.ntntType,
                                                                         m2.mdcareHsptHsptzYn,
                                                                         m2.mdcareHsptAdminSym,
                                                                         m2.disRegPrson20))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("SaveM2");
                return false;
            }
            return true;
        }

        public static DataTable SelectPANHM2MA(string msgrequestkey)
        {
            DataTable ReturnTable = new DataTable();

            if (!DBService.ExecuteDataTable(SQL.NhisSQL.SelectPANHM2MA(), ref ReturnTable, msgrequestkey))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("SelectPANHM2MA");
            }

            return ReturnTable;
        }

        public static bool UpdateM1(string key, string hicardno)
        {
            if (!DBService.ExecuteNonQuery(SQL.NhisSQL.ComplatePANHM1MA(), key, hicardno))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("UpdateM1");
                return false;
            }
            return true;
        }

        //자격조회 요청 시, M1 테이블의 처리구분코드를 1로 업데이트한다.
        public static bool UpdateM1_1(string key)
        {
            if (!DBService.ExecuteNonQuery(SQL.NhisSQL.UpdatePANHM1MA_1(), key))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("UpdateM1_1");
                return false;
            }
            return true;
        }

        #endregion

        #region [ Message3 - Message4 ]

        public static bool SaveM3(clsNhisM3 m3, int UniqNo)
        {
            string sujinjajuminno = m3.sujinjaJuminNo;
            string operatorjuminno = m3.operatorJuminNo;

            if (sujinjajuminno.Length >= 7) sujinjajuminno = sujinjajuminno.Substring(0, 7) + "******";
            if (operatorjuminno.Length >= 7) operatorjuminno = operatorjuminno.Substring(0, 7) + "******";

            if (!DBService.ExecuteNonQuery(SQL.NhisSQL.InsertPANHM3MA(), m3.PID,
                                                                         UniqNo.ToString(), // RQST_SQNO,
                                                                         m3.OTPT_ADMS_YN,
                                                                         m3.PT_CMHS_NO,
                                                                         m3.RCPT_OCRR_UNIQ_NO,
                                                                         m3.ykiho,
                                                                         m3.diagType,
                                                                         m3.payDdCnt,
                                                                         m3.tuyakDdCnt,
                                                                         m3.selfPartBrdnAmt,
                                                                         m3.cfhcDmdAmt,
                                                                         m3.adminBrdnAmt,
                                                                         m3.mainSickSym,
                                                                         m3.diagDt,
                                                                         m3.piadmin,
                                                                         m3.prscGnoAdmin,
                                                                         m3.sbrdnType,
                                                                         m3.otherRequestYn,
                                                                         m3.cfhcCfrNo,
                                                                         m3.diagItem,
                                                                         m3.prscGnoYn,
                                                                         m3.diagOutCode,
                                                                         m3.pregSumAmt,
                                                                         m3.pregDmndAmt,
                                                                         m3.diagReqYkiho,
                                                                         m3.loginId,
                                                                         m3.password,
                                                                         m3.InputDate,
                                                                         m3.status,
                                                                         m3.msgType,
                                                                         m3.clientInfo,
                                                                         operatorjuminno,
                                                                         m3.pgmType,
                                                                         m3.version,
                                                                         sujinjajuminno,
                                                                         m3.sujinjaJuminNm,
                                                                         m3.DSBL_DVCD,
                                                                         DateTime.Now.ToString("yyyyMMddHHmmss"),
                                                                         EncryptionService.Encoding(m3.sujinjaJuminNo),
                                                                         EncryptionService.Encoding(m3.operatorJuminNo)))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("SaveM3");
                return false;
            }
            return true;
        }

        public static DataTable SelectPANHM3MA(string hptl_rgno_cd)
        {
            DataTable ReturnTable = new DataTable();

            if (!DBService.ExecuteDataTable(SQL.NhisSQL.SelectPANHM3MA(hptl_rgno_cd), ref ReturnTable))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("SelectPANHM3MA");
            }

            return ReturnTable;
        }

        public static bool SaveM4(clsNhisM4 m4, string UniqNo)
        {
            string sujinjajuminno = m4.sujinjaJuminNo;
            string operatorjuminno = m4.operatorJuminNo;

            if (sujinjajuminno.Length >= 7) sujinjajuminno = sujinjajuminno.Substring(0, 7) + "******";
            if (operatorjuminno.Length >= 7) operatorjuminno = operatorjuminno.Substring(0, 7) + "******";

            if (!DBService.ExecuteNonQuery(SQL.NhisSQL.InsertPANHM4MA(), m4.PID,
                                                                         UniqNo,
                                                                         m4.OTPT_ADMS_YN,
                                                                         m4.PT_CMHS_NO,
                                                                         m4.RCPT_OCRR_UNIQ_NO,
                                                                         m4.ykiho,
                                                                         m4.admType,
                                                                         m4.cfhcCfrNo,
                                                                         m4.selfPartBrdnAmt,
                                                                         m4.cfhcDmdAmt,
                                                                         m4.cfhcRem,
                                                                         m4.pregDmndAmt,
                                                                         m4.pregRemAmt,
                                                                         m4.InputDate,
                                                                         m4.PICKUP_FLAG,
                                                                         m4.messageCode,
                                                                         m4.message,
                                                                         m4.msgType,
                                                                         m4.clientInfo,
                                                                         operatorjuminno,
                                                                         m4.pgmType,
                                                                         m4.version,
                                                                         sujinjajuminno,
                                                                         m4.sujinjaJuminNm,
                                                                         m4.RCPT_SQNO,
                                                                         m4.diagDt,
                                                                         DateTime.Now.ToString("yyyyMMddHHmmss"),
                                                                         EncryptionService.Encoding(m4.sujinjaJuminNo),
                                                                         EncryptionService.Encoding(m4.operatorJuminNo)))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("SaveM4");
                return false;
            }
            return true;
        }

        public static bool UpdateM3(string PID, string key)
        {
            if (!DBService.ExecuteNonQuery(SQL.NhisSQL.ComplatePANHM3MA(), PID, key))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("UpdateM3");
                return false;
            }
            return true;
        }

        public static DataTable SelectPANHM4MA(string PID, string msgrequestkey)
        {
            DataTable ReturnTable = new DataTable();

            if (!DBService.ExecuteDataTable(SQL.NhisSQL.SelectPANHM4MA(), ref ReturnTable, PID, msgrequestkey))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("SelectPANHM4MA");
            }

            return ReturnTable;
        }

        public static bool Update_PAOBILBD_MDAD_PRMT_NO(string PID, string PT_CMHS_NO, string RCPT_SQNO, string MDAD_PRMT_NO)
        {
            if (!DBService.ExecuteNonQuery(SQL.NhisSQL.Update_PAOBILBD_MDAD_PRMT_NO(), PID, PT_CMHS_NO, RCPT_SQNO, MDAD_PRMT_NO))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("Update_PAOBILBD_MDAD_PRMT_NO");
                return false;
            }
            return true;
        }

        public static bool FailPANHM3MA(string PID, string RQST_SQNO)
        {
            if (!DBService.ExecuteNonQuery(SQL.NhisSQL.FailPANHM3MA(), PID, RQST_SQNO))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("FailPANHM3MA");
                return false;
            }
            return true;
        }

        #endregion

        #region [ Message5 - Message6 ]

        public static bool SaveM5(clsNhisM5 m5, int UniqNo)
        {
            string sujinjajuminno = m5.sujinjaJuminNo;
            string operatorjuminno = m5.operatorJuminNo;

            if (sujinjajuminno.Length >= 7) sujinjajuminno = sujinjajuminno.Substring(0, 7) + "******";
            if (operatorjuminno.Length >= 7) operatorjuminno = operatorjuminno.Substring(0, 7) + "******";

            if (!DBService.ExecuteNonQuery(SQL.NhisSQL.InsertPANHM5MA(), m5.PID,
                                                                         UniqNo.ToString(), // RQST_SQNO,
                                                                         m5.OTPT_ADMS_YN,
                                                                         m5.PT_CMHS_NO,
                                                                         m5.RCPT_OCRR_UNIQ_NO,
                                                                         m5.ykiho,
                                                                         m5.cfhcCfrNo,
                                                                         m5.diagDt,
                                                                         m5.loginId,
                                                                         m5.password,
                                                                         m5.InputDate,
                                                                         m5.status,
                                                                         m5.msgType,
                                                                         m5.clientInfo,
                                                                         operatorjuminno,
                                                                         m5.pgmType,
                                                                         m5.version,
                                                                         sujinjajuminno,
                                                                         m5.sujinjaJuminNm,
                                                                         m5.DSBL_DVCD,
                                                                         DateTime.Now.ToString("yyyyMMddHHmmss"),
                                                                         EncryptionService.Encoding(m5.sujinjaJuminNo),
                                                                         EncryptionService.Encoding(m5.operatorJuminNo)))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("SaveM5");
                return false;
            }
            return true;
        }

        public static DataTable SelectPANHM5MA(string hptl_rgno_cd)
        {
            DataTable ReturnTable = new DataTable();

            if (!DBService.ExecuteDataTable(SQL.NhisSQL.SelectPANHM5MA(hptl_rgno_cd), ref ReturnTable))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("SelectPANHM5MA");
            }

            return ReturnTable;
        }

        public static bool SaveM6(clsNhisM6 m6, string UniqNo)
        {
            string sujinjajuminno = m6.sujinjaJuminNo;
            string operatorjuminno = m6.operatorJuminNo;

            if (sujinjajuminno.Length >= 7) sujinjajuminno = sujinjajuminno.Substring(0, 7) + "******";
            if (operatorjuminno.Length >= 7) operatorjuminno = operatorjuminno.Substring(0, 7) + "******";

            if (!DBService.ExecuteNonQuery(SQL.NhisSQL.InsertPANHM6MA(), m6.PID,
                                                                         UniqNo, // RQST_SQNO,
                                                                         m6.OTPT_ADMS_YN,
                                                                         m6.PT_CMHS_NO,
                                                                         m6.RCPT_OCRR_UNIQ_NO,
                                                                         m6.ykiho,
                                                                         m6.cnclType,
                                                                         m6.cfhcCfrNo,
                                                                         m6.cfhcRem,
                                                                         m6.pregRemAmt,
                                                                         m6.InputDate,
                                                                         m6.PICKUP_FLAG,
                                                                         m6.messageCode,
                                                                         m6.message,
                                                                         m6.msgType,
                                                                         m6.clientInfo,
                                                                         operatorjuminno,
                                                                         m6.pgmType,
                                                                         m6.version,
                                                                         sujinjajuminno,
                                                                         m6.sujinjaJuminNm,
                                                                         DateTime.Now.ToString("yyyyMMddHHmmss"),
                                                                         EncryptionService.Encoding(m6.sujinjaJuminNo),
                                                                         EncryptionService.Encoding(m6.operatorJuminNo)))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("SaveM6");
                return false;
            }
            return true;
        }

        public static bool UpdateM5(string PID, string key)
        {
            if (!DBService.ExecuteNonQuery(SQL.NhisSQL.ComplatePANHM5MA(), PID, key))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("UpdateM5");
                return false;
            }
            return true;
        }

        public static bool FailPANHM5MA(string PID, string RQST_SQNO)
        {
            if (!DBService.ExecuteNonQuery(SQL.NhisSQL.FailPANHM5MA(), PID, RQST_SQNO))
            {
                LogService.ErrorLog(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.Debug_WriteLine(string.Format("{0}\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                CL_CommonClass.StackTrace_CL("FailPANHM5MA");
                return false;
            }
            return true;
        }

        #endregion
    }
}