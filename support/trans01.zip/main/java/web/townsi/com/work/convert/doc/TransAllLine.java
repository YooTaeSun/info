package web.townsi.com.work.convert.doc;

import org.json.simple.JSONObject;

import web.townsi.com.utils.Util;

public class TransAllLine {

	public static StringBuilder contentSb = null;
	public static String strOfLine = "<rEaDlInE>";
	
	public static String convertAllLine(JSONObject jsonObject, String content) {
		content = content.replaceAll("\r\n", strOfLine);
		String reContent =  chgGetSetObj2(jsonObject, content);
		content = contentSb.toString() + reContent;
		content = content.replaceAll(strOfLine, "\r\n");
		return content;
	}
	
	public static String chgGetSetObj2(JSONObject jsonObject, String content) {
		
		JSONObject val = null;
		String idNew = "";
		String key = "";
	    for (Object keyObj : jsonObject.keySet()) {
	    	key = (String)keyObj;
	    	val = (JSONObject) jsonObject.get(key);
	    	idNew = (String) val.get("id_new");
	        try {
	        	content = Util.replaceOld(content, idNew, key);
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("e jsonObject key 이상 >> " + e);
			}
	    }
		return content;
	}
}