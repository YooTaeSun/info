//package web.townsi.com.work.tibero01.ddl.biz;
//
//import java.util.HashMap;
//import java.util.List;
//
//public interface Tibero01Biz {
//
////	public HashMap selectTableList(HashMap params);
//	public HashMap selectTableCountList(HashMap params);
//	public HashMap dropCreateTable(HashMap params);
//	public HashMap deleteTable(HashMap params);
//	public int dropTable(HashMap params);
//	public HashMap createTable(HashMap params);
//	
//	public List<HashMap> selectTableInfo(HashMap params, String dbName, String owner, String tableName);
//	
//	public HashMap copyData(HashMap params);
//	
//}