// *******************************************************
// Class 명 : clsOutReceiptBreakDown
// 역    할 : 외래수납처방내역 (PAORECBD)
// 작 성 자 : PGH
// 작 성 일 : 2017-09-14
// *******************************************************

<script setup lang="ts">
import { ref, reactive, onMounted, defineExpose, computed, getCurrentInstance } from "vue";
import { $ref, $computed } from 'vue/macros'
import { DataTable } from "@/app/framework/DataType/DataTable";
import { DBService } from "@/app/framework/DBService/DBService";
import { LogService } from "@/app/framework/CommonService/LogService";
import { Int } from "@/app/utils/Int";
import { clsOutReceiptBreakDown } from "@/modules/n_pa/views/CommonClass/clsOutReceiptBreakDown";
import { usePopup } from "@/app/utils/usePopup";
import { useBasePopUp_TP } from "@/app/framework/BaseForms/BasePopUp_TP";
import PopupTemplate from "@/app/components/Popup/PopupTemplate.vue";

/* Life Cycles */
onMounted(() => {
  instance.value = getCurrentInstance();
  Caption.value = '제목';
  ClientSize.value = { width: 1238, height: 1000 };
  InitializeComponent();
  OnLoad();
});
let m_DialogResult = DialogResult.OK;
let { Caption, ClientSize } = useBasePopUp_TP();

const instance = ref(null);
//클로즈만 할때
const ClosePopup = () => {
  //셀 더블 클릭하지 않고 폼 닫을 때,
  const { hidePopup } = usePopup();
  hidePopup(instance.value, DialogResult.Cancel);
};

const Close = () => {
  //셀 더블 클릭하지 않고 폼 닫을 때,
  const { hidePopup } = usePopup();
  hidePopup(instance.value, m_DialogResult);
};

const ShowDialog = async () => {
  const { showPopup } = usePopup();
  return await showPopup(instance.value);
};

const getKey = () => {
  if (instance.value) {
    return instance.value.uid;
  }
  return "";
};


const InitializeComponent = () => {
}


    
        // #region Define Member Property

        let m_PID:string = String.Empty;    //환자등록번호                     VARCHAR2(10)
        let m_PT_CMHS_NO:number = 0;               //환자내원번호                     NUMBER(10, 0)
        let m_RCPT_SQNO:number = 0;               //수납일련번호                     NUMBER(5, 0)
        let m_APLY_SQNO:number = 0;               //적용일련번호                     NUMBER(3, 0)
        let m_PRSC_SQNO:number = 0;               //처방일련번호                     NUMBER(5, 0)
        let m_MDCR_DD:string = String.Empty;    //진료일자                         VARCHAR2(8)
        let m_ACTG_DD:string = String.Empty;    //시행일자                         VARCHAR2(8)
        let m_CLAM_CRTN_YN:string = String.Empty;    //청구생성여부                     VARCHAR2(1)
        let m_REAL_PRDC_CD:string = String.Empty;    //실제처방의코드                   VARCHAR2(10)
        let m_PRSC_DVCD:string = String.Empty;    //처방구분코드                     VARCHAR2(2)
        let m_BNDL_PRSC_SQNO:number = 0;               //묶음처방일련번호                 NUMBER(3, 0)
        let m_BNDL_MEFE_CD:string = String.Empty;    //묶음수가코드                     VARCHAR2(10)
        let m_MEFE_CD:string = String.Empty;    //수가코드                         VARCHAR2(10)
        let m_MEFE_NM:string = String.Empty;    //수가명                           VARCHAR2(200)
        let m_EDI_CD:string = String.Empty;    //EDI코드                          VARCHAR2(10)
        let m_PRFT_CD:string = String.Empty;    //수익코드                         VARCHAR2(10)
        let m_ONTM_QTY:number = 0;               //1회수량                          NUMBER(10, 4)
        let m_NOTM:number = 0;               //횟수                             NUMBER(3, 0)
        let m_NODY:number = 0;               //일수                             NUMBER(3, 0)
        let m_AOMD_MTHD_CD:string = String.Empty;    //투여방법코드                     VARCHAR2(10)
        let m_OUPR_GRNT_NO:string = String.Empty;    //원외처방교부번호                 VARCHAR2(13)
        let m_EXCP_RESN_CD:string = String.Empty;    //예외사유코드                     VARCHAR2(2)
        let m_DLVR_DEPT_CD:string = String.Empty;    //전달부서코드                     VARCHAR2(10)
        let m_ACTG_DEPT_CD:string = String.Empty;    //시행부서코드                     VARCHAR2(10)
        let m_CLCL_DVCD:string = String.Empty;    //계산구분코드                     VARCHAR2(2)
        let m_ACTN_MATL_DVCD:string = String.Empty;    //행위재료구분코드                 VARCHAR2(2)
        let m_CLUS_DVCD:string = String.Empty;    //항구분코드                       VARCHAR2(2)
        let m_SBIT_DVCD:string = String.Empty;    //목구분코드                       VARCHAR2(2)
        let m_MEFE_DVCD:string = String.Empty;    //수가구분코드                     VARCHAR2(2)
        let m_PAY_NOPY_DVCD:string = String.Empty;    //급여비급여구분코드               VARCHAR2(2)
        let m_SCNG_PAY_CD:string = String.Empty;    //선별급여코드                     VARCHAR2(10)
        let m_CNFR_DVCD:string = String.Empty;    //확인구분코드                     VARCHAR2(2)
        let m_CNFR_CD:string = String.Empty;    //확인코드                         VARCHAR2(30)
        let m_CMPT_CD:string = String.Empty;    //산정코드                         VARCHAR2(4)
        let m_TIME_ADTN_DVCD:string = String.Empty;    //시간가산구분코드                 VARCHAR2(10)
        let m_VTRN_PT_YN:string = String.Empty;    //보훈환자여부                     VARCHAR2(1)
        let m_UNPR:number = 0;               //단가                             NUMBER(10, 0)
        let m_ADTN_CMPT_AMT:number = 0;               //가산산정금액                     NUMBER(10, 0)
        let m_BYKN_ADTN_AMT:number = 0;               //종별가산금액                     NUMBER(10, 0)
        let m_SMCR_AMT:number = 0;               //선택진료금액                     NUMBER(10, 0)
        let m_CLCL_AMT:number = 0;               //계산금액                         NUMBER(10, 0)
        let m_ORIG_CLCL_AMT:number = 0;               //원계산금액                       NUMBER(10, 0)
        let m_ADED_VALU_TAX_AMT:number = 0;               //부가가치세금액                   NUMBER(10, 0)
        let m_PAY_USCH_AMT:number = 0;               //급여본인부담금액                 NUMBER(10, 0)
        let m_PAY_CLAM_AMT:number = 0;               //급여청구금액                     NUMBER(10, 0)
        let m_SCNG_PAY_USCH_AMT:number = 0;               //선별급여본인부담금액             NUMBER(10, 0)
        let m_SCNG_PAY_CLAM_AMT:number = 0;               //선별급여청구금액                 NUMBER(10, 0)
        let m_VTRN_TAMT:number = 0;               //보훈총금액                       NUMBER(10, 0)
        let m_DCNT_AMT:number = 0;               //할인금액                         NUMBER(10, 0)
        let m_ADTN_APLY_TIME:string = String.Empty;    //가산적용시간                     VARCHAR2(4)
        let m_CMPT_DLWT_DVCD_1:string = String.Empty;    //산정처리구분코드첫째             VARCHAR2(10)
        let m_CMPT_DLWT_DVCD_2:string = String.Empty;    //산정처리구분코드둘째             VARCHAR2(10)
        let m_CMPT_DLWT_DVCD_3:string = String.Empty;    //산정처리구분코드셋째             VARCHAR2(10)
        let m_CMPT_DLWT_DVCD_4:string = String.Empty;    //산정처리구분코드넷째             VARCHAR2(10)
        let m_CNVR_PNT:number = 0;               //환산점수                         NUMBER(10, 2)
        let m_GRP_UNPR_APLY_YN:string = String.Empty;    //그룹단가적용여부                 VARCHAR2(1)
        let m_DNFR_RGUP_CNTS:string = String.Empty;    //치식우위내용                     VARCHAR2(8)
        let m_DNFR_LFUP_CNTS:string = String.Empty;    //치식좌위내용                     VARCHAR2(8)
        let m_DNFR_RGHT_LOW_CNTS:string = String.Empty;    //치식우하내용                     VARCHAR2(8)
        let m_DNFR_LEFT_LOW_CNTS:string = String.Empty;    //치식좌하내용                     VARCHAR2(8)
        let m_HPMD_CLCL_DVCD:string = String.Empty;    //고가약제계산구분코드             VARCHAR2(10)
        let m_HPMD_CLCL_QTY:number = 0;               //고가약제계산수량                 NUMBER(10, 4)
        let m_ENTS_ENTD_DVCD:string = String.Empty;    //위탁수탁구분코드                 VARCHAR2(2)
        let m_ENTS_ENTD_INSTNO:string = String.Empty;    //위탁수탁기관기호                 VARCHAR2(10)
        let m_SLCT_MCFE:number = 0;               //선택진료료                       NUMBER(10, 0)
        let m_SMCR_RATE:number = 0;               //선택진료율                       NUMBER(7, 2)
        let m_FXAM_INCL_YN:string = String.Empty;    //정액포함여부                     VARCHAR2(1)
        let m_TOTL_AOMD_QTY:number = 0;               //총투여수량                       NUMBER(10, 4)
        let m_ORMD_ANS_DVCD:string = String.Empty;    //한방가감구분코드                 VARCHAR2(2)
        let m_ORMD_ANS_ORIG_DVCD:string = String.Empty;    //한방가감원구분코드               VARCHAR2(10)
        let m_ORMD_ANS_ORIG_CD:string = String.Empty;    //한방가감원코드                   VARCHAR2(10)
        let m_ORMD_SITE_DVCD:string = String.Empty;    //한방부위구분코드                 VARCHAR2(2)
        let m_ORMD_SITE_CD:string = String.Empty;    //한방부위코드                     VARCHAR2(10)
        let m_MDCN_UPLM_AMT:number = 0;               //약제상한금액                     NUMBER(10, 0)
        let m_MDCN_UPLM_DIAM:number = 0;               //약제상한차액                     NUMBER(10, 0)
        let m_ORIG_PRSC_SQNO:number = 0;               //원처방일련번호                   NUMBER(5, 0)
        let m_ORIG_SQNO:number = 0;               //원일련번호                       NUMBER(3, 0)
        let m_PCLR_MATR:string = String.Empty;    //특이사항                         VARCHAR2(200)
        let m_AFRS_STAT_DVCD:string = String.Empty;    //업무상태구분코드                 VARCHAR2(2)
        let m_ROW_STAT_DVCD:string = String.Empty;    //행상태구분코드                   VARCHAR2(2)
        let m_RGST_DT:string = String.Empty;    //등록일시                         VARCHAR2(14)
        let m_RGSTR_ID:string = String.Empty;    //등록자ID                         VARCHAR2(10)
        let m_NEW_RCPT_RQNO:number = 0;               //새로운 수납일련번호
        let m_NEW_ROW_STAT_DVCD:string = String.Empty;

        let m_STATVAL1:number = 1;             //행상태구분에 따른 값 ROW_STAT_DVCD = 'D' -> -1, ROW_STAT_DVCD = 'A' -> 1, ROW_STAT_DVCD = 'F' -> 0
        let m_STATVAL2:number = 1;             // 0, -1, 1
        let m_CLUR_DSBL_DVCD:string = String.Empty;   // 장루요루구분코드 1 : YES, 0 : NO

        let m_DtPrsc:DataTable = new DataTable();

        const PID = $computed({
          get()  { return m_PID; }, 
          set(value: any)  { m_PID = value; }
        });
        const PT_CMHS_NO = $computed({
          get()  { return m_PT_CMHS_NO; }, 
          set(value: any)  { m_PT_CMHS_NO = value; }
        });
        const RCPT_SQNO = $computed({
          get()  { return m_RCPT_SQNO; }, 
          set(value: any)  { m_RCPT_SQNO = value; }
        });
        const APLY_SQNO = $computed({
          get()  { return m_APLY_SQNO; }, 
          set(value: any)  { m_APLY_SQNO = value; }
        });
        const PRSC_SQNO = $computed({
          get()  { return m_PRSC_SQNO; }, 
          set(value: any)  { m_PRSC_SQNO = value; }
        });
        const MDCR_DD = $computed({
          get()  { return m_MDCR_DD; }, 
          set(value: any)  { m_MDCR_DD = value; }
        });
        const ACTG_DD = $computed({
          get()  { return m_ACTG_DD; }, 
          set(value: any)  { m_ACTG_DD = value; }
        });
        const CLAM_CRTN_YN = $computed({
          get()  { return m_CLAM_CRTN_YN; }, 
          set(value: any)  { m_CLAM_CRTN_YN = value; }
        });
        const REAL_PRDC_CD = $computed({
          get()  { return m_REAL_PRDC_CD; }, 
          set(value: any)  { m_REAL_PRDC_CD = value; }
        });
        const PRSC_DVCD = $computed({
          get()  { return m_PRSC_DVCD; }, 
          set(value: any)  { m_PRSC_DVCD = value; }
        });
        const BNDL_PRSC_SQNO = $computed({
          get()  { return m_BNDL_PRSC_SQNO; }, 
          set(value: any)  { m_BNDL_PRSC_SQNO = value; }
        });
        const BNDL_MEFE_CD = $computed({
          get()  { return m_BNDL_MEFE_CD; }, 
          set(value: any)  { m_BNDL_MEFE_CD = value; }
        });
        const MEFE_CD = $computed({
          get()  { return m_MEFE_CD; }, 
          set(value: any)  { m_MEFE_CD = value; }
        });
        const MEFE_NM = $computed({
          get()  { return m_MEFE_NM; }, 
          set(value: any)  { m_MEFE_NM = value; }
        });
        const EDI_CD = $computed({
          get()  { return m_EDI_CD; }, 
          set(value: any)  { m_EDI_CD = value; }
        });
        const PRFT_CD = $computed({
          get()  { return m_PRFT_CD; }, 
          set(value: any)  { m_PRFT_CD = value; }
        });
        const ONTM_QTY = $computed({
          get()  { return m_ONTM_QTY; }, 
          set(value: any)  { m_ONTM_QTY = value; }
        });
        const NOTM = $computed({
          get()  { return m_NOTM; }, 
          set(value: any)  { m_NOTM = value; }
        });
        const NODY = $computed({
          get()  { return m_NODY; }, 
          set(value: any)  { m_NODY = value; }
        });
        const AOMD_MTHD_CD = $computed({
          get()  { return m_AOMD_MTHD_CD; }, 
          set(value: any)  { m_AOMD_MTHD_CD = value; }
        });
        const OUPR_GRNT_NO = $computed({
          get()  { return m_OUPR_GRNT_NO; }, 
          set(value: any)  { m_OUPR_GRNT_NO = value; }
        });
        const EXCP_RESN_CD = $computed({
          get()  { return m_EXCP_RESN_CD; }, 
          set(value: any)  { m_EXCP_RESN_CD = value; }
        });
        const DLVR_DEPT_CD = $computed({
          get()  { return m_DLVR_DEPT_CD; }, 
          set(value: any)  { m_DLVR_DEPT_CD = value; }
        });
        const ACTG_DEPT_CD = $computed({
          get()  { return m_ACTG_DEPT_CD; }, 
          set(value: any)  { m_ACTG_DEPT_CD = value; }
        });
        const CLCL_DVCD = $computed({
          get()  { return m_CLCL_DVCD; }, 
          set(value: any)  { m_CLCL_DVCD = value; }
        });
        const ACTN_MATL_DVCD = $computed({
          get()  { return m_ACTN_MATL_DVCD; }, 
          set(value: any)  { m_ACTN_MATL_DVCD = value; }
        });
        const CLUS_DVCD = $computed({
          get()  { return m_CLUS_DVCD; }, 
          set(value: any)  { m_CLUS_DVCD = value; }
        });
        const SBIT_DVCD = $computed({
          get()  { return m_SBIT_DVCD; }, 
          set(value: any)  { m_SBIT_DVCD = value; }
        });
        const MEFE_DVCD = $computed({
          get()  { return m_MEFE_DVCD; }, 
          set(value: any)  { m_MEFE_DVCD = value; }
        });
        const PAY_NOPY_DVCD = $computed({
          get()  { return m_PAY_NOPY_DVCD; }, 
          set(value: any)  { m_PAY_NOPY_DVCD = value; }
        });
        const SCNG_PAY_CD = $computed({
          get()  { return m_SCNG_PAY_CD; }, 
          set(value: any)  { m_SCNG_PAY_CD = value; }
        });
        const CNFR_DVCD = $computed({
          get()  { return m_CNFR_DVCD; }, 
          set(value: any)  { m_CNFR_DVCD = value; }
        });
        const CNFR_CD = $computed({
          get()  { return m_CNFR_CD; }, 
          set(value: any)  { m_CNFR_CD = value; }
        });
        const CMPT_CD = $computed({
          get()  { return m_CMPT_CD; }, 
          set(value: any)  { m_CMPT_CD = value; }
        });
        const TIME_ADTN_DVCD = $computed({
          get()  { return m_TIME_ADTN_DVCD; }, 
          set(value: any)  { m_TIME_ADTN_DVCD = value; }
        });
        const VTRN_PT_YN = $computed({
          get()  { return m_VTRN_PT_YN; }, 
          set(value: any)  { m_VTRN_PT_YN = value; }
        });
        const UNPR = $computed({
          get()  { return m_UNPR; }, 
          set(value: any)  { m_UNPR = value; }
        });
        const ADTN_CMPT_AMT = $computed({
          get()  { return m_ADTN_CMPT_AMT; }, 
          set(value: any)  { m_ADTN_CMPT_AMT = value; }
        });
        const BYKN_ADTN_AMT = $computed({
          get()  { return m_BYKN_ADTN_AMT; }, 
          set(value: any)  { m_BYKN_ADTN_AMT = value; }
        });
        const SMCR_AMT = $computed({
          get()  { return m_SMCR_AMT; }, 
          set(value: any)  { m_SMCR_AMT = value; }
        });
        const CLCL_AMT = $computed({
          get()  { return m_CLCL_AMT; }, 
          set(value: any)  { m_CLCL_AMT = value; }
        });
        const ORIG_CLCL_AMT = $computed({
          get()  { return m_ORIG_CLCL_AMT; }, 
          set(value: any)  { m_ORIG_CLCL_AMT = value; }
        });
        const ADED_VALU_TAX_AMT = $computed({
          get()  { return m_ADED_VALU_TAX_AMT; }, 
          set(value: any)  { m_ADED_VALU_TAX_AMT = value; }
        });
        const PAY_USCH_AMT = $computed({
          get()  { return m_PAY_USCH_AMT; }, 
          set(value: any)  { m_PAY_USCH_AMT = value; }
        });
        const PAY_CLAM_AMT = $computed({
          get()  { return m_PAY_CLAM_AMT; }, 
          set(value: any)  { m_PAY_CLAM_AMT = value; }
        });
        const SCNG_PAY_USCH_AMT = $computed({
          get()  { return m_SCNG_PAY_USCH_AMT; }, 
          set(value: any)  { m_SCNG_PAY_USCH_AMT = value; }
        });
        const SCNG_PAY_CLAM_AMT = $computed({
          get()  { return m_SCNG_PAY_CLAM_AMT; }, 
          set(value: any)  { m_SCNG_PAY_CLAM_AMT = value; }
        });
        const VTRN_TAMT = $computed({
          get()  { return m_VTRN_TAMT; }, 
          set(value: any)  { m_VTRN_TAMT = value; }
        });
        const DCNT_AMT = $computed({
          get()  { return m_DCNT_AMT; }, 
          set(value: any)  { m_DCNT_AMT = value; }
        });
        const ADTN_APLY_TIME = $computed({
          get()  { return m_ADTN_APLY_TIME; }, 
          set(value: any)  { m_ADTN_APLY_TIME = value; }
        });
        const CMPT_DLWT_DVCD_1 = $computed({
          get()  { return m_CMPT_DLWT_DVCD_1; }, 
          set(value: any)  { m_CMPT_DLWT_DVCD_1 = value; }
        });
        const CMPT_DLWT_DVCD_2 = $computed({
          get()  { return m_CMPT_DLWT_DVCD_2; }, 
          set(value: any)  { m_CMPT_DLWT_DVCD_2 = value; }
        });
        const CMPT_DLWT_DVCD_3 = $computed({
          get()  { return m_CMPT_DLWT_DVCD_3; }, 
          set(value: any)  { m_CMPT_DLWT_DVCD_3 = value; }
        });
        const CMPT_DLWT_DVCD_4 = $computed({
          get()  { return m_CMPT_DLWT_DVCD_4; }, 
          set(value: any)  { m_CMPT_DLWT_DVCD_4 = value; }
        });
        const CNVR_PNT = $computed({
          get()  { return m_CNVR_PNT; }, 
          set(value: any)  { m_CNVR_PNT = value; }
        });
        const GRP_UNPR_APLY_YN = $computed({
          get()  { return m_GRP_UNPR_APLY_YN; }, 
          set(value: any)  { m_GRP_UNPR_APLY_YN = value; }
        });
        const DNFR_RGUP_CNTS = $computed({
          get()  { return m_DNFR_RGUP_CNTS; }, 
          set(value: any)  { m_DNFR_RGUP_CNTS = value; }
        });
        const DNFR_LFUP_CNTS = $computed({
          get()  { return m_DNFR_LFUP_CNTS; }, 
          set(value: any)  { m_DNFR_LFUP_CNTS = value; }
        });
        const DNFR_RGHT_LOW_CNTS = $computed({
          get()  { return m_DNFR_RGHT_LOW_CNTS; }, 
          set(value: any)  { m_DNFR_RGHT_LOW_CNTS = value; }
        });
        const DNFR_LEFT_LOW_CNTS = $computed({
          get()  { return m_DNFR_LEFT_LOW_CNTS; }, 
          set(value: any)  { m_DNFR_LEFT_LOW_CNTS = value; }
        });
        const HPMD_CLCL_DVCD = $computed({
          get()  { return m_HPMD_CLCL_DVCD; }, 
          set(value: any)  { m_HPMD_CLCL_DVCD = value; }
        });
        const HPMD_CLCL_QTY = $computed({
          get()  { return m_HPMD_CLCL_QTY; }, 
          set(value: any)  { m_HPMD_CLCL_QTY = value; }
        });
        const ENTS_ENTD_DVCD = $computed({
          get()  { return m_ENTS_ENTD_DVCD; }, 
          set(value: any)  { m_ENTS_ENTD_DVCD = value; }
        });
        const ENTS_ENTD_INSTNO = $computed({
          get()  { return m_ENTS_ENTD_INSTNO; }, 
          set(value: any)  { m_ENTS_ENTD_INSTNO = value; }
        });
        const SLCT_MCFE = $computed({
          get()  { return m_SLCT_MCFE; }, 
          set(value: any)  { m_SLCT_MCFE = value; }
        });
        const SMCR_RATE = $computed({
          get()  { return m_SMCR_RATE; }, 
          set(value: any)  { m_SMCR_RATE = value; }
        });
        const FXAM_INCL_YN = $computed({
          get()  { return m_FXAM_INCL_YN; }, 
          set(value: any)  { m_FXAM_INCL_YN = value; }
        });
        const TOTL_AOMD_QTY = $computed({
          get()  { return m_TOTL_AOMD_QTY; }, 
          set(value: any)  { m_TOTL_AOMD_QTY = value; }
        });
        const ORMD_ANS_DVCD = $computed({
          get()  { return m_ORMD_ANS_DVCD; }, 
          set(value: any)  { m_ORMD_ANS_DVCD = value; }
        });
        const ORMD_ANS_ORIG_DVCD = $computed({
          get()  { return m_ORMD_ANS_ORIG_DVCD; }, 
          set(value: any)  { m_ORMD_ANS_ORIG_DVCD = value; }
        });
        const ORMD_ANS_ORIG_CD = $computed({
          get()  { return m_ORMD_ANS_ORIG_CD; }, 
          set(value: any)  { m_ORMD_ANS_ORIG_CD = value; }
        });
        const ORMD_SITE_DVCD = $computed({
          get()  { return m_ORMD_SITE_DVCD; }, 
          set(value: any)  { m_ORMD_SITE_DVCD = value; }
        });
        const ORMD_SITE_CD = $computed({
          get()  { return m_ORMD_SITE_CD; }, 
          set(value: any)  { m_ORMD_SITE_CD = value; }
        });
        const MDCN_UPLM_AMT = $computed({
          get()  { return m_MDCN_UPLM_AMT; }, 
          set(value: any)  { m_MDCN_UPLM_AMT = value; }
        });
        const MDCN_UPLM_DIAM = $computed({
          get()  { return m_MDCN_UPLM_DIAM; }, 
          set(value: any)  { m_MDCN_UPLM_DIAM = value; }
        });
        const ORIG_PRSC_SQNO = $computed({
          get()  { return m_ORIG_PRSC_SQNO; }, 
          set(value: any)  { m_ORIG_PRSC_SQNO = value; }
        });
        const ORIG_SQNO = $computed({
          get()  { return m_ORIG_SQNO; }, 
          set(value: any)  { m_ORIG_SQNO = value; }
        });
        const PCLR_MATR = $computed({
          get()  { return m_PCLR_MATR; }, 
          set(value: any)  { m_PCLR_MATR = value; }
        });
        const AFRS_STAT_DVCD = $computed({
          get()  { return m_AFRS_STAT_DVCD; }, 
          set(value: any)  { m_AFRS_STAT_DVCD = value; }
        });
        const ROW_STAT_DVCD = $computed({
          get()  { return m_ROW_STAT_DVCD; }, 
          set(value: any)  { m_ROW_STAT_DVCD = value; }
        });
        const RGST_DT = $computed({
          get()  { return m_RGST_DT; }, 
          set(value: any)  { m_RGST_DT = value; }
        });
        const RGSTR_ID = $computed({
          get()  { return m_RGSTR_ID; }, 
          set(value: any)  { m_RGSTR_ID = value; }
        });

        const NEW_RCPT_RQNO = $computed({
          get()  { return m_NEW_RCPT_RQNO++; }, 
          set(value: any)  { m_NEW_RCPT_RQNO = value; }
        });
        const NEW_ROW_STAT_DVCD = $computed({
          get()  { return m_NEW_ROW_STAT_DVCD; }, 
          set(value: any)  { m_NEW_ROW_STAT_DVCD = value; }
        });

        const STATVAL1 = $computed({
          get()  { return m_STATVAL1; }, 
          set(value: any)  { m_STATVAL1 = value; }
        });
        const STATVAL2 = $computed({
          get()  { return m_STATVAL2; }, 
          set(value: any)  { m_STATVAL2 = value; }
        });
        const CLUR_DSBL_DVCD = $computed({
          get()  { return m_CLUR_DSBL_DVCD; }, 
          set(value: any)  { m_CLUR_DSBL_DVCD = value; }
        });

        const DtPrsc = $computed({
          get()  { return m_DtPrsc; }, 
          set(value: any)  { m_DtPrsc = value; }
        });
        // #endregion

        // #region Constructor

        constructor()
        {
            Clear();
        }

        // #endregion

        // #region Method General

        const Clear = () => 
        {
            m_PID = String.Empty;
            m_PT_CMHS_NO = 0;
            m_RCPT_SQNO = 0;
            m_APLY_SQNO = 0;
            m_PRSC_SQNO = 0;
            m_MDCR_DD = String.Empty;
            m_ACTG_DD = String.Empty;
            m_CLAM_CRTN_YN = String.Empty;
            m_REAL_PRDC_CD = String.Empty;
            m_PRSC_DVCD = String.Empty;
            m_BNDL_PRSC_SQNO = 0;
            m_BNDL_MEFE_CD = String.Empty;
            m_MEFE_CD = String.Empty;
            m_MEFE_NM = String.Empty;
            m_EDI_CD = String.Empty;
            m_PRFT_CD = String.Empty;
            m_ONTM_QTY = 0;
            m_NOTM = 0;
            m_NODY = 0;
            m_AOMD_MTHD_CD = String.Empty;
            m_OUPR_GRNT_NO = String.Empty;
            m_EXCP_RESN_CD = String.Empty;
            m_DLVR_DEPT_CD = String.Empty;
            m_ACTG_DEPT_CD = String.Empty;
            m_CLCL_DVCD = String.Empty;
            m_ACTN_MATL_DVCD = String.Empty;
            m_CLUS_DVCD = String.Empty;
            m_SBIT_DVCD = String.Empty;
            m_MEFE_DVCD = String.Empty;
            m_PAY_NOPY_DVCD = String.Empty;
            m_SCNG_PAY_CD = String.Empty;
            m_CNFR_DVCD = String.Empty;
            m_CNFR_CD = String.Empty;
            m_CMPT_CD = String.Empty;
            m_TIME_ADTN_DVCD = String.Empty;
            m_VTRN_PT_YN = String.Empty;
            m_UNPR = 0;
            m_ADTN_CMPT_AMT = 0;
            m_BYKN_ADTN_AMT = 0;
            m_SMCR_AMT = 0;
            m_CLCL_AMT = 0;
            m_ORIG_CLCL_AMT = 0;
            m_ADED_VALU_TAX_AMT = 0;
            m_PAY_USCH_AMT = 0;
            m_PAY_CLAM_AMT = 0;
            m_SCNG_PAY_USCH_AMT = 0;
            m_SCNG_PAY_CLAM_AMT = 0;
            m_VTRN_TAMT = 0;
            m_DCNT_AMT = 0;
            m_ADTN_APLY_TIME = String.Empty;
            m_CMPT_DLWT_DVCD_1 = String.Empty;
            m_CMPT_DLWT_DVCD_2 = String.Empty;
            m_CMPT_DLWT_DVCD_3 = String.Empty;
            m_CMPT_DLWT_DVCD_4 = String.Empty;
            m_CNVR_PNT = 0;
            m_GRP_UNPR_APLY_YN = String.Empty;
            m_DNFR_RGUP_CNTS = String.Empty;
            m_DNFR_LFUP_CNTS = String.Empty;
            m_DNFR_RGHT_LOW_CNTS = String.Empty;
            m_DNFR_LEFT_LOW_CNTS = String.Empty;
            m_HPMD_CLCL_DVCD = String.Empty;
            m_HPMD_CLCL_QTY = 0;
            m_ENTS_ENTD_DVCD = String.Empty;
            m_ENTS_ENTD_INSTNO = String.Empty;
            m_SLCT_MCFE = 0;
            m_SMCR_RATE = 0;
            m_FXAM_INCL_YN = String.Empty;
            m_TOTL_AOMD_QTY = 0;
            m_ORMD_ANS_DVCD = String.Empty;
            m_ORMD_ANS_ORIG_DVCD = String.Empty;
            m_ORMD_ANS_ORIG_CD = String.Empty;
            m_ORMD_SITE_DVCD = String.Empty;
            m_ORMD_SITE_CD = String.Empty;
            m_MDCN_UPLM_AMT = 0;
            m_MDCN_UPLM_DIAM = 0;
            m_ORIG_PRSC_SQNO = 0;
            m_ORIG_SQNO = 0;
            m_PCLR_MATR = String.Empty;
            m_AFRS_STAT_DVCD = String.Empty;
            m_ROW_STAT_DVCD = String.Empty;
            m_RGST_DT = String.Empty;
            m_RGSTR_ID = String.Empty;
            m_NEW_RCPT_RQNO = 0;
            m_NEW_ROW_STAT_DVCD = String.Empty;

            m_STATVAL1 = 1;
            m_STATVAL2 = 1;

            m_CLUR_DSBL_DVCD = String.Empty;

            m_DtPrsc.Clear();
        }

        // #endregion

        // #region Method : Public Method

        /// <summary>
        /// 외래수납처방내역을 DataTable에 담아서 PaOrecBd Insert.
        /// </summary>
        /// <returns></returns>
        const SavePaOrecBd = (msg:string, optionString:string = "") => 
        {
            try
            {
                let dtPaOrecBd:DataTable = new DataTable();

                // 입원취소에서 A행을 생성할 경우
                if (m_NEW_ROW_STAT_DVCD.Equals("A") && m_AFRS_STAT_DVCD.Equals("9"))
                {
                    await DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAORECBD(true), /*ref*/ dtPaOrecBd, m_PID
                                                                                          , m_PT_CMHS_NO.ToString()
                                                                                          , m_ROW_STAT_DVCD);
                }
                else
                {
                    await DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAORECBD(false), /*ref*/ dtPaOrecBd, m_PID
                                                                                          , m_PT_CMHS_NO.ToString()
                                                                                          , m_RCPT_SQNO.ToString()
                                                                                          , m_ROW_STAT_DVCD);
                }

                if (dtPaOrecBd.Rows.Count > 0)
                {
                    return InsertPaOrecBd(dtPaOrecBd, /*ref*/ msg, optionString);
                }

                return false;
            }
            catch (ex)
            {
                msg = "외래접수내역 취소 중 오류를 발생했습니다.\r\n " +
                      "Method :  [SavePaOrecBd] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }
            return true;
        }

        /// <summary>
        /// 외래수납처방내역을 DataTable에 담아서 PaOrecBd Insert.
        /// </summary>
        /// <returns></returns>
        const SavePaOrecBd_Uncl = (msg:string, optionString:string = "") => 
        {
            try
            {
                let dt:DataTable = new DataTable();
                if (!await DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAORECBD(true), /*ref*/ dt, m_PID, m_PT_CMHS_NO.ToString(), m_ROW_STAT_DVCD))
                    throw new Error("이전 수납처방내역을 조회하는 중 에러가 발생했습니다.");

                if (dt.Rows.Count > 0)
                {
                    return InsertPaOrecBd(dt, /*ref*/ msg, optionString);
                }

                return false;
            }
            catch (ex)
            {
                msg = "외래접수내역 취소 중 오류를 발생했습니다.\r\n " +
                      "Method :  [SavePaOrecBd] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }
            return true;
        }

        /// <summary>
        /// 외래수납처방내역 Insert
        /// </summary>
        /// <param name="dtpaorecdb"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        const InsertPaOrecBd = (dtpaorecdb:DataTable, /*ref*/ string msg, optionString:string = "") => 
        {
            try
            {
                let clurdsblcount:number = 0;
                let pid:string = String.Empty;
                let ptcmhsno:string = String.Empty;

                for (const row of dtpaorecdb.Rows)
                {
                    if (optionString.Equals("D"))
                    {
                        // #region 입원등록 D Insert

                        if (!await DBService.ExecuteNonQuery(SQL.PA.BaseSql.Insert.PAORECBD(), row["PID"].ToString()
                                                                                       , row["PT_CMHS_NO"].ToString()
                                                                                       , m_NEW_RCPT_RQNO.ToString()
                                                                                       , row["APLY_SQNO"].ToString()
                                                                                       , row["PRSC_SQNO"].ToString()
                                                                                       , row["MDCR_DD"].ToString()
                                                                                       , row["ACTG_DD"].ToString()
                                                                                       , row["CLAM_CRTN_YN"].ToString()
                                                                                       , row["REAL_PRDC_CD"].ToString()
                                                                                       , row["PRSC_DVCD"].ToString()
                                                                                       , row["BNDL_PRSC_SQNO"].ToString()
                                                                                       , row["BNDL_MEFE_CD"].ToString()
                                                                                       , row["MEFE_CD"].ToString()
                                                                                       , row["MEFE_NM"].ToString()
                                                                                       , row["EDI_CD"].ToString()
                                                                                       , row["PRFT_CD"].ToString()
                                                                                       , row["ONTM_QTY"].ToString()
                                                                                       , row["NOTM"].ToString()
                                                                                       , (Int.Parse(row["NODY"].ToString()) * -1).ToString()            // 일수는 -1곱함
                                                                                       , row["AOMD_MTHD_CD"].ToString()
                                                                                       , row["OUPR_GRNT_NO"].ToString()
                                                                                       , row["EXCP_RESN_CD"].ToString()
                                                                                       , row["DLVR_DEPT_CD"].ToString()
                                                                                       , row["ACTG_DEPT_CD"].ToString()
                                                                                       , row["CLCL_DVCD"].ToString()
                                                                                       , row["ACTN_MATL_DVCD"].ToString()
                                                                                       , row["CLUS_DVCD"].ToString()
                                                                                       , row["SBIT_DVCD"].ToString()
                                                                                       , row["MEFE_DVCD"].ToString()
                                                                                       , row["PAY_NOPY_DVCD"].ToString()
                                                                                       , row["SCNG_PAY_CD"].ToString()
                                                                                       , row["CNFR_DVCD"].ToString()
                                                                                       , row["CNFR_CD"].ToString()
                                                                                       , row["CMPT_CD"].ToString()
                                                                                       , row["TIME_ADTN_DVCD"].ToString()
                                                                                       , row["VTRN_PT_YN"].ToString()
                                                                                       , row["UNPR"].ToString()
                                                                                       , row["ADTN_CMPT_AMT"].ToString()
                                                                                       , row["BYKN_ADTN_AMT"].ToString()
                                                                                       , row["SMCR_AMT"].ToString()
                                                                                       , (Int.Parse(row["CLCL_AMT"].ToString()) * -1).ToString()        // 계산금액도 -1곱함
                                                                                       , row["ORIG_CLCL_AMT"].ToString()
                                                                                       , row["ADED_VALU_TAX_AMT"].ToString()
                                                                                       , row["PAY_USCH_AMT"].ToString()
                                                                                       , row["PAY_CLAM_AMT"].ToString()
                                                                                       , row["SCNG_PAY_USCH_AMT"].ToString()
                                                                                       , row["SCNG_PAY_CLAM_AMT"].ToString()
                                                                                       , row["VTRN_TAMT"].ToString()
                                                                                       , row["DCNT_AMT"].ToString()
                                                                                       , row["ADTN_APLY_TIME"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_1"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_2"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_3"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_4"].ToString()
                                                                                       , row["CNVR_PNT"].ToString()
                                                                                       , row["GRP_UNPR_APLY_YN"].ToString()
                                                                                       , row["DNFR_RGUP_CNTS"].ToString()
                                                                                       , row["DNFR_LFUP_CNTS"].ToString()
                                                                                       , row["DNFR_RGHT_LOW_CNTS"].ToString()
                                                                                       , row["DNFR_LEFT_LOW_CNTS"].ToString()
                                                                                       , row["HPMD_CLCL_DVCD"].ToString()
                                                                                       , row["HPMD_CLCL_QTY"].ToString()
                                                                                       , row["ENTS_ENTD_DVCD"].ToString()
                                                                                       , row["ENTS_ENTD_INSTNO"].ToString()
                                                                                       , row["SLCT_MCFE"].ToString()
                                                                                       , row["SMCR_RATE"].ToString()
                                                                                       , row["FXAM_INCL_YN"].ToString()
                                                                                       , row["TOTL_AOMD_QTY"].ToString()
                                                                                       , row["ORMD_ANS_YN"].ToString()
                                                                                       , row["ORMD_ANS_CD"].ToString()
                                                                                       , row["ORMD_ANS_NM"].ToString()
                                                                                       , row["ORMD_SITE_DVCD"].ToString()
                                                                                       , row["ORMD_SITE_CD"].ToString()
                                                                                       , row["MDCN_UPLM_AMT"].ToString()
                                                                                       , row["MDCN_UPLM_DIAM"].ToString()
                                                                                       , row["ORIG_PRSC_SQNO"].ToString()
                                                                                       , row["ORIG_SQNO"].ToString()
                                                                                       , row["PCLR_MATR"].ToString()
                                                                                       , m_AFRS_STAT_DVCD
                                                                                       , m_NEW_ROW_STAT_DVCD
                                                                                       , m_RGST_DT
                                                                                       , m_RGSTR_ID))
                        {
                            msg = DBService.ErrorMessage + "\r\n 외래수납처방내역 발생중 오류발생[ ROW_STAT_DVCD = " + m_ROW_STAT_DVCD + " ]";
                            // DBService.RollbackTransaction();
                            return false;
                        }
                        // #endregion 입원등록 D Insert
                    }
                    else if (optionString.Equals("F"))
                    {
                        // #region F Insert

                        if (!await DBService.ExecuteNonQuery(SQL.PA.BaseSql.Insert.PAORECBD(), row["PID"].ToString()
                                                                                       , row["PT_CMHS_NO"].ToString()
                                                                                       , m_NEW_RCPT_RQNO.ToString()
                                                                                       , row["APLY_SQNO"].ToString()
                                                                                       , row["PRSC_SQNO"].ToString()
                                                                                       , row["MDCR_DD"].ToString()
                                                                                       , row["ACTG_DD"].ToString()
                                                                                       , row["CLAM_CRTN_YN"].ToString()
                                                                                       , row["REAL_PRDC_CD"].ToString()
                                                                                       , row["PRSC_DVCD"].ToString()
                                                                                       , row["BNDL_PRSC_SQNO"].ToString()
                                                                                       , row["BNDL_MEFE_CD"].ToString()
                                                                                       , row["MEFE_CD"].ToString()
                                                                                       , row["MEFE_NM"].ToString()
                                                                                       , row["EDI_CD"].ToString()
                                                                                       , row["PRFT_CD"].ToString()
                                                                                       , row["ONTM_QTY"].ToString()
                                                                                       , row["NOTM"].ToString()
                                                                                       , row["NODY"].ToString()
                                                                                       , row["AOMD_MTHD_CD"].ToString()
                                                                                       , row["OUPR_GRNT_NO"].ToString()
                                                                                       , row["EXCP_RESN_CD"].ToString()
                                                                                       , row["DLVR_DEPT_CD"].ToString()
                                                                                       , row["ACTG_DEPT_CD"].ToString()
                                                                                       , row["CLCL_DVCD"].ToString()
                                                                                       , row["ACTN_MATL_DVCD"].ToString()
                                                                                       , row["CLUS_DVCD"].ToString()
                                                                                       , row["SBIT_DVCD"].ToString()
                                                                                       , row["MEFE_DVCD"].ToString()
                                                                                       , row["PAY_NOPY_DVCD"].ToString()
                                                                                       , row["SCNG_PAY_CD"].ToString()
                                                                                       , row["CNFR_DVCD"].ToString()
                                                                                       , row["CNFR_CD"].ToString()
                                                                                       , row["CMPT_CD"].ToString()
                                                                                       , row["TIME_ADTN_DVCD"].ToString()
                                                                                       , row["VTRN_PT_YN"].ToString()
                                                                                       , row["UNPR"].ToString()
                                                                                       , row["ADTN_CMPT_AMT"].ToString()
                                                                                       , row["BYKN_ADTN_AMT"].ToString()
                                                                                       , row["SMCR_AMT"].ToString()
                                                                                       , "0"                                        // 계산금액 0 설정
                                                                                       , row["ORIG_CLCL_AMT"].ToString()
                                                                                       , row["ADED_VALU_TAX_AMT"].ToString()
                                                                                       , row["PAY_USCH_AMT"].ToString()
                                                                                       , row["PAY_CLAM_AMT"].ToString()
                                                                                       , row["SCNG_PAY_USCH_AMT"].ToString()
                                                                                       , row["SCNG_PAY_CLAM_AMT"].ToString()
                                                                                       , row["VTRN_TAMT"].ToString()
                                                                                       , row["DCNT_AMT"].ToString()
                                                                                       , row["ADTN_APLY_TIME"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_1"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_2"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_3"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_4"].ToString()
                                                                                       , row["CNVR_PNT"].ToString()
                                                                                       , row["GRP_UNPR_APLY_YN"].ToString()
                                                                                       , row["DNFR_RGUP_CNTS"].ToString()
                                                                                       , row["DNFR_LFUP_CNTS"].ToString()
                                                                                       , row["DNFR_RGHT_LOW_CNTS"].ToString()
                                                                                       , row["DNFR_LEFT_LOW_CNTS"].ToString()
                                                                                       , row["HPMD_CLCL_DVCD"].ToString()
                                                                                       , row["HPMD_CLCL_QTY"].ToString()
                                                                                       , row["ENTS_ENTD_DVCD"].ToString()
                                                                                       , row["ENTS_ENTD_INSTNO"].ToString()
                                                                                       , row["SLCT_MCFE"].ToString()
                                                                                       , row["SMCR_RATE"].ToString()
                                                                                       , row["FXAM_INCL_YN"].ToString()
                                                                                       , row["TOTL_AOMD_QTY"].ToString()
                                                                                       , row["ORMD_ANS_YN"].ToString()
                                                                                       , row["ORMD_ANS_CD"].ToString()
                                                                                       , row["ORMD_ANS_NM"].ToString()
                                                                                       , row["ORMD_SITE_DVCD"].ToString()
                                                                                       , row["ORMD_SITE_CD"].ToString()
                                                                                       , row["MDCN_UPLM_AMT"].ToString()
                                                                                       , row["MDCN_UPLM_DIAM"].ToString()
                                                                                       , row["ORIG_PRSC_SQNO"].ToString()
                                                                                       , row["ORIG_SQNO"].ToString()
                                                                                       , row["PCLR_MATR"].ToString()
                                                                                       , m_AFRS_STAT_DVCD
                                                                                       , m_NEW_ROW_STAT_DVCD
                                                                                       , m_RGST_DT
                                                                                       , m_RGSTR_ID))
                        {
                            msg = DBService.ErrorMessage + "\r\n 외래수납처방내역 발생중 오류발생[ ROW_STAT_DVCD = " + m_ROW_STAT_DVCD + " ]";
                            // DBService.RollbackTransaction();
                            return false;
                        }
                        // #endregion F Insert
                    }
                    else
                    {
                        // #region Default Insert

                        if (!await DBService.ExecuteNonQuery(SQL.PA.BaseSql.Insert.PAORECBD(), row["PID"].ToString()
                                                                                       , row["PT_CMHS_NO"].ToString()
                                                                                       , m_NEW_RCPT_RQNO.ToString()
                                                                                       , row["APLY_SQNO"].ToString()
                                                                                       , row["PRSC_SQNO"].ToString()
                                                                                       , row["MDCR_DD"].ToString()
                                                                                       , row["ACTG_DD"].ToString()
                                                                                       , row["CLAM_CRTN_YN"].ToString()
                                                                                       , row["REAL_PRDC_CD"].ToString()
                                                                                       , row["PRSC_DVCD"].ToString()
                                                                                       , row["BNDL_PRSC_SQNO"].ToString()
                                                                                       , row["BNDL_MEFE_CD"].ToString()
                                                                                       , row["MEFE_CD"].ToString()
                                                                                       , row["MEFE_NM"].ToString()
                                                                                       , row["EDI_CD"].ToString()
                                                                                       , row["PRFT_CD"].ToString()
                                                                                       , row["ONTM_QTY"].ToString()
                                                                                       , row["NOTM"].ToString()
                                                                                       , row["NODY"].ToString()
                                                                                       , row["AOMD_MTHD_CD"].ToString()
                                                                                       , row["OUPR_GRNT_NO"].ToString()
                                                                                       , row["EXCP_RESN_CD"].ToString()
                                                                                       , row["DLVR_DEPT_CD"].ToString()
                                                                                       , row["ACTG_DEPT_CD"].ToString()
                                                                                       , row["CLCL_DVCD"].ToString()
                                                                                       , row["ACTN_MATL_DVCD"].ToString()
                                                                                       , row["CLUS_DVCD"].ToString()
                                                                                       , row["SBIT_DVCD"].ToString()
                                                                                       , row["MEFE_DVCD"].ToString()
                                                                                       , row["PAY_NOPY_DVCD"].ToString()
                                                                                       , row["SCNG_PAY_CD"].ToString()
                                                                                       , row["CNFR_DVCD"].ToString()
                                                                                       , row["CNFR_CD"].ToString()
                                                                                       , row["CMPT_CD"].ToString()
                                                                                       , row["TIME_ADTN_DVCD"].ToString()
                                                                                       , row["VTRN_PT_YN"].ToString()
                                                                                       , row["UNPR"].ToString()
                                                                                       , row["ADTN_CMPT_AMT"].ToString()
                                                                                       , row["BYKN_ADTN_AMT"].ToString()
                                                                                       , row["SMCR_AMT"].ToString()
                                                                                       , row["CLCL_AMT"].ToString()
                                                                                       , row["ORIG_CLCL_AMT"].ToString()
                                                                                       , row["ADED_VALU_TAX_AMT"].ToString()
                                                                                       , row["PAY_USCH_AMT"].ToString()
                                                                                       , row["PAY_CLAM_AMT"].ToString()
                                                                                       , row["SCNG_PAY_USCH_AMT"].ToString()
                                                                                       , row["SCNG_PAY_CLAM_AMT"].ToString()
                                                                                       , row["VTRN_TAMT"].ToString()
                                                                                       , row["DCNT_AMT"].ToString()
                                                                                       , row["ADTN_APLY_TIME"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_1"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_2"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_3"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_4"].ToString()
                                                                                       , row["CNVR_PNT"].ToString()
                                                                                       , row["GRP_UNPR_APLY_YN"].ToString()
                                                                                       , row["DNFR_RGUP_CNTS"].ToString()
                                                                                       , row["DNFR_LFUP_CNTS"].ToString()
                                                                                       , row["DNFR_RGHT_LOW_CNTS"].ToString()
                                                                                       , row["DNFR_LEFT_LOW_CNTS"].ToString()
                                                                                       , row["HPMD_CLCL_DVCD"].ToString()
                                                                                       , row["HPMD_CLCL_QTY"].ToString()
                                                                                       , row["ENTS_ENTD_DVCD"].ToString()
                                                                                       , row["ENTS_ENTD_INSTNO"].ToString()
                                                                                       , row["SLCT_MCFE"].ToString()
                                                                                       , row["SMCR_RATE"].ToString()
                                                                                       , row["FXAM_INCL_YN"].ToString()
                                                                                       , row["TOTL_AOMD_QTY"].ToString()
                                                                                       , row["ORMD_ANS_YN"].ToString()
                                                                                       , row["ORMD_ANS_CD"].ToString()
                                                                                       , row["ORMD_ANS_NM"].ToString()
                                                                                       , row["ORMD_SITE_DVCD"].ToString()
                                                                                       , row["ORMD_SITE_CD"].ToString()
                                                                                       , row["MDCN_UPLM_AMT"].ToString()
                                                                                       , row["MDCN_UPLM_DIAM"].ToString()
                                                                                       , row["ORIG_PRSC_SQNO"].ToString()
                                                                                       , row["ORIG_SQNO"].ToString()
                                                                                       , row["PCLR_MATR"].ToString()
                                                                                       , m_AFRS_STAT_DVCD
                                                                                       , m_NEW_ROW_STAT_DVCD
                                                                                       , m_RGST_DT
                                                                                       , m_RGSTR_ID))
                        {
                            msg = DBService.ErrorMessage + "\r\n 외래수납처방내역 발생중 오류발생[ ROW_STAT_DVCD = " + m_ROW_STAT_DVCD + " ]";
                            // DBService.RollbackTransaction();
                            return false;
                        }
                        // #endregion Default Insert
                    }

                    if (row["CLUS_DVCD"].ToString().Equals("T") && row["SBIT_DVCD"].ToString().Equals("01"))
                    {
                        clurdsblcount++;
                        pid = row["PID"].ToString();
                        ptcmhsno = row["PT_CMHS_NO"].ToString();
                    }

                }
                //this.Clear();
                //장루요루구분코드 변경
                if (clurdsblcount > 0)
                {
                    m_CLUR_DSBL_DVCD = "1";
                }
                else
                {
                    m_CLUR_DSBL_DVCD = "0";
                }

                if (!await DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateClurDsblDvcdOfPAOPATRT(), pid
                                                                                        , ptcmhsno
                                                                                        , m_CLUR_DSBL_DVCD))
                {
                    msg = "외래접수정보 장루요루구분코드 변경중 오류발생 \r\n Error Message : " + DBService.ErrorMessage;
                    // DBService.RollbackTransaction();
                    return false;
                }
            }
            catch (ex)
            {
                msg = "외래수납내역 취소 중 오류를 발생했습니다.\r\n " +
                      "Method :  [InsertPaOrecBd] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }
            return true;
        }

        /// <summary>
        /// 외래수납처방내역의 행상태구분코드 UPDATE
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        const UpdateRowStatDvcdOfPaOrecBd = (msg:string) => 
        {
            let success:boolean = true;

            if (!await DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePAORECBD_RowStatDvcd(), PID
                                                                                  , PT_CMHS_NO.ToString()
                                                                                  , ROW_STAT_DVCD
                                                                                  , NEW_ROW_STAT_DVCD))
            {
                success = false;
                msg = DBService.ErrorMessage + "\r\n 외래수납처방내역의 행상태구분코드 변경중 오류가 발생하였습니다. 확인하시기 바랍니다.";
                // DBService.RollbackTransaction();
            }
            return success;
        }

        const GetORORDRRT = (pid:string, ptcmhsno:number) => 
        {
            let result:boolean = true;
            try
            {
                result = await DBService.ExecuteDataTable(SQL.PA.Sql.SelectORORDRRT_Receipt(true), /*ref*/ m_DtPrsc, pid, ptcmhsno.ToString());
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                result = false;
            }
            return result;
        }

        // #endregion Method : Public Method
   
/* Expose */
defineExpose({ });
</script>

<template>
<PopupTemplate :Key="getKey()" :ClientSize="ClientSize" :Caption="Caption">
</PopupTemplate>

</template>
