//********************************************************************************
// Class 명 : ucfLocCdInfo
// 역    할 : 가야할곳코드관리
// 작 성 자 : KJY (검수YJS)
// 작 성 일 : 2017-07-24 
//********************************************************************************
// 수정내역 : 2017-08-07, 수정자 : YJS, 로그인ID추가
//                                      변경내역 없을 시, 수정할 내역 없다고 알림 추가.
//                                      ClearCRUD와 UpdateOldValue가 Commit후에만 되도록 변경. 
//                                      저장 시, 적용시작일자 <= 종료일자 유효성 체크 추가.
//                                      Dup, Null 체크 추가
//            2017-08-08, 수정자 : YJS, 중복기간 체크 로직 추가
//            2017-09-05, 수정자 : YJS 개발표준적용
//            2017-10-25, 수정자 : YJS, 개발표준적용 테스트 및 재확인
//            2018-03-22 : 유준선 수정
//********************************************************************************
using System;
using System.Data;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;


namespace Lime.BI
{
    public partial class ucfLocCdInfo : BaseUCF_TP
    {
        #region Define : Member
        string strDate = ""; //날짜
        string userID = DOPack.UserInfo.USER_CD;
        string m_strSort = ""; //컬럼 sorting에 사용
        #endregion Define : Member

        #region Construction
        public ucfLocCdInfo()
        {
            InitializeComponent();
        }
        #endregion Construction

        #region Screen Load
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            Initialize();
        }

        /// <summary>
        /// 데이터 수정 후 다른 기능 수행하려고 할 때, DialogResult
        /// </summary>
        /// <param name="isSelectCLOSE">조회는 S, 종료는 C 를 넘긴다.</param>
        private bool IsModifiedCheck(string isSelectCLOSE)
        {
            try
            {
                if (sprMaster.IsModified())
                {
                    DialogResult dr = LxMessage.Show("작성중인 내용이 있습니다.\r\n작성중인 내용을 저장하시겠습니까?", "확인!", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
                    if (dr == DialogResult.Yes)
                    {
                        SaveData();

                        if (isSelectCLOSE == "S")
                            SelectData();
                        else if (isSelectCLOSE == "C")
                            Close();
                    }
                    else if (dr == DialogResult.No)
                    {
                        if (isSelectCLOSE == "S")
                            SelectData();
                        else if (isSelectCLOSE == "C")
                            Close();
                    }
                    else
                        return false;
                }
                else
                {
                    if (isSelectCLOSE == "S")
                        SelectData();
                    else if (isSelectCLOSE == "C")
                        Close();

                    return true;
                }

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
        }
        #endregion Screen Load

        #region Method : Initialize Method
        private void Initialize()
        {
            try
            {
                clsBICommon.SetDateTimeToMask(sprMaster, "APLY_STRT_DD");
                clsBICommon.SetDateTimeToMask(sprMaster, "APLY_END_DD");

                SelectData();
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
        }
        #endregion Method : Initialize Method

        #region Method : Private Method

        /// <summary>
        /// 컬럼 헤드 클릭 시, Sorting에 사용
        /// </summary>
        /// <param name="spr"></param>
        /// <param name="isColumn"></param>
        /// <param name="ColIndex"></param>
        private void SortColumn(LxSpread spr, bool isColumn, int ColIndex)
        {
            try
            {
                if (isColumn)
                {
                    if (m_strSort.Equals("") || m_strSort.Equals("A"))
                    {
                        spr.ActiveSheet.AutoSortColumn(ColIndex, true, false);
                        m_strSort = "D";
                    }
                    else
                    {
                        spr.ActiveSheet.AutoSortColumn(ColIndex, false, false);
                        m_strSort = "A";
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
        }

        private bool SelectData()
        {
            try
            {
                sprMaster.Clear();
                string isDtp;

                if (chkAplyStrtDd.Checked)
                    isDtp = "Y";
                else
                    isDtp = "N";

                strDate = dtpAplyStrtDd.Value.ToString("yyyy-MM-dd");

                DataTable dataT = new DataTable();
                if (DBService.ExecuteDataTable(SQL.BI.Sql.SelectBILOCDMA(), ref dataT, isDtp, strDate))
                {
                    if (dataT.Rows.Count > 0)
                    {
                        sprMaster.FillDataTag(dataT);
                    }
                    return true;
                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
        }

        /// <summary>
        /// 삭제
        /// </summary>
        private void DeleteData()
        {
            try
            {
                if (sprMaster.ActiveSheet.RowCount == 0)
                {
                    LxMessage.Show("삭제할 데이터가 없습니다!!", "삭제할 데이터 없음", MessageBoxButtons.OK, MessageBoxIcon.Warning, 2);
                    return;
                }

                DialogResult dr = LxMessage.Show("선택한 정보를 삭제하겠습니까?", "삭제확인", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dr == DialogResult.Yes)
                {
                    if (DBService.ExecuteNonQuery(SQL.BI.Sql.DeleteBILOCDMA(), sprMaster.GetValue("VIST_PLCE_CD_1").ToString(), sprMaster.GetValue("APLY_STRT_DD_1").ToString()))
                    {
                        DBService.BeginTransaction();
                        sprMaster.RemoveRow();
                        DBService.CommitTransaction();
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
        }

        /// <summary>
        /// 저장
        /// </summary>
        private void SaveData()
        {
            try
            {
                if (!clsBICommon.CheckModified(sprMaster))
                    return;

                if (!clsBICommon.CheckAplyDate(sprMaster, "APLY_STRT_DD", "APLY_END_DD"))
                    return;

                if (!clsBICommon.CheckValidDate(sprMaster, "APLY_STRT_DD", "APLY_END_DD"))
                    return;

                DataTable dataT = new DataTable();
                bool success = false;

                DBService.BeginTransaction();
                for (int i = 0; i < sprMaster.ActiveSheet.RowCount; i++)
                {
                    //추가
                    if (sprMaster.GetCRUDFromRow(i) == CRUD_TYPE.Create)
                    {
                        if (!clsBICommon.CheckDupDuration(sprMaster, i, "BILOCDMA", "APLY_STRT_DD", "APLY_END_DD", "VIST_PLCE_CD", false, true))
                        {
                            DBService.RollbackTransaction();
                            return;
                        }

                        if (string.IsNullOrWhiteSpace(sprMaster.GetValue(i, "VIST_PLCE_CD").ToString()))
                        {
                            DBService.RollbackTransaction();
                            BizCommon.SetRowFocus(sprMaster, i, "VIST_PLCE_CD");
                            LxMessage.Show("가야할곳 코드가 입력되지 않은 행이 있습니다.\r\n코드를 확인해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            return;
                        }

                        if (string.IsNullOrWhiteSpace(sprMaster.GetValue(i, "VIST_PLCE_NM").ToString()))
                        {
                            DBService.RollbackTransaction();
                            BizCommon.SetRowFocus(sprMaster, i, "VIST_PLCE_NM");
                            LxMessage.Show("가야할곳 장소가 입력되지 않은 행이 있습니다.\r\n장소를 확인해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            return;
                        }

                        if (DBService.ExecuteNonQuery(SQL.BI.BaseSql.Insert.BILOCDMA(), sprMaster.GetValue(i, "VIST_PLCE_CD").ToString()
                                                                                      , sprMaster.GetValue(i, "APLY_STRT_DD").ToString().Replace("-", "")
                                                                                      , sprMaster.GetValue(i, "APLY_END_DD").ToString().Replace("-", "")
                                                                                      , sprMaster.GetValue(i, "VIST_PLCE_NM").ToString()
                                                                                      , sprMaster.GetValue(i, "BLDG_FLOR_CNTS").ToString()
                                                                                      , "", "", ""
                                                                                      , sprMaster.GetValue(i, "SORT_SEQ").ToString()
                                                                                      , DateTime.Now.ToString("yyyyMMddHHmmss")
                                                                                      , userID
                                                                                      , DateTime.Now.ToString("yyyyMMddHHmmss")
                                                                                      , userID))
                        {
                            success = true;

                            sprMaster.SetText(i, "VIST_PLCE_CD_1", sprMaster.GetValue(i, "VIST_PLCE_CD").ToString());
                            sprMaster.SetText(i, "APLY_STRT_DD_1", sprMaster.GetValue(i, "APLY_STRT_DD").ToString().Replace("-", ""));
                        }
                        else
                        {
                            if (!clsBICommon.CheckDup(sprMaster, i, "VIST_PLCE_CD", "가야할곳코드, 적용시작일"))
                            {
                                DBService.RollbackTransaction();
                                return;
                            }
                            if (!clsBICommon.CheckNull(sprMaster, i, "VIST_PLCE_CD", "가야할곳코드"))
                            {
                                DBService.RollbackTransaction();
                                return;
                            }
                        }

                    }


                    //업데이트
                    if (sprMaster.GetCRUDFromRow(i) == CRUD_TYPE.Update)
                    {
                        if (!clsBICommon.CheckDupDuration(sprMaster, i, "BILOCDMA", "APLY_STRT_DD", "APLY_END_DD", "VIST_PLCE_CD", false, true))
                        {
                            DBService.RollbackTransaction();
                            return;
                        }

                        if (string.IsNullOrWhiteSpace(sprMaster.GetValue(i, "VIST_PLCE_CD").ToString()))
                        {
                            DBService.RollbackTransaction();
                            BizCommon.SetRowFocus(sprMaster, i, "VIST_PLCE_CD");
                            LxMessage.Show("가야할곳 코드가 입력되지 않은 행이 있습니다.\r\n코드를 확인해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            return;
                        }

                        if (string.IsNullOrWhiteSpace(sprMaster.GetValue(i, "VIST_PLCE_NM").ToString()))
                        {
                            DBService.RollbackTransaction();
                            BizCommon.SetRowFocus(sprMaster, i, "VIST_PLCE_NM");
                            LxMessage.Show("가야할곳 장소가 입력되지 않은 행이 있습니다.\r\n장소를 확인해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            return;
                        }

                        if (DBService.ExecuteNonQuery(SQL.BI.Sql.UpdateBILOCDMA(), sprMaster.GetValue(i, "VIST_PLCE_CD").ToString()
                                                                                    , sprMaster.GetValue(i, "APLY_STRT_DD").ToString().Replace("-", "")
                                                                                    , sprMaster.GetValue(i, "APLY_END_DD").ToString().Replace("-", "")
                                                                                    , sprMaster.GetValue(i, "VIST_PLCE_NM").ToString()
                                                                                    , sprMaster.GetValue(i, "BLDG_FLOR_CNTS").ToString()
                                                                                    , sprMaster.GetValue(i, "SORT_SEQ").ToString()
                                                                                    , sprMaster.GetValue(i, "VIST_PLCE_CD_1").ToString()
                                                                                    , sprMaster.GetValue(i, "APLY_STRT_DD_1").ToString()
                                                                                    , DateTime.Now.ToString("yyyyMMddHHmmss").ToString()
                                                                                    , userID))
                        {
                            success = true;
                        }
                        else
                        {
                            if (!clsBICommon.CheckDup(sprMaster, i, "VIST_PLCE_CD", "가야할곳코드, 적용시작일"))
                            {
                                DBService.RollbackTransaction();
                                return;
                            }
                            if (!clsBICommon.CheckNull(sprMaster, i, "VIST_PLCE_CD", "가야할곳코드"))
                            {
                                DBService.RollbackTransaction();
                                return;
                            }
                        }


                    }

                }
                if (success)
                {
                    DBService.CommitTransaction();
                    sprMaster.ClearCRUD();
                    sprMaster.UpdateOldValue(sprMaster.ActiveSheet);
                    LxMessage.Show("저장되었습니다.", "저장완료", MessageBoxButtons.OK, MessageBoxIcon.Information, 2);

                }
                else
                {
                    DBService.RollbackTransaction();
                    LxMessage.Show("저장이 정상적으로 완료되지 않았습니다!!\r\n", "알림", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                DBService.RollbackTransaction();
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

        }
        #endregion Method : Private Method

        #region Event : Event Process
        private void sprMaster_ChangeExpand(object sender, LxSpread.ChangeExpandEventArgs e)
        {
            try
            {
                if (sprMaster.ActiveSheet.Columns.Get(e.Column).Tag.ToString() == "APLY_STRT_DD")
                    clsBICommon.CheckValidDateString(sprMaster, e, "APLY_STRT_DD");

                if (sprMaster.ActiveSheet.Columns.Get(e.Column).Tag.ToString() == "APLY_END_DD")
                    clsBICommon.CheckValidDateString(sprMaster, e, "APLY_END_DD");
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
        }

        private void chkAplyStrtDd_CheckedChanged(object sender, EventArgs e)
        {
            if (chkAplyStrtDd.Checked == true)
            {
                dtpAplyStrtDd.Enabled = true;
                SelectData();
            }
            else
            {
                dtpAplyStrtDd.Enabled = false;
                SelectData();
            }
        }

        private void dtpAplyStrtDd_CloseUp(object sender, EventArgs e)
        {
            SelectData();
        }

        private void btnButtonList_ButtonClick(object sender, Framework.Controls.ButtonClickEventArgs e)
        {
            switch (e.ButtonType)
            {
                case ButtonType.Select:
                    if (!IsModifiedCheck("S"))
                        return;
                    SelectData();
                    break;
                case ButtonType.Append:
                    clsBICommon.AppendLine(sprMaster, "APLY_STRT_DD", "APLY_END_DD", true);
                    break;
                case ButtonType.Delete:
                    DeleteData();
                    break;
                case ButtonType.Save:
                    SaveData();
                    break;
                case ButtonType.Close:
                    IsModifiedCheck("C");
                    break;
            }
        }

        private void sprMaster_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader)
                SortColumn((LxSpread)sender, e.ColumnHeader, e.Column);
        }
        #endregion Event : Event Process


    }
}
