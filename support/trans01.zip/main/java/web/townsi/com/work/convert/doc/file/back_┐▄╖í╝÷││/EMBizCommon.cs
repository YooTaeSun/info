using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;
using System.Linq;
using PdfSharp;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using Lime.Framework.Controls;
using System.IO;

namespace Lime.Framework
{
    /// <summary>
    /// 내원정보의 Column
    /// </summary>
    public enum PatientIOInfoColumn
    {
        MDCR_DD, // 내원일자(입원일자)
        DSCH_DD  // 퇴원일자
    }

    /// <summary>
    /// 수술정보
    /// </summary>
    public enum PatientOpInfoColumn
    {
        MDCR_DEPT_CD, // 진료부서코드
        MDCR_DEPT_NM, // 진료부서
        OP_STRT_DD, // 수술시작일자
        OP_STRT_TIME, // 수술시작시간
        OP_END_DD, // 수술종료일자
        OP_END_TIME, // 수술종료시간
        OP_NEED_TIME, // 수술소요시간
        DGNS_NM, // 진단명
        OP_CD, // 수술코드
        OP_NM, // 수술명
        POSO_DR_ID, // 집도의코드
        POSO_DR_NM, // 집도의
        POSO_DEPT_CD, // 집도부서코드
        POSO_DEPT_NM, // 집도부서
        B_OP_NM, // 수술전 수술명
        B_DGNS_NM, // 수술전 진단명
    }

    /// <summary>
    /// 상병정보
    /// </summary>
    public enum DiseaseColumn
    {
        ILNS_CD,     // 상병코드
        ILNS_CD_HNM, // 상병한글명
        ILNS_CD_ENM, // 상병영문명
    }

    /// <summary>
    /// 처방정보
    /// </summary>
    public enum PatientPrscColumn
    {
        PRSC_LCLS_CDNM, //처방대분류명
        PRSC_MCLS_CDNM, //처방중분류명
        PRSC_CD,        //처방코드
        PRSC_NM,        //처방명
        ONTM_QTY,       //1회량
        NOTM,           //횟수
        TOTL_AOMD_QTY,  //총투여량
        NODY,           //일수
        AOMD_MTHD_CD,   //용법
    }

    public enum ResultChartDVCD
    {
        Page, // 서식
        Progress, // 간호/경과기록
    }

    public class SelectedDataParameters : Hashtable
    {
    }

    public class SelectedDataEventArgs : EventArgs
    {
        private SelectedDataParameters m_SelectedDataParameters;
        private string m_Key;

        public SelectedDataParameters SelectedDataParameters
        {
            get
            {
                return this.m_SelectedDataParameters;
            }
        }

        public string Key
        {
            get
            {
                return this.m_Key;
            }
        }

        public SelectedDataEventArgs(SelectedDataParameters param, string key)
        {
            this.m_SelectedDataParameters = param;
            this.m_Key = key;
        }
    }

    //public class ProgressInfo
    {
        //public string SheetCode { get; set; }
        //public string ProgressDvcd { get; set; }
        //public string TabKey { get; set; }
    //}

    public struct ControlSelectionInfo
    {
        /// <summary>
        /// 선택된 Control
        /// </summary>
        public Control sCtrl;

        /// <summary>
        /// 선택된 Control이 Spread일 경우 Acive Cell
        /// </summary>
        public FarPoint.Win.Spread.Cell sCell;

        /// <summary>
        /// 커서 선택된 시작위치
        /// </summary>
        public int sSelectionStart;

        /// <summary>
        /// 커서의 길이
        /// </summary>
        public int sSelectionLength;
    }

    public struct QueryFormatInfo
    {
        public string QUERYCODE;
        public string PARM01;
        public string PARM02;
        public string PARM03;
        public string PARM04;
        public string PARM05;
        public string PARM06;
        public string PARM07;
        public string PARM08;
        public string PARM09;
        public string PARM10;
    }

    public class EMBizCommon
    {
        #region Define : Member

        private static DataTable m_SheetListTable = new DataTable();
        private static bool m_Initialized = false;

        #endregion Define : Member

        #region :: Sheet의 모든 정보를 조회한다.

        private static void Load()
        {
            try
            {
                m_SheetListTable = new DataTable();

                if (DBService.ExecuteQueryCode("SHEETLIST.SELECT_SHEETLIST_ALL", ref m_SheetListTable))
                {
                    m_Initialized = true;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        #endregion :: Sheet의 모든 정보를 조회한다.

        #region :: Sheet의 정보 반환

        private static DataRow GetSheetRow(string sheetcode)
        {
            if (!m_Initialized)
                Load();

            foreach (DataRow row in m_SheetListTable.Rows)
            {
                if (row["SHEETCODE"].ToString().Equals(sheetcode))
                {
                    return row;
                }
            }

            return null;
        }

        #endregion :: Sheet의 정보 반환

        public static DataTable GetProgressSheet()
            => OverallCodeList.GetDataList("PROGRESS_SHEET");

        public static IEnumerable<ProgressInfo> GetProgressInfos(DataTable dt)
        {
            foreach (DataRow dr in dt.Rows)
                yield return new ProgressInfo
                {
                    SheetCode = dr["LWRN_OVRL_CDNM"].ToString(),
                    ProgressDvcd = dr["ITNL_USE_CD"].ToString(),
                    TabKey = dr["LWRN_OVRL_DETL_CD"].ToString(),
                };
        }

        public static ProgressInfo GetProgressInfo(string sheetcode)
        {
            var progressList = GetProgressInfos(GetProgressSheet());
            return progressList.FirstOrDefault(x => x.SheetCode == sheetcode);
        }

        #region :: EMR 차트 페이지 번호 조회

        /// <summary>
        /// 새로운 페이지 번호 조회
        /// </summary>
        private static int SelectMaxPageNo()
        {
            DataTable dtmaxpageno = new DataTable();

            try
            {
                if (DBService.ExecuteQueryCode("CHARTPAGE.SELECT_MAX_PAGESEQ", ref dtmaxpageno))
                {
                    if (dtmaxpageno.Rows.Count > 0)
                    {
                        return Convert.ToInt32(dtmaxpageno.Rows[0]["PAGESEQ"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return -1;
        }

        public static int SelectGetPageSeq(string pid, string createdate, string sheetcode, string pt_cmhs_no)
        {
            DataTable pageseq = new DataTable();

            try
            {
                if (DBService.ExecuteQueryCode("CHARTPAGE.SELECT_GET_PAGESEQ_20181210"
                                             , ref pageseq
                                             , pid, createdate, sheetcode, pt_cmhs_no))
                {
                    if (pageseq.Rows.Count > 0)
                    {
                        return Convert.ToInt32(pageseq.Rows[0]["PAGESEQ"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return -1;
        }

        #endregion :: EMR 차트 페이지 번호 조회

        #region :: EMR 차트 페이지 해당환자의 Max SortSeq 조회

        /// <summary>
        /// Max 페이지 순번 조회
        /// </summary>
        /// <param name="patientid"></param>
        /// <returns></returns>
        private static int SelectMaxSortSeq(string patientid)
        {
            DataTable dtmaxpagesort = new DataTable();

            try
            {
                if (DBService.ExecuteQueryCode("CHARTPAGE.SELECT_MAX_SORTSEQ", ref dtmaxpagesort, patientid))
                {
                    if (dtmaxpagesort.Rows.Count > 0)
                    {
                        return Convert.ToInt32(dtmaxpagesort.Rows[0]["SORTSEQ"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return 99999;
        }

        #endregion :: EMR 차트 페이지 해당환자의 Max SortSeq 조회

        #region :: 서식의 모든 Control을 가져와서 값을 합친다.

        /// <summary>
        /// 서식의 모든 Contorl을 가져와서 값을 합친다. (전자서명 용도)
        /// </summary>
        /// <param name="containercontrol">선택된Control</param>
        /// <returns></returns>
        public static string ESignValue(Control containercontrol)
        {
            List<string> list = new List<string>();

            foreach (Control ctrl in containercontrol.Controls)
            {
                if (ctrl is LxLabel || ctrl is LxTextBox || ctrl is LxComboBox || ctrl is LxDateTimeEditor || ctrl is LxDateTimePicker || ctrl is LxTitleLabel)
                    list.Add(ctrl.Text);
                else if (ctrl is LxCheckBox)
                    list.Add(((LxCheckBox)ctrl).Checked ? "Y" : "N");
                else if (ctrl is LxRadioButton)
                    list.Add(((LxRadioButton)ctrl).Checked ? "Y" : "N");
                else if (ctrl is LxSpread)
                {
                    for (int i = 0; i < ((LxSpread)ctrl).ActiveSheet.RowCount; i++)
                    {
                        for (int j = 0; j < ((LxSpread)ctrl).ActiveSheet.ColumnCount; j++)
                        {
                            string value = ((LxSpread)ctrl).GetValue(i, j) != null ? ((LxSpread)ctrl).GetValue(i, j).ToString() : "";
                            list.Add(value);
                        }
                    }
                }

                if (ctrl.Controls.Count > 0)
                    list.Add(ESignValue(ctrl));
            }

            return string.Join("", list.ToArray());
        }

        #endregion :: 서식의 모든 Control을 가져와서 값을 합친다.

        #region :: EMR 차트 페이지 정보 저장

        public static bool InsertPageInfo(string pid, string pt_cmhs_no, string sheetcode, string createdate, string ifkey, string esignvalue, bool checkdupdate = false)
        {
            if (!StringService.IsNotNull(pid, pt_cmhs_no, sheetcode, createdate, ifkey, esignvalue))
            {
                LogService.ErrorLog($"InsertPageInfo : {pid}, {pt_cmhs_no}, {sheetcode}, {createdate}, {ifkey}, {esignvalue}");
                return false;
            }

            DataTable dt = new DataTable();
            DataRow sheetinfo = GetSheetRow(sheetcode);

            if (sheetinfo == null)
            {
                LogService.ErrorLog(sheetcode + "로 조회된 EMR_MST_SHEET 정보가 존재하지 않습니다.");
                return false;
            }

            if (checkdupdate)
            {
                DBService.ExecuteQueryCode("CHARTPAGE.SELECT_PAGE_INFO_CREATEDATE_20181210", ref dt, pid, pt_cmhs_no, createdate, sheetcode);
                if (dt.Rows.Count > 0)
                {
                    return UpdatePageInfo(pid, pt_cmhs_no, sheetcode, createdate, dt.Rows[0]["IFKEY"].ToString(), ifkey, esignvalue);
                }
            }

            string pageseq = SelectMaxPageNo().ToString();
            string sortseq = SelectMaxSortSeq(pid).ToString();
            string sheettype = sheetinfo["SHEETTYPE"].ToString();
            string categorycode = sheetinfo["CATEGORYCODE"].ToString();
            string classname = sheetinfo["SHEETPATH"].ToString();

            dt = new DataTable();

            DBService.ExecuteQueryCode("PATIENT_INFO.SELECT_PATIENT_INFO_IO", ref dt, pid, pt_cmhs_no);

            if (dt.Rows.Count > 0)
            {
                string iotype = dt.Rows[0]["OTPT_ADMS_DVCD"].ToString();
                string iodate = dt.Rows[0]["IODATE"].ToString();
                string deptcode = dt.Rows[0]["MDCR_DEPT_CD"].ToString();

                if (DBService.ExecuteNonQueryCode("CHARTPAGE.INSERT_PAGEINFO"
                    , pid
                    , pageseq
                    , createdate
                    , sheettype
                    , iotype
                    , categorycode
                    , sheetcode
                    , pt_cmhs_no
                    , iodate
                    , deptcode
                    , sortseq
                    , classname
                    , ""
                    , ""
                    , "N"
                    , ""
                    , ifkey
                    , ""
                    , "N"
                    , ""
                    ))
                {
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }

        public static bool InsertPageInfo(string pid, string pt_cmhs_no, string sheetcode, string createdate, string ifkey, string esignvalue, string user_cd, bool checkdupdate = false)
        {
            if (!StringService.IsNotNull(pid, pt_cmhs_no, sheetcode, createdate, ifkey, esignvalue))
            {
                LogService.ErrorLog($"InsertPageInfo : {pid}, {pt_cmhs_no}, {sheetcode}, {createdate}, {ifkey}, {esignvalue}");
                return false;
            }

            DataTable dt = new DataTable();
            DataRow sheetinfo = GetSheetRow(sheetcode);

            if (sheetinfo == null)
            {
                LogService.ErrorLog(sheetcode + "로 조회된 EMR_MST_SHEET 정보가 존재하지 않습니다.");
                return false;
            }

            if (checkdupdate)
            {
                DBService.ExecuteQueryCode("CHARTPAGE.SELECT_PAGE_INFO_CREATEDATE_20181210", ref dt, pid, pt_cmhs_no, createdate, sheetcode);
                if (dt.Rows.Count > 0)
                {
                    return UpdatePageInfo(pid, pt_cmhs_no, sheetcode, createdate, dt.Rows[0]["IFKEY"].ToString(), ifkey, esignvalue);
                }
            }

            string pageseq = SelectMaxPageNo().ToString();
            string sortseq = SelectMaxSortSeq(pid).ToString();
            string sheettype = sheetinfo["SHEETTYPE"].ToString();
            string categorycode = sheetinfo["CATEGORYCODE"].ToString();
            string classname = sheetinfo["SHEETPATH"].ToString();

            dt = new DataTable();

            DBService.ExecuteQueryCode("PATIENT_INFO.SELECT_PATIENT_INFO_IO", ref dt, pid, pt_cmhs_no);

            if (dt.Rows.Count > 0)
            {
                string iotype = dt.Rows[0]["OTPT_ADMS_DVCD"].ToString();
                string iodate = dt.Rows[0]["IODATE"].ToString();
                string deptcode = dt.Rows[0]["MDCR_DEPT_CD"].ToString();

                if (DBService.ExecuteNonQueryCode("CHARTPAGE.INSERT_PAGEINFO_USERCD_20181206"
                    , pid
                    , pageseq
                    , createdate
                    , sheettype
                    , iotype
                    , categorycode
                    , sheetcode
                    , pt_cmhs_no
                    , iodate
                    , deptcode
                    , sortseq
                    , classname
                    , ""
                    , ""
                    , "N"
                    , "N"
                    , ""
                    , ifkey
                    , ""
                    , "N"
                    , ""
                    , string.IsNullOrWhiteSpace(user_cd) ? DOPack.UserInfo.USER_CD : user_cd
                    , "1"
                    ))
                {
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }

        public static bool InsertPageInfo(string pid, string pt_cmhs_no, string sheetcode, string createdate, string ifkey, string esignvalue, ref string ref_pageseq, bool checkdupdate = false)
        {
            if (!StringService.IsNotNull(pid, pt_cmhs_no, sheetcode, createdate, ifkey, esignvalue))
            {
                LogService.ErrorLog($"InsertPageInfo : {pid}, {pt_cmhs_no}, {sheetcode}, {createdate}, {ifkey}, {esignvalue}");
                return false;
            }

            DataTable dt = new DataTable();
            DataRow sheetinfo = GetSheetRow(sheetcode);

            if (sheetinfo == null)
            {
                LogService.ErrorLog(sheetcode + "로 조회된 EMR_MST_SHEET 정보가 존재하지 않습니다.");
                return false;
            }

            if (checkdupdate)
            {
                DBService.ExecuteQueryCode("CHARTPAGE.SELECT_PAGE_INFO_CREATEDATE_20181210", ref dt, pid, pt_cmhs_no, createdate, sheetcode);
                if (dt.Rows.Count > 0)
                {
                    return UpdatePageInfo(pid, pt_cmhs_no, sheetcode, createdate, dt.Rows[0]["IFKEY"].ToString(), ifkey, esignvalue);
                }
            }

            string pageseq = SelectMaxPageNo().ToString();
            string sortseq = SelectMaxSortSeq(pid).ToString();
            string sheettype = sheetinfo["SHEETTYPE"].ToString();
            string categorycode = sheetinfo["CATEGORYCODE"].ToString();
            string classname = sheetinfo["SHEETPATH"].ToString();

            dt = new DataTable();

            DBService.ExecuteQueryCode("PATIENT_INFO.SELECT_PATIENT_INFO_IO", ref dt, pid, pt_cmhs_no);

            if (dt.Rows.Count > 0)
            {
                string iotype = dt.Rows[0]["OTPT_ADMS_DVCD"].ToString();
                string iodate = dt.Rows[0]["IODATE"].ToString();
                string deptcode = dt.Rows[0]["MDCR_DEPT_CD"].ToString();

                if (DBService.ExecuteNonQueryCode("CHARTPAGE.INSERT_PAGEINFO"
                    , pid
                    , pageseq
                    , createdate
                    , sheettype
                    , iotype
                    , categorycode
                    , sheetcode
                    , pt_cmhs_no
                    , iodate
                    , deptcode
                    , sortseq
                    , classname
                    , ""
                    , ""
                    , "N"
                    , ""
                    , ifkey
                    , ""
                    , "N"
                    , ""
                    ))
                {
                    ref_pageseq = pageseq;
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }

        /// <summary>
        /// 간호기록지, 경과기록지에서 사용
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="sheetcode"></param>
        /// <param name="createdate"></param>
        /// <param name="iotype"></param>
        /// <param name="iodate"></param>
        /// <param name="deptcode"></param>
        /// <returns></returns>
        public static bool InsertPageInfo(string pid, string pt_cmhs_no, string sheetcode, string createdate, string iotype, string iodate, string deptcode, ref string ref_pageseq)
        {
            if (!StringService.IsNotNull(pid, pt_cmhs_no, sheetcode, createdate))
                return false;

            DataRow sheetinfo = GetSheetRow(sheetcode);

            if (sheetinfo == null)
            {
                LxMessage.Show("조회된 EMR 서식 정보가 존재하지 않습니다.\r\n", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }

            DataTable dt = new DataTable();

            DBService.ExecuteQueryCode("CHARTPAGE.SELECT_PAGE_INFO_CREATEDATE_20181210", ref dt, pid, pt_cmhs_no, createdate, sheetcode);

            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["PAGESEQ"] == null)
                    return false;

                ref_pageseq = dt.Rows[0]["PAGESEQ"].ToString();
                return UpdatePageInfo_PageSeq(dt.Rows[0]["PAGESEQ"].ToString());
            }

            string pageseq = SelectMaxPageNo().ToString();
            string sortseq = SelectMaxSortSeq(pid).ToString();
            string sheettype = sheetinfo["SHEETTYPE"].ToString();
            string categorycode = sheetinfo["CATEGORYCODE"].ToString();
            string classname = sheetinfo["SHEETPATH"].ToString();

            if (DBService.ExecuteNonQueryCode("CHARTPAGE.INSERT_PAGEINFO"
                                             , pid
                                             , pageseq
                                             , createdate
                                             , sheettype
                                             , iotype
                                             , categorycode
                                             , sheetcode
                                             , pt_cmhs_no
                                             , iodate
                                             , deptcode
                                             , sortseq
                                             , classname
                                             , ""
                                             , ""
                                             , "N"
                                             , ""
                                             , ""
                                             , ""
                                             , "N"
                                             , ""
                                             ))
            {
                ref_pageseq = pageseq;
                return true;
            }
            else
                return false;
        }

        #endregion :: EMR 차트 페이지 정보 저장

        #region :: EMR 차트 페이지 정보 수정

        public static bool UpdatePageInfo(string pid, string pt_cmhs_no, string sheetcode, string createdate, string pre_ifkey, string ifkey, string esignvalue)
        {
            if (!StringService.IsNotNull(pid, pt_cmhs_no, sheetcode, createdate, pre_ifkey, ifkey, esignvalue))
                return false;

            if (DBService.ExecuteNonQueryCode("CHARTPAGE.UPDATE_PAGEINFO_IFKEY"
                , pid
                , pt_cmhs_no
                , sheetcode
                , pre_ifkey
                , ifkey
                , "N"
                , ""
                ))
            {
                return true;
            }
            else
                return false;
        }

        /// <summary>
        /// EMR 차트 페이지 정보를 수정한다.
        /// </summary>
        /// <param name="pid">환자등록번호</param>
        /// <param name="pt_cmhs_no">환자내원번호</param>
        /// <param name="sheetcode">서식코드</param>
        /// <param name="update_createdate">변경할 작성일자</param>
        /// <param name="ifkey">OCS에서 사용하는 키 값</param>
        /// <param name="esignvalue">전자서명 값</param>
        /// <returns></returns>
        public static bool UpdatePageInfo_CreateDate(string pid, string pt_cmhs_no, string sheetcode, string update_createdate, string ifkey, string esignvalue)
        {
            if (!StringService.IsNotNull(pid, pt_cmhs_no, sheetcode, ifkey, update_createdate, esignvalue))
                return false;

            if (DBService.ExecuteNonQueryCode("CHARTPAGE.UPDATE_PAGEINFO_GENERATEDATE"
                , pid
                , pt_cmhs_no
                , sheetcode
                , ifkey
                , update_createdate
                , "N"
                , ""
                ))
            {
                return true;
            }
            else
                return false;
        }

        public static bool UpdatePageInfo_PageSeq(string pageseq)
        {
            if (!StringService.IsNotNull(pageseq))
                return false;

            if (DBService.ExecuteNonQueryCode("CHARTPAGE.UPDATE_PAGEINFO_PAGESEQ", pageseq))
            {
                return true;
            }
            else
                return false;
        }

        #endregion :: EMR 차트 페이지 정보 수정

        #region :: EMR 차트 페이지 정보 조회

        public static bool ExistPageInfo_IFKey(string pid, string pt_cmhs_no, string sheetcode, string ifkey)
        {
            if (!StringService.IsNotNull(pid, pt_cmhs_no, sheetcode, ifkey))
                return false;

            DataTable dt = new DataTable();

            if (DBService.ExecuteQueryCode("CHARTPAGE.SELECT_PAGE_EXIST_IFKEY", ref dt, pid, pt_cmhs_no, sheetcode, ifkey))
            {
                if (int.Parse(dt.Rows[0]["COUNT"].ToString()) > 0)
                    return true;
            }

            return false;
        }

        #endregion :: EMR 차트 페이지 정보 조회

        #region :: EMR 차트 페이지 정보 삭제

        public static bool DeletePageInfo(string pid, string pt_cmhs_no, string sheetcode, string ifkey)
        {
            if (!StringService.IsNotNull(pid, pt_cmhs_no, sheetcode, ifkey))
                return false;

            if (DBService.ExecuteNonQueryCode("CHARTPAGE.DELETE_PAGE_IFKEY"
                , pid
                , pt_cmhs_no
                , sheetcode
                , ifkey
                ))
            {
                return true;
            }
            else
                return false;
        }

        public static bool DeletePageInfo_CreateData(string pid, string pt_cmhs_no, string sheetcode, string createdate)
        {
            if (!StringService.IsNotNull(pid, pt_cmhs_no, sheetcode, createdate))
                return false;

            if (DBService.ExecuteNonQueryCode("CHARTPAGE.DELETE_PAGE_CREATEDATE"
                , pid
                , pt_cmhs_no
                , sheetcode
                , createdate
                ))
            {
                return true;
            }
            else
                return false;
        }

        #endregion :: EMR 차트 페이지 정보 삭제

        #region :: EMR 차트 입원 전환 시 입원변경 처리

        /// <summary>
        /// 외래환자 입원전환 시 차트 변경
        /// </summary>
        /// <param name="pid">환자등록번호</param>
        /// <param name="o_pt_cmhs_no">외래내원번호</param>
        /// <param name="i_pt_cmhs_no">입원내원번호</param>
        /// <param name="i_adms_dd">입원일자</param>
        /// <param name="i_mdcr_dept_cd">입원진료부서코드</param>
        /// <returns></returns>
        public static bool UpdatePageChangeIOType(string pid, string o_pt_cmhs_no, string i_pt_cmhs_no, string i_adms_dd, string i_mdcr_dept_cd)
        {
            try
            {
                // Chart Page 정보 외래 -> 입원전환
                if (!DBService.ExecuteNonQueryCode("CHARTPAGE.UPDATE_CHANGEIOTYPE", pid, o_pt_cmhs_no, i_pt_cmhs_no, i_adms_dd, i_mdcr_dept_cd))
                    throw new Exception("[" + DBService.ErrorCode + "]" + DBService.ErrorMessage);

                // 간호기록지 정보 외래 -> 입원전환 (2018-07-18, 권재호(우송간호요청))
                // 텍스트 형식
                if (!DBService.ExecuteNonQueryCode("PROGRESS.UPDATE_CHANGEIOTYPE_TXT", pid, o_pt_cmhs_no, i_pt_cmhs_no))
                    throw new Exception("[" + DBService.ErrorCode + "]" + DBService.ErrorMessage);
                // RTF 형식
                if (!DBService.ExecuteNonQueryCode("PROGRESS.UPDATE_CHANGEIOTYPE_RTF", pid, o_pt_cmhs_no, i_pt_cmhs_no))
                    throw new Exception("[" + DBService.ErrorCode + "]" + DBService.ErrorMessage);
                // 이미지 형식
                if (!DBService.ExecuteNonQueryCode("PROGRESS.UPDATE_CHANGEIOTYPE_IMG", pid, o_pt_cmhs_no, i_pt_cmhs_no))
                    throw new Exception("[" + DBService.ErrorCode + "]" + DBService.ErrorMessage);

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
        }

        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pid">환자등록번호</param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="otpt_adms_dvcd"></param>
        /// <param name="generatedate"></param>
        /// <param name="rtf"></param>
        /// <returns></returns>
        public static bool InsertNurseRecord(string pid, string pt_cmhs_no, string otpt_adms_dvcd, string generatedate, string text, ref string msg, bool rtf = false)
        {
            try
            {
                // ProgressSeq를 조회한다.
                DataTable commonseq = new DataTable();

                if (!DBService.ExecuteQueryCode("PROGRESS.SELECT_COMMONSEQ", ref commonseq))
                    throw new Exception("PROGRESS.SELECT_COMMONSEQ\r\n" + DBService.ErrorMessage + "[" + DBService.ErrorCode + "]");

                string s_commonseq = commonseq.Rows[0]["COMMONSEQ"].ToString();
                string[] progress_texts = StringService.SubStringArray(text, 4000);
                string sql = rtf ? "PROGRESS.INSERT_PROGRESSRTF_LIST_20181010"
                                 : "PROGRESS.INSERT_PROGRESSTEXT_LIST_20181010";

                for (int i = 0; i < progress_texts.Length; i++)
                {
                    if (!DBService.ExecuteNonQueryCode(sql
                                                     , pid
                                                     , DateTimeService.ConvertDateTimeStringToFormatString(generatedate, "yyyy-MM-dd HH:mm")
                                                     , s_commonseq
                                                     , "Nurse"
                                                     , (i + 1).ToString()
                                                     , progress_texts[i]
                                                     , otpt_adms_dvcd
                                                     , pt_cmhs_no
                                                     , ""
                                                     , ""
                                                     , ""
                                                     ))
                        throw new Exception(string.Format("{0}\r\n[{1}] {2}", sql, DBService.ErrorCode, DBService.ErrorMessage));
                }

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                msg = ex.Message + Environment.NewLine + ex.StackTrace;
                return false;
            }
        }

        #region :: Page Lock

        public class PageLockService
        {
            private static string m_PatientID = string.Empty;
            private static string m_SheetCode = string.Empty;
            private static string m_LockUserID = string.Empty;
            private static string m_LockUserName = string.Empty;
            private static string m_LockDeptCode = string.Empty;
            private static string m_LockDeptName = string.Empty;
            private static string m_LockPCIP = string.Empty;
            private static DateTime m_LockDate = DateTime.Now;

            public static void Clear()
            {
                m_PatientID = string.Empty;
                m_SheetCode = string.Empty;
                m_LockUserID = string.Empty;
                m_LockUserName = string.Empty;
                m_LockDeptCode = string.Empty;
                m_LockDeptName = string.Empty;
                m_LockPCIP = string.Empty;
                m_LockDate = DateTime.Now;
            }

            public static void ClearLockInfo()
            {
                m_LockUserID = string.Empty;
                m_LockUserName = string.Empty;
                m_LockDeptCode = string.Empty;
                m_LockDeptName = string.Empty;
                m_LockPCIP = string.Empty;
                m_LockDate = DateTime.Now;
            }

            #region Property

            public static string PatientID
            {
                get
                {
                    return m_PatientID;
                }

                set
                {
                    m_PatientID = value;
                }
            }

            public static string SheetCode
            {
                get
                {
                    return m_SheetCode;
                }

                set
                {
                    m_SheetCode = value;
                }
            }

            public static string LockUserID
            {
                get
                {
                    return m_LockUserID;
                }

                set
                {
                    m_LockUserID = value;
                }
            }

            public static string LockUserName
            {
                get
                {
                    return m_LockUserName;
                }
            }

            public static string LockDeptCode
            {
                get
                {
                    return m_LockDeptCode;
                }
                set
                {
                    m_LockDeptCode = value;
                }
            }

            public static string LockDeptName
            {
                get
                {
                    return m_LockDeptName;
                }
            }

            public static string LockPCIP
            {
                get
                {
                    return m_LockPCIP;
                }

                set
                {
                    m_LockPCIP = value;
                }
            }

            public static DateTime LockDate
            {
                get
                {
                    return m_LockDate;
                }
            }

            #endregion

            #region Method

            public static bool IsLocked(string patientid, string sheetcode)
            {
                m_PatientID = patientid;
                m_SheetCode = sheetcode;

                if (StringService.IsNotNull(patientid) && StringService.IsNotNull(sheetcode))
                {
                    SelectPageLock(patientid, sheetcode);

                    if (StringService.IsNotNull(m_LockUserID) && StringService.IsNotNull(m_LockPCIP) &&
                        m_LockUserID.Equals(DOPack.UserInfo.USER_CD) && m_LockPCIP.Equals(ClientEnvironment.IP))
                    {
                        return true;
                    }
                }

                return false;
            }

            public static bool SelectPageLock(string patientid, string sheetcode)
            {
                try
                {
                    ClearLockInfo();

                    if (StringService.IsNotNull(patientid) && StringService.IsNotNull(sheetcode))
                    {
                        DataTable pagelockinfo = new DataTable();

                        if (DBService.ExecuteQueryCode("CHARTPAGE_LOCK.SELECT_PAGELOCK_SHEETCODE", ref pagelockinfo, patientid, sheetcode))
                        {
                            if (pagelockinfo.Rows.Count > 0)
                            {
                                m_LockUserID = pagelockinfo.Rows[0]["USERID"].ToString().Trim();
                                m_LockUserName = pagelockinfo.Rows[0]["USERNAME"].ToString().Trim();
                                m_LockDeptCode = pagelockinfo.Rows[0]["DEPTCODE"].ToString().Trim();
                                m_LockDeptName = pagelockinfo.Rows[0]["DEPTNAME"].ToString().Trim();
                                m_LockPCIP = pagelockinfo.Rows[0]["CLIENTIP"].ToString().Trim();
                                m_LockDate = DateTime.Parse(pagelockinfo.Rows[0]["LOCKEDDATE"].ToString().Trim());

                                return true;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    LogService.ErrorLog(ex);
                }

                return false;
            }

            //public static bool Lock()
            //{
            //    return InsertPageLock(m_PatientID, m_PageSeq, m_LockUserID, m_LockDeptCode);
            //}

            //public static bool Lock(DOPatientInfo patientinfo, int pageseq, DOUserInfo userinfo)
            //{
            //    return InsertPageLock(patientinfo.PID, pageseq, userinfo.USER_CD, userinfo.DEPT_CD);
            //}

            public static bool Lock(string patientid, string sheetcode)
            {
                return InsertPageLock(patientid, sheetcode, DOPack.UserInfo.USER_CD, DOPack.UserInfo.DEPT_CD);
            }

            public static bool InsertPageLock(string patientid, string sheetcode, string userid, string deptcode)
            {
                try
                {
                    if (StringService.IsNotNull(userid) && StringService.IsNotNull(patientid) && StringService.IsNotNull(sheetcode))
                    {
                        DataTable pagelockinfo = new DataTable();

                        if (DBService.ExecuteQueryCode("CHARTPAGE_LOCK.SELECT_PAGELOCK_SHEETCODE", ref pagelockinfo, patientid, sheetcode.ToString()))
                        {
                            if (pagelockinfo.Rows.Count == 0)
                            {
                                if (DBService.ExecuteNonQueryCode("CHARTPAGE_LOCK.INSERT_PAGELOCK_SHEETCODE"
                                    , patientid
                                    , sheetcode
                                    , userid
                                    , deptcode
                                    ))
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    LogService.ErrorLog(ex);
                }

                return false;
            }

            //public static bool UnLock()
            //{
            //    return DeletePageLock();
            //}

            public static bool UnLock(string patientid, string sheetcode)
            {
                m_PatientID = patientid;
                m_SheetCode = sheetcode;

                return DeletePageLock();
            }

            public static bool DeletePageLock()
            {
                try
                {
                    if (DOPack.UserInfo == null)
                        return false;

                    if (m_PatientID != "" && m_SheetCode != "")
                    {
                        if (DBService.ExecuteNonQueryCode("CHARTPAGE_LOCK.DELETE_PAGELOCK_SHEETCODE"
                            , DOPack.UserInfo.USER_CD
                            , m_PatientID
                            , m_SheetCode))
                        {
                            Clear();
                            return true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    LogService.ErrorLog(ex);
                }

                return false;
            }

            /// <summary>
            /// 현재 조회중인 환자의 Lock 페이지중 유저에 의해 Lock이 걸린 페이지를 모두 UnLock
            /// </summary>
            /// <param name="userid"></param>
            /// <returns></returns>
            //public static bool DeletePageLockPatient()
            //{
            //    if (EMPack.PatientInfo == null)
            //        return false;
            //
            //    if (DOPack.UserInfo == null)
            //        return false;
            //
            //    return DeletePageLockPatient(EMPack.PatientInfo.PID, DOPack.UserInfo.USER_CD);
            //}

            /// <summary>
            /// 현재 조회중인 환자의 Lock 페이지중 지정한 유저에 의해 Lock이 걸린 페이지를 모두 UnLock
            /// </summary>
            /// <param name="userid"></param>
            /// <returns></returns>
            public static bool DeletePageLockPatient(string patientid)
            {
                if (DOPack.UserInfo == null)
                    return false;

                return DeletePageLockPatient(patientid, DOPack.UserInfo.USER_CD);
            }

            /// <summary>
            /// 지정한 환자의 Lock 페이지중 유저에 의해 Lock이 걸린 페이지를 모두 UnLock
            /// </summary>
            /// <param name="userid"></param>
            /// <returns></returns>
            public static bool DeletePageLockPatient(DOPatientInfo patientinfo)
            {
                if (patientinfo == null)
                    return false;

                if (DOPack.UserInfo == null)
                    return false;

                return DeletePageLockPatient(patientinfo.PID, DOPack.UserInfo.USER_CD);
            }

            /// <summary>
            /// 지정 환자의 Lock 페이지중 유저에 의해 Lock이 걸린 페이지를 모두 UnLock
            /// </summary>
            /// <param name="userid"></param>
            /// <returns></returns>
            public static bool DeletePageLockPatient(string userid, string patientid)
            {
                try
                {
                    if (patientid != "" && userid != "")
                    {
                        if (DBService.ExecuteNonQueryCode("CHARTPAGE_LOCK.DELETE_PAGELOCK_PATIENT", userid, patientid))
                        {
                            return true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    LogService.ErrorLog(ex);
                }

                return false;
            }

            /// <summary>
            /// 로그인 유저에 의해 Lock이 걸린 페이지를 모두 UnLock
            /// </summary>
            /// <param name="userid"></param>
            /// <returns></returns>
            public static bool DeletePageLockUser()
            {
                if (DOPack.UserInfo == null)
                    return false;

                return DeletePageLockUser(DOPack.UserInfo.USER_CD);
            }

            /// <summary>
            /// 유저에 의해 Lock이 걸린 페이지를 모두 UnLock
            /// </summary>
            /// <param name="userid"></param>
            /// <returns></returns>
            public static bool DeletePageLockUser(DOUserInfo userinfo)
            {
                if (userinfo == null)
                    return false;

                return DeletePageLockUser(userinfo.USER_CD);
            }

            /// <summary>
            /// 유저에 의해 Lock이 걸린 페이지를 모두 UnLock
            /// </summary>
            /// <param name="userid"></param>
            /// <returns></returns>
            public static bool DeletePageLockUser(string userid)
            {
                try
                {
                    if (userid != "")
                    {
                        if (DBService.ExecuteNonQueryCode("CHARTPAGE_LOCK.DELETE_PAGELOCK_USER", userid))
                        {
                            return true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    LogService.ErrorLog(ex);
                }

                return false;
            }

            /// <summary>
            /// Connection이 끊긴 유저들에 의해 Lock이 걸린 페이지를 모두 UnLock 처리
            /// </summary>
            /// <returns></returns>
            public static bool DeletePageLockDisconnect()
            {
                try
                {
                    if (DBService.ExecuteNonQueryCode("CHARTPAGE_LOCK.DELETE_PAGELOCK_DISCONNECT"))
                    {
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    LogService.ErrorLog(ex);
                }

                return false;
            }

            #endregion
        }

        #endregion

        #region :: OCS 서식 접근권한 공통 Method

        public static void GetChartAuthority()
        {

        }

        /// <summary>
        /// Select Export Max Seq
        /// </summary>
        public static int SelectExportMaxSeq()
        {
            DataTable resulttable = new DataTable();

            try
            {
                if (DBService.ExecuteQueryCode("EXPORT_SELECT_EXPORT_MAXSEQ", ref resulttable))
                {
                    if (resulttable.Rows.Count > 0)
                    {
                        return Convert.ToInt32(resulttable.Rows[0]["MAXSEQ"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return -1;
        }

        /// <summary>
        /// 출력 이력 생성
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="ifkey"></param>
        /// <param name="exporttype"></param>
        /// <param name="exportCount"></param>
        public static void InsertExportHistory(string pid, string ptcmhsno, string sheetcode, string ifkey, string exporttype, int exportCount)
        {
            try
            {
                if (!ConfigService.GetConfigValueBool("EM", "CHART_AUTHORITY", "OCS_EXPORT_HIS"))
                    return;

                // Get Export Sequence
                int exportseq = SelectExportMaxSeq();

                DataTable dt = new DataTable();

                if (!DBService.ExecuteQueryCode("CHARTPAGE.SELECT_PAGE_IFKEY", ref dt, pid, ptcmhsno, sheetcode, ifkey))
                    throw new Exception(string.Format("{0} [{1}] {2}", DBService.QueryCode, DBService.ErrorCode, DBService.ErrorMessage));

                // Get Page Sequence
                string pageseq = dt.Rows.Count > 0 ? dt.Rows[0]["PAGESEQ"].ToString() : "";


                if (!int.TryParse(pageseq, out int tmp) || tmp < 0)
                    return;

                if (!DBService.ExecuteNonQueryCode("EXPORT_INSERT_EXPORT_HISTORY"
                    , exportseq.ToString()
                    , exporttype
                    , pid
                    , pageseq
                    , exportCount.ToString()
                    , ClientEnvironment.IP
                    ))
                    throw new Exception(string.Format("{0} [{1}] {2}", DBService.QueryCode, DBService.ErrorCode, DBService.ErrorMessage));
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        /// <summary>
        /// OCS 서식지
        /// </summary>
        public enum NRSheet
        {
            InitAssess,                           // 간호초기평가지
            DischargeCarePlan,                    // 퇴원간호계획지
            EntranceSkinAssess,                   // 입실시 초기피부사정기록
            BedsoreAssessTool,                    // 욕창 관리도구
            BedsorePreventRecord,                 // 욕창 예방활동기록
            BedsoreRecord,                        // 욕창기록지
            FallRiskAssessTool,                   // 낙상위험평가도구
            FallPreventRecord,                    // 낙상예방활동기록지
            PainMediationChartAdult_Main,         // 통증중재차트 3세이상 (초기평가)
            PainMediationChartAdult_Sub,          // 통증중재차트 3세이상 (재평가)
            PainMediationChartChild,              // 통증중재차트 3세미만
            ProbationRecord,                      // 신체보호대 관찰기록지
            WardTransfer,                         // 전동간호기록지
            OpBeforeConfirm,                      // 수술전 간호확인표
            ERInitAssess,                         // 응급실 간호초기평가지
            ERInitAssess_NEDIS,                   // 응급실 간호초기평가지(NEDIS)
            NursingActivityRecord,                // 간호활동 기록지
            Consult,                              // 협진기록지
            TransDept,                            // 전과기록지
        }

        /// <summary>
        /// OCS 서식 삭제 요청을 위한 정보 취득
        /// </summary>
        /// <param name="owner">삭제 요청 사유 PopUp을 띄울 부모 Form</param>
        /// <param name="nr_sheet">OCS 서식 종류</param>
        /// <param name="pid">환자등록번호</param>
        /// <param name="pt_cmhs_no">내원번호</param>
        /// <param name="sqno">일련번호</param>
        /// <param name="sheetcode">삭제 요청 할 서식코드</param>
        /// <param name="pageSeq">삭제 요청 할 PageSeq</param>
        /// <param name="queryList">삭제 요청 목록</param>
        /// <param name="reasonCode">ref 삭제 요청 사유 코드</param>
        /// <param name="reasonCnts">ref 삭제 요청 사유 내용</param>
        /// <param name="message">ref 실패 시 알림 내용</param>
        /// <param name="signed">ref 사인(인증)되었는지의 여부</param>
        /// <param name="aply_sqno">서식 삭제 추가 조건</param>
        /// <returns>true : 성공 or 삭제 사유 사용x / false : 요청실패 또는 오류 발생</returns>
        public static bool GetOCSDeleteChartInfo(IWin32Window owner, NRSheet nr_sheet, string pid, string pt_cmhs_no, string sqno, string sheetcode, 
                                    ref string pageSeq, ref List<QueryFormatInfo> queryList, ref string reasonCode, ref string reasonCnts, ref string message, ref bool signed, string aply_sqno = "")
        {
            signed = false;

            if (!ConfigService.GetConfigValueBool("EM", "CHART_AUTHORITY", "OCS_DELETE_REQ"))
                return true;

            // C1 : 전산 / T2 : 의무기록사 / AUTH_OF_MR : 의무기록사 권한 대행은 사유 입력 제외
            if (DOPack.UserInfo.OCTY_DVCD.Equals("C1") || DOPack.UserInfo.OCTY_DVCD.Equals("T2") || OverallCodeList.GetDataList("AUTH_OF_MR").AsEnumerable().Where(x => x["LWRN_OVRL_CD"].ToString() == DOPack.UserInfo.USER_CD).Any())
                return true;

            // 협진기록지/전과기록지는 제외
            if (!(nr_sheet.Equals(NRSheet.Consult) || nr_sheet.Equals(NRSheet.TransDept)) && string.IsNullOrWhiteSpace(pid) || string.IsNullOrWhiteSpace(pt_cmhs_no) || string.IsNullOrWhiteSpace(sqno))
            {
                LxMessage.ShowError("삭제에 실패하였습니다.\r\n삭제를 위한 값이 충분하지 않아, 삭제할 수 없습니다.\r\n재조회 후 다시 시도해 주세요.");
                return false;
            }

            if (queryList == null) queryList = new List<QueryFormatInfo>();

            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            // 서식별로 query들을 담는다.
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            string uniquekey = string.Empty;

            if (nr_sheet.Equals(NRSheet.PainMediationChartAdult_Sub))
            {
                uniquekey = $"{pid}/{sqno}/{aply_sqno}";
                queryList.Add(new QueryFormatInfo() { QUERYCODE = "OCS_DELETE_MGR.DELETE_NR_TABLES_DT", PARM01 = "NRPARSIF", PARM02 = DOPack.UserInfo.USER_CD, PARM03 = pid, PARM04 = sqno, PARM05 = aply_sqno });    // 통증중재차트3세이상detail (NRPARSIF)
            }
            else if (nr_sheet.Equals(NRSheet.ProbationRecord))
            {
                uniquekey = $"{pid}/{pt_cmhs_no}/{sqno}";
                queryList.Add(new QueryFormatInfo() { QUERYCODE = "OCS_DELETE_MGR.DELETE_NRIBNDIF", PARM01 = "NRIBNDIF", PARM02 = DOPack.UserInfo.USER_CD, PARM03 = pid, PARM04 = pt_cmhs_no, PARM05 = sqno });    // 신체보호대관찰기록지 (NRIBNDIF)
            }
            else if (nr_sheet.Equals(NRSheet.NursingActivityRecord))
            {
                string[] a = sqno.Split('#');
                uniquekey = $"{pid}/{a[0]}/{a[1]}";
                queryList.Add(new QueryFormatInfo() { QUERYCODE = "OCS_DELETE_MGR.DELETE_NRACREIF", PARM01 = "NRACREIF", PARM02 = DOPack.UserInfo.USER_CD, PARM03 = pid, PARM04 = a[0], PARM05 = a[1]});    // 통증중재차트3세이상detail (NRPARSIF)
            }
            else if (nr_sheet.Equals(NRSheet.Consult))
            {
                // 협진기록지 : 메인성만 담는다.
                uniquekey = sqno;
                queryList.Add(new QueryFormatInfo() { QUERYCODE = "OCS_DELETE_MGR.DELETE_CONSULT", PARM01 = "ORCONRMT", PARM02 = DOPack.UserInfo.USER_CD, PARM03 = sqno }); // 진료협진등록메인 (ORCONRMT)
            }
            else if (nr_sheet.Equals(NRSheet.TransDept))
            {
                // 전과기록지 : 메인성만 담는다.
                uniquekey = sqno;
                queryList.Add(new QueryFormatInfo() { QUERYCODE = "OCS_DELETE_MGR.DELETE_TRANS_DEPT", PARM01 = "ORTRDPMT", PARM02 = DOPack.UserInfo.USER_CD, PARM03 = sqno }); // 전과등록메인 (ORTRDPMT)
            }
            else
            {
                uniquekey = $"{pid}/{sqno}";
                string table_name = nr_sheet.Equals(NRSheet.InitAssess)                   ? "NRINEXIF" :     // 간호초기평가지 (NRINEXIF)
                                    nr_sheet.Equals(NRSheet.DischargeCarePlan)            ? "NRDCMTIF" :     // 퇴원간호계획 메인 (NRDCMTIF)
                                    nr_sheet.Equals(NRSheet.EntranceSkinAssess)           ? "NRSINRIF" :     // 입실시 초기피부 사정 기록지 (NRSINRIF)
                                    nr_sheet.Equals(NRSheet.BedsoreAssessTool)            ? "NRSRDTIF" :     // 욕창발생위험사정도구 (NRSRDTIF)
                                    nr_sheet.Equals(NRSheet.BedsorePreventRecord)         ? "NRSRPAIF" :     // 욕창예방활동기록 (NRSRPAIF)
                                    nr_sheet.Equals(NRSheet.BedsoreRecord)                ? "NRSRRCIF" :     // 욕창기록지 (NRSRRCIF)
                                    nr_sheet.Equals(NRSheet.FallRiskAssessTool)           ? "NRFAERIF" :     // 낙상위험평가도구 (NRFAERIF)
                                    nr_sheet.Equals(NRSheet.FallPreventRecord)            ? "NRFANRIF" :     // 낙상 예방 활동기록지정보 (NRFANRIF)
                                    nr_sheet.Equals(NRSheet.PainMediationChartAdult_Main) ? "NRPARMIF" :     // 통증중재차트3세이상main (NRPARMIF)
                                    nr_sheet.Equals(NRSheet.PainMediationChartChild)      ? "NRPARCIF" :     // 통증중재차트3세미만 (NRPARCIF)
                                    //nr_sheet.Equals(NRSheet.ProbationRecord)              ? "NRIBNDIF" :     // 신체보호대관찰기록지 (NRIBNDIF)
                                    nr_sheet.Equals(NRSheet.WardTransfer)                 ? "NRTWNAIF" :     // 전동 간호기록지 메인 (NRTWNAIF)
                                    nr_sheet.Equals(NRSheet.OpBeforeConfirm)              ? "NROPCFIF" :     // 수술 전 간호확인표(NROPCFIF)
                                    nr_sheet.Equals(NRSheet.ERInitAssess)                 ? "NRINERIF" :     // 응급실 간호초기평가지 (NRINERIF)
                                    nr_sheet.Equals(NRSheet.ERInitAssess_NEDIS)           ? "ERINEXIF" :     // 응급실 간호초기평가지_NEDIS (ERINEXIF)
                                    nr_sheet.Equals(NRSheet.NursingActivityRecord)        ? "NRACREIF" :     // 간호활동 기록지()
                                    string.Empty;

                if (!string.IsNullOrWhiteSpace(table_name))
                    queryList.Add(new QueryFormatInfo() { QUERYCODE = "OCS_DELETE_MGR.DELETE_NR_TABLES", PARM01 = table_name, PARM02 = DOPack.UserInfo.USER_CD, PARM03 = pid, PARM04 = sqno }); 
            }

            // 키 값을 담지 못했으므로 삭제 불가.
            if (queryList == null || queryList.Count.Equals(0))
            {
                LxMessage.ShowError("삭제를 위한 키값을 조회하는 중 에러가 발생했습니다.\r\n재조회 후 다시 시도해 주세요.");
                return false;
            }

            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            // 인증 받은 데이터인지 확인해서 인증받지 않았으면 요청없이 삭제 가능하다.
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            if (!(DBService.ExecuteScalar($@"SELECT FN_EM_READ_ESIGN_YN('{queryList[0].PARM01}', '{uniquekey}') FROM DUAL")?.ToString() ?? "N").Equals("Y"))
            {
                queryList.Clear(); 
                queryList = null;
                return true;
            }

            // 욕창기록지/신체보호대관찰기록지/간호활동기록지의 경우 ifKey가 sqno가 아니어서 다른 값(작성일자)으로 대체 함
            string ifKey = nr_sheet.Equals(NRSheet.BedsoreRecord) || nr_sheet.Equals(NRSheet.ProbationRecord) || nr_sheet.Equals(NRSheet.NursingActivityRecord) ? aply_sqno : sqno;

            // EMR 서식지 query도 담는다. (제외 : 통증중재차트 재평가) 
            if (!nr_sheet.Equals(NRSheet.PainMediationChartAdult_Sub) && !string.IsNullOrWhiteSpace(ifKey))
                queryList.Add(new QueryFormatInfo() { QUERYCODE = "CHARTPAGE.DELETE_PAGE_IFKEY", PARM01 = pid, PARM02 = pt_cmhs_no, PARM03 = sheetcode, PARM04 = ifKey }); // EMR

            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            // 동일 데이터로 삭제요청 건이 존재하는지 확인한다.
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            if (!EMBizCommon.RequestDeleteChartDupCheck(pid, queryList, ref message))
            {
                LxMessage.ShowError($"{message}");
                return false;
            }

            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            // EMR서식지의 pageSeq를 취득한다.
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            if (!string.IsNullOrWhiteSpace(ifKey))
            {
                pageSeq = DBService.ExecuteScalar($@" SELECT NVL(PAGESEQ, 0) FROM EMR_INF_CHART_PAGE WHERE PATIENTID = '{pid}' AND IOSEQ =  {pt_cmhs_no} AND SHEETCODE = '{sheetcode}' AND IFKEY =  {ifKey} ").ToString();
                if (string.IsNullOrWhiteSpace(pageSeq) || pageSeq.Equals("0"))
                {
                    LxMessage.ShowError("서식차트 번호를 조회하는 중 에러가 발생했습니다.");
                    return false;
                }
            }

            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            // 협진/전과기록지의 Detail테이블을 여기서 추가하자.
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            if (nr_sheet.Equals(NRSheet.Consult))
            {
                // 협진기록지 : Detail성을 담자
                uniquekey = sqno;
                //queryList.Add(new QueryFormatInfo() { QUERYCODE = "OCS_DELETE_MGR.DELETE_CONSULT", PARM01 = "ORCONRDT", PARM02 = DOPack.UserInfo.USER_CD, PARM03 = sqno }); // 진료협진등록서브 (ORCONRDT)
                queryList.Add(new QueryFormatInfo() { QUERYCODE = "OCS_DELETE_MGR.DELETE_CONSULT", PARM01 = "ORCONDRT", PARM02 = DOPack.UserInfo.USER_CD, PARM03 = sqno }); // 진료회신상병등록 (ORCONDRT)
                queryList.Add(new QueryFormatInfo() { QUERYCODE = "OCS_DELETE_MGR.DELETE_CONSULT", PARM01 = "ORCONAMT", PARM02 = DOPack.UserInfo.USER_CD, PARM03 = sqno }); // 진료회신등록메인 (ORCONAMT)
                //queryList.Add(new QueryFormatInfo() { QUERYCODE = "OCS_DELETE_MGR.DELETE_CONSULT", PARM01 = "ORCONADT", PARM02 = DOPack.UserInfo.USER_CD, PARM03 = sqno }); // 진료회신등록서브 (ORCONADT)
            }
            else if (nr_sheet.Equals(NRSheet.TransDept))
            {
                // 전과기록지 : Detail성을 담는다.
                uniquekey = sqno;
                //queryList.Add(new QueryFormatInfo() { QUERYCODE = "OCS_DELETE_MGR.DELETE_TRANS_DEPT", PARM01 = "ORTRDPDT", PARM02 = DOPack.UserInfo.USER_CD, PARM03 = sqno }); // 전과등록서브 (ORTRDPDT)
                queryList.Add(new QueryFormatInfo() { QUERYCODE = "OCS_DELETE_MGR.DELETE_TRANS_DEPT", PARM01 = "ORTRCNMT", PARM02 = DOPack.UserInfo.USER_CD, PARM03 = sqno }); // 전과회신등록메인 (ORTRCNMT)
                //queryList.Add(new QueryFormatInfo() { QUERYCODE = "OCS_DELETE_MGR.DELETE_TRANS_DEPT", PARM01 = "ORTRCNDT", PARM02 = DOPack.UserInfo.USER_CD, PARM03 = sqno }); // 전과회신등록서브 (ORTRCNDT)
            }

            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            // 삭제 사유를 가져오자.
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            if (!EMBizCommon.RequestDeleteChartReason(owner, sheetcode, ref reasonCode, ref reasonCnts, ref message))
            {
                LxMessage.ShowError($"삭제요청이 취소되었습니다.\r\n{message}");
                return false;
            }

            signed = true;
            return true;
        }

        /// <summary>
        /// 삭제 요청 사유를 가져온다.
        /// </summary>
        /// <param name="owner">삭제 요청 사유 PopUp을 띄울 부모 Form</param>
        /// <param name="sheetCode">삭제 요청 할 서식코드</param>
        /// <param name="reasonCode">ref 삭제 요청사유 코드</param>
        /// <param name="reasonCnts">ref 삭제 요청사유 내용</param>
        /// <param name="message">ref 실패 시 알림 내용</param>
        /// <returns>true : 삭제 요청사유 기재 / false : 삭제 요청사유 미기재</returns>
        public static bool RequestDeleteChartReason(IWin32Window owner, string sheetCode, ref string reasonCode, ref string reasonCnts, ref string message)
        {
            try
            {
                using (popOcsInputReason pop = new popOcsInputReason(sheetCode))
                {
                    if (pop.ShowDialog(owner) == DialogResult.OK)
                    {
                        reasonCode = pop.ReasonCode;
                        reasonCnts = pop.ReasonCnts;
                        return true;
                    }
                }

                message = "입력을 취소하였습니다.";
                return false;
            }
            catch (Exception ex)
            {
                message = ex.Message;

                LogService.ErrorLog(ex);
                return false;
            }
        }

        /// <summary>
        /// 삭제 요청할 데이터의 삭제 요청정보 중복 체크
        /// </summary>
        /// <param name="pid">삭제 요청 대상의 환자등록번호</param>
        /// <param name="deleteQueryList">삭제 요청 목록</param>
        /// <param name="message">ref 실패 시 알림 내용</param>
        /// <returns>true : 정상 / false : 중복 존재 또는 오류 발생</returns>
        public static bool RequestDeleteChartDupCheck(string pid, List<QueryFormatInfo> deleteQueryList, ref string message)
        {
            try
            {
                DataTable dt = new DataTable();

                if (!DBService.ExecuteQueryCode("OCS_DELETE_MGR.SELECT_LIST_TO_PATIENTID", ref dt, pid))
                    throw new Exception($"[{DBService.ErrorCode}] {DBService.ErrorMessage}");

                var dupList = dt.AsEnumerable().Where(x => deleteQueryList.Any(y => (y.QUERYCODE??"") == x["QUERYCODE"].ToString() &&
                                                                                    (y.PARM01   ??"") == x["PARM01"   ].ToString() &&
                                                                                    (y.PARM02   ??"") == x["PARM02"   ].ToString() &&
                                                                                    (y.PARM03   ??"") == x["PARM03"   ].ToString() &&
                                                                                    (y.PARM04   ??"") == x["PARM04"   ].ToString() &&
                                                                                    (y.PARM05   ??"") == x["PARM05"   ].ToString() &&
                                                                                    (y.PARM06   ??"") == x["PARM06"   ].ToString() &&
                                                                                    (y.PARM07   ??"") == x["PARM07"   ].ToString() &&
                                                                                    (y.PARM08   ??"") == x["PARM08"   ].ToString() &&
                                                                                    (y.PARM09   ??"") == x["PARM09"   ].ToString() &&
                                                                                    (y.PARM10   ??"") == x["PARM10"   ].ToString()));

                // 중복된 요청정보가 존재하는지 여부
                if (dupList.Any())
                {
                    DataRow dr = dupList.First();

                    string reqDate = dr["DELETEDATE"].ToString();
                    string reqUserCd = dr["USER_CD"].ToString();
                    string reqUserNm = UserList.GetName(reqUserCd);

                    if (DateTimeService.IsDateTime(reqDate))
                        reqDate = DateTimeService.ConvertDateStringToFormatString(reqDate, "yyyy년 MM월 dd일 HH시 mm분");

                    message = $"{reqUserNm}({reqUserCd})님이 {reqDate}에\r\n삭제요청하였습니다.";
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                LogService.ErrorLog(ex);
                return false;
            }
        }

        /// <summary>
        /// 차트 삭제 요청 처리
        /// </summary>
        /// <param name="pid">환자등록번호</param>
        /// <param name="deleteReqId">삭제 요청자의 ID</param>
        /// <param name="pageSeq">삭제 요청 할 PageSeq</param>
        /// <param name="reasonCode">삭제 요청 사유 코드</param>
        /// <param name="reasonCnts">삭제 요청 사유 내용</param>
        /// <param name="pageDeleteYN">삭제 요청할 Page의 삭제 여부</param>
        /// <param name="deleteQueryList">삭제 요청 목록</param>
        /// <param name="message">ref 실패 시 알림 내용</param>
        /// <returns>true : 성공 / false : 요청실패 또는 오류 발생</returns>
        public static bool RequestDeleteChart(string pid, string deleteReqId, string pageSeq, string reasonCode, string reasonCnts, bool pageDeleteYN, List<QueryFormatInfo> deleteQueryList, ref string message)
        {
            try
            {
                DataTable dtSequence = new DataTable();

                if (!DBService.ExecuteQueryCode("OCS_DELETE_MGR.SELECT_SEQ_OCS_DELETE", ref dtSequence))
                    throw new Exception($"[{DBService.QueryCode}]/[{DBService.ErrorCode}]/{DBService.ErrorMessage}");

                if (dtSequence.Rows.Count <= 0)
                    throw new Exception("조회된 데이터가 없습니다. [OCS_DELETE_MGR.SELECT_SEQ_OCS_DELETE]");

                if (!int.TryParse(dtSequence.Rows[0][0].ToString(), out int sqno))
                    throw new Exception("[EMR_SEQ_OCS_DELETE.NEXTVAL Int 형변환 오류]");

                // ######################################################################
                // Insert EMR_INF_OCS_DELETE
                // ######################################################################
                if (!DBService.ExecuteNonQueryCode("OCS_DELETE_MGR.INSERT_OCS_DELETE"
                    , sqno.ToString()          // SQNO
                    , deleteReqId              // USER_CD
                    , pid                      // PATIENTID
                    , pageSeq                  // PAGESEQ
                    , reasonCode               // REASONCODE
                    , reasonCnts               // REASONCNTS
                    , pageDeleteYN ? "Y" : "N" // PAGE_DEL_YN
                    , "N"                      // DEL_RES_YN
                    , ""                       // DEL_RES_DT
                    , ""                       // DEL_RES_ID
                    , "", "", "", "", ""       // ETC_USE_CNTS_?
                    ))
                    throw new Exception($"[{DBService.QueryCode}]/[{DBService.ErrorCode}]/{DBService.ErrorMessage}");

                foreach (QueryFormatInfo query in deleteQueryList)
                {
                    DataTable dtMaxAplySqno = new DataTable();

                    if (!DBService.ExecuteQueryCode("OCS_DELETE_MGR.SELECT_DETAIL_MAX_APLYSQNO", ref dtMaxAplySqno, sqno.ToString()))
                        throw new Exception($"[{DBService.QueryCode}]/[{DBService.ErrorCode}]/{DBService.ErrorMessage}");

                    if (!int.TryParse(dtMaxAplySqno.Rows[0][0].ToString(), out int aply_sqno))
                        throw new Exception("[EMR_INF_OCS_DELELTE MaxAplySqno Int 형변환 오류]");

                    // ######################################################################
                    // Insert EMR_INF_OCS_DELETE_DETAIL
                    // ######################################################################
                    if (!DBService.ExecuteNonQueryCode("OCS_DELETE_MGR.INSERT_OCS_DELETE_DETAIL"
                        , sqno.ToString()      // SQNO
                        , aply_sqno.ToString() // APLY_SQNO
                        , query.QUERYCODE??""  // QUERYCODE
                        , query.PARM01   ??""  // PARM01
                        , query.PARM02   ??""  // PARM02
                        , query.PARM03   ??""  // PARM03
                        , query.PARM04   ??""  // PARM04
                        , query.PARM05   ??""  // PARM05
                        , query.PARM06   ??""  // PARM06
                        , query.PARM07   ??""  // PARM07
                        , query.PARM08   ??""  // PARM08
                        , query.PARM09   ??""  // PARM09
                        , query.PARM10   ??""  // PARM10
                        , "", "", "", "", ""   // ETC_USE_CNTS_?
                        ))
                        throw new Exception($"[{DBService.QueryCode}]/[{DBService.ErrorCode}]/{DBService.ErrorMessage}");
                }

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                message = $"삭제요청 중 오류가 발생하였습니다.\r\n{ex.Message}";
                return false;
            }
        }

        #endregion :: OCS 서식 접근권한 공통 Method

        #region 공인인증 전자서명

        public static bool SetESignOrderPickUp(string pid, string dlwt_uniq_no, ref string msg)
        {
            try
            {
                if (!ConfigService.GetConfigValueBool("%", "ESIGN_CONFIG", "USE_YN") || !ESignService.IsLogined)
                    return true;

                DataTable dt = new DataTable();
                DBService.ExecuteDataTable($"select a.* from orordrrt a, orsqtpif b where a.pid = b.pid and a.pt_cmhs_no = b.pt_cmhs_no and a.mdcr_dd = b.mdcr_dd and a.prsc_sqno = b.prsc_sqno and b.pid = '{pid}' and b.dlwt_uniq_no = '{dlwt_uniq_no}'", ref dt);

                if (dt.Rows.Count <= 0)
                    return true;

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string prsc_uniq_no = dt.Rows[i]["PRSC_UNIQ_NO"].ToString();

                    // 처방일자 + 부서 + 의사 + 코드 + 1회량 + 횟수 + 일수 + 용법
                    string keyData = dt.Rows[i]["MDCR_DD"].ToString() + dt.Rows[i]["MDCR_DEPT_CD"].ToString() + dt.Rows[i]["MDCR_DR_CD"].ToString()
                                   + dt.Rows[i]["PRSC_CD"].ToString() + dt.Rows[i]["ONTM_QTY"].ToString() + dt.Rows[i]["NOTM"].ToString() + dt.Rows[i]["NODY"].ToString() + dt.Rows[i]["AOMD_MTHD_CD"].ToString();

                    string refHash = "";
                    string refSign = "";
                    string refMsg = "";

                    if (!ESignService.GetESignValue(keyData, ref refHash, ref refSign, ref refMsg))
                    {
                        msg = refMsg;
                        return false;
                    }

                    if (!DBService.ExecuteNonQuery($"update oradecma set etc_use_cnts_11 = '{refSign}' where pid = '{pid}' and prsc_uniq_no = '{prsc_uniq_no}'"))
                    {
                        msg = string.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage);
                        return false;
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                msg = ex.Message;
                return false;
            }
        }

        public static bool SetESignOrderUniqNo(string pid, string prsc_uniq_no, ref string msg)
        {
            try
            {
                if (!ConfigService.GetConfigValueBool("%", "ESIGN_CONFIG", "USE_YN") || !ESignService.IsLogined)
                    return true;

                DataTable dt = new DataTable();
                DBService.ExecuteDataTable($"select * from orordrrt where pid = '{pid}' and prsc_uniq_no = '{prsc_uniq_no}'", ref dt);

                if (dt.Rows.Count <= 0)
                {
                    msg = "일치하는 처방정보가 존재하지 않습니다.";
                    return false;
                }

                // 처방일자 + 부서 + 의사 + 코드 + 1회량 + 횟수 + 일수 + 용법
                string keyData = dt.Rows[0]["MDCR_DD"].ToString() + dt.Rows[0]["MDCR_DEPT_CD"].ToString()  + dt.Rows[0]["MDCR_DR_CD"].ToString()
                               + dt.Rows[0]["PRSC_CD"].ToString() + dt.Rows[0]["ONTM_QTY"].ToString() + dt.Rows[0]["NOTM"].ToString() + dt.Rows[0]["NODY"].ToString() + dt.Rows[0]["AOMD_MTHD_CD"].ToString();

                string refHash = "";
                string refSign = "";
                string refMsg = "";

                if (!ESignService.GetESignValue(keyData, ref refHash, ref refSign, ref refMsg))
                {
                    msg = refMsg;
                    return false;
                }

                if (!DBService.ExecuteNonQuery($"update etc_use_cnts_11 = '{refSign}' from oradecma where pid = '{pid}' and prsc_uniq_no = '{prsc_uniq_no}'"))
                {
                    msg = string.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage);
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                msg = ex.Message;
                return false;
            }
        }

        public static string GetSignData(string value, ref string msg)
        {
            if (!ConfigService.GetConfigValueBool("%", "ESIGN_CONFIG", "USE_YN") || !ESignService.IsLogined)
                return "";

            string refHash = "";
            string refSign = "";

            if (!ESignService.GetESignValue(value, ref refHash, ref refSign, ref msg))
                return "";

            return refSign;
        }

        #endregion

        #region OCS Data Sign

        /// <summary>
        /// 전자서명이 요구되는 환자를 조회 및 전자서명 한다.
        /// </summary>
        public static void RequireSignPatient(string date)
        {
            DataTable dtSignList = new DataTable();
            dtSignList.Columns.Add("TABLE_NAME");
            dtSignList.Columns.Add("UNIQUEKEY");
            dtSignList.Columns.Add("QUERY");

            //######################################################################
            // 퇴원환자
            //######################################################################
            DataTable dtDschPatient = new DataTable();

            DBService.ExecuteDataTable($@"
SELECT A.PID
     , A.PT_CMHS_NO
  FROM PAIPATRT A
 WHERE A.ROW_STAT_DVCD = 'A'
   AND A.MAIN_SUB_ADMS_DVCD = 'J'
   AND A.DSCH_DD = TO_CHAR(TO_DATE('{date}') - 7, 'YYYYMMDD')", ref dtDschPatient);

            if (dtDschPatient.Rows.Count > 0)
            {
                for (int i = 0; i < dtDschPatient.Rows.Count; i++)
                    SaveOcsSignTotalData(dtDschPatient.Rows[i]["PID"].ToString(), dtDschPatient.Rows[i]["PT_CMHS_NO"].ToString(), dtSignList);
            }

            //######################################################################
            // FlowSheet, Acting, VitalSign, 수술전간호확인표
            //######################################################################
            SaveOcsSignData(dtSignList, $"NRFLSNIF", $"SELECT * FROM NRFLSNIF WHERE CHEK_DD = TO_CHAR(TO_DATE('{date}') - 2, 'YYYYMMDD') AND DEL_YN = 'A'");
            SaveOcsSignData(dtSignList, $"NRFLSFIF", $"SELECT * FROM NRFLSFIF WHERE CHEK_DD = TO_CHAR(TO_DATE('{date}') - 2, 'YYYYMMDD') AND DEL_YN = 'A'");
            SaveOcsSignData(dtSignList, $"NRFLSIIF", $"SELECT * FROM NRFLSIIF WHERE CHEK_DD = TO_CHAR(TO_DATE('{date}') - 2, 'YYYYMMDD')");
            SaveOcsSignData(dtSignList, $"NRIACTMA", $"SELECT * FROM NRIACTMA WHERE MDCR_DD = TO_CHAR(TO_DATE('{date}') - 2, 'YYYYMMDD')");
            SaveOcsSignData(dtSignList, $"NRVSCRIF", $"SELECT * FROM NRVSCRIF WHERE CHEK_DD = TO_CHAR(TO_DATE('{date}') - 2, 'YYYYMMDD') AND DEL_YN = 'A'");
            SaveOcsSignData(dtSignList, $"NROPCFIF", $"SELECT * FROM NROPCFIF WHERE OP_DD   = TO_CHAR(TO_DATE('{date}') - 2, 'YYYYMMDD') AND DEL_YN = 'A'");

            //######################################################################
            // 전자동의서
            //######################################################################
            string sqlEMR = $@"
SELECT PATIENTID, PAGESEQ, FILEPATH, CREATEUSER
  FROM EMR_INF_CHART_PAGE A
 WHERE A.GENERATEDATE LIKE TO_CHAR(TO_DATE('{date}') - 7, 'YYYYMMDD') || '%'
   AND A.SHEETTYPE IN ('A', 'Q')
   AND A.ENABLEFLAG = 'Y'
   AND A.TEMPFLAG = 'N'";

            DataTable dtEMR = new DataTable();
            DBService.ExecuteDataTable(sqlEMR, ref dtEMR);

            if (dtEMR.Rows.Count > 0)
            {
                using (FTPService ftp = new FTPService(
                    ConfigService.GetConfigValueString("EM", "EMR_FTP_SERVER", "IP"),
                    ConfigService.GetConfigValueInt("EM", "EMR_FTP_SERVER", "PORT"),
                    ConfigService.GetConfigValueString("EM", "EMR_FTP_SERVER", "USERID"),
                    ConfigService.GetConfigValueString("EM", "EMR_FTP_SERVER", "PASSWORD")))
                {
                    try
                    {
                        DBService.BeginTransaction();

                        foreach (DataRow dr in dtEMR.Rows)
                        {
                            string pid = dr["PATIENTID"].ToString();
                            string pageseq = dr["PAGESEQ"].ToString();
                            string serverPath = dr["FILEPATH"].ToString();
                            string clientPath = Path.Combine(ClientEnvironment.TempFolder, DateTime.Now.ToString("yyyyMMddHHmmssfff") + Path.GetExtension(serverPath) ?? "");
                            string createuser = dr["CREATEUSER"].ToString();

                            if (ftp.Download(serverPath, clientPath))
                            {
                                using (StreamReader sr = new StreamReader(clientPath))
                                {
                                    string fileText = sr.ReadToEnd();

                                    string h = "", s = "", c = "", m = "";

                                    if (!ESignService.Hash(createuser, fileText, ref h, ref c, ref m))
                                        throw new Exception($"전자서명 중 오류가 발생하였습니다. [ESignService.Hash : {c} / {m}]");

                                    if (!ESignService.SignData(createuser, h, ref s, ref c, ref m))
                                        throw new Exception($"전자서명 중 오류가 발생하였습니다. [ESignService.SignData : {c} / {m}]");

                                    if (!DBService.ExecuteNonQuery($"update emr_inf_chart_page set esignflag = 'Y', esignkey = '{s}' where patientid = '{pid}' and pageseq = '{pageseq}'"))
                                        throw new Exception($"[{DBService.ErrorCode}] {DBService.ErrorMessage}");
                                }
                            }
                        }

                        DBService.CommitTransaction();
                    }
                    catch (Exception ex)
                    {
                        DBService.RollbackTransaction();
                        LogService.ErrorLog(ex);
                    }
                }
            }

            SaveSignData(dtSignList);

            dtSignList.Clear();
            dtSignList.Dispose();

            dtDschPatient.Clear();
            dtDschPatient.Dispose();

            dtEMR.Clear();
            dtEMR.Dispose();
        }

        /// <summary>
        /// 전자서명 데이터를 저장한다.
        /// </summary>
        /// <param name="dt">저장할 DataList</param>
        public static bool SaveSignData(DataTable dt)
        {
            // TABLE_NAME, UNIQUEKEY, QUERY Column 중 존재하지 않는 컬럼이 있는지 체크
            if (new string[] { "TABLE_NAME", "UNIQUEKEY", "QUERY" }.Any(s => !dt.Columns.Cast<DataColumn>().Select(x => x.ColumnName).Any(col => col == s)))
            {
                LxMessage.ShowInformation("EMBizCommon.SaveSignData.dt의 Column 중 누락 항목이 존재합니다.");
                return false;
            }

            string sqltext_InsertSign = @"
INSERT INTO EMR_INF_OCS_SIGN
       ( SQNO, TABLE_NAME, UNIQUEKEY, ESIGNKEY, SIGNDATE
       , SIGNUSER, SIGNSTATUS, ETC_USE_CNTS_1, ETC_USE_CNTS_2, ETC_USE_CNTS_3
       , ETC_USE_CNTS_4, ETC_USE_CNTS_5, CREATEDATE, CREATEUSER, MODIFYDATE
       , MODIFYUSER )
";

            string sqltext_DeleteSign = @"
DELETE FROM EMR_INF_OCS_SIGN
 WHERE {0}
";

            try
            {
                DBService.BeginTransaction();

                // 1000건씩 Insert
                var list = dt.AsEnumerable();
                // Current Index, Total Count, Split Range
                int cur = 0, tot = dt.Rows.Count, range = 1000;

                while (cur < tot)
                {
                    var item = list.Skip(cur).Take(range);

                    if (item.Any())
                    {
                        int index = 0;
                        string deleteQuery = string.Format(sqltext_DeleteSign, string.Join(" OR ", item.Select(x => $"(TABLE_NAME = '{x["TABLE_NAME"].ToString()}' AND UNIQUEKEY = '{x["UNIQUEKEY"].ToString()}')")));
                        string insertQuery = sqltext_InsertSign + string.Join("\r\nUNION ALL\r\n", item.Select(s => string.Format(s["QUERY"].ToString(), ++index)));

                        // 중복된 UniqueKey는 삭제 후 저장한다.
                        if (!DBService.ExecuteNonQuery(deleteQuery))
                            throw new Exception($"[{DBService.ErrorCode}] {DBService.ErrorMessage}");


                        if (!DBService.ExecuteNonQuery(insertQuery))
                            throw new Exception($"[{DBService.ErrorCode}] {DBService.ErrorMessage}");

                        deleteQuery = string.Empty;
                        insertQuery = string.Empty;
                    }

                    cur += range;
                }

                for (int i = list.Count() - 1; i >= 0; i--)
                    list.ElementAt(i).Delete();

                DBService.CommitTransaction();
                return true;
            }
            catch (Exception ex)
            {
                DBService.RollbackTransaction();
                LogService.ErrorLog(ex);
                return false;
            }
        }

        public static void SaveOcsSignTotalData(string pid, string ptcmhsno, DataTable dt)
        {
            try
            {
                SaveOcsSignData(dt, "NRBSTRIF", $"SELECT * FROM NRBSTRIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRDCMTIF", $"SELECT * FROM NRDCMTIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRDCTPIF", $"SELECT * FROM NRDCTPIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRDCAPIF", $"SELECT * FROM NRDCAPIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRFAERIF", $"SELECT * FROM NRFAERIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRFANRIF", $"SELECT * FROM NRFANRIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRFANTIF", $"SELECT * FROM NRFANTIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
              //SaveOcsSignData(dt, "NRFLSNIF", $"SELECT * FROM NRFLSNIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
              //SaveOcsSignData(dt, "NRFLSFIF", $"SELECT * FROM NRFLSFIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
              //SaveOcsSignData(dt, "NRFLSIIF", $"SELECT * FROM NRFLSIIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno}");
              //SaveOcsSignData(dt, "NRIACTMA", $"SELECT * FROM NRIACTMA WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno}");
                SaveOcsSignData(dt, "NRIBNDIF", $"SELECT * FROM NRIBNDIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRINEXIF", $"SELECT * FROM NRINEXIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRIOSFIF", $"SELECT * FROM NRIOSFIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRIOSBIF", $"SELECT * FROM NRIOSBIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRIOSDIF", $"SELECT * FROM NRIOSDIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRIOSOIF", $"SELECT * FROM NRIOSOIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
              //SaveOcsSignData(dt, "NROPCFIF", $"SELECT * FROM NROPCFIF WHERE OP_REFR_UNIQ_NO IN (SELECT Z.MLAP_UNIQ_NO FROM OPREFRMA Z WHERE Z.PID = '{pid}' AND Z.PT_CMHS_NO = {ptcmhsno} AND Z.CNCL_YN = 'N' AND Z.OP_STAT_DVCD <> 'CAN' AND Z.ROW_STAT_DVCD = 'A') AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRPARCIF", $"SELECT * FROM NRPARCIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRPARMIF", $"SELECT * FROM NRPARMIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRPARSIF", $"SELECT * FROM NRPARSIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRSINRIF", $"SELECT * FROM NRSINRIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRSRDTIF", $"SELECT * FROM NRSRDTIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRSRPAIF", $"SELECT * FROM NRSRPAIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRSRRCIF", $"SELECT * FROM NRSRRCIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRTWNAIF", $"SELECT * FROM NRTWNAIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "NRTWNBIF", $"SELECT * FROM NRTWNBIF A WHERE EXISTS (SELECT 1 FROM NRTWNAIF Z WHERE Z.PID = A.PID AND Z.SQNO = A.SQNO AND Z.PID = '{pid}' AND Z.PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A') AND DEL_YN = 'A'");
              //SaveOcsSignData(dt, "NRVSCRIF", $"SELECT * FROM NRVSCRIF WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "ORCONRMT", $"SELECT * FROM ORCONRMT WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "ORCONRDT", $"SELECT * FROM ORCONRDT WHERE MLAP_UNIQ_NO IN ( SELECT MLAP_UNIQ_NO FROM ORCONRMT WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} )");
                SaveOcsSignData(dt, "ORCONDRT", $"SELECT * FROM ORCONDRT WHERE MLAP_UNIQ_NO IN ( SELECT MLAP_UNIQ_NO FROM ORCONRMT WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A' )");
                SaveOcsSignData(dt, "ORCONAMT", $"SELECT * FROM ORCONAMT WHERE MLAP_UNIQ_NO IN ( SELECT MLAP_UNIQ_NO FROM ORCONRMT WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A' )");
                SaveOcsSignData(dt, "ORCONADT", $"SELECT * FROM ORCONADT WHERE MLAP_UNIQ_NO IN ( SELECT MLAP_UNIQ_NO FROM ORCONRMT WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno})");
                SaveOcsSignData(dt, "ORTRDPMT", $"SELECT * FROM ORTRDPMT WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A'");
                SaveOcsSignData(dt, "ORTRDPDT", $"SELECT * FROM ORTRDPDT WHERE DPTF_UNIQ_NO IN ( SELECT DPTF_UNIQ_NO FROM ORTRDPMT WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} )");
                SaveOcsSignData(dt, "ORTRCNMT", $"SELECT * FROM ORTRCNMT WHERE DPTF_UNIQ_NO IN ( SELECT DPTF_UNIQ_NO FROM ORTRDPMT WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} AND DEL_YN = 'A' )");
                SaveOcsSignData(dt, "ORTRCNDT", $"SELECT * FROM ORTRCNDT WHERE DPTF_UNIQ_NO IN ( SELECT DPTF_UNIQ_NO FROM ORTRDPMT WHERE PID = '{pid}' AND PT_CMHS_NO = {ptcmhsno} )");
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        public static void SaveOcsSignData(DataTable dt, string tableName, string sqlBySign)
        {
            try
            {
                string sqltext = $@"
SELECT a.COLUMN_NAME
  FROM USER_TAB_COLS A
     , USER_INDEXES B
     , USER_IND_COLUMNS C
 WHERE A.TABLE_NAME = '{tableName}'
   AND A.TABLE_NAME = B.TABLE_NAME
   AND B.INDEX_NAME = C.INDEX_NAME
   AND B.TABLE_NAME = C.TABLE_NAME
   AND C.COLUMN_NAME = A.COLUMN_NAME
   AND B.UNIQUENESS = 'UNIQUE'
 ORDER BY A.COLUMN_ID
";

                // Table RowData의 UniqueKey 값을 가져오기 위해 Unique Index Column들을 조회한다.
                DataTable dtUniqueColumnList = new DataTable();

                if (!DBService.ExecuteDataTable(sqltext, ref dtUniqueColumnList))
                    throw new Exception($"[{DBService.ErrorCode}] {DBService.ErrorMessage}");

                if (dtUniqueColumnList.Rows.Count <= 0)
                    throw new Exception($"{tableName} 테이블의 Unique Key가 지정되지 않았습니다.");

                DataTable dtTarget = new DataTable();

                // 전자서명 대상 데이터 조회
                if (!DBService.ExecuteDataTable(sqlBySign, ref dtTarget))
                    throw new Exception($"[{DBService.ErrorCode}] {DBService.ErrorMessage}");

                foreach (DataRow dr in dtTarget.Rows)
                {
                    string msg = string.Empty;
                    string user_cd = "LIME";

                    // 전자서명 인증서 사용자 설정
                    switch (tableName)
                    {
                        case "NRIACTMA": // Acting
                            if (dtTarget.Columns.Contains("SKIP_RGSTR_ID") && !string.IsNullOrWhiteSpace(dr["SKIP_RGSTR_ID"].ToString()))
                                user_cd = dr["SKIP_RGSTR_ID"].ToString();
                            else if (dtTarget.Columns.Contains("ACTG_RGSTR_ID") && !string.IsNullOrWhiteSpace(dr["ACTG_RGSTR_ID"].ToString()))
                                user_cd = dr["ACTG_RGSTR_ID"].ToString();
                            break;

                        case "NRBSTRIF": // BST Sheet
                            if (dtTarget.Columns.Contains("WRTR_ID") && !string.IsNullOrWhiteSpace(dr["WRTR_ID"].ToString()))
                                user_cd = dr["WRTR_ID"].ToString();
                            break;

                        case "NRDCMTIF": // 퇴원간호계획 Main
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRDCTPIF": // 퇴원간호계획 투약
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRDCAPIF": // 퇴원간호계획 예약
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRFAERIF": // 낙상 위험 평가 도구
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRFANRIF": // 낙상 예방 활동기록지정보
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRFANTIF": // 낙상 예방 활동기록 관련요인
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRFLSNIF": // 중환자실 FlowSheet
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRFLSFIF": // 중환자실 FlowSheet Fluid
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRFLSIIF": // 중환자실 FlowSheet 시간간격
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRIBNDIF": // 억제대 관찰 기록지
                            if (dtTarget.Columns.Contains("WRTR_ID") && !string.IsNullOrWhiteSpace(dr["WRTR_ID"].ToString()))
                                user_cd = dr["WRTR_ID"].ToString();
                            break;

                        case "NRINEXIF": // 간호초기평가정보
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRIOSFIF": // 입원환자 I & O Sheet(Fluid)
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRIOSBIF": // 입원환자 I & O Sheet(Blood)
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRIOSDIF": // 입원환자 I & O Sheet(Diet)
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRIOSOIF": // 입원환자 I & O Sheet(OutPut)
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NROPCFIF": // 수술전 간호확인표
                            if (dtTarget.Columns.Contains("ETC_USE_CNTS_1") && !string.IsNullOrWhiteSpace(dr["ETC_USE_CNTS_1"].ToString()))
                                user_cd = dr["ETC_USE_CNTS_1"].ToString();
                            else if (dtTarget.Columns.Contains("ETC_USE_CNTS_2") && !string.IsNullOrWhiteSpace(dr["ETC_USE_CNTS_2"].ToString()))
                                user_cd = dr["ETC_USE_CNTS_2"].ToString();
                            break;

                        case "NRPARCIF": // 통증평가중재차트 3세미만
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRPARMIF": // 통증중재차트3세이상 메인
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRPARSIF": // 통증중재차트3세이상 상세
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRSINRIF": // 입실시 초기피부 사정 기록지
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRSRDTIF": // 욕창발생위험사정도구
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRSRPAIF": // 욕창예방 간호활동 기록
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRSRRCIF": // 욕창 기록지 정보
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRTWNAIF": // 전동 간호기록지 메인
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRTWNBIF": // 전동 간호기록지 약품
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "NRVSCRIF": // VitalSign Chart
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "ORCONRMT": // 협진 의뢰
                            if (dtTarget.Columns.Contains("REFR_DR_CD"))
                                user_cd = dr["REFR_DR_CD"].ToString();
                            break;

                        case "ORCONRDT": // 협진 의뢰 내용
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "ORCONAMT": // 협진 회신
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "ORCONDRT": // 협진 회신 상병
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "ORCONADT": // 협진 회신 내용
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "ORTRDPMT": // 전과 의뢰
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "ORTRDPDT": // 전과 의뢰 내용
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "ORTRCNMT": // 전과 회신
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;

                        case "ORTRCNDT": // 전과 회신 내용 
                            if (dtTarget.Columns.Contains("RGSTR_ID"))
                                user_cd = dr["RGSTR_ID"].ToString();
                            break;
                    }

                    // Unique Column Data
                    string uniquekey = string.Join("/", dtUniqueColumnList.AsEnumerable().Select(col => dr[col["COLUMN_NAME"].ToString()].ToString()));

                    // All Column Data
                    string allData = string.Join("/", dtTarget.Columns.Cast<DataColumn>().Select(col => dr[col.ColumnName].ToString()));

                    // ESign Data
                    string signData = string.Empty;

                    // ESign Hash
                    string hash = string.Empty;

                    if (!GetSignByUserCode(user_cd, allData, ref hash, ref signData, ref msg))
                        throw new Exception(msg);

                    dt.Rows.Add(dt.NewRow());
                    dt.Rows[dt.Rows.Count - 1]["TABLE_NAME"] = tableName;
                    dt.Rows[dt.Rows.Count - 1]["UNIQUEKEY"] = uniquekey;
                    dt.Rows[dt.Rows.Count - 1]["QUERY"] = $@"
SELECT (SELECT NVL(MAX(SQNO), 0) + {{0}} FROM EMR_INF_OCS_SIGN), '{tableName}', '{uniquekey}', '{signData}', @TODT
       , '@USCD', 'A', '', '', ''
       , '', '', @TODT, '@USCD', @TODT
       , '@USCD'
  FROM DUAL
";
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        public static void SavePartSignData(string tableName, string sqlBySign)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("TABLE_NAME");
            dt.Columns.Add("UNIQUEKEY");
            dt.Columns.Add("QUERY");

            SaveOcsSignData(dt, tableName, sqlBySign);
            SaveSignData(dt);
        }

        public static bool GetSignByUserCode(string user_cd, string data, ref string hash, ref string sign, ref string errMsg)
        {
            if (!ConfigService.GetConfigValueBool("%", "ESIGN_CONFIG", "USE_YN"))
                return true;

            string code = string.Empty;
            string msg = string.Empty;

            if (!ESignService.Hash(user_cd, data, ref hash, ref code, ref msg))
            {
                errMsg = $"전자서명 중 오류가 발생하였습니다. [ESignService.Hash : {code} / {msg}]";
                return false;
            }

            if (!ESignService.SignData(user_cd, hash, ref sign, ref code, ref msg))
            {
                errMsg = $"전자서명 중 오류가 발생하였습니다. [ESignService.SignData : {code} / {msg}]";
                return false;
            }

            return true;
        }

        public static string GetSignOriginalData(string data)
        {
            string code = string.Empty, mesg = string.Empty;
            return ESignService.GetOriginalData(data, ref code, ref mesg);
        }

        #endregion
    }

    /// <summary>
    /// 화면 출력 Class
    /// </summary>
    public class clsScreenDraw : IDisposable
    {
        #region Define : Member

        PdfDocument m_PdfDocument = new PdfDocument();
        PrintDocument m_PrintDocument = new PrintDocument(); // 출력 class
        Control m_CtrlPrint = null; // 출력할 화면

        int m_PageCount;// 출력할 총 Page 수
        int m_CurrentPageNumber;// 현재 출력 중인 Page 번호

        #endregion

        /// <summary>
        /// Pdf 출력 페이지를 그린다.
        /// </summary>
        /// <param name="ctrl"></param>
        public void AddPdfPage(Control ctrl)
        {
            if (m_PdfDocument == null)
                m_PdfDocument = new PdfDocument();

            Size size = PageSizeConverter.ToSize(PageSize.A4);

            int pagecount = int.Parse(Math.Ceiling(ctrl.Height / 1100.0).ToString());

            for (int curpage = 1; curpage <= pagecount; curpage++)
            {
                using (Bitmap bmp = new Bitmap((int)(760 * 1.5), (int)(1100 * 1.5)))
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    PdfPage pdfPage = new PdfPage()
                    {
                        Orientation = PageOrientation.Portrait,
                        Width = size.Width,
                        Height = size.Height,
                    };

                    m_PdfDocument.Pages.Add(pdfPage);
                    DrawPage(g, ctrl, curpage, pagecount);

                    using (Bitmap bmp2 = new Bitmap(bmp, new Size((int)(bmp.Width * .95), (int)(bmp.Height * .95))))
                    using (XGraphics xgr = XGraphics.FromPdfPage(m_PdfDocument.Pages[m_PdfDocument.Pages.Count - 1]))
                    using (XImage img = XImage.FromGdiPlusImage(bmp2.Clone() as Image))
                        xgr.DrawImage(img, 0, 0);
                }
            }
        }

        /// <summary>
        /// Pdf로 저장한다.
        /// </summary>
        /// <param name="filename"></param>
        public void SaveToPdf(string filename)
        {
            if (m_PdfDocument == null || m_PdfDocument.PageCount <= 0)
                return;

            using (SaveFileDialog sfd = new SaveFileDialog
            {
                Filter = "pdf File|*.pdf",
                FileName = filename,
            })
            {

                if (sfd.ShowDialog() != DialogResult.OK)
                    return;

                string filepath = sfd.FileName;

                m_PdfDocument.Save(filepath);
                m_PdfDocument.Dispose();
                m_PdfDocument = null;
            };
        }

        /// <summary>
        /// 화면을 출력한다.
        /// ctrl w760xh1100(한페이지 기준, 페이지 증가 시 1100*x)
        /// </summary>
        /// <param name="ctrl">출력할 화면</param>
        /// <param name="type">출력장치 설정(none:기본프린터)</param>
        /// <returns></returns>
        public bool PrintScreen(Control ctrl, PRINTER_TYPE type)
        {
            try
            {
                m_CtrlPrint = ctrl;
                m_CurrentPageNumber = 1;
                m_PageCount = int.Parse(Math.Ceiling(ctrl.Height / 1100.0).ToString());
                
                m_PrintDocument.PrintPage += PrintDocument_PrintPage;
                m_PrintDocument.PrinterSettings.PrinterName = type == PRINTER_TYPE.None || string.IsNullOrWhiteSpace(PrinterConfig.GetConfigPrinterName(type)) ? PrinterConfig.DefaultPrinterName : PrinterConfig.GetConfigPrinterName(type);
                m_PrintDocument.Print();

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            if (m_CtrlPrint == null || m_CtrlPrint.Controls.Count <= 0)
                return;

            DrawPage(e.Graphics, m_CtrlPrint, m_CurrentPageNumber, m_PageCount);

            if (m_PageCount > m_CurrentPageNumber)
            {
                e.HasMorePages = true;
                m_CurrentPageNumber++;
            }
            else
                e.HasMorePages = false;
        }

        #region :: 해당 Control로 부터 하위 Control 중 'PictureBox'를 찾는다.

        private Control[] GetPictureBoxControl(Control containercontrol)
        {
            List<Control> elementhost = new List<Control>();

            foreach (Control x in containercontrol.Controls)
            {
                if (x is LxPictureBox)
                    elementhost.Add(x);

                if (x.Controls.Count > 0)
                    elementhost.AddRange(GetPictureBoxControl(x));
            }

            return elementhost.ToArray();
        }

        #endregion :: 해당 Control로 부터 하위 Control 중 'PictureBox'를 찾는다.

        #region :: 모든 Control 그리기

        /// <summary>
        /// Line의 두께를 나타낸다.
        /// </summary>
        private float m_LineWidth = 1F;

        /// <summary>
        /// 페이지를 그린다.
        /// </summary>
        /// <param name="g"></param>
        /// <param name="containercontrol"></param>
        /// <param name="pageidx"></param>
        /// <param name="pagecount"></param>
        private void DrawPage(Graphics g, Control containercontrol, int pageidx, int pagecount)
        {
            // Control을 그리기 전, 화면을 White로 Clear한다.
            g.Clear(Color.White);

            // ######################################################################
            // 해상도 고화질 처리
            // ######################################################################
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;

            // ※ Graphics로 그리는 과정에서 겹쳐질 수 있기 때문에
            //   하위로 내려가도 상관 없는 것 들은 먼저,
            //   상위로 올라올 것 들은 나중에 그리도록 처리한다.

            // Page 정보를 그린다.
            DrawPageInformation(g, containercontrol, pageidx, pagecount);

            // PictureBox를 그리고
            DrawPictureBoxControl(g, containercontrol, pageidx, pagecount);

            // Control을 그리고
            DrawControls(g, containercontrol, pageidx, pagecount);
        }

        /// <summary>
        /// Page의 기본 정보를 그린다.
        /// </summary>
        /// <param name="g"></param>
        /// <param name="containercontrol"></param>
        /// <param name="pageidx"></param>
        /// <param name="pagecount"></param>
        public static void DrawPageInformation(Graphics g, Control containercontrol, int pageidx, int pagecount)
        {
            // ######################################################################
            // Draw Watermark
            // ######################################################################
            bool drawWatermarkLOGO = ConfigService.GetConfigValueBool("EM", "PRNT_OPTION", "DRAW_WTMK_LOGO2");
            bool drawWatermarkHPNM = ConfigService.GetConfigValueBool("EM", "PRNT_OPTION", "DRAW_WTMK_HPNM2");
            RectangleF recWatermark = RectangleF.Empty;

            if (drawWatermarkLOGO && DOPack.HospitalInfo.Watermark != null)
            {
                using (Image imgWatermark = DOPack.HospitalInfo.Watermark.Clone() as Image)
                {
                    recWatermark.Size = imgWatermark.Size;
                    recWatermark.Location = new PointF(
                        (containercontrol.Width - imgWatermark.Width) / 2
                      , (1100 - imgWatermark.Height) / 2);

                    g.DrawImage(imgWatermark, recWatermark);
                }
            }

            if (drawWatermarkHPNM)
            {
                recWatermark = recWatermark.IsEmpty
                    ? new RectangleF(0, 1100 / 2 - 20, containercontrol.Width, 40)
                    : new RectangleF(0, recWatermark.Bottom + 5, containercontrol.Width, 40);

                using (SolidBrush brush = new SolidBrush(Color.FromArgb(213, 213, 213)))
                using (StringFormat sf = new StringFormat() { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center, })
                {
                    g.DrawString(
                        DOPack.HospitalInfo.HSPT_NM
                        , new Font("맑은 고딕", 30F, FontStyle.Bold)
                        , brush
                        , recWatermark
                        , sf
                        );
                }
            }
        }

        private void DrawPictureBoxControl(Graphics g, Control containercontrol, int pageidx, int pagecount)
        {
            try
            {
                Point location = new Point();

                Control[] pictureboxs = GetPictureBoxControl(containercontrol);

                foreach (Control control in pictureboxs)
                {
                    if (control.Visible && control is LxPictureBox)
                    {
                        // 화면에서의 해당 Control의 X,Y 좌표를 구한다.
                        int screen_x = CalcControlLocationX(control) - CalcControlLocationX(m_CtrlPrint);
                        int screen_y = CalcControlLocationY(control) - CalcControlLocationY(m_CtrlPrint);

                        // 현재 페이지의 해당하는 좌표의 Control만 출력한다.
                        if (((pageidx - 1) * 1100) <= screen_y && (pageidx * 1100) >= screen_y)
                        {
                            location.X = screen_x + 15;
                            location.Y = (screen_y % 1100) + 30;

                            // Border 존재하면 Border도 그려주기
                            if (((LxPictureBox)control).BorderStyle != BorderStyle.None)
                            {
                                g.DrawRectangle(
                                      new Pen(Color.Black, m_LineWidth)
                                    , new Rectangle(location, control.Size));
                            }

                            if (((LxPictureBox)control).Image != null)
                            {
                                Image img = ((LxPictureBox)control).Image;
                                ((Bitmap)img).MakeTransparent(Color.White);

                                g.DrawImage(
                                      img
                                    , new RectangleF(new Point(location.X + ((control.Width - img.Width) / 2), location.Y + ((control.Height - img.Height) / 2)), img.Size));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("출력 중 오류가 발생하였습니다!\r\n");
            }
        }

        /// <summary>
        /// Page의 모든 Control을 그린다.
        /// </summary>
        /// <param name="containercontrol">선택한 컨트롤</param>
        /// <returns>모든 컨트롤</returns>
        private void DrawControls(Graphics g, Control containercontrol, int pageidx, int pagecount)
        {
            try
            {
                Point location = new Point();

                foreach (Control control in containercontrol.Controls)
                {
                    if (control.Visible)
                    {
                        if (control is Control)
                        {
                            // 화면에서의 해당 Control의 X,Y 좌표를 구한다.
                            int screen_x = CalcControlLocationX(control) - CalcControlLocationX(m_CtrlPrint);
                            int screen_y = CalcControlLocationY(control) - CalcControlLocationY(m_CtrlPrint);

                            // 현재 페이지의 해당하는 좌표의 Control만 출력한다.
                            if (((pageidx - 1) * 1100) <= screen_y && (pageidx * 1100) >= screen_y)
                            {
                                location.X = screen_x + 15;
                                location.Y = (screen_y % 1100) + 30;

                                #region :: Label

                                if (control is LxLabel)
                                {
                                    g.FillRectangle(new SolidBrush(((LxLabel)control).Appearance.BackColor), new Rectangle(location, new Size(((LxLabel)control).Size.Width - 1, ((LxLabel)control).Size.Height - 1)));

                                    if (((LxLabel)control).BorderStyleInner == Infragistics.Win.UIElementBorderStyle.Solid || ((LxLabel)control).BorderStyleOuter == Infragistics.Win.UIElementBorderStyle.Solid)
                                    {
                                        g.DrawRectangle(new Pen(((LxLabel)control).Appearance.BorderColor == Color.Empty ? Color.FromArgb(150, 150, 150) : ((LxLabel)control).Appearance.BorderColor, m_LineWidth), new Rectangle(location, new Size(((LxLabel)control).Size.Width - 1, ((LxLabel)control).Size.Height - 1)));
                                    }

                                    Font textfont = new Font(new FontFamily(((LxLabel)control).Appearance.FontData.Name == null ? "맑은 고딕" : (((LxLabel)control).Appearance.FontData.Name)), (((LxLabel)control).Appearance.FontData.SizeInPoints <= 0 ? 9 : ((LxLabel)control).Appearance.FontData.SizeInPoints) * 0.95F, ((LxLabel)control).Appearance.FontData.Bold == Infragistics.Win.DefaultableBoolean.True ? FontStyle.Bold : FontStyle.Regular);
                                    Brush brush = new SolidBrush(control.ForeColor == Color.Empty ? Color.FromArgb(30, 30, 30) : control.ForeColor);

                                    StringFormat sf = new StringFormat();
                                    sf.LineAlignment = ((LxLabel)control).Appearance.TextVAlign == Infragistics.Win.VAlign.Top ? StringAlignment.Near : (((LxLabel)control).Appearance.TextVAlign == Infragistics.Win.VAlign.Bottom ? StringAlignment.Far : StringAlignment.Center);
                                    sf.Alignment = ((LxLabel)control).Appearance.TextHAlign == Infragistics.Win.HAlign.Center ? StringAlignment.Center : (((LxLabel)control).Appearance.TextHAlign == Infragistics.Win.HAlign.Right ? StringAlignment.Far : StringAlignment.Near);

                                    g.DrawString(
                                          ((LxLabel)control).Text
                                        , textfont
                                        , brush
                                        , new RectangleF(location, ((LxLabel)control).Size)
                                        , sf);
                                }

                                #endregion :: Label

                                #region :: TitleLabel

                                if (control is LxTitleLabel)
                                {
                                    g.FillRectangle(new SolidBrush(((LxTitleLabel)control).Appearance.BackColor), new Rectangle(location, new Size(((LxTitleLabel)control).Size.Width - 1, ((LxTitleLabel)control).Size.Height - 1)));

                                    if (((LxTitleLabel)control).BorderStyleInner == Infragistics.Win.UIElementBorderStyle.Solid || ((LxTitleLabel)control).BorderStyleOuter == Infragistics.Win.UIElementBorderStyle.Solid)
                                    {
                                        g.DrawRectangle(new Pen(((LxTitleLabel)control).Appearance.BorderColor == Color.Empty ? Color.FromArgb(150, 150, 150) : ((LxTitleLabel)control).Appearance.BorderColor, m_LineWidth), new Rectangle(location, new Size(((LxTitleLabel)control).Size.Width - 1, ((LxTitleLabel)control).Size.Height - 1)));
                                    }

                                    Font textfont = new Font(new FontFamily(((LxTitleLabel)control).Appearance.FontData.Name == null ? "맑은 고딕" : (((LxTitleLabel)control).Appearance.FontData.Name)), (((LxTitleLabel)control).Appearance.FontData.SizeInPoints <= 0 ? 9 : ((LxTitleLabel)control).Appearance.FontData.SizeInPoints) * 0.95F, ((LxTitleLabel)control).Appearance.FontData.Bold == Infragistics.Win.DefaultableBoolean.True ? FontStyle.Bold : FontStyle.Regular);
                                    Brush brush = new SolidBrush(control.ForeColor == Color.Empty ? Color.FromArgb(30, 30, 30) : control.ForeColor);

                                    StringFormat sf = new StringFormat();
                                    sf.LineAlignment = ((LxTitleLabel)control).Appearance.TextVAlign == Infragistics.Win.VAlign.Top ? StringAlignment.Near : (((LxTitleLabel)control).Appearance.TextVAlign == Infragistics.Win.VAlign.Bottom ? StringAlignment.Far : StringAlignment.Center);
                                    sf.Alignment = ((LxTitleLabel)control).Appearance.TextHAlign == Infragistics.Win.HAlign.Center ? StringAlignment.Center : (((LxTitleLabel)control).Appearance.TextHAlign == Infragistics.Win.HAlign.Right ? StringAlignment.Far : StringAlignment.Near);

                                    g.DrawString(
                                          ((LxTitleLabel)control).Text
                                        , textfont
                                        , brush
                                        , new RectangleF(location, ((LxTitleLabel)control).Size)
                                        , sf);
                                }

                                #endregion :: TitleLabel

                                #region :: Panel

                                else if (control is LxPanel)
                                {
                                    if (((LxPanel)control).BackColor != Color.White)
                                        g.FillRectangle(new SolidBrush(((LxPanel)control).BackColor), new Rectangle(location, new Size(((LxPanel)control).Size.Width - 1, ((LxPanel)control).Height - 1)));

                                    if (((LxPanel)control).DisplayBorder)
                                    {
                                        g.DrawRectangle(new Pen(((LxPanel)control).BorderColor, m_LineWidth), new Rectangle(location, new Size(((LxPanel)control).Size.Width - 1, ((LxPanel)control).Height - 1)));
                                    }
                                }

                                #endregion :: Panel

                                #region :: CheckBox

                                else if (control is LxCheckBox)
                                {
                                    g.DrawImage(((LxCheckBox)control).Checked ? Controls.Properties.Resources.CheckBox_Checked : Controls.Properties.Resources.CheckBox_UnChecked
                                        , ((LxCheckBox)control).CheckAlign == ContentAlignment.MiddleLeft ? location.X : ((LxCheckBox)control).CheckAlign == ContentAlignment.MiddleCenter ? location.X + ((control.Width - 14) / 2) : location.X, location.Y + ((control.Size.Height - 14) / 2), 14, 14);

                                    if (StringService.IsNotNull(((LxCheckBox)control).Text))
                                    {
                                        StringFormat sf = new StringFormat();
                                        sf.LineAlignment = StringAlignment.Center;
                                        sf.Alignment = ((LxCheckBox)control).Appearance.TextHAlign == Infragistics.Win.HAlign.Center ? StringAlignment.Center : (((LxCheckBox)control).Appearance.TextHAlign == Infragistics.Win.HAlign.Right ? StringAlignment.Far : StringAlignment.Near);

                                        Font font = new Font(new FontFamily(control.Font.Name)
                                            , control.Font.Size * 0.95F
                                            , control.Font.Bold ? FontStyle.Bold : FontStyle.Regular);

                                        g.DrawString(
                                            ((LxCheckBox)control).Text
                                          , font
                                          , new SolidBrush(control.ForeColor == Color.Empty ? Color.FromArgb(30, 30, 30) : control.ForeColor)
                                          , new RectangleF(new Point(location.X + 15, location.Y), ((LxCheckBox)control).Size)
                                          , sf);
                                    }
                                }

                                #endregion :: CheckBox

                                #region :: RadioButton

                                else if (control is LxRadioButton)
                                {
                                    g.DrawImage(((LxRadioButton)control).Checked ? Controls.Properties.Resources.RadioButton_Checked : Controls.Properties.Resources.RadioButton_UnChecked
                                        , location.X, location.Y + (control.Size.Height / 2) - 7, 14, 14);

                                    if (StringService.IsNotNull(((LxRadioButton)control).Text))
                                    {
                                        StringFormat sf = new StringFormat();
                                        sf.LineAlignment = StringAlignment.Center;
                                        sf.Alignment = StringAlignment.Near;

                                        Font font = new Font(new FontFamily(control.Font.Name)
                                            , control.Font.Size * 0.95F
                                            , control.Font.Bold ? FontStyle.Bold : FontStyle.Regular);

                                        g.DrawString(
                                              ((LxRadioButton)control).Text
                                            , font
                                            , new SolidBrush(control.ForeColor == Color.Empty ? Color.FromArgb(30, 30, 30) : control.ForeColor)
                                            , new RectangleF(new Point(location.X + 15, location.Y), ((LxRadioButton)control).Size)
                                            , sf);
                                    }
                                }

                                #endregion :: RadioButton

                                #region :: TextBox

                                else if (control is LxTextBox)
                                {
                                    if (((LxTextBox)control).BorderStyle == Infragistics.Win.UIElementBorderStyle.Inset)
                                    {
                                        g.DrawRectangle(new Pen(((LxTextBox)control).Appearance.BorderColor == Color.Empty ? Color.Black : ((LxTextBox)control).Appearance.BorderColor, m_LineWidth), new Rectangle(location, new Size(((LxTextBox)control).Size.Width - 1, ((LxTextBox)control).Height - 1)));
                                    }

                                    if (StringService.IsNotNull(((LxTextBox)control).Text))
                                    {
                                        StringFormat sf = new StringFormat();
                                        sf.LineAlignment = ((LxTextBox)control).Appearance.TextVAlign == Infragistics.Win.VAlign.Top ? StringAlignment.Near : StringAlignment.Center;
                                        sf.Alignment = ((LxTextBox)control).Appearance.TextHAlign == Infragistics.Win.HAlign.Center ? StringAlignment.Center : (((LxTextBox)control).Appearance.TextHAlign == Infragistics.Win.HAlign.Right ? StringAlignment.Far : StringAlignment.Near);

                                        if (((LxTextBox)control).Multiline)
                                            sf.LineAlignment = StringAlignment.Near;

                                        Font font = new Font(new FontFamily(control.Font.Name)
                                            , control.Font.Size * 0.95F
                                            , control.Font.Bold ? FontStyle.Bold : FontStyle.Regular);

                                        g.DrawString(
                                              ((LxTextBox)control).Text
                                            , font
                                            , new SolidBrush(control.ForeColor == Color.Empty ? Color.FromArgb(30, 30, 30) : control.ForeColor)
                                            , new RectangleF(location, ((LxTextBox)control).Size)
                                            , sf);
                                    }
                                }

                                #endregion :: TextBox

                                #region :: MaskedEdit

                                else if (control is LxMaskedEdit)
                                {
                                    StringFormat sf = new StringFormat();
                                    sf.LineAlignment = StringAlignment.Center;
                                    sf.Alignment = ((LxMaskedEdit)control).Appearance.TextHAlign == Infragistics.Win.HAlign.Center ? StringAlignment.Center : (((LxMaskedEdit)control).Appearance.TextHAlign == Infragistics.Win.HAlign.Right ? StringAlignment.Far : StringAlignment.Near);

                                    Font font = new Font(new FontFamily(((LxMaskedEdit)control).Appearance.FontData.Name == null ? "맑은 고딕" : ((LxMaskedEdit)control).Appearance.FontData.Name)
                                        , (((LxMaskedEdit)control).Appearance.FontData.SizeInPoints <= 0 ? 9 : ((LxMaskedEdit)control).Appearance.FontData.SizeInPoints) * 0.95F
                                        , ((LxMaskedEdit)control).Appearance.FontData.Bold == Infragistics.Win.DefaultableBoolean.True ? FontStyle.Bold : FontStyle.Regular);

                                    g.DrawString(
                                          string.IsNullOrWhiteSpace(control.Text) ? ((LxMaskedEdit)control).InputMask.Replace("#", " ") : ((LxMaskedEdit)control).Text
                                        , font
                                        , new SolidBrush(control.ForeColor == Color.Empty ? Color.FromArgb(30, 30, 30) : control.ForeColor)
                                        , new RectangleF(location, ((LxMaskedEdit)control).Size)
                                        , sf);
                                }

                                #endregion :: MaskedEdit

                                #region :: DateTimeEditor

                                else if (control is LxDateTimeEditor)
                                {
                                    if (StringService.IsNotNull(((LxDateTimeEditor)control).Text))
                                    {
                                        StringFormat sf = new StringFormat();
                                        sf.LineAlignment = StringAlignment.Center;
                                        sf.Alignment = ((LxDateTimeEditor)control).Appearance.TextHAlign == Infragistics.Win.HAlign.Center ? StringAlignment.Center : (((LxDateTimeEditor)control).Appearance.TextHAlign == Infragistics.Win.HAlign.Right ? StringAlignment.Far : StringAlignment.Near);

                                        Font font = new Font(new FontFamily(control.Font.Name)
                                            , control.Font.Size * 0.95F
                                            , control.Font.Bold ? FontStyle.Bold : FontStyle.Regular);

                                        g.DrawString(
                                              ((LxDateTimeEditor)control).Text
                                            , font
                                            , new SolidBrush(control.ForeColor == Color.Empty ? Color.FromArgb(30, 30, 30) : control.ForeColor)
                                            , new RectangleF(location, ((LxDateTimeEditor)control).Size)
                                            , sf);
                                    }
                                }

                                #endregion :: DateTimeEditor

                                #region :: ComboBox

                                else if (control is LxComboBox)
                                {
                                    if (StringService.IsNotNull(((LxComboBox)control).Text))
                                    {
                                        StringFormat sf = new StringFormat();
                                        sf.LineAlignment = StringAlignment.Center;
                                        sf.Alignment = ((LxComboBox)control).Appearance.TextHAlign == Infragistics.Win.HAlign.Center ? StringAlignment.Center : (((LxComboBox)control).Appearance.TextHAlign == Infragistics.Win.HAlign.Right ? StringAlignment.Far : StringAlignment.Near);

                                        Font font = new Font(new FontFamily(control.Font.Name)
                                            , control.Font.Size * 0.95F
                                            , control.Font.Bold ? FontStyle.Bold : FontStyle.Regular);

                                        g.DrawString(
                                              ((LxComboBox)control).Text
                                            , font
                                            , new SolidBrush(control.ForeColor == Color.Empty ? Color.FromArgb(30, 30, 30) : control.ForeColor)
                                            , new RectangleF(location, ((LxComboBox)control).Size)
                                            , sf);
                                    }
                                }

                                #endregion :: ComboBox

                                #region :: Spread

                                else if (control is LxSpread)
                                {
                                    for (int i = 0; i < ((LxSpread)control).ActiveSheet.RowCount; i++)
                                    {
                                        if (!((LxSpread)control).ActiveSheet.Rows[i].Visible)
                                            continue;

                                        for (int j = 0; j < ((LxSpread)control).ActiveSheet.ColumnCount; j++)
                                        {
                                            if (!((LxSpread)control).ActiveSheet.Columns[j].Visible || ((LxSpread)control).ActiveSheet.Columns[j].Label.Substring(0, 1).Equals("!"))
                                                continue;

                                            FarPoint.Win.ComplexBorder border = ((LxSpread)control).ActiveSheet.Cells[i, j].Border as FarPoint.Win.ComplexBorder;

                                            if (border != null || !string.IsNullOrWhiteSpace(((LxSpread)control).ActiveSheet.Cells[i, j].Text) || (((LxSpread)control).ActiveSheet.Cells[i, j].Tag != null && !string.IsNullOrWhiteSpace(((LxSpread)control).ActiveSheet.Cells[i, j].Tag.ToString())))
                                            {
                                                Pen pen = new Pen(Color.Black, m_LineWidth);
                                                Point pnt = CurrentCellLocation(((LxSpread)control), i, j);
                                                pnt.X += location.X;
                                                pnt.Y += location.Y;

                                                int width = 0;
                                                for (int x = 0; x < ((LxSpread)control).ActiveSheet.Cells[i, j].ColumnSpan; x++)
                                                    width += (int)((LxSpread)control).ActiveSheet.Columns[j + x].Width;

                                                int height = 0;
                                                for (int y = 0; y < ((LxSpread)control).ActiveSheet.Cells[i, j].RowSpan; y++)
                                                    height += (int)((LxSpread)control).ActiveSheet.Rows[i + y].Height;

                                                if (((LxSpread)control).ActiveSheet.Cells[i, j].BackColor != Color.White ||
                                                    ((LxSpread)control).ActiveSheet.Cells[i, j].BackColor != Color.FromArgb(0, 0, 0, 0))
                                                    g.FillRectangle(new SolidBrush(((LxSpread)control).ActiveSheet.Cells[i, j].BackColor)
                                                        , new RectangleF(pnt, new Size(width, height)));

                                                if (border != null)
                                                {
                                                    // 2019-11-21
                                                    // Style이 None이 아니고, Draw면서 선 굵기가 0 이상일때만 그리도록 수정
                                                    if (border.Top.Style != FarPoint.Win.ComplexBorderSideStyle.None &&
                                                        border.Top.Draw &&
                                                        border.Top.Width > 0)
                                                        g.DrawLine(pen, pnt.X, pnt.Y, pnt.X + width, pnt.Y);

                                                    if (border.Left.Style != FarPoint.Win.ComplexBorderSideStyle.None &&
                                                        border.Left.Draw &&
                                                        border.Left.Width > 0)
                                                        g.DrawLine(pen, pnt.X, pnt.Y, pnt.X, pnt.Y + height);

                                                    if (border.Right.Style != FarPoint.Win.ComplexBorderSideStyle.None &&
                                                        border.Right.Draw &&
                                                        border.Right.Width > 0)
                                                        g.DrawLine(pen, pnt.X + width, pnt.Y, pnt.X + width, pnt.Y + height);

                                                    if (border.Bottom.Style != FarPoint.Win.ComplexBorderSideStyle.None &&
                                                        border.Bottom.Draw &&
                                                        border.Bottom.Width > 0)
                                                        g.DrawLine(pen, pnt.X, pnt.Y + height, pnt.X + width, pnt.Y + height);
                                                }

                                                Font font = new Font(((LxSpread)control).ActiveSheet.Cells[i, j].Font != null ? ((LxSpread)control).ActiveSheet.Cells[i, j].Font.Name : "맑은 고딕"
                                                    , ((LxSpread)control).ActiveSheet.Cells[i, j].Font != null ? ((LxSpread)control).ActiveSheet.Cells[i, j].Font.Size * 0.95F : 8.5F
                                                    , ((LxSpread)control).ActiveSheet.Cells[i, j].Font != null && ((LxSpread)control).ActiveSheet.Cells[i, j].Font.Bold ? FontStyle.Bold : FontStyle.Regular);

                                                StringFormat sf = new StringFormat();
                                                sf.LineAlignment = ((LxSpread)control).ActiveSheet.Cells[i, j].VerticalAlignment == FarPoint.Win.Spread.CellVerticalAlignment.Center ? StringAlignment.Center : (((LxSpread)control).ActiveSheet.Cells[i, j].VerticalAlignment == FarPoint.Win.Spread.CellVerticalAlignment.Bottom ? StringAlignment.Far : StringAlignment.Near);
                                                sf.Alignment = ((LxSpread)control).ActiveSheet.Cells[i, j].HorizontalAlignment == FarPoint.Win.Spread.CellHorizontalAlignment.Center ? StringAlignment.Center : (((LxSpread)control).ActiveSheet.Cells[i, j].HorizontalAlignment == FarPoint.Win.Spread.CellHorizontalAlignment.Right ? StringAlignment.Far : StringAlignment.Near);
                                                Brush brush = new SolidBrush(((LxSpread)control).ActiveSheet.Cells[i, j].ForeColor == Color.Empty ? Color.FromArgb(30, 30, 30) : ((LxSpread)control).ActiveSheet.Cells[i, j].ForeColor);

                                                if (((LxSpread)control).ActiveSheet.Cells[i, j].CellType is FarPoint.Win.Spread.CellType.CheckBoxCellType)
                                                {
                                                    FarPoint.Win.Spread.CellType.CheckBoxCellType celltype = ((LxSpread)control).ActiveSheet.Cells[i, j].CellType as FarPoint.Win.Spread.CellType.CheckBoxCellType;
                                                    object value = ((LxSpread)control).ActiveSheet.Cells[i, j].Value;
                                                    int _location_x_add = 2;

                                                    g.DrawImage(
                                                          ((LxSpread)control).ActiveSheet.Cells[i, j].Text.Equals("True") ? Controls.Properties.Resources.CheckBox_Checked : Controls.Properties.Resources.CheckBox_UnChecked
                                                        , new RectangleF(new Point(pnt.X + _location_x_add, pnt.Y + (((int)((LxSpread)control).ActiveSheet.Cells[i, j].Row.Height - 14) / 2)), new Size(14, 14)));

                                                    _location_x_add += 15;

                                                    g.DrawString(
                                                        celltype.Caption
                                                        , font
                                                        , brush
                                                        , new RectangleF(new Point(pnt.X + _location_x_add, pnt.Y), new Size(width - _location_x_add, height))
                                                        , sf);
                                                }
                                                else if (((LxSpread)control).ActiveSheet.Cells[i, j].CellType is FarPoint.Win.Spread.CellType.MultiOptionCellType)
                                                {
                                                    FarPoint.Win.Spread.CellType.MultiOptionCellType celltype = ((LxSpread)control).ActiveSheet.Cells[i, j].CellType as FarPoint.Win.Spread.CellType.MultiOptionCellType;
                                                    object value = ((LxSpread)control).ActiveSheet.Cells[i, j].Value;

                                                    int _location_x_add = 2;

                                                    if (celltype.Orientation == FarPoint.Win.RadioOrientation.Vertical && sf.Alignment == StringAlignment.Center)
                                                    {
                                                        int max_width = 0;

                                                        for (int x = 0; i < celltype.Items.Length; x++)
                                                        {
                                                            int string_width = GetDisplayStringWidth(celltype.Items[x], font, g);
                                                            if (max_width < string_width)
                                                                max_width = string_width;
                                                        }

                                                        _location_x_add = (width - (_location_x_add + 15 + max_width)) / 2;
                                                    }

                                                    sf.Alignment = StringAlignment.Near;

                                                    for (int item_idx = 0; item_idx < celltype.Items.Length; item_idx++)
                                                    {
                                                        bool checked_radio = celltype.ItemData[item_idx].ToString().Equals(value != null ? value.ToString() : "");

                                                        if (celltype.Orientation == FarPoint.Win.RadioOrientation.Vertical)
                                                        {
                                                            g.DrawImage(
                                                                checked_radio ? Controls.Properties.Resources.RadioButton_Checked : Controls.Properties.Resources.RadioButton_UnChecked
                                                                , new RectangleF(new Point(pnt.X + _location_x_add, pnt.Y + item_idx * 20), new Size(14, 14)));

                                                            g.DrawString(
                                                                celltype.Items[item_idx]
                                                                , font
                                                                , brush
                                                                , new RectangleF(new Point(pnt.X + _location_x_add + 15, pnt.Y + item_idx * 20), new Size((int)((LxSpread)control).ActiveSheet.Cells[i, j].Column.Width - 15, 18))
                                                                , sf);
                                                        }
                                                        else
                                                        {
                                                            g.DrawImage(
                                                                checked_radio ? Controls.Properties.Resources.RadioButton_Checked : Controls.Properties.Resources.RadioButton_UnChecked
                                                                , new RectangleF(new Point(pnt.X + _location_x_add, pnt.Y + ((height - 14) / 2)), new Size(14, 14)));

                                                            _location_x_add += 15;

                                                            int string_width = GetDisplayStringWidth(celltype.Items[item_idx], font, g);

                                                            g.DrawString(
                                                                celltype.Items[item_idx]
                                                                , font
                                                                , brush
                                                                , new RectangleF(new Point(pnt.X + _location_x_add, pnt.Y + ((height - 18) / 2)), new Size(string_width, 18))
                                                                , sf);

                                                            _location_x_add += string_width + 2;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    if (StringService.IsNotNull(((LxSpread)control).ActiveSheet.Cells[i, j].Text))
                                                    {
                                                        g.DrawString(
                                                              ((LxSpread)control).ActiveSheet.Cells[i, j].Text
                                                            , font
                                                            , brush
                                                            , new RectangleF(pnt, new Size(width, height))
                                                            , sf);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                #endregion :: Spread
                            }
                        }
                        //만일 자식 컨트롤이 또 다른 자식 컨트롤을 가지고 있다면
                        if (control.Controls.Count > 0)
                        {
                            //자신을 재귀적으로 호출한다
                            DrawControls(g, control, pageidx, pagecount);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("출력 중 오류가 발생하였습니다!\r\n");
            }
        }

        /// <summary>
        /// Control의 화면상 X좌표를 구한다.
        /// </summary>
        /// <param name="containercontrol"></param>
        /// <returns></returns>
        private int CalcControlLocationX(Control containercontrol)
        {
            if (containercontrol == null || containercontrol is IBaseProgramChart)
                return 0;

            return containercontrol.Location.X + CalcControlLocationX(containercontrol.Parent);
        }

        /// <summary>
        /// Control의 화면상 X좌표를 구한다.
        /// </summary>
        /// <param name="containercontrol"></param>
        /// <returns></returns>
        private int CalcControlLocationXToChartContainer(Control containercontrol)
        {
            if (containercontrol == null || containercontrol is IBaseProgramChart)
                return 0;

            return containercontrol.Location.X + CalcControlLocationXToChartContainer(containercontrol.Parent);
        }

        /// <summary>
        /// Control의 화면상 Y좌표를 구한다.
        /// </summary>
        /// <param name="containercontrol"></param>
        /// <returns></returns>
        private int CalcControlLocationY(Control containercontrol)
        {
            if (containercontrol == null || containercontrol is IBaseProgramChart)
                return 0;

            return containercontrol.Location.Y + CalcControlLocationY(containercontrol.Parent);
        }

        /// <summary>
        /// Control의 화면상 Y좌표를 구한다.
        /// </summary>
        /// <param name="containercontrol"></param>
        /// <returns></returns>
        private int CalcControlLocationYToChartContainer(Control containercontrol)
        {
            if (containercontrol == null || containercontrol is IBaseProgramChart)
                return 0;

            return containercontrol.Location.Y + CalcControlLocationYToChartContainer(containercontrol.Parent);
        }

        /// <summary>
        /// Spread를 기점으로 Cell의 좌표를 구한다.
        /// </summary>
        /// <param name="spr"></param>
        /// <param name="row"></param>
        /// <param name="col"></param>
        /// <returns></returns>
        private Point CurrentCellLocation(LxSpread spr, int row, int col)
        {
            int x = 0;
            int y = 0;

            try
            {
                for (int i = 0; i < row; i++)
                {
                    if (!spr.ActiveSheet.Rows[i].Visible)
                        continue;

                    y += Convert.ToInt32(spr.ActiveSheet.Rows[i].Height);
                }

                for (int i = 0; i < col; i++)
                {
                    if (!spr.ActiveSheet.Columns[i].Visible || spr.ActiveSheet.Columns[i].Label.Substring(0, 1).Equals("!"))
                        continue;

                    x += Convert.ToInt32(spr.ActiveSheet.Columns[i].Width);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return new Point(x, y);
        }

        #endregion :: 모든 Control 그리기

        #region :: String Width 계산

        /// <summary>
        /// String의 Width를 구한다.
        /// </summary>
        /// <param name="text"></param>
        /// <param name="font"></param>
        /// <param name="g"></param>
        /// <returns></returns>
        private int GetDisplayStringWidth(string text, Font font, Graphics g)
        {
            StringFormat sf = new StringFormat();
            RectangleF rect = new RectangleF(0, 0, 1000, 1000);
            Region[] region = new Region[1];
            CharacterRange[] range = { new CharacterRange(0, text.Length) };

            sf.SetMeasurableCharacterRanges(range);
            region = g.MeasureCharacterRanges(text, font, rect, sf);
            rect = region[0].GetBounds(g);

            return (int)(rect.Right + 1.0F);
        }

        #endregion :: String Width 계산

        #region IDisposable Support
        private bool disposedValue = false; // 중복 호출을 검색하려면

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: 관리되는 상태(관리되는 개체)를 삭제합니다.
                    m_PrintDocument?.Dispose();
                    m_PdfDocument?.Dispose();
                }

                // TODO: 관리되지 않는 리소스(관리되지 않는 개체)를 해제하고 아래의 종료자를 재정의합니다.
                // TODO: 큰 필드를 null로 설정합니다.

                disposedValue = true;
            }
        }

        // TODO: 위의 Dispose(bool disposing)에 관리되지 않는 리소스를 해제하는 코드가 포함되어 있는 경우에만 종료자를 재정의합니다.
        // ~clsScreenDraw() {
        //   // 이 코드를 변경하지 마세요. 위의 Dispose(bool disposing)에 정리 코드를 입력하세요.
        //   Dispose(false);
        // }

        // 삭제 가능한 패턴을 올바르게 구현하기 위해 추가된 코드입니다.
        public void Dispose()
        {
            // 이 코드를 변경하지 마세요. 위의 Dispose(bool disposing)에 정리 코드를 입력하세요.
            Dispose(true);
            // TODO: 위의 종료자가 재정의된 경우 다음 코드 줄의 주석 처리를 제거합니다.
            // GC.SuppressFinalize(this);
        }
        #endregion
    }
}