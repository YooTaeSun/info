namespace Lime.Framework
{
    /// <summary>
    /// PhoneNumber Service
    /// </summary>
    public static class PhoneNumberService
    {
        public static string AddHyphenPhoneNumber(string number)
        {
            number = number.Replace("-", string.Empty);

            int Length = 3;

            if (number.Length < Length) return number;

            if (!TypeCheckService.IsLong(number)) return number;

            string PhoneNumber = string.Empty;

            try
            {
                if (number.Length >= 9 && number.Substring(0, 2) == "02")
                {
                    PhoneNumber = number.Substring(0, 2);
                    PhoneNumber += "-";
                    PhoneNumber += number.Substring(2, number.Length <= 9 ? 3 : 4);
                    PhoneNumber += "-";
                    PhoneNumber += number.Substring(PhoneNumber.Replace("-", string.Empty).Length);

                    return PhoneNumber;
                }
                else if (number.Length == 6)
                {
                    PhoneNumber = number.Substring(0, 3);
                    PhoneNumber += "-";
                    PhoneNumber += number.Substring(PhoneNumber.Replace("-", string.Empty).Length);
                }
                else if (number.Length == 8)
                {
                    PhoneNumber = number.Substring(0, 4);
                    PhoneNumber += "-";
                    PhoneNumber += number.Substring(PhoneNumber.Replace("-", string.Empty).Length);
                }
                else if (number.Length == 7)
                {
                    PhoneNumber = number.Substring(0, 3);
                    PhoneNumber += "-";
                    PhoneNumber += number.Substring(PhoneNumber.Replace("-", string.Empty).Length);
                }
                else
                {
                    PhoneNumber = number.Substring(0, 3);

                    if (number.Length == 7 || number.Length < 11)
                    {
                        PhoneNumber += "-";
                        PhoneNumber += number.Substring(3, 3);
                        PhoneNumber += "-";
                        PhoneNumber += number.Substring(PhoneNumber.Replace("-", string.Empty).Length);
                    }
                    else if (number.Length == 11 || number.Length < 13)
                    {
                        PhoneNumber += "-";
                        PhoneNumber += number.Substring(3, 4);
                        PhoneNumber += "-";
                        PhoneNumber += number.Substring(PhoneNumber.Replace("-", string.Empty).Length);
                    }
                    else
                    {
                        PhoneNumber += "-";
                        PhoneNumber += number.Substring(3, 4);
                        PhoneNumber += "-";
                        PhoneNumber += number.Substring(PhoneNumber.Replace("-", string.Empty).Length);
                    }
                }
            }
            catch
            {
                PhoneNumber = number;
            }

            return PhoneNumber;
        }
    }
}
