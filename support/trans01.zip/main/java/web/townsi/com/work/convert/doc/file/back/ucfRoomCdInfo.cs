//********************************************************************************
// Class 명 : ucfRoomCdInfo
// 역    할 : 해당 병동의 병실을 관리하는 화면
// 작 성 자 : 김우준
// 작 성 일 : 2017-07-25
//********************************************************************************
// 수정내역 : 2017-08-02 : 김우준 : 없음
//            2017-09-14 : 권재호 : Insert Row 삭제 및 Validation 체크 등 전체적인 수정
//            2018-03-22 : 유준선 수정
//********************************************************************************
// TODO : 조회 리턴 프레임워크에 OldValue 적용되면 반영할 것
// TODO : 적용시작일자~적용종료일자 중복체크는 스프레드상에서만 할 것
using System;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.BI
{
    public partial class ucfRoomCdInfo : BaseUCF_TP
    {
        private enum COL_R
        {
              ROOM_CD           // 병실코드
            , APLY_STRT_DD      // 시작일자
            , APLY_END_DD       // 종료일자
            , ROOM_GRAD_CD      // 병실등급
            , ROOM_DVCD         // 병실구분
            , NRCR_GRAD_CD      // 간호등급
            , BASS_BED_CNT      // 기준병상
            , AVLB_BED_CNT      // 가동병상
            , MFML_APLY_YN      // 남녀구분
            , MFML_MIX_PSBL_YN  // 남녀혼용
            , USE_YN            // 사용
            , ROOM_DIAM_CD      // 차액코드
            , PCLR_MATR         // 특이사항
        }

        private enum COL_B
        {
              BED_NO            //병상번호
            , APLY_STRT_DD      //적용시작일자
            , APLY_END_DD       //적용종료일자
            , BED_LCTN_DVCD     //병상위치구분코드
            , OXYG_YN           //산소여부
            , SUCT_YN           //Suction여부
            , BED_PCFT          //병상특이사항
            , USE_YN            //사용여부
            , WARD_CD           //병동코드
            , ROOM_CD           //병실코드
            , ETC_USE_CNTS_1    //기타사용내용첫째
            , ETC_USE_CNTS_2    //기타사용내용둘째
            , ETC_USE_CNTS_3    //기타사용내용셋째
            , RGST_DT           //등록일시
            , RGSTR_ID          //등록자ID
            , UPDT_DT           //수정일시
            , UPDTR_ID          //수정자ID
        }

        private LxSpread m_FocusedSpread = null;

        #region Construction

        public ucfRoomCdInfo()
        {
            InitializeComponent();
        }

        #endregion Construction

        #region Screen Load

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode)
                return;

            Initialize();

            SelectDataWard();
        }

        #endregion Screen Load

        #region Method : Initialize Method

        private void Initialize()
        {
            InitializeSpread();

            sprRoom.SetComboItems("ROOM_GRAD_CD", OverallCodeList.GetDataList("ROOM_GRAD_CD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            sprRoom.SetComboItems("ROOM_DVCD", OverallCodeList.GetDataList("ROOM_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            sprRoom.SetComboItems("NRCR_GRAD_CD", OverallCodeList.GetDataList("NRCR_GRAD_CD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            sprRoom.SetComboItems("MFML_APLY_YN", OverallCodeList.GetDataList("MFML_APLY_YN"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            sprBed.SetComboItems("BED_LCTN_DVCD", OverallCodeList.GetDataList("BED_LCTN_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");

            // 조회성 스프레드 선택모드 싱글, 첫번째 행 선택
            sprWard.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect;
            sprWard.ActiveSheet.AddSelection(0, -1, 1, -1);

            dteAplyDd.DateTime = DateTime.Today;
            dteAplyDd.ValueChanged += (s, e) =>
            {
                if (!chkBassDdd.Checked)
                    return;

                SelectDataWard();
            };

            sprWard.CellClick += (s, e) => m_FocusedSpread = sprWard;
            sprRoom.CellClick += (s, e) => m_FocusedSpread = sprRoom;
            sprBed.CellClick += (s, e) => m_FocusedSpread = sprBed;

            sprRoom.RowChanged += sprRoom_RowChanged;
            sprWard.RowChanged += sprWard_RowChanged;

            btnButtonList.ButtonClick += btnButtonList_ButtonClick;

            chkBassDdd.CheckedChanged += chkBassDdd_CheckedChanged;
        }

        private void InitializeSpread()
        {
            this.sprBed.SetSpreadSheet(this.sprBed.ActiveSheet, FarPoint.Win.Spread.Model.SelectionPolicy.Range, FarPoint.Win.Spread.Model.SelectionUnit.Row, FarPoint.Win.Spread.SelectionStyles.SelectionColors, FarPoint.Win.Spread.OperationMode.RowMode, true, true, FarPoint.Win.Spread.ButtonDrawModes.Always, true, true, FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded, FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded, true, false, false, false);

            this.sprBed.SetSpreadSheetColumn(this.sprBed.ActiveSheet, (int)COL_B.BED_NO, "BED_NO", "병상번호", 100, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType, false);
            this.sprBed.SetSpreadSheetColumn(this.sprBed.ActiveSheet, (int)COL_B.APLY_STRT_DD, "APLY_STRT_DD", "적용시작일", 100, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.MaskCellTypeYMD, false);
            this.sprBed.SetSpreadSheetColumn(this.sprBed.ActiveSheet, (int)COL_B.APLY_END_DD, "APLY_END_DD", "적용종료일", 100, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.MaskCellTypeYMD, false);
            this.sprBed.SetSpreadSheetColumn(this.sprBed.ActiveSheet, (int)COL_B.BED_LCTN_DVCD, "BED_LCTN_DVCD", "병상위치", 100, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.ComboBoxCellType, false);
            this.sprBed.SetSpreadSheetColumn(this.sprBed.ActiveSheet, (int)COL_B.OXYG_YN, "OXYG_YN", "산소", 60, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.CheckBoxCellType, false);
            this.sprBed.SetSpreadSheetColumn(this.sprBed.ActiveSheet, (int)COL_B.SUCT_YN, "SUCT_YN", "Suction", 60, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.CheckBoxCellType, false);
            this.sprBed.SetSpreadSheetColumn(this.sprBed.ActiveSheet, (int)COL_B.BED_PCFT, "BED_PCFT", "병상특이사항", 1000, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType, false);
            this.sprBed.SetSpreadSheetColumn(this.sprBed.ActiveSheet, (int)COL_B.USE_YN, "USE_YN", "사용", 60, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.CheckBoxCellType, false);

            this.sprBed.SetSpreadSheetColumn(this.sprBed.ActiveSheet, (int)COL_B.WARD_CD, "WARD_CD", "!병동코드", 25, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType, false);
            this.sprBed.SetSpreadSheetColumn(this.sprBed.ActiveSheet, (int)COL_B.ROOM_CD, "ROOM_CD", "!병실코드", 25, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType, false);
            this.sprBed.SetSpreadSheetColumn(this.sprBed.ActiveSheet, (int)COL_B.ETC_USE_CNTS_1, "ETC_USE_CNTS_1", "!기타사용내용첫째", 25, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType, false);
            this.sprBed.SetSpreadSheetColumn(this.sprBed.ActiveSheet, (int)COL_B.ETC_USE_CNTS_2, "ETC_USE_CNTS_2", "!기타사용내용둘째", 25, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType, false);
            this.sprBed.SetSpreadSheetColumn(this.sprBed.ActiveSheet, (int)COL_B.ETC_USE_CNTS_3, "ETC_USE_CNTS_3", "!기타사용내용셋째", 25, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType, false);
            this.sprBed.SetSpreadSheetColumn(this.sprBed.ActiveSheet, (int)COL_B.RGST_DT, "RGST_DT", "!등록일시", 25, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType, false);
            this.sprBed.SetSpreadSheetColumn(this.sprBed.ActiveSheet, (int)COL_B.RGSTR_ID, "RGSTR_ID", "!등록자ID", 25, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType, false);
            this.sprBed.SetSpreadSheetColumn(this.sprBed.ActiveSheet, (int)COL_B.UPDT_DT, "UPDT_DT", "!수정일시", 25, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType, false);
            this.sprBed.SetSpreadSheetColumn(this.sprBed.ActiveSheet, (int)COL_B.UPDTR_ID, "UPDTR_ID", "!수정자ID", 25, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType, false);

            //this.sprBed_Sheet1.Columns.Get((int)COL.BED_NO).Locked         = true;  //병상번호
            //this.sprBed_Sheet1.Columns.Get((int)COL.APLY_STRT_DD).Locked   = true;  //적용시작일자
            //this.sprBed_Sheet1.Columns.Get((int)COL.APLY_END_DD).Locked    = true;  //적용종료일자
            //this.sprBed_Sheet1.Columns.Get((int)COL.BED_LCTN_DVCD).Locked  = true;  //병상위치구분코드
            //this.sprBed_Sheet1.Columns.Get((int)COL.OXYG_YN).Locked        = true;  //산소여부
            //this.sprBed_Sheet1.Columns.Get((int)COL.SUCT_YN).Locked        = true;  //Suction여부
            //this.sprBed_Sheet1.Columns.Get((int)COL.BED_PCFT).Locked       = true;  //병상특이사항
            //this.sprBed_Sheet1.Columns.Get((int)COL.USE_YN).Locked         = true;  //사용여부

            this.sprBed_Sheet1.Columns.Get((int)COL_B.WARD_CD).Locked = true;  //병동코드
            this.sprBed_Sheet1.Columns.Get((int)COL_B.ROOM_CD).Locked = true;  //병실코드
            this.sprBed_Sheet1.Columns.Get((int)COL_B.ETC_USE_CNTS_1).Locked = true;  //기타사용내용첫째
            this.sprBed_Sheet1.Columns.Get((int)COL_B.ETC_USE_CNTS_2).Locked = true;  //기타사용내용둘째
            this.sprBed_Sheet1.Columns.Get((int)COL_B.ETC_USE_CNTS_3).Locked = true;  //기타사용내용셋째
            this.sprBed_Sheet1.Columns.Get((int)COL_B.RGST_DT).Locked = true;  //등록일시
            this.sprBed_Sheet1.Columns.Get((int)COL_B.RGSTR_ID).Locked = true;  //등록자ID
            this.sprBed_Sheet1.Columns.Get((int)COL_B.UPDT_DT).Locked = true;  //수정일시
            this.sprBed_Sheet1.Columns.Get((int)COL_B.UPDTR_ID).Locked = true;  //수정자ID

            FarPoint.Win.Spread.CellType.ComboBoxCellType comboCellType = new FarPoint.Win.Spread.CellType.ComboBoxCellType();
            comboCellType.Editable = false;
            this.sprBed.ActiveSheet.Columns.Get((int)COL_B.BED_LCTN_DVCD).CellType = comboCellType;

            this.sprBed_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.sprBed_Sheet1.RowHeader.Visible = true;
            this.sprBed_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;

            this.sprBed.ActiveSheet.ColumnCount = (int)COL_B.UPDTR_ID + 1;
            this.sprBed.ActiveSheet.RowCount = 0;
            this.sprBed.TextTipDelay = 10;
            this.sprBed.TextTipPolicy = FarPoint.Win.Spread.TextTipPolicy.Floating;

            FarPoint.Win.Spread.CellType.TextCellType textCellType1 = new FarPoint.Win.Spread.CellType.TextCellType();
            sprBed.ActiveSheet.Columns.Get((int)COL_B.BED_NO).CellType = textCellType1;
            textCellType1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            textCellType1.MaxLength = 10;
        }

        #endregion Method : Initialize Method

        #region Method : Private Method

        private void SelectDataWard()
        {
            try
            {
                sprWard.ActiveSheet.Rows.Count = 0;

                DataTable dt = new DataTable();

                if (!DBService.ExecuteDataTable(SQL.BI.Sql.SelectBIDEPTMA_ROOM(chkBassDdd.Checked ? dteAplyDd.DateTime.ToString("yyyyMMdd") : string.Empty), ref dt))
                    throw new Exception("병동 조회 중 에러가 발생했습니다.");

                sprWard.FillDataTag(dt);

                if (dt.Rows.Count > 0)
                    SelectDataRoom();
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        private void SelectDataRoom(string room_cd = "", string aply_strt_dd = "")
        {
            try
            {
                sprRoom.ActiveSheet.Rows.Count = 0;

                if (sprWard.ActiveSheet.ActiveRowIndex < 0)
                    return;

                DataTable dt = new DataTable();

                string ward_cd = sprWard.GetValue(sprWard.ActiveSheet.ActiveRowIndex, "DEPT_CD").ToString();

                if (!DBService.ExecuteDataTable(SQL.BI.Sql.SelectBIROOMMA(ward_cd, chkBassDdd.Checked ? dteAplyDd.DateTime.ToString("yyyyMMdd"): string.Empty), ref dt))
                    throw new Exception("병실 정보를 조회하는 중 에러가 발생했습니다.");

                sprRoom.RowChanged -= sprRoom_RowChanged;
                sprRoom.FillDataTag(dt);
                sprRoom.RowChanged += sprRoom_RowChanged;

                if (!string.IsNullOrWhiteSpace(room_cd) && !string.IsNullOrWhiteSpace(aply_strt_dd))
                {
                    var temp = dt.AsEnumerable().Where(r => r["ROOM_CD"].ToString().Equals(room_cd) && r["APLY_STRT_DD"].ToString().Equals(aply_strt_dd));
                    if (temp.Any())
                    {
                        int i = temp.Select(r => r.Table.Rows.IndexOf(r)).FirstOrDefault();
                        sprRoom.RowChanged -= sprRoom_RowChanged;
                        sprRoom.ActiveSheet.ActiveRowIndex = i;
                        sprRoom.SetActiveCell(i, 0);
                        sprRoom.RowChanged += sprRoom_RowChanged;
                        sprRoom.ShowActiveCell(FarPoint.Win.Spread.VerticalPosition.Center, FarPoint.Win.Spread.HorizontalPosition.Left);
                    }
                }

                SelectDataBed();

                sprRoom.Focus();
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        #endregion Method : Detail Spread 조회

        #region Method : Detail Sub Spread 조회

        private void SelectDataBed()
        {
            try
            {
                sprBed.ActiveSheet.Rows.Count = 0;

                if (sprRoom.ActiveSheet.ActiveRowIndex < 0)
                    return;

                string ward_cd = sprWard.GetValue(sprWard.ActiveSheet.ActiveRowIndex, "DEPT_CD").ToString();
                string room_cd = sprRoom.GetValue(sprRoom.ActiveSheet.ActiveRowIndex, "ROOM_CD").ToString();

                DataTable dt = new DataTable();

                if (!DBService.ExecuteDataTable(SQL.BI.Sql.SelectBIRMBDMA(ward_cd, room_cd, dteAplyDd.DateTime.ToString("yyyyMMdd")), ref dt))
                    throw new Exception("병상 정보를 조회하는 중 에러가 발생했습니다.");

                sprBed.FillDataTag(dt);
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        #endregion Method : Detail Sub Spread 조회

        #region Method : Row 추가

        private void AppendData()
        {
            try
            {
                int addrow = sprRoom.AppendRow();
                sprRoom.SetValue(addrow, (int)COL_R.APLY_STRT_DD, dteAplyDd.DateTime.ToString("yyyyMMdd"));
                sprRoom.SetValue(addrow, (int)COL_R.APLY_END_DD, "29991231");
                sprRoom.SetValue(addrow, (int)COL_R.USE_YN, "Y");
                sprRoom.SetValue(addrow, (int)COL_R.ROOM_DVCD, "1");
                sprRoom.SetValue(addrow, (int)COL_R.ROOM_GRAD_CD, "40");
                sprRoom.SetValue(addrow, (int)COL_R.BASS_BED_CNT, "4");
                sprRoom.SetValue(addrow, (int)COL_R.AVLB_BED_CNT, "4");
                sprRoom.SetValue(addrow, (int)COL_R.MFML_APLY_YN, "A");
                sprRoom.SetValue(addrow, (int)COL_R.MFML_MIX_PSBL_YN, "Y");
                sprRoom.ActiveSheet.Columns[0].Locked = false;

                sprRoom.ActiveSheet.SetActiveCell(addrow, (int)COL_R.ROOM_CD);
                sprRoom.ShowRow(0, addrow, FarPoint.Win.Spread.VerticalPosition.Nearest);
                sprRoom.Focus();
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        private void CopyData()
        {
            int a = sprRoom.ActiveSheet.ActiveRowIndex;
            int z = sprRoom.AppendRow();

            for (int i = 0; i < sprRoom.ActiveSheet.Columns.Count; i++)
            {
                sprRoom.ActiveSheet.Cells[z, i].Value = sprRoom.ActiveSheet.Cells[a, i].Value;
            }
        }

        private void CopyDataRoom()
        {
            int a = sprBed.ActiveSheet.ActiveRowIndex;
            int z = sprBed.AppendRow();

            for (int i = 0; i < sprBed.ActiveSheet.Columns.Count; i++)
            {
                sprBed.ActiveSheet.Cells[z, i].Value = sprBed.ActiveSheet.Cells[a, i].Value;
            }
        }

        private void AppendBed()
        {
            try
            {
                if (sprRoom.ActiveSheet.RowCount == 0)
                {
                    LxMessage.Show("상위병실이 존재하지 않습니다.\r\n상위병실을 먼저 입력해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                int i = sprBed.AppendRow();
                sprBed.SetValue(i, (int)COL_B.WARD_CD, sprWard.GetValue(sprWard.ActiveSheet.ActiveRowIndex, "DEPT_CD").ToString());
                sprBed.SetValue(i, (int)COL_B.ROOM_CD, sprRoom.GetValue(sprRoom.ActiveSheet.ActiveRowIndex, "ROOM_CD").ToString());
                sprBed.SetValue(i, (int)COL_B.APLY_STRT_DD, sprWard.GetText(sprWard.ActiveSheet.ActiveRowIndex, "APLY_STRT_DD").ToString());

                sprBed.ActiveSheet.Cells[i, (int)COL_B.APLY_STRT_DD].Value = sprRoom.GetValue(sprRoom.ActiveSheet.ActiveRowIndex, "APLY_STRT_DD").ToString();

                sprBed.SetValue(i, (int)COL_B.APLY_END_DD, "29991231");
                sprBed.SetValue(i, (int)COL_B.USE_YN, "Y");
                sprBed.Focus();
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        #endregion Method : Row 추가

        #region Method : 데이터 저장

        private void SaveData()
        {
            if (!sprRoom.IsModified() && !sprBed.IsModified())
            {
                LxMessage.Show("저장할 데이터가 없습니다", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (sprRoom.IsModified() && !ValidationRoom())
                return;

            if (sprBed.IsModified() && !ValidationBed())
                return;

            string currentdate = DateTime.Now.ToString("yyyyMMddHHmmss");

            try
            {
                DBService.BeginTransaction();

                // 병실
                for (int i = 0; i < sprRoom.ActiveSheet.RowCount; i++)
                {
                    if (sprRoom.GetCRUDFromRow(i) == CRUD_TYPE.Create)
                    {
                        if (!DBService.ExecuteNonQuery(SQL.BI.Sql.InsertBIROOMMA(), sprWard.GetValue(sprWard.ActiveSheet.ActiveRowIndex, "DEPT_CD").ToString()
                                                                                        , sprRoom.GetValue(i, "ROOM_CD").ToString()
                                                                                        , DateTimeService.ConvertDateTimeStringToFormatString(sprRoom.GetValue(i, "APLY_STRT_DD").ToString(), "yyyyMMdd")
                                                                                        , DateTimeService.ConvertDateTimeStringToFormatString(sprRoom.GetValue(i, "APLY_END_DD").ToString(), "yyyyMMdd")
                                                                                        , sprRoom.GetValue(i, "ROOM_DVCD").ToString()
                                                                                        , sprRoom.GetValue(i, "ROOM_GRAD_CD").ToString()
                                                                                        , sprRoom.GetValue(i, "BASS_BED_CNT").ToString()
                                                                                        , sprRoom.GetValue(i, "AVLB_BED_CNT").ToString()
                                                                                        , ""
                                                                                        , sprRoom.GetValue(i, "MFML_APLY_YN").ToString()
                                                                                        , sprRoom.GetValue(i, "MFML_MIX_PSBL_YN").ToString()
                                                                                        , ""
                                                                                        , sprRoom.GetValue(i, "NRCR_GRAD_CD").ToString()
                                                                                        , "1"
                                                                                        , sprRoom.GetValue(i, "USE_YN").ToString()
                                                                                        , sprRoom.GetValue(i, "PCLR_MATR").ToString()
                                                                                        , DOPack.UserInfo.USER_CD))
                            throw new Exception("병실 정보 신규 저장 중 에러가 발생했습니다.");
                    }
                    else if (sprRoom.GetCRUDFromRow(i) == CRUD_TYPE.Update)
                    {
                        if (!DBService.ExecuteNonQuery(SQL.BI.Sql.UpdateBIROOMMA(), sprWard.GetValue(sprWard.ActiveSheet.ActiveRowIndex, "DEPT_CD").ToString()
                                                                                    , sprRoom.GetValue(i, "ROOM_CD").ToString()
                                                                                    , DateTimeService.ConvertDateTimeStringToFormatString(sprRoom.GetValue(i, "APLY_STRT_DD").ToString(), "yyyyMMdd")
                                                                                    , DateTimeService.ConvertDateTimeStringToFormatString(sprRoom.GetValue(i, "APLY_END_DD").ToString(), "yyyyMMdd")
                                                                                    , sprRoom.GetValue(i, "ROOM_DVCD").ToString()
                                                                                    , sprRoom.GetValue(i, "ROOM_GRAD_CD").ToString()
                                                                                    , sprRoom.GetValue(i, "BASS_BED_CNT").ToString()
                                                                                    , sprRoom.GetValue(i, "AVLB_BED_CNT").ToString()
                                                                                    , ""
                                                                                    , sprRoom.GetValue(i, "MFML_APLY_YN").ToString()
                                                                                    , sprRoom.GetValue(i, "MFML_MIX_PSBL_YN").ToString()
                                                                                    , ""
                                                                                    , sprRoom.GetValue(i, "NRCR_GRAD_CD").ToString()
                                                                                    , "1"
                                                                                    , sprRoom.GetValue(i, "USE_YN").ToString()
                                                                                    , sprRoom.GetValue(i, "PCLR_MATR").ToString()
                                                                                    , DOPack.UserInfo.USER_CD
                                                                                    , sprWard.GetOldValue(sprWard.ActiveSheet.ActiveRowIndex, "DEPT_CD").ToString()
                                                                                    , sprRoom.GetOldValue(i, "ROOM_CD").ToString()
                                                                                    , sprRoom.GetOldValue(i, "APLY_STRT_DD").ToString()))
                            throw new Exception("병실 정보 신규 저장 중 에러가 발생했습니다.");
                    }
                }
                for (int i = 0; i < sprBed.ActiveSheet.Rows.Count; i++)
                {
                    if (sprBed.GetCRUDFromRow(i).Equals(CRUD_TYPE.Create))
                    {
                        if (!DBService.ExecuteNonQuery(SQL.BI.Sql.InsertBIRMBDMA(), sprWard.GetValue(sprWard.ActiveSheet.ActiveRowIndex, "DEPT_CD").ToString()       //병동코드
                                                                                  , sprRoom.GetValue("ROOM_CD").ToString()        //병실코드
                                                                                  , sprBed.GetValue(i, (int)COL_B.BED_NO).ToString()         //병상번호
                                                                                  , sprBed.GetValue(i, (int)COL_B.APLY_STRT_DD).ToString()   //적용시작일자
                                                                                  , sprBed.GetValue(i, (int)COL_B.APLY_END_DD).ToString()    //적용종료일자
                                                                                  , sprBed.GetValue(i, (int)COL_B.BED_LCTN_DVCD).ToString()  //병상위치구분코드
                                                                                  , sprBed.GetValue(i, (int)COL_B.OXYG_YN).ToString()        //산소여부
                                                                                  , sprBed.GetValue(i, (int)COL_B.SUCT_YN).ToString()        //Suction여부
                                                                                  , sprBed.GetValue(i, (int)COL_B.BED_PCFT).ToString()       //병상특이사항
                                                                                  , sprBed.GetValue(i, (int)COL_B.USE_YN).ToString()         //사용여부
                                                                                  , ""                                                     //기타사용내용첫째
                                                                                  , ""                                                     //기타사용내용둘째
                                                                                  , ""                                                     //기타사용내용셋째
                                                                                  , currentdate                                            //등록일시, 수정일시
                                                                                  , DOPack.UserInfo.USER_CD))                              //등록자ID, 수정자ID
                            throw new Exception("병상정보를 신규 저장하는 중 에러가 발생했습니다.");
                    }
                    else if (sprBed.GetCRUDFromRow(i).Equals(CRUD_TYPE.Update))
                    {
                        if (!DBService.ExecuteNonQuery(SQL.BI.Sql.UpdateBIRMBDMA(), sprBed.GetValue(i, (int)COL_B.BED_NO).ToString()            //병상번호
                                                                                  , sprBed.GetValue(i, (int)COL_B.APLY_STRT_DD).ToString()      //적용시작일자
                                                                                  , sprBed.GetValue(i, (int)COL_B.APLY_END_DD).ToString()       //적용종료일자
                                                                                  , sprBed.GetValue(i, (int)COL_B.BED_LCTN_DVCD).ToString()     //병상위치구분코드
                                                                                  , sprBed.GetValue(i, (int)COL_B.OXYG_YN).ToString()           //산소여부
                                                                                  , sprBed.GetValue(i, (int)COL_B.SUCT_YN).ToString()           //Suction여부
                                                                                  , sprBed.GetValue(i, (int)COL_B.BED_PCFT).ToString()          //병상특이사항
                                                                                  , sprBed.GetValue(i, (int)COL_B.USE_YN).ToString()            //사용여부
                                                                                  , currentdate                                               //수정일시
                                                                                  , DOPack.UserInfo.USER_CD                                   //수정자ID
                                                                                  , sprBed.GetValue(i, (int)COL_B.WARD_CD).ToString()           //병동코드
                                                                                  , sprBed.GetValue(i, (int)COL_B.ROOM_CD).ToString()           //병실코드
                                                                                  , sprBed.GetOldValue(i, (int)COL_B.BED_NO).ToString()         //병상번호
                                                                                  , sprBed.GetOldValue(i, (int)COL_B.APLY_STRT_DD).ToString()   //적용시작일자
                                                                                  , sprBed.GetOldValue(i, (int)COL_B.APLY_END_DD).ToString()))  //적용시작일자
                            throw new Exception("병상정보를 변경 저장하는 중 에러가 발생했습니다.");
                    }
                }

                DBService.CommitTransaction();

                LxMessage.ShowInformation("저장되었습니다.", 3);

                SelectDataRoom();
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                if (DBService.IsTransaction)
                    DBService.RollbackTransaction();

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        #endregion Method : 데이터 저장

        #region Method : Validation

        private bool ValidationRoom()
        {
            DataTable dt = sprRoom.ToDataTable();

            for (int i = 0; i < sprRoom.ActiveSheet.RowCount; i++)
            {
                if (sprRoom.GetCRUDFromRow(i) != CRUD_TYPE.Create && sprRoom.GetCRUDFromRow(i) != CRUD_TYPE.Update)
                    continue;

                string room_cd = sprRoom.ActiveSheet.Cells[i, (int)COL_R.ROOM_CD]?.Value.ToString();
                string aply_strt_dd = sprRoom.ActiveSheet.Cells[i, (int)COL_R.APLY_STRT_DD]?.Value.ToString().Replace("-", "");
                string aply_end_dd  = sprRoom.ActiveSheet.Cells[i, (int)COL_R.APLY_END_DD]?.Value.ToString().Replace("-", "");

                if (string.IsNullOrWhiteSpace(room_cd))
                {
                    sprRoom.SetActiveCell(i, (int)COL_R.ROOM_CD);
                    sprRoom.ShowActiveCell(FarPoint.Win.Spread.VerticalPosition.Center, FarPoint.Win.Spread.HorizontalPosition.Left);
                    LxMessage.ShowError("[병실코드]가 입력되지 않았습니다.");
                    return false;
                }

                if (!DateTimeService.IsDateTime(aply_strt_dd))
                {
                    sprRoom.SetActiveCell(i, (int)COL_R.APLY_STRT_DD);
                    sprRoom.ShowActiveCell(FarPoint.Win.Spread.VerticalPosition.Center, FarPoint.Win.Spread.HorizontalPosition.Left);
                    LxMessage.ShowError("[적용시작일자]가 잘 못 입력되었습니다.");
                    return false;
                }

                if (!DateTimeService.IsDateTime(aply_end_dd))
                {
                    sprRoom.SetActiveCell(i, (int)COL_R.APLY_END_DD);
                    sprRoom.ShowActiveCell(FarPoint.Win.Spread.VerticalPosition.Center, FarPoint.Win.Spread.HorizontalPosition.Left);
                    LxMessage.ShowError("[적용종료일자]가 잘 못 입력되었습니다.");
                    return false;
                }

                // 기간 중복된 내역을 찾는다.

                // 병실코드가 같은 내역 중에 현재 rowindex와 다른 내역
                var temp = dt.AsEnumerable().Where(r => r["ROOM_CD"].ToString().Equals(room_cd) && !r["APLY_STRT_DD"].ToString().Equals(aply_strt_dd) && !r["APLY_END_DD"].ToString().Equals(aply_end_dd));
                if (temp.Any())
                {
                    var tempDup = temp.Where(r => DateTimeService.ConvertDateTime(r["APLY_STRT_DD"].ToString()) <= DateTimeService.ConvertDateTime(aply_end_dd) &&
                                                  DateTimeService.ConvertDateTime(aply_strt_dd) <= DateTimeService.ConvertDateTime(r["APLY_END_DD"].ToString()));
                    if (tempDup.Any())
                    {
                        sprRoom.SetActiveCell(i, (int)COL_R.APLY_STRT_DD);
                        sprRoom.ShowActiveCell(FarPoint.Win.Spread.VerticalPosition.Center, FarPoint.Win.Spread.HorizontalPosition.Left);
                        LxMessage.ShowError("기간이 겹치는 내역이 존재합니다.");
                        return false;
                    }
                }

                if (string.IsNullOrWhiteSpace(sprRoom.ActiveSheet.Cells[i, (int)COL_R.ROOM_GRAD_CD]?.Value?.ToString() ?? string.Empty))
                {
                    sprRoom.SetActiveCell(i, (int)COL_R.ROOM_GRAD_CD);
                    sprRoom.ShowActiveCell(FarPoint.Win.Spread.VerticalPosition.Center, FarPoint.Win.Spread.HorizontalPosition.Left);
                    LxMessage.ShowError("병실등급을 선택해 주세요.");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(sprRoom.ActiveSheet.Cells[i, (int)COL_R.ROOM_DVCD]?.Value?.ToString() ?? string.Empty))
                {
                    sprRoom.SetActiveCell(i, (int)COL_R.ROOM_DVCD);
                    sprRoom.ShowActiveCell(FarPoint.Win.Spread.VerticalPosition.Center, FarPoint.Win.Spread.HorizontalPosition.Left);
                    LxMessage.ShowError("병실구분을 선택해 주세요.");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(sprRoom.ActiveSheet.Cells[i, (int)COL_R.NRCR_GRAD_CD]?.Value?.ToString() ?? string.Empty))
                {
                    sprRoom.SetActiveCell(i, (int)COL_R.NRCR_GRAD_CD);
                    sprRoom.ShowActiveCell(FarPoint.Win.Spread.VerticalPosition.Center, FarPoint.Win.Spread.HorizontalPosition.Left);
                    LxMessage.ShowError("간호등급을 선택해 주세요.");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(sprRoom.ActiveSheet.Cells[i, (int)COL_R.BASS_BED_CNT]?.Value?.ToString() ?? string.Empty))
                {
                    sprRoom.SetActiveCell(i, (int)COL_R.BASS_BED_CNT);
                    sprRoom.ShowActiveCell(FarPoint.Win.Spread.VerticalPosition.Center, FarPoint.Win.Spread.HorizontalPosition.Left);
                    LxMessage.ShowError("기준병상을 입력해 주세요.");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(sprRoom.ActiveSheet.Cells[i, (int)COL_R.AVLB_BED_CNT]?.Value?.ToString() ?? string.Empty))
                {
                    sprRoom.SetActiveCell(i, (int)COL_R.AVLB_BED_CNT);
                    sprRoom.ShowActiveCell(FarPoint.Win.Spread.VerticalPosition.Center, FarPoint.Win.Spread.HorizontalPosition.Left);
                    LxMessage.ShowError("가동병상을 입력해 주세요.");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(sprRoom.ActiveSheet.Cells[i, (int)COL_R.MFML_APLY_YN]?.Value?.ToString() ?? string.Empty))
                {
                    sprRoom.SetActiveCell(i, (int)COL_R.MFML_APLY_YN);
                    sprRoom.ShowActiveCell(FarPoint.Win.Spread.VerticalPosition.Center, FarPoint.Win.Spread.HorizontalPosition.Left);
                    LxMessage.ShowError("남녀구분을 선택해 주세요.");
                    return false;
                }

                if (!string.IsNullOrWhiteSpace(sprRoom.ActiveSheet.Cells[i, (int)COL_R.PCLR_MATR]?.Value?.ToString() ?? string.Empty) && 
                    StringService.ByteCount(sprRoom.ActiveSheet.Cells[i, (int)COL_R.PCLR_MATR]?.Value?.ToString()) > 300)
                {
                    sprRoom.SetActiveCell(i, (int)COL_R.PCLR_MATR);
                    sprRoom.ShowActiveCell(FarPoint.Win.Spread.VerticalPosition.Center, FarPoint.Win.Spread.HorizontalPosition.Left);
                    LxMessage.ShowError("참고사항은 영문 300자, 한글 150자 이내로 입력해 주세요.");
                    return false;
                }
            }

            return true;
        }

        private bool ValidationBed()
        {
            try
            {
                if (sprBed.ActiveSheet.ActiveRowIndex.Equals(-1))
                    return false;

                for (int i = 0; i < sprBed.ActiveSheet.Rows.Count; i++)
                {
                    CRUD_TYPE crud = sprBed.GetCRUDFromRow(i);
                    if (crud.Equals(CRUD_TYPE.Read) || crud.Equals(CRUD_TYPE.Delete))
                        continue;

                    if (StringService.IsNull(sprBed.GetValue(i, (int)COL_B.BED_NO).ToString()))
                    {
                        LxMessage.ShowError("병상번호가 입력되지 않았습니다");
                        sprBed.SetActiveCell(i, (int)COL_B.BED_NO);
                        sprBed.Focus();
                        return false;
                    }

                    if (StringService.IsNull(sprBed.GetValue(i, (int)COL_B.APLY_STRT_DD).ToString().Replace("-", "")) ||
                        !DateTimeService.IsDateTime(sprBed.GetValue(i, (int)COL_B.APLY_STRT_DD).ToString()))
                    {
                        LxMessage.ShowError("적용시작일의 입력이 잘못되었습니다");
                        sprBed.SetActiveCell(i, (int)COL_B.APLY_STRT_DD);
                        sprBed.Focus();
                        return false;
                    }

                    if (StringService.IsNull(sprBed.GetValue(i, (int)COL_B.APLY_END_DD).ToString().Replace("-", "")) ||
                        !DateTimeService.IsDateTime(sprBed.GetValue(i, (int)COL_B.APLY_END_DD).ToString()))
                    {
                        LxMessage.ShowError("적용종료일의 입력이 잘못되었습니다");
                        sprBed.SetActiveCell(i, (int)COL_B.APLY_END_DD);
                        sprBed.Focus();
                        return false;
                    }

                    if (DateTimeService.ConvertDateTime(sprBed.GetValue(i, (int)COL_B.APLY_STRT_DD).ToString()) >
                        DateTimeService.ConvertDateTime(sprBed.GetValue(i, (int)COL_B.APLY_END_DD).ToString()))
                    {
                        LxMessage.ShowError("적용시작일이 적용종료일보다 큽니다.\r\n다시 입력해 주세요");
                        sprBed.SetActiveCell(i, (int)COL_B.APLY_END_DD);
                        sprBed.Focus();
                        return false;
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
        }

        #endregion Method : Validation

        #region Method : 데이터 삭제

        private void DeleteData()
        {
            try
            {
                if (m_FocusedSpread.Equals(sprRoom))
                {
                    if (sprRoom.ActiveSheet.RowCount == 0)
                    {
                        LxMessage.Show("삭제할 데이터가 없습니다", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    DialogResult result = LxMessage.Show(string.Format("선택한 병실코드 '{0}' 를 삭제하시겠습니까?", sprRoom.GetOldValue("ROOM_CD").ToString()), "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (!result.Equals(DialogResult.Yes))
                        return;

                    if (sprRoom.GetCRUDFromRow() == CRUD_TYPE.Create)
                    {
                        sprRoom.RemoveRow();
                    }
                    else
                    {
                        //하위 BED정보가 있으면 Return.
                        if (sprBed.ActiveSheet.RowCount != 0)
                        {
                            LxMessage.Show("하위 병상리스트가 존재합니다.\r\n병상을 먼저 삭제해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            return;
                        }

                        if (DBService.ExecuteNonQuery(SQL.BI.Sql.DeleteBIROOMMA(), sprWard.GetValue(sprWard.ActiveSheet.ActiveRowIndex, "DEPT_CD").ToString()
                                                                                    , sprRoom.GetValue("ROOM_CD").ToString()
                                                                                    , DateTimeService.ConvertDateTimeStringToFormatString(sprRoom.GetValue("APLY_STRT_DD").ToString(), "yyyyMMdd")
                                                                                    ))
                        {
                            LxMessage.Show("삭제가 완료되었습니다", "완료", MessageBoxButtons.OK, MessageBoxIcon.Information, 2);
                            SelectDataRoom();
                        }
                        else
                        {
                            LxMessage.Show("삭제 중 에러가 발생하였습니다", "경고", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                else if (m_FocusedSpread.Equals(sprBed))
                {
                    if (sprBed.ActiveSheet.Rows.Count.Equals(0))
                    {
                        LxMessage.Show("삭제할 데이터가 없습니다", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (!LxMessage.ShowQuestion(string.Format("선택한 병상번호 '{0}' 를 삭제하시겠습니까?", sprBed.GetValue((int)COL_B.BED_NO).ToString())).Equals(DialogResult.Yes))
                        return;

                    // 추가한 행 삭제할 경우
                    if (sprBed.GetCRUDFromRow().Equals(CRUD_TYPE.Create))
                    {
                        sprBed.RemoveRow();
                        return;
                    }

                    // TABLE에 존재하는 행 삭제할 경우
                    int i = sprBed.ActiveSheet.ActiveRowIndex;
                    if (!DBService.ExecuteNonQuery(SQL.BI.Sql.DeleteBIRMBDMA(), sprBed.GetOldValue(i, (int)COL_B.WARD_CD).ToString()
                                                                                , sprBed.GetOldValue(i, (int)COL_B.ROOM_CD).ToString()
                                                                                , sprBed.GetOldValue(i, (int)COL_B.BED_NO).ToString()
                                                                                , sprBed.GetOldValue(i, (int)COL_B.APLY_STRT_DD).ToString()
                                                                                , sprBed.GetOldValue(i, (int)COL_B.APLY_END_DD).ToString()))
                    {
                        LxMessage.ShowError("삭제 중 에러가 발생하였습니다");
                        return;
                    }

                    //LxMessage.Show("삭제 되었습니다", "완료", MessageBoxButtons.OK, MessageBoxIcon.Information, 2);
                    SelectDataBed();
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
        }

        #endregion Method : 데이터 삭제

        #region Event : Event Process

        private void btnButtonList_ButtonClick(object sender, ButtonClickEventArgs e)
        {
            switch (e.ButtonType)
            {
                case ButtonType.Select:
                    SelectDataWard();
                    break;

                // 병실 추가
                case ButtonType.Append:
                    AppendData();
                    break;

                // 병실 복사
                case ButtonType.Copy:
                    CopyData();
                    break;

                // 병상 추가
                case ButtonType.Custom1:
                    AppendBed();
                    break;

                // 병상 복사
                case ButtonType.Custom2:
                    CopyDataRoom();
                    break;

                // 저장
                case ButtonType.Delete:
                    DeleteData();
                    break;

                // 삭제
                case ButtonType.Save:
                    SaveData();
                    break;

                case ButtonType.Close:
                    Close();
                    break;
            }
        }

        private void chkBassDdd_CheckedChanged(object sender, EventArgs e)
        {
            dteAplyDd.Enabled = chkBassDdd.Checked;

            SelectDataRoom();
        }

        private void sprWard_RowChanged(object sender, LxSpread.RowChangedEventArgs e)
        {
            SelectDataRoom();
        }

        private void sprRoom_RowChanged(object sender, LxSpread.RowChangedEventArgs e)
        {
            if (sprRoom.ActiveSheet.ActiveRowIndex.Equals(-1))
                return;

            SelectDataBed();

            sprRoom.ActiveSheet.Columns[0].Locked = sprRoom.GetCRUDFromRow() != CRUD_TYPE.Create;
        }

        #endregion Event : Event Process
    }
}