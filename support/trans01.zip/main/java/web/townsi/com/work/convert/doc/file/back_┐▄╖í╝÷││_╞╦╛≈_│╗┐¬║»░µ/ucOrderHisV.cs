using System;
using System.ComponentModel;
using System.Data;
using Lime.Framework;
using Lime.Framework.Controls;

namespace Lime.PA
{
    [ToolboxItem(true)]
    public partial class ucOrderHisV : BaseUserControl
    {
        private string m_PID = string.Empty;
        private string m_PtCmhsNo = string.Empty;

        public ucOrderHisV()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode)
                return;

            sprMain.ActiveSheet.ColumnHeader.Rows[0].Height = 22;
            sprMain.ActiveSheet.Rows[-1].Height = 22;
            sprSub.ActiveSheet.ColumnHeader.Rows[0].Height = 22;
            sprSub.ActiveSheet.Rows[-1].Height = 22;

            this.SelectMain();
        }

        public void SelectData(string pid, string ptcmhsno)
        {
            m_PID = pid;
            m_PtCmhsNo = ptcmhsno;

            if (sprMain.ActiveSheet.Rows.Count > 0)
                sprMain.ActiveSheet.ActiveRowIndex = 0;

            this.SelectSub();
        }

        public void Clear()
        {
            m_PID = string.Empty;
            m_PtCmhsNo = string.Empty;

            this.sprSub.ActiveSheet.Rows.Count = 0;
        }

        private void SelectMain()
        {
            DataTable dt = OverallCodeList.GetDataList("OR_DLVR_CD");
            sprMain.FillDataTag(dt);
            sprMain.RowChanged += sprMain_RowChanged;
        }

        private void SelectSub()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(m_PID) || string.IsNullOrWhiteSpace(m_PtCmhsNo))
                    return;

                if (sprMain.ActiveSheet.ActiveRowIndex.Equals(-1))
                    return;

                sprSub.ActiveSheet.Rows.Count = 0;

                string selectedCode = sprMain.GetValue(sprMain.ActiveSheet.ActiveRowIndex, "LWRN_OVRL_CD").ToString();

                string sqltext = string.Format(@"
        SELECT  A.PID,
                MIN(A.MDCR_DD) MDCR_DD,
                MAX(A.PRSC_LAST_DD) PRSC_LAST_DD,
                SUBSTR(MIN(A.MDCR_DD), 3, 6) NY_MDCR_DD,
                SUBSTR(MAX(A.PRSC_LAST_DD), 3, 6) NY_PRSC_LAST_DD,
                A.PRSC_CD,
                A.PRSC_NM,
                SUM(A.ONTM_QTY * A.NOTM) QTY,
                SUM(A.NODY) NODY
           FROM ORORDRRT A
          WHERE A.PID          = '{0}'
            AND A.PT_CMHS_NO   =  {1}
            AND A.DEL_YN       = 'A'
            AND A.DC_PRSC_DVCD = 'A' ", m_PID, m_PtCmhsNo);

                #region 조건 추가

                switch (selectedCode)
                {
                    // 일반촬영
                    case "RY":
                        sqltext += @"
            AND A.DLVR_DEPT_CD = 'E602'
            AND A.PRSC_LCLS_CD = '50'
            AND A.PRSC_MCLS_CD = '01'
          GROUP BY A.PID, A.PRSC_CD, A.PRSC_NM, A.PRSC_LCLS_CD, A.PRSC_MCLS_CD
          ORDER BY MIN(A.MDCR_DD) DESC";
                        break;
                    // CT/MRI
                    case "CTMRI":
                        sqltext += @"
            AND A.DLVR_DEPT_CD = 'E602'
            AND A.PRSC_LCLS_CD = '50'
            AND A.PRSC_MCLS_CD IN('04', '09')
          GROUP BY A.PID, A.PRSC_CD, A.PRSC_NM, A.PRSC_LCLS_CD, A.PRSC_MCLS_CD
          ORDER BY A.PRSC_MCLS_CD, MIN(A.MDCR_DD) DESC";
                        break;
                    // 특수촬영(초음파, 골밀도, 특수촬영)
                    case "RET":
                        sqltext += @"
            AND A.DLVR_DEPT_CD = 'E602'
            AND A.PRSC_LCLS_CD = '50'
            AND A.PRSC_MCLS_CD NOT IN ('01', '04', '09')
          GROUP BY A.PID, A.PRSC_CD, A.PRSC_NM, A.PRSC_LCLS_CD, A.PRSC_MCLS_CD
          ORDER BY A.PRSC_MCLS_CD, MIN(A.MDCR_DD) DESC";
                        break;
                    // 내시경실
                    case "E101":
                        sqltext += @"
            AND A.DLVR_DEPT_CD = 'E101'
            AND A.PRSC_LCLS_CD = 'A0'
          GROUP BY A.PID, A.PRSC_CD, A.PRSC_NM, A.PRSC_LCLS_CD, A.PRSC_MCLS_CD
          ORDER BY A.PRSC_MCLS_CD, MIN(A.MDCR_DD) DESC";
                        break;
                    // 기능검사(내시경을 제외한 검사)
                    case "FNT":
                        sqltext += @"
            AND A.DLVR_DEPT_CD NOT IN ( 'E101', 'E901', 'E401', 'E602')
            AND A.DLVR_DEPT_CD IN ( SELECT Z.DEPT_CD
                                      FROM BIDEPTMA Z
                                     WHERE Z.DEPT_CLSF_CD = '3'
                                       AND Z.APLY_STRT_DD <= A.MDCR_DD
                                       AND Z.APLY_END_DD  >= A.MDCR_DD )
            AND A.PRSC_LCLS_CD = 'A0'
          GROUP BY A.PID, A.PRSC_CD, A.PRSC_NM, A.PRSC_LCLS_CD, A.PRSC_MCLS_CD
          ORDER BY A.PRSC_MCLS_CD, MIN(A.MDCR_DD) DESC";
                        break;
                    // 물리치료실
                    case "E401":
                        sqltext += @"
            AND A.DLVR_DEPT_CD = 'E401'
            AND A.PRSC_LCLS_CD = '70'
          GROUP BY A.PID, A.PRSC_CD, A.PRSC_NM, A.PRSC_LCLS_CD, A.PRSC_MCLS_CD
          ORDER BY A.PRSC_MCLS_CD, A.PRSC_CD, MIN(A.MDCR_DD) DESC";
                        break;
                    // 진단검사
                    case "E901":
                        sqltext += @"
            AND A.DLVR_DEPT_CD = 'E901'
            AND A.PRSC_LCLS_CD = '40'
          GROUP BY A.PID, A.PRSC_CD, A.PRSC_NM, A.PRSC_LCLS_CD, A.PRSC_MCLS_CD
          ORDER BY A.PRSC_MCLS_CD, A.PRSC_CD, MIN(A.MDCR_DD) DESC";
                        break;
                    // 약
                    case "MED":
                        sqltext += @"
            AND A.PRSC_LCLS_CD = '30'
          GROUP BY A.PID, A.PRSC_CD, A.PRSC_NM, A.PRSC_LCLS_CD, A.PRSC_MCLS_CD
          ORDER BY A.PRSC_LCLS_CD, A.PRSC_MCLS_CD, A.PRSC_CD, MIN(A.MDCR_DD) DESC";
                        break;
                    // 주사
                    case "INJ":
                        sqltext += @"
            AND A.PRSC_LCLS_CD = '20'
            AND A.PRSC_DVCD   <> 'P'
          GROUP BY A.PID, A.PRSC_CD, A.PRSC_NM, A.PRSC_LCLS_CD, A.PRSC_MCLS_CD
          ORDER BY A.PRSC_LCLS_CD, A.PRSC_MCLS_CD, A.PRSC_CD, MIN(A.MDCR_DD) DESC";
                        break;
                    // 재료
                    case "I0":
                        sqltext += @"
            AND A.PRSC_LCLS_CD = 'I0'
          GROUP BY A.PID, A.PRSC_CD, A.PRSC_NM, A.PRSC_LCLS_CD, A.PRSC_MCLS_CD
          ORDER BY A.PRSC_LCLS_CD, A.PRSC_MCLS_CD, A.PRSC_CD, MIN(A.MDCR_DD) DESC";
                        break;
                    // 항생제
                    case "ANT":
                        sqltext += @"
            AND A.PRSC_LCLS_CD IN('20', '30')
            AND EXISTS ( SELECT Z.*
                           FROM PMMFCDMA Z
                          WHERE A.PRSC_CD = Z.MDPR_CD
                            AND Z.APLY_STRT_DD <= A.MDCR_DD
                            AND Z.APLY_END_DD  >= A.MDCR_DD
                            AND Z.ACMD_DVCD    IN ('10', '20') )
          GROUP BY A.PID, A.PRSC_CD, A.PRSC_NM, A.PRSC_LCLS_CD, A.PRSC_MCLS_CD
          ORDER BY A.PRSC_LCLS_CD, A.PRSC_MCLS_CD, A.PRSC_CD, MIN(A.MDCR_DD) DESC";
                        break;
                    // ETC
                    default:
                        sqltext += string.Format(@"
            AND A.DLVR_DEPT_CD = '{0}'
          GROUP BY A.PID, A.PRSC_CD, A.PRSC_NM, A.PRSC_LCLS_CD, A.PRSC_MCLS_CD
          ORDER BY MIN(A.MDCR_DD DESC)", selectedCode);
                        break;
                }

                #endregion 조건 추가

                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(sqltext, ref dt))
                    throw new Exception("처방내역 조회 중 에러가 발생했습니다.");

                sprSub.FillDataTag(dt);
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        private void sprMain_RowChanged(object sender, LxSpread.RowChangedEventArgs e)
        {
            this.SelectSub();
        }
    }
}
