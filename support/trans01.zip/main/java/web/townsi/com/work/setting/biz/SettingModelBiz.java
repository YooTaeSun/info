package web.townsi.com.work.setting.biz;

import java.util.HashMap;
import java.util.List;

public interface SettingModelBiz {
	public abstract HashMap<String, Object> makeDto(HashMap paramHashMap) throws Exception;
	public abstract HashMap<String, Object> makeVo(HashMap paramHashMap) throws Exception;
}