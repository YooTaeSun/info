using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Lime.Framework
{
    public class ClientEnvironment
    {
        #region Define : Member

        private static string m_SolutionPath = "";
        private static string m_ConfigFolder = "Config";
        private static string m_TempFolder = "Temp";
        private static string m_MakeChartFolder = "MakeChart";
        private static string m_DownChartFolder = "DownChart";
        private static string m_BackupChartFolder = "BackupChart";
        private static string m_ErrorChartFolder = "ErrorChart";
        private static string m_ClipartFolder = "Clipart";
        private static string m_ScanFolder = "Scan";
        private static string m_FontFolder = "Font";
        private static bool m_Initialize = false;

        #endregion

        #region UDP Port

        //Udp Msg Port
        private const int m_UPD_PORT = 15022;

        //Udp Msg Port
        public static int UPD_PORT
        {
            get
            {
                return m_UPD_PORT;
            }
        }

        #endregion

        #region Default Encoder

        public static System.Text.Encoding BaseEncoder
        {
            get
            {
                return StringService.BaseEncoder;
            }
        }

        #endregion


        #region System Environment

        public static string ComputerName
        {
            get
            {
                return ClientService.ComputerName;
            }
        }

        public static string UserName
        {
            get
            {
                return ClientService.UserName;
            }
        }

        #endregion

        #region O/S Environment

        public static string OSVersion
        {
            get
            {
                return ClientService.OSVersion;
            }
        }

        public static bool Is64Bit
        {
            get
            {
                return ClientService.Is64Bit;
            }
        }

        #endregion

        #region Path Environment

        public static string StartupPath
        {
            get
            {
                return ClientService.StartupPath;
            }
            set
            {
                ClientService.StartupPath = value;
            }
        }

        public static string SolutionPath
        {
            get
            {
                if (StringService.IsNull(m_SolutionPath))
                    return ClientService.StartupPath;
                else
                    return m_SolutionPath;
            }
            set
            {
                m_SolutionPath = value;
            }
        }

        public static string CurrentDirectory
        {
            get
            {
                return Environment.CurrentDirectory;
            }
            set
            {
                Environment.CurrentDirectory = value;
            }
        }

        public static void LoadClientFolder()
        {
            try
            {
                m_ConfigFolder = Path.Combine(SolutionPath, ConfigService.GetConfigValueString("%", "CLIENT_FOLDER", "CONFIG", m_ConfigFolder));
                m_TempFolder = Path.Combine(SolutionPath, ConfigService.GetConfigValueString("%", "CLIENT_FOLDER", "TEMP", m_TempFolder));
                m_MakeChartFolder = Path.Combine(SolutionPath, ConfigService.GetConfigValueString("%", "CLIENT_FOLDER", "MAKECHART", m_MakeChartFolder));
                m_DownChartFolder = Path.Combine(SolutionPath, ConfigService.GetConfigValueString("%", "CLIENT_FOLDER", "DOWNCHART", m_DownChartFolder));
                m_BackupChartFolder = Path.Combine(SolutionPath, ConfigService.GetConfigValueString("%", "CLIENT_FOLDER", "BACKUPCHART", m_BackupChartFolder));
                m_ErrorChartFolder = Path.Combine(SolutionPath, ConfigService.GetConfigValueString("%", "CLIENT_FOLDER", "ERRORCHART", m_ErrorChartFolder));
                m_ClipartFolder = Path.Combine(SolutionPath, ConfigService.GetConfigValueString("%", "CLIENT_FOLDER", "CLIPART", m_ClipartFolder));
                m_ScanFolder = Path.Combine(SolutionPath, ConfigService.GetConfigValueString("%", "CLIENT_FOLDER", "SCAN", m_ScanFolder));
                m_FontFolder = Path.Combine(SolutionPath, ConfigService.GetConfigValueString("%", "CLIENT_FOLDER", "FONT", m_FontFolder));
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            m_Initialize = true;
        }

        public static void DeleteClientFolder()
        {
            FileService.DeleteFolder(m_TempFolder);
            FileService.DeleteFolder(m_MakeChartFolder);
            FileService.DeleteFolder(m_DownChartFolder);
        }

        public static string ConfigFolder
        {
            get
            {
                if (!m_Initialize)
                    LoadClientFolder();

                FileService.CreateFolder(m_ConfigFolder);

                return m_ConfigFolder;
            }
            set
            {
                m_ConfigFolder = value;
            }
        }

        public static string TempFolder
        {
            get
            {
                if (!m_Initialize)
                    LoadClientFolder();

                FileService.CreateFolder(m_TempFolder);

                return m_TempFolder;
            }
            set
            {
                m_TempFolder = value;
            }
        }

        public static string MakeChartFolder
        {
            get
            {
                if (!m_Initialize)
                    LoadClientFolder();

                FileService.CreateFolder(m_MakeChartFolder);

                return m_MakeChartFolder;
            }
            set
            {
                m_MakeChartFolder = value;
            }
        }

        public static string DownChartFolder
        {
            get
            {
                if (!m_Initialize)
                    LoadClientFolder();

                FileService.CreateFolder(m_DownChartFolder);

                return m_DownChartFolder;
            }
            set
            {
                m_DownChartFolder = value;
            }
        }

        public static string BackupChartFolder
        {
            get
            {
                if (!m_Initialize)
                    LoadClientFolder();

                FileService.CreateFolder(m_BackupChartFolder);

                return m_BackupChartFolder;
            }
            set
            {
                m_BackupChartFolder = value;
            }
        }

        public static string ErrorChartFolder
        {
            get
            {
                if (!m_Initialize)
                    LoadClientFolder();

                FileService.CreateFolder(m_ErrorChartFolder);

                return m_ErrorChartFolder;
            }
            set
            {
                m_ErrorChartFolder = value;
            }
        }

        public static string ClipartFolder
        {
            get
            {
                if (!m_Initialize)
                    LoadClientFolder();

                FileService.CreateFolder(m_ClipartFolder);

                return m_ClipartFolder;
            }
            set
            {
                m_ClipartFolder = value;
            }
        }

        public static string ScanFolder
        {
            get
            {
                if (!m_Initialize)
                    LoadClientFolder();

                FileService.CreateFolder(m_ScanFolder);

                return m_ScanFolder;
            }
            set
            {
                m_ScanFolder = value;
            }
        }

        public static string FontFolder
        {
            get
            {
                if (!m_Initialize)
                    LoadClientFolder();

                FileService.CreateFolder(m_FontFolder);

                return m_FontFolder;
            }
            set
            {
                m_FontFolder = value;
            }
        }

        #endregion

        #region Network Environment

        public static bool NetworkEnable
        {
            get
            {
                return NetworkService.CheckNetworkAvailable();
            }
        }

        public static string IP
        {
            get
            {
                return NetworkService.IP;
            }
        }

        #endregion

        #region Monitor Environment

        public static Screen PrimaryScreen
        {
            get
            {
                return Screen.PrimaryScreen;
            }
        }

        public static int GetMonitorCount
        {
            get
            {
                return ScreenService.GetMonitorCount;
            }
        }

        public static Size GetPrimaryMonitorSize
        {
            get
            {
                return ScreenService.GetPrimaryMonitorSize;
            }
        }

        public static Rectangle GetWorkingArea
        {
            get
            {
                return ScreenService.GetWorkingArea;
            }
        }

        public static Rectangle GetMaxScreenSize
        {
            get
            {
                return ScreenService.GetMaxScreenSize;
            }
        }

        #endregion

        #region Program Name/Version

        public static string ProgramName
        {
            get
            {
                return ClientService.ProgramName;
            }
        }

        public static string ProgramVersion
        {
            get
            {
                return System.Windows.Forms.Application.ProductVersion.Trim();
            }
        }

        private static int m_TCPPort = 23321;
        public static int TCPPort
        {
            get
            {
                return m_TCPPort;
            }
            set
            {
                m_TCPPort = value;
            }
        }

        #endregion

        #region Design Mode

        private static bool m_DesignMode = true;
        public static bool DesignMode
        {
            get
            {
                return m_DesignMode;
            }
            set
            {
                m_DesignMode = value;
                DBService.DesignMode = value;
            }
        }

        #endregion

        #region Printer Name

        private static string m_PrinterName = "";
        public static string PrinterName
        {
            get
            {
                return m_PrinterName;
            }

            set
            {
                m_PrinterName = value;
            }
        }

        public static string GetWindowDefaultPrinterName()
        {
            System.Drawing.Printing.PrinterSettings prn = new System.Drawing.Printing.PrinterSettings();

            return prn.PrinterName;
        }

        #endregion

        #region SignPad

        private static bool m_SignPadConnected = false;
        public static bool SignPadConnected
        {
            get
            {
                return m_SignPadConnected;
            }
            set
            {
                m_SignPadConnected = value;
            }
        }

        #endregion

        #region Process Number

        public static int ProcessNumber
        {
            get
            {
                return ClientService.ProcessNumber;
            }
            set
            {
                ClientService.ProcessNumber = value;
            }
        }

        public static bool FristRunClient
        {
            get
            {
                return ClientService.FristRunClient;
            }
        }

        #endregion
    }
}
