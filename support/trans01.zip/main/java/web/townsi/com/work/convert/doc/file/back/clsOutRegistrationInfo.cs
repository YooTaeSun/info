//********************************************************************************
// Class 명 : clsOutRegistrationInfo
// 역    할 : 외래접수정보
// 작 성 자 : PGH
// 작 성 일 : 2017-08-23
//********************************************************************************
// 수정내역 : 
//********************************************************************************
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public class clsOutRegistrationInfo
    {
        // 임상시험센터 Lime 이용
        bool m_l090_lime_accept = ConfigService.GetConfigValueBool("%", "L090_LIME_ACCEPT", "L090_LIME_ACCEPT");

        #region Define Variable Member
        private string m_NEW_PID_YN = "N";               //신환여부
        private string m_OTPT_ADMS_DVCD = String.Empty;      //외래입원구분
        private string m_PID = String.Empty;      //환자등록번호                     VARCHAR2(10)
        private int m_PT_CMHS_NO = 0;                 //환자내원번호                     NUMBER(10, 0)
        private int m_RCPN_SQNO = 0;                 //접수일련번호                     NUMBER(3, 0)
        private string m_MDCR_DD = String.Empty;      //진료일자                         VARCHAR2(8)
        private string m_APNT_TIME = String.Empty;      //예약시간                         VARCHAR2(4)
        private string m_MDCR_TIME = String.Empty;      //진료시간                         VARCHAR2(4)
        private string m_MDCR_DEPT_CD = String.Empty;      //진료부서코드                     VARCHAR2(10)
        private string m_INSN_CLAM_DEPT_CD = String.Empty;      //보험청구부서코드                 VARCHAR2(10)
        private string m_EMRM_MMCD_CD = String.Empty;      //응급실주진료부서코드             VARCHAR2(10)
        private string m_ISCL_EMRM_MMCD_CD = String.Empty;      //보험청구응급실주진료부서코드     VARCHAR2(10)
        private string m_MDCR_DR_CD = String.Empty;      //진료의사코드                     VARCHAR2(10)
        private string m_REAL_MDCR_DR_CD = String.Empty;      //실제진료의사코드                 VARCHAR2(10)
        private string m_INSN_TYCD = String.Empty;      //보험유형코드                     VARCHAR2(2)
        private string m_ASST_TYCD = String.Empty;      //보조유형코드                     VARCHAR2(2)
        private string m_ASCT_RGNO_CD = String.Empty;      //조합기호코드                     VARCHAR2(20)
        private string m_FRVS_RVST_DVCD = String.Empty;      //초진재진구분코드                 VARCHAR2(2)
        private string m_MCCH_CMPT_DVCD = String.Empty;      //진찰료산정구분코드               VARCHAR2(2)
        private string m_HMCR_YN = String.Empty;      //가정간호여부                     VARCHAR2(1)
        private string m_SMCR_YN = String.Empty;      //선택진료여부                     VARCHAR2(1)
        private string m_CMHS_DVCD = String.Empty;      //내원구분코드                     VARCHAR2(2)
        private string m_CMHS_MOTV_DVCD = String.Empty;      //내원동기구분코드                 VARCHAR2(2)
        private string m_APNT_YN = String.Empty;      //예약여부                         VARCHAR2(1)
        private string m_APNT_PATH_DVCD = String.Empty;      //예약경로구분코드                 VARCHAR2(2)
        private string m_MCSP_APNT_DVCD = String.Empty;      //진료지원예약구분코드             VARCHAR2(2)
        private string m_CNTT_PRSC_DVCD = String.Empty;      //연속처방구분코드                 VARCHAR2(2)
        private string m_NRSN_CNFR_YN = String.Empty;      //간호확인여부                     VARCHAR2(1)
        private string m_MDCR_STRT_DT = String.Empty;      //진료시작일시                     VARCHAR2(14)
        private string m_MDCR_END_DT = String.Empty;      //진료종료일시                     VARCHAR2(14)
        private string m_PT_MDCR_STAT_DVCD = String.Empty;      //환자진료상태구분코드             VARCHAR2(2)
        private int m_PRSC_NOTM = 0;                 //처방횟수                         NUMBER(3, 0)
        private int m_RCPT_NOTM = 0;                 //수납횟수                         NUMBER(3, 0)
        private string m_EXCP_RESN_CD = String.Empty;      //예외사유코드                     VARCHAR2(2)
        private string m_VTRN_PT_YN = String.Empty;      //보훈환자여부                     VARCHAR2(1)
        private string m_MOMR_AGE_DVCD = String.Empty;      //유공자연령구분코드               VARCHAR2(2)
        private string m_INDP_MOMR_YN = String.Empty;      //독립유공자여부                   VARCHAR2(1)
        private string m_VTRN_FALU_YN = String.Empty;      //보훈등외여부                     VARCHAR2(1)
        private string m_VTRN_USCH_DVCD = String.Empty;      //보훈본인부담구분코드             VARCHAR2(2)
        private string m_VTRN_NON_QLFC_YN = String.Empty;      //보훈미자격여부                   VARCHAR2(1)
        private string m_CLUR_DSBL_DVCD = String.Empty;      //장루요루장애구분코드             VARCHAR2(2)
        private string m_MAIN_ILNS_CD = String.Empty;      //주상병코드                       VARCHAR2(10)
        private string m_CFSC_RGNO_CD = String.Empty;      //산정특례기호코드                 VARCHAR2(10)
        private string m_CHRN_DSSE_DVCD = String.Empty;      //만성질환구분코드                 VARCHAR2(2)
        private string m_TBRC_DVCD = String.Empty;      //결핵구분코드                     VARCHAR2(10)
        private string m_USCH_APLY_CD = String.Empty;      //본인부담적용코드                 VARCHAR2(4)
        private string m_REFR_INSTNO = String.Empty;      //의뢰기관기호                     VARCHAR2(10)
        private string m_ECOI_CD = String.Empty;      //상해외인코드                     VARCHAR2(2)
        private int m_HLLF_MNCS_BLCE = 0;                 //건강생활유지비잔액               NUMBER(10, 0)
        private string m_OTHR_HSPT_HPTF_YN = String.Empty;      //타병원전원여부                   VARCHAR2(1)
        private string m_MTWM_YN = String.Empty;      //산모여부                         VARCHAR2(1)
        private int m_MTWM_BLCE = 0;                 //산모잔액                         NUMBER(10, 0)
        private string m_VCNT_CLTP_YN = String.Empty;      //예방접종청구대상자여부           VARCHAR2(1)
        private string m_VCNT_PRTW_YN = String.Empty;      //예방접종예진표작성여부           VARCHAR2(1)
        private string m_FCLT_APLY_YN = String.Empty;      //시설적용여부                     VARCHAR2(1)
        private string m_FCLT_APLY_CD = String.Empty;      //시설적용구분코드                 VARCHAR2(10)
        private string m_QLFC_RTRV_YN = String.Empty;      //자격조회여부                     VARCHAR2(1)
        private string m_PAY_QLFC_DVCD = String.Empty;      //급여자격구분코드                 VARCHAR2(2)
        private string m_SNDT_TGPS_DVCD = String.Empty;      //노인틀니대상자구분코드           VARCHAR2(2)
        private string m_CNST_REFR_YN = String.Empty;      //컨설트의뢰여부                   VARCHAR2(1)
        private string m_FXAM_FXRT_DVCD = String.Empty;      //정액정률구분코드                 VARCHAR2(2)
        private string m_RRNS_FAFR_DVCD = String.Empty;      //희귀정액정률구분코드             VARCHAR2(2)
        private string m_OTPT_DRG_YN = String.Empty;      //외래DRG여부                      VARCHAR2(1)
        private string m_DRG_DVCD = String.Empty;      //DRG구분코드                      VARCHAR2(10)
        private string m_DRG_NO = String.Empty;      //DRG번호                          VARCHAR2(10)
        private string m_DY_WARD_YN = String.Empty;      //낮병동여부                       VARCHAR2(1)
        private string m_ENTS_ENTD_DVCD = String.Empty;      //위탁수탁구분코드                 VARCHAR2(2)
        private string m_DYTM_CNTR_USE_YN = String.Empty;      //주간센터사용여부                 VARCHAR2(1)
        private string m_EMRM_WTNG_YN = String.Empty;      //응급실대기여부                   VARCHAR2(1)
        private string m_TAIC_PT_UNIQ_NO = String.Empty;      //자보산재환자고유번호             VARCHAR2(10)
        private int m_TRAI_USPR_SHRT = 0;                 //자보본인일부부담율
        private string m_CLAM_CRTN_YN = String.Empty;      //청구생성여부                     VARCHAR2(1)
        private string m_CLAM_REVW_YN = String.Empty;      //청구심사여부                     VARCHAR2(1)
        private string m_CLAM_CRTN_DEL_RESN = String.Empty;      //청구생성삭제사유                 VARCHAR2(200)
        private string m_DCNT_RDIA_CD = String.Empty;      //할인감액코드                     VARCHAR2(10)
        private string m_DCNT_RDIA_EMNO = String.Empty;      //할인감액직원번호                 VARCHAR2(10)
        private int m_RCPN_AGE = 0;                 //접수연령                         NUMBER(3, 0)
        private string m_RCPN_ADDR_CD = String.Empty;      //접수주소코드                     VARCHAR2(6)
        private string m_DC_DD = String.Empty;      //DC일자                           VARCHAR2(8)
        private string m_AFRS_STAT_DVCD = String.Empty;      //업무상태구분코드                 VARCHAR2(2)
        private string m_ROW_STAT_DVCD = String.Empty;      //행상태구분코드                   VARCHAR2(2)
        private string m_RGST_DT = String.Empty;      //등록일시                         VARCHAR2(14)
        private string m_RGSTR_ID = String.Empty;      //등록자ID                         VARCHAR2(10)
        private string m_PT_NM = String.Empty;      //환자명
        private string m_FRRN = String.Empty;      //주민등록앞번호
        private string m_SRRN = String.Empty;      //주민등록뒷번호
        private string m_DOBR = String.Empty;      //생년월일
        private int m_AGE = 0;                 //연령
        private string m_PT_PCLR_MATR = String.Empty;      //환자특이사항
        private string m_SEX_DVCD = String.Empty;       //성별
        private int m_PRSC_COUNT = 0;                    // 처방갯수
        private int m_BILL_COUNT = 0;                    // 영수증갯수
        private bool m_initialized = false;
        private string m_ETC_USE_CNTS_1 = string.Empty; //주야구분
        private string m_ETC_USE_CNTS_2 = string.Empty;
        private string m_ETC_USE_CNTS_3 = string.Empty;
        private string m_ETC_USE_CNTS_4 = string.Empty;
        private string m_ETC_USE_CNTS_5 = string.Empty; // 강제내역변경시 내용 기록
        private string m_REBURN = String.Empty; // 재수상여부
        private string m_CLPH_TEL = String.Empty;

        private string m_HIRA_REQ_NO = string.Empty; // 진료의뢰일련번호(HIRA)
        private string m_HIRA_SDBK_NO = string.Empty; // 진료회송일련번호(HIRA)

        private string m_RRNO = string.Empty;
        #endregion

        #region Define Member Property

        public string NEW_PID_YN
        {
            get { return m_NEW_PID_YN; }
            set { m_NEW_PID_YN = value; }
        }           // 신환여부

        public string OTPT_ADMS_DVCD
        {
            get { return m_OTPT_ADMS_DVCD; }
            set { m_OTPT_ADMS_DVCD = value; }
        }           // 외래 입원 구분

        public string PID { get { return m_PID; } set { m_PID = value; } }    //환자등록번호           VARCHAR2(10 ) 
        public int PT_CMHS_NO { get { return m_PT_CMHS_NO; } set { m_PT_CMHS_NO = value; } }    //환자내원번호           NUMBER(10, 0) 
        public int RCPN_SQNO { get { return m_RCPN_SQNO; } set { m_RCPN_SQNO = value; } }    //접수일련번호           NUMBER(3, 0)  
        public string MDCR_DD { get { return m_MDCR_DD; } set { m_MDCR_DD = value; } }    //진료일자               VARCHAR2(8)   
        public string APNT_TIME { get { return m_APNT_TIME; } set { m_APNT_TIME = value; } }    //예약시간               VARCHAR2(4)   
        public string MDCR_TIME { get { return m_MDCR_TIME; } set { m_MDCR_TIME = value; } }    //진료시간               VARCHAR2(4)   
        public string MDCR_DEPT_CD { get { return m_MDCR_DEPT_CD; } set { m_MDCR_DEPT_CD = value; } }    //진료부서코드           VARCHAR2(10 ) 
        public string INSN_CLAM_DEPT_CD { get { return m_INSN_CLAM_DEPT_CD; } set { m_INSN_CLAM_DEPT_CD = value; } }    //보험청구부서코드       VARCHAR2(10 ) 
        public string EMRM_MMCD_CD { get { return m_EMRM_MMCD_CD; } set { m_EMRM_MMCD_CD = value; } }    //응급실주진료부서코드   VARCHAR2(10 ) 
        public string ISCL_EMRM_MMCD_CD { get { return m_ISCL_EMRM_MMCD_CD; } set { m_ISCL_EMRM_MMCD_CD = value; } }    //보험청구응급실주진료부 VARCHAR2(10 )   
        public string MDCR_DR_CD { get { return m_MDCR_DR_CD; } set { m_MDCR_DR_CD = value; } }    //진료의사코드           VARCHAR2(10 ) 
        public string REAL_MDCR_DR_CD { get { return m_REAL_MDCR_DR_CD; } set { m_REAL_MDCR_DR_CD = value; } }    //실제진료의사코드       VARCHAR2(10 ) 
        public string INSN_TYCD { get { return m_INSN_TYCD; } set { m_INSN_TYCD = value; } }    //보험유형코드           VARCHAR2(2)   
        public string ASST_TYCD { get { return m_ASST_TYCD; } set { m_ASST_TYCD = value; } }    //보조유형코드           VARCHAR2(2)   
        public string ASCT_RGNO_CD { get { return m_ASCT_RGNO_CD; } set { m_ASCT_RGNO_CD = value; } }    //조합기호코드           VARCHAR2(20 ) 
        public string FRVS_RVST_DVCD { get { return m_FRVS_RVST_DVCD; } set { m_FRVS_RVST_DVCD = value; } }    //초진재진구분코드       VARCHAR2(2)   
        public string MCCH_CMPT_DVCD { get { return m_MCCH_CMPT_DVCD; } set { m_MCCH_CMPT_DVCD = value; } }    //진찰료산정구분코드     VARCHAR2(2)   
        public string HMCR_YN { get { return m_HMCR_YN; } set { m_HMCR_YN = value; } }    //가정간호여부           VARCHAR2(1)   
        public string SMCR_YN { get { return m_SMCR_YN; } set { m_SMCR_YN = value; } }    //선택진료여부           VARCHAR2(1)   
        public string CMHS_DVCD { get { return m_CMHS_DVCD; } set { m_CMHS_DVCD = value; } }    //내원구분코드           VARCHAR2(2)   
        public string CMHS_MOTV_DVCD { get { return m_CMHS_MOTV_DVCD; } set { m_CMHS_MOTV_DVCD = value; } }    //내원동기구분코드       VARCHAR2(2)   
        public string APNT_YN { get { return m_APNT_YN; } set { m_APNT_YN = value; } }    //예약여부               VARCHAR2(1)   
        public string APNT_PATH_DVCD { get { return m_APNT_PATH_DVCD; } set { m_APNT_PATH_DVCD = value; } }    //예약경로구분코드       VARCHAR2(2)   
        public string MCSP_APNT_DVCD { get { return m_MCSP_APNT_DVCD; } set { m_MCSP_APNT_DVCD = value; } }    //진료지원예약구분코드   VARCHAR2(2)   
        public string CNTT_PRSC_DVCD { get { return m_CNTT_PRSC_DVCD; } set { m_CNTT_PRSC_DVCD = value; } }    //연속처방구분코드       VARCHAR2(2)   
        public string NRSN_CNFR_YN { get { return m_NRSN_CNFR_YN; } set { m_NRSN_CNFR_YN = value; } }    //간호확인여부           VARCHAR2(1)   
        public string MDCR_STRT_DT { get { return m_MDCR_STRT_DT; } set { m_MDCR_STRT_DT = value; } }    //진료시작일시           VARCHAR2(14 ) 
        public string MDCR_END_DT { get { return m_MDCR_END_DT; } set { m_MDCR_END_DT = value; } }    //진료종료일시           VARCHAR2(14 ) 
        public string PT_MDCR_STAT_DVCD { get { return m_PT_MDCR_STAT_DVCD; } set { m_PT_MDCR_STAT_DVCD = value; } }    //환자진료상태구분코드   VARCHAR2(2)   
        public int PRSC_NOTM { get { return m_PRSC_NOTM; } set { m_PRSC_NOTM = value; } }    //처방횟수               NUMBER(3, 0)  
        public int RCPT_NOTM { get { return m_RCPT_NOTM; } set { m_RCPT_NOTM = value; } }    //수납횟수               NUMBER(3, 0)  
        public string EXCP_RESN_CD { get { return m_EXCP_RESN_CD; } set { m_EXCP_RESN_CD = value; } }    //예외사유코드           VARCHAR2(2)   
        public string VTRN_PT_YN { get { return m_VTRN_PT_YN; } set { m_VTRN_PT_YN = value; } }    //보훈환자여부           VARCHAR2(1)   
        public string MOMR_AGE_DVCD { get { return m_MOMR_AGE_DVCD; } set { m_MOMR_AGE_DVCD = value; } }    //유공자연령구분코드     VARCHAR2(2)   
        public string INDP_MOMR_YN { get { return m_INDP_MOMR_YN; } set { m_INDP_MOMR_YN = value; } }    //독립유공자여부         VARCHAR2(1)   
        public string VTRN_FALU_YN { get { return m_VTRN_FALU_YN; } set { m_VTRN_FALU_YN = value; } }    //보훈등외여부           VARCHAR2(1)   
        public string VTRN_USCH_DVCD { get { return m_VTRN_USCH_DVCD; } set { m_VTRN_USCH_DVCD = value; } }    //보훈본인부담구분코드   VARCHAR2(2)   
        public string VTRN_NON_QLFC_YN { get { return m_VTRN_NON_QLFC_YN; } set { m_VTRN_NON_QLFC_YN = value; } }    //보훈미자격여부         VARCHAR2(1)   
        public string CLUR_DSBL_DVCD { get { return m_CLUR_DSBL_DVCD; } set { m_CLUR_DSBL_DVCD = value; } }    //장루요루장애구분코드   VARCHAR2(2)   
        public string MAIN_ILNS_CD { get { return m_MAIN_ILNS_CD; } set { m_MAIN_ILNS_CD = value; } }    //주상병코드             VARCHAR2(10 ) 
        public string CFSC_RGNO_CD { get { return m_CFSC_RGNO_CD; } set { m_CFSC_RGNO_CD = value; } }    //산정특례기호코드       VARCHAR2(10 ) 
        public string CHRN_DSSE_DVCD { get { return m_CHRN_DSSE_DVCD; } set { m_CHRN_DSSE_DVCD = value; } }    //만성질환구분코드       VARCHAR2(2)   
        public string TBRC_DVCD { get { return m_TBRC_DVCD; } set { m_TBRC_DVCD = value; } }    //결핵구분코드           VARCHAR2(10 ) 
        public string USCH_APLY_CD { get { return m_USCH_APLY_CD; } set { m_USCH_APLY_CD = value; } }    //본인부담적용코드       VARCHAR2(4)   
        public string REFR_INSTNO { get { return m_REFR_INSTNO; } set { m_REFR_INSTNO = value; } }    //의뢰기관기호           VARCHAR2(10 ) 
        public string ECOI_CD { get { return m_ECOI_CD; } set { m_ECOI_CD = value; } }    //상해외인코드           VARCHAR2(2)   
        public int HLLF_MNCS_BLCE { get { return m_HLLF_MNCS_BLCE; } set { m_HLLF_MNCS_BLCE = value; } }    //건강생활유지비잔액     NUMBER(10, 0) 
        public string OTHR_HSPT_HPTF_YN { get { return m_OTHR_HSPT_HPTF_YN; } set { m_OTHR_HSPT_HPTF_YN = value; } }    //타병원전원여부         VARCHAR2(1)   
        public string MTWM_YN { get { return m_MTWM_YN; } set { m_MTWM_YN = value; } }    //산모여부               VARCHAR2(1)   
        public int MTWM_BLCE { get { return m_MTWM_BLCE; } set { m_MTWM_BLCE = value; } }    //산모잔액               NUMBER(10, 0) 
        public string VCNT_CLTP_YN { get { return m_VCNT_CLTP_YN; } set { m_VCNT_CLTP_YN = value; } }    //예방접종청구대상자여부 VARCHAR2(1)   
        public string VCNT_PRTW_YN { get { return m_VCNT_PRTW_YN; } set { m_VCNT_PRTW_YN = value; } }    //예방접종예진표작성여부 VARCHAR2(1)   
        public string FCLT_APLY_YN { get { return m_FCLT_APLY_YN; } set { m_FCLT_APLY_YN = value; } }    //시설적용여부           VARCHAR2(1)   
        public string FCLT_APLY_CD { get { return m_FCLT_APLY_CD; } set { m_FCLT_APLY_CD = value; } }    //시설적용구분코드       VARCHAR2(10 ) 
        public string QLFC_RTRV_YN { get { return m_QLFC_RTRV_YN; } set { m_QLFC_RTRV_YN = value; } }    //자격조회여부           VARCHAR2(1)   
        public string PAY_QLFC_DVCD { get { return m_PAY_QLFC_DVCD; } set { m_PAY_QLFC_DVCD = value; } }    //급여자격구분코드       VARCHAR2(2)   
        public string SNDT_TGPS_DVCD { get { return m_SNDT_TGPS_DVCD; } set { m_SNDT_TGPS_DVCD = value; } }    //노인틀니대상자구분코드 VARCHAR2(2)   
        public string CNST_REFR_YN { get { return m_CNST_REFR_YN; } set { m_CNST_REFR_YN = value; } }    //컨설트의뢰여부         VARCHAR2(1)   
        public string FXAM_FXRT_DVCD { get { return m_FXAM_FXRT_DVCD; } set { m_FXAM_FXRT_DVCD = value; } }    //정액정률구분코드       VARCHAR2(2)   
        public string RRNS_FAFR_DVCD { get { return m_RRNS_FAFR_DVCD; } set { m_RRNS_FAFR_DVCD = value; } }    //희귀정액정률구분코드   VARCHAR2(2)   
        public string OTPT_DRG_YN { get { return m_OTPT_DRG_YN; } set { m_OTPT_DRG_YN = value; } }    //외래DRG여부            VARCHAR2(1)   
        public string DRG_DVCD { get { return m_DRG_DVCD; } set { m_DRG_DVCD = value; } }    //DRG구분코드            VARCHAR2(10 ) 
        public string DRG_NO { get { return m_DRG_NO; } set { m_DRG_NO = value; } }    //DRG번호                VARCHAR2(10 ) 
        public string DY_WARD_YN { get { return m_DY_WARD_YN; } set { m_DY_WARD_YN = value; } }    //낮병동여부             VARCHAR2(1)   
        public string ENTS_ENTD_DVCD { get { return m_ENTS_ENTD_DVCD; } set { m_ENTS_ENTD_DVCD = value; } }    //위탁수탁구분코드       VARCHAR2(2)   
        public string DYTM_CNTR_USE_YN { get { return m_DYTM_CNTR_USE_YN; } set { m_DYTM_CNTR_USE_YN = value; } }    //주간센터사용여부       VARCHAR2(1)   
        public string EMRM_WTNG_YN { get { return m_EMRM_WTNG_YN; } set { m_EMRM_WTNG_YN = value; } }    //응급실대기여부         VARCHAR2(1)   
        public string TAIC_PT_UNIQ_NO { get { return m_TAIC_PT_UNIQ_NO; } set { m_TAIC_PT_UNIQ_NO = value; } }    //자보산재환자고유번호   VARCHAR2(10 ) 
        public int TRAI_USPR_SHRT { get { return m_TRAI_USPR_SHRT; } set { m_TRAI_USPR_SHRT = value; } }    //자보본인일부부담율   NUMBER(10 ) 
        public string CLAM_CRTN_YN { get { return m_CLAM_CRTN_YN; } set { m_CLAM_CRTN_YN = value; } }    //청구생성여부           VARCHAR2(1)   
        public string CLAM_REVW_YN { get { return m_CLAM_REVW_YN; } set { m_CLAM_REVW_YN = value; } }    //청구심사여부           VARCHAR2(1)   
        public string CLAM_CRTN_DEL_RESN { get { return m_CLAM_CRTN_DEL_RESN; } set { m_CLAM_CRTN_DEL_RESN = value; } }    //청구생성삭제사유       VARCHAR2(20 0)
        public string DCNT_RDIA_CD { get { return m_DCNT_RDIA_CD; } set { m_DCNT_RDIA_CD = value; } }    //할인감액코드           VARCHAR2(10 ) 
        public string DCNT_RDIA_EMNO { get { return m_DCNT_RDIA_EMNO; } set { m_DCNT_RDIA_EMNO = value; } }    //할인감액직원번호       VARCHAR2(10 ) 
        public int RCPN_AGE { get { return m_RCPN_AGE; } set { m_RCPN_AGE = value; } }    //접수연령               NUMBER(3, 0)  
        public string RCPN_ADDR_CD { get { return m_RCPN_ADDR_CD; } set { m_RCPN_ADDR_CD = value; } }    //접수주소코드           VARCHAR2(6)   
        public string DC_DD { get { return m_DC_DD; } set { m_DC_DD = value; } }    //DC일자                 VARCHAR2(8)   
        public string AFRS_STAT_DVCD { get { return m_AFRS_STAT_DVCD; } set { m_AFRS_STAT_DVCD = value; } }    //업무상태구분코드       VARCHAR2(2)   
        public string ROW_STAT_DVCD { get { return m_ROW_STAT_DVCD; } set { m_ROW_STAT_DVCD = value; } }    //행상태구분코드         VARCHAR2(2)   
        public string RGST_DT { get { return m_RGST_DT; } set { m_RGST_DT = value; } }    //등록일시               VARCHAR2(14 ) 
        public string RGSTR_ID { get { return m_RGSTR_ID; } set { m_RGSTR_ID = value; } }    //등록자ID               VARCHAR2(10)
        public string PT_NM { get { return m_PT_NM; } set { m_PT_NM = value; } }
        public string FRRN { get { return m_FRRN; } set { m_FRRN = value; } }
        public string SRRN { get { return m_SRRN; } set { m_SRRN = value; } }
        public string DOBR { get { return m_DOBR; } set { m_DOBR = value; } }
        public int AGE { get { return m_AGE; } set { m_AGE = value; } }
        public string PT_PCLR_MATR { get { return m_PT_PCLR_MATR; } set { m_PT_PCLR_MATR = value; } }
        public string SEX_DVCD { get { return m_SEX_DVCD; } set { m_SEX_DVCD = value; } }
        public int PRSC_COUNT { get { return m_PRSC_COUNT; } set { m_PRSC_COUNT = value; } }
        public int BILL_COUNT { get { return m_BILL_COUNT; } set { m_BILL_COUNT = value; } }
        public string ETC_USE_CNTS_1 { get { return m_ETC_USE_CNTS_1; } set { m_ETC_USE_CNTS_1 = value; } }
        public string ETC_USE_CNTS_2 { get { return m_ETC_USE_CNTS_2; } set { m_ETC_USE_CNTS_2 = value; } }
        public string ETC_USE_CNTS_3 { get { return m_ETC_USE_CNTS_3; } set { m_ETC_USE_CNTS_3 = value; } }
        public string ETC_USE_CNTS_4 { get { return m_ETC_USE_CNTS_4; } set { m_ETC_USE_CNTS_4 = value; } }
        public string ETC_USE_CNTS_5 { get { return m_ETC_USE_CNTS_5; } set { m_ETC_USE_CNTS_5 = value; } } // 강제내역변경의 경우 내용기록
        public string REBURN { get { return m_REBURN; } set { m_REBURN = value; } } // 재수상여부
        public string CLPH_TEL { get { return m_CLPH_TEL; } set { m_CLPH_TEL = value; } }


        public string HIRA_REQ_NO { get { return m_HIRA_REQ_NO; } set { m_HIRA_REQ_NO = value; } } // 진료의뢰일련번호(HIRA)
        public string HIRA_SDBK_NO { get { return m_HIRA_SDBK_NO; } set { m_HIRA_SDBK_NO = value; } } // 진료회송일련번호(HIRA)

        public string RRNO { get { return m_RRNO; } set { m_RRNO = value; } } // m_FCLT_APLY_RRNO

        #endregion

        #region Construction
        public clsOutRegistrationInfo()
        {
            Clear();
        }
        #endregion

        #region Method : Public Method
        /// <summary>
        /// clear
        /// </summary>
        public void Clear()
        {
            m_NEW_PID_YN = "N";
            m_OTPT_ADMS_DVCD = String.Empty;
            m_PID = String.Empty;
            m_PT_CMHS_NO = 0;
            m_RCPN_SQNO = 0;
            m_MDCR_DD = String.Empty;
            m_APNT_TIME = String.Empty;
            m_MDCR_TIME = String.Empty;
            m_MDCR_DEPT_CD = String.Empty;
            m_INSN_CLAM_DEPT_CD = String.Empty;
            m_EMRM_MMCD_CD = String.Empty;
            m_ISCL_EMRM_MMCD_CD = String.Empty;
            m_MDCR_DR_CD = String.Empty;
            m_REAL_MDCR_DR_CD = String.Empty;
            m_INSN_TYCD = String.Empty;
            m_ASST_TYCD = String.Empty;
            m_ASCT_RGNO_CD = String.Empty;
            m_FRVS_RVST_DVCD = String.Empty;
            m_MCCH_CMPT_DVCD = String.Empty;
            m_HMCR_YN = String.Empty;
            m_SMCR_YN = String.Empty;
            m_CMHS_DVCD = String.Empty;
            m_CMHS_MOTV_DVCD = String.Empty;
            m_APNT_YN = String.Empty;
            m_APNT_PATH_DVCD = String.Empty;
            m_MCSP_APNT_DVCD = String.Empty;
            m_CNTT_PRSC_DVCD = String.Empty;
            m_NRSN_CNFR_YN = String.Empty;
            m_MDCR_STRT_DT = String.Empty;
            m_MDCR_END_DT = String.Empty;
            m_PT_MDCR_STAT_DVCD = String.Empty;
            m_PRSC_NOTM = 0;
            m_RCPT_NOTM = 0;
            m_EXCP_RESN_CD = String.Empty;
            m_VTRN_PT_YN = String.Empty;
            m_MOMR_AGE_DVCD = String.Empty;
            m_INDP_MOMR_YN = String.Empty;
            m_VTRN_FALU_YN = String.Empty;
            m_VTRN_USCH_DVCD = String.Empty;
            m_VTRN_NON_QLFC_YN = String.Empty;
            m_CLUR_DSBL_DVCD = String.Empty;
            m_MAIN_ILNS_CD = String.Empty;
            m_CFSC_RGNO_CD = String.Empty;
            m_CHRN_DSSE_DVCD = String.Empty;
            m_TBRC_DVCD = String.Empty;
            m_USCH_APLY_CD = String.Empty;
            m_REFR_INSTNO = String.Empty;
            m_ECOI_CD = String.Empty;
            m_HLLF_MNCS_BLCE = 0;
            m_OTHR_HSPT_HPTF_YN = String.Empty;
            m_MTWM_YN = String.Empty;
            m_MTWM_BLCE = 0;
            m_VCNT_CLTP_YN = String.Empty;
            m_VCNT_PRTW_YN = String.Empty;
            m_FCLT_APLY_YN = String.Empty;
            m_FCLT_APLY_CD = String.Empty;
            m_RRNO = string.Empty;
            m_QLFC_RTRV_YN = String.Empty;
            m_PAY_QLFC_DVCD = String.Empty;
            m_SNDT_TGPS_DVCD = String.Empty;
            m_CNST_REFR_YN = String.Empty;
            m_FXAM_FXRT_DVCD = String.Empty;
            m_RRNS_FAFR_DVCD = String.Empty;
            m_OTPT_DRG_YN = String.Empty;
            m_DRG_DVCD = String.Empty;
            m_DRG_NO = String.Empty;
            m_DY_WARD_YN = String.Empty;
            m_ENTS_ENTD_DVCD = String.Empty;
            m_DYTM_CNTR_USE_YN = String.Empty;
            m_EMRM_WTNG_YN = String.Empty;
            m_TAIC_PT_UNIQ_NO = String.Empty;
            m_TRAI_USPR_SHRT = 0;
            m_CLAM_CRTN_YN = String.Empty;
            m_CLAM_REVW_YN = String.Empty;
            m_CLAM_CRTN_DEL_RESN = String.Empty;
            m_DCNT_RDIA_CD = String.Empty;
            m_DCNT_RDIA_EMNO = String.Empty;
            m_RCPN_AGE = 0;
            m_RCPN_ADDR_CD = String.Empty;
            m_DC_DD = String.Empty;
            m_AFRS_STAT_DVCD = String.Empty;
            m_ROW_STAT_DVCD = String.Empty;
            m_RGST_DT = String.Empty;
            m_RGSTR_ID = String.Empty;
            m_PT_NM = String.Empty;
            m_FRRN = String.Empty;
            m_SRRN = String.Empty;
            m_DOBR = String.Empty;
            m_AGE = 0;
            m_PT_PCLR_MATR = String.Empty;
            m_SEX_DVCD = String.Empty;
            m_PRSC_COUNT = 0;
            m_BILL_COUNT = 0;
            m_ETC_USE_CNTS_1 = string.Empty;
            m_ETC_USE_CNTS_2 = string.Empty;
            m_ETC_USE_CNTS_3 = string.Empty;
            m_ETC_USE_CNTS_4 = string.Empty;
            m_ETC_USE_CNTS_5 = string.Empty;
            m_REBURN = String.Empty;
            m_CLPH_TEL = string.Empty;

            m_HIRA_REQ_NO = string.Empty;
            m_HIRA_SDBK_NO = string.Empty;
        }

        public bool Load(string pid, int ptcmhsno)
        {
            return GetOutRegistrationInfo(pid, ptcmhsno);
        }

        public bool Load(string condition, string pid, int ptcmhsno, string mdcrdd)
        {
            return GetOutRegistrationInfo(condition, pid, ptcmhsno, mdcrdd);
        }

        /// <summary>
        /// 초진재진구분을 가져온다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool CheckFrvsRvstDvcd(ref string msg)
        {
            bool result = true;

            try
            {
                // 초진재진구분코드
                string frvsrvstdvcd = "";
                result = SqlPack.Procedure.PR_PA_PRC_FRVSRVSTSET(this.PID, this.PT_CMHS_NO, this.MDCR_DD, this.INSN_CLAM_DEPT_CD, ref frvsrvstdvcd, ref msg);
                if (result)
                {
                    if (msg.Length > 0)
                    {
                        return false;
                    }

                    this.FRVS_RVST_DVCD = frvsrvstdvcd;
                }
                else
                {
                    msg = "오류 내용 : [" + DBService.DBError + "] " + DBService.ErrorMessage;
                    result = false;
                }
            }
            catch (Exception ex)
            {
                msg = "초진재진구분코드를 확인하는 중 오류를 발생했습니다.\r\n " +
                      "Method :  [CheckFrvsRvstDvcd] \r\n " +
                      "오류 메시지 : " + ex.Message;
                result = false;
            }

            return result;
        }

        #region Method : SaveData Method
        /// <summary>
        /// 접수정보 Insert
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool InsertOutRegistrationInfo(ref string msg)
        {
            bool success = true;

            try
            {
                // 접수변경에 의하여 쌓이는 경우는 몇가지 항목을 다시 읽어오자.
                // MDCR_STRT_DT, MDCR_END_DT, PT_MDCR_STAT_DVCD, PRSC_NOTM, RCPT_NOTM, CLAM_CRTN_YN, CLAM_REVW_YN, CLAM_CRTN_DEL_RESN
                if (this.RCPN_SQNO > 1)
                {
                    int rcpn_sqno_prev = RCPN_SQNO - 1;
                    string sqltext = $@" SELECT * FROM PAOPATRT WHERE PID = '{this.PID}' AND PT_CMHS_NO = {this.PT_CMHS_NO} AND RCPN_SQNO = {rcpn_sqno_prev} ";

                    DataTable dt = new DataTable();
                    if (!DBService.ExecuteDataTable(sqltext, ref dt))
                        throw new Exception("접수정보를 재조회하는 중 에러가 발생했습니다.");

                    if (dt.Rows.Count > 0)
                    {
                        this.MDCR_STRT_DT = dt.Rows[0]["MDCR_STRT_DT"].ToString();
                        this.MDCR_END_DT = dt.Rows[0]["MDCR_END_DT"].ToString();
                        this.PT_MDCR_STAT_DVCD = dt.Rows[0]["PT_MDCR_STAT_DVCD"].ToString();
                        int temp = 0; int.TryParse(dt.Rows[0]["PRSC_NOTM"].ToString(), out temp); this.PRSC_NOTM = temp;
                        temp = 0;     int.TryParse(dt.Rows[0]["RCPT_NOTM"].ToString(), out temp); this.RCPT_NOTM = temp;
                        this.CLAM_CRTN_YN = dt.Rows[0]["CLAM_CRTN_YN"].ToString();
                        this.CLAM_REVW_YN = dt.Rows[0]["CLAM_REVW_YN"].ToString();
                        this.CLAM_CRTN_DEL_RESN = dt.Rows[0]["CLAM_CRTN_DEL_RESN"].ToString();
                    }
                }

                if (!DBService.ExecuteNonQuery(SQL.PA.BaseSql.Insert.PAOPATRT(), this.PID
                                                                               , this.PT_CMHS_NO.ToString()
                                                                               , this.RCPN_SQNO.ToString()
                                                                               , this.MDCR_DD
                                                                               , this.APNT_TIME
                                                                               , this.MDCR_TIME
                                                                               , this.MDCR_DEPT_CD
                                                                               , this.INSN_CLAM_DEPT_CD
                                                                               , this.EMRM_MMCD_CD
                                                                               , this.ISCL_EMRM_MMCD_CD
                                                                               , this.MDCR_DR_CD
                                                                               , this.REAL_MDCR_DR_CD
                                                                               , this.INSN_TYCD
                                                                               , this.ASST_TYCD
                                                                               , this.ASCT_RGNO_CD
                                                                               , this.FRVS_RVST_DVCD
                                                                               , this.MCCH_CMPT_DVCD
                                                                               , this.HMCR_YN
                                                                               , this.SMCR_YN
                                                                               , this.CMHS_DVCD
                                                                               , this.CMHS_MOTV_DVCD
                                                                               , this.APNT_YN
                                                                               , this.APNT_PATH_DVCD
                                                                               , this.MCSP_APNT_DVCD
                                                                               , this.CNTT_PRSC_DVCD
                                                                               , this.NRSN_CNFR_YN
                                                                               , this.MDCR_STRT_DT
                                                                               , this.MDCR_END_DT
                                                                               , this.PT_MDCR_STAT_DVCD
                                                                               , this.PRSC_NOTM.ToString()
                                                                               , this.RCPT_NOTM.ToString()
                                                                               , this.EXCP_RESN_CD
                                                                               , this.VTRN_PT_YN
                                                                               , string.IsNullOrWhiteSpace(this.MOMR_AGE_DVCD) ? "N" : this.MOMR_AGE_DVCD
                                                                               , this.INDP_MOMR_YN
                                                                               , this.VTRN_FALU_YN
                                                                               , string.IsNullOrWhiteSpace(this.VTRN_USCH_DVCD) ? "0" : this.VTRN_USCH_DVCD
                                                                               , this.VTRN_NON_QLFC_YN
                                                                               , this.CLUR_DSBL_DVCD
                                                                               , this.MAIN_ILNS_CD
                                                                               , string.IsNullOrWhiteSpace(this.CFSC_RGNO_CD) ? "NO" : this.CFSC_RGNO_CD
                                                                               , this.CHRN_DSSE_DVCD
                                                                               , this.TBRC_DVCD
                                                                               , this.USCH_APLY_CD
                                                                               , this.REFR_INSTNO
                                                                               , this.ECOI_CD
                                                                               , this.HLLF_MNCS_BLCE.ToString()
                                                                               , this.OTHR_HSPT_HPTF_YN
                                                                               , this.MTWM_YN
                                                                               , this.MTWM_BLCE.ToString()
                                                                               , this.VCNT_CLTP_YN
                                                                               , this.VCNT_PRTW_YN
                                                                               , this.FCLT_APLY_YN
                                                                               , this.FCLT_APLY_CD
                                                                               , this.QLFC_RTRV_YN
                                                                               , this.PAY_QLFC_DVCD
                                                                               , this.SNDT_TGPS_DVCD
                                                                               , this.CNST_REFR_YN
                                                                               , this.FXAM_FXRT_DVCD
                                                                               , this.RRNS_FAFR_DVCD
                                                                               , string.IsNullOrWhiteSpace(this.OTPT_DRG_YN) ? "N" : this.OTPT_DRG_YN
                                                                               , this.DRG_DVCD
                                                                               , string.IsNullOrWhiteSpace(this.DRG_NO) ? "NO" : this.DRG_NO
                                                                               , this.DY_WARD_YN
                                                                               , this.ENTS_ENTD_DVCD
                                                                               , string.IsNullOrWhiteSpace(this.DYTM_CNTR_USE_YN) ? "N" : this.DYTM_CNTR_USE_YN
                                                                               , string.IsNullOrWhiteSpace(this.EMRM_WTNG_YN) ? "N" : this.EMRM_WTNG_YN
                                                                               , this.TAIC_PT_UNIQ_NO
                                                                               , string.IsNullOrWhiteSpace(this.CLAM_CRTN_YN) ? "N" : this.CLAM_CRTN_YN
                                                                               , string.IsNullOrWhiteSpace(this.CLAM_REVW_YN) ? "N" : this.CLAM_REVW_YN
                                                                               , this.CLAM_CRTN_DEL_RESN
                                                                               , this.DCNT_RDIA_CD
                                                                               , this.DCNT_RDIA_EMNO
                                                                               , this.RCPN_AGE.ToString()
                                                                               , this.RCPN_ADDR_CD
                                                                               , this.DC_DD
                                                                               , this.AFRS_STAT_DVCD
                                                                               , this.ROW_STAT_DVCD
                                                                               , this.RGST_DT
                                                                               , this.RGSTR_ID
                                                                               , "0"
                                                                               , "N"
                                                                               , this.ETC_USE_CNTS_1
                                                                               , this.ETC_USE_CNTS_2
                                                                               , this.ETC_USE_CNTS_3
                                                                               , this.ETC_USE_CNTS_4
                                                                               , this.ETC_USE_CNTS_5
                                                                               ))
                {
                    success = false;
                    msg = DBService.ErrorMessage + "\r\n 외래접수등록 [PAOPATRT INSERT] 저장 중 에러가 발생했습니다!!\r\n관리자에게 문의해주세요!!\r\n";
                    DBService.RollbackTransaction();
                }

                // 진료의뢰회송일련번호 존재할 경우
                // (진료의뢰회송 송신내역에서 접수했을 경우)
                if (!string.IsNullOrWhiteSpace(this.HIRA_REQ_NO) || !string.IsNullOrWhiteSpace(this.HIRA_SDBK_NO))
                {
                    // PATR ?? >> ETC 저장
                    if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePATRTEIF_ReqRes()
                                                 , this.PID
                                                 , this.PT_CMHS_NO.ToString()
                                                 , !string.IsNullOrWhiteSpace(this.HIRA_REQ_NO) ? "02" : "00"
                                                 , !string.IsNullOrWhiteSpace(this.HIRA_SDBK_NO) ? "02" : "00"
                                                 , !string.IsNullOrWhiteSpace(this.HIRA_REQ_NO) ? this.HIRA_REQ_NO : ""
                                                 , !string.IsNullOrWhiteSpace(this.HIRA_SDBK_NO) ? this.HIRA_SDBK_NO : ""
                                                 ))
                    {
                        success = false;
                        msg = DBService.ErrorMessage + "\r\n 외래접수등록 [PAOPATRT INSERT] 저장 중 에러가 발생했습니다!!\r\n관리자에게 문의해주세요!!\r\n";
                        DBService.RollbackTransaction();
                    }

                    // 의뢰/회송 차트정보 생성
                    if (!string.IsNullOrWhiteSpace(this.HIRA_REQ_NO))
                    {
                        EMBizCommon.InsertPageInfo(this.PID, this.PT_CMHS_NO.ToString(), "COMMON_진료의뢰서(HIRA)", DateTime.Now.ToString("yyyyMMddHHmm"), this.HIRA_REQ_NO, "-", "OUTUSER");
                    }

                    if (!string.IsNullOrWhiteSpace(this.HIRA_SDBK_NO))
                    {
                        EMBizCommon.InsertPageInfo(this.PID, this.PT_CMHS_NO.ToString(), "COMMON_진료회송서(HIRA)", DateTime.Now.ToString("yyyyMMddHHmm"), this.HIRA_SDBK_NO, "-", "OUTUSER");
                    }
                }
            }
            catch (Exception ex)
            {
                msg = "외래접수정보 저장 중 오류를 발생했습니다.\r\n " +
                      "Method :  [InsertPAIPATRT] \r\n " +
                      "오류 메시지 : " + ex.Message;
                DBService.RollbackTransaction();
                success = false;

            }

            //의뢰서 정보를 생성한다.
            if (!CheckMdcrReferInfo(this.AFRS_STAT_DVCD, this.ROW_STAT_DVCD, ref msg))
            {
                DBService.RollbackTransaction();
                success = false;
            }

            return success;
        }
        /// <summary>
        /// 외래접수등록 행상태구분코드 변경
        /// </summary>
        /// <param name="rowstatdvcd">변경할 행상태구분코드</param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool UpdateRowStatDvcdOfPaOpatRt(string rowstatdvcd, ref string msg)
        {
            bool success = true;

            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePAOPATRT_RowStatDvcd(), this.PID
                                                                                  , this.PT_CMHS_NO.ToString()
                                                                                  , this.ROW_STAT_DVCD
                                                                                  , rowstatdvcd))
            {
                success = false;
                msg = DBService.ErrorMessage + "\r\n 외래접수정보의 행상태구분코드 변경중 오류가 발생하였습니다. 확인하시기 바랍니다.";
                DBService.RollbackTransaction();
            }
            return success;
        }

        /// <summary>
        /// 외래접수정보의 보조유형코드, 산정특례코드, 결핵구분코드, 본인부담적용코드를 변경한다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool UpdateAsstTycdOfPaOpatRt(ref string msg)
        {
            bool success = true;

            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateAsstTycdOfPaOpatRt(), this.PID
                                                                                , this.PT_CMHS_NO.ToString()
                                                                                , this.RCPN_SQNO.ToString()
                                                                                , this.ASST_TYCD
                                                                                , this.CFSC_RGNO_CD
                                                                                , this.TBRC_DVCD
                                                                                , this.USCH_APLY_CD))
            {
                success = false;
                msg = "외래접수정보의 유형보조, 산정특례기호코드  변경중 오류가 발생하였습니다. 확인하시기 바랍니다.\r\n Error Message : " + DBService.ErrorMessage;
                DBService.RollbackTransaction();
            }
            return success;
        }
        /// <summary>
        /// 외래접수정보의 조합기호코드  변경
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool UpdateAsctRgnoCdOfPaOpatRt(ref string msg)
        {
            bool success = true;
            string asctrgnocd = String.Empty;

            asctrgnocd = StringService.IsNvl(DBService.ExecuteScalar(SQL.PA.Sql.SelectAsctRgnoCdOfPaPinsIf(), this.PID
                                                                                        , this.INSN_TYCD
                                                                                        , this.MDCR_DD).ToString(), "NO");

            if (!this.ASCT_RGNO_CD.Equals(asctrgnocd))
            {
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateAsctRgnoCdOfPaOpatRt(), this.PID
                                                                                      , this.PT_CMHS_NO.ToString()
                                                                                      , this.ASCT_RGNO_CD))
                {
                    success = false;
                    msg = "외래접수정보의 조합기호코드  변경중 오류가 발생하였습니다. 확인하시기 바랍니다.\r\n Error Message : " + DBService.ErrorMessage;
                    DBService.RollbackTransaction();
                }
            }

            return success;
        }
        /// <summary>
        /// 수납에서 접수정보 변경시 UPDATE
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool UpdateRegistInfoChangeAtRec(ref string msg)
        {
            bool success = true;
            // 보훈환자, 유공자, 독립유공 중 하나만 인정한다.
            if ((this.VTRN_PT_YN == "Y" && this.MOMR_AGE_DVCD == "Y") || (this.VTRN_PT_YN == "Y" && this.INDP_MOMR_YN == "Y"))
            {
                msg = "[UpdatePAOPATRT_ForceChange] 보훈, 유공자연령감명, 독립유공자 중 하나만 선택가능합니다.";
                return false;
            }
            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePAOPATRT_ForceChange(), this.PID
                                                                                  , this.PT_CMHS_NO.ToString()
                                                                                  , this.MDCR_DD
                                                                                  , this.RCPN_SQNO.ToString()
                                                                                  , this.FRVS_RVST_DVCD
                                                                                  , this.MCCH_CMPT_DVCD
                                                                                  , this.CMHS_DVCD
                                                                                  , this.HMCR_YN
                                                                                  , this.ECOI_CD
                                                                                  , this.DY_WARD_YN
                                                                                  , this.VTRN_PT_YN
                                                                                  , this.MOMR_AGE_DVCD
                                                                                  , this.INDP_MOMR_YN
                                                                                  , this.MTWM_YN
                                                                                  , this.FCLT_APLY_YN
                                                                                  , this.VCNT_CLTP_YN
                                                                                  , this.VCNT_PRTW_YN))
            {
                success = false;
                msg = DBService.ErrorMessage + "\r\n [UpdatePAOPATRT_ForceChange] 외래접수정보 변경 오류가 발생하였습니다. 확인하시기 바랍니다.";
            }
            return success;
        }

        /// <summary>
        /// 처방횟수를 증가시킨다. 유형변경을 한 후 수납을 안했을 때 확인할 수가 없다.
        /// 유형변경을 했을경우 미수납여부를 표시하기위해서 수납횟수를 증가시킴.
        /// 처방은 수납완료가 되어있을수도 있고 수납이 안되어 있을수도 있음.
        /// 문제있을시 변경할 것임....
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool UpdatePrscNotmOfPaOpaRt(ref string msg)
        {
            try
            {
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePrscNotmOfPaOpatRt(), m_PID
                                                                                    , m_PT_CMHS_NO.ToString()
                                                                                    , "Y"))
                {
                    msg = DBService.ErrorMessage + " : 외래접수등록의 수납횟수 변경 중 에러 발생.";
                    return false;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
            return true;
        }

        public bool CheckAffairsLock()
        {
            //이전정보삭제
            //DBService.ExecuteNonQuery(SQL.PA.Sql.DeleteNRLOCKMT_Afrs(), )
            //동일 IP 작업 정보 삭제
            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.DeleteNRLOCKMT_IpAddr(), "PA", ClientEnvironment.IP))
            {
                return false;
            }

            //SystemList.GetColumnValue("PA", "SYSTEM_NAME")
            return true;
        }

        private int CheckAffairsInfo(ref string msg)
        {
            string afrslocdstrtdd = String.Empty;


            afrslocdstrtdd = ConfigService.GetConfigValueString("%", "AFRS_LOCK", "STRT_DD", "*").ToString();

            if (DateTimeService.ConvertDateTime(afrslocdstrtdd) > DateTime.Now)
            {
                return 1;
            }
            DataTable dt = new DataTable();
            if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectNRLOCKMT(), ref dt, this.PID
                                                                              , this.PT_CMHS_NO.ToString()))
            {
                if (dt.Rows.Count > 0)
                {

                }
            }
            else
            {

            }

            return 1;
        }

        /// <summary>
        /// 01.02.외래접수정보의 입력값을 멤버변수에 담은 후
        /// 저장하기전 외래접수정보의 입력값을 확인한다.
        /// 
        /// </summary>
        /// <param name="afrsstatdvcd">업무구분코드</param>
        /// <param name="rowstatdvcd">행상태구분코드</param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public int CheckDataOfPAOPATRT(string afrsstatdvcd, string rowstatdvcd, ref string msg)
        {
            try
            {
                int rtnval = 0;

                // 동일접수정보를 확인한다.
                rtnval = clsPACommon.CheckSameRegInfo(this.m_PID, this.m_PT_CMHS_NO, this.m_MDCR_DD, this.m_MDCR_DEPT_CD, this.m_INSN_CLAM_DEPT_CD, this.m_INSN_TYCD, ref msg);
                if (rtnval < 0)
                {
                    return -10;
                }
                else if (rtnval >= 1)
                {
                    msg = "동일날 동일보험, 동일진료부서로 접수된 정보가 존재합니다. 확인하시기 바랍니다.";
                    rtnval = -11;
                }

                //DRG, 낮병동 접수정보가 있는지 확인한다.
                rtnval = IsDrgDschPatient(ref msg);

                if (rtnval < 0)
                {
                    return -20;
                }

                // 장루요루장애구분은 건강보험의 보험환자만 적용한다.

                if (this.m_CLUR_DSBL_DVCD.Equals("1") && this.m_INSN_TYCD.Equals("11") && (this.m_ASST_TYCD.Equals("00") || this.m_ASST_TYCD.Equals("60")) &&
                    !this.m_VTRN_PT_YN.Equals("Y") && !this.m_MOMR_AGE_DVCD.Equals("Y"))
                {
                    this.CLUR_DSBL_DVCD = "1";
                }
                else
                {
                    this.CLUR_DSBL_DVCD = "0";
                }

                if (this.ASST_TYCD.Equals("50") || this.ASST_TYCD.Equals("B0"))
                {
                    msg = "외래에서는 발생하지 않는 보조유형(자연분만 & 신생아)입니다.";
                    return -1;
                }

                //의료급여1종 만6세미만은 본인부담율이 동일하므로 외래에서는 없음으로 한다.
                if (this.INSN_TYCD.Equals("21") && this.ASST_TYCD.Equals("60"))
                {
                    this.ASST_TYCD = "00";
                }

                // 산재, 자보는 보훈과 상관이 없다.
                if (this.INSN_TYCD.Substring(0, 1).Equals("3") || this.INSN_TYCD.Substring(0, 1).Equals("4"))
                {
                    this.VTRN_PT_YN = "N";  //보훈환자여부
                    this.MOMR_AGE_DVCD = "N";  // 유공자연령
                    this.INDP_MOMR_YN = "N";  // 독립유공자
                }

                // 건강보험이 아니면 유공자연령 감면이나 독립유공자는 인정이 되지 않는다.
                if (this.INSN_TYCD.Substring(0, 1).Equals("1"))
                {
                    if (this.ASST_TYCD.Equals("99") || this.ASST_TYCD.Equals("D9") || this.ASST_TYCD.Equals("P9"))
                    {
                        this.MOMR_AGE_DVCD = "N";  // 유공자연령
                        this.INDP_MOMR_YN = "N";  // 독립유공자
                    }

                }
                else
                {
                    this.MOMR_AGE_DVCD = "N";  // 유공자연령
                    this.INDP_MOMR_YN = "N";  // 독립유공자
                }

                if (this.INSN_TYCD.Substring(0, 1).Equals("2") && this.ASST_TYCD.Equals("99") && (this.VTRN_PT_YN.Equals("Y") || this.MOMR_AGE_DVCD.Equals("Y")))
                {
                    if (this.APNT_YN.Equals("Y") && this.FRVS_RVST_DVCD.Equals("1"))
                    {
                        msg = "보훈환자가 의료급여를 상실하면 건강보험100%로 접수를 해야 합니다.";
                        return -1;
                    }
                    else
                    {
                        this.INSN_TYCD = "11";
                    }
                }

                if (this.INSN_TYCD.Substring(0, 1).Equals("2") && !this.ASST_TYCD.Equals("99") && this.USCH_APLY_CD.Equals("M012"))
                {
                    if (!this.INSN_CLAM_DEPT_CD.Equals("24"))
                    {
                        msg = "노숙인시설 외래진료 완됩니다. 응급실 접수만 가능합니다.";
                        return -1;
                    }
                }

                // 보훈등외구분은 국비 무자격자와 구분하기 위해서.
                if (!this.VTRN_PT_YN.Equals("Y") || !this.INSN_TYCD.Equals("11") || (!this.ASST_TYCD.Equals("99") && !this.ASST_TYCD.Equals("D9") && !this.ASST_TYCD.Equals("P9")))
                {
                    this.VTRN_FALU_YN = "N";
                }

                if ((this.VTRN_PT_YN.Equals("Y") && this.MOMR_AGE_DVCD.Equals("Y")) || (this.VTRN_PT_YN.Equals("Y") && this.INDP_MOMR_YN.Equals("Y")))
                {
                    msg = "보훈, 유공자연령감면, 독립유공자중 하나만 선택 가능합니다.";
                }

                // TODO :
                // 자동차보험의 보험사와 접수번호를 확인한다.
                if (this.INSN_TYCD.Equals("41"))
                {
                    if (!this.ASCT_RGNO_CD.Equals("ZZZZZ"))
                    {

                    }
                }

                // 초진재진구분코드를 확인한다.
                if (StringService.IsNull(this.FRVS_RVST_DVCD))
                {
                    msg = "초진재진구분이 제대로 입력되지 않았습니다. 최근 정보를 확인하시기 바랍니다.";
                    return -1;
                }

                // TODO :
                // 진료의 출국여부를 확인한다. 외래접수를 할 수 없다.(단, 출국일, 입국일 당일은 접수 가능하다.)

                // 보조유형을 변경한다.
                this.m_ASST_TYCD = clsPACommon.CheckAsstTycd("O", this.m_INSN_TYCD, this.m_ASST_TYCD, this.m_RCPN_AGE);

                // 급여자격구분코드
                if (!afrsstatdvcd.Equals("7") && !afrsstatdvcd.Equals("9"))
                {
                    if (!this.m_ASST_TYCD.Equals("99"))
                    {
                        if (!(this.m_INSN_TYCD.Equals("11") && this.m_PAY_QLFC_DVCD.Equals("02")))
                        {
                            this.m_PAY_QLFC_DVCD = "0";
                        }
                    }
                    else
                    {
                        if (this.m_INSN_TYCD.Equals("11") && this.m_PAY_QLFC_DVCD.Equals("02"))
                        {
                            this.m_PAY_QLFC_DVCD = "0";
                        }
                    }
                }
                //치과만 노인틀니을 적용한다.
                if (!this.MDCR_DEPT_CD.Equals("5500"))
                {
                    this.SNDT_TGPS_DVCD = "0";
                }

                // 자보일부본인부담율을 가져온다.
                int traiusprshrt = 0;
                int.TryParse(DBService.ExecuteScalar(SQL.PA.Sql.SelectTraiUsprShrt(), this.TAIC_PT_UNIQ_NO).ToString(), out traiusprshrt);

                this.TRAI_USPR_SHRT = traiusprshrt;

                //TODO :
                // 실진료의 변경을 확인한다.
                if (afrsstatdvcd.Equals("4") && rowstatdvcd.Equals("A"))
                {

                }

                // 간호확여부 옵션 적용한다. - 의사별 스케줄 예약시 옵션
                if (ConfigService.GetConfigValueString("PA", "NRSN_CNFR", "APNT_APLY_YN").Equals("Y"))
                {
                    this.m_NRSN_CNFR_YN = "Y";

                    if (StringService.IsNull(this.m_PT_MDCR_STAT_DVCD) || this.m_PT_MDCR_STAT_DVCD.Equals("1"))
                    {
                        this.m_PT_MDCR_STAT_DVCD = "2";
                        this.m_MDCR_STRT_DT = DateTimeService.NowDateTimeNoneSeperatorString();
                    }
                }
            }
            catch (Exception ex)
            {
                msg = "외래접수정보 저장 중 오류를 발생했습니다.\r\n " +
                      "Method :  [CheckDataOfPAOPATRT] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return -100;
            }
            return 1;
        }

        #endregion Method : SaveData Method

        #endregion Method : Public Method

        #region Method : Private Method

        private bool GetOutRegistrationInfo(string pid, int ptcmhsno)
        {
            try
            {
                DataTable dtOutRegInfo = new DataTable();

                try
                {
                    DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOPATRT(), ref dtOutRegInfo, "PT_CMHS_NO"
                                                                                            , pid
                                                                                            , ptcmhsno.ToString());
                }
                catch (Exception ex)
                {
                    LogService.ErrorLog(ex);
                }

                if (dtOutRegInfo.Rows.Count > 0)
                {
                    DataRow row = dtOutRegInfo.Rows[0];

                    m_PID = row["PID"].ToString();
                    m_PT_CMHS_NO = int.Parse(row["PT_CMHS_NO"].ToString());
                    m_RCPN_SQNO = int.Parse(row["RCPN_SQNO"].ToString());
                    m_MDCR_DD = row["MDCR_DD"].ToString();
                    m_APNT_TIME = row["APNT_TIME"].ToString();
                    m_MDCR_TIME = row["MDCR_TIME"].ToString();
                    m_MDCR_DEPT_CD = row["MDCR_DEPT_CD"].ToString();
                    m_INSN_CLAM_DEPT_CD = row["INSN_CLAM_DEPT_CD"].ToString();
                    m_EMRM_MMCD_CD = row["EMRM_MMCD_CD"].ToString();
                    m_ISCL_EMRM_MMCD_CD = row["ISCL_EMRM_MMCD_CD"].ToString();
                    m_MDCR_DR_CD = row["MDCR_DR_CD"].ToString();
                    m_REAL_MDCR_DR_CD = row["REAL_MDCR_DR_CD"].ToString();
                    m_INSN_TYCD = row["INSN_TYCD"].ToString();
                    m_ASST_TYCD = row["ASST_TYCD"].ToString();
                    m_ASCT_RGNO_CD = row["ASCT_RGNO_CD"].ToString();
                    m_FRVS_RVST_DVCD = row["FRVS_RVST_DVCD"].ToString();
                    m_MCCH_CMPT_DVCD = row["MCCH_CMPT_DVCD"].ToString();
                    m_HMCR_YN = row["HMCR_YN"].ToString();
                    m_SMCR_YN = row["SMCR_YN"].ToString();
                    m_CMHS_DVCD = row["CMHS_DVCD"].ToString();
                    m_CMHS_MOTV_DVCD = row["CMHS_MOTV_DVCD"].ToString();
                    m_APNT_YN = row["APNT_YN"].ToString();
                    m_APNT_PATH_DVCD = row["APNT_PATH_DVCD"].ToString();
                    m_MCSP_APNT_DVCD = row["MCSP_APNT_DVCD"].ToString();
                    m_CNTT_PRSC_DVCD = row["CNTT_PRSC_DVCD"].ToString();
                    m_NRSN_CNFR_YN = row["NRSN_CNFR_YN"].ToString();
                    m_MDCR_STRT_DT = row["MDCR_STRT_DT"].ToString();
                    m_MDCR_END_DT = row["MDCR_END_DT"].ToString();
                    m_PT_MDCR_STAT_DVCD = row["PT_MDCR_STAT_DVCD"].ToString();
                    m_PRSC_NOTM = int.Parse(row["PRSC_NOTM"].ToString());
                    m_RCPT_NOTM = int.Parse(row["RCPT_NOTM"].ToString());
                    m_EXCP_RESN_CD = row["EXCP_RESN_CD"].ToString();
                    m_VTRN_PT_YN = row["VTRN_PT_YN"].ToString();
                    m_MOMR_AGE_DVCD = row["MOMR_AGE_DVCD"].ToString();
                    m_INDP_MOMR_YN = row["INDP_MOMR_YN"].ToString();
                    m_VTRN_FALU_YN = row["VTRN_FALU_YN"].ToString();
                    m_VTRN_USCH_DVCD = row["VTRN_USCH_DVCD"].ToString();
                    m_VTRN_NON_QLFC_YN = row["VTRN_NON_QLFC_YN"].ToString();
                    m_CLUR_DSBL_DVCD = row["CLUR_DSBL_DVCD"].ToString();
                    m_MAIN_ILNS_CD = row["MAIN_ILNS_CD"].ToString();
                    m_CFSC_RGNO_CD = row["CFSC_RGNO_CD"].ToString();
                    m_CHRN_DSSE_DVCD = row["CHRN_DSSE_DVCD"].ToString();
                    m_TBRC_DVCD = row["TBRC_DVCD"].ToString();
                    m_USCH_APLY_CD = row["USCH_APLY_CD"].ToString();
                    m_REFR_INSTNO = row["REFR_INSTNO"].ToString();
                    m_ECOI_CD = row["ECOI_CD"].ToString();
                    m_HLLF_MNCS_BLCE = int.Parse(row["HLLF_MNCS_BLCE"].ToString());
                    m_OTHR_HSPT_HPTF_YN = row["OTHR_HSPT_HPTF_YN"].ToString();
                    m_MTWM_YN = row["MTWM_YN"].ToString();
                    m_MTWM_BLCE = int.Parse(row["MTWM_BLCE"].ToString());
                    m_VCNT_CLTP_YN = row["VCNT_CLTP_YN"].ToString();
                    m_VCNT_PRTW_YN = row["VCNT_PRTW_YN"].ToString();
                    m_FCLT_APLY_YN = row["FCLT_APLY_YN"].ToString();
                    m_FCLT_APLY_CD = row["FCLT_APLY_CD"].ToString();
                    m_QLFC_RTRV_YN = row["QLFC_RTRV_YN"].ToString();
                    m_PAY_QLFC_DVCD = row["PAY_QLFC_DVCD"].ToString();
                    m_SNDT_TGPS_DVCD = row["SNDT_TGPS_DVCD"].ToString();
                    m_CNST_REFR_YN = row["CNST_REFR_YN"].ToString();
                    m_FXAM_FXRT_DVCD = row["FXAM_FXRT_DVCD"].ToString();
                    m_RRNS_FAFR_DVCD = row["RRNS_FAFR_DVCD"].ToString();
                    m_OTPT_DRG_YN = row["OTPT_DRG_YN"].ToString();
                    m_DRG_DVCD = row["DRG_DVCD"].ToString();
                    m_DRG_NO = row["DRG_NO"].ToString();
                    m_DY_WARD_YN = row["DY_WARD_YN"].ToString();
                    m_ENTS_ENTD_DVCD = row["ENTS_ENTD_DVCD"].ToString();
                    m_DYTM_CNTR_USE_YN = row["DYTM_CNTR_USE_YN"].ToString();
                    m_EMRM_WTNG_YN = row["EMRM_WTNG_YN"].ToString();
                    m_TAIC_PT_UNIQ_NO = row["TAIC_PT_UNIQ_NO"].ToString();
                    m_CLAM_CRTN_YN = row["CLAM_CRTN_YN"].ToString();
                    m_CLAM_REVW_YN = row["CLAM_REVW_YN"].ToString();
                    m_CLAM_CRTN_DEL_RESN = row["CLAM_CRTN_DEL_RESN"].ToString();
                    m_DCNT_RDIA_CD = row["DCNT_RDIA_CD"].ToString();
                    m_DCNT_RDIA_EMNO = row["DCNT_RDIA_EMNO"].ToString();
                    m_RCPN_AGE = int.Parse(row["RCPN_AGE"].ToString());
                    m_RCPN_ADDR_CD = row["RCPN_ADDR_CD"].ToString();
                    m_DC_DD = row["DC_DD"].ToString();
                    m_AFRS_STAT_DVCD = row["AFRS_STAT_DVCD"].ToString();
                    m_ROW_STAT_DVCD = row["ROW_STAT_DVCD"].ToString();
                    m_RGST_DT = row["RGST_DT"].ToString();
                    m_RGSTR_ID = row["RGSTR_ID"].ToString();
                    //m_PT_NM = row["PT_NM"].ToString();
                    //m_FRRN = row["FRRN"].ToString();
                    //m_SRRN = row["SRRN"].ToString();
                    m_ETC_USE_CNTS_1 = row["ETC_USE_CNTS_1"].ToString();     // 주야
                    m_ETC_USE_CNTS_4 = row["ETC_USE_CNTS_4"].ToString();     // 타병원
                    m_ETC_USE_CNTS_5 = row["ETC_USE_CNTS_5"].ToString();     // 강제적용

                    m_RRNO = this.GetFCLT_APLY_RRNO();

                    return true;
                }
                else
                {
                    LogService.DebugLog(String.Format("Patient not found.({0})", pid));
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return false;
        }

        private string GetFCLT_APLY_RRNO()
        {
            // 시설여부 Y가 아니면 인적정보 주민번호를 리턴.
            if (!m_FCLT_APLY_YN.Equals("Y"))
                return string.Format("{0}{1}", m_FRRN, m_SRRN);

            string inpnRrno = "";
            string msg = "";
            if (!clsPACommon.GetInpnRrno(m_PID, m_INSN_TYCD, m_MDCR_DD, ref inpnRrno, ref msg))
            {
                throw new Exception(msg);
            }

            // 피보험자주민등록번호를 리턴.
            if (StringService.IsNotNull(inpnRrno) && !inpnRrno.Equals("NO"))
            {
                return inpnRrno;
            }

            // 피보험자주민등록번호가 없으면 인적정보 주민번호를 리턴.
            return string.Format("{0}{1}", m_FRRN, m_SRRN);
        }

        private bool GetOutRegistrationInfo(string condition, string pid, int ptcmhsno, string mdcrdd)
        {
            try
            {
                DataTable dtOutRegInfo = new DataTable();

                try
                {
                    DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOPATRT_Rec_ContainCancel(), ref dtOutRegInfo, condition
                                                                                                , pid
                                                                                                , ptcmhsno.ToString()
                                                                                                , mdcrdd);
                }
                catch (Exception ex)
                {
                    LogService.ErrorLog(ex);
                }

                if (dtOutRegInfo.Rows.Count > 0)
                {
                    DataRow row = dtOutRegInfo.Rows[0];

                    m_PID = row["PID"].ToString();
                    m_PT_CMHS_NO = int.Parse(row["PT_CMHS_NO"].ToString());
                    m_RCPN_SQNO = int.Parse(row["RCPN_SQNO"].ToString());
                    m_MDCR_DD = row["MDCR_DD"].ToString();
                    m_APNT_TIME = row["APNT_TIME"].ToString();
                    m_MDCR_TIME = row["MDCR_TIME"].ToString();
                    m_MDCR_DEPT_CD = row["MDCR_DEPT_CD"].ToString();
                    m_INSN_CLAM_DEPT_CD = row["INSN_CLAM_DEPT_CD"].ToString();
                    m_EMRM_MMCD_CD = row["EMRM_MMCD_CD"].ToString();
                    m_ISCL_EMRM_MMCD_CD = row["ISCL_EMRM_MMCD_CD"].ToString();
                    m_MDCR_DR_CD = row["MDCR_DR_CD"].ToString();
                    m_REAL_MDCR_DR_CD = row["REAL_MDCR_DR_CD"].ToString();
                    m_INSN_TYCD = row["INSN_TYCD"].ToString();
                    m_ASST_TYCD = row["ASST_TYCD"].ToString();
                    m_ASCT_RGNO_CD = row["ASCT_RGNO_CD"].ToString();
                    m_FRVS_RVST_DVCD = row["FRVS_RVST_DVCD"].ToString();
                    m_MCCH_CMPT_DVCD = row["MCCH_CMPT_DVCD"].ToString();
                    m_HMCR_YN = row["HMCR_YN"].ToString();
                    m_SMCR_YN = row["SMCR_YN"].ToString();
                    m_CMHS_DVCD = row["CMHS_DVCD"].ToString();
                    m_CMHS_MOTV_DVCD = row["CMHS_MOTV_DVCD"].ToString();
                    m_APNT_YN = row["APNT_YN"].ToString();
                    m_APNT_PATH_DVCD = row["APNT_PATH_DVCD"].ToString();
                    m_MCSP_APNT_DVCD = row["MCSP_APNT_DVCD"].ToString();
                    m_CNTT_PRSC_DVCD = row["CNTT_PRSC_DVCD"].ToString();
                    m_NRSN_CNFR_YN = row["NRSN_CNFR_YN"].ToString();
                    m_MDCR_STRT_DT = row["MDCR_STRT_DT"].ToString();
                    m_MDCR_END_DT = row["MDCR_END_DT"].ToString();
                    m_PT_MDCR_STAT_DVCD = row["PT_MDCR_STAT_DVCD"].ToString();
                    m_PRSC_NOTM = int.Parse(row["PRSC_NOTM"].ToString());
                    m_RCPT_NOTM = int.Parse(row["RCPT_NOTM"].ToString());
                    m_EXCP_RESN_CD = row["EXCP_RESN_CD"].ToString();
                    m_VTRN_PT_YN = row["VTRN_PT_YN"].ToString();
                    m_MOMR_AGE_DVCD = row["MOMR_AGE_DVCD"].ToString();
                    m_INDP_MOMR_YN = row["INDP_MOMR_YN"].ToString();
                    m_VTRN_FALU_YN = row["VTRN_FALU_YN"].ToString();
                    m_VTRN_USCH_DVCD = row["VTRN_USCH_DVCD"].ToString();
                    m_VTRN_NON_QLFC_YN = row["VTRN_NON_QLFC_YN"].ToString();
                    m_CLUR_DSBL_DVCD = row["CLUR_DSBL_DVCD"].ToString();
                    m_MAIN_ILNS_CD = row["MAIN_ILNS_CD"].ToString();
                    m_CFSC_RGNO_CD = row["CFSC_RGNO_CD"].ToString();
                    m_CHRN_DSSE_DVCD = row["CHRN_DSSE_DVCD"].ToString();
                    m_TBRC_DVCD = row["TBRC_DVCD"].ToString();
                    m_USCH_APLY_CD = row["USCH_APLY_CD"].ToString();
                    m_REFR_INSTNO = row["REFR_INSTNO"].ToString();
                    m_ECOI_CD = row["ECOI_CD"].ToString();
                    m_HLLF_MNCS_BLCE = int.Parse(row["HLLF_MNCS_BLCE"].ToString());
                    m_OTHR_HSPT_HPTF_YN = row["OTHR_HSPT_HPTF_YN"].ToString();
                    m_MTWM_YN = row["MTWM_YN"].ToString();
                    m_MTWM_BLCE = int.Parse(row["MTWM_BLCE"].ToString());
                    m_VCNT_CLTP_YN = row["VCNT_CLTP_YN"].ToString();
                    m_VCNT_PRTW_YN = row["VCNT_PRTW_YN"].ToString();
                    m_FCLT_APLY_YN = row["FCLT_APLY_YN"].ToString();
                    m_FCLT_APLY_CD = row["FCLT_APLY_CD"].ToString();
                    m_QLFC_RTRV_YN = row["QLFC_RTRV_YN"].ToString();
                    m_PAY_QLFC_DVCD = row["PAY_QLFC_DVCD"].ToString();
                    m_SNDT_TGPS_DVCD = row["SNDT_TGPS_DVCD"].ToString();
                    m_CNST_REFR_YN = row["CNST_REFR_YN"].ToString();
                    m_FXAM_FXRT_DVCD = row["FXAM_FXRT_DVCD"].ToString();
                    m_RRNS_FAFR_DVCD = row["RRNS_FAFR_DVCD"].ToString();
                    m_OTPT_DRG_YN = row["OTPT_DRG_YN"].ToString();
                    m_DRG_DVCD = row["DRG_DVCD"].ToString();
                    m_DRG_NO = row["DRG_NO"].ToString();
                    m_DY_WARD_YN = row["DY_WARD_YN"].ToString();
                    m_ENTS_ENTD_DVCD = row["ENTS_ENTD_DVCD"].ToString();
                    m_DYTM_CNTR_USE_YN = row["DYTM_CNTR_USE_YN"].ToString();
                    m_EMRM_WTNG_YN = row["EMRM_WTNG_YN"].ToString();
                    m_TAIC_PT_UNIQ_NO = row["TAIC_PT_UNIQ_NO"].ToString();
                    m_CLAM_CRTN_YN = row["CLAM_CRTN_YN"].ToString();
                    m_CLAM_REVW_YN = row["CLAM_REVW_YN"].ToString();
                    m_CLAM_CRTN_DEL_RESN = row["CLAM_CRTN_DEL_RESN"].ToString();
                    m_DCNT_RDIA_CD = row["DCNT_RDIA_CD"].ToString();
                    m_DCNT_RDIA_EMNO = row["DCNT_RDIA_EMNO"].ToString();
                    m_RCPN_AGE = int.Parse(row["RCPN_AGE"].ToString());
                    m_RCPN_ADDR_CD = row["RCPN_ADDR_CD"].ToString();
                    m_DC_DD = row["DC_DD"].ToString();
                    m_AFRS_STAT_DVCD = row["AFRS_STAT_DVCD"].ToString();
                    m_ROW_STAT_DVCD = row["ROW_STAT_DVCD"].ToString();
                    m_RGST_DT = row["RGST_DT"].ToString();
                    m_RGSTR_ID = row["RGSTR_ID"].ToString();
                    m_PT_NM = row["PT_NM"].ToString();
                    m_FRRN = row["FRRN"].ToString();
                    m_SRRN = EncryptionService.Decoding(row["SRRN_ECPT"].ToString());
                    m_DOBR = row["DOBR"].ToString();
                    m_AGE = int.Parse(row["AGE"].ToString());
                    m_SEX_DVCD = row["SEX_DVCD"].ToString();
                    m_ETC_USE_CNTS_1 = row["ETC_USE_CNTS_1"].ToString();
                    m_ETC_USE_CNTS_4 = row["ETC_USE_CNTS_4"].ToString();
                    m_ETC_USE_CNTS_5 = row["ETC_USE_CNTS_5"].ToString();
                    m_CLPH_TEL = row["CLPH_TEL"].ToString();

                    m_RRNO = this.GetFCLT_APLY_RRNO();

                    return true;
                }
                else
                {
                    LogService.DebugLog(String.Format("Patient not found.({0})", pid));
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return false;
        }

        /// <summary>
        /// DRG퇴원, 낮병동 환자  당일 외래 접수 불가.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        private int IsDrgDschPatient(ref string msg)
        {
            if (!(INSN_CLAM_DEPT_CD.Equals("24") || ASST_TYCD.Equals("99")))
            {
                if (DBService.ExecuteInteger(SQL.PA.Sql.SelectCountIsDrgDsch(), PID
                                                                             , MDCR_DD) > 0)
                {
                    msg = "DRG 퇴원 당일 외래접수를 할 수 없습니다. 퇴원 취소 후 퇴원수납을 하시기 바랍니다. \r\n (단, 응급의학과 또는 보조유형 보험100%제외)";
                    return -1;
                }
                else
                {
                    if (DBService.ExecuteInteger(SQL.PA.Sql.SelectCountIsDayWard(), PID
                                                                                  , PT_CMHS_NO.ToString()
                                                                                  , MDCR_DD) > 0)
                    {
                        msg = "낮병동 환자입니다. 당일 외래접수를 할 수 없습니다. \r\n (단, 응급의학과 또는 보조유형 보험100%제외)";
                        return -1;
                    }
                }
            }
            return 1;
        }

        /// <summary>
        /// 가장최근 환자내원번호를 가져온다. 재진예약접수시 환자접수정보를 가져오기 위해서
        /// </summary>
        /// <param name="otptadmsdvcd"></param>
        /// <param name="ptcmhsno"></param>
        private bool GetOldPtCmhsNo(string pid, ref int ptcmhsno)
        {
            try
            {
                // 최신 내원번호, 내원구분코드를 구한다.
                DataTable dt = new DataTable();

                DBService.ExecuteDataTable(SQL.PA.Sql.SelectLastPtCmhsNo_ForApnt(pid, m_l090_lime_accept)
                                         , ref dt);

                if (dt.Rows.Count.Equals(0))
                    return false;

                int.TryParse(dt.Rows[0]["PT_CMHS_NO"].ToString(), out ptcmhsno);

                //// 외래 / 입원을 확인한다.
                //if (otptadmsdvcd.Equals("I"))
                //{
                //    // 재원중인지 확인한다.
                //    if (DBService.ExecuteInteger(SQL.PA.Sql.SelectPAIPATRT_ADMS_YN(), this.m_PID, "J") >= 1)
                //    {
                //int.TryParse(DBService.ExecuteScalar(SQL.PA.Sql.SelectMaxOfPT_CMHS_NO(), this.m_PID
                //                                                                                   , "I").ToString(), out ptcmhsno);
                //    }
                //    else
                //        int.TryParse(DBService.ExecuteScalar(SQL.PA.Sql.SelectMaxOfPT_CMHS_NO(), this.m_PID
                //                                                                                   , "D").ToString(), out ptcmhsno);
                //}
                //else
                //{
                //    int.TryParse(DBService.ExecuteScalar(SQL.PA.Sql.SelectMaxOfPT_CMHS_NO(), this.m_PID
                //                                                                              , "O").ToString(), out ptcmhsno);
                //}
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// 외래접수정보 Insert후 의뢰서정보를 확인한다. 
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        private bool CheckMdcrReferInfo(string afrsstatdvcd, string rowstatdvcd, ref string msg)
        {
            try
            {

                // TODO:
                // 진료의뢰서 
                if (afrsstatdvcd.Equals("2") && rowstatdvcd.Equals("A"))     // 접수 의뢰서생성
                {

                }
                else if (afrsstatdvcd.Equals("4") && rowstatdvcd.Equals("A")) // 접수변경 의뢰서변경
                {

                }
                else if (afrsstatdvcd.Equals("3") && rowstatdvcd.Equals("F")) // 접수취소 의뢰서삭제
                {

                }
            }
            catch (Exception ex)
            {
                msg = "외래접수정보Insert후 자료확인 중 오류를 발생했습니다.\r\n " +
                      "Method :  [clsOutRegistrationInfo -> CheckPostInsertPAOPATRT] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }
            return true;
        }

        #endregion  Method : Private Method

        internal void SaveNewOutReginfo()
        {
            throw new NotImplementedException();
        }
    }
}