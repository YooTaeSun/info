//********************************************************************
// Class 명 : ucOrecRegInf1
// 역    할 : 환자정보 User Control
// 작 성 자 : PGH
// 작 성 일 : 2017-09-19
//********************************************************************
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Lime.BusinessControls;
using Lime.Framework;
using Lime.Framework.BusinessService;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public partial class ucOrecRegInf1 : BaseUserControl
    {
        #region Define : Event
        public delegate void PatientSelectedEventHandler(object sender, SelectDataEventArgs e);
        public event PatientSelectedEventHandler PatientSelected;

        public delegate void PatientClear();
        public event PatientClear OnPatientClear;

        /* 미수납 신용 승인 여부 체크*/
        public delegate bool CreditCheck(string dvcd); // 리턴 false : 기존 환자 번호 표시 (Y), 
        public event CreditCheck OnCreditCheck;

        public delegate void SystemLockedEventHandler(bool locked);
        public event SystemLockedEventHandler SystemLocked;
        #endregion

        #region Define : Member
        clsOutRegistrationInfo m_OutRegInfo = new clsOutRegistrationInfo();
        public string m_Mdcr_Dd = String.Empty;
        public string m_FrvsRvstDvcd = String.Empty;
        public string m_ChangeFlag = String.Empty;    // 접수변경여부
        public string m_QtyZeroYn = String.Empty;

        private bool EnableSave = false;

        public string m_TbrcSuptTrgtYn = String.Empty;
        public string m_HpvSameIlnsYn = String.Empty;
        public string m_HpvOthrIlnsYn = String.Empty;
        public string m_AllDcPrscDvcd = String.Empty;
        public string m_NhicYn = "NO";
        public int m_TotlMdcrAmt = 0;              // 총진료비금액
        public string m_DrgMefeYn = String.Empty;   // DRG정액수가발생여부
        private int m_PrscCount = 0;              // 처방갯수
        private int m_BillCount = 0;              // 영수증갯수
        private string m_ClamCmplYn = String.Empty;   // 청구완료여부
        private clsNhisM2 m_M2 = null;
        private string m_NhisErrorYn = String.Empty;     // 자격조회 장애여부 
        private string m_ReadOnly = String.Empty;     // 읽기전용여부
        private bool m_FrvsRvstDvcdSave = false;    // 초재진구분코드변경여부

        private string rrno = string.Empty;

        private string m_Compare_ASST_TYCD = string.Empty;
        public string Compare_ASST_TYCD { get { return m_Compare_ASST_TYCD; } set { m_Compare_ASST_TYCD = value; } }
        private string m_Compare_CFSC_RGNO_CD = string.Empty;
        public string Compare_CFSC_RGNO_CD { get { return m_Compare_CFSC_RGNO_CD; } set { m_Compare_CFSC_RGNO_CD = value; } }

        private string m_EMRM_MMCD_CD_bk = string.Empty;
        public string EMRM_MMCD_CD_bk { get { return m_EMRM_MMCD_CD_bk; } set { m_EMRM_MMCD_CD_bk = value; } }

        #endregion Define : Member

        #region Property : Member Property
        public clsOutRegistrationInfo OutRegInfo
        {
            get { return m_OutRegInfo; }
            set { m_OutRegInfo = value; }
        }

        public bool FrvsRvstDvcdSave
        {
            get { return m_FrvsRvstDvcdSave; }
        }

        #endregion Property : Member Property

        #region Construction
        public ucOrecRegInf1()
        {
            InitializeComponent();
        }
        #endregion Construction

        #region Screen Load
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode) return;

            Initialize();
            InitializeCombo();
            InitializeEvent();

        }
        #endregion Screen Load

        #region Method : Initialize Method

        private void Initialize()
        {
            //선택진료여부
            cboSmcrYn.Items.Add("Y", "예");
            cboSmcrYn.Items.Add("N", "아니오");

            //낮병동여부
            cboDyWardYn.Items.Add("Y", "예");
            cboDyWardYn.Items.Add("N", "아니오");

            // 결핵
            txtTbrcDvcd.ReadOnly = true;
            txtTbrcDvcd.Appearance.BackColor = txtPtNm.Appearance.BackColor;
        }

        private void InitializeCombo()
        {
            if (this.DesignMode) return;

            // 상해외인코드
            cboEcoiCd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            string sqltext = @"SELECT LWRN_OVRL_CD
                                    , '['||LWRN_OVRL_CD||']'||LWRN_OVRL_CDNM AS LWRN_OVRL_CDNM
                                 FROM BICDINDT 
                                WHERE OVRL_CD = 'CL_ECOI_CD' 
                                  AND APLY_STRT_DD <= TO_CHAR(SYSDATE, 'YYYYMMDD') 
                                  AND TO_CHAR(SYSDATE, 'YYYYMMDD') <= APLY_END_DD";
            DataTable dt = new DataTable();
            DBService.ExecuteDataTable(sqltext, ref dt);
            cboEcoiCd.SetComboItems(dt, "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");

            //진료부서
            cboMdcrDeptCd.SetComboItems(ClinicList.LoadList(), "DEPT_CD", "DEPT_HNM");

            //응급실주과
            cboEmrmMmcdCd.SetComboItems(ClinicList.LoadList(), "DEPT_CD", "DEPT_HNM");

            //할인코드
            clsPACommon.SetComboPA(cboDcntRdiaCd, "DCNT_CD", "DCNT_CDNM", "1", OutRegInfo.MDCR_DD, "NO");

            // 예외사유코드
            clsPACommon.SetComboPA(cboExcpResnCd, "EXCP_RESN_CD", "EXCP_RESN_CNTS", "1", OutRegInfo.MDCR_DD, "NO");

            // 본인부담코드 산정특례코드관리
            clsPACommon.SetComboPA(cboUschAplyCd, "CFSC_CD", "CFSC_CD_NM", "1", OutRegInfo.MDCR_DD, "NO");

            //주야구분코드
            cboDYNT_DVCD_DRG.SetComboItems(OverallCodeList.GetDataList("DYNT_DVCD_DRG"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
        }

        private void InitializeEvent()
        {
            txtPid.KeyDown += OntxtPid_KeyDown;
            txtPid.EditorButtonClick += txtPid_EditorButtonClick;
            cboInsnTycd.ValueChanged += OnCombo_ValueChanged;
            cboFrvsRvstDvcd.ValueChanged += OnCombo_ValueChanged;
            //cboEcoiCd.ValueChanged += OnCombo_ValueChanged;
            cboCmhsDvcd.ValueChanged += OnCombo_ValueChanged;
            cboMcchCmptDvcd.ValueChanged += OnCombo_ValueChanged;
            cboDyWardYn.ValueChanged += OnCombo_ValueChanged;
            cboEmrmMmcdCd.ValueChanged += OnCombo_ValueChanged;

            lblMediParams.Visible = DOPack.UserInfo.USER_CD.Equals("LIME") ? true : false;
            lblMediParams.DoubleClick += (s, e) => { Clipboard.Clear(); Clipboard.SetData(DataFormats.Text, lblMediParams.Tag == null ? string.Empty : lblMediParams.Tag.ToString()); };

            btnNhic.Click += btnNhic_Click;
        }

        #endregion

        #region Method : Public Method

        public void Clear()
        {
            // 초기화시 LOCK을 해제한다.
            this.UnLockSystem(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString());

            m_FrvsRvstDvcd = String.Empty;
            m_QtyZeroYn = String.Empty;
            m_TbrcSuptTrgtYn = String.Empty;
            m_HpvSameIlnsYn = String.Empty;
            m_HpvOthrIlnsYn = String.Empty;
            m_AllDcPrscDvcd = String.Empty;
            m_NhicYn = "NO";
            m_TotlMdcrAmt = 0;
            m_DrgMefeYn = String.Empty;
            EnableSave = true;
            m_ChangeFlag = "N";
            m_NhisErrorYn = "N";
            m_ReadOnly = "N";
            OutRegInfo.Clear();
            this.ClearControlData();
            chkReBurn.Checked = false;      //lblForceChange게 안정화되면 없앨거임            
            lblForceChange.Visible = false;
            m_EMRM_MMCD_CD_bk = string.Empty;
            lblPregnant.Visible = false;             // 임부
            lblDisasterSupt.Visible = false;         // 재난지원(코로나19)
            lblPtMdcrStatDvcd9.Visible = false;      // 과취소
            lblIncsDr.Visible = false;               // 산재 지정의

            m_Compare_ASST_TYCD = string.Empty;
            m_Compare_CFSC_RGNO_CD = string.Empty;

        }

        /// <summary>
        /// 01.환자접수등록정보를 확인한다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public int CheckPatientRegistInfo(ref string msg)
        {
            //string msg = String.Empty;
            string etcusecnts2 = String.Empty;
            string assttycd = String.Empty;
            string cfscrgnocd = String.Empty;
            //string ecoicd = String.Empty;
            string tbrcdvcd = String.Empty;
            string iovmsg = String.Empty;
            int unclamt = 0;                    // 미수잔액
            string uncldd = String.Empty;         // 미수발새일자
            int uschrtn = 0;                    // 본인부담리턴값
            string uschaplycd = String.Empty;          // 본인부담코드
            string uscherrorcd = String.Empty;          // 본인부담에러코드
            string uschmsg = String.Empty;          // 본인부담메시지
            string refchk = String.Empty;
            string refmsg = String.Empty;
            string cfhcRem = String.Empty;   // 건생비잔액
            bool nonmcchcmpt = false; // 진찰료산정안함여부
            try
            {
                EnableSave = true;
                //사망환자확인 루틴
                if (ConfigService.GetConfigValueBool("PA", "RECEIPT", "DEATH_CHECK", false))
                {
                    // 사망환자 여부 확인

                    if (StringService.IsNotNull(this.PatientInfo.DETH_DD) && DateTimeService.IsDateTime(this.PatientInfo.DETH_DD))
                    {
                        LxMessage.Show("사망환자로 등록된 환자등록번호입니다! [ 사망일자 : " + this.PatientInfo.DETH_DD + " ]");
                    }
                    else
                    {
                        // TODO : 사망진단서 확인 
                        // EMR에서 뷰제공하기로 함.

                    }
                }

                // 진료완료만 수납 처리 할것인지 확인?
                // 처방이 한건이라도 있는 경우만 체크함.
                if (int.Parse(OutRegInfo.PT_MDCR_STAT_DVCD) < 5 && clsPACommon.ReturnPrscIssuedCnt(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO, "%", "AC") >= 1)
                {
                    msg = "처방입력 진료완료전(진료중)입니다. 처방입력 진료완료후 수납하세요!!";

                    if (ConfigService.GetConfigValueString("%", "MDCR_STAT_CHECK_YN", "MDCR_STAT_CHECK_YN", "N").Equals("Y"))
                    {
                        return -1;
                    }
                }

                // 당일 입원취소인 경우 알림메시지
                if (DBService.ExecuteInteger(SQL.PA.Sql.SelectAdmsCancelCount(), OutRegInfo.PID, OutRegInfo.MDCR_DD) > 0)
                    LxMessage.Show("당일 입원 취소 환자입니다.", "확인");

                // OCS오픈일자를 확인한다.
                if (!clsPACommon.CheckOcsOpenDate(OutRegInfo.MDCR_DD))
                    return -1;

                // TODO : 개인정보수집동의서 작성유무

                // TODO : 보훈인경우 보훈개인정보수집동의서를 작성했을 경우 EMR에 동의서 존재 여부를 확인한다.

                // TODO : OPEN CARD

                // 보조유형
                clsPACommon.SetComboPA(cboAsstTycd, "ASST_TYCD", "LWRN_OVRL_CDNM", OutRegInfo.INSN_TYCD, OutRegInfo.MDCR_DD);
                cboAsstTycd.SelectValue(OutRegInfo.ASST_TYCD);

                // Start : 자격조회여부를 확인한다. 
                // 건강생활유지잔액, 산전지원비잔액을 가져온다.
                if (clsPACommon.ReturnQlfcRtrvYn(OutRegInfo.INSN_TYCD, OutRegInfo.ASST_TYCD, OutRegInfo.MDCR_DD, OutRegInfo.FCLT_APLY_YN))
                {
                    if (OutRegInfo.INSN_TYCD.Substring(0, 1) == "2")
                    {
                        //의료급여 미승인 건 존재 여부를 확인한다.
                        string dlwtdvcd = String.Empty;
                        if (!clsPACommon.ReturnDlwtDvcdPANHM3MA(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), ref dlwtdvcd))
                        {
                            msg = "이전 의료급여 미승인 건 존재 여부를 확인중 오류 발생";
                            return -11;
                        }
                        if (dlwtdvcd.Equals("0"))
                        {
                            msg = "내원정보중 진료확인번호 미승인 정보가 존재합니다. \rrn" +
                                  "건생비(산전지원비) 청구액이 존재하는 경우이므로 현재의 건생비(산전지원비)잔액을 \r\n" +
                                  "정상적으로 가져올수가 없기 때문에 추가 수납이 불가능합니다. \r\n " +
                                  "승인서버를 확인하거나 전산팀에 문의 하세요!";
                            return -12;
                        }

                        if (!SelectIsNonCompletion(OutRegInfo.PID, ref msg))
                        {
                            LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);

                            EnableSave = false;
                        }
                    }

                    // 자격조회를 한다.
                    // M1 을 생성한다. M2 를 받는다.
                    if (!ShowQualificationInfo("N", OutRegInfo.PID, OutRegInfo.MDCR_DD, OutRegInfo.PT_NM, OutRegInfo.RRNO, OutRegInfo.INSN_TYCD, ref msg))
                    {
                        DBService.RollbackTransaction();
                        LxMessage.ShowError(msg);
                        return -13;
                    }

                    if (OutRegInfo.INSN_TYCD.Substring(0, 1) == "2")
                    {
                        if (this.m_NhisErrorYn.Equals("Y"))
                        {
                            LxMessage.Show("자격조회 시스템 장애 중입니다.! \r\n 보조유형을 보험100%으로 우선 처리하시기 바랍니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            this.m_NhicYn = "YES";

                            if (DBService.ExecuteScalar("SELECT CONF_VAL FROM ADCONFDT WHERE SYSTEM_CD = 'PA' AND CONF_TYPE = 'RECEIPT' AND CONF_CD = 'NO_CHECK_NHIS_MDAD'").ToString().Equals("N"))
                            {
                                txtAsctRgnoCd.Text = this.m_M2.protAdminSym;    // 조합기호코드

                                // 건강생활유지비잔액
                                decimal.TryParse(this.m_M2.cfhcRem, out decimal cfhc_rem);
                                txtHllfMncsBlce.Text = string.Format("{0:#,##0}", cfhc_rem);

                                cfhcRem = this.m_M2.cfhcRem;
                                // 이전 건강생활유지비잔액을 가져온다.
                                SelectBeforeHealthLifeAmt(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO);

                                // this.m_M2.pregRemAmt // TODO : 산전지원비잔액
                                if (this.m_M2.qlfType.Equals("N") || (!this.m_M2.qlfType.Equals("7") && !this.m_M2.qlfType.Equals("8")))
                                {
                                    if (DateTimeService.ConvertDateTime(OutRegInfo.MDCR_DD) > DateTimeService.ConvertDateTime(DateTimeService.NowDateNoneSeperatorString()) && this.m_M2.qlfType.Equals("N"))
                                    {
                                        LxMessage.Show("의료급여 자격자는 미래처방에 대해서 수납를 할 수 없습니다. \r\n 금액확인만 가능하며, 최종 확정된 금액은 아닙니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);

                                        EnableSave = false;
                                    }
                                    else
                                    {

                                        LxMessage.Show("현재 환자는 의료급여 자격자가 아닙니다.\r\n " +
                                                       "보험100% 또는 자격 재 조회를 하여 주시기 바랍니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        return -14;
                                    }
                                }

                                if (StringService.IsNvl(this.m_M2.sbrdnType, "NO").Equals("NO") && DateTimeService.ConvertDateTime(StringService.IsNvl(this.m_M2.payRestricDt, "29991231")) <= DateTimeService.ConvertDateTime(OutRegInfo.MDCR_DD))
                                {

                                    LxMessage.Show("급여제한일이 지난 일자입니다. 보험100%로 처리하여 주시기 바랍니다. \r\n" +
                                                   "급여제한일 : " + this.m_M2.payRestricDt, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    return -15;
                                }

                                // 본인부담여부코드를 다시 확인한다.
                                uschrtn = clsPACommon.CheckUschAplyCd("NO", "NO", "NO", OutRegInfo.USCH_APLY_CD, OutRegInfo.CMHS_DVCD, this.m_M2.sbrdnType, this.m_M2.ykiho1, this.m_M2.ykiho2, this.m_M2.ykiho3, this.m_M2.ykiho4,
                                                                      ref uschaplycd, ref uscherrorcd, ref uschmsg);
                                if (uscherrorcd.Equals("ERROR"))
                                {
                                    LxMessage.Show("현재 본인부담적용코드 : " + OutRegInfo.USCH_APLY_CD + ", 가능 본인부담코드는 : " + uschaplycd + " 입니다. \r\n" +
                                                   "내역변경하시기 바랍니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                    //OnPatientSelected("INSNCHANGE", OutRegInfo.PID);
                                    //return 1;
                                }
                                else
                                {
                                    if (OutRegInfo.USCH_APLY_CD.Equals("M009") && !OutRegInfo.MDCR_DEPT_CD.Equals("2400"))
                                    {
                                        LxMessage.Show("현재 본인부담적용코드 : " + OutRegInfo.USCH_APLY_CD + ", 가능 본인부담코드는 : B009, B005 입니다. \r\n" +
                                                       "내역변경하시기 바랍니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                        //OnPatientSelected("INSNCHANGE", OutRegInfo.PID);
                                        //return 1;
                                    }
                                }
                            }
                        }

                        DataTable dthealth = new DataTable();

                        if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectHealthLifeAmt(), ref dthealth, OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString()))
                        {
                            msg = "[SelectHealthLifeAmt]오류내용 : [ " + DBService.ErrorCode + " ]" + DBService.ErrorMessage;
                            return -1;
                        }

                        if (dthealth.Rows.Count > 0)
                        {
                            DataRow row = dthealth.Rows[0];
                            int hllfmncsblce = 0;
                            int hllfmncsclamamt = 0;
                            int.TryParse(row["HLLF_MNCS_BLCE"].ToString(), out hllfmncsblce);
                            int.TryParse(row["HLLF_MNCS_CLAM_AMT"].ToString(), out hllfmncsclamamt);
                            txtMdadPrmtNo.Text = row["MDAD_PRMT_NO"].ToString();       // 진료확인번호
                            txtOldHllfMncsBlce.Text = string.Format("{0:#,##0}", hllfmncsblce + hllfmncsclamamt);     // 이전 건생비 잔액
                            txtHllfMncsClamAmt.Text = string.Format("{0:#,##0}", hllfmncsclamamt);                    // 이전 건생비 청구 금액
                        }
                    }
                    else
                    {
                        if (this.m_M2 != null & !this.m_NhisErrorYn.Equals("Y"))
                        {// 중증등록내역을 확인한다.
                            clsPACommon.CheckNhicCancer(OutRegInfo.PID, OutRegInfo.MDCR_DD, this.m_M2.disRegPrson2, this.m_M2.disRegPrson4, this.m_M2.disRegPrson5, this.m_M2.disRegPrson9, this.m_M2.preInfant, this.m_M2.disRegPrson12, ref refchk, ref refmsg);

                            if (refchk.Equals("Y"))
                            {
                                LxMessage.Show(refmsg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }

                // End : 자격조회여부를 확인한다. 

                //DBService.BeginTransaction();
                // TODO : 의사출국확인
                // TODO : 독립유공자사용여부를 확인한다.
                // TODO : 전문의 본인이 본인진료과 진료시 진찰료 산정안함.
                // TODO : 전문의 진료 가능 여부 체크.
                //자보환자 유효성 확인한다.
                if (OutRegInfo.INSN_TYCD == "41" && OutRegInfo.ASST_TYCD != "99")
                {
                    if (OutRegInfo.ASCT_RGNO_CD != "ZZZZZ")
                    {
                        if (DBService.ExecuteScalar(SqlPack.Function.SelectFN_BI_READ_BIINCDMA(), OutRegInfo.ASCT_RGNO_CD
                                                                                                , OutRegInfo.INSN_TYCD
                                                                                                , "MNDT_YN").ToString() != "Y")
                        {
                            msg = "보헙사 코드가 존재하지 않거나, 사용하지 않는 보험사코드입니다. 확인하세요!!";
                            return -1;
                        }

                        if (!CheckTraiIncsValid(OutRegInfo.INSN_TYCD, ref msg))
                            return -1;

                        // TODO : 지급심사요청건
                        // 자보산재관리에서 지급심사요청을 등록/취소할 수 있다.

                        if (DBService.ExecuteScalar(SQL.PA.Sql.SelectRevwRqstYnOfPAOPATRT(), OutRegInfo.PID
                                                                                          , OutRegInfo.PT_CMHS_NO.ToString()).ToString().Equals("Y"))
                        {
                            msg = "선택한 접수정보는 자동차보험 지급심사요청건으로 등록된 정보입니다. \r\n" +
                                  "수납을 위해서는 지급심사요청을 취소 요청하세요.[문의 : 자동차보험 담당자]";
                            return -1;
                        }
                        // TODO : 본인일부부담율을 가져와서 접수정보에 담는다.
                        int traiusprshrt = 0;
                        if (!CheckTraiUsprShrt(OutRegInfo.TAIC_PT_UNIQ_NO, ref traiusprshrt, ref msg))
                        {
                            return -1;
                        }

                        OutRegInfo.TRAI_USPR_SHRT = traiusprshrt;

                    }
                }
                else if (OutRegInfo.INSN_TYCD == "31" && OutRegInfo.ASST_TYCD != "99" && OutRegInfo.ASST_TYCD != "G")
                {
                    if (!CheckTraiIncsValid(OutRegInfo.INSN_TYCD, ref msg))
                        return -1;

                    // TODO 산재환자관리 PAIPATMA : 산재보험 적용 진료과 인지 확인한다.
                }

                if (StringService.IsNull(OutRegInfo.INSN_CLAM_DEPT_CD.Trim()))
                {
                    // 청구부서 가져온다.
                    string insnclamdeptcd = ClinicList.GetColumnValue(OutRegInfo.MDCR_DEPT_CD, "INSN_CLAM_DEPT_CD").ToString();

                    OutRegInfo.INSN_CLAM_DEPT_CD = StringService.IsNvl(insnclamdeptcd, " ");
                }

                //내원구분이 검진관련이고 진찰료산정이면 보험100%이 아닌 건강보험이나 의료급여로 변경 청구한다.
                etcusecnts2 = OverallCodeList.GetColumnValue("CMHS_DVCD", OutRegInfo.CMHS_DVCD, "ETC_USE_CNTS_2").ToString();

                if ((etcusecnts2 == "2" || etcusecnts2 == "3" || etcusecnts2 == "4" || etcusecnts2 == "5") && OutRegInfo.ASST_TYCD == "99" && OutRegInfo.MCCH_CMPT_DVCD == "Y" && OutRegInfo.INSN_CLAM_DEPT_CD != "99")
                {
                    msg = "검진당일 검진이외의 진료를 받는 경우 진찰료를 산정하고 청구할 수 있습니다. \r\n 보험으로 내역 변경 처리하세요!!";
                    LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //OnPatientSelected("INSNCHANGE", OutRegInfo.PID);
                    //return -1;
                }

                this.m_FrvsRvstDvcdSave = false;
                //초재진변경, 접수변경재계산의 경우 초재진변경을 체크하지 않는다.
                if (m_FrvsRvstDvcd == "Y" && m_ChangeFlag != "F")
                {
                    string frvsrvstdvcd = OutRegInfo.FRVS_RVST_DVCD;

                    if (!frvsrvstdvcd.Equals("1")) // 신환환자가 아니면
                    {
                        msg = String.Empty;
                        if (!OutRegInfo.CheckFrvsRvstDvcd(ref msg))
                        {
                            LxMessage.Show(msg + " 초진재진 체크중 오류가 발생헀습니다. ", "초진재진체크", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            return 1;
                        }

                        //미수납 처방이 있는지 확인한다.
                        //미수납 처방이 있는 경우에 초진재진구분이 변경되는 경우 메시지를 띄운다.
                        if (frvsrvstdvcd != OutRegInfo.FRVS_RVST_DVCD && clsPACommon.ReturnPrscIssuedCnt(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO, "N", "ALL") > 0)
                        {
                            string frvsrvstnm = OverallCodeList.GetColumnValue("FRVS_RVST_DVCD", OutRegInfo.FRVS_RVST_DVCD, "LWRN_OVRL_CDNM").ToString();

                            if (LxMessage.Show("초진재진구분이 맞지 않습니다. 다음과 같이 변경하시겠습니까? \r\n [초진재진구분코드 : " + OutRegInfo.FRVS_RVST_DVCD + "(" + frvsrvstnm + ") ] \r\n 수납처리전까지는 저장되지 않습니다.", "초진재진변경확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {

                                cboFrvsRvstDvcd.SelectValue(OutRegInfo.FRVS_RVST_DVCD);
                                this.m_FrvsRvstDvcdSave = true;
                            }
                            else
                            {
                                OutRegInfo.FRVS_RVST_DVCD = frvsrvstdvcd;
                            }
                        }
                        else if (frvsrvstdvcd != OutRegInfo.FRVS_RVST_DVCD)
                        {
                            // 초재구분이 변경되었더라도 처방이 없거나 수납 처방이 있는 경우에는 초재구분을 변경하지 않는다.
                            OutRegInfo.FRVS_RVST_DVCD = frvsrvstdvcd;
                        }
                    }
                }

                if (m_ChangeFlag != "F")
                {//양한방 동일보험유형 진료내역 존재 확인
                    if (!CheckWestMediAndOrieMedi(ref msg))
                    {
                        DBService.RollbackTransaction();
                        LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return -1;
                    }
                }

                // 요양병원 입원여부
                lblMDCAREHSPTHSPTZYN.Visible = Lime.BusinessControls.clsPACommon.SelectMDCAREHSPTHSPTZYN(false, OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString());

                /*************************** 내역변경 확인 Start ************************/
                if (m_ChangeFlag == "F")
                {
                    // TODO : 접수정보 백업 생성
                    // 내역정보변경있으면 변경내역저장

                    OutRegInfo.MCCH_CMPT_DVCD = cboMcchCmptDvcd.SelectedValue;   // 진찰료 산정 구분코드
                    OutRegInfo.CMHS_DVCD = cboCmhsDvcd.SelectedValue;       // 내원구분코드
                    OutRegInfo.FRVS_RVST_DVCD = cboFrvsRvstDvcd.SelectedValue;   // 초진재진구분코드
                    OutRegInfo.DY_WARD_YN = cboDyWardYn.SelectedValue;       // 낮병동여부

                    // 2020-06-01 SJH 변경될 일이 없어짐
                    //OutRegInfo.ECOI_CD = cboEcoiCd.SelectedValue;         // 상해외인코드
                    //OutRegInfo.EMRM_MMCD_CD     = cboEmrmMmcdCd.SelectedValue;     // 응급실주과
                    //if (!OutRegInfo.UpdateRegistInfoChangeAtRec(ref msg))
                    //    return -1;

                    // TODO :  보훈병원 지정시 저장
                }
                else
                {
                    // 미수내역을 메시지로 보여준다.
                    if (clsPACommon.ShowMessage_UnclAmt(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), this))
                    {
                        OnPatientClear();
                        return 1;
                    }

                    unclamt = 0;
                    //현내원정보의 미수존재 여부확인
                    if (!clsPACommon.GetUnclAmtNow(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO, "*", ref unclamt, ref msg))
                        return -1;

                    if (unclamt > 0)
                    {
                        LxMessage.Show("현 내원정보에 미수금이 존재합니다. \rn\n 미수금액은 " + string.Format("{0:#,##0}", unclamt) + " 원 입니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    // TODO : 환불처리정보확인(외래입원확인)
                    // TODO : 외래보관금 존재여부확인
                    // TODO : 금연보험대상자확인

                    m_Compare_ASST_TYCD = OutRegInfo.ASST_TYCD;
                    m_Compare_CFSC_RGNO_CD = OutRegInfo.CFSC_RGNO_CD;

                    if ((OutRegInfo.INSN_TYCD == "11" || OutRegInfo.INSN_TYCD == "21" || OutRegInfo.INSN_TYCD == "22") && OutRegInfo.ASST_TYCD != "99" && OutRegInfo.ASST_TYCD != "D9"
                                                                                                                        && OutRegInfo.ASST_TYCD != "91" && OutRegInfo.ASST_TYCD != "P9" && OutRegInfo.ASST_TYCD != "9C")
                    {
                        string ecoicd = string.Empty;

                        if (!SqlPack.Procedure.PR_PA_PRC_ASSTTYCDSET(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO, OutRegInfo.RRNO, OutRegInfo.PT_NM, OutRegInfo.MDCR_DD, ref assttycd, ref cfscrgnocd, ref ecoicd, ref tbrcdvcd, ref iovmsg))
                        {
                            msg = " 보조유형, 산정특례 적용중 에러 발생 : " + iovmsg;
                            return -1;
                        }

                        if (StringService.IsNotNull(iovmsg))
                        {
                            msg = "[PR_PA_PRC_ASSTTYCDSET] " + iovmsg;
                            return -1;
                        }

                        // 2019-08-06 SJH 외래보조유형 세팅이력 history를 쌓자.
                        if (!clsPACommon.InsertPAOPASRT(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), OutRegInfo.RCPN_SQNO.ToString(),
                                                            assttycd, cfscrgnocd, ecoicd, tbrcdvcd, ref iovmsg))
                        {
                            msg = iovmsg;
                            return -1;
                        }

                        //if (chkReBurn.Checked)
                        //{
                        //    assttycd = OutRegInfo.ASST_TYCD;
                        //    cfscrgnocd = "NO";
                        //}

                        //chkReBurn.Checked를 뺄예정
                        if (chkReBurn.Checked || lblForceChange.Visible)
                        {
                            assttycd = OutRegInfo.ASST_TYCD;
                            cfscrgnocd = "NO";
                        }

                        //청구된 내역이면 진행못하게 한다.
                        // 청구생성확인 = "Y" AND 청구생성에 상관없이 수정작업가능자가 아닌경우

                        //if (ConfigService.GetConfigValueString("%", "CLAM_CRTN_CFRM_YN", "CLAM_CRTN_CFRM_YN") == "Y" &&
                        //    ConfigService.GetConfigValueString("%", "NO_CLAM_CRTN_USER", "NO_CLAM_CRTN_USER") != DOPack.UserInfo.USER_CD)
                        //{
                        //    if (DBService.ExecuteScalar(SqlPack.Function.SelectFN_CL_PRC_CHKCLAMCRTN(), OutRegInfo.PID
                        //                                                                            , OutRegInfo.PT_CMHS_NO.ToString()
                        //                                                                            , iovmsg).ToString() == "Y")
                        //    {
                        //        LxMessage.Show(" 해당 환자는 청구심사 중이거나 이미 청구가 완료되어 수정이 불가합니다. \r\n" +
                        //                       " 보험 심사과에 문의하세요 !", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //        m_EnableSave = false;
                        //    }
                        //}

                        // 보조유형변경반영
                        if ((!string.IsNullOrWhiteSpace(assttycd) && OutRegInfo.ASST_TYCD != assttycd) ||
                            (!string.IsNullOrWhiteSpace(cfscrgnocd) && OutRegInfo.CFSC_RGNO_CD != cfscrgnocd) ||
                            (!string.IsNullOrWhiteSpace(tbrcdvcd) && OutRegInfo.TBRC_DVCD != tbrcdvcd))
                        {
                            if (OutRegInfo.INSN_TYCD == "21")
                            {
                                if (assttycd == "D0" || OutRegInfo.ASST_TYCD == "D0")
                                {
                                    cboAsstTycd.SelectValue(assttycd);
                                    OutRegInfo.ASST_TYCD = assttycd;
                                }
                                //임플란트
                                else if (assttycd == "P0" || OutRegInfo.ASST_TYCD == "P0")
                                {
                                    cboAsstTycd.SelectValue(assttycd);
                                    OutRegInfo.ASST_TYCD = assttycd;
                                }
                                else if (assttycd == "V0" || OutRegInfo.ASST_TYCD == "V0")
                                {
                                    cboAsstTycd.SelectValue(assttycd);
                                    OutRegInfo.ASST_TYCD = assttycd;
                                }
                                else if (assttycd == "V1" || OutRegInfo.ASST_TYCD == "V1")
                                {
                                    cboAsstTycd.SelectValue(assttycd);
                                    OutRegInfo.ASST_TYCD = assttycd;
                                }
                                cboAsstTycd.SelectValue(assttycd);
                                //cboTbrcDvcd.SelectValue(tbrcdvcd);
                                txtTbrcDvcd.Text = tbrcdvcd;

                                OutRegInfo.ASST_TYCD = assttycd;
                                OutRegInfo.TBRC_DVCD = tbrcdvcd;
                            }
                            else
                            {
                                cboAsstTycd.SelectValue(assttycd);
                                //cboTbrcDvcd.SelectValue(tbrcdvcd);
                                txtTbrcDvcd.Text = tbrcdvcd;

                                OutRegInfo.ASST_TYCD = assttycd;
                                OutRegInfo.TBRC_DVCD = tbrcdvcd;
                            }

                            if (!(cfscrgnocd.Length < 4 || string.IsNullOrEmpty(cfscrgnocd) || cfscrgnocd == "NO"))
                            {
                                txtCfscRgnoCd.Text = cfscrgnocd;
                                OutRegInfo.CFSC_RGNO_CD = cfscrgnocd;
                            }
                            /*
                            if (ecoicd == "F" && OutRegInfo.ECOI_CD != ecoicd)
                            {
                                //상해외인
                                OutRegInfo.ECOI_CD = "F";
                                cboEcoiCd.SelectValue(OutRegInfo.ECOI_CD);
                            }
                            */
                            //결핵
                            if (OutRegInfo.INSN_TYCD == "11" && (OutRegInfo.CFSC_RGNO_CD == "V206" || OutRegInfo.CFSC_RGNO_CD == "V246" || OutRegInfo.CFSC_RGNO_CD == "V231"))
                            {
                                //cboTbrcDvcd.SelectValue(OutRegInfo.CFSC_RGNO_CD);
                                //cboTbrcDvcd.SelectValue("Y/" + OutRegInfo.CFSC_RGNO_CD);
                                txtTbrcDvcd.Text = "Y/" + OutRegInfo.CFSC_RGNO_CD;
                            }

                            if (OutRegInfo.INSN_TYCD == "22" && OutRegInfo.ASST_TYCD == "J0")
                            {
                                cboUschAplyCd.SelectValue("B010");
                                OutRegInfo.USCH_APLY_CD = "B010";
                            }

                        } // 보조유형변경반영
                    }
                    else if (OutRegInfo.INSN_TYCD == "21" && OutRegInfo.ASST_TYCD != "99")
                    {
                        txtCfscRgnoCd.Text = "NO";
                        OutRegInfo.CFSC_RGNO_CD = "NO";
                    }
                    else if (OutRegInfo.INSN_TYCD == "11" && (OutRegInfo.ASST_TYCD == "99" || OutRegInfo.ASST_TYCD == "D9" || OutRegInfo.ASST_TYCD == "P9"))
                    {
                        if (OutRegInfo.ASST_TYCD.Equals("D9"))              // 보훈일반틀니이면 본인100%로 변경한다.
                        {
                            OutRegInfo.ASST_TYCD = "99";
                            cboAsstTycd.SelectValue(OutRegInfo.ASST_TYCD);
                        }
                        else if (OutRegInfo.ASST_TYCD.Equals("P9"))         // 보훈일반임플란트이면 본인100%로 변경한다.
                        {
                            OutRegInfo.ASST_TYCD = "99";
                            cboAsstTycd.SelectValue(OutRegInfo.ASST_TYCD);
                        }
                        // TODO : 보훈이면
                    }
                }
                /*************************** 내역변경 확인 end ************************/

                // TODO : 주상병 비급여이고 부/의증 상병이 급여인 경우 수납제한을 건다.
                //if (CheckNoPayILns(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), OutRegInfo.INSN_TYCD, "02", ref msg) == 100) // 2018-04-30 YOON 보조유형을 체크해야함..
                if (CheckNoPayILns(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), OutRegInfo.ASST_TYCD, "02", ref msg) == 100)
                {
                    LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //OnPatientSelected("INSNCHANGE", OutRegInfo.PID);
                    //return 1;
                }

                //무자격자 건강보험100%
                if (OutRegInfo.INSN_TYCD == "11" && OutRegInfo.ASST_TYCD != "99" && OutRegInfo.PAY_QLFC_DVCD == "01")
                {
                    LxMessage.Show("무자격자입니다. 건강보험100%로 내역변경하시기 바랍니다!!", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //OnPatientSelected("INSNCHANGE", OutRegInfo.PID);
                    //return 1;
                }

                //급여제한자 보험100% 안되게
                if (OutRegInfo.INSN_TYCD == "11" && OutRegInfo.ASST_TYCD == "99" && OutRegInfo.PAY_QLFC_DVCD == "02")
                {
                    LxMessage.ShowInformation("급여제한자입니다. 확인해 주세요.");
                    //OnPatientSelected("INSNCHANGE", OutRegInfo.PID);
                    //return 1;
                }

                //타과 급여제한자 접수내역이 있으면 알림메시지
                if (OutRegInfo.INSN_TYCD == "11" && OutRegInfo.PAY_QLFC_DVCD != "02")
                {
                    if (DBService.ExecuteInteger(SQL.PA.Sql.SelectOtherDeptPayLmdt(), OutRegInfo.PID
                                                                                   , OutRegInfo.PT_CMHS_NO.ToString()
                                                                                   , OutRegInfo.MDCR_DD) > 0)
                    {
                        LxMessage.Show("급여제한이 타과 접수 정보에 있습니다. 자격조회후 수납하세요.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

                // 처방을 가져와서 처방내역에 표시한다.
                // 방문할 곳을 표시한다.
                OnPatientSelected("PRSC", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO);

                if (m_QtyZeroYn.Equals("Y"))
                {
                    LxMessage.Show("투여량이 0 인 처방이 있습니다. 진료부서에 문의하세요.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    EnableSave = false;

                }

                //잠복결핵감염대상자
                if (m_TbrcSuptTrgtYn.Equals("Y") && OutRegInfo.INSN_TYCD != "31" && OutRegInfo.INSN_TYCD != "41")
                {
                    if (OutRegInfo.INSN_TYCD == "11" && (OutRegInfo.ASST_TYCD.Substring(0, 1) == "E" || OutRegInfo.ASST_TYCD.Substring(0, 1) == "F") && OutRegInfo.DRG_DVCD != "Y")
                        msg = "";
                    else if ((OutRegInfo.INSN_TYCD == "11" || OutRegInfo.INSN_TYCD == "21" || OutRegInfo.INSN_TYCD == "22") && OutRegInfo.ASST_TYCD != "99")
                    {
                        msg = "";
                        return -1;
                    }

                    tbrcdvcd = "F009";

                }

                //HPV 지원대상자 
                if (m_HpvSameIlnsYn == "Y" && OutRegInfo.DRG_DVCD != "Y" && (((OutRegInfo.INSN_TYCD.Substring(0, 1) == "1" || OutRegInfo.INSN_TYCD.Substring(0, 1) == "2") && OutRegInfo.ASST_TYCD != "99") || OutRegInfo.VTRN_PT_YN == "Y"))
                {

                    if (DBService.ExecuteInteger(SQL.PA.Sql.SelectSpecIlnsCount(), OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), OutRegInfo.MDCR_DD) <= 0)
                    {
                        LxMessage.Show("HPC치료대상이지만, 해당 주상병이 존재하지 않습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        EnableSave = false;
                    }
                    if (OutRegInfo.FRVS_RVST_DVCD == "3")
                    {
                        LxMessage.Show("HPC치료비지원 대상자는 초진진찰료만 산정 가능합니다. 반드시 초진재진구분을 변경하세요.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        EnableSave = false;
                    }
                    LxMessage.Show("HPV예방접종지원 대상자입니다. \r\n 급여본인부담금(보험100%, 비급여는 제외) 모두 지원금에서 처리됩니다. \r\n 단 HPV예방접종비는 보건소(질병관리본부)에서 지원됩니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    tbrcdvcd = "F102";
                }
                else
                {
                    if (m_HpvSameIlnsYn == "Y" && ((OutRegInfo.INSN_TYCD.Substring(0, 1) == "1" || OutRegInfo.INSN_TYCD.Substring(0, 1) == "2") && OutRegInfo.ASST_TYCD == "99"))
                    {
                        LxMessage.Show("HPV예방접종지원은 일반수납 불가 합니다! 무자격자는 보건소로 안내", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

                /*
                if (m_HpvSameIlnsYn == "Y" && (((OutRegInfo.INSN_TYCD.Substring(0, 1) == "1" || OutRegInfo.INSN_TYCD.Substring(0, 1) == "2") && OutRegInfo.ASST_TYCD != "99") || OutRegInfo.VTRN_PT_YN == "Y"))
                {
                    LxMessage.Show("HPV예방접종지원 동일과 타상병 대상자입니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ecoicd = "R";
                }
                else
                {
                    if (StringService.CodeFindFromString("R", OutRegInfo.ECOI_CD))
                        ecoicd = "*";
                }

                if (!OutRegInfo.ECOI_CD.Equals(StringService.IsNvl(ecoicd, "*")))
                {
                    OutRegInfo.ECOI_CD = ecoicd;
                    //
                }
                */

                if (!OutRegInfo.TBRC_DVCD.Equals(tbrcdvcd))
                {
                    //cboTbrcDvcd.SelectValue(tbrcdvcd);
                    txtTbrcDvcd.Text = tbrcdvcd;
                    OutRegInfo.TBRC_DVCD = tbrcdvcd;
                }

                // OutRegInfo.CFSC_RGNO_CD
                string cfsc_rgno_cd = OutRegInfo.CFSC_RGNO_CD;

                // F010 조건 
                // 건강보험 + 보조유형이 차상위, 없음이 아니고
                // DRG / 보훈이 아니고
                // 산정특례기호가 F010이 아닌 경우

                // 2021.07.01 산정특례로 V010이 추가되어 이후는 필요 없음.
                if (!string.IsNullOrWhiteSpace(OutRegInfo.MDCR_DD) && DateTimeService.ConvertDateTime(OutRegInfo.MDCR_DD) < DateTimeService.ConvertDateTime("20210701"))
                {
                    if (OutRegInfo.INSN_TYCD.Equals("11") &&
                        OutRegInfo.ASST_TYCD.Length > 0 && !OutRegInfo.ASST_TYCD.Equals("99") && !OutRegInfo.ASST_TYCD.Substring(0, 1).Equals("E") && !OutRegInfo.ASST_TYCD.Substring(0, 1).Equals("F") &&
                        !OutRegInfo.OTPT_DRG_YN.Equals("Y") && !OutRegInfo.VTRN_PT_YN.Equals("Y") &&
                        !OutRegInfo.CFSC_RGNO_CD.Equals("F010") && OutRegInfo.TBRC_DVCD == "*")
                    {
                        // F010에 해당되는 상병이 있는지 확인한다.
                        string sqltext = string.Format(@"
    SELECT *
      FROM ORDISRRT
     WHERE PID = '{0}'
       AND PT_CMHS_NO = {1}
       AND DEL_YN = 'A'
       AND ILNS_CD IN ( SELECT ILNS_CD
                          FROM BISPDCDT
                         WHERE ILNS_DVCD = '35'
                           AND APLY_STRT_DD <= MDCR_DD
                           AND APLY_END_DD  >= MDCR_DD ) ", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString());

                        DataTable tempDT = new DataTable();
                        DBService.ExecuteDataTable(sqltext, ref tempDT);
                        if (tempDT.Rows.Count > 0)
                        {
                            cfsc_rgno_cd = OutRegInfo.CFSC_RGNO_CD + "/Y/F010";
                            txtTbrcDvcd.Text = "Y/F010";
                            OutRegInfo.TBRC_DVCD = "Y/F010";
                        }
                        else
                        {
                            // F010에 해당되는 상병이 없는 경우,
                            // 잠복결핵 지시형 오더(INSEX62)가 존재하는지 확인한다.
                            sqltext = string.Format(@"
    SELECT *
      FROM ORORDRRT 
     WHERE PID = '{0}'
       AND PT_CMHS_NO = {1}
       AND DEL_YN = 'A'
       AND DC_PRSC_DVCD = 'A'
       AND PRSC_CD = 'INSEX62' ", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString());

                            tempDT.Reset();
                            DBService.ExecuteDataTable(sqltext, ref tempDT);
                            if (tempDT.Rows.Count > 0)
                            {
                                cfsc_rgno_cd = OutRegInfo.CFSC_RGNO_CD + "/Y/F010";
                                txtTbrcDvcd.Text = "Y/F010";
                                OutRegInfo.TBRC_DVCD = "Y/F010";
                            }
                        }
                    }
                }

                //TODO : IRG대상자, 수혈처방확인
                //TODO : 선택진료확인
                //TODO : 노숙인 응급보험

                //처방이 모두 D/C난 경우 산정구분 처리안함으로 함.
                if (OutRegInfo.MCCH_CMPT_DVCD != "N" && m_AllDcPrscDvcd == "D")
                {
                    if (LxMessage.Show("처방이 모두 D/C되었습니다.\r\n 산정안함으로 변경하시겠습니까?", "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        OutRegInfo.MCCH_CMPT_DVCD = "N";
                        cboMcchCmptDvcd.SelectValue("N");
                        nonmcchcmpt = true;
                        //OnPatientSelected("SAVEYN", "RECALC"); // 진료비재계산
                    }
                }

                if (OutRegInfo.MCCH_CMPT_DVCD != "N")
                {
                    if (DBService.ExecuteInteger(SQL.PA.Sql.SelectSameInsnSameDept(), OutRegInfo.PID
                                                                                   , OutRegInfo.PT_CMHS_NO.ToString()
                                                                                   , OutRegInfo.MDCR_DD
                                                                                   , OutRegInfo.MDCR_DEPT_CD
                                                                                   , OutRegInfo.INSN_TYCD
                                                                                   , OutRegInfo.ASST_TYCD
                                                                                   , "1") > 0)
                    {
                        if (LxMessage.Show("동일진료과 접수내역이 있습니다.\r\n 산정안함으로 변경하시겠습니까?", "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            OutRegInfo.MCCH_CMPT_DVCD = "N";
                            cboMcchCmptDvcd.SelectValue("N");
                            nonmcchcmpt = true;
                        }
                    }
                }

                // 예약내역을 조회한다.
                OnPatientSelected("APP", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO, OutRegInfo.MDCR_DD);

                // 접수내역을 조회한다.
                OnPatientSelected("REG", OutRegInfo.PID);

                // ++++++++++++++++++++++++++++++++++++++++++++++++++
                // 미수 내역을 확인한다.
                // ++++++++++++++++++++++++++++++++++++++++++++++++++
                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectUnclDpstAmt(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString()), ref dt))
                    throw new Exception("미수 내역을 조회하는 중 에러가 발생했습니다.");

                // 개인미수 외에 입금된 내역이 있는 경우
                bool has_clam_dpst_amt = dt.AsEnumerable().Where(r => (!r["UNCL_OCRR_DVCD"].ToString().Equals("*") && decimal.Parse(r["DPST_AMT"].ToString()) > 0)).Any();

                if (dt.Rows.Count > 0)
                {
                    if (has_clam_dpst_amt)
                    {
                        // 청구미수 등 입금내역이 있는 경우는 재수납 불가.
                        EnableSave = false;
                    }
                    else
                    {
                        string message = string.Empty;
                        message += "미수입금정보가 존재하므로 다음과 같은 작업 후\r\n재수납하세요.\r\n\r\n";
                        message += "예       : 미수입금을 취소 후 수납\r\n";
                        message += "아니오 : 미수입금 외래수납금으로 전환\r\n";
                        message += "취소    : 금액 조회";

                        DialogResult dialog = LxMessage.Show(message, "확인", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

                        if (dialog == DialogResult.Yes)
                        {
                            // 미수입금 팝업을 띄운다.
                            OnPatientSelected("SAVEYN", "RECALC");

                            clsPACommon.ShowForm_UnclAmt(OutRegInfo.PID, dt.Rows[0]["UNCL_OCRR_DVCD"].ToString(), this);
                            return -1;
                        }
                        else if (dialog == DialogResult.No)
                        {
                            // 미수입금된 내역의 paobilbd 들을 만든다.
                            OnPatientSelected("CHANGEUNCOMABILBD", OutRegInfo.PID);
                        }
                        else
                        {
                            // 수납 불가.
                            EnableSave = false;
                        }
                    }
                }

                // TODO : 공단 의료급여 승인서버 가동여부 확인

                // 다른유저가 사용중인지 확인한다. (LOCK 확인)

                bool editMode = true;

                if (IsLockedSystem(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), "PA"))
                {
                    SystemLockInfo lockinfo = this.SystemLockService.SelectSystemLock(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), "PA");

                    if (!string.IsNullOrWhiteSpace(lockinfo.LOCK_USER_CD) &&
                        (!lockinfo.LOCK_USER_CD.Equals(DOPack.UserInfo.USER_CD) || !lockinfo.LOCK_IP.Equals(ClientEnvironment.IP)))
                    {
                        editMode = false;

                        string message = string.Empty;
                        message += $"이미 다른 유저가 사용중이므로, 조회모드로 들어갑니다.\r\n";
                        message += $"\r\n 사용중인 유저 정보";
                        message += $"\r\n    {lockinfo.LOCK_DEPT_NM} / {lockinfo.LOCK_USER_NM} ({lockinfo.LOCK_USER_CD})";
                        message += $"\r\n    {DateTimeService.ConvertDateTime(lockinfo.LOCK_DT).ToString("yyyy-MM-dd HH:mm")} / {lockinfo.LOCK_IP}";

                        if (DBService.ExecuteScalar("SELECT CONF_VAL FROM ADCONFDT T WHERE SYSTEM_CD = 'PA' AND CONF_TYPE = 'RECEIPT' AND CONF_CD = 'LOCK_QUESTION' ").ToString().Equals("Y"))
                        {
                            message += $"\r\n\r\nLock을 해제하고 수납가능 모드로 들어가시겠습니까?";
                            if (LxMessage.ShowQuestion(message).Equals(DialogResult.Yes))
                                editMode = true;
                        }
                        else
                        {
                            LxMessage.ShowError(message);
                        }
                    }
                }

                // lock 을 건다
                if (editMode)
                    this.LockSystem(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString());

                SystemLocked?.Invoke(!editMode);

                /**************************** Transaction Start ***************************/

                DBService.BeginTransaction();

                if (m_ChangeFlag == "F")
                {
                    // TODO : 접수정보 백업 생성
                    // 내역정보변경있으면 변경내역저장
                    if (!OutRegInfo.UpdateRegistInfoChangeAtRec(ref msg))
                        return -1;

                    // TODO :  보훈병원 지정시 저장
                }

                // 진찰료 산정안함으로 변경되어 있으면 외래접수를 변경한다.
                if (nonmcchcmpt)
                {
                    string errordvcd = String.Empty;
                    string errorcnts = String.Empty;

                    if (!SqlPack.Procedure.PR_PA_PRC_PAOPATRTCH(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), OutRegInfo.RCPN_SQNO.ToString(), "MCCH_CMPT_DVCD", "N", DOPack.UserInfo.USER_CD, ref errordvcd, ref errorcnts))
                    {
                        throw new Exception(string.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));
                    }

                    if (StringService.IsNotNull(errordvcd))
                    {
                        throw new Exception("오류 내용[PR_PA_PRC_PAOPATRTCH] : [" + errordvcd + "]" + errorcnts);
                    }
                }

                if (!OutRegInfo.RRNO.Length.Equals(13))
                {
                    msg = string.Format("[PR_PA_COM_MEDICOSTMAIN] 주민번호가 13자리가 아닙니다. ({0}) : ", OutRegInfo.RRNO) + DBService.ErrorMessage;
                    DBService.RollbackTransaction();
                    return -1;
                }

                // 진료비계산 로직
                // 정산시작일자를 건생비잔액으로 사용한다. (인적정보 주민번호를 넘겨야 함!!!)
                if (!SqlPack.Procedure.PR_PA_COM_MEDICOSTMAIN(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), OutRegInfo.FRRN, OutRegInfo.SRRN, "O"
                                                            , OutRegInfo.RCPN_SQNO.ToString(), OutRegInfo.MDCR_DD, OutRegInfo.FRVS_RVST_DVCD, OutRegInfo.INSN_TYCD, OutRegInfo.ASST_TYCD
                                                            , cfsc_rgno_cd, OutRegInfo.MDCR_DD, this.m_FrvsRvstDvcdSave ? "Y" : "N", OutRegInfo.MDCR_DD, ""
                                                            , "", cfhcRem, "", ref iovmsg))
                {
                    msg = "[PR_PA_COM_MEDICOSTMAIN] 진료비 계산 처리 중 오류 발생[DB] : " + DBService.ErrorMessage;
                    DBService.RollbackTransaction();
                    return -1;
                }

                string a = this.m_FrvsRvstDvcdSave ? "Y" : "N";

                lblMediParams.Tag = $@"
    [PR_PA_COM_MEDICOSTMAIN]
    IV_PID                = {OutRegInfo.PID}
    IN_PT_CMHS_NO         = {OutRegInfo.PT_CMHS_NO}
    IV_FRRN               = {OutRegInfo.FRRN}
    IV_SRRN               = {OutRegInfo.SRRN}
    IV_OTPT_ADMS_DVCD     = O

    IN_RCPN_SQNO          = {OutRegInfo.RCPN_SQNO}
    IV_MDCR_DD            = {OutRegInfo.MDCR_DD}
    IV_MAIN_SUB_ADMS_DVCD = {OutRegInfo.FRVS_RVST_DVCD}
    IV_INSN_TYCD          = {OutRegInfo.INSN_TYCD}
    IV_ASST_TYCD          = {OutRegInfo.ASST_TYCD}
    IV_CFSC_RGNO_CD       = {cfsc_rgno_cd}

    IV_ADMS_DD            = {OutRegInfo.MDCR_DD}
    IV_ADMS_TIME          = {a}
    IV_DSCH_DD            = {OutRegInfo.MDCR_DD}
    IV_DSCH_TIME          = 
    IV_CLSN_DVCD          = 
    IV_CMPY_STRT_DD       = {cfhcRem}
    IV_CMPY_END_DD        =  ";

                if (StringService.IsNotNull(iovmsg))
                {
                    msg = "[PR_PA_COM_MEDICOSTMAIN] 진료비 계산 처리 중 오류 발생[MSG] : " + iovmsg;
                    DBService.RollbackTransaction();
                    return -1;
                }

                // TODO : 약국 스크린 등록

                DBService.CommitTransaction();

                /**************************** Transaction End ***************************/
                // 처방갯수확인
                OutRegInfo.PRSC_COUNT = DBService.ExecuteInteger(SQL.PA.Sql.SelectPrscCountToCompare(), OutRegInfo.PID
                                                                                                      , OutRegInfo.PT_CMHS_NO.ToString()
                                                                                                      , OutRegInfo.MDCR_DD);
                // 영수증갯수확인

                OutRegInfo.BILL_COUNT = DBService.ExecuteInteger(SQL.PA.Sql.SelectBillCountToCompare(), OutRegInfo.PID
                                                                                                    , OutRegInfo.PT_CMHS_NO.ToString());
                //수납처방
                OnPatientSelected("RECPRSC", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO);
                //수익별집계
                OnPatientSelected("PROFIT", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO);
                //영수내역
                OnPatientSelected("BILLHIS", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO);
                //영수정보
                OnPatientSelected("BILL", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO);
                //특이사항
                OnPatientSelected("REMARK", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO);
                //상병
                OnPatientSelected("ILLNESS", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO, OutRegInfo.MDCR_DD);

                // DRG환자확인
                string drgno = String.Empty;
                string insntycddrg = String.Empty;
                string assttycddrg = String.Empty;

                if (OutRegInfo.OTPT_DRG_YN.Equals("Y") && (m_TotlMdcrAmt > 0 || m_AllDcPrscDvcd.Equals("A")))
                {
                    drgno = DBService.ExecuteScalar(SqlPack.Function.FN_PA_READ_DRGCREATEYN(), "O"
                                                                                             , OutRegInfo.PID
                                                                                             , OutRegInfo.PT_CMHS_NO.ToString()
                                                                                             , "0"
                                                                                             , "3").ToString();
                    if (!drgno.Equals("Y"))
                    {
                        LxMessage.Show("DRG 적용환자입니다. \r\n DRG 질병분류번호 산정중입니다." +
                                       "해당부서(보험심사과)에서 분류번호 적용(심사완료)후에 수납하시기 바랍니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        EnableSave = false;
                    }
                    insntycddrg = OutRegInfo.INSN_TYCD;
                    assttycddrg = assttycd;

                    DataTable dtinsn = new DataTable();
                    if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectDrgInsnTycdOfCLIINIF(), ref dtinsn, OutRegInfo.PID
                                                                                                      , OutRegInfo.PT_CMHS_NO.ToString()))
                    {
                        if (dtinsn.Rows.Count > 0)
                        {
                            DataRow row = dtinsn.Rows[0];
                            insntycddrg = row["INSN_TYCD"].ToString();
                            assttycddrg = row["ASST_TYCD"].ToString();
                        }
                    }

                    if (!OutRegInfo.INSN_TYCD.Equals(StringService.IsNvl(insntycddrg, OutRegInfo.INSN_TYCD)) || assttycd.Equals(StringService.IsNvl(assttycddrg, assttycd)))
                    {
                        LxMessage.Show("DRG 적용 보험과 현재 계산 보험이 다릅니다.\r\n" +
                                       "해당부서(보험심사과)에 문의하시기 바랍니다.\r\n" +
                                       "DRG적용보험 : " + insntycddrg + "/" + assttycddrg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        EnableSave = false;
                    }

                    if (m_DrgMefeYn.Equals("Y"))
                    {
                        LxMessage.Show("DRG 적용환자이지만 DRG정액수가가 제대로 산정되지 않았습니다..\r\n" +
                                       "재조회후 다시 처리하시기 바랍니다.\r\n" +
                                       "계속 동일한 알림메시지가 뜨면 전산실에 연락하시기 바랍니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        EnableSave = false;
                    }
                }
                // TODO :  응급환자KTAS 등급 분류
                // TODO :  초음파 급여 가능 여부 확인.
                // TODO :  직계할인 예방접종수가의 경우 본인및가족이외는 입력불가.

                //인공신장은 진찰료 산정안함으로 처리불가. 정액진료비가 발생 안됨.
                if (OutRegInfo.INSN_TYCD.Substring(0, 1) == "2" && OutRegInfo.ASST_TYCD != "99" && OutRegInfo.INSN_CLAM_DEPT_CD == "98" && OutRegInfo.MCCH_CMPT_DVCD == "N")
                {
                    LxMessage.Show("의료급여 정액진료비 대상자는 진찰료 산정안함으로 해야 합니다. \r\n 진찰료 미산정시 정액진료비(진찰료) 산정이 안됩니다.",
                                   "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    EnableSave = false;
                }

                // 의료급여 동일 진료과 접수내역이 존재하는지 확인한다.
                if (OutRegInfo.INSN_TYCD.Substring(0, 1) == "2" && OutRegInfo.ASST_TYCD != "99")
                {
                    if (DBService.ExecuteInteger(SQL.PA.Sql.SelectSameInsnSameDept(), OutRegInfo.PID
                                                                                      , OutRegInfo.PT_CMHS_NO.ToString()
                                                                                      , OutRegInfo.MDCR_DD
                                                                                      , OutRegInfo.MDCR_DEPT_CD
                                                                                      , OutRegInfo.INSN_TYCD
                                                                                      , OutRegInfo.ASST_TYCD
                                                                                      , "2") > 0)
                    {
                        LxMessage.Show("의료급여 동일진료과 접수내역이 있습니다.\r\n 동일 진료과로 이중 수납이 불가합니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

                if (!EnableSave)
                {
                    OnPatientSelected("SAVEYN", OutRegInfo.PID);
                }

                // 당일 이전 미수납 처방을 확인한다.
                string norcptmdcrdd = DBService.ExecuteScalar(SQL.PA.Sql.SelectNoReceipt(), OutRegInfo.PID
                                                                                          , OutRegInfo.MDCR_DD).ToString();

                if (string.IsNullOrWhiteSpace(norcptmdcrdd) && DateTimeService.IsDateTime(norcptmdcrdd))
                {
                    LxMessage.Show(clsPACommon.ConvertDateFormat(2, norcptmdcrdd) + " 에 미수납된 접수내역이 존재합니다. 확인하시기 바랍니다.",
                                   "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                // TODO :  중증대상자(산정특례)대상자인경우 특정처방이 존재는지 확인한다.

                // 당일퇴원환자인지를 확인한다.
                if (DBService.ExecuteInteger(SQL.PA.Sql.SelectPAIPATRT_DSCH_YN(), OutRegInfo.PID
                                                                            , OutRegInfo.MDCR_DD) > 0)
                {
                    LxMessage.Show("내원 당일 퇴원예정이거나 퇴원환자입니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                // 재원중인 환자인지를 확인한다.
                if (DBService.ExecuteInteger(SQL.PA.Sql.SelectPAIPATRT_MAIN_ADMS_DVCD_J(OutRegInfo.PID)) > 0)
                {
                    LxMessage.Show("재원중인 환자입니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                // 낮병동 확인
                if (OutRegInfo.DY_WARD_YN.Equals("Y"))
                {
                    if (OutRegInfo.INSN_CLAM_DEPT_CD == "24")
                    {
                        LxMessage.Show("응급환자 진료구역관찰료 계산 대상환자입니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        LxMessage.Show("낮병동 계산 대상환자입니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

                if (OutRegInfo.ECOI_CD.Equals("E") && OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("2") && !OutRegInfo.ASST_TYCD.Equals("99"))
                {
                    LxMessage.Show("NP타병원의뢰 대상환자이므로 입원본인부담율로 계산됩니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                // TODO :  응급의학과 경증질환 청구방법 확인한다.

                // TODO :  노인틀니/임플란트 보험적용 확인한다.

                // TODO :  보훈정보를 확인한다.

                // 그룹처방의 경우 세부처방이 존재하는지 확인한다.
                string groupprscnm = DBService.ExecuteScalar(SQL.PA.Sql.SelectDetailPrscOfGroupPrsc(), OutRegInfo.PID
                                                                                                     , OutRegInfo.PT_CMHS_NO.ToString()).ToString();

                if (StringService.IsNotNull(groupprscnm))
                {
                    LxMessage.Show("그룹수가 [" + groupprscnm + "] 의 세부수가가 없는 그룹수가가 존재합니다. 보험심사과나 전산실에 문의하세요.",
                                   "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }


                if (DBService.ExecuteInteger(SQL.PA.Sql.SelectDrgOrder(), OutRegInfo.PID
                                                                        , OutRegInfo.PT_CMHS_NO.ToString()
                                                                        , OutRegInfo.MDCR_DD) > 0)
                {
                    LxMessage.Show("당일 DRG시술코드가 발생한 환자입니다. 타과 접수 및 수납이 안되도록 주의하시기 바랍니다.",
                                   "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                // 결핵이나 특정기호에 'F010'이 있으면 잠복결핵 감염 치료비지원 대상자 메시지를 띄워준다.
                if (OutRegInfo.TBRC_DVCD.Contains("F010") || OutRegInfo.CFSC_RGNO_CD.Contains("F010") || 
                    (OutRegInfo.TBRC_DVCD.Contains("V010") || OutRegInfo.CFSC_RGNO_CD.Contains("V010")))
                {
                    LxMessage.ShowInformation("잠복결핵 감염 치료비지원 대상자입니다.\r\n급여본인부담금 모두 결핵접촉지원금액으로 처리됩니다.\r\n(보험100%,비급여는 제외)");
                }

                // TODO :  의료급여 응급실 내원시 진료의뢰서 지참 알림

                if (OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("2") && OutRegInfo.USCH_APLY_CD.Equals("B009"))
                {
                    switch (OutRegInfo.CFSC_RGNO_CD)
                    {
                        case "V252":
                        case "V352":
                        case "V100":
                            LxMessage.ShowInformation(string.Format("{0}[B009] 의뢰서 확인이 필요합니다.", OutRegInfo.CFSC_RGNO_CD));
                            break;
                    }
                }

                if (OutRegInfo.INSN_TYCD.Equals("11") && (OutRegInfo.ASST_TYCD.Equals("00") || OutRegInfo.ASST_TYCD.Equals("L0")) && !OutRegInfo.CFSC_RGNO_CD.Contains("F003") && !OutRegInfo.DY_WARD_YN.Equals("Y"))
                {
                    string sqltext = string.Format(@"
               SELECT 1
                 FROM ORORDRRT Z,
                      BIMFCDMA Y,
                      BIEXCDMA B
                WHERE Z.PRSC_CD        = Y.MEFE_CD
                  AND Y.APLY_STRT_DD  <= '{2}'
                  AND Y.APLY_END_DD   >= '{2}'
                  AND B.APLY_STRT_DD  <= '{2}'
                  AND B.APLY_END_DD   >= '{2}'
                  AND Z.PID            = '{0}'
                  AND Z.PT_CMHS_NO     =  {1}
                  AND Z.EXCP_RESN_CD   = B.EXCP_RESN_CD
                  AND Z.DEL_YN         = 'A'
                  AND Z.DC_PRSC_DVCD   = 'A'
                  AND B.USCH_APLY_YN   = 'Y'
                  AND Z.PRSC_LCLS_CD   = '30'
                  AND Z.PNPY_DVCD      = '1'
                  AND Y.HLNS_CLUS_DVCD = '03' ", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), OutRegInfo.MDCR_DD);

                    DataTable dtF003 = new DataTable();
                    if (!DBService.ExecuteDataTable(sqltext, ref dtF003))
                        throw new Exception(string.Format("F003적용 여부 조회 중 에러가 발생했습니다.\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));

                    if (dtF003.Rows.Count > 0)
                        LxMessage.ShowInformation("F003 적용 대상자 입니다.\r\n재조회하거나 내역변경에서 수동으로 F003을 입력해 주세요.\r\n(수동으로 입력할 경우 [보조유형 강제적용]에 체크해 주세요.)");
                }

                // 이벤트의 마지막인걸 알려준다.
                OnPatientSelected("END", OutRegInfo.PID);

                return 1;
            }
            catch (Exception ex)
            {
                if (DBService.IsTransaction)
                    DBService.RollbackTransaction();

                LxMessage.Show(ex.Message, "외래수납 계산 중 오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
            return 1;
        }

        public void SetPatientRegInfo()
        {
            txtPid.Text = OutRegInfo.PID;
            txtPtNm.Text = OutRegInfo.PT_NM;
            txtFrrn.Text = OutRegInfo.FRRN;
            txtSrrn.Text = OutRegInfo.SRRN;
            txtRrno.Text = OutRegInfo.FRRN + "-" + OutRegInfo.SRRN;
            txtSexDvcd.Text = OutRegInfo.SEX_DVCD;
            txtAge.Text = OutRegInfo.AGE.ToString();
            mskMdcrDd.Text = OutRegInfo.MDCR_DD;
            mskMdcrTime.Text = OutRegInfo.MDCR_TIME;
            cboInsnTycd.SelectValue(OutRegInfo.INSN_TYCD);              //보험유형
            cboAsstTycd.SelectValue(OutRegInfo.ASST_TYCD);              //보조유형
            cboMdcrDeptCd.SelectValue(OutRegInfo.MDCR_DEPT_CD);         //진료부서

            //응급실주과
            cboEmrmMmcdCd.SelectValue(OutRegInfo.EMRM_MMCD_CD);
            m_EMRM_MMCD_CD_bk = OutRegInfo.EMRM_MMCD_CD;
            if (OutRegInfo.MDCR_DEPT_CD.Equals("2400"))
            {
                cboEmrmMmcdCd.ReadOnly = false;
            }
            else
            {
                cboEmrmMmcdCd.ReadOnly = true;
                lblEmrmMmcdCd.ResetAppearance();
            }

            cboMdcrDrCd.SelectValue(OutRegInfo.MDCR_DR_CD);             //진료의사
            cboRealMdcrDrCd.SelectValue(OutRegInfo.REAL_MDCR_DR_CD);    //실진료의
            cboFrvsRvstDvcd.SelectValue(OutRegInfo.FRVS_RVST_DVCD);     //초재진구분코드
            cboMcchCmptDvcd.SelectValue(OutRegInfo.MCCH_CMPT_DVCD);     //진찰료산정구분코드
            cboCmhsDvcd.SelectValue(OutRegInfo.CMHS_DVCD);              //내원구분코드
            cboExcpResnCd.SelectValue(OutRegInfo.EXCP_RESN_CD);         //예외사유코드
            cboUschAplyCd.SelectValue(OutRegInfo.USCH_APLY_CD);         //본인부담코드
            txtCfscRgnoCd.Text = OutRegInfo.CFSC_RGNO_CD;               //산정특례기호코드
            cboDyWardYn.SelectValue(OutRegInfo.DY_WARD_YN);             //낮병동
            cboSmcrYn.SelectValue(OutRegInfo.SMCR_YN);                  //선택진료여부
            cboDYNT_DVCD_DRG.SelectValue(OutRegInfo.ETC_USE_CNTS_1);    //주야구분
            // TODO :
            //진료확인번호
            //건강생활유지비잔액
            //이전건강생활유지비잔액
            //이전건강생활유지비청구
            //산모여부
            //cboTbrcDvcd.SelectValue(OutRegInfo.TBRC_DVCD);  //결핵구분코드
            txtTbrcDvcd.Text = OutRegInfo.TBRC_DVCD;
            cboEcoiCd.SelectedValue = string.IsNullOrWhiteSpace(OutRegInfo.ECOI_CD) ? "*" : OutRegInfo.ECOI_CD;      //상해외인코드
            txtClphTel.Text = OutRegInfo.CLPH_TEL;

            // 임부 표시
            lblPregnant.Visible = DBService.ExecuteScalar(SQL.Function.FN_NR_READ_NRPAPRMA(), OutRegInfo.PID).ToString().Equals("Y");

            // 재난지원(코로나19) 환자인지 표시
            lblDisasterSupt.Visible = false;
            string etc21 = DBService.ExecuteScalar(SQL.PA.Sql.SelectPATRTEIF_ETC21(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString())).ToString();
            
            if (etc21.Contains("CVD"))
            {
                lblDisasterSupt.Visible = true;
                lblDisasterSupt.Text = etc21.Equals("CVD_SCR") ? "★재난지원 (코로나 재택)" : etc21.Equals("CVD_OPT") ? "★재난지원 (코로나 외래)" : "★재난지원 (코로나)";
            }

            // 요양병원 입원여부
            lblMDCAREHSPTHSPTZYN.Visible = Lime.BusinessControls.clsPACommon.SelectMDCAREHSPTHSPTZYN(false, OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString());

            // 과취소 표시
            lblPtMdcrStatDvcd9.Visible = OutRegInfo.PT_MDCR_STAT_DVCD.Equals("9");

            // 산재지정의
            lblIncsDr.Visible = clsCommon.Is_INCS_DR_YN(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), OutRegInfo.INSN_TYCD, OutRegInfo.ASST_TYCD, OutRegInfo.MDCR_DD, OutRegInfo.MDCR_DR_CD);
        }

        public int CheckRowStatDvcdOfPatient(ref string msg)
        {
            string rowstatdvcd = String.Empty;
            rowstatdvcd = DBService.ExecuteScalar(SQL.PA.Sql.SelectRowStatDvcd(), OutRegInfo.PID
                                                                                , OutRegInfo.PT_CMHS_NO.ToString()
                                                                                , OutRegInfo.MDCR_DD).ToString();

            if (rowstatdvcd.Equals("I"))
            {
                msg = "이미 입원등록이 되었습니다.확인하세요.";
                return 2;
            }
            else if (!rowstatdvcd.Equals("A"))
            {
                msg = "접수취소 또는 진료부서가 변경되었습니다. 확인하세요.";
                return 3;
            }

            return 1;
        }

        #region Method : SelectData Method

        /// <summary>
        /// 자보 산재 유효성 체크
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        private bool CheckTraiIncsValid(string insntycd, ref string msg)
        {
            string traircpnno = "";
            string aplystrtdd = "";
            string aplyenddd = "";
            try
            {
                DataTable dt = new DataTable();
                if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectTraiRcpnNo(), ref dt, OutRegInfo.PID
                                                                                   , OutRegInfo.ASCT_RGNO_CD
                                                                                   , OutRegInfo.TAIC_PT_UNIQ_NO
                                                                                   , insntycd))
                {
                    if (dt.Rows.Count > 0)
                    {
                        DataRow row = dt.Rows[0];

                        traircpnno = row["TRAI_RCPN_NO"].ToString();
                        aplystrtdd = row["APLY_STRT_DD"].ToString();
                        aplyenddd = row["APLY_END_DD"].ToString();

                        string insntynm = insntycd.Equals("31") ? "산재보험" : "자동차보험";

                        if (DateTimeService.ConvertDateTime(OutRegInfo.MDCR_DD) < DateTimeService.ConvertDateTime(aplystrtdd) || DateTimeService.ConvertDateTime(OutRegInfo.MDCR_DD) > DateTimeService.ConvertDateTime(aplyenddd))
                        {
                            msg = "진료일자가 " + insntynm + " 적용일자와 맞지 않습니다. \r\n 보험 적용 기간은 " + DateTimeService.ConvertDateStringToFormatString(aplystrtdd) + " 에서 " + DateTimeService.ConvertDateStringToFormatString(aplyenddd) + " 입니다.";
                            return false;
                        }

                        if (insntycd == "41" && traircpnno == "NO")
                        {
                            LxMessage.Show(insntynm + " 접수번호가 등록되지 않았습니다. \r\n  " + insntynm + " 100%로 내역변경 처리하세요!",
                                           "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            OnPatientSelected("INSNCHANGE", OutRegInfo.PID);
                            return false;
                        }

                        return true;
                    }
                    else
                    {
                        msg = " 자동차보험(또는 산재보험) 정보가 존재하지 않습니다.";
                        return false;
                    }

                }
                msg = "오류내용 : [" + DBService.ErrorCode + "] " + DBService.ErrorMessage;
                return false;
            }
            catch (Exception ex)
            {
                msg = "[ CheckTraiIncsValid ] 오류내용 : " + ex.Message;
                return false;
            }
        }

        /// <summary>
        /// 당일 동일보험유형으로 접수한 양한방 내역을 체크한다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        private bool CheckWestMediAndOrieMedi(ref string msg)
        {
            int cnt = 0;
            string westorientflag = String.Empty;
            int insnclamdeptcd = 0;
            int.TryParse(OutRegInfo.INSN_CLAM_DEPT_CD, out insnclamdeptcd);

            if (insnclamdeptcd >= 80 && insnclamdeptcd <= 89)
                westorientflag = "O";                           //한방
            else
                westorientflag = "W";                           //양방

            cnt = DBService.ExecuteInteger(SQL.PA.Sql.SelectWestMediAndOrieMedi(), OutRegInfo.PID
                                                                                 , OutRegInfo.PT_CMHS_NO.ToString()
                                                                                 , OutRegInfo.MDCR_DD
                                                                                 , OutRegInfo.INSN_TYCD
                                                                                 , westorientflag);
            if (cnt < 0)
            {
                msg = DBService.ErrorMessage;
                return false;
            }

            if (cnt > 0)
            {
                if (westorientflag == "O")
                    msg = " 당일 동일보험유형으로 접수한 [양방] 정보가 존재합니다!!";
                else
                    msg = " 당일 동일보험유형으로 접수한 [한방] 정보가 존재합니다!!";


                return false;
            }
            return true;
        }

        #endregion  Method : SelectData Method

        #region Method : SaveData Method

        /// <summary>
        /// 외래접수의 예외사유코드 UPDATE
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public int UpdateExcpResnCdOfPaOpaRt(ref string msg)
        {
            if (OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("2") && !OutRegInfo.ASST_TYCD.Equals("99") && OutRegInfo.INSN_CLAM_DEPT_CD.Equals("03") && !OutRegInfo.EXCP_RESN_CD.Equals("13"))
            {
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateExcpResnCdOfPaOpatRt(), OutRegInfo.PID
                                                                                      , OutRegInfo.PT_CMHS_NO.ToString()))
                {
                    msg = DBService.ErrorMessage;
                    return -1;
                }
            }
            return 1;
        }
        /// <summary>
        /// 외래접수의  정액정율구분코드 UPDATE
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public void UpdateFxamFxrtDvcdOfPaOpatRt(int fxammccs)
        {
            // 일단 정률코드
            OutRegInfo.FXAM_FXRT_DVCD = "9";

            // 상해외인코드가 [E]가 아닌 경우만 정액코드
            if (OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("2") && !OutRegInfo.ASST_TYCD.Equals("99") && fxammccs > 0 && !OutRegInfo.ECOI_CD.Equals("E"))
                OutRegInfo.FXAM_FXRT_DVCD = "0";

            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateFxamFxrtDvcdOfPaOpatRt(), OutRegInfo.PID
                                                                                    , OutRegInfo.PT_CMHS_NO.ToString()
                                                                                    , OutRegInfo.FXAM_FXRT_DVCD))
                throw new Exception("정액정률구분을 저장하는 중 에러가 발생했습니다.");
        }
        /// <summary>
        /// 외래접수의 수납회수 UPDATE
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public int UpdateRcptNotmOfPaOpaRt(ref string msg)
        {
            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateRcptNotmOfPaOpatRt()
                                         , OutRegInfo.PID
                                         , OutRegInfo.PT_CMHS_NO.ToString()
                                         , "Y"))
            {
                msg = DBService.ErrorMessage + " : 외래접수등록의 수납횟수 변경 중 에러 발생.";
                return -1;
            }
            return 1;
        }

        #endregion Method : SaveData Method

        #endregion

        #region Method : Private Method
        private void ClearControlData()
        {
            //this.FindChildControls(this.Controls);
            ClearControl(this.Controls);
        }

        private void ClearControl(Control.ControlCollection controls)
        {
            foreach (Control ctl in controls)
            {
                if (ctl.HasChildren)
                {
                    this.ClearChildControl(ctl);
                    this.ClearControl(ctl.Controls);
                }
                else
                {
                    this.ClearChildControl(ctl);
                }

            }

            txtTbrcDvcd.Text = string.Empty;
            lblMDCAREHSPTHSPTZYN.Visible = false;
        }

        private void ClearChildControl(Control controls)
        {
            if (controls is LxTextBox)
            {
                ((LxTextBox)controls).Text = String.Empty;
            }
            else if (controls is LxComboBox)
            {
                LxComboBox cboBox = controls as LxComboBox;

                cboBox.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
                cboBox.Clear();
            }
            else if (controls is LxMaskedEdit)
            {
                ((LxMaskedEdit)controls).Text = String.Empty;
            }
            else if (controls is LxDateTimeEditor)
            {
                ((LxDateTimeEditor)controls).DateTime = DateTimeService.ConvertDateTime(m_Mdcr_Dd);
            }
            else if (controls is LxTitleLabel)
            {
                LxTitleLabel lblLabel = controls as LxTitleLabel;

                string lbl = lblLabel.Text;

                if (lblLabel.Tag == "C")
                {
                    lblLabel.Appearance.ForeColor = Color.Blue;
                    lblLabel.Appearance.FontData.Bold = Infragistics.Win.DefaultableBoolean.True;
                }
            }
        }

        private bool SelectIsNonCompletion(string pid, ref string msg)
        {
            try
            {
                int cfhcdmdamt = 0; // 건강생활비청구액
                int pregdmndamt = 0; // 산전지원비청구액
                DataTable dt = new DataTable();
                if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectNonCompletionOfPANHM3MA(), ref dt, pid))
                {
                    if (dt.Rows.Count > 0)
                    {
                        DataRow row = dt.Rows[0];
                        int.TryParse(row["CFHCDMDAMT"].ToString(), out cfhcdmdamt);
                        int.TryParse(row["PREGDMNDAMT"].ToString(), out pregdmndamt);
                        if (!StringService.IsNvl(row["DIAGDT"].ToString(), "29991231").Equals("29991231") && (cfhcdmdamt + pregdmndamt) > 0)
                        {
                            msg = "진료확인번호 승인건이 아래와 같이 존재합니다. \r\n" +
                                  " 진료일자 : " + row["DIAGDT"].ToString() + "\r\n" +
                                  " 진료과목 : " + row["DIAGITEM"].ToString() + "\r\n" +
                                  " 건강생활비청구액 : " + string.Format("{0:#,##0}", cfhcdmdamt) + "원 \r\n" +
                                  " 산전지원비청구액 : " + string.Format("{0:#,##0}", pregdmndamt) + "원 \r\n" +
                                  " ------------------------------------------------------------------\r\n" +
                                  " 잠시 후 처리하거나, 자격조회 서버의 실행여부를 확인하세요.";
                            throw new Exception(msg);
                        }
                    }
                }
                else
                {
                    throw new Exception(string.Format("오류내용 : [{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));
                }
                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }

        }


        /// <summary>
        /// 이전 건강생활유지비잔액/청구액을 가져온다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <returns></returns>
        private bool SelectBeforeHealthLifeAmt(string pid, int ptcmhsno)
        {
            bool result = true;
            try
            {
                int hllfmncsblce = 0;      // 건강생활유지비잔액
                int hllfmncsclamamt = 0;    // 건강생활유지비청구액
                DataTable dt = new DataTable();
                if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectBeforeHealthLifeAmt(), ref dt, pid
                                                                                            , ptcmhsno.ToString()))
                {
                    if (dt.Rows.Count > 0)
                    {
                        DataRow row = dt.Rows[0];
                        int.TryParse(row["HLLF_MNCS_CLAM_AMT"].ToString(), out hllfmncsclamamt);
                        int.TryParse(row["HLLF_MNCS_BLCE"].ToString(), out hllfmncsblce);
                        txtHllfMncsClamAmt.Text = string.Format("{0:#,##0}", hllfmncsclamamt);
                        txtOldHllfMncsBlce.Text = string.Format("{0:#,##0}", hllfmncsblce);
                        result = true; ;
                    }
                }
                else
                {
                    throw new Exception(string.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                result = false;
            }

            return result;

        }

        /// <summary>
        /// 자보 본인일부부담율을 가져와서 접수정보에 적용한다.
        /// </summary>
        /// <param name="pid"></param>
        /// <returns></returns>
        private bool CheckTraiUsprShrt(string traiptuniqno, ref int reftraiusprshrt, ref string msg)
        {
            try
            {
                string traiusprshrt = String.Empty;

                traiusprshrt = DBService.ExecuteScalar(SQL.PA.Sql.SelectTraiUsprShrt(), traiptuniqno).ToString();
                if (DBService.HasError)
                    throw new Exception(string.Format(" [SelectTraiUsprShrt] {0} {1}", DBService.DBError, DBService.ErrorMessage));

                if (DBService.AffectedRows < 1) traiusprshrt = "0";


                if (!traiusprshrt.Equals("0"))
                {
                    msg = "자동차보험 일부본인부담 [ " + traiusprshrt + "% ] 적용대상자입니다. \r\n 자세한 내용은 자보담당자에게 문의하세요.";
                }
                int.TryParse(StringService.IsNvl(traiusprshrt, "0"), out reftraiusprshrt);
                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                msg = " [CheckTraiUsprShrt] 오류 내용 : " + ex.Message;

                return false;
            }

        }

        /// <summary>
        /// 주상병이 비급여고 부/의증 상병이 급여인 경우
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="insntycd"></param>
        /// <param name="dvcd"> 진료/수납여부</param>
        /// <param name="msg"></param>
        /// <returns></returns>
        //private int CheckNoPayILns(string pid, string ptcmhsno, string insntycd, string dvcd, ref string msg)  // 2018-04-30 YOON 보조유형을 체크해야함..
        private int CheckNoPayILns(string pid, string ptcmhsno, string assttyecd, string dvcd, ref string msg)
        {
            try
            {
                int maincnt = 0;
                int subcnt = 0;
                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectNoPayIlns(), ref dt, pid
                                                                                  , ptcmhsno))
                {
                    throw new Exception(string.Format("[SelectNoPayIlns] {0} {1}", DBService.ErrorCode, DBService.ErrorMessage));
                }
                if (dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];

                    int.TryParse(row["MAIN_ILNS_CNT"].ToString(), out maincnt); // 주상병 비급여 count
                    int.TryParse(row["SUB_ILNS_CNT"].ToString(), out subcnt);   // 부/의증 급여 count

                    if (maincnt >= 1 && subcnt >= 1)
                    {
                        //if (!insntycd.Equals("99"))
                        if (!assttyecd.Equals("99"))
                        {
                            msg = "주상병이 비급여 상병입니다. \r\n" +
                                  "환자의 보조유형을 보험100%로 변경하여 주시기 바랍니다.!";
                            return 100;
                        }
                    }
                }
                return 1;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                msg = "오류내용 : " + ex.Message;
                return -1;
            }
        }

        #region 자격조회호출

        private bool ShowQualificationInfo(string newpatientyn, string pid, string mdcrdd, string ptnm, string rrno, string insntycd, ref string msg)
        {
            try
            {
                string mothernm = String.Empty;
                string motherrrno = String.Empty;
                string inpnrrno = String.Empty;

                if (StringService.IsNull(ptnm) || StringService.IsNull(rrno))
                {
                    throw new Exception("환자성명 또는 주민등록번호가 누락되었습니다.");
                }
                //신생아인경우 엄마정보로 자격조회를 한다.
                if (!Lime.BusinessControls.clsPACommon.ReturnMotherInfo(pid, ref mothernm, ref motherrrno, mdcrdd))
                {
                    throw new Exception("엄마정보를 가져오는 중에 오류를 발생했습니다.");
                }

                if (StringService.IsNotNull(mothernm) && StringService.IsNotNull(motherrrno))
                {
                    ptnm = mothernm;
                    rrno = motherrrno;
                }


                // 시설환자의 경우 보험정보의 주민번호를 가져온다.
                if (!clsPACommon.GetInpnRrno(pid, insntycd, mdcrdd, ref inpnrrno, ref msg))
                {
                    throw new Exception(msg);
                }

                if (StringService.IsNotNull(inpnrrno) && !inpnrrno.Equals("NO"))
                {
                    rrno = inpnrrno;
                }

                ShowNhisMessage(newpatientyn, pid, mdcrdd, ptnm, rrno, ref msg);

                return true;
            }
            catch (Exception ex)
            {
                msg = "자격조회 중 오류를 발생했습니다.\r\n " +
                               "Method :  [QualificationInfo] \r\n " +
                               "오류 메시지 : " + ex.Message;
                return false;
            }
        }

        private void ShowNhisMessage(string newpatient, string pid, string mdcrdd, string ptnm, string rrno, ref string msg)
        {
            try
            {
                if (newpatient.Equals("N"))
                {
                    DOPack.PatientInfo.Load(pid);
                }

                clsNhisM1 m1 = new clsNhisM1();

                if (!m1.SendM1(mdcrdd, false, ptnm, rrno))
                {
                    msg = "자격조회 중 오류가 발생했습니다.\r\n다시 조회해 주세요.";
                    return;
                }

                PopNhicResponse2(m_M2, m1.Uniqno.ToString());
            }
            catch (Exception ex)
            {
                msg = "자격 조회중 오류를 발생하였습니다.\r\n 오류메시지 : " + ex.Message;
                return;
            }
        }

        private void m1_OnGetMessage2(clsNhisM2 m2)
        {

            try
            {
                frmNhicResponse2P pop = new frmNhicResponse2P();
                pop.SetM2Data(m2);
                pop.StartPosition = FormStartPosition.CenterParent;
                pop.ShowDialog();
                pop.DisposeEvent();
                pop.Dispose();
            }
            catch (Exception ex)
            {
                LxMessage.Show("자격 조회중 오류를 발생하였습니다.\r\n 오류메시지 : " + ex.Message, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PopNhicResponse2(clsNhisM2 m2, string uniqno)
        {
            try
            {
                using (frmNhicResponse2P pop = new frmNhicResponse2P(uniqno))
                {
                    pop.StartPosition = FormStartPosition.CenterParent;
                    pop.BaseMDI = this.BaseMDI;
                    pop.ShowDialog(this);

                    if (pop.DialogResult == DialogResult.OK)
                    {
                        this.m_NhisErrorYn = pop.m_ErrorYn;
                        if (!pop.m_ErrorYn.Equals("Y"))
                        {
                            this.m_M2 = pop.M2;
                        }
                    }

                    pop.DisposeEvent();
                }
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError("자격조회 중 에러가 발생했습니다.\r\n" + ex.Message + error);
            }
        }

        #endregion 자격조회호출

        /// <summary>
        /// 환자번호 입력 시 / EditorButtonClick 시 동작.
        /// </summary>
        /// <param name="date">일자</param>
        private void PopUpPatRegList(string date)
        {
            string convertpid = String.Empty;
            try
            {
                #region [ 환자번호 NULL 여부에 따른 환자번호 세팅 로직 ]
                // 환자등록번호 완성
                convertpid = DBService.ExecuteScalar(SqlPack.Function.FN_PA_PRC_CONVERTPID(), txtPid.Text.Trim()).ToString();

                if (StringService.IsNotNull(convertpid))
                {

                    DataTable dt = new DataTable();
                    DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAPATHIN_PID(), ref dt, convertpid);

                    if (dt.Rows.Count == 1)
                    {
                        DataRow row = dt.Rows[0];
                        convertpid = row["PID"].ToString();
                    }
                    else if (dt.Rows.Count > 1)
                    { // 환자이름 입력시 동명이인이 존재한는 경우 환자 검색창을 띄운다.
                        popSearchPatient pop = new popSearchPatient("PT_NM", convertpid);
                        pop.BaseMDI = this.BaseMDI;
                        pop.ShowDialog(this);
                        if (pop.DialogResult.Equals(DialogResult.OK))
                        {
                            convertpid = pop.Pid;
                            pop.Dispose();
                        }
                        else
                        {
                            pop.Dispose();
                            return;
                        }
                    }
                    else
                    {
                        LxMessage.Show("입력하신 환자번호 또는 환자명에 해당하는 환자가 존재하지 않습니다.\r\n환자번호 또는 환자명을 확인해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        return;
                    }
                    txtPid.Text = convertpid;
                }

                if (StringService.IsNull(convertpid))
                {
                    LxMessage.Show("환자번호 또는 환자명을 입력해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                #endregion [ 환자번호 NULL 여부에 따른 환자번호 세팅 로직 ]

                // LOCK 해제
                if (StringService.IsNotNull(OutRegInfo.PID))
                {
                    this.UnLockSystem(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString());
                }

                string msg = String.Empty;

                if (!clsPACommon.CheckCreditPermit("O", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString()))
                {
                    msg = "신용카드/현금 승인된 자료가 존재합니다.\r\n" +
                          "수납 또는 승인취소를 진행하지 않으면,\r\n마감시 금액이 맞지 않습니다.\r\n\r\n" +
                          "환자를 조회하시겠습니까?";

                    if (LxMessage.Show(msg, "환자조회여부", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
                        return;
                }

                frmOutInsnTypeChangeP popTypeChange = new frmOutInsnTypeChangeP(convertpid, 0, true);
                popTypeChange.BaseMDI = this.BaseMDI;
                popTypeChange.ShowDialog(this);

                if (popTypeChange.DialogResult == DialogResult.OK)
                {
                    Clear();

                    OutRegInfo.Load("PT_CMHS_NO", popTypeChange.Pid, popTypeChange.PtCmhsNo, popTypeChange.MdcrDd);

                    if (OutRegInfo.ETC_USE_CNTS_5 != null && OutRegInfo.ETC_USE_CNTS_5 == "강제변경:재수상")
                    {
                        chkReBurn.Checked = true;
                        lblForceChange.Visible = true;
                    }
                    else
                    {
                        chkReBurn.Checked = false;
                        lblForceChange.Visible = false;
                    }

                    if (!clsPACommon.CheckNotAply_CttrUnclAplyAmt(popTypeChange.Pid, popTypeChange.PtCmhsNo.ToString(), popTypeChange.MdcrDd, popTypeChange.MdcrDd))
                    {
                        // TODO : SJH 2019-05-07 일단 코멘트아웃해놓자.
                        //LxMessage.ShowInformation("협력지원금 temp데이터 수정 중 에러가 발생했습니다.\r\n관리자에게 연락 바랍니다.");
                        //return;
                    }

                    if (CheckPatientRegistInfo(ref msg) < 0)
                    {
                        if (DBService.IsTransaction)
                            DBService.RollbackTransaction();
                        if (StringService.IsNotNull(msg))
                        {
                            LxMessage.Show(msg, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        //return;
                    }

                    SetPatientRegInfo();

                    if (popTypeChange.MdcrDd.Equals(DateTimeService.NowDateNoneSeperatorString()))
                        OnPatientSelected("PT_CMHS_NO", popTypeChange.Pid);

                    // TODO SJH
                    OnPatientSelected("SHOW_PREVIEW_RECEIPT", popTypeChange.Pid);

                    txtPid.Focus();
                }

                popTypeChange.Dispose();
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        #endregion Method : Private Method

        #region Event : Event Process

        private void OntxtPid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                /* 수정 */

                // 환자 접수 내역을 Open하고 해당 접수정보를 선택하고 수납작업을 진행한다.
                PopUpPatRegList(m_Mdcr_Dd);


                /** 기존 **/
                // 기존 당일 접수 정보 조회
                //DisplayPatientInfo();
            }
        }

        private void OnCombo_ValueChanged(object sender, EventArgs e)
        {
            LxComboBox cbo = (LxComboBox)sender;

            switch (cbo.Name)
            {
                case "cboInsnTycd":
                    if (cbo.Value != null)
                        clsPACommon.SetComboPA(cboAsstTycd, "ASST_TYCD", "LWRN_OVRL_CDNM", cbo.Value.ToString().Trim(), OutRegInfo.MDCR_DD);

                    break;
                case "cboFrvsRvstDvcd":
                case "cboMcchCmptDvcd":
                case "cboDyWardYn":
                    //case "cboEcoiCd":
                    OnPatientSelected("SAVEYN", "RECALC"); // 진료비재계산
                    break;
                case "cboCmhsDvcd":     // 외래접수와 같은 로직이나, 여기선 수정할 수 있는 항목이 정해져 있어서, 그거 외에는 값이 변경되면 안된다.
                    if (cboCmhsDvcd.Value == null)
                        return;

                    OutRegInfo.CMHS_DVCD = cboCmhsDvcd.Value.ToString();

                    switch (OutRegInfo.CMHS_DVCD)
                    {
                        // 내원구분:환자가족처방 => 산정구분:보호자 내원 처방전 수령
                        case "5":
                            OutRegInfo.MCCH_CMPT_DVCD = "O";
                            cboMcchCmptDvcd.SelectValue("O");
                            break;

                        case "3": // 종검
                        case "9": // 영유아검진
                        case "T": // 일반검진
                        case "E": // 특수검진
                            OutRegInfo.MCCH_CMPT_DVCD = "N";
                            cboMcchCmptDvcd.SelectValue("N");
                            break;

                        case "4": // 진단서발행
                        case "S": // 예방접종
                        case "10": // 레이저
                            OutRegInfo.MCCH_CMPT_DVCD = "N";
                            cboMcchCmptDvcd.SelectValue("N");
                            break;

                        case "11": // (산재) 수수료 청구
                            OutRegInfo.MCCH_CMPT_DVCD = "N";
                            cboMcchCmptDvcd.SelectValue("N");
                            break;

                        case "7": //물리치료/주사이면, 산정구분 '병원관리료 재진 50%' 설정
                            OutRegInfo.MCCH_CMPT_DVCD = "P";
                            cboMcchCmptDvcd.SelectValue("P");
                            break;
                        default: // 그외
                            OutRegInfo.MCCH_CMPT_DVCD = "Y";
                            cboMcchCmptDvcd.SelectValue("Y");
                            break;
                    }

                    OnPatientSelected("SAVEYN", "RECALC"); // 진료비재계산
                    break;

                case "cboEmrmMmcdCd":
                    OutRegInfo.EMRM_MMCD_CD = cboEmrmMmcdCd.SelectedValue;     // 응급실주과
                    break;
            }
        }

        private void btnNhic_Click(object sender, EventArgs e)
        {
            try
            {
                string msg = String.Empty;

                // 자격조회를 한다.
                // M1 을 생성한다. M2 를 받는다.
                if (!ShowQualificationInfo("N", OutRegInfo.PID, OutRegInfo.MDCR_DD, this.OutRegInfo.PT_NM, this.OutRegInfo.RRNO, OutRegInfo.INSN_TYCD, ref msg))
                {
                    DBService.RollbackTransaction();
                    LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (m_NhisErrorYn.Equals("Y"))
                    LxMessage.Show("자격조회 장애중");

                if (OutRegInfo.INSN_TYCD.Substring(0, 1) == "2")
                {
                    if (this.m_NhisErrorYn.Equals("Y"))
                    {
                        LxMessage.Show("자격조회 시스템 장애 중입니다.! \r\n 보조유형을 보험100%으로 우선 처리하시기 바랍니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        txtAsctRgnoCd.Text = this.m_M2.protAdminSym;    // 조합기호코드

                        // 건강생활유지비잔액
                        decimal.TryParse(this.m_M2.cfhcRem, out decimal cfhc_rem);
                        txtHllfMncsBlce.Text = string.Format("{0:#,##0}", cfhc_rem);
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

        }

        /// <summary>
        /// 
        /// 환자검색창 PopUp -> 환자 내원 내역 조회로 변경
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtPid_EditorButtonClick(object sender, Infragistics.Win.UltraWinEditors.EditorButtonEventArgs e)
        {
            PopUpPatRegList(m_Mdcr_Dd);
        }

        #endregion Event : Event Process

        #region Event : Raise Event

        public void OnPatientSelected(string condition, string pid)
        {
            this.PatientSelected?.Invoke(this, new SelectDataEventArgs(condition, pid));
        }

        public void OnPatientSelected(string condition, string pid, int ptcmhsno)
        {
            this.PatientSelected?.Invoke(this, new SelectDataEventArgs(condition, pid, ptcmhsno));
        }

        public void OnPatientSelected(string condition, string pid, int ptcmhsno, string mdcrdd)
        {
            this.PatientSelected?.Invoke(this, new SelectDataEventArgs(condition, pid, ptcmhsno, mdcrdd));
        }

        #endregion Event : Raise Event

        #region Event : EventArgs
        public class SelectDataEventArgs : EventArgs
        {
            private string m_Condition = String.Empty;
            private string m_Pid = String.Empty;
            private int m_PtCmhsNo = 0;
            private string m_MdcrDd = String.Empty;

            public string Condition
            {
                get { return m_Condition; }
                set { m_Condition = value; }
            }

            public string Pid
            {
                get { return m_Pid; }
                set { m_Pid = value; }
            }

            public int PtCmhsNo
            {
                get { return m_PtCmhsNo; }
                set { m_PtCmhsNo = value; }
            }


            public string MdcrDd
            {
                get { return m_MdcrDd; }
                set { m_MdcrDd = value; }
            }


            public SelectDataEventArgs(string condition, string pid)
            {
                this.m_Condition = condition;
                this.m_Pid = pid;
            }
            public SelectDataEventArgs(string condition, string pid, int ptcmhsno)
            {
                this.m_Condition = condition;
                this.m_Pid = pid;
                this.m_PtCmhsNo = ptcmhsno;
            }
            public SelectDataEventArgs(string condition, string pid, int ptcmhsno, string mdcrdd)
            {
                this.m_Condition = condition;
                this.m_Pid = pid;
                this.m_PtCmhsNo = ptcmhsno;
                this.m_MdcrDd = mdcrdd;
            }
        }
        #endregion Event : EventArgs

    }
}
