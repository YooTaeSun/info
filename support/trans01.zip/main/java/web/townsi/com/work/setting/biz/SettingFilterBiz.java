package web.townsi.com.work.setting.biz;

import java.util.HashMap;

public interface SettingFilterBiz {
	public abstract HashMap<String, Object> makeFilter(HashMap paramHashMap) throws Exception;
}