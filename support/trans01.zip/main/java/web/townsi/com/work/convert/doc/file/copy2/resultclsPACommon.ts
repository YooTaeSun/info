
import { DateTime } from "@/app/framework/CommonService/DateTime";
import { DataTable } from "@/app/framework/DataType/DataTable";
import { Int } from "@/app/utils/Int";
import { DOPack } from "@/app/framework/DataObject/DOPack";
import { DBService } from "@/app/framework/DBService/DBService";
import { ConfigService } from "@/app/framework/ConfigService/ConfigService";
import { StringService } from "@/app/framework/CommonService/StringService";
import { DateTimeService } from "@/app/framework/CommonService/DateTimeService";
import { LogService } from "@/app/framework/CommonService/LogService";
import { clsPACommon } from "@/modules/n_pa/views/CommonClass/clsPACommon";
import LxMessage from "@/app/framework/Controls/LxMessage.vue";
import { Convert } from "@/app/app/utils/Convert.vue";
import { MessageBoxButtons } from "@/app/utils/MessageBoxButtons";
import { MessageBoxIcon } from "@/app/utils/MessageBoxIcon";
import { COMBO_ADD_ITEM_TYPE } from "@/app/framework/DataType/PublicEnum";
import "@/app/utils/number.extensions";
import { DOPatientInfo } from "@/app/framework/DataObject/DOPatientInfo";
import { ScreenParameters } from "@/app/framework/BaseForms/TypeClass/SreenParameters";
import { DoctorList } from "@/app/framework/DataService/DoctorList";

{
    class clsPACommon
    {
        public static clsNhisM2 m_M2 = null;

        private static m_NonPermitDt:DataTable = new DataTable();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cbo"></param>
        /// <param name="ovrl_cd"></param>
        /// <param name="ovrl_nm"></param>
        /// <param name="cboValue"></param>
        /// <param name="mdcr_dd"></param>
        public static SetComboPA(LxComboBox cbo, ovrl_cd:string, ovrl_nm:string, cboValue:string, mdcr_dd:string)
        {
            let defaultvalue:string = String.Empty;

            if (cboValue == "")
                cbo.Clear();
            else
                cbo.SetComboItems(GetDtCbo(ovrl_cd, cboValue, mdcr_dd, defaultvalue), ovrl_cd, ovrl_nm, COMBO_ADD_ITEM_TYPE.None, defaultvalue);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="cbo"></param>
        /// <param name="ovrl_cd"></param>
        /// <param name="ovrl_nm"></param>
        /// <param name="cboValue"></param>
        /// <param name="mdcr_dd"></param>
        public static SetComboPA(LxComboBox cbo, ovrl_cd:string, ovrl_nm:string, cbovalue:string, mdcr_dd:string, defaultselectvalue:string)
        {
            if (String.IsNullOrWhiteSpace(cbovalue))
                cbo.Clear();
            else
                cbo.SetComboItems(GetDtCbo(ovrl_cd, cbovalue, StringService.IsNvl(mdcr_dd, DateTimeService.NowDateNoneSeperatorString())), ovrl_cd, ovrl_nm, COMBO_ADD_ITEM_TYPE.None, defaultselectvalue);
        }

        /// <summary>
        /// 각종 구분코드, 코드에 따른 data를 DataTable에담기
        /// </summary>
        /// <param name="ovrl_cd" 구분코드></param>
        /// <param name="mdcr_dd" 기준일자></param>
        /// <returns></returns>
        public static GetDtCbo(ovrl_cd:string, cboValue:string, mdcr_dd:string)
        {
            let dt:DataTable = new DataTable();
            try
            {
                switch (ovrl_cd)
                {
                    case "DEPT_CD":
                        if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectBIDEPTMA_CLSF_CD(true), dt, cboValue
                                                                                                   , mdcr_dd
                                                                                                   , "Y"))
                            return dt;
                        break;
                    case "ROOM_CD":
                        if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectBIROOMMA_ROOM_CD(), dt, cboValue
                                                                                                   , "%"
                                                                                                   , mdcr_dd))
                            return dt;
                        break;
                    case "USER_CD":
                        if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectBIUSERDT_DEPT_CD(), dt, cboValue
                                                                                                  , mdcr_dd))
                            return dt;
                        break;
                    case "EXCP_RESN_CD":
                        if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectBIEXCDMA_RESN_CD(), dt, mdcr_dd))
                            return dt;
                        break;
                    case "CFSC_CD":
                        if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectBISCCDMA_CFSC_CD(), dt, mdcr_dd))
                            return dt;
                        break;
                    case "DCNT_CD":
                        if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectBIDCCDMA_DCNT_CD(), dt, mdcr_dd))
                            return dt;
                        break;
                    case "ASST_TYCD":
                        if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectBITPCLMA(), dt, cboValue
                                                                                          , mdcr_dd))
                            return dt;
                        break;
                    case "CMPT_CD":
                        if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectCmptCdExpl(), dt, mdcr_dd))
                            return dt;
                        break;
                    default:
                        if (DBService.ExecuteDataTable(SQL.BI.Sql.SelectBICDINDT(), dt, ovrl_cd
                                                                                              , "Y"
                                                                                              , mdcr_dd))
                            return dt;
                        break;
                }
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
            }
            return dt;
        }
        static DataTable GetDtCbo(string ovrl_cd, string cboValue, string mdcr_dd, string defaultvalue)
        {

            let dt:DataTable = new DataTable();

            try
            {
                switch (ovrl_cd)
                {
                    case "DEPT_CD":
                        if (cboValue.Equals("2"))
                        {
                            if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectBIDEPTMA_CLSF_CD_Ward(), dt, cboValue, mdcr_dd))
                            {
                                if (dt.Rows.Count > 0)
                                {
                                    let row = dt.Rows[0];
                                    defaultvalue = "0403"; //기본진료과 화상외과 설정
                                }
                                return dt;
                            }
                        }
                        else
                        {
                            let L090:boolean = ConfigService.GetConfigValueDirect("PA", "OUT_REG", "DEPT_L090_YN", false);

                            if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectBIDEPTMA_CLSF_CD(L090), dt, cboValue
                                                                                                       , mdcr_dd
                                                                                                       , cboValue == "2" ? "N" : "Y"))
                            {
                                if (dt.Rows.Count > 0)
                                {
                                    let row = dt.Rows[0];
                                    defaultvalue = "0403"; //기본진료과 화상외과 설정
                                }
                                return dt;
                            }
                        }
                        return dt;
                        break;
                    case "ROOM_CD":
                        if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectBIROOMMA_ROOM_CD(), dt, cboValue
                                                                                                  , "%"
                                                                                                   , mdcr_dd))
                        {
                            if (dt.Rows.Count > 0)
                            {
                                let row = dt.Rows[0];
                                defaultvalue = row["ROOM_CD"].ToString();
                            }
                            return dt;
                        }
                        return dt;
                        break;

                    case "USER_CD":

                        string sqltext = String.Format(@"
SELECT DISTINCT Z.USER_CD, Z.USER_NM, Z.MAIN_DEPT_YN
  FROM (
SELECT USM.USER_CD                        --사용자코드
     , USM.USER_NM                        --사용자명
     , USD.MAIN_DEPT_YN
  FROM BIUSERMT USM, BIUSERDT USD, BIDEPTMA DEP, BICDINDT IND
 WHERE USD.USER_CD        = USM.USER_CD
   AND (USD.APLY_STRT_DD <= '{1}' AND '{1}' <= USD.APLY_END_DD)
   AND DEP.DEPT_CD        = USD.DEPT_CD
   AND DEP.DEPT_CD        = '{0}'
   AND (DEP.APLY_STRT_DD <= '{1}' AND '{1}' <= DEP.APLY_END_DD)
   AND IND.OVRL_CD        = 'OCTY_DVCD'
   AND IND.LWRN_OVRL_CD   = USM.OCTY_DVCD
   AND (IND.APLY_STRT_DD <= '{1}' AND '{1}' <= IND.APLY_END_DD)
   AND IND.ITNL_USE_CD    = 'D0' ) Z
ORDER BY Z.MAIN_DEPT_YN DESC, Z.USER_CD ASC", cboValue, mdcr_dd);

                        dt.Reset();
                        if (DBService.ExecuteDataTable(sqltext, dt))
                        {
                        }
                        else
                        {
                            dt = DoctorList.GetDataList(cboValue);
                            dt.DefaultView.Sort = "MAIN_DEPT_YN DESC, USER_CD ASC";
                            dt = dt.DefaultView.ToTable();
                        }

                        if (dt.Rows.Count > 0)
                        {
                            defaultvalue = dt.Rows[0]["USER_CD"].ToString();
                            return dt;
                        }
                        return dt;
                        break;
                    case "EXCP_RESN_CD":
                        if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectBIEXCDMA_RESN_CD(), dt, mdcr_dd))
                        {
                            if (dt.Rows.Count > 0)
                            {
                                let row = dt.Rows[0];
                                defaultvalue = row["EXCP_RESN_CD"].ToString();
                                return dt;
                            }
                        }
                        return dt;
                        break;
                    case "CFSC_CD":
                        if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectBISCCDMA_CFSC_CD(), dt, mdcr_dd))
                        {
                            if (dt.Rows.Count > 0)
                            {
                                let row = dt.Rows[0];
                                defaultvalue = row["CFSC_CD"].ToString();
                                return dt;
                            }
                        }
                        return dt;
                        break;
                    case "ASST_TYCD":
                        if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectBITPCLMA(), dt, cboValue
                                                                                          , mdcr_dd))
                        {
                            if (dt.Rows.Count > 0)
                            {
                                let row = dt.Rows[0];
                                defaultvalue = row["ASST_TYCD"].ToString();
                                return dt;
                            }
                        }
                        return dt;
                        break;
                    case "EXST_GRAD_CD":
                        if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectExstGradCd(), dt, cboValue
                                                                                            , mdcr_dd))
                        {
                            if (dt.Rows.Count > 0)
                            {
                                let row = dt.Rows[0];
                                defaultvalue = row["MEFE_CD"].ToString();
                                return dt;
                            }
                        }
                        return dt;
                        break;
                    default:
                        if (DBService.ExecuteDataTable(SQL.BI.Sql.SelectBICDINDT(), dt, ovrl_cd
                                                                                              , "Y"
                                                                                              , mdcr_dd))
                            return dt;
                        break;
                }
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
            }
            return dt;
        }
        /// <summary>
        /// 각종 구분코드 데이터를 DataTable에담기
        /// </summary>
        /// <param name="ovrl_cd"></param>
        /// <param name="aply_dd_yn"></param>
        /// <param name="mdcr_dd"></param>
        /// <returns></returns>
        public static GetDtBICDINDT(ovrl_cd:string, aply_dd_yn:string, mdcr_dd:string)
        {
            let dt:DataTable = new DataTable();
            if (DBService.ExecuteDataTable(SQL.BI.Sql.SelectBICDINDT(), dt, ovrl_cd
                                                                              , aply_dd_yn
                                                                              , mdcr_dd))
                return dt;

            return dt;
        }
        public static GetDtBICDINDT(ovrl_cd:string, aply_dd_yn:string, mdcr_dd:string, defaultvalue:string)
        {
            let dt:DataTable = new DataTable();
            if (DBService.ExecuteDataTable(SQL.BI.Sql.SelectBICDINDT(), dt, ovrl_cd
                                                                              , aply_dd_yn
                                                                              , mdcr_dd))
            {
                if (dt.Rows.Count > 0)
                {
                    let row = dt.Rows[0];
                    defaultvalue = row["LWRN_OVRL_CD"].ToString();
                    return dt;
                }
            }
            return dt;
        }
        public static GetDtBIASCDMA(mdcr_dd:string)
        {
            let dt:DataTable = new DataTable();
            try
            {
                if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectCmptCdExpl(), dt, mdcr_dd))
                    return dt;

            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
            }
            return dt;
        }
        /// <summary>
        /// 신환환자등록번호 생성
        /// </summary>
        public static CreateNewPid()
        {
            let newPid:string = String.Empty;

            DBParameters dbparams = DBService.CreateParameters();

            dbparams.Add("IV_NO_EDWM_DVCD", "A", ParameterDirection.Input);
            dbparams.Add("IOV_NEW_PID", "", ParameterDirection.Output);
            dbparams.Add("IOV_MSG", "", ParameterDirection.Output);

            if (DBService.ExecuteProcedure("PR_PA_READ_NEWPID", dbparams))
            {

                newPid = dbparams["IOV_NEW_PID"].Value.ToString().Trim();
            }
            return newPid;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <returns></returns>
        public static SelectMaxRcpnSqno(otptadmsdvcd:string, pid:string, ptcmhsno:number)
        {
            let maxrcpnsqno:number = 0;
            try
            {
                maxrcpnsqno = DBService.ExecuteInteger(SQL.PA.Sql.SelectPAOPATRT_MAXRCPNSQNO(), pid
                                                                                                , ptcmhsno.ToString()
                                                                                                , otptadmsdvcd);

                if (maxrcpnsqno < 0)
                {
                    return -1;
                }
                maxrcpnsqno++;
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                return -100;
            }

            return maxrcpnsqno;
        }
        /// <summary>
        /// 테이블의 특정 컬럼값의 유효성 여부를 리턴한다.
        /// </summary>
        /// <param name="mdcrdrcd"></param>
        /// <param name="mdcrdeptcd"></param>
        /// <param name="value1">부서코드</param>
        /// <param name="value2">의사코드</param>
        /// <returns></returns>
        public static ReturnValidityOfColumnValue(tablename:string, columnname:string, value1:string, value2:string)
        {
            let result:string = "Y";
            let octydvcd:string = String.Empty;
            let deptcd:string = String.Empty;
            let usercd:string = String.Empty;

            switch (columnname)
            {
                case "MDCR_DR_CD":
                    octydvcd = UserList.GetColumnValue(value1, "OCTY_DVCD").ToString();

                    // 직종이 의사인지 확인한다
                    if (String.IsNullOrWhiteSpace(octydvcd) || octydvcd.Substring(0, 1) != "D")
                        result = "N";

                    // 의사의 진료부서와 접수진료부서가 동일한지 확인한다.
                    foreach (DataRow row in DoctorList.GetDataList(value1).Rows)
                    {
                        if (row["DEPT_CD"].ToString().Equals(value2))
                        {
                            result = "N";
                            break;
                        }
                    }
                    break;
            }

            return result;
        }
        /// <summary>
        /// 처방발행건수 리턴
        /// </summary>
        /// <param name="pid">환자등록번호</param>
        /// <param name="ptcmhsno">환자내원번호</param>
        /// <param name="rcptyn">수납여부</param>
        /// <param name="dc">dc처방상태구분 A:정상, D:DC, ALL = 정상, DC 모두</param>
        /// <returns></returns>
        public static ReturnPrscIssuedCnt(pid:string, ptcmhsno:number, rcptyn:string, dc:string)
        {
            let result:number = 0;
            try
            {
                result = DBService.ExecuteInteger(SQL.PA.Sql.SelectORORDRRT_PrscCnt(), pid
                                                                                    , ptcmhsno.ToString()
                                                                                    , rcptyn
                                                                                    , dc);
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                result = -1;
            }
            return result;
        }

        /// <summary>
        /// <para>DBService.ExecuteNonquery가 false일 때 사용</para>
        /// <para>PK 컬럼이 중복되면 OracleException코드를 받아 확인하고, 원하는 Cell에 Focus를 주고, false를 반환한다.</para>
        /// </summary>
        /// <param name="spr">적용할 스프레드</param>
        /// <param name="rowIdx">적용할 RowIndex</param>
        /// <param name="focusCellTag">Focus를 줄 컬럼의 Tag명</param>
        /// <param name="PKColumnNames">메세지박스에 표시할 PK컬럼의 이름목록</param>
        /// <param name="isMsgBox">메세지박스를 출력할지 여부. True:출력 / False:미출력</param>
        /// <returns></returns>
        public static CheckDupByTable(LxSpread spr, rowIdx:number, focusCellTag:string, PKColumnNames:string, isMsgBox:boolean)
        {
            if (DBService.DBError.DupError)
            {
                spr.SetActiveRow(rowIdx);
                spr.SetActiveCell(rowIdx, focusCellTag);
                spr.ShowRow(0, rowIdx, FarPoint.Win.Spread.VerticalPosition.Nearest);

                if (isMsgBox)
                    LxMessage.Show("[" + PKColumnNames + "]은(는) 중복된 값이 입력될 수 없습니다!!", "중복값 존재", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return false;
            }
            return true;
        }

        /// <summary>
        /// <para>Spread에 데이터 저장 시 사용하는 For문 내부나 LeaveCell, ChangedExpand 이벤트 등에 사용</para>
        /// <para>NotNull컬럼에 Null이나 공백이 들어갔을 때 메세지박스를 띄우고 False를 반환한다.</para>>
        /// </summary>
        /// <param name="spr">적용할 스프레드</param>
        /// <param name="rowidx">확인할 rowIndex</param>
        /// <param name="colidx">확인할 ColumnIndex</param>
        /// <param name="colname">메세지박스에 출력할 컬럼명</param>
        /// <param name="isMsgBox">메세지박스 출력여부</param>
        /// <returns></returns>
        public static CheckNullBySpread(LxSpread spr, rowidx:number, colidx:number, colname:string, isMsgBox:boolean)
        {
            if ((StringService.ByteCount(spr.GetValue(rowidx, colidx).ToString()) == 0) || (String.IsNullOrWhiteSpace(spr.GetValue(rowidx, colidx).ToString())))
            {
                spr.SetActiveRow(rowidx);
                spr.ShowRow(spr.GetRootWorkbook().GetActiveRowViewportIndex(), rowidx, FarPoint.Win.Spread.VerticalPosition.Top);

                if (isMsgBox)
                    LxMessage.Show(colname + "에는 공백이 들어갈 수 없습니다.\r\n확인해주세요.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                return false;
            }

            return true;
        }

        /// <summary>
        /// <para>Spread에 데이터 저장 시 사용하는 For문 내부나 LeaveCell, ChangedExpand 이벤트 등에 사용</para>
        /// <para>데이터가 Table내에 설정된 MaxLength 초과하면 메세지박스를 띄우고 False를 반환한다.</para>>
        /// </summary>
        /// <param name="spr">적용할 스프레드</param>
        /// <param name="rowidx">체크할 RowIndex</param>
        /// <param name="colidx">체크할 ColumnIndex</param>
        /// <param name="maxlength">테이블에 설정된 해당 컬럼의 최대 MaxLength</param>
        /// <param name="colname">메세지박스에 표시할 컬럼 이름</param>
        /// <param name="isMsgBox">메세지박스를 출력할지 여부. True:출력 / False:미출력</param>
        /// <returns></returns>
        public static CheckLength(LxSpread spr, rowidx:number, colidx:number, maxlength:number, colname:string, isMsgBox:boolean)
        {
            if (StringService.ByteCount(spr.GetValue(rowidx, colidx).ToString()) > maxlength)
            {
                LxMessage.Show(colname + "의 글자수는 " + maxlength + "글자를 넘을 수 없습니다.\r\n확인해주세요.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                spr.SetActiveRow(rowidx);

                if (isMsgBox)
                    spr.ShowRow(spr.GetRootWorkbook().GetActiveRowViewportIndex(), rowidx, FarPoint.Win.Spread.VerticalPosition.Top);

                return false;
            }
            return true;
        }
        /// <summary>
        /// OCS OPEN 일자 확인
        /// </summary>
        /// <param name="mdcrdd"></param>
        /// <returns></returns>
        public static CheckOcsOpenDate(mdcrdd:string)
        {

            let ocsopendd:string = "";    // OCS오픈일자
            // 병원 OPEN일자 확인
            ocsopendd = ConfigService.GetConfigValueString("%", "OCS", "OPEN_DATE", "19000101");
            if (StringService.IsNotNull(ocsopendd))
            {
                if (DateTimeService.ConvertDateTime(mdcrdd) < DateTimeService.ConvertDateTime(ocsopendd))
                {
                    LxMessage.Show("진료일자가 OCS 오픈일자보다 이전입니다. 작업을 더이상 진행 할 수 없습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }
            }
            return true;
        }
        /// <summary>
        /// 수납에서 자격조회 여부를 리턴한다.
        /// </summary>
        /// <param name="insntycd"></param>
        /// <param name="assttycd"></param>
        /// <param name="mdcrdd"></param>
        /// <returns></returns>
        public static ReturnQlfcRtrvYn(insntycd:string, assttycd:string, mdcrdd:string, fcltaplyyn:string)
        {
            let success:boolean = false;

            let strtdd:string = String.Empty;

            if (insntycd.Substring(0, 1) == "2" && assttycd != "99")
                success = true;
            else if (fcltaplyyn.Equals("Y"))
                success = true;
            else if (insntycd.Substring(0, 1) == "1" && assttycd != "99")
            {
                // 건강보험 자격조회 시작일자 확인
                strtdd = ConfigService.GetConfigValueString("%", "HLNS_QLFC_STRT_DD", "HLNS_QLFC_STRT_DD", "19000101");
                if (String.IsNullOrWhiteSpace(strtdd))
                    success = false;
                else
                {
                    if (DateTimeService.ConvertDateTime(mdcrdd) >= DateTimeService.ConvertDateTime(strtdd) &&
                        mdcrdd == DateTimeService.NowDateNoneSeperatorString())
                    {
                        success = true;
                    }
                }
            }

            if (success)
            {
                if (!ConfigService.GetConfigValueString("%", "NOW_AFTER_QLFC_YN", "NOW_AFTER_QLFC_YN").ToString().Equals("Y"))
                {
                    if (DateTimeService.ConvertDateTime(mdcrdd) > DateTimeService.ConvertDateTime(strtdd))
                        success = false;
                }
            }

            return success;
        }

        public static ReturnDlwtDvcdPANHM3MA(pid:string, ptcmhsno:string, dlwtdvcd:string)
        {
            try
            {
                int cnt = DBService.ExecuteInteger(SQL.PA.Sql.SelectCountOfPANHM3MA(), pid
                                                                                      , ptcmhsno);
                if (cnt < 0)
                {
                    return false;
                }

                if (cnt > 0)
                {
                    dlwtdvcd = "0";   // 미승인건존재
                }
                else
                {
                    dlwtdvcd = "2";   // 승인완료
                }
                return true;

            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }

        }

        /// <summary>
        /// 문자열을 입력받아 날짜형식인지 체크한 후 맞다면, Format을 바꿔준다.
        /// <para>변환에 실패하면, 입력받은 문자열을 다시 Return한다.</para>
        /// <para>[사용예]</para>
        /// <para>변환형식을 구분하는 번호 : 입력문자열 → 출력문자열</para>
        /// <para>1 : 20170923(8자리) → 2017-09-23</para>
        /// <para>2 : 20170923(8자리) → 2017년9월23일</para>
        /// <para>3 : 2017-09-23(10자리) → 20170923</para>
        /// <para>4 : 2017-09-23(10자리) → 2017년09월23일</para>
        /// </summary>
        /// <param name="rule">변환형식을 구분하는 번호</param>
        /// <param name="dateString"></param>
        /// <returns></returns>
        public static ConvertDateFormat(rule:number, dateString:string)
        {
            if (DateTimeService.IsDateTime(dateString))
            {
                if (dateString.Length == 8)
                {
                    if (rule == 1)
                        return dateString.Substring(0, 4) + "-" + dateString.Substring(4, 2) + "-" + dateString.Substring(6, 2);
                    if (rule == 2)
                        return dateString.Substring(0, 4) + "년" + dateString.Substring(4, 2) + "월" + dateString.Substring(6, 2) + "일";
                }

                if (dateString.Length == 10)
                {
                    if (dateString.Contains("-"))
                    {
                        if (rule == 3)
                            return dateString.Replace("-", "");
                        if (rule == 4)
                        {
                            let replaceString:string = dateString.Replace("-", "");
                            return replaceString.Substring(0, 4) + "년" + replaceString.Substring(4, 2) + "월" + replaceString.Substring(6, 2) + "일";
                        }
                    }
                }
            }

            return dateString;
        }
        // #region 자격조회호출

        // 주석 SEO 2018-07-17 이 Region 자격조회호출 안 쓰고 있음
        public static ShowQualificationInfo(newpatientyn:string, pid:string, mdcrdd:string, ptnm:string, rrno:string, insntycd:string)
        {
            let msg:string = String.Empty;
            try
            {
                let basisdate:string = String.Empty;
                let mothernm:string = String.Empty;
                let motherrrno:string = String.Empty;
                let inpnrrno:string = String.Empty;

                if (StringService.IsNull(ptnm) || StringService.IsNull(rrno))
                {
                    LxMessage.Show("환자성명 또는 주민등록번호가 누락되었습니다.");
                    return;
                }
                //신생아인경우 엄마정보로 자격조회를 한다.
                if (!Lime.BusinessControls.clsPACommon.ReturnMotherInfo(pid, mothernm, motherrrno, basisdate))
                {
                    throw new Exception(msg);
                }

                if (StringService.IsNotNull(mothernm) && StringService.IsNotNull(motherrrno))
                {
                    ptnm = mothernm;
                    rrno = motherrrno;
                }


                // 시설환자의 경우 보험정보의 주민번호를 가져온다.
                if (!clsPACommon.GetInpnRrno(pid, insntycd, basisdate, inpnrrno, msg))
                {
                    throw new Exception(msg);
                }

                if (StringService.IsNotNull(inpnrrno))
                {
                    rrno = inpnrrno;
                }

                //clsPACommon.StartNhisMessage();
                ShowNhisMessage("Y", pid, basisdate, ptnm, rrno);
            }
            catch (ex)
            {
                LxMessage.Show("자격조회 중 오류를 발생했습니다.\r\n " +
                               "Method :  [QualificationInfo] \r\n " +
                               "오류 메시지 : " + ex.Message, "확인",
                               MessageBoxButtons.OK,
                               MessageBoxIcon.Error);
            }
        }

        public static ShowNhisMessage(newpatient:string, pid:string, mdcrdd:string, ptnm:string = "", rrno:string = "")
        {
            try
            {
                if (newpatient.Equals("N"))
                {
                    DOPack.PatientInfo.Load(pid);
                }

                clsNhisM1 m1 = new clsNhisM1();
                m1.SendM1(mdcrdd, ptnm, rrno);
                m1.OnGetMessage2 += m1_OnGetMessage2;

            }
            catch (ex)
            {
                LxMessage.Show("자격 조회중 오류를 발생하였습니다.\r\n 오류메시지 : " + ex.Message, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static m1_OnGetMessage2(clsNhisM2 m2)
        {
            try
            {
                popMessage2Response pop = new popMessage2Response();
                pop.SetM2Data(m2);
                pop.StartPosition = FormStartPosition.CenterParent;
                pop.ShowDialog();

                if (pop.DialogResult == DialogResult.OK)
                {
                    m_M2 = m2;
                }

                pop.Dispose();
            }
            catch (ex)
            {
                LxMessage.Show("자격 조회중 오류를 발생하였습니다.\r\n 오류메시지 : " + ex.Message, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        /*
        public static StartNhisMessage()
        {
            try
            {
                clsNhisM2 m2 = new clsNhisM2();
                m2.ReceiveM2();
                clsNhisM4 m4 = new clsNhisM4();
                m4.ReceiveM4();
                clsNhisM6 m6 = new clsNhisM6();
                m6.ReceiveM6();
            }
            catch (ex)
            {
                LxMessage.Show("자격 조회중 오류를 발생하였습니다.\r\n 오류메시지 : " + ex.Message, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        */

        public static GetM2Message()
        {

        }
        // #endregion 자격조회호출

        /// <summary>
        /// 환자특이사항을 가져온다.
        /// </summary>
        /// <param name="pid"> 환자등록번호</param>
        /// <param name="ptcmhsno"> 환자내원번호</param>
        /// <param name="otptadmsdvcd"> 외래입원구분코드</param>
        /// <param name="ptafmdcrdvcd"> 원무진료구분코드</param>
        public static ViewRemark(pid:string, ptcmhsno:number, otptadmsdvcd:string, ptafmdcrdvcd:string)
        {
            clsPatientRemark patientRem = new clsPatientRemark();
            return patientRem.ReturnPtPclrMatr(pid, ptcmhsno, otptadmsdvcd, ptafmdcrdvcd);
        }

        /// <summary>
        /// 선택진료의사 여부를 확인한다.
        /// </summary>
        /// <param name="mdcrdeptcd"></param>
        /// <param name="mdcrdrcd"></param>
        /// <param name="mdcrdd"></param>
        /// <returns></returns>
        public static SelectBiUserDtSlctDrYn(mdcrdeptcd:string, mdcrdrcd:string, mdcrdd:string)
        {
            try
            {
                let result:string = "";
                result = DBService.ExecuteScalar(SqlPack.Function.SelectFN_AD_READ_ADCONFDT(), "PA", "SPCR_OUT", "APLY_YN", mdcrdd).ToString();

                if (result == "Y")
                {
                    return StringService.IsNvl(DoctorList.GetColumnValue(mdcrdrcd, mdcrdeptcd, "SLCT_DR_YN").ToString(), "N");
                }
            }
            catch (ex)
            {
                LxMessage.Show("선택진료의사여부 확인 중 오류를 발생하였습니다. \r\n [ SelectBiUserDtSlctDrYn ] 오류메시지 : " + ex.Message, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return "N";
        }

        /// <summary>
        /// 병실차액금액을 가져온다.
        /// </summary>
        /// <param name="roomgradcd"></param>
        /// <param name="admsdd"></param>
        public static SetRoomDiamAmt(roomgradcd:string, admsdd:string, roomdiamamt:number)
        {
            try
            {
                string roomdiamcd = DBService.ExecuteScalar(SQL.PA.Sql.SelectRoomDiamCd(), roomgradcd
                                                                                         , admsdd).ToString();
                if (StringService.IsNull(roomdiamcd))
                {
                    roomdiamamt = 0;
                    return "N";
                }
                roomdiamamt = DBService.ExecuteInteger(SQL.PA.Sql.SelectRoomDiamAmt(), roomdiamcd
                                                                                     , admsdd);
                return "Y";
            }
            catch (ex)
            {
                roomdiamamt = 0;
                LxMessage.Show("병실차액금액 조회중 오류를 발생하였습니다.\r\n [SetRoomDiamAmt]오류메시지 : " + ex.Message, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return "N";
        }

        /// <summary>
        /// 신생아의 엄마정보를 가져온다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="mothernm">엄마성명</param>
        /// <param name="motherrrno">엄마주민등록번호</param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static GetMotherInfo(pid:string, mothernm:string, motherrrno:string, msg:string)
        {
            try
            {
                let dt:DataTable = new DataTable();

                if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectMotherInfoNRNBABRT(), dt, pid))
                {
                    if (dt.Rows.Count > 0)
                    {
                        let row = dt.Rows[0];

                        mothernm = StringService.IsNvl(row["MOM_NM"].ToString(), "NO");
                        motherrrno = row["MOM_FRRN"].ToString() + EncryptionService.Decoding(row["MOM_SRRN_ECPT"].ToString());
                    }
                    else
                    {
                        mothernm = "NO";
                    }
                }
                else
                {
                    msg = "엄마정보조회 중 오류를 발생헀습니다. \r\n " +
                          "Method :  [clsPACommon.GetMotherInfo -> SelectMotherInfoNRNBABRT] \r\n  " +
                          "오류메시지 : " + DBService.ErrorMessage;
                    return false;
                }
            }
            catch (ex)
            {
                msg = "엄마정보조회 중 오류를 발생했습니다.\r\n " +
                      "Method :  [clsPACommon.GetMotherInfo] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }

            return true;
        }

        /// <summary>
        /// 시설환자의 피보험주민번호를 가져온다
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="insntycd"></param>
        /// <param name="aplystrtdd"></param>
        /// <param name="inpnrrno"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static GetInpnRrno(pid:string, insntycd:string, aplystrtdd:string, inpnrrno:string, msg:string)
        {
            try
            {
                let dt:DataTable = new DataTable();

                if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectInpnRrnoOfPAPINSIF(), dt, pid
                                                                                            , insntycd
                                                                                            , aplystrtdd))
                {
                    if (dt.Rows.Count > 0)
                    {
                        let row = dt.Rows[0];

                        inpnrrno = row["INPN_FRRN"].ToString() + EncryptionService.Decoding(row["INPN_SRRN_ECPT"].ToString());
                    }
                    else
                    {
                        inpnrrno = "NO";
                    }
                }
                else
                {
                    msg = "시설환자의 피보험주민번호 조회 중 오류를 발생헀습니다. \r\n " +
                          "Method :  [clsPACommon.GetInpnRrno -> SelectInpnRrnoOfPAPINSIF] \r\n  " +
                          "오류메시지 : " + DBService.ErrorMessage;
                    return false;
                }
            }
            catch (ex)
            {
                msg = "시설환자의 피보험주민번호 조회 중 오류를 발생했습니다.\r\n " +
                      "Method :  [clsPACommon.GetInpnRrno] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }

            return true;
        }

        // #region [의료급여승인/승인취소]
        /// <summary>
        /// 의료급여승인 또는 승인취소를 한다.
        /// </summary>
        /// <param name="pid">환자등록번호</param>
        /// <param name="ptcmhsno">환자내원번호</param>
        /// <param name="rcptsqno">영수증일련번호</param>
        /// <param name="rcptocrruniqno">수납발생고유번호</param>
        /// <param name="origrcptsqno">이전수납일련번호</param>
        /// <param name="otptadmsdvcd">외래입원구분코드</param>
        /// <param name="dywardyn">낮병동여부</param>
        /// <param name="insntycd">보험유형</param>
        /// <param name="aplystrtdd">적용시작일자</param>
        /// <param name="rowstatdvcd">행상태구분코드</param>
        /// <param name="newrowstatdvcd">새로운행상태구분코드</param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static PermitAndCancelMedicalAid(pid:string, ptcmhsno:number, rcptsqno:number, rcptocrruniqno:string, origrcptsqno:number, otptadmsdvcd:string, dywardyn:string, insntycd:string, aplystrtdd:string, rowstatdvcd:string, newrowstatdvcd:string, msg:string)
        {
            try
            {
                let outmsg:string = String.Empty;
                let outmsgcd:string = String.Empty;
                let rrno:string = String.Empty;
                let ptnm:string = String.Empty;
                let inpnrrno:string = String.Empty;
                let motherrrno:string = String.Empty;
                let motherptnm:string = String.Empty;

                // using (DOPatientInfo pt = new DOPatientInfo())
                {
                    pt.Load(pid);
                    rrno = pt.FRRN + pt.SRRN_ECPT;
                    ptnm = pt.PT_NM;
                }

                //신생아인경우 엄마정보로 자격조회를 한다.
                if (!GetMotherInfo(pid, motherptnm, motherrrno, msg))
                {
                    return false;
                }
                if (StringService.IsNotNull(motherptnm) && !motherptnm.Equals("NO"))
                {
                    ptnm = motherptnm;
                    rrno = motherrrno;
                }

                if (!GetInpnRrno(pid, insntycd, aplystrtdd, inpnrrno, msg))
                {
                    return false;
                }

                if (rowstatdvcd.Equals("A") && newrowstatdvcd.Equals("D"))
                {
                    // 승인 취소
                    if (!SqlPack.Procedure.PR_PA_READ_PANHM5(pid
                                                            , ptcmhsno
                                                            , rcptsqno
                                                            , rcptocrruniqno
                                                            , origrcptsqno
                                                            , dywardyn.Equals("Y") ? "I" : otptadmsdvcd
                                                            , "0000"
                                                            , "0"
                                                            , "N"
                                                            , DOPack.HospitalInfo.NHIC_LOGN_ID
                                                            , DOPack.HospitalInfo.NHIC_LOGN_PW
                                                            , DOPack.HospitalInfo.BRNO
                                                            , ClientEnvironment.IP
                                                            , DOPack.UserInfo.FRRN + EncryptionService.Decoding(DOPack.UserInfo.SRRN_ECPT)
                                                            , DateTimeService.NowDateTimeNoneSeperatorString()
                                                            , DOPack.UserInfo.USER_CD
                                                            , outmsgcd
                                                            , outmsg))
                    {
                        msg = "의료급여 취소 승인 중 에러가 발생했습니다.\r\n" + DBService.ErrorMessage;
                        return false;
                    }

                    if (StringService.IsNotNull(outmsgcd))
                    {
                        msg = $"의료급여 취소 승인 중 에러가 발생했습니다.\r\n[ {outmsgcd} ] {outmsg}";
                        return false;
                    }
                }
                else if ((rowstatdvcd.Equals("I") && newrowstatdvcd.Equals("A")) ||
                         (rowstatdvcd.Equals("A") && newrowstatdvcd.Equals("A")))
                {
                    // 승인
                    if (!SqlPack.Procedure.PR_PA_READ_PANHM3(pid
                                                            , ptcmhsno.ToString()
                                                            , rcptsqno.ToString()
                                                            , rcptocrruniqno
                                                            , "0000"
                                                            , "0"
                                                            , "N"
                                                            , dywardyn.Equals("Y") ? "I" : otptadmsdvcd
                                                            , rrno
                                                            , inpnrrno
                                                            , ptnm
                                                            , dywardyn
                                                            , PABizCommon.GetHPTL_RGNO_CD(aplystrtdd)
                                                            , DOPack.HospitalInfo.ITSL_INST_DVCD
                                                            , DOPack.HospitalInfo.NHIC_LOGN_ID
                                                            , DOPack.HospitalInfo.BRNO
                                                            , ClientEnvironment.IP
                                                            , DOPack.UserInfo.FRRN + DOPack.UserInfo.SRRN_ECPT
                                                            , DateTimeService.NowDateTimeNoneSeperatorString()
                                                            , DOPack.UserInfo.USER_CD
                                                            , outmsgcd
                                                            , outmsg))
                    {
                        msg = "의료급여 승인 중 에러가 발생했습니다.\r\n" + DBService.ErrorMessage;
                        return false;
                    }

                    if (StringService.IsNotNull(outmsgcd))
                    {
                        msg = $"의료급여 승인 중 에러가 발생했습니다.\r\n[ {outmsgcd} ] {outmsg}";
                        return false;
                    }
                }

                return true;
            }
            catch (ex)
            {
                msg = $"의료급여 승인/취소 중 에러가 발생했습니다.\r\n{ex.Message}";
                return false;
            }

            return true;
        }
        // #endregion [의료급여승인/승인취소]

        /// <summary>
        /// 영수증번호를 생성한다.
        /// </summary>
        /// <param name="rcptdate"></param>
        /// <returns></returns>
        public static GetBillNo(rcptdate:string, billno:string, msg:string)
        {
            try
            {
                let lastno:string = String.Empty;

                if (rcptdate.Length > 8)
                    rcptdate = rcptdate.Substring(0, 8);

                if (!SqlPack.Procedure.PR_PA_READ_NEWBILLNO("B", rcptdate.Substring(0, 4), rcptdate, lastno, msg))
                    throw new Exception("영수증 번호를 생성하는 중 오류가 발생했습니다.");

                billno = rcptdate + lastno;
            }
            catch (ex)
            {
                let error:string = DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                msg = ex.Message + error;
                return false;
            }

            return true;
        }

        /// <summary>
        /// 수납발생고유번호(RCPT_OCRR_UNIQ_NO)를 생성한다.
        /// </summary>
        /// <param name="rcptdate"></param>
        /// <returns></returns>
        public static GetRcptOcrrUniqNo(rcptdate:string, rcptocrruniqno:string, msg:string)
        {
            try
            {
                let dttbsqno:number = 0;

                if (!SqlPack.Procedure.PR_AD_READ_UNIQSQ("RCPT_OCRR_UNIQ_NO", rcptdate.Substring(0, 4), rcptdate.Substring(4, 2), rcptdate.Substring(6, 2), "N", "N", dttbsqno))
                    throw new Exception("수납발생 고유번호를 생성하는 중 에러가 발생했습니다.");

                rcptocrruniqno = String.Format("{0}{1:00000}", rcptdate.Substring(0, 8), dttbsqno);
            }
            catch (ex)
            {
                let error:string = DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                msg = ex.Message + error;
                return false;
            }

            return true;
        }

        /// <summary>
        /// 6세 미만의 보조유형을 변경한다.
        /// </summary>
        /// <param name="insntycd">현보험유형</param>
        /// <param name="assttycd">현보조유형</param>
        /// <param name="age">연령</param>
        /// <param name="refassttycd">변경보조유형</param>
        public static CheckAsstTycd(otptadmsdvcd:string, insntycd:string, assttycd:string, age:number)
        {
            let rtnassttycd:string = assttycd;

            //보조유형 확인
            if ((insntycd.Equals("11") || insntycd.Equals("22")) && (!assttycd.Equals("99") && !assttycd.Equals("D9") & !assttycd.Equals("P9")))
            {
                //6세미만
                if (insntycd.Equals("11") && DateTime.Today >= DateTimeService.ConvertDateTime("20190101") && age < 1)
                {
                    rtnassttycd = "W0";        // 1세미만 소아
                }
                else if (age < 6)
                {
                    rtnassttycd = "60";        // 6세미만 소아
                }
                else if (age >= 6 && assttycd.Equals("60"))
                {
                    rtnassttycd = "00";        // 없음
                }
                else // age
                {
                    //11 : 행려
                    //50 : 자연분만신생아
                    //
                    if (otptadmsdvcd.Equals("O") && insntycd.Equals("11") && (assttycd.Equals("50") || assttycd.Equals("E3") || assttycd.Equals("E5") ||
                                                                              assttycd.Equals("F3") || assttycd.Equals("F5") || assttycd.Equals("V3") ||
                                                                              assttycd.Equals("HV")))
                    {
                        rtnassttycd = "00";
                    }
                    else if (otptadmsdvcd.Equals("O") && insntycd.Substring(0, 1).Equals("2") && (assttycd.Equals("50") || assttycd.Equals("FF") ||
                                                                                                 assttycd.Equals("V3")))
                    {
                        rtnassttycd = "00";
                    }
                    rtnassttycd = assttycd;           //보조유형
                }
            }
            else
            {
                rtnassttycd = assttycd;           //보조유형
            }

            return rtnassttycd;
        }

        /// <summary>
        /// 동일날 동일 보험청구부서와 동일보험유형의 접수정보가 있는 지 확인한다.
        /// 내과의 진료과로 확인한다.
        /// </summary>
        /// <param name="pid">환자등록번호</param>
        /// <param name="ptcmhsno">환자내원번호</param>
        /// <param name="mdcrdd">진료일자</param>
        /// <param name="mdcrdeptcd">진료부서코드</param>
        /// <param name="insnclamdeptcd">청구부서코드</param>
        /// <param name="insntycd">보험유형</param>
        /// <param name="msg">오류 메시지</param>
        /// <returns></returns>
        public static CheckSameRegInfo(pid:string, ptcmhsno:number, mdcrdd:string, mdcrdeptcd:string, insnclamdeptcd:string, insntycd:string, msg:string)
        {
            let result:number = 0;
            try
            {
                if (!insnclamdeptcd.Equals("01"))
                {
                    result = DBService.ExecuteInteger(SQL.PA.Sql.SelectSameRegInfo_ClamDept(), pid
                                                                                             , ptcmhsno.ToString()
                                                                                             , mdcrdd
                                                                                             , insnclamdeptcd
                                                                                             , insntycd);

                }
                else
                {

                    result = DBService.ExecuteInteger(SQL.PA.Sql.SelectSameRegInfo_MdcrDept(), pid
                                                                                             , ptcmhsno.ToString()
                                                                                             , mdcrdd
                                                                                             , mdcrdeptcd
                                                                                             , insnclamdeptcd
                                                                                             , insntycd);

                }
            }
            catch (ex)
            {
                msg = "동일날 동일청구부서와 동일보험유형으로 접수된 정보조회 중 오류를 발생했습니다.\r\n " +
                      "Method :  [clsPACOmmon -> CheckSameRegInfo] \r\n " +
                      "오류 메시지 : " + ex.Message;
                result = -100;
            }
            return result;
        }

        /// <summary>
        /// 초진재진구분을 가져온다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static CheckFrvsRvstDvcd(pid:string, ptcmhsno:number, mdcrdd:string, insnclamdeptcd:string, frvsrvstdvcd:string, msg:string)
        {
            let result:boolean = true;

            try
            {
                // 초진재진구분코드
                result = SqlPack.Procedure.PR_PA_PRC_FRVSRVSTSET(pid, ptcmhsno, mdcrdd, insnclamdeptcd, frvsrvstdvcd, msg);
                if (result)
                {
                    if (msg.Length > 0)
                    {
                        result = false;
                    }

                }
                else
                {
                    msg = "오류를 발생했습니다. \r\n " + DBService.ErrorMessage;
                    result = false;
                }
            }
            catch (ex)
            {
                msg = "초진재진구분코드를 확인하는 중 오류를 발생했습니다.\r\n " +
                      "Method :  [CheckFrvsRvstDvcd] \r\n " +
                      "오류 메시지 : " + ex.Message;
                result = false;
            }

            return result;
        }

        /// <summary>
        /// 수익코드 위치 정보를 리턴한다.
        /// </summary>
        /// <param name="spr"></param>
        /// <param name="billlctn"></param>
        /// <param name="rowcount"></param>
        /// <returns></returns>
        public static FindRowOfBillLctn(LxSpread spr, billlctn:string, rowcount:number)
        {
            let lwrnovrlcd:string = String.Empty;
            for (int i = 0; i < rowcount; i++)
            {
                lwrnovrlcd = spr.GetText(i, "LWRN_OVRL_CD");

                if (lwrnovrlcd.Equals(billlctn))
                {
                    return i;
                }

            }

            return -1;
        }

        /// <summary>
        /// 미수입금등록 화면을 연다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="unclOcrrDvcd"></param>
        /// <param name="form"></param>
        public static ShowForm_UnclAmt(pid:string, unclOcrrDvcd:string, UserControl form)
        {
            // [미수입금등록]화면을 연다.
            let param:ScreenParameters = new ScreenParameters();
            param.Add("PID", pid);
            param.Add("UNCL_CD", unclOcrrDvcd);

            if (form is BaseUserControl)
                ((BaseUserControl)form).CallPopUp("Lime.PA.dll", "Lime.PA.frmUncollectedDepositP", "미수입금등록", param);
            else if (form is BaseUCF)
                ((BaseUCF)form).CallPopUp("Lime.PA.dll", "Lime.PA.frmUncollectedDepositP", "미수입금등록", param);
            else if (form is BaseUCF_TP)
                ((BaseUCF_TP)form).CallPopUp("Lime.PA.dll", "Lime.PA.frmUncollectedDepositP", "미수입금등록", param);
        }

        /// <summary>
        /// 미수금 메시지를 띄운다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="form">현재 폼</param>
        public static ShowMessage_UnclAmt(pid:string, ptcmhsno:string, UserControl form)
        {
            let unclText:string = "";
            let unclTextPersonal:string = "";
            let unclDt:DataTable = new DataTable();

            // 미수발생구분코드별 미수금 취득
            clsPACommon.GetUnclAmt_UnclOcrrDvcd(pid, ptcmhsno, unclText, unclTextPersonal, unclDt);

            // 미수금이 없으면 리턴
            if (unclDt == null || unclDt.Rows.Count.Equals(0))
                return false;

            let text:string = "";

            // 개인미수 외 (혈액미수, 계약업체미수, 의료지원 등) => 메시지만 띄워준다.
            if (StringService.IsNotNull(unclText))
            {
                text = String.Format("아래의 미수금이 존재합니다.\r\n\r\n{0}", unclText);
                LxMessage.ShowInformation(text);
            }

            // 개인미수    (개인미수, 기타미수)                 => 메시지 띄워서 미수입금 팝업 창을 띄울수 있게 한다.
            if (StringService.IsNotNull(unclTextPersonal))
            {
                text = String.Format("개인 미수금이 존재합니다. 미수입금 하시겠습니까?\r\n\r\n{0}", unclTextPersonal);
                if (!LxMessage.ShowQuestion(text).Equals(DialogResult.Yes))
                    return false;

                // [미수입금등록]화면을 연다.
                clsPACommon.ShowForm_UnclAmt(pid, unclDt.Rows[0]["UNCL_OCRR_DVCD"].ToString(), form);
                return true;
            }

            return false;
        }

        /// <summary>
        /// 미수발생구분코드별 미수금 취득
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="unclText"></param>
        /// <param name="unclTextPersonal"></param>
        /// <param name="unclDt"></param>
        /// <param name="showMessage"></param>
        public static GetUnclAmt_UnclOcrrDvcd(pid:string, ptcmhsno:string, unclText:string, unclTextPersonal:string, unclDt:DataTable)
        {
            unclDt = new DataTable();
            unclText = "";
            unclTextPersonal = "";

            try
            {
                // 당일 미수금 조회여부를 취득한다. (Y => 내원번호는 무시한다)
                if (ConfigService.GetConfigValueBool("PA", "DAY_ACCOUNT_RECEIVABLE", "USE_YN"))
                    ptcmhsno = "0";

                // 전체 미수발생금을 조회한다.
                // (단, BICDINDT = 'UNCL_OCRR_DVCD' 의 ETC_USE_CNTS_6 ='Y'인 미수만을 대상으로 한다.)
                let allDt:DataTable = new DataTable();
                DBService.ExecuteDataTable(SQL.PA.Sql.GetOccurUnclAll(pid, ptcmhsno), allDt);

                // 미수발생금이 없으면 리턴
                if (allDt.Rows.Count.Equals(0))
                    return;

                // 전체 미수사용금을 조회한다.
                // (단, BICDINDT = 'UNCL_OCRR_DVCD' 의 ETC_USE_CNTS_6 ='Y'인 미수만을 대상으로 한다.)
                let useDt:DataTable = new DataTable();
                DBService.ExecuteDataTable(SQL.PA.Sql.GetPayUnclAll(pid, ptcmhsno), useDt);

                // 전체 미수발생금으로 loop
                double occurAmt = 0;
                double payAmt = 0;
                double unclAmt = 0;

                unclDt.Columns.Add("UNCL_OCRR_DVCD", typeof(string));
                unclDt.Columns.Add("UNCL_OCRR_DVNM", typeof(string));
                unclDt.Columns.Add("RCPT_DD", typeof(string));
                unclDt.Columns.Add("UNCL_AMT", typeof(double));

                for (int i = 0; i < allDt.Rows.Count; i++)
                {
                    unclAmt = 0;
                    double.TryParse(allDt.Rows[i]["SUM_UNCL_AMT"].ToString(), occurAmt);

                    useDt.DefaultView.RowFilter = "";
                    useDt.DefaultView.RowFilter = String.Format(" UNCL_OCRR_DVCD = '{0}'", allDt.Rows[i]["UNCL_OCRR_DVCD"].ToString());

                    if (useDt.DefaultView.ToTable().Rows.Count.Equals(0))
                    {
                        // 입금된 내역이 없는 경우
                        unclAmt = occurAmt;
                    }
                    else
                    {
                        // 입금된 내역이 있는 경우
                        double.TryParse(useDt.DefaultView.ToTable().Rows[0]["SUM_UNCL_AMT"].ToString(), payAmt);
                        unclAmt = occurAmt - payAmt;
                        if (unclAmt.Equals(0))
                            continue;
                    }

                    let dr = unclDt.NewRow();
                    dr["UNCL_OCRR_DVCD"] = allDt.Rows[i]["UNCL_OCRR_DVCD"].ToString();
                    dr["UNCL_OCRR_DVNM"] = allDt.Rows[i]["UNCL_OCRR_DVNM"].ToString();
                    dr["RCPT_DD"] = allDt.Rows[i]["MAX_RCPT_DD"].ToString();
                    dr["UNCL_AMT"] = unclAmt;
                    unclDt.Rows.Add(dr);
                }

                if (unclDt.Rows.Count.Equals(0))
                    return;

                let rcptDd:string = "";

                // ++++++++++++++++++++++++++++++++++++++
                // 개인미수 외 (단, BICDINDT = 'UNCL_OCRR_DVCD' 의 ETC_USE_CNTS_6 ='Y'인 미수만을 대상으로 한다.)
                // ++++++++++++++++++++++++++++++++++++++
                for (int i = 0; i < unclDt.Rows.Count; i++)
                {
                    if (unclDt.Rows[i]["UNCL_OCRR_DVCD"].ToString().Equals("*") || unclDt.Rows[i]["UNCL_OCRR_DVCD"].ToString().Equals("X10"))
                        continue;

                    // 수납일자
                    rcptDd = unclDt.Rows[i]["RCPT_DD"].ToString();
                    rcptDd = rcptDd.Length.Equals(8) ? String.Format("{0}-{1}-{2}", rcptDd.Substring(0, 4), rcptDd.Substring(4, 2), rcptDd.Substring(6, 2)) : "";

                    // 개행코드 + 미수구분명 + 수납일자 + 미수금액
                    unclText += String.Format("{0}   ＊[{1}] {2} ({3})", StringService.IsNotNull(unclText) ? "\r\n" : ""
                                                                     , unclDt.Rows[i]["UNCL_OCRR_DVNM"].ToString()
                                                                     , StringService.PadLeft(String.Format("{0:#,##0}", unclDt.Rows[i]["UNCL_AMT"]), 15)
                                                                     , rcptDd);
                }

                // ++++++++++++++++++++++++++++++++++++++
                // 개인미수
                // ++++++++++++++++++++++++++++++++++++++

                let objRcptDd:DateTime = unclDt.Compute("MAX(RCPT_DD)", "UNCL_OCRR_DVCD IN ('*', 'X10')");
                let objUnclAmt:DateTime = unclDt.Compute("SUM(UNCL_AMT)", "UNCL_OCRR_DVCD IN ('*', 'X10')");
                if (objUnclAmt != null)
                {
                    rcptDd = objRcptDd.ToString();
                    rcptDd = rcptDd.Length.Equals(8) ? String.Format("{0}-{1}-{2}", rcptDd.Substring(0, 4), rcptDd.Substring(4, 2), rcptDd.Substring(6, 2)) : "";

                    double doubleUnclAmt;
                    double.TryParse(objUnclAmt.ToString(), doubleUnclAmt);

                    if (!doubleUnclAmt.Equals(0))
                    {
                        unclTextPersonal = String.Format("   ＊[{0}] {1} ({2})", "개인미수"
                                                                       , StringService.PadLeft(String.Format("{0:#,##0}", doubleUnclAmt), 15)
                                                                       , rcptDd);
                    }
                }
            }
            catch (ex)
            {
                LxMessage.ShowError("미수금 조회 중, 에러가 발생했습니다.");
                LogService.ErrorLog("미수금 조회 중, 에러가 발생했습니다. - clsPACommon (GetUnclAmt_UnclOcrrDvcd) ");

                unclDt = new DataTable();
                unclText = "";
                unclTextPersonal = "";
            }
        }

        /// <summary>
        /// 미수금액(잔액)을 가져온다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="unclocrrdvcd"></param>
        /// <param name="unclamt"></param>
        /// <param name="uncldd"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static GetUnclAmt(pid:string, ptcmhsno:number, unclocrrdvcd:string, unclamt:number, uncldd:string, msg:string)
        {
            try
            {
                let uncltotlamt:number = 0, nopyuclamt = 0, uncldpstamt = 0, nopydpstamt = 0;
                let lastuncldd:string = String.Empty;
                let lastnopydd:string = String.Empty;

                if (ConfigService.GetConfigValueBool("PA", "DAY_ACCOUNT_RECEIVABLE", "USE_YN"))
                    ptcmhsno = 0;


                //미수발생총액
                uncltotlamt = DBService.ExecuteInteger(SQL.PA.Sql.SelectUnclTotlAmt(), pid
                                                                                     , unclocrrdvcd
                                                                                     , ptcmhsno.ToString());
                //미수입금총액
                uncldpstamt = DBService.ExecuteInteger(SQL.PA.Sql.SelectUnclDpstTotalAmt(), pid
                                                                                          , unclocrrdvcd
                                                                                          , ptcmhsno.ToString());

                uncltotlamt = uncltotlamt - uncldpstamt;

                //비급여미수발생총액
                nopyuclamt = DBService.ExecuteInteger(SQL.PA.Sql.SelectNopyUnclAmt(), pid);

                //비급여미수입금총액
                nopydpstamt = DBService.ExecuteInteger(SQL.PA.Sql.SelectNopyUnclAmt(), pid);

                nopyuclamt = nopyuclamt - nopydpstamt;

                unclamt = uncltotlamt + nopyuclamt;

                if (uncltotlamt > 0)
                {
                    lastuncldd = DBService.ExecuteScalar(SQL.PA.Sql.SelectLastUnclDd(), pid
                                                                                      , unclocrrdvcd
                                                                                      , ptcmhsno.ToString()).ToString();
                }
                if (nopyuclamt > 0)
                {
                    lastnopydd = DBService.ExecuteScalar(SQL.PA.Sql.SelectLastUnclDd(), pid).ToString();
                }

                if (unclamt > 0)
                {
                    if (DateTimeService.ConvertDateTime(lastuncldd) > DateTimeService.ConvertDateTime(lastnopydd))
                    {
                        uncldd = lastuncldd;
                    }
                    else if (DateTimeService.ConvertDateTime(lastnopydd) > DateTimeService.ConvertDateTime(lastuncldd))
                    {
                        uncldd = lastnopydd;
                    }
                }

                return true;

            }
            catch (ex)
            {
                LxMessage.Show("미수금액 조회중 오류가 발생하였습니다. \r\n [ GetUnclAmt ] 오류메시지 : " + ex.Message, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

        }



        /// <summary>
        /// 현 내원정보의 미수금액(잔액)을 가져온다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="unclocrrdvcd"></param>
        /// <param name="unclamt"></param>
        /// <param name="uncldd"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static GetUnclAmtNow(pid:string, ptcmhsno:number, unclocrrdvcd:string, unclamt:number, msg:string)
        {
            try
            {
                let uncltotlamt:number = 0, nopyuclamt = 0, uncldpstamt = 0, nopydpstamt = 0;
                let lastuncldd:string = String.Empty;
                let lastnopydd:string = String.Empty;

                //미수발생총액
                uncltotlamt = DBService.ExecuteInteger(SQL.PA.Sql.SelectUnclTotlAmtNow(), pid
                                                                                     , unclocrrdvcd
                                                                                     , ptcmhsno.ToString());
                //미수입금총액
                uncldpstamt = DBService.ExecuteInteger(SQL.PA.Sql.SelectUnclDpstTotalAmtNow(), pid
                                                                                          , unclocrrdvcd
                                                                                          , ptcmhsno.ToString());

                uncltotlamt = uncltotlamt - uncldpstamt;


                return true;

            }
            catch (ex)
            {
                LxMessage.Show("미수금액 조회중 오류가 발생하였습니다. \r\n [ GetUnclAmt ] 오류메시지 : " + ex.Message, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

        }

        /// <summary>
        /// 부입원 정보가 존재하는 지 확인한다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="dschdd"></param>
        /// <returns></returns>
        public static CheckIsSubAdms(pid:string, ptcmhsno:number, dschdd:string)
        {
            let subadmscount:number = 0;

            try
            {
                subadmscount = DBService.ExecuteInteger(SQL.PA.Sql.SelectIsSubAdms(), pid , dschdd);

                if (subadmscount < 0)
                {
                    LxMessage.ShowError("부입원정보 조회 중 오류를 발생했습니다.");
                    subadmscount = -100;
                }
                else if (subadmscount == 0)
                {
                    subadmscount = DBService.ExecuteInteger(SQL.PA.Sql.SelectIsPAAREBMA(), pid
                                                                                         , ptcmhsno.ToString()
                                                                                         , dschdd);
                    if (subadmscount < 0)
                    {
                        LxMessage.ShowError("입원환자정산내역 조회 중 오류를 발생했습니다.");
                        subadmscount = -200;
                    }
                }
            }
            catch (ex)
            {
                LxMessage.ShowError("부입원정보 조회 중 오류를 발생했습니다.");
                subadmscount = -300;
            }

            return subadmscount;
        }


        /// <summary>
        /// 미수발생정보를 가져온다.
        /// </summary>
        /// <param name="pid">환자등록번호</param>
        /// <param name="otptadmsdvcd">외래입원구분코드</param>
        /// <param name="ptcmhsno">환자내원번호</param>
        /// <param name="unclocrrdvcd">미수발생구분코드</param>
        /// <param name="rowstatdvcd">행상태구분코드</param>
        /// <param name="unclocrrsqno">미수발생일련번호</param>
        /// <param name="unclamt">미수금액</param>
        /// <param name="ptafclsnyn">원무확인여부</param>
        /// <param name="msg">오류메시지</param>
        /// <returns></returns>
        public static SelectIsUnclOcrr(pid:string, otptadmsdvcd:string, ptcmhsno:number, unclocrrdvcd:string, strtdd:string, rowstatdvcd:string, unclocrrsqno:number, unclamt:number, ptafclsnyn:string, msg:string)
        {
            try
            {
                unclocrrsqno = 0;
                unclamt = 0;
                let dt:DataTable = new DataTable();
                if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectIsUnclOcrr(), dt, pid
                                                                                    , otptadmsdvcd
                                                                                    , ptcmhsno.ToString()
                                                                                    , unclocrrdvcd
                                                                                    , strtdd
                                                                                    , rowstatdvcd))
                {
                    if (dt.Rows.Count > 0)
                    {
                        let row = dt.Rows[0];

                        unclocrrsqno = Int.Parse(row["UNCL_OCRR_SQNO"].ToString());
                        unclamt = Int.Parse(row["UNCL_AMT"].ToString());
                        ptafclsnyn = row["PTAF_CLSN_YN"].ToString();
                    }
                }
            }
            catch (ex)
            {
                msg = "미수발생자료 조회 중 오류를 발생했습니다.\r\n " +
                      "Method :  [SelectIsUnclOcrr] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }
            return true;
        }

        public static GetConfigCodeName(systemcd:string, conftype:string, confcd:string)
        {
            try
            {
                return DBService.ExecuteScalar(SQL.PA.Sql.SelectConfigCodeName(), systemcd
                                                                                , conftype
                                                                                , confcd).ToString();
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                return "원무";
            }
        }

        /// <summary>
        /// 현재기준 보증금잔액을 가져온다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="admsdd"></param>
        /// <returns></returns>
        public static GetBalanceOfInterAmt(pid:string, ptcmhsno:number, admsdd:string)
        {
            try
            {
                let gurntamt:number = 0;
                let usedamt:number = 0;

                gurntamt = DBService.ExecuteInteger(SQL.PA.Sql.SelectAdmsInterAmtTotal(), pid
                                                                                        , ptcmhsno.ToString());

                usedamt = DBService.ExecuteInteger(SQL.PA.Sql.SelectUsedGurnAmtTotal(), pid
                                                                                      , ptcmhsno.ToString());

                return gurntamt - usedamt;

            }
            catch (ex)
            {
                LogService.ErrorLog(ex);

                return -100;
            }
        }

        /// <summary>
        /// 영수정보에서 금액 변경이 있을 때 금액 재셋팅 - SetAmountOfBillInfo와 다음포커스 주는 거 빼면 같다. 나중에 이걸로 바꿔버릴거임
        /// </summary>
        /// <param name="ctl"></param>
        /// <param name="strcol"></param>
        /// <param name="leave_event"></param>
        /// <returns></returns>
        public static SetAmountOfBillInfo_NotFocus(Control ctl, StringCollection strcol, Dictionary<string, Control> allControls)
        {
            try
            {
                // 영수정보 LOAD 여부
                let loadyn:string = String.Empty;
                if (strcol.ContainsKey("LOAD_YN"))
                    loadyn = strcol.GetValue("LOAD_YN");

                if (!loadyn.Equals("Y")) return false;

                let trnc_yn:boolean = ConfigService.GetConfigValueBool("PA", "RECEIPT", "TRNC_YN", true);

                double amt = 0;
                double ptsharamt = 0;                        // 환자부담금액
                double ptshartamt = 0;                       // 환자본인부담총금액
                double cardrcptamt = 0;                      // 카드영수금액
                double cardrcptamt_ing = 0;                  // 카드영수금액 - 수납전카드승인내역
                double cashrcptamt = 0;                      // 현금영수금액
                double cashrcptamt_ing = 0;                  // 현금영수금액 - 수납전현금승인내역
                double bnacrcptamt = 0;                      // 통장영수금액
                double bnacrcptamt_ing = 0;                  // 통장영수금액 - 수납전통장영수금액
                double frtmcardrcptamt = 0;                  // 기카드영수금액
                double frtmcardrcptamt_c = 0;                // 기카드취소영수금액
                double frtmcashrcptamt = 0;                  // 기현금영수금액
                double frtmcashrcptamt_c = 0;                // 기현금취소영수금액
                double frtmbnacrcptamt = 0;                  // 기통장영수금액
                double frtmbnacamt_c = 0;                    // 기통장취소영수금액
                double dcntrdiaamt = 0;                      // 할인감액금액
                let spcldcntdvcd:string = String.Empty;          // 특별할인코드
                double spcldcntamt = 0;                      // 특별할인금액
                double frtmdcntrdiaamt = 0;                  // 기할인감액금액
                let dcntrdiacd:string = String.Empty;            // 할인감액코드
                let unclcd:string = String.Empty;                // 미수코드
                double unclamt = 0;                          // 미수금액
                double rcptamt = 0;                          // 수납처리한금액(받은금액)

                double vcntclamamt = 0;                      // 예방접종청구액
                //double vtrdamt = 0;                        // 수직감면금액
                double cttr_uncl_aply_amt = 0;               // 계약처미수적용금액
                double uschuplmamt = 0;                      // 상한액초과금액
                double pfanamt = 0;                          // 대불금액
                double gurnamt = 0;                          // 보증금액
                double firstgurnamt = 0;                     // 최초보증금액
                double emrgsuptamt = 0;                      // 긴급지원금액
                double tbrcctctsuptamt = 0;                  // 소아결핵지원금액
                double blodrdiaamt = 0;                      // 헌혈감액

                let pid:string = String.Empty;                   // 환자번호
                let ptcmhsno:string = String.Empty;              // 환자내원번호
                let insntycd:string = String.Empty;              // 진료일자(정산종료일자)
                let assttycd:string = String.Empty;              // 정산시작일자
                let mdcrdd:string = String.Empty;                // 정산종료일자
                let cmpystrtdd:string = String.Empty;            // 보험유형코드
                let cmpyenddd:string = String.Empty;             // 보조유형코드
                let cfscrgnocd:string = String.Empty;            // 산정특례기호코드
                let uschaplycd:string = String.Empty;            // 본인부담코드
                let dywardyn:string = String.Empty;              // 낮병동여부
                let otptdrgyn:string = String.Empty;             // 외래DRG여부
                let vtrnptyn:string = String.Empty;              // 보훈환자여부
                let momragedvdc:string = String.Empty;           // 유공자연령구분코드
                let indpmomryn:string = String.Empty;            // 독립유공자여부
                let refdcntamt:string = String.Empty;
                let msg:string = String.Empty;
                let otptadmsdvcd:string = String.Empty;

                otptadmsdvcd = strcol.GetValue("OTPT_ADMS_DVCD");

                if (allControls.ContainsKey("txtCardRcptAmt")) double.TryParse(((LxTextBox)(allControls["txtCardRcptAmt"])).Text.Replace(",", ""), cardrcptamt);                    // 카드영수금액
                if (allControls.ContainsKey("txtCardRcptAmt_ing")) double.TryParse(((LxTextBox)(allControls["txtCardRcptAmt_ing"])).Text.Replace(",", ""), cardrcptamt_ing);        // 카드영수금액 - 수납전카드승인내역
                if (allControls.ContainsKey("txtFrtmCardRcptAmt")) double.TryParse(((LxTextBox)(allControls["txtFrtmCardRcptAmt"])).Text.Replace(",", ""), frtmcardrcptamt);        // 기카드영수금액
                if (allControls.ContainsKey("txtFrtmCardRcptAmt")) double.TryParse(((LxTextBox)(allControls["txtFrtmCardRcptAmt_C"])).Text.Replace(",", ""), frtmcardrcptamt_c);    // 기카드취소영수금액
                if (allControls.ContainsKey("txtCashRcptAmt")) double.TryParse(((LxTextBox)(allControls["txtCashRcptAmt"])).Text.Replace(",", ""), cashrcptamt);                    // 현금영수금액
                if (allControls.ContainsKey("txtCashRcptAmt_ing")) double.TryParse(((LxTextBox)(allControls["txtCashRcptAmt_ing"])).Text.Replace(",", ""), cashrcptamt_ing);        // 현금영수금액 - 수납전현금승인내역
                if (allControls.ContainsKey("txtFrtmCashRcptAmt")) double.TryParse(((LxTextBox)(allControls["txtFrtmCashRcptAmt"])).Text.Replace(",", ""), frtmcashrcptamt);        // 기현금영수금액
                if (allControls.ContainsKey("txtFrtmCashRcptAmt")) double.TryParse(((LxTextBox)(allControls["txtFrtmCashRcptAmt_C"])).Text.Replace(",", ""), frtmcashrcptamt_c);    // 기현금취소영수금액
                if (allControls.ContainsKey("txtBnacRcptAmt")) double.TryParse(((LxTextBox)(allControls["txtBnacRcptAmt"])).Text.Replace(",", ""), bnacrcptamt);                    // 통장영수금액
                if (allControls.ContainsKey("txtBnacRcptAmt_ing")) double.TryParse(((LxTextBox)(allControls["txtBnacRcptAmt_ing"])).Text.Replace(",", ""), bnacrcptamt_ing);        // 통장영수금액 - 수납전통장승인내역
                if (allControls.ContainsKey("txtFrtmBnacAmt")) double.TryParse(((LxTextBox)(allControls["txtFrtmBnacAmt"])).Text.Replace(",", ""), frtmbnacrcptamt);                // 기통장영수금액
                if (allControls.ContainsKey("txtFrtmBnacAmt")) double.TryParse(((LxTextBox)(allControls["txtFrtmBnacAmt_C"])).Text.Replace(",", ""), frtmbnacamt_c);                // 기통장취소영수금액

                if (allControls.ContainsKey("cboDcntRdiaCd"))
                    dcntrdiacd = ((LxComboBox)(allControls["cboDcntRdiaCd"])).Value == null ? "" : ((LxComboBox)(allControls["cboDcntRdiaCd"])).SelectedItem.DataValue.ToString();      // 할인감액코드

                if (allControls.ContainsKey("txtDcntRdiaAmt")) double.TryParse(((LxTextBox)(allControls["txtDcntRdiaAmt"])).Text.Replace(",", ""), dcntrdiaamt);                    // 할인감액금액

                if (allControls.ContainsKey("cboSpclDcntDvcd"))
                    spcldcntdvcd = ((LxComboBox)(allControls["cboSpclDcntDvcd"])).Value == null ? "" : ((LxComboBox)(allControls["cboSpclDcntDvcd"])).SelectedItem.DataValue.ToString();// 특별할인구분코드

                if (allControls.ContainsKey("txtSpclDcntAmt")) double.TryParse(((LxTextBox)(allControls["txtSpclDcntAmt"])).Text.Replace(",", ""), spcldcntamt);                    // 특별할인금액

                // 2019-08-23 SJH 10원단위가 아니면 강제로 10원단위로 맞춰주자.
                if (spcldcntamt - (Math.Truncate(spcldcntamt / 10) * 10) != 0)
                {
                    double tempspcldcntamt = spcldcntamt;
                    spcldcntamt = Math.Round(spcldcntamt / 10, MidpointRounding.AwayFromZero) * 10;

                    LxMessage.ShowError(String.Format("할인금액(추가할인)에 1원단위가 입력되어 아래와 같은 금액으로 변경됩니다.(1원단위 반올림)\r\n\r\n할인금액 {0}원 => {1}원", String.Format("{0:#,##0}", tempspcldcntamt), String.Format("{0:#,##0}", spcldcntamt)));

                    ((LxTextBox)(allControls["txtSpclDcntAmt"])).Text = String.Format("{0:#,##0}", spcldcntamt);
                }

                if (allControls.ContainsKey("cboUnclCd"))
                    unclcd = ((LxComboBox)(allControls["cboUnclCd"])).Value == null ? "" : ((LxComboBox)(allControls["cboUnclCd"])).SelectedItem.DataValue.ToString();                  // 미수코드

                if (allControls.ContainsKey("txtUnclAmt")) double.TryParse(((LxTextBox)(allControls["txtUnclAmt"])).Text.Replace(",", ""), unclamt);                                // 미수할인금액

                if (otptadmsdvcd.Equals("B"))                                                                                                                                           // 비급여수납
                {
                    if (allControls.ContainsKey("txtPtSharAmt")) double.TryParse(((LxTextBox)(allControls["txtPtSharAmt"])).Text.Replace(",", ""), ptsharamt);

                    vcntclamamt = 0;                                                                                                                                                    // 예방접종청구액
                    //vtrdamt = 0;                                                                                                                                                        // 수직감면금액
                    cttr_uncl_aply_amt = 0;         // 계약처미수적용금액
                    uschuplmamt = 0;                                                                                                                                                    // 상한액초과금액
                    pfanamt = 0;                                                                                                                                                        // 대불금액
                    gurnamt = 0;                                                                                                                                                        // 보증금액
                    firstgurnamt = 0;                                                                                                                                                   // 최초보증금액
                    emrgsuptamt = 0;                                                                                                                                                    // 긴급지원금액
                    tbrcctctsuptamt = 0;                                                                                                                                                // 소아결핵지원금액
                }
                else
                {
                    if (allControls.ContainsKey("txtPtSharAmt")) double.TryParse(((LxTextBox)(allControls["txtPtSharAmt"])).Text.Replace(",", ""), ptsharamt);
                    if (allControls.ContainsKey("txtVcntClamAmt")) double.TryParse(((LxTextBox)(allControls["txtVcntClamAmt"])).Text.Replace(",", ""), vcntclamamt);                // 예방접종청구액
                    //if (allControls.ContainsKey("txtVtrnAmt")) double.TryParse(((LxTextBox)(allControls["txtVtrnAmt"])).Text.Replace(",", ""), vtrdamt);                            // 수직감면금액
                    if (allControls.ContainsKey("txtCttrUnclAplyAmt")) double.TryParse(((LxTextBox)(allControls["txtCttrUnclAplyAmt"])).Text.Replace(",", ""), cttr_uncl_aply_amt); // 계약처미수적용금액

                    if (otptadmsdvcd.Equals("O") || otptadmsdvcd.Equals("D"))
                    {
                        uschuplmamt = 0;                                                                                                                                                // 상한액초과금액
                        pfanamt = 0;                                                                                                                                                    // 대불금액
                        gurnamt = 0;                                                                                                                                                    // 보증금액
                        firstgurnamt = 0;                                                                                                                                               // 최초보증금액
                    }
                    else
                    {
                        if (allControls.ContainsKey("txtUschUplmAmt")) double.TryParse(((LxTextBox)(allControls["txtUschUplmAmt"])).Text.Replace(",", ""), uschuplmamt);            // 상한액초과금액
                        if (allControls.ContainsKey("txtPfanAmt")) double.TryParse(((LxTextBox)(allControls["txtPfanAmt"])).Text.Replace(",", ""), pfanamt);                        // 대불금액
                        if (allControls.ContainsKey("txtGurnAmt")) double.TryParse(((LxTextBox)(allControls["txtGurnAmt"])).Text.Replace(",", ""), gurnamt);                        // 보증금액
                        if (allControls.ContainsKey("txtFirstGurnAmt")) double.TryParse(((LxTextBox)(allControls["txtFirstGurnAmt"])).Text.Replace(",", ""), firstgurnamt);         // 최초보증금액
                    }

                    if (allControls.ContainsKey("txtEmrgSuptAmt")) double.TryParse(((LxTextBox)(allControls["txtEmrgSuptAmt"])).Text.Replace(",", ""), emrgsuptamt);                // 긴급지원금액
                    if (allControls.ContainsKey("txtTbrcCtctSuptAmt")) double.TryParse(((LxTextBox)(allControls["txtTbrcCtctSuptAmt"])).Text.Replace(",", ""), tbrcctctsuptamt);    // 소아결핵지원금액

                    if (allControls.ContainsKey("txtBlodRdiaAmt")) double.TryParse(((LxTextBox)(allControls["txtBlodRdiaAmt"])).Text.Replace(",", ""), blodrdiaamt); // 헌혈감액
                }

                ptsharamt = Convert.ToInt32(Math.Truncate(Convert.ToDouble(ptsharamt) / 10) * 10);

                if (StringService.IsNull(ctl.Text))
                    ctl.Text = "0";

                switch (ctl.Name)
                {
                    case "txtCardRcptAmt": // 카드영수금액
                    case "txtBnacRcptAmt": // 계좌영수금액
                    case "txtUnclAmt": // 미수금액

                        // 현금영수금액부터 구한다.
                        // 현금영수금액 = 본인부담 - (상한액초과금 + 대불금액 + 기카드영수금액 + 기계좌영수금액 + 기현금영수금액
                        //                     + 기할인감액금액 + 카드영수금액 + 계좌영수금액 + 할인감액금액 + 특별할인금액
                        //                     + 미수금액 + 수직감면금액 + 보증금액 + 긴급지원금액 (X 2019-03-20 SJH)
                        //                     + 미수금액 + 계약처미수적용금액 + 보증금액 + 긴급지원금액 (O 2019-03-20 SJH) + 헌혈
                        //                     + 소아결핵접촉지원금액 (X 2019-03-28 PMK) + 수납전카드승인금액 + 수납전현금승인금액 + 수납전통장승인금액 + 기카드취소영수금액
                        //                     + 기통장취소영수금액 + 기현금취소영수금액)
                        cashrcptamt = ptsharamt - (uschuplmamt + pfanamt + frtmcardrcptamt + frtmbnacrcptamt + frtmcashrcptamt
                                                 + frtmdcntrdiaamt + cardrcptamt + bnacrcptamt + dcntrdiaamt + spcldcntamt
                                                 //+ unclamt + vtrdamt + gurnamt + emrgsuptamt
                                                 + unclamt + cttr_uncl_aply_amt + gurnamt + emrgsuptamt + blodrdiaamt
                                                 + cardrcptamt_ing + cashrcptamt_ing + bnacrcptamt_ing + frtmcardrcptamt_c
                                                 + frtmbnacamt_c + frtmcashrcptamt_c);

                        if (trnc_yn)
                            cashrcptamt = Math.Truncate(cashrcptamt / 10) * 10;

                        //현금금액 + 통장금액 + 할인금액 + 추가할인 + 미수금액 + 카드금액 + 수납전카드승인금액 + 수납전현금승인금액 + 수납전통장승인금액 > 본인총액
                        if (cashrcptamt + bnacrcptamt + dcntrdiaamt + spcldcntamt + unclamt
                           + cardrcptamt + cardrcptamt_ing + cashrcptamt_ing + bnacrcptamt_ing > ptsharamt)
                        {
                            LxMessage.Show("카드결재금액이 본인부담금액보다 많습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            ((LxTextBox)(allControls["txtCardRcptAmt"])).Text = String.Format("{0:#,##0}", ptsharamt - (cashrcptamt + bnacrcptamt + dcntrdiaamt + spcldcntamt + unclamt + cardrcptamt_ing + cashrcptamt_ing + bnacrcptamt_ing));

                            return false;
                        }

                        // 현금영수금액 컨트롤에 값을 세팅한다.
                        ((LxTextBox)(allControls["txtCashRcptAmt"])).Text = String.Format("{0:#,##0}", cashrcptamt);

                        if (unclamt == 0)
                        {
                            ((LxComboBox)(allControls["cboUnclCd"])).SelectValue("NO");
                            ((LxTextBox)(allControls["txtUnclAmt"])).Text = "0";

                            if (otptadmsdvcd.Equals("B"))
                            {
                                // TODO : 비급여일 경우 다른 컨트롤에 텍스트 클리어 되어야 할 듯?
                                ((LxTextBox)(allControls["txtUnclResn"])).Text = "";
                            }
                            else
                            {
                                ((LxTextBox)(allControls["txtUnclResn"])).Text = "";
                            }
                        }
                        break;

                    case "txtCashRcptAmt": // 현금영수금액
                        if ((cashrcptamt + cardrcptamt + bnacrcptamt + dcntrdiaamt + spcldcntamt + cardrcptamt_ing + cashrcptamt_ing + bnacrcptamt_ing) > ptsharamt)
                        {
                            LxMessage.Show("영수금액(카드 또는 계좌 또는 할인금액 포함)이 본인부담금액보다 많습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            if (ConfigService.GetConfigValueDirect("%", "TEST_SJH", "TEST_SJH_17", "N").Equals("Y"))
                            {
                                var temp = ptsharamt - (uschuplmamt + pfanamt + frtmcardrcptamt + frtmbnacrcptamt + frtmcashrcptamt
                                                     + frtmdcntrdiaamt + 0 + cardrcptamt + bnacrcptamt + dcntrdiaamt
                                                     //+ spcldcntamt + vtrdamt + gurnamt + emrgsuptamt
                                                     + spcldcntamt + cttr_uncl_aply_amt + gurnamt + emrgsuptamt + blodrdiaamt
                                                     + cardrcptamt_ing + cashrcptamt_ing + bnacrcptamt_ing + frtmcardrcptamt_c
                                                     + frtmbnacamt_c + frtmcashrcptamt_c);

                                ((LxTextBox)(allControls["txtCashRcptAmt"])).Text = String.Format("{0:#,##0}", temp);
                            }
                            else
                            {
                                ((LxTextBox)(allControls["txtCashRcptAmt"])).Text = String.Format("{0:#,##0}", ptsharamt - (cardrcptamt + bnacrcptamt + dcntrdiaamt + spcldcntamt));
                            }

                            return false;
                        }

                        // 현금영수금액 = 본인부담 - (상한액초과금 + 대불금액 + 기카드영수금액 + 기통장영수금액 + 기현금영수금액
                        //                     + 기할인감액금액 + 현금영수금액 + 카드영수금액 + 계좌영수금액 + 할인감액금액
                        //                     + 특별할인금액 + 수직감면금액 + 보증금액 + 긴급지원금액 (X 2019-03-20 SJH)
                        //                     + 특별할인금액 + 계약처미수적용금액 + 보증금액 + 긴급지원금액 (O 2019-03-20 SJH) + 헌혈
                        //                     + 소아결핵접촉지원금액 (X 2019-03-28 PMK)+ 수납전카드승인금액 + 수납전현금승인금액 + 수납전통장승인금액 + 기카드취소영수금액
                        //                     + 기통장취소영수금액 + 기현금취소영수금액)
                        unclamt = ptsharamt - (uschuplmamt + pfanamt + frtmcardrcptamt + frtmbnacrcptamt + frtmcashrcptamt
                                             + frtmdcntrdiaamt + cashrcptamt + cardrcptamt + bnacrcptamt + dcntrdiaamt
                                             //+ spcldcntamt + vtrdamt + gurnamt + emrgsuptamt
                                             + spcldcntamt + cttr_uncl_aply_amt + gurnamt + emrgsuptamt + blodrdiaamt
                                             + cardrcptamt_ing + cashrcptamt_ing + bnacrcptamt_ing + frtmcardrcptamt_c
                                             + frtmbnacamt_c + frtmcashrcptamt_c);

                        if (trnc_yn)
                            unclamt = Math.Truncate(unclamt / 10) * 10;

                        ((LxTextBox)(allControls["txtUnclAmt"])).Text = String.Format("{0:#,##0}", unclamt);

                        if (unclamt > 0)
                        {
                        }
                        else
                        {
                            ((LxComboBox)(allControls["cboUnclCd"])).SelectValue("NO");
                            ((LxTextBox)(allControls["txtUnclResn"])).Clear();
                        }
                        break;
                    case "cboDcntRdiaCd":       // 할인감액코드

                        // 기타수납시에 여기 안타게 했음
                        if (dcntrdiacd.Equals("NO"))
                        {
                            dcntrdiaamt = 0;

                            if (allControls.ContainsKey("txtDcntRdiaEmnm"))
                            {
                                ((LxTextBox)(allControls["txtDcntRdiaEmnm"])).ReadOnly = true;
                                ((LxTextBox)(allControls["txtDcntRdiaEmnm"])).Text = String.Empty;
                                //((LxTextBox)(allControls["txtDcntRdiaEmcd"])).Text = String.Empty;
                                ((LxTextBox)(allControls["txtDcntRdiaEmnm"])).Appearance.BackColor = Color.FromArgb(250, 252, 252);
                                ((LxTextBox)(allControls["txtDcntRdiaEmnm"])).NullTextAppearance.BackColor = Color.FromArgb(250, 252, 252);
                            }
                        }
                        else
                        {
                            if (allControls.ContainsKey("txtDcntRdiaEmnm"))
                            {
                                ((LxTextBox)(allControls["txtDcntRdiaEmnm"])).ReadOnly = false;
                                ((LxTextBox)(allControls["txtDcntRdiaEmnm"])).Appearance.BackColor = Color.White;
                                ((LxTextBox)(allControls["txtDcntRdiaEmnm"])).NullTextAppearance.BackColor = Color.White;
                            }

                            pid = strcol.GetValue("PID");
                            ptcmhsno = strcol.GetValue("PT_CMHS_NO");

                            if (!otptadmsdvcd.Equals("B"))
                            {
                                insntycd = strcol.GetValue("INSN_TYCD");
                                assttycd = strcol.GetValue("ASST_TYCD");
                            }

                            if (otptadmsdvcd.Equals("O") || otptadmsdvcd.Equals("D") || otptadmsdvcd.Equals("B"))
                            {
                                mdcrdd = strcol.GetValue("MDCR_DD");
                                mdcrdd = strcol.GetValue("CMPY_STRT_DD");
                                mdcrdd = strcol.GetValue("CMPY_END_DD");
                            }
                            else
                            {
                                mdcrdd = strcol.GetValue("CMPY_END_DD");
                                cmpystrtdd = strcol.GetValue("CMPY_STRT_DD");
                                cmpyenddd = strcol.GetValue("CMPY_END_DD");
                            }

                            // TODO :가족할인코드인 경우 자동적용 임의 변경못하게한다.
                            if (otptadmsdvcd.Equals("O") || otptadmsdvcd.Equals("D") || otptadmsdvcd.Equals("B"))
                            {

                            }

                            // TODO : 수익집계합계로 할인계산, 처방집계합계로 할인계산 옵션
                            if (otptadmsdvcd.Equals("B"))
                            {

                            }
                            else
                            {
                                // DBService.BeginTransaction ();
                                if (!SqlPack.Procedure.PR_PA_COM_PRSCDCNTAMT(otptadmsdvcd
                                                                          , pid
                                                                          , ptcmhsno
                                                                          , insntycd
                                                                          , assttycd
                                                                          , strcol.GetValue("USCH_APLY_CD")
                                                                          , dcntrdiacd
                                                                          , mdcrdd
                                                                          , cmpystrtdd
                                                                          , cmpyenddd
                                                                          , strcol.GetValue("CFSC_RGNO_CD")
                                                                          , strcol.GetValue("OTPT_DRG_YN")
                                                                          , strcol.GetValue("VTRN_PT_YN")
                                                                          , strcol.GetValue("MOMR_AGE_DVCD")
                                                                          , strcol.GetValue("INDP_MOMR_YN")
                                                                          , refdcntamt
                                                                          , msg))
                                {
                                    let errmsg:string = String.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage);
                                    // DBService.RollbackTransaction();
                                    LxMessage.Show(errmsg, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    return false;
                                }
                                if (StringService.IsNotNull(msg))
                                {
                                    // DBService.RollbackTransaction();
                                    LxMessage.Show(msg, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    return false;
                                }
                                // DBService.CommitTransaction ();
                                double.TryParse(refdcntamt, dcntrdiaamt);
                            }

                            dcntrdiaamt = Convert.ToInt32(Math.Truncate(Convert.ToDouble(dcntrdiaamt) / 100) * 100);
                        }

                        // 산재공상 청구할인
                        if (StringService.IsNotNull(dcntrdiacd) && dcntrdiacd.Substring(0, 2).Equals("SG") && dcntrdiaamt > 0)
                        {
                            if (allControls.ContainsKey("txtDcntRdiaAmt")) ((LxTextBox)(allControls["txtDcntRdiaAmt"])).Text = String.Format("{0:#,##0}", dcntrdiaamt);
                        }
                        else
                        {
                            // 현금영수금액부터 구한다.
                            // 현금영수금액 = 본인부담 - (상한액초과금 + 대불금액 + 기카드영수금액 + 기통장영수금액 + 기현금영수금액
                            //                     + 기할인감액금액 + 카드영수금액 + 계좌영수금액 + 할인감액금액 + 특별할인금액
                            //                     + 미수금액 + 수직감면금액 + 보증금액 + 긴급지원금액 (X 2019-03-20 SJH)
                            //                     + 미수금액 + 계약처미수적용금액 + 보증금액 + 긴급지원금액 (O 2019-03-20 SJH) + 헌혈
                            //                     + 소아결핵접촉지원금액 (X 2019-03-28 PMK) + 수납전카드승인금액 + 수납전현금승인금액 + 수납전통장승인금액 + 기카드취소영수금액
                            //                     + 기통장취소영수금액 + 기현금취소영수금액)
                            cashrcptamt = ptsharamt - (uschuplmamt + pfanamt + frtmcardrcptamt + frtmbnacrcptamt + frtmcashrcptamt
                                                     + frtmdcntrdiaamt + cardrcptamt + bnacrcptamt + dcntrdiaamt + spcldcntamt
                                                     //+ unclamt + vtrdamt + gurnamt + emrgsuptamt
                                                     + unclamt + cttr_uncl_aply_amt + gurnamt + emrgsuptamt + blodrdiaamt
                                                     + cardrcptamt_ing + cashrcptamt_ing + bnacrcptamt_ing + frtmcardrcptamt_c
                                                     + frtmbnacamt_c + frtmcashrcptamt_c);

                            if (trnc_yn)
                                cashrcptamt = Math.Truncate(cashrcptamt / 10) * 10;

                            if (allControls.ContainsKey("txtDcntRdiaAmt")) ((LxTextBox)(allControls["txtDcntRdiaAmt"])).Text = String.Format("{0:#,##0}", dcntrdiaamt);
                            if (allControls.ContainsKey("txtCashRcptAmt")) ((LxTextBox)(allControls["txtCashRcptAmt"])).Text = String.Format("{0:#,##0}", cashrcptamt);
                            if (allControls.ContainsKey("txtBnacRcptAmt")) ((LxTextBox)(allControls["txtBnacRcptAmt"])).Text = "0";
                            if (allControls.ContainsKey("txtCardRcptAmt")) ((LxTextBox)(allControls["txtCardRcptAmt"])).Text = "0";
                            if (allControls.ContainsKey("cboUnclCd")) ((LxComboBox)(allControls["cboUnclCd"])).SelectValue("NO");
                            if (allControls.ContainsKey("txtUnclAmt")) ((LxTextBox)(allControls["txtUnclAmt"])).Text = "0";
                            if (allControls.ContainsKey("txtUnclResn")) ((LxTextBox)(allControls["txtUnclResn"])).Text = "";
                        }
                        break;
                    case "txtDcntRdiaAmt":      // 할인감액금액
                        if ((dcntrdiaamt + spcldcntamt) > ptsharamt)
                        {
                            LxMessage.Show("할인감액금액이 본인부담금액보다 많습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            if (allControls.ContainsKey("txtDcntRdiaAmt")) ((LxTextBox)(allControls["txtDcntRdiaAmt"])).Text = String.Format("{0:#,##0}", ptsharamt - (cardrcptamt + cashrcptamt + bnacrcptamt + unclamt + spcldcntamt));
                            return false;
                        }

                        // 현금영수금액부터 구한다.
                        // 현금영수금액 = 본인부담 - (상한액초과금 + 대불금액 + 기카드영수금액 + 기계좌영수금액 + 기현금영수금액
                        //                     + 기할인감액금액 + 카드영수금액 + 계좌영수금액 + 할인감액금액 + 특별할인금액
                        //                     + 미수금액 + 수직감면금액 + 보증금액 + 긴급지원금액 (X 2019-03-20 SJH)
                        //                     + 미수금액 + 계약처미수적용금액 + 보증금액 + 긴급지원금액 (O 2019-03-20 SJH) + 헌혈
                        //                     + 소아결핵접촉지원금액 (X 2019-03-28 PMK) + 수납전카드승인금액 + 수납전현금승인금액 + 수납전통장승인금액 + 기카드취소영수금액
                        //                     + 기통장취소영수금액 + 기현금취소영수금액)
                        cashrcptamt = ptsharamt - (uschuplmamt + pfanamt + frtmcardrcptamt + frtmbnacrcptamt + frtmcashrcptamt
                                                 + frtmdcntrdiaamt + cardrcptamt + bnacrcptamt + dcntrdiaamt + spcldcntamt
                                                 //+ unclamt + vtrdamt + gurnamt + emrgsuptamt
                                                 + unclamt + cttr_uncl_aply_amt + gurnamt + emrgsuptamt + blodrdiaamt
                                                 + cardrcptamt_ing + cashrcptamt_ing + bnacrcptamt_ing + frtmcardrcptamt_c
                                                 + frtmbnacamt_c + frtmcashrcptamt_c);

                        if (trnc_yn)
                            cashrcptamt = Math.Truncate(cashrcptamt / 10) * 10;

                        if (allControls.ContainsKey("txtCashRcptAmt")) ((LxTextBox)(allControls["txtCashRcptAmt"])).Text = String.Format("{0:#,##0}", cashrcptamt);
                        if (allControls.ContainsKey("txtBnacRcptAmt")) ((LxTextBox)(allControls["txtBnacRcptAmt"])).Text = String.Format("{0:#,##0}", bnacrcptamt); ;
                        if (allControls.ContainsKey("txtCardRcptAmt")) ((LxTextBox)(allControls["txtCardRcptAmt"])).Text = "0";
                        if (allControls.ContainsKey("cboUnclCd")) ((LxComboBox)(allControls["cboUnclCd"])).SelectValue("NO");
                        if (allControls.ContainsKey("txtUnclAmt")) ((LxTextBox)(allControls["txtUnclAmt"])).Text = "0";
                        if (allControls.ContainsKey("txtUnclResn")) ((LxTextBox)(allControls["txtUnclResn"])).Text = "";

                        break;
                    case "cboSpclDcntDvcd":     // 특별할인코드
                        if (spcldcntdvcd.Equals("NO"))
                        {
                            if (allControls.ContainsKey("txtSpclDcntAmt"))
                            {
                                ((LxTextBox)(allControls["txtSpclDcntAmt"])).Text = "0";
                                ((LxTextBox)(allControls["txtSpclDcntAmt"])).ReadOnly = true;
                                ((LxTextBox)(allControls["txtSpclDcntAmt"])).Appearance.BackColor = Color.FromArgb(250, 252, 252);
                                ((LxTextBox)(allControls["txtSpclDcntAmt"])).NullTextAppearance.BackColor = Color.FromArgb(250, 252, 252);
                            }
                        }
                        else
                        {
                            if (allControls.ContainsKey("txtSpclDcntAmt"))
                            {
                                ((LxTextBox)(allControls["txtSpclDcntAmt"])).ReadOnly = false;
                                ((LxTextBox)(allControls["txtSpclDcntAmt"])).Appearance.BackColor = Color.White;
                                ((LxTextBox)(allControls["txtSpclDcntAmt"])).NullTextAppearance.BackColor = Color.White;
                            }
                        }
                        break;
                    case "txtSpclDcntAmt":      // 특별할인금액
                        if ((dcntrdiaamt + spcldcntamt) > ptsharamt)
                        {
                            LxMessage.Show("할인감액금액이 본인부담금액보다 많습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ((LxTextBox)(allControls["txtSpclDcntAmt"])).Text = String.Format("{0:#,##0}", ptsharamt - (cardrcptamt + cashrcptamt + bnacrcptamt + unclamt + dcntrdiaamt));
                            return false;
                        }

                        if (spcldcntamt - (Math.Truncate(spcldcntamt / 10) * 10) != 0)
                        {
                            LxMessage.ShowError("할인금액은 1원단위가 아닌 10원 단위로 입력해 주세요!!!");
                        }

                        // 현금영수금액부터 구한다.
                        // 현금영수금액 = 본인부담 - (상한액초과금 + 대불금액 + 기카드영수금액 + 기계좌영수금액 + 기현금영수금액
                        //                     + 기할인감액금액 + 카드영수금액 + 계좌영수금액 + 할인감액금액 + 특별할인금액
                        //                     + 미수금액 + 계약처미수적용금액 + 보증금액 + 긴급지원금액 (O 2019-03-20 SJH) + 헌혈
                        //                     + 소아결핵접촉지원금액 (X 2019-03-28 PMK) + 수납전카드승인금액 + 수납전현금승인금액 + 수납전통장승인금액 + 기카드취소영수금액
                        //                     + 기통장취소영수금액 + 기현금취소영수금액)
                        cashrcptamt = ptsharamt - (uschuplmamt + pfanamt + frtmcardrcptamt + frtmbnacrcptamt + frtmcashrcptamt
                                                 + frtmdcntrdiaamt + cardrcptamt + bnacrcptamt + dcntrdiaamt + spcldcntamt
                                                 + unclamt + cttr_uncl_aply_amt + gurnamt + emrgsuptamt + blodrdiaamt
                                                 + cardrcptamt_ing + cashrcptamt_ing + bnacrcptamt_ing + frtmcardrcptamt_c
                                                 + frtmbnacamt_c + frtmcashrcptamt_c);

                        if (trnc_yn)
                            cashrcptamt = Math.Truncate(cashrcptamt / 10) * 10;

                        if (allControls.ContainsKey("txtCashRcptAmt")) ((LxTextBox)(allControls["txtCashRcptAmt"])).Text = String.Format("{0:#,##0}", cashrcptamt);
                        if (allControls.ContainsKey("txtBnacRcptAmt")) ((LxTextBox)(allControls["txtBnacRcptAmt"])).Text = "0";
                        if (allControls.ContainsKey("txtCardRcptAmt")) ((LxTextBox)(allControls["txtCardRcptAmt"])).Text = "0";
                        //if (allControls.ContainsKey("cboUnclCd")) ((LxComboBox)(allControls["cboUnclCd"])).SelectValue("NO");
                        //if (allControls.ContainsKey("txtUnclAmt")) ((LxTextBox)(allControls["txtUnclAmt"])).Text = "0";
                        //if (allControls.ContainsKey("txtUnclResn")) ((LxTextBox)(allControls["txtUnclResn"])).Text = "";

                        break;
                    case "cboUnclCd":       // 미수코드
                        if (unclamt > 0 && StringService.IsNull(unclcd))
                        {
                            LxMessage.Show("미수금액이 존재합니다. 미수코드를 선택하세요..!", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            if (allControls.ContainsKey("cboUnclCd")) ((LxComboBox)(allControls["cboUnclCd"])).SelectValue("NO");

                            if (allControls.ContainsKey("txtUnclResn"))
                            {
                                if (otptadmsdvcd.Equals("B"))
                                {
                                    ((LxTextBox)(allControls["txtUnclResn"])).Text = "";
                                }
                                else
                                {
                                    ((LxTextBox)(allControls["txtUnclResn"])).Text = "";
                                }
                            }

                            return false;
                        }

                        break;
                    case "txtUschUplmAmt": // 상한액초과금
                        if (uschuplmamt > ptsharamt)
                        {
                            LxMessage.Show("상한초과금액이 본인부담금액보다 많습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            if (allControls.ContainsKey("txtUschUplmAmt")) ((LxTextBox)(allControls["txtUschUplmAmt"])).Text = "0";
                            //return false;
                            uschuplmamt = 0;
                        }

                        // 현금영수금액부터 구한다.
                        // 현금영수금액 = 본인부담 - (상한액초과금 + 대불금액 + 기카드영수금액 + 기계좌영수금액 + 기현금영수금액
                        //                     + 기할인감액금액 + 카드영수금액 + 계좌영수금액 + 할인감액금액 + 특별할인금액
                        //                     + 미수금액 + 계약처미수적용금액 + 보증금액 + 긴급지원금액 (O 2019-03-20 SJH) + 헌혈
                        //                     + 소아결핵접촉지원금액 (X 2019-03-28 PMK) + 수납전카드승인금액 + 수납전현금승인금액 + 수납전통장승인금액 + 기카드취소영수금액
                        //                     + 기통장취소영수금액 + 기현금취소영수금액)
                        cashrcptamt = ptsharamt - (uschuplmamt + pfanamt + frtmcardrcptamt + frtmbnacrcptamt + frtmcashrcptamt
                                                 + frtmdcntrdiaamt + cardrcptamt + bnacrcptamt + dcntrdiaamt + spcldcntamt
                                                 + unclamt + cttr_uncl_aply_amt + gurnamt + emrgsuptamt + blodrdiaamt
                                                 + cardrcptamt_ing + cashrcptamt_ing + bnacrcptamt_ing + frtmcardrcptamt_c
                                                 + frtmbnacamt_c + frtmcashrcptamt_c);

                        if (trnc_yn)
                            cashrcptamt = Math.Truncate(cashrcptamt / 10) * 10;

                        if (allControls.ContainsKey("txtCashRcptAmt")) ((LxTextBox)(allControls["txtCashRcptAmt"])).Text = String.Format("{0:#,##0}", cashrcptamt);
                        if (allControls.ContainsKey("txtBnacRcptAmt")) ((LxTextBox)(allControls["txtBnacRcptAmt"])).Text = "0";
                        if (allControls.ContainsKey("txtCardRcptAmt")) ((LxTextBox)(allControls["txtCardRcptAmt"])).Text = "0";
                        //if (allControls.ContainsKey("cboUnclCd")) ((LxComboBox)(allControls["cboUnclCd"])).SelectValue("NO");
                        //if (allControls.ContainsKey("txtUnclAmt")) ((LxTextBox)(allControls["txtUnclAmt"])).Text = "0";
                        //if (allControls.ContainsKey("txtUnclResn")) ((LxTextBox)(allControls["txtUnclResn"])).Text = "";

                        break;
                    case "txtPfanAmt":     // 대불금액
                        if (pfanamt > ptsharamt)
                        {
                            LxMessage.Show("대불금액이 본인부담금액보다 많습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ((LxTextBox)(allControls["txtPfanAmt"])).Text = "0";
                            return false;
                        }

                        // 현금영수금액부터 구한다.
                        // 현금영수금액 = 본인부담 - (상한액초과금 + 대불금액 + 기카드영수금액 + 기계좌영수금액 + 기현금영수금액
                        //                     + 기할인감액금액 + 카드영수금액 + 계좌영수금액 + 할인감액금액 + 특별할인금액
                        //                     + 미수금액 + 계약처미수적용금액 + 보증금액 + 긴급지원금액 (O 2019-03-20 SJH) + 헌혈
                        //                     + 소아결핵접촉지원금액 (X 2019-03-28 PMK) + 수납전카드승인금액 + 수납전현금승인금액 + 기카드취소영수금액
                        //                     + 기통장취소영수금액 + 기현금취소영수금액)
                        cashrcptamt = ptsharamt - (uschuplmamt + pfanamt + frtmcardrcptamt + frtmbnacrcptamt + frtmcashrcptamt
                                                 + frtmdcntrdiaamt + cardrcptamt + bnacrcptamt + dcntrdiaamt + spcldcntamt
                                                 + unclamt + cttr_uncl_aply_amt + gurnamt + emrgsuptamt + blodrdiaamt
                                                 + cardrcptamt_ing + cashrcptamt_ing + bnacrcptamt_ing + frtmcardrcptamt_c
                                                 + frtmbnacamt_c + frtmcashrcptamt_c);

                        if (trnc_yn)
                            cashrcptamt = Math.Truncate(cashrcptamt / 10) * 10;

                        if (allControls.ContainsKey("txtCashRcptAmt")) ((LxTextBox)(allControls["txtCashRcptAmt"])).Text = String.Format("{0:#,##0}", cashrcptamt);
                        if (allControls.ContainsKey("txtBnacRcptAmt")) ((LxTextBox)(allControls["txtBnacRcptAmt"])).Text = "0";
                        if (allControls.ContainsKey("txtCardRcptAmt")) ((LxTextBox)(allControls["txtCardRcptAmt"])).Text = "0";
                        //if (allControls.ContainsKey("cboUnclCd")) ((LxComboBox)(allControls["cboUnclCd"])).SelectValue("NO");
                        //if (allControls.ContainsKey("txtUnclAmt")) ((LxTextBox)(allControls["txtUnclAmt"])).Text = "0";
                        //if (allControls.ContainsKey("txtUnclResn")) ((LxTextBox)(allControls["txtUnclResn"])).Text = "";

                        break;
                    case "txtVcntClamAmt": // 예방접종청구금액
                        if (vcntclamamt > ptsharamt)
                        {
                            LxMessage.Show("예방접종청구금액이 본인부담금액보다 많습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ((LxTextBox)(allControls["txtVcntClamAmt"])).Text = "0";
                            return false;
                        }

                        // 현금영수금액부터 구한다.
                        // 현금영수금액 = 본인부담 - (상한액초과금 + 대불금액 + 기카드영수금액 + 기계좌영수금액 + 기현금영수금액
                        //                     + 기할인감액금액 + 카드영수금액 + 계좌영수금액 + 할인감액금액 + 특별할인금액
                        //                     + 미수금액 + 계약처미수적용금액 + 보증금액 + 긴급지원금액 (O 2019-03-20 SJH) + 헌혈
                        //                     + 소아결핵접촉지원금액 (X 2019-03-28 PMK) + 수납전카드승인금액 + 수납전현금승인금액 + 기카드취소영수금액
                        //                     + 기통장취소영수금액 + 기현금취소영수금액)
                        cashrcptamt = ptsharamt - (uschuplmamt + pfanamt + frtmcardrcptamt + frtmbnacrcptamt + frtmcashrcptamt
                                                 + frtmdcntrdiaamt + cardrcptamt + bnacrcptamt + dcntrdiaamt + spcldcntamt
                                                 + unclamt + cttr_uncl_aply_amt + gurnamt + emrgsuptamt + blodrdiaamt
                                                 + cardrcptamt_ing + cashrcptamt_ing + bnacrcptamt_ing + frtmcardrcptamt_c
                                                 + frtmbnacamt_c + frtmcashrcptamt_c);

                        if (trnc_yn)
                            cashrcptamt = Math.Truncate(cashrcptamt / 10) * 10;

                        if (allControls.ContainsKey("txtCashRcptAmt")) ((LxTextBox)(allControls["txtCashRcptAmt"])).Text = String.Format("{0:#,##0}", cashrcptamt);
                        if (allControls.ContainsKey("txtBnacRcptAmt")) ((LxTextBox)(allControls["txtBnacRcptAmt"])).Text = "0";
                        if (allControls.ContainsKey("txtCardRcptAmt")) ((LxTextBox)(allControls["txtCardRcptAmt"])).Text = "0";
                        //if (allControls.ContainsKey("cboUnclCd")) ((LxComboBox)(allControls["cboUnclCd"])).SelectValue("NO");
                        //if (allControls.ContainsKey("txtUnclAmt")) ((LxTextBox)(allControls["txtUnclAmt"])).Text = "0";
                        //if (allControls.ContainsKey("txtUnclResn")) ((LxTextBox)(allControls["txtUnclResn"])).Text = "";

                        break;
                    /*
                case "txtVtrnAmt": // 수직감면금액
                    if (vtrdamt > ptsharamt)
                    {
                        LxMessage.Show("수직감면금액이 본인부담금액보다 많습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ((LxTextBox)(allControls["txtVtrnAmt"])).Text = "0";
                        return false;
                    }

                    // 현금영수금액부터 구한다.
                    // 현금영수금액 = 본인부담 - (상한액초과금 + 대불금액 + 기카드영수금액 + 기계좌영수금액 + 기현금영수금액
                    //                     + 기할인감액금액 + 카드영수금액 + 계좌영수금액 + 할인감액금액 + 특별할인금액
                    //                     + 미수금액 + 수직감면금액 + 보증금액 + 긴급지원금액 (X 2019-03-20 SJH)
                    //                     + 미수금액 + 계약처미수적용금액 + 보증금액 + 긴급지원금액 (O 2019-03-20 SJH)
                    //                     + 소아결핵접촉지원금액 (X 2019-03-28 PMK) + 수납전카드승인금액 + 수납전현금승인금액 + 수납전통장승인금액 + 기카드취소영수금액
                    //                     + 기통장취소영수금액 + 기현금취소영수금액)
                    cashrcptamt = ptsharamt - (uschuplmamt + pfanamt + frtmcardrcptamt + frtmbnacrcptamt + frtmcashrcptamt
                                             + frtmdcntrdiaamt + cardrcptamt + bnacrcptamt + dcntrdiaamt + spcldcntamt
                                             //+ unclamt + vtrdamt + gurnamt + emrgsuptamt
                                             + unclamt + cttr_uncl_aply_amt + gurnamt + emrgsuptamt
                                             + cardrcptamt_ing + cashrcptamt_ing + bnacrcptamt_ing + frtmcardrcptamt_c
                                             + frtmbnacamt_c + frtmcashrcptamt_c);

                    cashrcptamt = Math.Truncate(cashrcptamt / 10) * 10;

                    if (allControls.ContainsKey("txtCashRcptAmt")) ((LxTextBox)(allControls["txtCashRcptAmt"])).Text = String.Format("{0:#,##0}", cashrcptamt);
                    if (allControls.ContainsKey("txtBnacRcptAmt")) ((LxTextBox)(allControls["txtBnacRcptAmt"])).Text = "0";
                    if (allControls.ContainsKey("txtCardRcptAmt")) ((LxTextBox)(allControls["txtCardRcptAmt"])).Text = "0";
                    if (allControls.ContainsKey("cboUnclCd")) ((LxComboBox)(allControls["cboUnclCd"])).SelectValue("NO");
                    if (allControls.ContainsKey("txtUnclAmt")) ((LxTextBox)(allControls["txtUnclAmt"])).Text = "0";
                    if (allControls.ContainsKey("txtUnclResn")) ((LxTextBox)(allControls["txtUnclResn"])).Text = "";

                    break;
                     * */
                    case "txtCttrUnclAplyAmt": // 수직감면금액
                        if (cttr_uncl_aply_amt > ptsharamt)
                        {
                            // TODO : 
                            LxMessage.Show("협력지원금액이 본인부담금액보다 많습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ((LxTextBox)(allControls["txtCttrUnclAplyAmt"])).Text = "0";
                            return false;
                        }

                        // 현금영수금액부터 구한다.
                        // 현금영수금액 = 본인부담 - (상한액초과금 + 대불금액 + 기카드영수금액 + 기계좌영수금액 + 기현금영수금액
                        //                     + 기할인감액금액 + 카드영수금액 + 계좌영수금액 + 할인감액금액 + 특별할인금액
                        //                     + 미수금액 + 계약처미수적용금액 + 보증금액 + 긴급지원금액 (O 2019-03-20 SJH) + 헌혈
                        //                     + 소아결핵접촉지원금액 (X 2019-03-28 PMK) + 수납전카드승인금액 + 수납전현금승인금액 + 수납전통장승인금액 + 기카드취소영수금액
                        //                     + 기통장취소영수금액 + 기현금취소영수금액)
                        cashrcptamt = ptsharamt - (uschuplmamt + pfanamt + frtmcardrcptamt + frtmbnacrcptamt + frtmcashrcptamt
                                                 + frtmdcntrdiaamt + cardrcptamt + bnacrcptamt + dcntrdiaamt + spcldcntamt
                                                 + unclamt + cttr_uncl_aply_amt + gurnamt + emrgsuptamt + blodrdiaamt
                                                 + cardrcptamt_ing + cashrcptamt_ing + bnacrcptamt_ing + frtmcardrcptamt_c
                                                 + frtmbnacamt_c + frtmcashrcptamt_c);

                        if (trnc_yn)
                            cashrcptamt = Math.Truncate(cashrcptamt / 10) * 10;

                        if (allControls.ContainsKey("txtCashRcptAmt")) ((LxTextBox)(allControls["txtCashRcptAmt"])).Text = String.Format("{0:#,##0}", cashrcptamt);
                        if (allControls.ContainsKey("txtBnacRcptAmt")) ((LxTextBox)(allControls["txtBnacRcptAmt"])).Text = "0";
                        if (allControls.ContainsKey("txtCardRcptAmt")) ((LxTextBox)(allControls["txtCardRcptAmt"])).Text = "0";
                        //if (allControls.ContainsKey("cboUnclCd")) ((LxComboBox)(allControls["cboUnclCd"])).SelectValue("NO");
                        //if (allControls.ContainsKey("txtUnclAmt")) ((LxTextBox)(allControls["txtUnclAmt"])).Text = "0";
                        //if (allControls.ContainsKey("txtUnclResn")) ((LxTextBox)(allControls["txtUnclResn"])).Text = "";

                        break;
                    case "txtEmrgSuptAmt":  // 긴급지원금액                        
                    case "txtGurnAmt":      // 보증금액
                    case "txtBlodRdiaAmt":  // 헌혈감액
                        if (ctl.Name == "txtEmrgSuptAmt")
                        {
                            if (emrgsuptamt > ptsharamt)
                            {
                                LxMessage.Show("긴급지원금액이 본인부담금액보다 많습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                ((LxTextBox)(allControls["txtEmrgSuptAmt"])).Text = "0";
                                return false;
                            }
                        }
                        else if (ctl.Name == "txtGurnAmt")
                        {
                            if (gurnamt > ptsharamt)
                            {
                                LxMessage.Show("보증금액이 본인부담금액보다 많습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                ((LxTextBox)(allControls["txtGurnAmt"])).Text = "0";
                                return false;
                            }
                        }
                        else if (ctl.Name == "txtBlodRdiaAmt")
                        {
                            if (blodrdiaamt > ptsharamt)
                            {
                                LxMessage.Show("헌혈감액금액이 본인부담금액보다 많습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                ((LxTextBox)(allControls["txtBlodRdiaAmt"])).Text = "0";
                                return false;
                            }
                        }

                        // 현금영수금액부터 구한다.
                        // 현금영수금액 = 본인부담 - (상한액초과금 + 대불금액 + 기카드영수금액 + 기계좌영수금액 + 기현금영수금액
                        //                     + 기할인감액금액 + 카드영수금액 + 계좌영수금액 + 할인감액금액 + 특별할인금액
                        //                     + 미수금액 + 계약처미수적용금액 + 보증금액 + 긴급지원금액 (O 2019-03-20 SJH) + 헌혈
                        //                     + 소아결핵접촉지원금액 (X 2019-03-28 PMK) + 수납전카드승인금액 + 수납전현금승인금액 + 수납전통장승인금액 + 기카드취소영수금액
                        //                     + 기통장취소영수금액 + 기현금취소영수금액)
                        cashrcptamt = ptsharamt - (uschuplmamt + pfanamt + frtmcardrcptamt + frtmbnacrcptamt + frtmcashrcptamt
                                                 + frtmdcntrdiaamt + cardrcptamt + bnacrcptamt + dcntrdiaamt + spcldcntamt
                                                 + unclamt + cttr_uncl_aply_amt + gurnamt + emrgsuptamt + blodrdiaamt
                                                 + cardrcptamt_ing + cashrcptamt_ing + bnacrcptamt_ing + frtmcardrcptamt_c
                                                 + frtmbnacamt_c + frtmcashrcptamt_c);

                        if (trnc_yn)
                            cashrcptamt = Math.Truncate(cashrcptamt / 10) * 10;

                        if (allControls.ContainsKey("txtCashRcptAmt")) ((LxTextBox)(allControls["txtCashRcptAmt"])).Text = String.Format("{0:#,##0}", cashrcptamt);
                        if (allControls.ContainsKey("txtBnacRcptAmt")) ((LxTextBox)(allControls["txtBnacRcptAmt"])).Text = "0";
                        if (allControls.ContainsKey("txtCardRcptAmt")) ((LxTextBox)(allControls["txtCardRcptAmt"])).Text = "0";
                        //if (allControls.ContainsKey("cboUnclCd")) ((LxComboBox)(allControls["cboUnclCd"])).SelectValue("NO");
                        //if (allControls.ContainsKey("txtUnclAmt")) ((LxTextBox)(allControls["txtUnclAmt"])).Text = "0";
                        //if (allControls.ContainsKey("txtUnclResn")) ((LxTextBox)(allControls["txtUnclResn"])).Text = "";

                        break;
                }
                return true;
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);

                return false;
            }
        }


        /// <summary>
        /// 본인부담적용코드를 체크한다.
        /// </summary>
        /// <param name="pid">환자등록번호</param>
        /// <param name="mdcrdeptcd">진료부서</param>
        /// <param name="mdcrdd">진료일자/param>
        /// <param name="uschaplycd">본인부담적용코드</param>
        /// <param name="cmhsdvcd">내원구분코드</param>
        /// <param name="sbrdntype">공단본인부담적용코드</param></param>
        /// <param name="ykiho1">선택요양기관기호1</param>
        /// <param name="ykiho2">선택요양기관기호2</param>
        /// <param name="ykiho3">선택요양기관기호3</param>
        /// <param name="ykiho4">선택요양기관기호4</param>
        /// <param name="refuschaplycd"></param>
        /// <param name="referror"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static CheckUschAplyCd(pid:string, mdcrdeptcd:string, mdcrdd:string, uschaplycd:string, cmhsdvcd:string, sbrdntype:string, ykiho1:string, ykiho2:string, ykiho3:string, ykiho4:string, refuschaplycd:string, referror:string, msg:string)
        {
            try
            {
                // 2019-09-16 SJH 의뢰서 작성하지 않기 때문에 옵션처리 함
                let checkPAMDRFMAYn:boolean = ConfigService.GetConfigValueBool("PA", "USCH_APLY_CD", "CHECK_PAMDRFMA_YN", false);

                let ykiho:string = String.Empty;    // 본원 요양기관기호
                let selectyn:string = String.Empty; // 본원 요양기관기호 동일한지 여부
                let uschcd:string = String.Empty;   // 본인부담코드
                let cnt:number = 0;                 // 의뢰시 등록 여부
                ykiho = DOPack.HospitalInfo.HPTL_RGNO_CD;
                if (uschaplycd.Length.Equals(4) && (uschaplycd.Substring(0, 1).Equals("M") || uschaplycd.Substring(0, 1).Equals("B")) && !cmhsdvcd.Equals("G"))
                {
                    ykiho1 = StringService.IsNvl(ykiho1, " ");
                    ykiho2 = StringService.IsNvl(ykiho2, " ");
                    ykiho3 = StringService.IsNvl(ykiho3, " ");
                    ykiho4 = StringService.IsNvl(ykiho4, " ");

                    if (!ykiho.Equals(ykiho1) && !ykiho.Equals(ykiho2) && !ykiho.Equals(ykiho3) && !ykiho.Equals(ykiho4))
                    {
                        selectyn = "N";
                    }
                    else
                    {
                        selectyn = "Y";
                    }

                    if (sbrdntype.Equals("M003") || sbrdntype.Equals("M004") || sbrdntype.Equals("M005") || sbrdntype.Equals("M006") ||
                       sbrdntype.Equals("M015") || sbrdntype.Equals("M016") || sbrdntype.Equals("M017") || sbrdntype.Equals("M007") ||
                       sbrdntype.Equals("M008") || (sbrdntype.Equals("M012") && !mdcrdeptcd.Equals("NO")))
                    {
                        if (!uschaplycd.Equals(sbrdntype))
                        {
                            msg = "본인부담 면제자입니다. 보험공단에서 조회된 본인부담여부코드를 사용하십시오.!\r\n" +
                                  "본인부담여부코드 : " + sbrdntype;
                            refuschaplycd = sbrdntype;
                            referror = "ERROR";
                            return -1;
                        }
                    }

                    //의료급여 2종 임산부 및 조산아
                    if (sbrdntype.Equals("B011"))
                    {
                        if (!uschaplycd.Equals(sbrdntype))
                        {
                            msg = "등록조산아 및 저체중 출산아 2종 적용자입니다. 보험공단에서 조회된 본인부담여부코드를 사용하십시오.!\r\n" +
                                  "본인부담여부코드 : " + sbrdntype;
                            refuschaplycd = sbrdntype;
                            referror = "ERROR";
                            return -1;
                        }
                    }

                    if (sbrdntype.Equals("M001") || sbrdntype.Equals("M002") || (sbrdntype.Equals("M012") && !mdcrdeptcd.Equals("NO")))
                    {
                        if (selectyn.Equals("Y"))
                        {
                            if (!uschaplycd.Equals(sbrdntype))
                            {
                                msg = "본원을 선택한 선택기관1종 적용자입니다. 보험공단에서 조회된 본인부담여부코드를 사용하십시오.!\r\n" +
                                     "본인부담여부코드 : " + sbrdntype;
                                refuschaplycd = sbrdntype;
                                referror = "ERROR";
                                return -1;
                            }
                        }
                        else
                        {
                            if (!uschaplycd.Equals("M009") && !uschaplycd.Equals("M010") && !uschaplycd.Equals("M013") && !uschaplycd.Equals("M014") &&
                                !uschaplycd.Equals("B005") && !uschaplycd.Equals("B006") && !uschaplycd.Equals("B007") && !uschaplycd.Equals("B008") &&
                                !uschaplycd.Equals("B009") && !uschaplycd.Equals("B099"))
                            {
                                if (mdcrdeptcd.Equals("NO"))
                                {
                                    LxMessage.ShowInformation("선택기관 적용자이지만 본원을 선택기관으로 하지 않았습니다. 아래 본인부담코드에서 선택하세요.\r\n\r\n" +
                                                   "  [M009] 응급환자인 1종환자\r\n" +
                                                   "  [M010] 장애인보장구 지급는 1종환자\r\n" +
                                                   "  [B005] 선택기관에서 의뢰된 환자1,2종\r\n" +
                                                   "  [B006] 선택기관에서 의뢰되어 제의뢰된 환자1,2종\r\n" +
                                                   "  [B007] 촉탁의 진료환자 1,2종\r\n" +
                                                   "  [B008] 한의원 또는 치과의원에서 진료받은자1,2종\r\n" +
                                                   "  [B009] 선택의료급여기관 적용자로 의료급여 의뢰서를\r\n            제출한 것으로 갈음하는자1,2종\r\n\r\n" +
                                                   " 위 코드 외의 경우는 본인100%로 접수하시기 바랍니다.");
                                    refuschaplycd = "M009";
                                    referror = "ERROR";
                                }
                                else
                                {
                                    if (!mdcrdeptcd.Equals("2400"))
                                    {
                                        cnt = DBService.ExecuteInteger(SQL.PA.Sql.SelectCountIsMdcrRefer(), pid
                                                                                                          , mdcrdeptcd
                                                                                                          , ykiho1
                                                                                                          , ykiho2
                                                                                                          , ykiho3
                                                                                                          , ykiho4
                                                                                                          , mdcrdd);
                                        if (cnt < 0)
                                        {
                                            msg = "의뢰서정보를 조회 중 오류 발생.";
                                            return -2;
                                        }
                                        referror = "ERROR";
                                        if (cnt > 0)
                                        {
                                            uschcd = "B005";
                                        }
                                        else
                                        {
                                            uschcd = DBService.ExecuteScalar(SQL.PA.Sql.SelectUschAplyCdOfPAOPATRT(), pid
                                                                                                                    , mdcrdeptcd
                                                                                                                    , mdcrdd).ToString();

                                            if (DBService.HasError)
                                            {
                                                LxMessage.Show("과거진료 정보 조회중 오류 발생. [" + DBService.ErrorCode + "]" + DBService.ErrorMessage);
                                                return -3;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        uschcd = "M009";  // 응급실의 경우
                                    }

                                    switch (uschcd)
                                    {
                                        case "B005":
                                            refuschaplycd = "B005";
                                            break;
                                        case "B008":
                                            refuschaplycd = "B008";
                                            break;
                                        case "M009":
                                            refuschaplycd = "M009";
                                            break;
                                        default:
                                            refuschaplycd = "B009";
                                            break;
                                    }
                                }
                                return 1;
                            }
                        }
                    }

                    if (sbrdntype.Equals("M012"))
                    {
                        if (!uschaplycd.Equals("M013"))
                        {
                            LxMessage.Show("노숙인 지정병원이 아닙니다. \r\n " +
                                            "응급환자인 노숙인 1종       M013 으로 처리하세요! \r\n" +
                                            "만약 여기에 해당되지 않으면 보험100%로 접수하세요...",
                                            "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            refuschaplycd = "M013";
                            referror = "ERROR";
                            return 1;
                        }
                    }

                    if (sbrdntype.Equals("B001") || sbrdntype.Equals("B002"))
                    {
                        if (selectyn.Equals("Y"))
                        {
                            if (!uschaplycd.Equals(sbrdntype))
                            {
                                msg = "본원을 선택한 선택기관2종 적용자입니다. 보험공단에서 조회된 본인부담여부코드를 사용하십시오.!\r\n" +
                                     "본인부담여부코드 : " + sbrdntype;
                                refuschaplycd = sbrdntype;
                                referror = "ERROR";
                                return -1;
                            }
                        }
                        else
                        {
                            if (!uschaplycd.Equals("B003") && !uschaplycd.Equals("B004") && !uschaplycd.Equals("B005") && !uschaplycd.Equals("B006") &&
                                !uschaplycd.Equals("B007") && !uschaplycd.Equals("B008") && !uschaplycd.Equals("B009") && !uschaplycd.Equals("B099"))
                            {
                                if (mdcrdeptcd.Equals("NO"))
                                {
                                    LxMessage.ShowInformation("선택기관 적용자이지만 본원을 선택기관으로 하지 않았습니다. 아래 본인부담코드에서 선택하세요.\r\n\r\n" +
                                                   "  [B003] 응급환자인 2종환자\r\n" +
                                                   "  [B004] 장애인보장구 지급는 2종환자\r\n" +
                                                   "  [B005] 선택기관에서 의뢰된 환자1,2종\r\n" +
                                                   "  [B006] 선택기관에서 의뢰되어 제의뢰된 환자1,2종\r\n" +
                                                   "  [B007] 촉탁의 진료환자 1,2종\r\n" +
                                                   "  [B008] 한의원 또는 치과의원에서 진료받은자1,2종\r\n" +
                                                   "  [B009] 선택의료급여기관 적용자로 의료급여 의뢰서를\r\n            제출한 것으로 갈음하는자1,2종\r\n\r\n" +
                                                   " 위 코드 외의 경우는 본인100%로 접수하시기 바랍니다.");
                                    refuschaplycd = "B003";
                                    referror = "ERROR";
                                }
                                else
                                {
                                    if (!mdcrdeptcd.Equals("2400"))
                                    {
                                        // 의뢰서 작성을 하는 경우와 작성하지 않는 경우를 나눔.
                                        if (checkPAMDRFMAYn)
                                        {
                                            cnt = DBService.ExecuteInteger(SQL.PA.Sql.SelectCountIsMdcrRefer(), pid
                                                                                                              , mdcrdeptcd
                                                                                                              , ykiho1
                                                                                                              , ykiho2
                                                                                                              , ykiho3
                                                                                                              , ykiho4
                                                                                                              , mdcrdd);
                                            if (cnt < 0)
                                            {
                                                msg = "의뢰서정보를 조회 중 오류 발생.";
                                                return -2;
                                            }
                                            referror = "ERROR";
                                            if (cnt > 0)
                                            {
                                                uschcd = "B005";
                                            }
                                            else
                                            {
                                                uschcd = DBService.ExecuteScalar(SQL.PA.Sql.SelectUschAplyCdOfPAOPATRT(), pid
                                                                                                                        , mdcrdeptcd
                                                                                                                        , mdcrdd).ToString();

                                                if (DBService.HasError)
                                                {
                                                    LxMessage.Show("과거진료 정보 조회중 오류 발생. [" + DBService.ErrorCode + "]" + DBService.ErrorMessage);
                                                    return -3;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            // 의뢰서를 작성하지 않는 경우 Default값을 B005로 하자.
                                            referror = "ERROR";
                                            uschcd = "B005";
                                        }
                                    }
                                    else
                                    {
                                        uschcd = "M003";  // 응급실의 경우
                                    }

                                    switch (uschcd)
                                    {
                                        case "B005":
                                            refuschaplycd = "B005";
                                            break;
                                        case "B008":
                                            refuschaplycd = "B008";
                                            break;
                                        case "B003":
                                            refuschaplycd = "B003";
                                            break;
                                        default:
                                            refuschaplycd = "B009";
                                            break;
                                    }
                                }

                                return 1;
                            }
                        }
                    }

                    if (uschaplycd.Substring(0, 1).Equals("M") && !sbrdntype.Substring(0, 1).Equals("M"))
                    {
                        LxMessage.Show("보험공단 조회시 본인부담 면제자가 아닙니다. 본인부담여부코드 " + uschaplycd + " 는 사용할 수 없습니다.",
                                       "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        refuschaplycd = sbrdntype;
                        referror = "ERROR";
                        return 1;
                    }
                }
                else if (uschaplycd.Length < 4)
                {
                    ykiho1 = StringService.IsNvl(ykiho1, " ");
                    ykiho2 = StringService.IsNvl(ykiho2, " ");
                    ykiho3 = StringService.IsNvl(ykiho3, " ");
                    ykiho4 = StringService.IsNvl(ykiho4, " ");

                    // 선택병원중 본원의 요양기호가 존재하는지 확인한다.
                    if (!ykiho.Equals(ykiho1) && !ykiho.Equals(ykiho2) && !ykiho.Equals(ykiho3) && !ykiho.Equals(ykiho4))
                    {
                        selectyn = "N";
                    }
                    else
                    {
                        selectyn = "Y";
                    }

                    if (sbrdntype.Equals("M003") || sbrdntype.Equals("M004") || sbrdntype.Equals("M005") || sbrdntype.Equals("M006") ||
                       sbrdntype.Equals("M015") || sbrdntype.Equals("M016") || sbrdntype.Equals("M017") || sbrdntype.Equals("M007") ||
                       sbrdntype.Equals("M008") || (sbrdntype.Equals("M012") && !mdcrdeptcd.Equals("NO")))
                    {
                        if (!uschaplycd.Equals(sbrdntype))
                        {
                            msg = "본인부담 면제자입니다. 보험공단에서 조회된 본인부담여부코드를 사용하십시오.!\r\n" +
                                  "본인부담여부코드 : " + sbrdntype;
                            refuschaplycd = sbrdntype;
                            referror = "ERROR";
                            return -1;
                        }
                    }

                    //의료급여 2종 임산부 및 조산아
                    if (sbrdntype.Equals("B011"))
                    {
                        if (!uschaplycd.Equals(sbrdntype))
                        {
                            msg = "등록조산아 및 저체중 출산아 2종 적용자입니다. 보험공단에서 조회된 본인부담여부코드를 사용하십시오.!\r\n" +
                                  "본인부담여부코드 : " + sbrdntype;
                            refuschaplycd = sbrdntype;
                            referror = "ERROR";
                            return -1;
                        }
                    }

                    if (sbrdntype.Equals("M001") || sbrdntype.Equals("M002") || (sbrdntype.Equals("M012") && !mdcrdeptcd.Equals("NO")))
                    {
                        if (selectyn.Equals("Y"))
                        {
                            if (!uschaplycd.Equals(sbrdntype))
                            {
                                msg = "본원을 선택한 선택기관1종 적용자입니다. 보험공단에서 조회된 본인부담여부코드를 사용하십시오.!\r\n" +
                                     "본인부담여부코드 : " + sbrdntype;
                                refuschaplycd = sbrdntype;
                                referror = "ERROR";
                                return -1;
                            }
                        }
                        else
                        {
                            if (!uschaplycd.Equals("M009") && !uschaplycd.Equals("M010") && !uschaplycd.Equals("M013") && !uschaplycd.Equals("M014") &&
                                !uschaplycd.Equals("B005") && !uschaplycd.Equals("B006") && !uschaplycd.Equals("B007") && !uschaplycd.Equals("B008") &&
                                !uschaplycd.Equals("B009") && !uschaplycd.Equals("B099"))
                            {
                                if (mdcrdeptcd.Equals("NO"))
                                {
                                    LxMessage.ShowInformation("선택기관 적용자이지만 본원을 선택기관으로 하지 않았습니다. 아래 본인부담코드에서 선택하세요.\r\n\r\n" +
                                                   "  [M009] 응급환자인 1종환자\r\n" +
                                                   "  [M010] 장애인보장구 지급는 1종환자\r\n" +
                                                   "  [B005] 선택기관에서 의뢰된 환자1,2종\r\n" +
                                                   "  [B006] 선택기관에서 의뢰되어 제의뢰된 환자1,2종\r\n" +
                                                   "  [B007] 촉탁의 진료환자 1,2종\r\n" +
                                                   "  [B008] 한의원 또는 치과의원에서 진료받은자1,2종\r\n" +
                                                   "  [B009] 선택의료급여기관 적용자로 의료급여 의뢰서를\r\n            제출한 것으로 갈음하는자1,2종\r\n\r\n" +
                                                   " 위 코드 외의 경우는 본인100%로 접수하시기 바랍니다.");
                                    refuschaplycd = "M009";
                                    referror = "ERROR";
                                }
                                else
                                {
                                    if (!mdcrdeptcd.Equals("2400"))
                                    {
                                        // 의뢰서 작성을 하는 경우와 작성하지 않는 경우를 나눔.
                                        if (checkPAMDRFMAYn)
                                        {
                                            cnt = DBService.ExecuteInteger(SQL.PA.Sql.SelectCountIsMdcrRefer(), pid
                                                                                                              , mdcrdeptcd
                                                                                                              , ykiho1
                                                                                                              , ykiho2
                                                                                                              , ykiho3
                                                                                                              , ykiho4
                                                                                                              , mdcrdd);
                                            if (cnt < 0)
                                            {
                                                msg = "의뢰서정보를 조회 중 오류 발생.";
                                                return -2;
                                            }
                                            referror = "ERROR";
                                            if (cnt > 0)
                                            {
                                                uschcd = "B005";
                                            }
                                            else
                                            {
                                                uschcd = DBService.ExecuteScalar(SQL.PA.Sql.SelectUschAplyCdOfPAOPATRT(), pid
                                                                                                                        , mdcrdeptcd
                                                                                                                        , mdcrdd).ToString();

                                                if (DBService.HasError)
                                                {
                                                    LxMessage.Show("과거진료 정보 조회중 오류 발생. [" + DBService.ErrorCode + "]" + DBService.ErrorMessage);
                                                    return -3;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            // 의뢰서를 작성하지 않는 경우 Default값을 B005로 하자.
                                            referror = "ERROR";
                                            uschcd = "B005";
                                        }
                                    }
                                    else
                                    {
                                        uschcd = "M009";  // 응급실의 경우
                                    }

                                    switch (uschcd)
                                    {
                                        case "B005":
                                            refuschaplycd = "B005";
                                            break;
                                        case "B008":
                                            refuschaplycd = "B008";
                                            break;
                                        case "M009":
                                            refuschaplycd = "M009";
                                            break;
                                        default:
                                            refuschaplycd = "B009";
                                            break;
                                    }
                                }
                                return 1;
                            }
                        }
                    }

                    if (sbrdntype.Equals("M012"))
                    {
                        if (!uschaplycd.Equals("M013"))
                        {
                            LxMessage.Show("노숙인 지정병원이 아닙니다. \r\n " +
                                            "응급환자인 노숙인 1종       M013 으로 처리하세요! \r\n" +
                                            "만약 여기에 해당되지 않으면 보험100%로 접수하세요...",
                                            "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            refuschaplycd = "M013";
                            referror = "ERROR";
                            return 1;
                        }
                    }

                    if (sbrdntype.Equals("B001") || sbrdntype.Equals("B002"))
                    {
                        if (selectyn.Equals("Y"))
                        {
                            if (!uschaplycd.Equals(sbrdntype))
                            {
                                msg = "본원을 선택한 선택기관2종 적용자입니다. 보험공단에서 조회된 본인부담여부코드를 사용하십시오.!\r\n" +
                                     "본인부담여부코드 : " + sbrdntype;
                                refuschaplycd = sbrdntype;
                                referror = "ERROR";
                                return -1;
                            }
                        }
                        else
                        {
                            if (!uschaplycd.Equals("B003") && !uschaplycd.Equals("B004") && !uschaplycd.Equals("B005") && !uschaplycd.Equals("B006") &&
                                !uschaplycd.Equals("B007") && !uschaplycd.Equals("B008") && !uschaplycd.Equals("B009") && !uschaplycd.Equals("B099"))
                            {
                                if (mdcrdeptcd.Equals("NO"))
                                {
                                    LxMessage.ShowInformation("선택기관 적용자이지만 본원을 선택기관으로 하지 않았습니다. 아래 본인부담코드에서 선택하세요.\r\n\r\n" +
                                                   "  [B003] 응급환자인 2종환자\r\n" +
                                                   "  [B004] 장애인보장구 지급는 2종환자\r\n" +
                                                   "  [B005] 선택기관에서 의뢰된 환자1,2종\r\n" +
                                                   "  [B006] 선택기관에서 의뢰되어 제의뢰된 환자1,2종\r\n" +
                                                   "  [B007] 촉탁의 진료환자 1,2종\r\n" +
                                                   "  [B008] 한의원 또는 치과의원에서 진료받은자1,2종\r\n" +
                                                   "  [B009] 선택의료급여기관 적용자로 의료급여 의뢰서를\r\n            제출한 것으로 갈음하는자1,2종\r\n\r\n" +
                                                   " 위 코드 외의 경우는 본인100%로 접수하시기 바랍니다.");
                                    refuschaplycd = "B003";
                                    referror = "ERROR";
                                }
                                else
                                {
                                    if (!mdcrdeptcd.Equals("2400"))
                                    {
                                        cnt = DBService.ExecuteInteger(SQL.PA.Sql.SelectCountIsMdcrRefer(), pid
                                                                                                          , mdcrdeptcd
                                                                                                          , ykiho1
                                                                                                          , ykiho2
                                                                                                          , ykiho3
                                                                                                          , ykiho4
                                                                                                          , mdcrdd);
                                        if (cnt < 0)
                                        {
                                            msg = "의뢰서정보를 조회 중 오류 발생.";
                                            return -12;
                                        }
                                        referror = "ERROR";
                                        if (cnt > 0)
                                        {
                                            uschcd = "B005";
                                        }
                                        else
                                        {
                                            uschcd = DBService.ExecuteScalar(SQL.PA.Sql.SelectUschAplyCdOfPAOPATRT(), pid
                                                                                                                    , mdcrdeptcd
                                                                                                                    , mdcrdd).ToString();

                                            if (DBService.HasError)
                                            {
                                                LxMessage.Show("과거진료 정보 조회중 오류 발생. [" + DBService.ErrorCode + "]" + DBService.ErrorMessage);
                                                return -13;
                                            }
                                        }

                                    }
                                    else
                                    {
                                        uschcd = "M003";  // 응급실의 경우
                                    }
                                    switch (uschcd)
                                    {
                                        case "B005":
                                            refuschaplycd = "B005";
                                            break;
                                        case "B008":
                                            refuschaplycd = "B008";
                                            break;
                                        case "B003":
                                            refuschaplycd = "B003";
                                            break;
                                        default:
                                            refuschaplycd = "B009";
                                            break;
                                    }
                                }

                                return 1;
                            }
                        }
                    }
                }
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                return -100;
            }

            return 1;
        }

        public static CheckNhicCancer(pid:string, mdcrdd:string, disregprson2:string, disregprson4:string, disregprson5:string, disregprson9:string, preinfant:string, disregprson12:string, refchk:string, refmsg:string)
        {
            try
            {
                let msg:string = String.Empty;

                let dt:DataTable = new DataTable();

                if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAPSDSMAtoCompare(), dt, pid
                                                                                          , mdcrdd))
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            if (row["SEVR_DVCD"].ToString().Equals("1"))            // 암
                            {
                                if (!StringService.PadRight(disregprson4, 4).Substring(0, 4).Equals("V193"))
                                {
                                    msg += "1.병원에 등록된 [암중증정보]가 존재하지만, 공단 자격정보에는 존재하지 않습니다. \r\n";
                                }
                            }
                            else if (row["SEVR_DVCD"].ToString().Equals("2"))            // 심장질환
                            {
                                if (!StringService.PadRight(disregprson4, 4).Substring(0, 4).Equals("V192"))
                                {
                                    msg += "2.병원에 등록된 [심장질환정보]가 존재하지만, 공단 자격정보에는 존재하지 않습니다. \r\n";
                                }
                            }
                            else if (row["SEVR_DVCD"].ToString().Equals("3"))            // 뇌혈관질환
                            {
                                if (!StringService.PadRight(disregprson4, 4).Substring(0, 4).Equals("V191"))
                                {
                                    msg += "3.병원에 등록된 [뇌혈관질환정보]가 존재하지만, 공단 자격정보에는 존재하지 않습니다. \r\n";
                                }
                            }
                            else if (row["SEVR_DVCD"].ToString().Equals("4"))            // 기타산정특례
                            {
                                if (!StringService.PadRight(disregprson2, 1).Substring(0, 1).Equals("V"))
                                {
                                    if (StringService.PadRight(disregprson9, 15).Substring(0, 1).Equals("V") && StringService.PadRight(disregprson9, 15).Substring(4, 15).Trim().Equals(row["SEVR_NO"].ToString().Trim()))
                                    {

                                    }
                                    else
                                    {
                                        msg += "4.병원에 등록된 [기타산정특례정보]가 존재하지만, 공단 자격정보에는 존재하지 않습니다. \r\n";
                                    }
                                }
                            }
                            else if (row["SEVR_DVCD"].ToString().Equals("5"))            // 중증화상
                            {
                                if (!StringService.PadRight(disregprson5, 1).Substring(0, 1).Equals("V"))
                                {
                                    msg += "5.병원에 등록된 [중증화상정보]가 존재하지만, 공단 자격정보에는 존재하지 않습니다. \r\n";
                                }
                            }
                            else if (row["SEVR_DVCD"].ToString().Equals("C"))            // 결핵산정특례
                            {
                                if (StringService.IsNotNull(disregprson12))
                                {
                                    if (!disregprson12.Substring(4, 10).Trim().Equals(row["SEVR_NO"].ToString().Trim()))
                                    {
                                        msg += "C.병원에 등록된 [결핵산정특례정보]가 존재하지만, 공단 자격정보에는 존재하지 않습니다. \r\n";
                                    }
                                    else
                                    {
                                        if ((StringService.PadRight(disregprson9, 15).Substring(0, 4).Equals("V000") && StringService.PadRight(disregprson9, 15).Substring(4, 2).Equals("08")) &&
                                           (!row["VCODE_CD"].ToString().Equals("V000") && row["SEVR_NO"].ToString().Substring(0, 2).Equals("05")))
                                        {
                                            msg += "C.최근 공단 자격정보[결핵산정특례정보(2016.07.01시행)]입니다. \r\n 병원에 등록된 [결핵산정특례정보]의 종료유무를 확인하세요. \r\n";
                                        }
                                        else if (!StringService.PadRight(disregprson9, 15).Substring(0, 4).Trim().Equals("V"))
                                        {
                                            msg += "C.병원에 등록된 [결핵산정특례정보]가 존재하지만, 공단 자격정보에는 존재하지 않습니다. \r\n";
                                        }
                                    }
                                }
                            }
                            else if (row["SEVR_DVCD"].ToString().Equals("P"))            // 조산아 및 저체중출생아
                            {
                                if (!StringService.PadRight(preinfant, 10).Substring(0, 10).Equals(row["SEVR_NO"].ToString()))
                                {
                                    msg += "P.병원에 등록된 [조산아 및 저체중출생아정보]가 존재하지만, 공단 자격정보에는 존재하지 않습니다. \r\n";
                                }
                            }
                        }
                    }
                    if (msg.Length > 1)
                    {
                        refchk = "Y";
                        refmsg = msg + " ** 보험팀에 암중증정보나 산정특례정보를 확인하고 처리하시기 바랍니다.!";
                    }
                }
                else
                {
                    throw new Exception(String.Format("{0} {1}", DBService.ErrorCode, DBService.ErrorMessage));

                }
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[CheckNhicCancer ] 오류내용 : " + ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 가산본인부담률 체크
        /// </summary>
        /// <param name="startdate"></param>
        /// <param name="enddate"></param>
        /// <param name="admsdate"></param>
        /// <param name="insn_tycd"></param>
        /// <param name="asst_tycd"></param>
        /// <param name="drg_yn"></param>
        /// <param name="vtrn_pt_yn"></param>
        /// <param name="momr_age_dvcd"></param>
        /// <param name="indp_momr_yn"></param>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <returns></returns>
        public static Check_MainDiag_Opinion(DateTime startdate, DateTime enddate, DateTime admsdate, string insn_tycd, string asst_tycd
                                                  , string drg_yn, string vtrn_pt_yn, string momr_age_dvcd, string indp_momr_yn, string pid
                                                  , string pt_cmhs_no)
        {
            //일단 막아둔다!!! - 병원요청
            //TimeSpan ts_start = startdate - admsdate;
            //TimeSpan ts_end = enddate - admsdate;
            //int start = 1;
            //int end = 1;

            //if (ts_start.Days < 15)
            //    start = 1;
            //else if (ts_start.Days >= 15 && ts_start.Days < 30)
            //    start = 16;
            //else if (ts_start.Days >= 30)
            //    start = 31;

            //if (ts_end.Days < 15)
            //    end = 1;
            //else if (ts_end.Days >= 15 && ts_end.Days < 30)
            //    end = 16;
            //else if (ts_end.Days >= 30)
            //    end = 31;

            ////기간에 따라 본인부담율이 틀린경우!!
            //if (start != end)
            //{
            //    Lime.Framework.CommonClass.clsCommon common = new Framework.CommonClass.clsCommon();

            //    if (common.Check_MainDiag_Opinion(admsdate, insn_tycd, asst_tycd, drg_yn, vtrn_pt_yn
            //                                    , momr_age_dvcd, indp_momr_yn, pid, pt_cmhs_no, "I") != "N")
            //    {
            //        return "입원료 본인부담 증감대상자입니다.\r\n입원료 본인부담율이 다른 기간은 반드시 분리 등록하세요.";                    
            //    }
            //}

            return String.Empty;
        }

        /// <summary>
        /// 병원옵션관리에서 현재 선택된 병동이 [간호간병통합서비스여부='Y']인 병동인지 확인
        /// </summary>
        /// <returns></returns>
        public static GetWardNurseSystemExist(wardcd:string)
        {
            let tempDt:DataTable = new DataTable();
            DBService.ExecuteDataTable(SQL.PA.Sql.SelectNurseSystemYNEqualsY(), tempDt, wardcd);

            if (tempDt.Rows.Count.Equals(0))
                return "N";

            return "Y";
        }

        /// <summary>
        /// 선택한 병실의 유효성 체크
        /// </summary>
        /// <param name="mainsub"></param>
        /// <param name="pid"></param>
        /// <param name="wardcd"></param>
        /// <param name="roomcd"></param>
        /// <param name="chekdd"></param>
        /// <param name="bedno"></param>
        /// <param name="isReserved"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static ValidationSelectRoom(mainsub:string, pid:string, wardcd:string, roomcd:string, chekdd:string, bedno:string, isReserved:boolean, msg:string)
        {
            // 주입원의 경우만 체크함
            if (!mainsub.Equals("J"))
                return true;

            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++
            // 입원등록하려는 환자가 병실 예약이 되어있는 환자인지 체크
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++
            let tempdt:DataTable = new DataTable();
            DBService.ExecuteDataTable(SQL.PA.Sql.CheckThisPatientRoomReserved(), tempdt, pid);
            if (!tempdt.Rows.Count.Equals(0))
            {
                // 예약된 환자의 경우

                // 입실시간을 Update
                isReserved = true;
            }
            else
            {
                // 예약되지 않은 환자의 경우

                // 선택한 병실에 예약이 존재하는지 체크
                tempdt = new DataTable();
                DBService.ExecuteDataTable(SQL.PA.Sql.CheckThisRoomReserved(), tempdt, wardcd, roomcd, bedno);
                if (!tempdt.Rows.Count.Equals(0))
                {
                    // 선택한 병실에 예약이 존재하는 경우

                    if (!LxMessage.ShowQuestion("선택하신 병실에는 예약정보가 존재합니다.\r\n그래도 저장 하시겠습니까?").Equals(DialogResult.Yes))
                    {
                        msg = "저장을 취소합니다.";
                        return false;
                    }
                }
            }

            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++
            // 병원옵션관리에서 잔여병상이 있는 병원만 입원등록가능한지의 여부를 가져옴
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++
            let remainRoom:boolean = ConfigService.GetConfigValueBool("PA", "ADMS_REG_ROOM", "APLY_YN");
            if (remainRoom)
            {
                // 선택한 병실에 잔여병상이 있는지 확인
                let dt:DataTable = new DataTable();
                DBService.ExecuteDataTable(SQL.PA.Sql.SelectRoomStatus(), dt, wardcd, chekdd);
                dt.DefaultView.RowFilter = String.Format(" ROOM_CD = '{0}' ", roomcd);
                dt = dt.DefaultView.ToTable();

                if (dt.Rows.Count.Equals(0))
                {
                    msg = "병실 정보 취득에 실패하였습니다.";
                    return false;
                }

                let bassbedcnt:number = -1;
                let sthscnt:number = -1;
                Int.TryParse(dt.Rows[0]["BASS_BED_CNT"].ToString(), bassbedcnt);
                Int.TryParse(dt.Rows[0]["STHS_CNT"].ToString(), sthscnt);

                // 잔여병상수
                if ((bassbedcnt - sthscnt) < 1)
                {
                    msg = "잔여 병상수가 없는 병실에 입원등록할 수 없습니다.";
                    return false;
                }
            }

            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++
            // 병상이 선택된 경우, 해당 병상이 사용중인지 체크
            // 병상이 null인지는 체크하지 않음 (병상 선택 없이도 등록가능) 
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++
            if (DBService.ExecuteScalar("SELECT CONF_VAL FROM ADCONFDT WHERE SYSTEM_CD = 'PA' AND CONF_TYPE = 'ADMS_REG_ROOM' AND CONF_CD = 'NEED_ROOM'").ToString().Equals("Y")
                && String.IsNullOrWhiteSpace(bedno))
            {
                msg = "병상이 선택되지 않았습니다.\r\n병상은 반드시 선택되어야 합니다.";
                return false;
            }

            if (StringService.IsNotNull(bedno))
            {
                string sqlText = @"
        SELECT COUNT(*)
            FROM PAIPATRT A
            WHERE A.WARD_CD          = '{0}'
            AND A.ROOM_CD            = '{1}'
            AND A.BED_NO             = '{2}'
            AND A.ROW_STAT_DVCD      = 'A' 
            AND A.STHS_DSCH_DVCD     = 'J'
            AND A.MAIN_SUB_ADMS_DVCD = 'J' 
            AND A.DSCH_DD            = '29991231'
            AND A.PID               != '{3}'";
                let count:number = DBService.ExecuteInteger(sqlText, wardcd, roomcd, bedno, pid);
                if (!count.Equals(0))
                {
                    msg = "선택한 병상은 다른 환자가 사용중입니다.";
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 신용카드/현금영수증 승인후 수납 여부가 반영되었는지 확인한다.
        /// 수납여부를 적용하지 않으면 마감시 영수금액과 승인금액이 맞지 않는다.
        /// </summary>
        /// <param name="ocrrdvcd">발생구분코드</param>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static CheckCreditPermit(ocrrdvcd:string, pid:string, ptcmhsno:string, msg:string)
        {
            try
            {
                let nonrcptcount:number = 0;

                if (StringService.IsNull(pid)) return true;

                nonrcptcount = DBService.ExecuteInteger(SQL.PA.Sql.SelectCountNotRcptOfPACAPEMA(), pid
                                                                                                 , ptcmhsno
                                                                                                 , ocrrdvcd);
                if (DBService.HasError)
                {
                    throw new Exception(String.Format("[SelectCountNotRcptOfPACAPEMA][{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));
                }

                if (nonrcptcount > 0)
                {
                    //msg = "신용카드/현금 승인된 자료가 존재합니다.\r\n수납을 하시거나 승인을 취소하세요.\r\n\r\n" +
                    //      "프로그램을 종료하면 마감시 금액이 맞지 않습니다.";

                    msg = "신용카드/현금 승인된 자료가 존재합니다.\r\n수납을 하시거나 승인을 취소하세요.\r\n\r\n" +
                          "프로그램을 종료하면 마감시 금액이 맞지 않습니다.";

                    return false;
                }

                return true;
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                msg = ex.Message;
                return false;
            }
        }

        /// <summary>
        /// 신용카드/현금영수증 승인후 수납 여부가 반영되었는지 확인한다.
        /// 수납여부를 적용하지 않으면 마감시 영수금액과 승인금액이 맞지 않는다.
        /// </summary>
        /// <param name="ocrrdvcd">발생구분코드</param>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <returns></returns>
        public static CheckCreditPermit(ocrrdvcd:string, pid:string, ptcmhsno:string)
        {
            try
            {
                let nonrcptcount:number = 0;

                if (StringService.IsNull(pid)) return true;

                nonrcptcount = DBService.ExecuteInteger(SQL.PA.Sql.SelectCountNotRcptOfPACAPEMA(), pid
                                                                                                 , ptcmhsno
                                                                                                 , ocrrdvcd);
                if (DBService.HasError)
                    throw new Exception(String.Format("[SelectCountNotRcptOfPACAPEMA][{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));

                if (nonrcptcount > 0)
                    return false;

                return true;
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
        }

        /// <summary>
        /// 신용카드/현금영수증 승인후 수납 여부가 반영되었는지 확인한다.
        /// 수납여부를 적용하지 않으면 마감시 영수금액과 승인금액이 맞지 않는다.
        /// </summary>
        /// <param name="ocrrdvcd">발생구분코드</param>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="cnclyn"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static CheckCreditPermit(ocrrdvcd:string, pid:string, ptcmhsno:string, cnclyn:string, msg:string)
        {
            try
            {
                let nonrcptcount:number = 0;

                if (StringService.IsNull(pid)) return true;

                nonrcptcount = DBService.ExecuteInteger(SQL.PA.Sql.SelectRcptYnAfterPermit(), pid
                                                                                            , ptcmhsno
                                                                                            , ocrrdvcd
                                                                                            , cnclyn);
                if (DBService.HasError)
                {
                    throw new Exception(String.Format("[SelectRcptYnAfterPermit][{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));
                }

                if (nonrcptcount > 0)
                {
                    msg = "신용카드/현금 승인된 자료가 존재합니다.\r\n수납을 하시거나 승인을 취소하세요.\r\n\r\n" +
                          "프로그램을 종료하면 마감시 금액이 맞지 않습니다.";
                    return false;
                }

                return true;
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                msg = "신용카드/현금 승인된 자료 확인 중 오류발생 \r\n " + ex.Message;
                return false;
            }
        }

        /// <summary>
        /// 신용카드/현금영수증 승인후 수납 여부가 반영되었는지 확인한다.
        /// 수납여부를 적용하지 않으면 마감시 영수금액과 승인금액이 맞지 않는다.
        /// </summary>
        /// <param name="ocrrdvcd">발생구분코드</param>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="cnclyn"></param>
        /// <returns></returns>
        public static CheckCreditPermit(ocrrdvcd:string, pid:string, ptcmhsno:string, cnclyn:string)
        {
            try
            {
                let nonrcptcount:number = 0;

                if (StringService.IsNull(pid)) return true;

                nonrcptcount = DBService.ExecuteInteger(SQL.PA.Sql.SelectRcptYnAfterPermit(), pid
                                                                                            , ptcmhsno
                                                                                            , ocrrdvcd
                                                                                            , cnclyn);
                if (DBService.HasError)
                    throw new Exception(String.Format("[SelectRcptYnAfterPermit][{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));

                if (nonrcptcount > 0)
                    return false;

                return true;
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
        }

        /// <summary>
        /// 사용자의 서명 Image To Byte Array
        /// </summary>
        /// <param name="usercd"></param>
        /// <returns></returns>
        public static GetSignMegaBytes(usercd:string)
        {
            System.IO.MemoryStream ms = new System.IO.MemoryStream();

            try
            {
                byte[] sign = new byte[0];
                DOSignInfo signinfo = new DOSignInfo(usercd);

                signinfo.SignImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);

            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
            }

            return ms.ToArray();
        }

        public static GetAllControlsTextBoxComboBox(Dictionary<string, Control> stockControls, Control.ControlCollection Controls)
        {
            foreach (Control ctrl in Controls)
            {
                if (ctrl is LxTextBox)
                {
                    stockControls.Add(((LxTextBox)ctrl).Name, ctrl);
                }
                else if (ctrl is LxComboBox)
                {
                    stockControls.Add(((LxComboBox)ctrl).Name, ctrl);
                }
                else
                {
                    if (ctrl.Controls.Count > 0)
                        GetAllControlsTextBoxComboBox(stockControls, ctrl.Controls);
                }
            }
        }


        public static CheckHasPermitAmount(pid:string, ptcmhsno:string, showMessage:boolean = true)
        {
            // 환자가 선택되지 않은 경우는 리턴.
            if (StringService.IsNull(pid) || StringService.IsNull(ptcmhsno))
                return true;

            // 수납버튼 이외의 버튼이 눌러진 경우, 카드 승인된 내역이 존재하는지 확인한다.
            // 존재하는 경우, 수납버튼만 눌러지도록 한다.
            string sqltext = String.Format(@" 
                                        SELECT * 
                                          FROM PACAPEMA 
                                         WHERE PID = '{0}' 
                                           AND PT_CMHS_NO = {1} 
                                           AND RCPT_OCRR_UNIQ_NO = 'NO'
                                           AND CCCS_OCRR_DVCD = 'B' 
                                           AND CNCL_YN <> 'D' ", pid, ptcmhsno);

            let dt:DataTable = new DataTable();
            DBService.ExecuteDataTable(sqltext, dt);

            if (!dt.Rows.Count.Equals(0))
            {
                if (showMessage)
                    LxMessage.ShowWarning("카드/현금 승인정보가 존재합니다.\r\n수납후에 진행가능합니다");

                return false;
            }

            return true;
        }

        public static SetAsstTycd_PR_PA_PRC_ASSTTYCDADMSET(pid:string, ptCmhsNo:number, mdcrDd:string, insnTycd:string, asstTycd:string)
        {
            try
            {
                let ptInfo:DOPatientInfo = new DOPatientInfo(pid);
                let frrn:string = ptInfo.FRRN;
                let srrn:string = ptInfo.SRRN_ECPT;
                let ptNm:string = ptInfo.PT_NM;
                ptInfo.Clear();
                ptInfo.Dispose();
                ptInfo = null;

                let iov_asst_tycd:string = "";  // 보조유형코드
                let iov_cfsc_rgno_cd:string = "";  // 산정특례코드
                let iov_ecoi_cd:string = "";  // 상해외인코드
                let iov_trbc_dvcd:string = "";  // 결핵구분코드(보조산정특례코드)
                let iov_msg:string = "";  // 에러메시지

                if (!SQL.Procedure.PR_PA_PRC_ASSTTYCDADMSET(pid, ptCmhsNo, String.Format("{0}{1}", frrn, srrn), ptNm, mdcrDd, insnTycd, asstTycd, iov_asst_tycd, iov_cfsc_rgno_cd, iov_ecoi_cd, iov_trbc_dvcd, iov_msg))
                {
                    throw new Exception("보조유형 세팅 중 에러가 발생했습니다.(Procedure)\r\n");
                }

                if (StringService.IsNotNull(iov_msg))
                {
                    throw new Exception("보조유형 세팅 중 에러가 발생했습니다.(Message)\r\n" + iov_msg + "\r\n");
                }

                asstTycd = iov_asst_tycd;
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.ShowError(ex.Message);
                return false;
            }

            return true;
        }

        public static SetAsstTycd_PR_PA_PRC_ASSTTYCDADMSET(pid:string, ptCmhsNo:number, mdcrDd:string, insnTycd:string, asstTycd:string, cfscRgnoCd:string)
        {
            try
            {
                let ptInfo:DOPatientInfo = new DOPatientInfo(pid);
                let frrn:string = ptInfo.FRRN;
                let srrn:string = ptInfo.SRRN_ECPT;
                let ptNm:string = ptInfo.PT_NM;
                ptInfo.Clear();
                ptInfo.Dispose();
                ptInfo = null;

                let rrno:string = String.Format("{0}{1}", frrn, srrn);
                let sqltext:string = String.Format(@" SELECT NVL(FCLT_APLY_YN, 'N') FROM PAOPATRT T WHERE PID = '{0}' AND PT_CMHS_NO = {1} AND ROW_STAT_DVCD = 'A' ", pid, ptCmhsNo);
                let fcltAplyYn:string = DBService.ExecuteScalar(sqltext).ToString();
                if (fcltAplyYn.Equals("Y"))
                {
                    let inpnRrno:string = "";
                    let msg:string = "";
                    if (!clsPACommon.GetInpnRrno(pid, insnTycd, mdcrDd, inpnRrno, msg))
                    {
                        throw new Exception(msg);
                    }

                    if (StringService.IsNotNull(inpnRrno) && !inpnRrno.Equals("NO"))
                    {
                        rrno = inpnRrno;
                    }
                }

                let iov_asst_tycd:string = String.Empty;  // 보조유형코드
                let iov_cfsc_rgno_cd:string = String.Empty;  // 산정특례코드
                let iov_ecoi_cd:string = String.Empty;  // 상해외인코드
                let iov_trbc_dvcd:string = String.Empty;  // 결핵구분코드(보조산정특례코드)
                let iov_msg:string = String.Empty;  // 에러메시지

                if (!SQL.Procedure.PR_PA_PRC_ASSTTYCDADMSET(pid, ptCmhsNo, rrno, ptNm, mdcrDd, insnTycd, asstTycd, iov_asst_tycd, iov_cfsc_rgno_cd, iov_ecoi_cd, iov_trbc_dvcd, iov_msg))
                {
                    throw new Exception("보조유형 세팅 중 에러가 발생했습니다.(Procedure)\r\n");
                }

                if (StringService.IsNotNull(iov_msg))
                {
                    throw new Exception("보조유형 세팅 중 에러가 발생했습니다.(Message)\r\n" + iov_msg + "\r\n");
                }

                asstTycd = iov_asst_tycd;
                cfscRgnoCd = iov_cfsc_rgno_cd;
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.ShowError(ex.Message);
                return false;
            }

            return true;
        }

        /// <summary>
        /// 회계연동을 위해서 미수입금내역이 있을시, 임의의 데이터를 만들어준다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="mdcr_dd"></param>
        public static SaveAccountingPacapema_Uncama(pid:string, pt_cmhs_no:string, mdcr_dd:string)
        {
            // 외래것도 돌려놓자...
            SaveAccountingPacapema(pid, pt_cmhs_no);

            // 2020-09-09 SJH 미수입금금액은 미수쪽에서 돌리면서 넣도록 수정함
            //if (!DBService.ExecuteNonQuery(SqlPack.PA.Sql.InsertAccountingPacapema_uncoma()
            //                             , pid, pt_cmhs_no, DOPack.UserInfo.USER_CD, mdcr_dd))
            //    throw new Exception("오류 내용 : InsertAccountingPacapema");
        }

        /// <summary>
        /// 회계연동을 위해서 외래수납에서 재승인할때 임의의 데이터를 만들어준다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        public static SaveAccountingPacapema(pid:string, pt_cmhs_no:string)
        {
            if (!DBService.ExecuteNonQuery(SqlPack.PA.Sql.UpdateAccountingPacapema()
                                         , pid, pt_cmhs_no))
                throw new Exception("오류 내용 : UpdateAccountingPacapema");

            if (!DBService.ExecuteNonQuery(SqlPack.PA.Sql.InsertAccountingPacapema()
                                         , pid, pt_cmhs_no, DOPack.UserInfo.USER_CD))
                throw new Exception("오류 내용 : InsertAccountingPacapema");
        }

        /// <summary>
        /// 회계연동을 위해서 입원전환금으로 넘길때 임의의 데이터를 만들어준다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="new_pt_cmhs_no"></param>
        public static SaveAccountingPacapema_i_change(pid:string, pt_cmhs_no:string, new_pt_cmhs_no:string)
        {
            if (!DBService.ExecuteNonQuery(SqlPack.PA.Sql.UpdateAccountingPacapema()
                                         , pid, pt_cmhs_no))
                throw new Exception("오류 내용 : UpdateAccountingPacapema");

            if (!DBService.ExecuteNonQuery(SqlPack.PA.Sql.InsertAccountingPacapema_i_change()
                                         , pid, pt_cmhs_no, new_pt_cmhs_no, DOPack.UserInfo.USER_CD))
                throw new Exception("오류 내용 : InsertAccountingPacapema");
        }

        /// <summary>
        /// 회계연동을 위해서 입원전환금으로 넘길때 임의의 데이터를 만들어준다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="new_pt_cmhs_no"></param>
        public static SaveAccountingPacapema_i_change_bill_no_update(string pid, int pt_cmhs_no, int new_pt_cmhs_no, string D_rcpt_sqno, string rcpt_ocrr_uniq_no, string bill_no, string currentdate,
                                                                          string adms_dd, string mdcr_dept_cd, string mdcr_dr_cd, string insn_tycd, string asst_tycd)
        {
            if (!DBService.ExecuteNonQuery(SqlPack.PA.Sql.UpdateAccountingPacapema(), pid, pt_cmhs_no.ToString()))
                throw new Exception("오류 내용 : UpdateAccountingPacapema");

            let msg:string = String.Empty;
            let rcpt_ocrr_uniq_no_w:string = String.Empty;
            let bill_no_w:string = String.Empty;

            // 취소된 내역이 있으면 회계연동 자료를 생성한다.
            if (DBService.AffectedRows <= 0)
                return;

            //PAOIKYMA
            let oDt:DataTable = new DataTable();
            if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPACAPEMA_O_Bill(pid, pt_cmhs_no.ToString()), oDt))
                throw new Exception("수납 내역 조회 중 에러가 발생했습니다.");

            let card_amt:number = 0;
            let cash_amt:number = 0;
            let bank_amt:number = 0;
            let card_cash_dvcd:string = String.Empty;
            let prmt_sqno:string = String.Empty;

            let chng_sqno:string = DBService.ExecuteScalar(SQL.PA.Sql.SelectPAOIKYMA_CHNG_SQNO(pid)).ToString();

            for (int i = 0; i < oDt.Rows.Count; i++)
            {
                // 영수증번호를 생성한다. (PAIMDMMA)
                if (!clsPACommon.GetBillNo(currentdate.Substring(0, 8), bill_no_w, msg))
                    throw new Exception(String.Format("영수증 번호 생성 중 에러가 발생했습니다. (입원전환금 저장)\r\n{0}", msg));

                // 수납발생고유번호를 생성한다. (PAIMDMMA)
                if (!clsPACommon.GetRcptOcrrUniqNo(currentdate, rcpt_ocrr_uniq_no_w, msg))
                    throw new Exception(String.Format("수납발생고유 번호 생성 중 에러가 발생했습니다. (입원전환금 저장)\r\n{0}", msg));

                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                // 기존의 외래수납 취소 (C)
                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePACAPEMA_CNCL_YN_Y(pid, oDt.Rows[i]["RQST_DD"].ToString(), oDt.Rows[i]["PRMT_SQNO"].ToString())))
                    throw new Exception("입원전환금을 외래로 전환하는 중 에러가 발생했습니다. (1)");

                prmt_sqno = DBService.ExecuteScalar(SQL.PA.Sql.SelectPACAPEMA_MaxPrmtSqno(pid, oDt.Rows[i]["RQST_DD"].ToString())).ToString();

                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                // 기존의 외래수납 취소 (D)
                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertPACAPEMA_Cancel(pid, oDt.Rows[i]["RQST_DD"].ToString(), oDt.Rows[i]["PRMT_SQNO"].ToString(), rcpt_ocrr_uniq_no, bill_no, currentdate, DOPack.UserInfo.USER_CD, "O", prmt_sqno, D_rcpt_sqno)))
                    throw new Exception("입원전환금 승인내역 취소 중 에러가 발생했습니다. (회계연동 취소)");

                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                // 기존의 외래수납 => 보증금 전환
                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                card_amt = 0;
                cash_amt = 0;
                bank_amt = 0;

                card_cash_dvcd = oDt.Rows[i]["CASH_CARD_DVCD"].ToString();

                if (card_cash_dvcd == "01")
                    long.TryParse(oDt.Rows[i]["CARD_PRMT_AMT"].ToString(), card_amt);
                else if (card_cash_dvcd == "02")
                    long.TryParse(oDt.Rows[i]["CASH_PRMT_AMT"].ToString(), cash_amt);
                else if (card_cash_dvcd == "03")
                    long.TryParse(oDt.Rows[i]["CASH_PRMT_AMT"].ToString(), bank_amt);

                let sqno:number = DBService.ExecuteInteger(SQL.PA.Sql.SelectMaxSqnoPAIMDMMA(), pid, new_pt_cmhs_no.ToString());
                if (sqno < 0)
                    throw new Exception("보증금 내역의 일련번호를 취득하는 중 에러가 발생했습니다.");

                sqno++;

                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertPAIMDMMA(), pid, new_pt_cmhs_no.ToString(), sqno.ToString(), adms_dd, bill_no_w
                                                                          , rcpt_ocrr_uniq_no_w, mdcr_dept_cd, mdcr_dr_cd, insn_tycd, asst_tycd
                                                                          , "W", card_amt.ToString(), "", "", ""
                                                                          , bank_amt.ToString(), cash_amt.ToString(), "N", "", "A"
                                                                          , currentdate, DOPack.UserInfo.USER_CD))
                {
                    throw new Exception("입원전환금을 저장하는 중 에러가 발생했습니다.(1)");
                }

                prmt_sqno = DBService.ExecuteScalar(SQL.PA.Sql.SelectPACAPEMA_MaxPrmtSqno(pid, oDt.Rows[i]["RQST_DD"].ToString())).ToString();

                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertPACAPEMA_W(pid, oDt.Rows[i]["RQST_DD"].ToString(), oDt.Rows[i]["PRMT_SQNO"].ToString(), rcpt_ocrr_uniq_no_w, bill_no_w, currentdate, DOPack.UserInfo.USER_CD, new_pt_cmhs_no.ToString(), String.Empty, "W", prmt_sqno)))
                    throw new Exception("입원전환금 승인내역 취소 중 에러가 발생했습니다. (회계연동 승인)");

                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePACAPEMA_RcptSqno(sqno.ToString(), pid, oDt.Rows[i]["RQST_DD"].ToString(), prmt_sqno)))
                    throw new Exception("입원전환금의 카드내역(수납정보)을 저장하는 중 에러가 발생했습니다.");

                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                // 외래수납 => 보증금 History 저장
                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertPAOIKYMA(pid, chng_sqno, "B", pt_cmhs_no.ToString(), rcpt_ocrr_uniq_no, bill_no, new_pt_cmhs_no.ToString(), rcpt_ocrr_uniq_no_w, bill_no_w, currentdate, DOPack.UserInfo.USER_CD)))
                    throw new Exception("외래 수납내역(입원전환금 내역)을 저장하는 중 에러가 발생했습니다.");
            }
        }

        /// <summary>
        /// 회계연동을 위해서 입원전환취소할때, 임의의 데이터를 만들어준다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="new_pt_cmhs_no"></param>
        public static SaveAccountingPacapema_i_change_cancel(pid:string, adms_pt_cmhs_no:number, o_pt_cmhs_no:string, newrcptsqno:string, o_rcpt_ocrr_uniq_no:string, o_bill_no:string, currentdate:string)
        {
            // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
            // 기존의 외래수납 내역을 가져온다.
            // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
            let dt:DataTable = new DataTable();
            if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPACAPEMA_FromPAOIKYMA(pid, o_pt_cmhs_no, adms_pt_cmhs_no.ToString()), dt))
                throw new Exception("입원전환된 영수내역을 조회하는 중 에러가 발생했습니다.");

            if (dt.Rows.Count.Equals(0))
                return;

            let bill_no_w_cancel:string = String.Empty;
            let rcpt_ocrr_uniq_no_w_cancel:string = String.Empty;
            let msg:string = String.Empty;
            let prmt_sqno:string = String.Empty;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                // 영수증번호를 생성한다.
                if (!clsPACommon.GetBillNo(currentdate.Substring(0, 8), bill_no_w_cancel, msg))
                    throw new Exception(String.Format("영수증 번호 생성 중 에러가 발생했습니다.(입원전환금 외래 복원 중)\r\n{0}", msg));

                // 수납발생고유번호를 생성한다.
                if (!clsPACommon.GetRcptOcrrUniqNo(currentdate.Substring(0, 8), rcpt_ocrr_uniq_no_w_cancel, msg))
                    throw new Exception(String.Format("수납발생고유 번호 생성 중 에러가 발생했습니다.(입원전환금 외래 복원 중)\r\n{0}", msg));

                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                // 입원전환금 취소 (C) PACAPEMA
                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePACAPEMA_CNCL_YN_Y(pid, dt.Rows[i]["RQST_DD"].ToString(), dt.Rows[i]["PRMT_SQNO"].ToString())))
                    throw new Exception("입원전환금을 외래로 전환하는 중 에러가 발생했습니다. (1)");

                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                // 입원전환금 취소 (D) PACAPEMA
                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                prmt_sqno = DBService.ExecuteScalar(SQL.PA.Sql.SelectPACAPEMA_MaxPrmtSqno(pid, dt.Rows[i]["RQST_DD"].ToString())).ToString();

                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertPACAPEMA_Cancel(pid, dt.Rows[i]["RQST_DD"].ToString(), dt.Rows[i]["PRMT_SQNO"].ToString(), rcpt_ocrr_uniq_no_w_cancel
                                                                                , bill_no_w_cancel, currentdate, DOPack.UserInfo.USER_CD, "W", prmt_sqno, "RCPT_SQNO")))
                    throw new Exception("입원전환금 승인내역 취소 중 에러가 발생했습니다. (회계연동 취소)");

                let cancel_prmt_sqno:string = prmt_sqno;

                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                // 외래 승인내역으로 복원
                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                prmt_sqno = DBService.ExecuteScalar(SQL.PA.Sql.SelectPACAPEMA_MaxPrmtSqno(pid, dt.Rows[i]["RQST_DD"].ToString())).ToString();

                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertPACAPEMA_W(pid, dt.Rows[i]["RQST_DD"].ToString(), dt.Rows[i]["PRMT_SQNO"].ToString(), o_rcpt_ocrr_uniq_no, o_bill_no
                                                                            , currentdate, DOPack.UserInfo.USER_CD, o_pt_cmhs_no, newrcptsqno, "O", prmt_sqno)))
                    throw new Exception("입원전환금 승인내역 취소 중 에러가 발생했습니다. (회계연동 승인)");

                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePACAPEMA_RcptSqno(newrcptsqno, pid, dt.Rows[i]["RQST_DD"].ToString(), prmt_sqno)))
                    throw new Exception("입원전환금의 카드내역(수납정보)을 저장하는 중 에러가 발생했습니다.");

                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                // 입원전환금 취소 (C) PAIMDMMA
                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePAIMDMMA_RCPT_OCRR_UNIQ_NO(pid, dt.Rows[i]["RCPT_OCRR_UNIQ_NO"].ToString(), "C")))
                    throw new Exception("입원전환금을 취소하는 중 에러가 발생했습니다. (데이터 삭제)");

                if (DBService.AffectedRows.Equals(0))
                    continue;

                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                // 입원전환금 취소 (D) PAIMDMMA
                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                let sqno:number = DBService.ExecuteInteger(SQL.PA.Sql.SelectMaxSqnoPAIMDMMA(), pid, adms_pt_cmhs_no.ToString());
                sqno++;
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertPAIMDMMA_W_Cancel_RCPT_OCRR_UNIQ_NO(pid
                                                                                                , adms_pt_cmhs_no.ToString()
                                                                                                , sqno.ToString()
                                                                                                , "-1"
                                                                                                , "D"
                                                                                                , currentdate
                                                                                                , DOPack.UserInfo.USER_CD
                                                                                                , rcpt_ocrr_uniq_no_w_cancel
                                                                                                , bill_no_w_cancel
                                                                                                , dt.Rows[i]["RCPT_OCRR_UNIQ_NO"].ToString())))
                    throw new Exception("입원전환금을 취소하는 중 에러가 발생했습니다. (데이터 마이너스 처리)");

                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePACAPEMA_RcptSqno(sqno.ToString(), pid, dt.Rows[i]["RQST_DD"].ToString(), cancel_prmt_sqno)))
                    throw new Exception("입원전환금의 카드내역(수납정보)을 저장하는 중 에러가 발생했습니다.");
            }
        }

        /// <summary>
        /// 회계연동을 위해서 기타수납에서 재승인할때 임의의 데이터를 만들어준다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        public static SaveEtcAccountingPacapema(pid:string, pt_cmhs_no:string)
        {
            if (!DBService.ExecuteNonQuery(SqlPack.PA.Sql.UpdateEtcAccountingPacapema()
                                         , pid, pt_cmhs_no))
                throw new Exception("오류 내용 : UpdateEtcAccountingPacapema");

            if (!DBService.ExecuteNonQuery(SqlPack.PA.Sql.InsertEtcAccountingPacapema()
                                         , pid, pt_cmhs_no))
                throw new Exception("오류 내용 : InsertEtcAccountingPacapema");
        }

        //부입원 정보가 존재하는 경우 업데이트 한다.
        public static ApplyToSubAdmsRoom(pid:string, aplyStrtDd:string, wardCd:string, roomCd:string, bedNo:string, roomDvcd:string, roomGradCd:string, nrsnExstInsvYn:string)
        {
            // ++++++++++++++++++++++++++++++++
            // 부입원이 존재하는지 확인
            // ++++++++++++++++++++++++++++++++
            let tempDt:DataTable = new DataTable();
            let sqltext:string = SQL.PA.Sql.SelectPAIPCHMA_GetSubAdms(pid, aplyStrtDd);
            DBService.ExecuteDataTable(sqltext, tempDt);

            // 부입원이 존재하는 수만큼 Updqte한다. (병동, 병실, 병상, 병실구분, 병실등급, 간병통합)
            // 부입원의 경우는, 따로 Insert해서 History쌓지 않는다.
            for (int i = 0; i < tempDt.Rows.Count; i++)
            {
                // ++++++++++++++++++++++++++++++++
                // PAIPCHMA (입원접수변경내역) Update
                // ++++++++++++++++++++++++++++++++
                sqltext = SQL.PA.Sql.UpdatePAIPCHMA_ChangeRoom(wardCd, roomCd, bedNo, roomDvcd, roomGradCd, nrsnExstInsvYn, pid, tempDt.Rows[i]["PT_CMHS_NO"].ToString(), tempDt.Rows[i]["RCPN_CHNG_SQNO"].ToString(), DOPack.UserInfo.USER_CD);
                if (!DBService.ExecuteNonQuery(sqltext))
                    throw new Exception("부입원 정보에 적용하는 중 에러가 발생했습니다. PAIPCHMA (입원접수변경내역)");

                // ++++++++++++++++++++++++++++++++
                // PAIPATRT (입원접수등록) Update
                // ++++++++++++++++++++++++++++++++
                sqltext = SQL.PA.Sql.UpdatePAIPATRT_ChangeRoom(wardCd, roomCd, bedNo, nrsnExstInsvYn, pid, tempDt.Rows[i]["PT_CMHS_NO"].ToString());
                if (!DBService.ExecuteNonQuery(sqltext))
                    throw new Exception("부입원 정보에 적용하는 중 에러가 발생했습니다. PAIPATRT (입원접수등록)");
            }
        }

        public static CheckMedicalCarePatientNonePermitNo(UserControl form)
        {
            // using (popNone_MdadPrmtNo popup = new popNone_MdadPrmtNo())
                popup.ShowDialog(form);
        }

        public static CheckNoneCard(BaseUCF_TP form)
        {
            popNoneCard popup = new popNoneCard();
            popup.ShowDialog(form);
            popup.Dispose();
        }

        /// <summary>
        /// 미정산내역이 있는지 확인
        /// </summary>
        /// <returns></returns>
        public static CheckNonCmpy(pid:string, msgbox:boolean)
        {
            try
            {
                let dt:DataTable = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOUNRMA(pid), dt))
                    throw new Exception("SelectPAOUNRMA - " + DBService.ErrorMessage + "[" + DBService.ErrorCode + "]");

                if (dt.Rows.Count > 0)
                {
                    if (msgbox)
                    {
                        let message:string = "";
                        let mdcrdd:string = "";
                        let nonCmpyAmt:string = "";
                        decimal tempDecimal = 0;

                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            // 어떤 날짜에 미정산 내역이 있는지 메시지를 구성한다.
                            mdcrdd = dt.Rows[i]["MDCR_DD"].ToString();
                            if (StringService.IsNotNull(mdcrdd) && mdcrdd.Length.Equals(8))
                                mdcrdd = String.Format("{0}-{1}-{2}", mdcrdd.Substring(0, 4), mdcrdd.Substring(4, 2), mdcrdd.Substring(6, 2));

                            tempDecimal = 0;
                            decimal.TryParse(dt.Rows[i]["NON_CMPY_AMT"].ToString(), tempDecimal);
                            nonCmpyAmt = String.Format("{0:#,##0}", tempDecimal);

                            message += String.Format("\r\n    [ {0} ] {1} 원\r\n      사유 : {2}", mdcrdd, StringService.PadLeft(nonCmpyAmt, 15), dt.Rows[i]["PCLR_MATR"].ToString());
                        }

                        LxMessage.ShowInformation("미정산 내역이 있습니다." + message);
                    }

                    // 미정산 내역 있음
                    return true;
                }
            }
            catch (ex)
            {
                LxMessage.Show(ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // 미정산 내역 없음
            return false;
        }

        public static CheckCLAM_CRTN_YN(pid:string, ptcmhsno:string, rcpnsqno:string, showMessage:boolean, isReceipt:boolean, message:string, trms_cmpl_yn:boolean)
        {
            try
            {
                if (isReceipt)
                {
                    string sqltext = String.Format(@"
SELECT COUNT(*)
  FROM PACLRSMA
 WHERE PID        = '{0}'
   AND PT_CMHS_NO =  {1}
   AND RCPT_SQNO  =  {2}
   AND NVL(ETC_USE_CNTS_1, 'RO') = 'RO'   -- 사유 구분 : 외래수납 재정산인 건만
", pid, ptcmhsno, rcpnsqno);

                    if (DBService.ExecuteInteger(sqltext) > 0)
                    {
                        return true;
                    }
                }

                let ediTrmsCmplYn:string = DBService.ExecuteScalar(SQL.Function.SelectFN_CL_PRC_CHKCLAMCRTN(), pid, ptcmhsno, "").ToString();

                trms_cmpl_yn = !(ediTrmsCmplYn == null || String.IsNullOrWhiteSpace(ediTrmsCmplYn) || ediTrmsCmplYn == "N");

                if (ediTrmsCmplYn == null || ediTrmsCmplYn.Equals(String.Empty))
                    return true;

                if (ediTrmsCmplYn.Equals("N"))
                    return true;

                message = String.Format("EDI 전송이 완료된 내역입니다. 내역변경/수납시에 반드시 심사과에 연락해 주세요.");

                if (showMessage)
                {
                    message = String.Format(isReceipt ? "EDI 전송이 완료된 내역입니다.\r\n금액 등이 변경되어 재수납하는 경우 반드시 심사과에 연락해 주세요.\r\n\r\n재정산 하시겠습니까?"
                                                      : "EDI 전송이 완료된 내역입니다.\r\n내역변경 후에 금액변경 등이 발생하는 경우 반드시 심사과에 연락해 주세요.\r\n\r\n내역변경 하시겠습니까?");

                    if (!LxMessage.ShowQuestion(message).Equals(DialogResult.Yes))
                        return false;

                    string logmessage = String.Format(@"[OutReciept_CheckEDIYn] {0} / {1}({2}) / {3} / {4} / PID : {5} , PT_CMHS_NO : {6}"
                        , DateTime.Now.ToString("yyy-MM-dd HH:mm:ss"), DOPack.UserInfo.USER_NM, DOPack.UserInfo.USER_CD, NetworkService.IP, ClientEnvironment.ComputerName, pid, ptcmhsno);
                    LogService.ErrorLog(logmessage);

                    return true;
                }
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.ShowError(ex.Message);
            }

            return false;
        }

        public static CheckChangeOrder_OUPR_GRNT_NO(rcptsaveyn:string, pid:string, ptcmhsno:string, mdcrdd:string)
        {
            // 원외처방이 수정되지 않았으면 수정되지 않았다는 뜻으로 return false.
            if (!rcptsaveyn.Equals("N"))
                return false;

            string sqltext = String.Format(@"
SELECT COUNT(*)
    FROM ORORDRRT
   WHERE PID          = '{0}'
    AND PT_CMHS_NO   =  {1}
    AND MDCR_DD      = '{2}'
    AND EXCP_RESN_CD = 'NO'
    AND DLVR_DEPT_CD = 'PMR'
    AND OUPR_GRNT_NO = 'NO'
    AND DEL_YN       = 'A'
    AND DC_PRSC_DVCD = 'A'
    AND RCPT_YN = 'Y' ", pid, ptcmhsno, mdcrdd);

            let tempCount:string = DBService.ExecuteScalar(sqltext).ToString();

            if (tempCount.Equals("0"))
                return false;

            // 업데이트한다.
            sqltext = String.Format(@"
UPDATE ORORDRRT
    SET RCPT_YN = 'N'
    WHERE PID          = '{0}'
    AND PT_CMHS_NO   =  {1}
    AND MDCR_DD      = '{2}'
    AND EXCP_RESN_CD = 'NO'
    AND DLVR_DEPT_CD = 'PMR'
    AND OUPR_GRNT_NO = 'NO'
    AND DEL_YN       = 'A'
    AND DC_PRSC_DVCD = 'A'
    AND RCPT_YN = 'Y' ", pid, ptcmhsno, mdcrdd);

            if (!DBService.ExecuteNonQuery(sqltext))
                throw new Exception("원외처방전 발행 데이터 수정 중 에러가 발생했습니다.");

            return true;
        }

        public static IsTestMode()
        {
            let returnValue:string = DBService.ExecuteScalar(@" SELECT CONF_VAL FROM ADCONFDT WHERE SYSTEM_CD = 'PA' AND CONF_TYPE = 'TEST_YN' AND CONF_CD = 'TEST_YN' ").ToString();
            if (returnValue.Equals(String.Empty) || returnValue.Equals("N"))
                return false;
            else
                return true;
        }

        public static CheckPAIPCAMA_PRAR_DFNT_YN_N(pid:string, ptcmhsno:string)
        {
            // 주부입원 구분코드를 찾아, '부입원'이면 체크하지 않는다.
            string sqltext = String.Format(@"
    SELECT MAIN_SUB_ADMS_DVCD
      FROM PAIPATRT
     WHERE PID = '{0}'
       AND PT_CMHS_NO = {1} ", pid, ptcmhsno);

            let dt:DataTable = new DataTable();
            DBService.ExecuteDataTable(sqltext, dt);
            if (dt.Rows.Count.Equals(0))
                throw new Exception("주부입원 구분코드를 취득하는 중 에러가 발생했습니다. 데이터가 없습니다.");

            if (dt.Rows[0]["MAIN_SUB_ADMS_DVCD"].ToString().Equals("B"))
                return;

            // PAIPCAMA 테이블에서 확정여부가 N인 데이터를 찾아, 존재하는 경우 메시지를 띄운다.
            sqltext = String.Format(@"
SELECT T.*
     , FN_BI_READ_USERNM(T.RGSTR_ID) AS RGSTR_NM
     , (SELECT B.DEPT_HNM
          FROM BIUSERDT A
             , BIDEPTMA B
         WHERE A.USER_CD = T.RGSTR_ID
           AND A.MAIN_DEPT_YN = 'Y'
           AND A.DEPT_CD = B.DEPT_CD) AS DEPT_NM
     , (SELECT FN_BI_READ_BICDINDT( 'OCTY_DVCD', C.OCTY_DVCD,TO_CHAR(SYSDATE, 'YYYYMMDD'), 'LWRN_OVRL_CDNM')
          FROM BIUSERMT C
         WHERE C.USER_CD = T.RGSTR_ID) AS OCTY_DVNM
  FROM PAIPCAMA T
 WHERE PID = '{0}'
   AND PT_CMHS_NO = {1} 
   AND NVL(PRAR_DFNT_YN, 'N') = 'N'  ", pid, ptcmhsno);

            dt.Clear();
            DBService.ExecuteDataTable(sqltext, dt);
            if (dt.Rows.Count.Equals(0))
                return;

            let usernm:string = dt.Rows[0]["RGSTR_NM"].ToString();
            let deptnm:string = dt.Rows[0]["DEPT_NM"].ToString();
            let octyDvnm:string = dt.Rows[0]["OCTY_DVNM"].ToString();
            let rgstdt:string = DateTimeService.ConvertDateTime(dt.Rows[0]["RGST_DT"].ToString()).ToString("yyyy-MM-dd HH:mm");

            let message:string = String.Format("{0}({2} {3})님이 {1}에 등록한 전과전실 자료가 확정되지 않은 상태입니다.\r\n해당 자료가 확정된 후에 입원변경내역을 저장할 수 있습니다.", usernm, rgstdt, deptnm, octyDvnm);
            throw new Exception(message);
        }

        public static UpdatePAOPATRT_EMRM_MMCD_CD(pid:string, ptcmhsno:string, mdcrDd:string, emrmMmcdCd:string)
        {
            let error_dvcd:string = String.Empty;
            let error_cnts:string = String.Empty;

            let sqltext:string = String.Format(@"SELECT RCPN_SQNO FROM PAOPATRT WHERE PID = '{0}' AND PT_CMHS_NO = {1} AND ROW_STAT_DVCD IN ('A', 'I')", pid, ptcmhsno);
            let rcpnsqno:string = DBService.ExecuteScalar(sqltext).ToString();
            if (string.IsNullOrEmpty(sqltext))
                throw new Exception("일련번호를 조회하는 중 에러가 발생했습니다.");

            // 변경한 주과에 대한 청구부서 조회
            let insn_clam_dept_cd:string = DBService.ExecuteScalar(SQL.Function.SelectFN_BI_READ_BIDEPTMA(), emrmMmcdCd, mdcrDd, "INSN_CLAM_DEPT_CD").ToString();

            // 응급실주진료부서코드 저장
            if (!(SQL.Procedure.PR_PA_PRC_PAOPATRTCH(pid, ptcmhsno, rcpnsqno, "EMRM_MMCD_CD", emrmMmcdCd, DOPack.UserInfo.USER_CD, error_dvcd, error_cnts)))
            {
                throw new Exception("[응급실주과]를 저장하는 중 에러가 발생했습니다.");
            }

            // 보험청구응급실주진료부서코드 저장
            if (!(SQL.Procedure.PR_PA_PRC_PAOPATRTCH(pid, ptcmhsno, rcpnsqno, "ISCL_EMRM_MMCD_CD", insn_clam_dept_cd, DOPack.UserInfo.USER_CD, error_dvcd, error_cnts)))
            {
                throw new Exception("[보험청구 응급실 주진료부서코드]를 저장하는 중 에러가 발생했습니다.");
            }
        }

        public static InsertPAOPATRT_AdmsAppendF(pid:string, ptcmhsno:string, rgst_dt:string, returnException:boolean)
        {
            let sqltext:string = String.Format(@"SELECT RCPN_SQNO FROM PAOPATRT WHERE PID = '{0}' AND PT_CMHS_NO = {1} AND ROW_STAT_DVCD IN ('A', 'I') ORDER BY RCPN_SQNO ", pid, ptcmhsno);
            let rcpnSqno:string = DBService.ExecuteScalar(sqltext).ToString();

            sqltext = String.Format(@"
    INSERT INTO PAOPATRT 
         ( PID, PT_CMHS_NO, RCPN_SQNO
         , MDCR_DD, APNT_TIME, MDCR_TIME, MDCR_DEPT_CD, INSN_CLAM_DEPT_CD, EMRM_MMCD_CD, ISCL_EMRM_MMCD_CD
         , MDCR_DR_CD, REAL_MDCR_DR_CD, INSN_TYCD, ASST_TYCD, ASCT_RGNO_CD, FRVS_RVST_DVCD, MCCH_CMPT_DVCD, HMCR_YN
         , SMCR_YN, CMHS_DVCD, CMHS_MOTV_DVCD, APNT_YN, APNT_PATH_DVCD, MCSP_APNT_DVCD, CNTT_PRSC_DVCD, NRSN_CNFR_YN
         , MDCR_STRT_DT, MDCR_END_DT, PT_MDCR_STAT_DVCD, PRSC_NOTM, RCPT_NOTM, EXCP_RESN_CD, VTRN_PT_YN, MOMR_AGE_DVCD
         , INDP_MOMR_YN, VTRN_FALU_YN, VTRN_USCH_DVCD, VTRN_NON_QLFC_YN, CLUR_DSBL_DVCD, MAIN_ILNS_CD, CFSC_RGNO_CD
         , CHRN_DSSE_DVCD, TBRC_DVCD, USCH_APLY_CD, REFR_INSTNO, ECOI_CD, HLLF_MNCS_BLCE, OTHR_HSPT_HPTF_YN, MTWM_YN
         , MTWM_BLCE, VCNT_CLTP_YN, VCNT_PRTW_YN, FCLT_APLY_YN, FCLT_APLY_CD, QLFC_RTRV_YN, PAY_QLFC_DVCD, SNDT_TGPS_DVCD
         , CNST_REFR_YN, FXAM_FXRT_DVCD, RRNS_FAFR_DVCD, OTPT_DRG_YN, DRG_DVCD, DRG_NO, DY_WARD_YN, ENTS_ENTD_DVCD
         , DYTM_CNTR_USE_YN, EMRM_WTNG_YN, TAIC_PT_UNIQ_NO, TRAI_USPR_SHRT, REVW_RQST_YN, REVW_RQST_RESN, CLAM_CRTN_YN
         , CLAM_REVW_YN, CLAM_CRTN_DEL_RESN, DCNT_RDIA_CD, DCNT_RDIA_EMNO, RCPN_AGE, RCPN_ADDR_CD, DC_DD
         , ETC_USE_CNTS_1, ETC_USE_CNTS_2, ETC_USE_CNTS_3, ETC_USE_CNTS_4, ETC_USE_CNTS_5, AFRS_STAT_DVCD, ROW_STAT_DVCD, RGST_DT, RGSTR_ID )
    SELECT PID, PT_CMHS_NO, (SELECT NVL(MAX(RCPN_SQNO), 0) + 1 FROM PAOPATRT WHERE PID = '{0}' AND PT_CMHS_NO = {1})
         , MDCR_DD, APNT_TIME, MDCR_TIME, MDCR_DEPT_CD, INSN_CLAM_DEPT_CD, EMRM_MMCD_CD, ISCL_EMRM_MMCD_CD
         , MDCR_DR_CD, REAL_MDCR_DR_CD, INSN_TYCD, ASST_TYCD, ASCT_RGNO_CD, FRVS_RVST_DVCD, MCCH_CMPT_DVCD, HMCR_YN
         , SMCR_YN, CMHS_DVCD, CMHS_MOTV_DVCD, APNT_YN, APNT_PATH_DVCD, MCSP_APNT_DVCD, CNTT_PRSC_DVCD, NRSN_CNFR_YN
         , MDCR_STRT_DT, MDCR_END_DT, PT_MDCR_STAT_DVCD, PRSC_NOTM, RCPT_NOTM, EXCP_RESN_CD, VTRN_PT_YN, MOMR_AGE_DVCD
         , INDP_MOMR_YN, VTRN_FALU_YN, VTRN_USCH_DVCD, VTRN_NON_QLFC_YN, CLUR_DSBL_DVCD, MAIN_ILNS_CD, CFSC_RGNO_CD
         , CHRN_DSSE_DVCD, TBRC_DVCD, USCH_APLY_CD, REFR_INSTNO, ECOI_CD, HLLF_MNCS_BLCE, OTHR_HSPT_HPTF_YN, MTWM_YN
         , MTWM_BLCE, VCNT_CLTP_YN, VCNT_PRTW_YN, FCLT_APLY_YN, FCLT_APLY_CD, QLFC_RTRV_YN, PAY_QLFC_DVCD, SNDT_TGPS_DVCD
         , CNST_REFR_YN, FXAM_FXRT_DVCD, RRNS_FAFR_DVCD, OTPT_DRG_YN, DRG_DVCD, DRG_NO, DY_WARD_YN, ENTS_ENTD_DVCD
         , DYTM_CNTR_USE_YN, EMRM_WTNG_YN, TAIC_PT_UNIQ_NO, TRAI_USPR_SHRT, REVW_RQST_YN, REVW_RQST_RESN, CLAM_CRTN_YN
         , CLAM_REVW_YN, CLAM_CRTN_DEL_RESN, DCNT_RDIA_CD, DCNT_RDIA_EMNO, RCPN_AGE, RCPN_ADDR_CD, DC_DD
         , ETC_USE_CNTS_1, ETC_USE_CNTS_2, ETC_USE_CNTS_3, ETC_USE_CNTS_4, ETC_USE_CNTS_5, '7', '{3}', '{4}', '{5}'
FROM PAOPATRT
     WHERE PID = '{0}'
       AND PT_CMHS_NO = {1}
       AND RCPN_SQNO = {2} ", pid, ptcmhsno, rcpnSqno, "F", rgst_dt, DOPack.UserInfo.USER_CD);

            if (!DBService.ExecuteNonQuery(sqltext))
            {
                if (returnException)
                {
                    throw new Exception("외래접수내역 저장 중 에러가 발생했습니다. (F데이터 생성 실패)");
                }
                else
                {
                    //LxMessage.ShowError("외래접수내역 저장 중 에러가 발생했습니다. (F데이터 생성 실패)");
                    return false;
                }
            }

            return true;
        }

        public static SetCRCCheckbox(LxCheckBox chkCRC)
        {
            if (!ConfigService.GetConfigValueBool("%", "CRC_HOSP_YN", "CRC_HOSP_YN"))
                chkCRC.Visible = false;
            else
                chkCRC.Checked = false;
        }

        public static SearchUser(searchUser:string, user_cd:string, user_nm:string)
        {
            user_cd = String.Empty;
            user_nm = String.Empty;

            let dt:DataTable = new DataTable();
            if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectBIUSERMT(searchUser), dt))
                throw new Exception("유저를 조회하는 중 에러가 발생했습니다.");

            if (dt.Rows.Count.Equals(0))
                return;

            if (dt.Rows.Count.Equals(1))
            {
                user_cd = dt.Rows[0]["USER_CD"].ToString();
                user_nm = dt.Rows[0]["USER_NM"].ToString();
                return;
            }

            popSearchUser2 popup = new popSearchUser2(searchUser);
            popup.ShowDialog();

            if (!String.IsNullOrWhiteSpace(popup.UserCd))
            {
                user_cd = popup.UserCd;
                user_nm = popup.UserNm;
            }

            popup.Dispose();
        }

        public static SelectPrevRcptOcrrUniqNo(pid:string, ptcmhsno:string, rcptsqno:string, otptadmsdvcd:string, rcptocrruniqno:string, msg:string)
        {
            try
            {
                rcptocrruniqno = String.Empty;

                let dt:DataTable = new DataTable();
                let sqltext:string = otptadmsdvcd.Equals("O") ? SQL.PA.Sql.SelectPAOBILBD_RcptOcrrUniqNo(pid, ptcmhsno) : SQL.PA.Sql.SelectPAIBILBD_RcptOcrrUniqNo(pid, ptcmhsno, rcptsqno);
                if (!DBService.ExecuteDataTable(sqltext, dt))
                    throw new Exception("협력업체 기존수납금액의 고유번호를 취득하는 중 에러가 발생했습니다.");

                if (!dt.Rows.Count.Equals(0))
                    rcptocrruniqno = dt.Rows[0]["RCPT_OCRR_UNIQ_NO"].ToString();
            }
            catch (ex)
            {
                let error:string = DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);

                msg = ex.Message + error;

                return false;
            }

            return true;
        }

        public static SavePABREDMA_Make_C_D(pid:string, ptcmhsno:string, prevRcptOcrrUniqNo:string, currentdate:string, msg:string)
        {
            try
            {
                // +++++++++++++++++++++++++++++++
                // 아직 수납된 적이 없으면 리턴
                // +++++++++++++++++++++++++++++++
                if (String.IsNullOrWhiteSpace(prevRcptOcrrUniqNo))
                    return true;

                // +++++++++++++++++++++++++++++++
                // 혈액감액 금액이 없었으면 리턴
                // +++++++++++++++++++++++++++++++
                let dt:DataTable = new DataTable();
                let sqltext:string = SQL.PA.Sql.SelectPABREDMA_RcptOcrrUniqNo(pid, ptcmhsno, prevRcptOcrrUniqNo);
                if (!DBService.ExecuteDataTable(sqltext, dt))
                    throw new Exception("혈액감액 수납금액을 조회하는 중 에러가 발생했습니다.");

                if (dt.Rows.Count.Equals(0))
                    return true;

                // +++++++++++++++++++++++++++++++
                // 혈액감액 수납금액이 있었으면 D / C 를 만들자.
                // +++++++++++++++++++++++++++++++
                // A를 토대로 D를 만들자.
                sqltext = String.Format(@"
INSERT INTO PABREDMA 
          (PID, BLOD_RDIA_SQNO, RDIA_SQNO, OTPT_ADMS_DVCD, PT_CMHS_NO, 
           RCPT_OCRR_UNIQ_NO, CMPY_STRT_DD, CMPY_END_DD, INSN_TYCD, ASST_TYCD, 
           MEFE_CD, EDI_CD, MEFE_HNM, QTY, NODY, 
           UNPR, BYKN_ADTN_AMT, CLCL_AMT, RDIA_AMT, RCPT_YN,
           RCPT_DD, RCPT_TIME, ROW_STAT_DVCD, RGST_DT, RGSTR_ID)
   VALUES ('{0}', {1}, (SELECT NVL(MAX(RDIA_SQNO), 0) + 1 FROM PABREDMA WHERE PID = '{0}' AND BLOD_RDIA_SQNO = {1}), '{2}', {3}, 
           '{4}', '{5}', '{6}', '{7}', '{8}',
           '{9}', '{10}', '{11}', '{12}', '{13}',
           '{14}', '{15}', '{16}', '{17}', '{18}',
           '{19}', '{20}', '{21}', '{22}', '{23}' ) ", dt.Rows[0]["PID"].ToString()
                                                     , dt.Rows[0]["BLOD_RDIA_SQNO"].ToString()
                                                     , dt.Rows[0]["OTPT_ADMS_DVCD"].ToString()
                                                     , dt.Rows[0]["PT_CMHS_NO"].ToString()
                                                     , dt.Rows[0]["RCPT_OCRR_UNIQ_NO"].ToString()
                                                     , dt.Rows[0]["CMPY_STRT_DD"].ToString()
                                                     , dt.Rows[0]["CMPY_END_DD"].ToString()
                                                     , dt.Rows[0]["INSN_TYCD"].ToString()
                                                     , dt.Rows[0]["ASST_TYCD"].ToString()
                                                     , dt.Rows[0]["MEFE_CD"].ToString()
                                                     , dt.Rows[0]["EDI_CD"].ToString()
                                                     , dt.Rows[0]["MEFE_HNM"].ToString()
                                                     , dt.Rows[0]["QTY"].ToString()
                                                     , dt.Rows[0]["NODY"].ToString()
                                                     , dt.Rows[0]["UNPR"].ToString()
                                                     , dt.Rows[0]["BYKN_ADTN_AMT"].ToString()
                                                     , dt.Rows[0]["CLCL_AMT"].ToString()
                                                     , dt.Rows[0]["RDIA_AMT"].ToString()
                                                     , dt.Rows[0]["RCPT_YN"].ToString()
                                                     , dt.Rows[0]["RCPT_DD"].ToString()
                                                     , dt.Rows[0]["RCPT_TIME"].ToString()
                                                     , "D"
                                                     , currentdate
                                                     , DOPack.UserInfo.USER_CD);
                /*
                sqltext = String.Format(SQL.PA.Sql.InsertPACOBSMA(), dt.Rows[0]["APLY_UNIQ_SQNO"].ToString()
                                                                   , dt.Rows[0]["PID"].ToString()
                                                                   , dt.Rows[0]["PT_CMHS_NO"].ToString()
                                                                   , dt.Rows[0]["RCPT_OCRR_UNIQ_NO"].ToString()
                                                                   , dt.Rows[0]["OTPT_ADMS_DVCD"].ToString()

                                                                   , String.IsNullOrWhiteSpace(dt.Rows[0]["DIS_PAY_SURA"].ToString()) ? "null" : dt.Rows[0]["DIS_PAY_SURA"].ToString()
                                                                   , String.IsNullOrWhiteSpace(dt.Rows[0]["DIS_PAY_AMT"].ToString()) ? "null" : dt.Rows[0]["DIS_PAY_AMT"].ToString()
                                                                   , String.IsNullOrWhiteSpace(dt.Rows[0]["DIS_NOPY_SURA"].ToString()) ? "null" : dt.Rows[0]["DIS_NOPY_SURA"].ToString()
                                                                   , String.IsNullOrWhiteSpace(dt.Rows[0]["DIS_NOPY_AMT"].ToString()) ? "null" : dt.Rows[0]["DIS_NOPY_AMT"].ToString()
                                                                   , String.IsNullOrWhiteSpace(dt.Rows[0]["SPPT_PAY_SURA"].ToString()) ? "null" : dt.Rows[0]["SPPT_PAY_SURA"].ToString()
                                                                   , String.IsNullOrWhiteSpace(dt.Rows[0]["SPPT_PAY_AMT"].ToString()) ? "null" : dt.Rows[0]["SPPT_PAY_AMT"].ToString()
                                                                   , String.IsNullOrWhiteSpace(dt.Rows[0]["SPPT_NOPY_SURA"].ToString()) ? "null" : dt.Rows[0]["SPPT_NOPY_SURA"].ToString()
                                                                   , String.IsNullOrWhiteSpace(dt.Rows[0]["SPPT_NOPY_AMT"].ToString()) ? "null" : dt.Rows[0]["SPPT_NOPY_AMT"].ToString()

                                                                   , dt.Rows[0]["CMPY_STRT_DD"].ToString()
                                                                   , dt.Rows[0]["CMPY_END_DD"].ToString()
                                                                   , String.Empty
                                                                   , String.Empty
                                                                   , String.Empty

                                                                   , "D"
                                                                   , "A"
                                                                   , dt.Rows[0]["RGST_DT"].ToString()
                                                                   , dt.Rows[0]["RGSTR_ID"].ToString()
                                                                   , currentdate
                                                                   , DOPack.UserInfo.USER_CD);
                 * */

                if (!DBService.ExecuteNonQuery(sqltext))
                    throw new Exception("혈액감액 수납금액을 취소(D)하는 중 에러가 발생했습니다. (1)");

                // A를 C로 업데이트 하자.
                sqltext = String.Format(@"
    UPDATE PABREDMA
       SET ROW_STAT_DVCD = 'C'
     WHERE PID = '{0}'
       AND PT_CMHS_NO = {1}
       AND RDIA_SQNO = {2}
       AND ROW_STAT_DVCD = 'A' ", dt.Rows[0]["PID"].ToString()
                                , dt.Rows[0]["BLOD_RDIA_SQNO"].ToString()
                                , dt.Rows[0]["RDIA_SQNO"].ToString());

                /*
                sqltext = SQL.PA.Sql.UpdatePACOBSMA_C(dt.Rows[0]["PID"].ToString()
                                                    , dt.Rows[0]["PT_CMHS_NO"].ToString()
                                                    , dt.Rows[0]["RCPT_OCRR_UNIQ_NO"].ToString()
                                                    , currentdate
                                                    , DOPack.UserInfo.USER_CD
                                                    , dt.Rows[0]["CMPY_STRT_DD"].ToString()
                                                    , dt.Rows[0]["CMPY_END_DD"].ToString());
                */

                if (!DBService.ExecuteNonQuery(sqltext))
                    throw new Exception("혈액감액 수납금액을 취소(C)하는 중 에러가 발생했습니다. (2)");
            }
            catch (ex)
            {
                let error:string = DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);

                msg = ex.Message + error;

                return false;
            }

            return true;
        }

        public static SavePACOBSMA_Make_C_D(pid:string, ptcmhsno:string, prevRcptOcrrUniqNo:string, currentdate:string, msg:string)
        {
            try
            {
                // +++++++++++++++++++++++++++++++
                // 아직 수납된 적이 없으면 리턴
                // +++++++++++++++++++++++++++++++
                if (String.IsNullOrWhiteSpace(prevRcptOcrrUniqNo))
                    return true;

                // +++++++++++++++++++++++++++++++
                // 협력업체 수납금액이 없었으면 리턴
                // +++++++++++++++++++++++++++++++
                let dt:DataTable = new DataTable();
                let sqltext:string = SQL.PA.Sql.SelectPACOBSMA_RcptOcrrUniqNo(pid, ptcmhsno, prevRcptOcrrUniqNo);
                if (!DBService.ExecuteDataTable(sqltext, dt))
                    throw new Exception("협력업체 수납금액을 조회하는 중 에러가 발생했습니다.");

                if (dt.Rows.Count.Equals(0))
                    return true;

                // +++++++++++++++++++++++++++++++
                // 협력업체 수납금액이 있었으면 D / C 를 만들자.
                // +++++++++++++++++++++++++++++++
                // A를 토대로 D를 만들자.
                sqltext = String.Format(SQL.PA.Sql.InsertPACOBSMA(), dt.Rows[0]["APLY_UNIQ_SQNO"].ToString()
                                                                   , dt.Rows[0]["PID"].ToString()
                                                                   , dt.Rows[0]["PT_CMHS_NO"].ToString()
                                                                   , dt.Rows[0]["RCPT_OCRR_UNIQ_NO"].ToString()
                                                                   , dt.Rows[0]["OTPT_ADMS_DVCD"].ToString()

                                                                   , String.IsNullOrWhiteSpace(dt.Rows[0]["DIS_PAY_SURA"].ToString()) ? "null" : dt.Rows[0]["DIS_PAY_SURA"].ToString()
                                                                   , String.IsNullOrWhiteSpace(dt.Rows[0]["DIS_PAY_AMT"].ToString()) ? "null" : dt.Rows[0]["DIS_PAY_AMT"].ToString()
                                                                   , String.IsNullOrWhiteSpace(dt.Rows[0]["DIS_NOPY_SURA"].ToString()) ? "null" : dt.Rows[0]["DIS_NOPY_SURA"].ToString()
                                                                   , String.IsNullOrWhiteSpace(dt.Rows[0]["DIS_NOPY_AMT"].ToString()) ? "null" : dt.Rows[0]["DIS_NOPY_AMT"].ToString()
                                                                   , String.IsNullOrWhiteSpace(dt.Rows[0]["SPPT_PAY_SURA"].ToString()) ? "null" : dt.Rows[0]["SPPT_PAY_SURA"].ToString()
                                                                   , String.IsNullOrWhiteSpace(dt.Rows[0]["SPPT_PAY_AMT"].ToString()) ? "null" : dt.Rows[0]["SPPT_PAY_AMT"].ToString()
                                                                   , String.IsNullOrWhiteSpace(dt.Rows[0]["SPPT_NOPY_SURA"].ToString()) ? "null" : dt.Rows[0]["SPPT_NOPY_SURA"].ToString()
                                                                   , String.IsNullOrWhiteSpace(dt.Rows[0]["SPPT_NOPY_AMT"].ToString()) ? "null" : dt.Rows[0]["SPPT_NOPY_AMT"].ToString()

                                                                   , dt.Rows[0]["CMPY_STRT_DD"].ToString()
                                                                   , dt.Rows[0]["CMPY_END_DD"].ToString()
                                                                   , String.Empty
                                                                   , String.Empty
                                                                   , String.Empty

                                                                   , "D"
                                                                   , "A"
                                                                   , dt.Rows[0]["RGST_DT"].ToString()
                                                                   , dt.Rows[0]["RGSTR_ID"].ToString()
                                                                   , currentdate
                                                                   , DOPack.UserInfo.USER_CD);
                if (!DBService.ExecuteNonQuery(sqltext))
                    throw new Exception("협력업체 수납금액을 취소(D)하는 중 에러가 발생했습니다. (1)");

                // A를 C로 업데이트 하자.
                sqltext = SQL.PA.Sql.UpdatePACOBSMA_C(dt.Rows[0]["PID"].ToString()
                                                    , dt.Rows[0]["PT_CMHS_NO"].ToString()
                                                    , dt.Rows[0]["RCPT_OCRR_UNIQ_NO"].ToString()
                                                    , currentdate
                                                    , DOPack.UserInfo.USER_CD
                                                    , dt.Rows[0]["CMPY_STRT_DD"].ToString()
                                                    , dt.Rows[0]["CMPY_END_DD"].ToString());

                if (!DBService.ExecuteNonQuery(sqltext))
                    throw new Exception("협력업체 수납금액을 취소(C)하는 중 에러가 발생했습니다. (2)");
            }
            catch (ex)
            {
                let error:string = DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);

                msg = ex.Message + error;

                return false;
            }

            return true;
        }

        public static CheckNotAply_CttrUnclAplyAmt(pid:string, ptcmhsno:string, cmpystrtdd:string, cmpyenddd:string)
        {
            let message:string = String.Empty;

            try
            {
                let sqltext:string = SQL.PA.Sql.SelectPACOBSMA_ExistNotApply(pid, ptcmhsno, cmpystrtdd, cmpyenddd);

                let dt:DataTable = new DataTable();
                if (!DBService.ExecuteDataTable(sqltext, dt))
                    throw new Exception("협력업체 지원금액 존재유무 체크 중 에러가 발생했습니다.");

                if (!dt.Rows.Count.Equals(0))
                {
                    let msg:string = "수납되지 않은 협력업체 지원금액이 존재합니다.\r\n재수납하는 경우 삭제하고 다시 적용해야 합니다.\r\n삭제 하시겠습니까?\r\n(다른 유저가 수납중일 경우 삭제하지 마십시오.)";
                    if (!LxMessage.ShowQuestion(msg).Equals(DialogResult.Yes))
                        return true;

                    // 적용되지 않은 협력업체 지원금액이 존재하는 경우 전체 삭제(del_yn = 'D')한다.
                    let currnetdate:string = DateTime.Now.ToString("yyyyMMddHHmmss");

                    sqltext = SQL.PA.Sql.DeletePACOBSMA_ExistNotApply(currnetdate, DOPack.UserInfo.USER_CD, pid, ptcmhsno, cmpystrtdd, cmpyenddd);
                    if (!DBService.ExecuteNonQuery(sqltext))
                        throw new Exception("협력업체 지원금액 중 수납에 적용되지 않은 금액을 삭제하는 중 에러가 발생했습니다.");
                }
            }
            catch (ex)
            {
                let error:string = DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);

                LxMessage.ShowError(ex.Message + error);
                return false;
            }

            return true;
        }

        public static ValidationPACOBSMA(pid:string, ptcmhsno:string, otptAdmsDvcd:string, cmpystrtdd:string, cmpyenddd:string, cttrunclaplyamt:string, object cttrnocd, msg:string)
        {
            if (String.IsNullOrWhiteSpace(cttrunclaplyamt) || cttrunclaplyamt.Equals("0") || cttrnocd == null || String.IsNullOrWhiteSpace(cttrnocd.ToString()))
                return true;

            try
            {
                let sqltext:string = SQL.PA.Sql.SelectPACOBSMA_ExistsSaveData(cttrnocd.ToString(), pid, ptcmhsno, otptAdmsDvcd, cmpystrtdd, cmpyenddd);

                let dt:DataTable = new DataTable();
                if (!DBService.ExecuteDataTable(sqltext, dt))
                    throw new Exception("협력업체 수납내역 조회 중 에러가 발생했습니다.");

                if (dt.Rows.Count.Equals(0))
                    throw new Exception("협력업체 지원금액이 다른 사용자에 의해 삭제취소 되었습니다.\r\n협력업체 지원금액 적용을 취소하고 다시 적용해 주세요.");
            }
            catch (ex)
            {
                let error:string = DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);

                msg = ex.Message + error;
                return false;
            }

            return true;
        }

        public static GetExcpResnCd(mdcrDd:string, mdcrTimeString:string)
        {
            //// 병원정보의 응급실 원외처방 시간을 무시하고 무조건 원외로 세팅해야 되는 경우 리턴 NO
            //// 2019-04-11 현재 베스티안부산병원에서 그렇게 사용중
            //if (ConfigService.GetConfigValueBool("PA", "ER_NO_YN", "ER_NO_YN", false))
            //    return "NO";

            // 2021-02-05 SJH 예외사유구분코드를 응급실 원외처방시간 무시하고 저장할 지 여부 (부산 : NO / 오송, 우송 : 11 / 서울, 부천 : TIME)
            let default_excp_resn_cd:string = ConfigService.GetConfigValueString("PA", "ER_NO_YN", "EXCP_RESN_CD").ToString();
            if (!default_excp_resn_cd.Equals("TIME"))
                return default_excp_resn_cd;

            //// 응급실분류가 [응급실]이 아닌 경우 리턴 11 (예외사유코드 11)
            //if (DOPack.HospitalInfo.ETC_USE_CNTS_1 != "2")
            //return "11";

            if (String.IsNullOrWhiteSpace(DOPack.HospitalInfo.EHOP_STRT_TIME) || String.IsNullOrWhiteSpace(DOPack.HospitalInfo.EHOP_END_TIME))
                return "11";

            let dt:DataTable = new DataTable();
            DBService.ExecuteDataTable($" SELECT * FROM BIHODYMA WHERE PBHL_DD = '{mdcrDd}' AND PBHL_ADTN_APLY_YN = 'Y' ", dt);
            if (dt.Rows.Count > 0)
            {
                // 공휴일의 경우
                return "11";
            }

            let mdcrTime:number = 0;
            Int.TryParse(mdcrTimeString, mdcrTime);

            let strtTime:number = 0;
            let endTime:number = 0;
            if (DateTimeService.ConvertDateTime(mdcrDd).DayOfWeek == DayOfWeek.Saturday)
            {
                // 토요일의 경우
                Int.TryParse(DOPack.HospitalInfo.HPBH_STRT_TIME, strtTime);
                Int.TryParse(DOPack.HospitalInfo.HPBH_END_TIME, endTime);
            }
            else
            {
                // 평일의 경우
                Int.TryParse(DOPack.HospitalInfo.EHOP_STRT_TIME, strtTime);
                Int.TryParse(DOPack.HospitalInfo.EHOP_END_TIME, endTime);
            }

            if (strtTime <= mdcrTime || mdcrTime < endTime)
                return "11";

            return "NO";
        }

        public static GetBillNoAmt(pid:string, cccs_ocrr_dvcd:string, ptcmhsno:string, cmpydd:string, decimal card_amt, decimal cash_amt, decimal bank_amt)
        {
            try
            {
                card_amt = 0;
                cash_amt = 0;
                bank_amt = 0;

                let dt:DataTable = new DataTable();

                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectBillNoApply()
                                              , dt
                                              , pid, cccs_ocrr_dvcd, ptcmhsno, cmpydd))
                    throw new Exception("승인내역 조회중 에러가 발생했습니다.");

                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        switch (dr["CASH_CARD_DVCD"].ToString())
                        {
                            case "01":
                                card_amt = decimal.Parse(dr["CARD_PRMT_AMT"].ToString());
                                break;
                            case "02":
                                cash_amt = decimal.Parse(dr["CASH_PRMT_AMT"].ToString());
                                break;
                            case "03":
                                bank_amt = decimal.Parse(dr["CASH_PRMT_AMT"].ToString());
                                break;
                        }
                    }
                }
            }
            catch (ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static GetSpclDcnt(cccs_ocrr_dvcd:string, pid:string, ptcmhsno:string, spcl_dcnt_dvcd:string, decimal spcl_dcnt_amt)
        {
            try
            {
                spcl_dcnt_dvcd = String.Empty;
                spcl_dcnt_amt = 0;

                let dt:DataTable = new DataTable();

                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectSpclDcnt(cccs_ocrr_dvcd, pid, ptcmhsno)
                                              , dt))
                    throw new Exception("할인내역 조회중 에러가 발생했습니다.");

                if (dt.Rows.Count > 0)
                {
                    spcl_dcnt_dvcd = dt.Rows[0]["SPCL_DCNT_DVCD"].ToString();
                    decimal.TryParse(dt.Rows[0]["SPCL_DCNT_AMT"].ToString(), spcl_dcnt_amt);
                }
            }
            catch (ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static GetSpclDcntDsch(pid:string, ptcmhsno:string, rcpt_sqno:string, spcl_dcnt_dvcd:string, decimal spcl_dcnt_amt)
        {
            try
            {
                spcl_dcnt_dvcd = String.Empty;
                spcl_dcnt_amt = 0;

                let dt:DataTable = new DataTable();

                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectSpclDcntDsch(pid, ptcmhsno, rcpt_sqno)
                                              , dt))
                    throw new Exception("할인내역 조회중 에러가 발생했습니다.");

                if (dt.Rows.Count > 0)
                {
                    spcl_dcnt_dvcd = dt.Rows[0]["SPCL_DCNT_DVCD"].ToString();
                    decimal.TryParse(dt.Rows[0]["SPCL_DCNT_AMT"].ToString(), spcl_dcnt_amt);
                }
            }
            catch (ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static InsertPAOPASRT(pid:string, pt_cmhs_no:string, rcpn_sqno:string, asst_tycd:string, cfsc_rgno_cd:string, ecoi_cd:string, trbc_dvcd:string, msg:string)
        {
            string sqltext = String.Format(@"
    INSERT INTO PAOPASRT
         ( PID, PT_CMHS_NO, RCPN_SQNO, SQNO, ASST_TYCD, CFSC_RGNO_CD, ECOI_CD, TRBC_DVCD, DLWT_IP_ADDR, RGST_DT, RGSTR_ID )
    VALUES
         ( '{0}',      {1},       {2}, (SELECT NVL(MAX(SQNO), 0) + 1 FROM PAOPASRT WHERE PID = '{0}' AND PT_CMHS_NO = {1} AND RCPN_SQNO = {2}),
                                                 '{3}',        '{4}',   '{5}',     '{6}',        '{7}',   '{8}',    '{9}' ) "
                                , pid, pt_cmhs_no, rcpn_sqno, asst_tycd, cfsc_rgno_cd, ecoi_cd, trbc_dvcd, ClientService.IP, DateTime.Now.ToString("yyyyMMddHHmmss"), DOPack.UserInfo.USER_CD);

            if (!DBService.ExecuteNonQuery(sqltext))
            {
                msg = "외래보조유형세팅이력 저장 중 에러가 발생했습니다.";
                return false;
            }

            return true;
        }

        public static SetComboboxForeColor(LxComboBox comboBox, type:string)
        {
            if (comboBox == null || comboBox.SelectedItem == null)
                return;

            let select_value:string = comboBox.SelectedItem.DataValue.ToString();

            switch (type)
            {
                // 자격여부 (급여대상이 아니면 Red)
                case "01_PAYQLFCDVCD":
                    comboBox.Appearance.ForeColor = select_value.Equals("0") ? Color.FromArgb(30, 30, 30) : Color.FromArgb(220, 0, 0);
                    break;

                // 보험유형
                case "02_INSNTYCD":
                    comboBox.Appearance.ForeColor = select_value.Equals("11") ? Color.FromArgb(30, 30, 30) :
                                                    select_value.Equals("21") || select_value.Equals("22") ? Color.Blue :
                                                    select_value.Equals("31") ? Color.Green :
                                                    select_value.Equals("41") ? Color.Purple :
                                                    select_value.Equals("51") ? Color.Red : Color.FromArgb(30, 30, 30);
                    break;

                // 진찰료산정
                case "03_MCCHCMPTDVCD":
                    comboBox.Appearance.ForeColor = select_value.Equals("N") ? Color.Red : Color.FromArgb(30, 30, 30);
                    break;
            }
        }

        public static CheckIsolationRoom(room_dvcd:string, date:string)
        {
            string sqltext = String.Format(@"
  SELECT ETC_USE_CNTS_6
    FROM BICDINDT
   WHERE OVRL_CD = 'ROOM_DVCD'
     AND LWRN_OVRL_CD = '{0}' 
     AND '{1}' BETWEEN APLY_STRT_DD AND APLY_END_DD ", room_dvcd, date);

            let RetVal:DateTime = DBService.ExecuteScalar(sqltext);
            if (RetVal != null && RetVal.ToString() == "I")
                return true;

            return false;
        }

        public static HasNonPermit()
        {
            m_NonPermitDt.Clear();

            if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOBILBD_MDAD_PRMT_NO(), m_NonPermitDt))
                LxMessage.ShowInformation("의료급여환자 승인 조회 중 에러가 발생했습니다.");

            if (m_NonPermitDt.Rows.Count.Equals(0))
                return false;

            return true;
        }

        public static Cancel16A(string pid, string ptcmhsno, string cmpystrtdd, string cmpyenddd, string m_CmpyDvcd, string currentdate,
                                     string pt_shar_amt, string usch_uplm_amt, string insn_tycd, string asst_tycd, decimal emrg_supt_amt, decimal spcl_dcnt_amt, string msg)
        {
            try
            {
                // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                // 일괄 중간정산 16A만 남겨진 상태로 수납하려고 하면 16A를 취소해준다.
                // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                let dt:DataTable = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAIBILBD_16(pid, ptcmhsno, "A", cmpystrtdd, cmpyenddd), dt))
                    throw new Exception(String.Format("재원미수 조회 중 에러가 발생했습니다.{0}", DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : ""));

                if (dt == null || dt.Rows.Count.Equals(0))
                    return true;

                let errordvcd:string = String.Empty;
                let errorcnts:string = String.Empty;

                for (int RowIndex = 0; RowIndex < dt.Rows.Count; RowIndex++)
                {
                    let cmpy_strt_dd_16A:string = dt.Rows[RowIndex]["CMPY_STRT_DD"].ToString();
                    let cmpy_end_dd_16A:string = dt.Rows[RowIndex]["CMPY_END_DD"].ToString();

                    if (!SqlPack.Procedure.PR_PA_READ_ALLMIDBILCRCAN_UNCL(cmpy_end_dd_16A, currentdate.Substring(0, 8), pid, ptcmhsno, ClientEnvironment.IP, DOPack.UserInfo.USER_CD
                                                                    , currentdate, "16", errordvcd, errorcnts))
                        throw new Exception(String.Format("재원미수(16)의 취소 데이터를 생성하는 중 에러가 발생했습니다.\r\n{0}", errordvcd));

                    errordvcd = String.Empty;

                    // 금액이 달라졌을 때 다시 미수코드20을 남기는 것은 중간정산일 때만.
                    // 2019-08-05 SJH 긴급지원금액이 존재하는 경우
                    // 2019-08-19 SJH 같은 기간 내에서
                    // 2019-08-30 SJH 할인금액이 존재하는 경우
                    //                본인부담금이 변경된 경우
                    // 2020-01-14 SJH 본인부담상한액이 변경된 경우
                    if (m_CmpyDvcd == "J" && cmpy_strt_dd_16A == cmpystrtdd && cmpy_end_dd_16A == cmpyenddd &&
                        (pt_shar_amt != dt.Rows[RowIndex]["PT_SHAR_AMT"].ToString() || emrg_supt_amt > 0 || spcl_dcnt_amt > 0 || usch_uplm_amt != dt.Rows[RowIndex]["USCH_UPLM_AMT"].ToString()))
                    {
                        // 본인부담금이 다른 경우 20로 미수 다시 남겨주자.
                        if (!SqlPack.Procedure.PR_PA_READ_ALLMIDBILCR(pid, ptcmhsno, m_CmpyDvcd, cmpystrtdd, cmpy_end_dd_16A
                                                                    , insn_tycd, asst_tycd, ClientEnvironment.IP, DOPack.UserInfo.USER_CD, currentdate
                                                                    , "20", errordvcd, errorcnts))
                            throw new Exception(String.Format("재원미수(20)을 생성하는 중 에러가 발생했습니다.\r\n{0}", errordvcd));

                        if (errordvcd == "9")
                            throw new Exception(String.Format("재원미수(20)을 생성하는 중 에러가 발생했습니다.(ERROR_DVCD = '9')\r\n{0}", errordvcd));

                        if (!SqlPack.Procedure.PR_PA_READ_ALLMIDBILCRCAN_UNCL(cmpy_end_dd_16A, currentdate.Substring(0, 8), pid, ptcmhsno, ClientEnvironment.IP, DOPack.UserInfo.USER_CD
                                                                        , currentdate, "20", errordvcd, errorcnts))
                            throw new Exception(String.Format("재원미수(20)의 취소 데이터를 생성하는 중 에러가 발생했습니다.\r\n{0}", errordvcd));
                    }
                }

                return true;
            }
            catch (ex)
            {
                let error:string = DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                msg = ex.Message + error;
                return false;
            }
        }

        public static Cancel16A_Create20CD(string pid, string ptcmhsno, string cmpystrtdd, string cmpyenddd, string m_CmpyDvcd, string currentdate,
                                        string insn_tycd, string asst_tycd, string msg)
        {
            try
            {
                // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                // 일괄 중간정산 16A만 남겨진 상태로 수납 취소하려고 하면 16A를 취소해 주고 20CD도 만든다.
                // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                let dt:DataTable = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAIBILBD_16(pid, ptcmhsno, "A", cmpystrtdd, cmpyenddd), dt))
                    throw new Exception(String.Format("재원미수 조회 중 에러가 발생했습니다.{0}", DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : ""));

                if (dt == null || dt.Rows.Count.Equals(0))
                    return false;

                let errordvcd:string = String.Empty;
                let errorcnts:string = String.Empty;

                // DBService.BeginTransaction ();

                for (int RowIndex = 0; RowIndex < dt.Rows.Count; RowIndex++)
                {
                    let cmpy_strt_dd_16A:string = dt.Rows[RowIndex]["CMPY_STRT_DD"].ToString();
                    let cmpy_end_dd_16A:string = dt.Rows[RowIndex]["CMPY_END_DD"].ToString();

                    if (!SqlPack.Procedure.PR_PA_READ_ALLMIDBILCRCAN_UNCL(cmpy_end_dd_16A, currentdate.Substring(0, 8), pid, ptcmhsno, ClientEnvironment.IP, DOPack.UserInfo.USER_CD
                                                                    , currentdate, "16", errordvcd, errorcnts))
                        throw new Exception(String.Format("재원미수(16)의 취소 데이터를 생성하는 중 에러가 발생했습니다.\r\n{0}", errordvcd));

                    errordvcd = String.Empty;

                    // 본인부담금이 다른 경우 20로 미수 다시 남겨주자.
                    if (!SqlPack.Procedure.PR_PA_READ_ALLMIDBILCR(pid, ptcmhsno, m_CmpyDvcd, cmpystrtdd, cmpy_end_dd_16A
                                                                , insn_tycd, asst_tycd, ClientEnvironment.IP, DOPack.UserInfo.USER_CD, currentdate
                                                                , "20", errordvcd, errorcnts))
                        throw new Exception(String.Format("재원미수(20)을 생성하는 중 에러가 발생했습니다.\r\n{0}", errordvcd));

                    if (errordvcd == "9")
                        throw new Exception(String.Format("재원미수(20)을 생성하는 중 에러가 발생했습니다.(ERROR_DVCD = '9')\r\n{0}", errordvcd));

                    if (!SqlPack.Procedure.PR_PA_READ_ALLMIDBILCRCAN_UNCL(cmpy_end_dd_16A, currentdate.Substring(0, 8), pid, ptcmhsno, ClientEnvironment.IP, DOPack.UserInfo.USER_CD
                                                                    , currentdate, "20", errordvcd, errorcnts))
                        throw new Exception(String.Format("재원미수(20)의 취소 데이터를 생성하는 중 에러가 발생했습니다.\r\n{0}", errordvcd));
                }

                // DBService.CommitTransaction ();

                LxMessage.ShowInformation("정산 취소 완료 되었습니다.");
                return true;
            }
            catch (ex)
            {
                let error:string = DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                // if(DBService.IsTransaction)
                    // DBService.RollbackTransaction();

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
                return false;
            }
        }

        public static CheckNeedReReceipt()
        {
            let count:number = DBService.ExecuteInteger(SQL.PA.Sql.SelectCountReReciept());

            return count > 0 ? true : false;
        }

        public static UpdatePAORCHMA(pid:string, pt_cmhs_no:string, currentdate:string)
        {
            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePAORCHMA_RgstDt(pid, pt_cmhs_no, currentdate, currentdate, DOPack.UserInfo.USER_CD)))
                throw new Exception("재수납 대상 환자 확인여부 저장 중 에러가 발생했습니다.");
        }

        public static SetButtonColor(LxButton btn, colorType:string)
        {
            if (colorType.Equals("0"))
            {
                // 기본 색깔 (Green)
                btn.Appearance.BorderColor = Color.FromArgb(10, 150, 90);
                btn.Appearance.ForeColor = Color.FromArgb(0, 90, 20);
                btn.HotTrackAppearance.BorderColor = Color.FromArgb(10, 150, 90);
                btn.HotTrackAppearance.ForeColor = Color.FromArgb(0, 150, 50);
                btn.PressedAppearance.BorderColor = Color.FromArgb(10, 150, 90);
                btn.PressedAppearance.ForeColor = Color.FromArgb(0, 150, 50);
            }
            else if (colorType.Equals("1"))
            {
                // Red
                btn.Appearance.BorderColor = Color.Red;
                btn.Appearance.ForeColor = Color.Red;
                btn.HotTrackAppearance.BorderColor = Color.Red;
                btn.HotTrackAppearance.ForeColor = Color.Red;
                btn.PressedAppearance.BorderColor = Color.Red;
                btn.PressedAppearance.ForeColor = Color.Red;
            }
        }

        public static SetAutoB099(LxComboBox insnTycd, LxComboBox asstTycd, LxComboBox uschAplyCd)
        {
            /*
            if (!asstTycd.SelectedValue.Equals("0T") || (!insnTycd.SelectedValue.Equals("21") && !insnTycd.SelectedValue.Equals("22")))
            {
                if (uschAplyCd.SelectedValue == "B099")
                    LxMessage.ShowError("본인코드를 확인해 주세요.");

                return;
            }

            // 코로나19
            if (uschAplyCd.SelectedValue != "B099")
            {
                uschAplyCd.SelectedValue = "B099";
                LxMessage.ShowInformation("본인코드 [B099]로 자동 세팅됩니다.");
            }
            */
        }

        public static ShowPopupCashRepermit(UserControl base_form, pid:string, pt_cmhs_no:number, cmpy_dd:string, bill_no:string)
        {
            frmCardCashPermitP popup = null;

            try
            {
                clsCardCashPermitInfo clsPermitInfo = new clsCardCashPermitInfo();
                clsPermitInfo.PID = pid;
                clsPermitInfo.PT_CMHS_NO = pt_cmhs_no;
                clsPermitInfo.CMPY_DD = cmpy_dd;
                clsPermitInfo.PRMT_RQST_DVCD = "C";
                clsPermitInfo.BILL_NO = bill_no;
                clsPermitInfo.CheckBillNo = true;

                popup = new frmCardCashPermitP(clsPermitInfo);
                popup.ShowDialog(base_form);
                return true;
            }
            catch (ex)
            {
                let error:string = DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
                return false;
            }
            finally
            {
                if (popup != null)
                {
                    popup.Dispose();
                    popup = null;
                }
            }
        }

        public static CheckChangedUschUplmAmtFromCL()
        {
            let count:number = DBService.ExecuteInteger(SQL.PA.Sql.SelectPACLRSMA_CU());

            return count > 0;
        }

        public static HasPatientMemo(pid:string)
        {
            return DBService.ExecuteInteger(SQL.PA.Sql.SelectFTPMMMA_List_Count(pid)) > 0;
        }

        public static RePrmtMdadNo(pid:string, rqst_sqno:string)
        {
            try
            {
                let currentdate:string = DateTime.Now.ToString("yyyyMMddHHmmss");

                // DBService.BeginTransaction ();

                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertPANHM4MA_BK(pid, rqst_sqno, currentdate, DOPack.UserInfo.USER_CD)))
                    throw new Exception("기존 승인내역을 백업하는 중 에러가 발생했습니다.");

                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.DeletePANHM4MA(pid, rqst_sqno)))
                    throw new Exception("기존 승인내역을 삭제하는 중 에러가 발생했습니다.");

                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePANHM3MA_Reset(pid, rqst_sqno)))
                    throw new Exception("재승인 정보를 저장하는 중 에러가 발생했습니다.");

                // DBService.CommitTransaction ();
                return true;
            }
            catch (ex)
            {
                let error:string = DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                // if(DBService.IsTransaction)
                    // DBService.RollbackTransaction();

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
                return false;
            }
        }
    }
}
