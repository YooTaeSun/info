package web.townsi.com.work.setting.biz.impl;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;
import web.townsi.com.utils.ListUtil;
import web.townsi.com.work.mapper.SettingMapper;
import web.townsi.com.work.setting.biz.SettingBiz;
import web.townsi.com.work.setting.biz.SettingFilterBiz;

/**
* SettingServiceImpl
* @author 유태선
* @since 2020.08.31
* @version 1.0
* @see
* </pre>
*/
@SuppressWarnings({"rawtypes","unchecked","unused"})
@Service
public class SettingFilterBizImpl implements SettingFilterBiz {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private SettingBiz settingBiz;

	@Autowired
	private SettingMapper settingMapper;


	public static String LINE = "\n";
	public static String SPACE_CNT = "    ";
	public static String SLASH = File.separator;// lastIndexOf("/")


	public static String rTxt  = "#{txt}";

	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();

	public HashMap makeFilter(HashMap params) throws Exception {
		HashMap dataMap = new HashMap();
		HashMap replaceMap = new HashMap();
		StringBuilder dtoMemer = new StringBuilder(500);
		StringBuilder dtoSearcgMemer = new StringBuilder(500);
		StringBuilder dtoMethod = new StringBuilder(500);
		StringBuilder conParam = new StringBuilder(500);
		StringBuilder conParamBody = new StringBuilder(500);

		String column_name = "";
		String mem_vari = "";
		String column_comment = "";
		String camel_column_name = "";
		String set_get_column_name = "";
		String w_type = "";
		String pk = "";
		String is_nullable = "";

		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String upperTableName = StringUtils.defaultString((String) params.get("upperTableName"));
		String lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		String camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		String tableSchema = StringUtils.defaultString((String) params.get("tableSchema"));
		String camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String group1 = StringUtils.defaultString((String) params.get("group1"));
		String author = StringUtils.defaultString((String) params.get("author"));
		String desc = StringUtils.defaultString((String) params.get("desc"));
		String today = StringUtils.defaultString((String) params.get("today"));
		String current = StringUtils.defaultString((String) params.get("current"));
		String voComment = StringUtils.defaultString((String) params.get("voComment"),"Y_NEXT");
		String sort = StringUtils.defaultString((String) params.get("sort"));
		String taskName = StringUtils.defaultString((String) params.get("taskName"));
		String taskNameFirstUpperName = StringUtils.defaultString((String) params.get("taskNameFirstUpperName"));
		String packageNm = StringUtils.defaultString((String) params.get("packageNm"));
		String tableNewName = StringUtils.defaultString((String) params.get("tableNewName"));
		String tableNewFirstUpperName = StringUtils.defaultString((String) params.get("tableNewFirstUpperName"));
		
		HashMap entityObj = (HashMap) params.get("entityObj");
		
		
		List<HashMap> list = settingBiz.selectTableInfo(params,
				  StringUtils.defaultString((String)params.get("dbName"))
				, StringUtils.defaultString((String)params.get("tableSchema"))
			    , StringUtils.defaultString((String)params.get("tableName"))
				);

		if(!taskName.isEmpty()) {
			replaceMap.put("#camelTableFirstUpperName#",taskNameFirstUpperName);
		}
		
		replaceMap.put("#camelTableName#",camelTableName);
		replaceMap.put("#dtoContent#", dtoMemer.toString());
		replaceMap.put("#searchDtoContent#", dtoSearcgMemer.toString());
		replaceMap.put("#lowerTableName#", lowerTableName.replaceAll("_", ""));
		replaceMap.put("#group#", group);
		replaceMap.put("#desc#", desc);
		replaceMap.put("#group1#", group1);
		replaceMap.put("#author#", author);
		replaceMap.put("#today#", today);
		replaceMap.put("#current#",current);
		replaceMap.put("#dtoMethod#",dtoMethod.toString());
		replaceMap.put("#upperTableName#",upperTableName);
		replaceMap.put("#tableName#",tableName);
		replaceMap.put("#camelTableFirstUpperName#",camelTableFirstUpperName);
		replaceMap.put("#taskNameFirstUpperName#",taskNameFirstUpperName);
		replaceMap.put("#taskName#",taskName);
		replaceMap.put("#packageNm#",packageNm);
		replaceMap.put("#tableNewName#", tableNewName);
		replaceMap.put("#tableNewFirstUpperName#", tableNewFirstUpperName);
		
		String rfullPath = SITE_WEB_ROOT + "/copy/SampleFilter.java";

		String wfullPath = "";
		wfullPath = SITE_WEB_ROOT + "/new/" + tableSchema + "/" + tableName+"/model/"+tableNewFirstUpperName+"Filter.java";

		String str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);

		dataMap.put("str", str);
		dataMap.put("fullPath", wfullPath);
		list = null;
		return dataMap;
	}
	
	
	
}