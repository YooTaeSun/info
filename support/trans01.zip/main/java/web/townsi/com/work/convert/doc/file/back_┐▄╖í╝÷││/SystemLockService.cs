using System;
using System.Data;
using SQL = Lime.Framework.BaseForms.Sql;

namespace Lime.Framework
{
    /// <summary>
    /// System Lock Service에 대한 요약 설명
    /// </summary>
    public class SystemLockService
    {
        private SystemLockInfo m_SystemLockInfo = new SystemLockInfo();

        public SystemLockInfo SystemLockInfo
        {
            get
            {
                return m_SystemLockInfo;
            }
            set
            {
                m_SystemLockInfo = value;
            }
        }

        public SystemLockService()
        {
            this.Clear();
            this.DeleteSystemLockDeadSession();
        }

        #region Method

        public void Clear()
        {
            m_SystemLockInfo.Clear();
        }

        /// <summary>
        /// System Lock이 걸려 있는지 확인
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="system_cd"></param>
        /// <returns></returns>
        public bool IsLocked(string pid, string pt_cmhs_no)
        {
            if (StringService.IsNotNull(pid, pt_cmhs_no))
            {
                if (ExistSystemLock(pid, pt_cmhs_no))
                    return true;
            }

            return false;
        }

        /// <summary>
        /// System Lock이 걸려 있는지 확인
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="system_cd"></param>
        /// <returns></returns>
        public bool IsLocked(string pid, string pt_cmhs_no, string system_cd)
        {
            if (StringService.IsNotNull(pid, pt_cmhs_no, system_cd))
            {
                if (ExistSystemLock(pid, pt_cmhs_no, system_cd))
                    return true;
            }

            return false;
        }

        /// <summary>
        /// System Lock이 걸려 있는지 확인
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <returns></returns>
        private bool ExistSystemLock(string pid, string pt_cmhs_no)
        {
            //TODO
            DataTable dt = new DataTable();

            try
            {
                //Select Lock Info
                if (DBService.ExecuteDataTable(SQL.ExistSystemLock(pid, pt_cmhs_no), ref dt))
                {
                    if (dt.Rows.Count > 0)
                        return true;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return false;
        }

        /// <summary>
        /// System Lock이 걸려 있는지 확인
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <returns></returns>
        private bool ExistSystemLock(string pid, string pt_cmhs_no, string system_cd)
        {
            //TODO
            DataTable dt = new DataTable();

            try
            {
                //Select Lock Info
                if (DBService.ExecuteDataTable(SQL.ExistSystemLock(pid, pt_cmhs_no, system_cd), ref dt))
                {
                    if (dt.Rows.Count > 0)
                        return true;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return false;
        }

        /// <summary>
        /// System Lock 정보 조회
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <returns></returns>
        public SystemLockInfo SelectSystemLock(string pid, string pt_cmhs_no)
        {
            SystemLockInfo lockinfo = new SystemLockInfo();
            DataTable dt = new DataTable();

            try
            {
                //Select Lock Info
                if (DBService.ExecuteDataTable(SQL.SelectSystemLock(pid, pt_cmhs_no), ref dt))
                {
                    if (dt.Rows.Count > 0)
                    {
                        lockinfo.SYSTEM_CD = dt.Rows[0]["SYSTEM_CD"].ToString();
                        lockinfo.SYSTEM_NM = dt.Rows[0]["SYSTEM_NM"].ToString();
                        lockinfo.LOCK_USER_CD = dt.Rows[0]["LOCK_USER_CD"].ToString();
                        lockinfo.LOCK_USER_NM = dt.Rows[0]["LOCK_USER_NM"].ToString();
                        lockinfo.LOCK_DEPT_CD = dt.Rows[0]["LOCK_DEPT_CD"].ToString();
                        lockinfo.LOCK_DEPT_NM = dt.Rows[0]["LOCK_DEPT_NM"].ToString();
                        lockinfo.LOCK_DT = dt.Rows[0]["LOCK_DT"].ToString();
                        lockinfo.LOCK_IP = dt.Rows[0]["LOCK_IP"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return lockinfo;
        }

        public SystemLockInfo SelectSystemLock(string pid, string pt_cmhs_no, string system_cd)
        {
            SystemLockInfo lockinfo = new SystemLockInfo();
            DataTable dt = new DataTable();

            try
            {
                //Select Lock Info
                if (DBService.ExecuteDataTable(SQL.SelectSystemLock(pid, pt_cmhs_no, system_cd), ref dt))
                {
                    if (dt.Rows.Count > 0)
                    {
                        lockinfo.SYSTEM_CD = dt.Rows[0]["SYSTEM_CD"].ToString();
                        lockinfo.SYSTEM_NM = dt.Rows[0]["SYSTEM_NM"].ToString();
                        lockinfo.LOCK_USER_CD = dt.Rows[0]["LOCK_USER_CD"].ToString();
                        lockinfo.LOCK_USER_NM = dt.Rows[0]["LOCK_USER_NM"].ToString();
                        lockinfo.LOCK_DEPT_CD = dt.Rows[0]["LOCK_DEPT_CD"].ToString();
                        lockinfo.LOCK_DEPT_NM = dt.Rows[0]["LOCK_DEPT_NM"].ToString();
                        lockinfo.LOCK_DT = dt.Rows[0]["LOCK_DT"].ToString();
                        lockinfo.LOCK_IP = dt.Rows[0]["LOCK_IP"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return lockinfo;
        }

        /// <summary>
        /// System Lock을 생성하여 Lock을 건다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="system_cd"></param>
        /// <returns></returns>
        public bool Lock(string pid, string pt_cmhs_no, string system_cd)
        {
            if (StringService.IsNotNull(pid, pt_cmhs_no, system_cd))
            {
                if (!IsLocked(pid, pt_cmhs_no))
                    return InsertSystemLockInfo(pid, pt_cmhs_no, system_cd);
            }

            return false;
        }

        /// <summary>
        /// System Lock 정보를 저장한다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="system_cd"></param>
        /// <returns></returns>
        private bool InsertSystemLockInfo(string pid, string pt_cmhs_no, string system_cd)
        {
            try
            {
                //Insert Lock
                if (DBService.ExecuteNonQuery(SQL.InsertSystemLock(pid, pt_cmhs_no, system_cd, SystemList.GetName(system_cd))))
                {
                    //Lock을 건후 Lock 정보를 다시 가져오기 위해.
                    m_SystemLockInfo = this.SelectSystemLock(pid, pt_cmhs_no);
                    return true;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return false;
        }

        /// <summary>
        /// System Lock을 삭제하여 Lock을 푼다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <returns></returns>
        public bool UnLock(string pid, string pt_cmhs_no)
        {
            if (StringService.IsNotNull(pid, pt_cmhs_no))
            {
                if (IsLocked(pid, pt_cmhs_no))
                {
                    if (DeleteSystemLock(pid, pt_cmhs_no))
                    {
                        this.Clear();
                        return true;
                    }
                }
                else
                    return true;    //삭제할 Lock이 없어도 true로 리턴
            }

            return false;
        }

        /// <summary>
        /// System Lock 정보 삭제
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="system_cd"></param>
        /// <returns></returns>
        private bool DeleteSystemLock(string pid, string pt_cmhs_no)
        {
            try
            {
                //Delete Lock
                if (DBService.ExecuteNonQuery(SQL.DeleteSystemLock(pid, pt_cmhs_no)))
                    return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return false;
        }

        public bool UnLock(string pid, string pt_cmhs_no, string system_cd)
        {
            if (StringService.IsNotNull(pid, pt_cmhs_no))
            {
                if (IsLocked(pid, pt_cmhs_no))
                {
                    if (DeleteSystemLock(pid, pt_cmhs_no, system_cd))
                    {
                        this.Clear();
                        return true;
                    }
                }
                else
                    return true;    //삭제할 Lock이 없어도 true로 리턴
            }

            return false;
        }

        /// <summary>
        /// System Lock 정보 삭제
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="system_cd"></param>
        /// <returns></returns>
        private bool DeleteSystemLock(string pid, string pt_cmhs_no, string system_cd)
        {
            try
            {
                //Delete Lock
                if (DBService.ExecuteNonQuery(SQL.DeleteSystemLock(pid, pt_cmhs_no, system_cd)))
                    return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return false;
        }

        /// <summary>
        /// User에 의해 생성된 System Lock을 모두 삭제하여 Lock을 푼다.(Login, Logout 시에 호출)
        /// </summary>
        /// <returns></returns>
        public bool UnLockUser()
        {
            if (DeleteSystemLockUser(DOPack.UserInfo.USER_CD))
            {
                this.Clear();
                return true;
            }
            else
                return false;
        }

        /// <summary>
        /// User에 의해 생성된 System Lock을 모두 삭제하여 Lock을 푼다.(Login, Logout 시에 호출)
        /// </summary>
        /// <param name="user_cd"></param>
        /// <returns></returns>
        public bool UnLockUser(string user_cd)
        {
            try
            {
                if (StringService.IsNotNull(user_cd))
                {
                    if (DeleteSystemLockUser(user_cd))
                    {
                        //지정한 User가 로그인 User와 같으면 Lock 정보를 Clear한다.                
                        if (DOPack.UserInfo.USER_CD.Equals(user_cd))
                            this.Clear();

                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return false;
        }

        /// <summary>
        /// User에 의해 생성된 System Lock을 모두 삭제
        /// </summary>
        /// <param name="user_cd"></param>
        /// <returns></returns>
        private bool DeleteSystemLockUser(string user_cd)
        {
            try
            {
                //Delete Lock of User
                if (DBService.ExecuteNonQuery(SQL.DeleteSystemLockUser(user_cd)))
                    return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return false;
        }

        /// <summary>
        /// Connection이 끊긴 유저들에 의해 생성된 System Lock을 모두 삭제하여 Lock을 푼다.(Intro 실행시 호출)
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="system_cd"></param>
        /// <returns></returns>
        public bool UnLockDeadSession()
        {
            return DeleteSystemLockDeadSession();
        }

        /// <summary>
        /// Connection이 끊긴 유저들에 의해 생성된 System Lock을 모두 삭제하여 Lock을 푼다.(Intro 실행시 호출)
        /// </summary>
        /// <returns></returns>
        private bool DeleteSystemLockDeadSession()
        {
            try
            {
                //Delete Lock of Dead Session
                if (DBService.ExecuteNonQuery(SQL.DeleteSystemLockDeadSession()))
                    return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return false;
        }

        #endregion
    }
}
