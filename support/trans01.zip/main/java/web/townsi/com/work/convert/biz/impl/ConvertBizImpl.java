package web.townsi.com.work.convert.biz.impl;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.work.convert.biz.ConvertBiz;
import web.townsi.com.work.convert.doc.ChgLangId;
import web.townsi.com.work.convert.doc.DocExcute;
import web.townsi.com.work.convert.doc.LangExcute;

/**
* ConvertBizImpl
* @author 유태선
* @version 1.0
* @see
* </pre>
*/
@SuppressWarnings({"rawtypes","unchecked","unused"})
@Service
public class ConvertBizImpl implements ConvertBiz {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

//	@Autowired
//	private SettingMapper settingMapper;

	public static String READ_LINE = "\n";
	public static String TAB = "\t";
	public static String SLASH = File.separator;// lastIndexOf("/")

	public static String rTxt  = "#{txt}";
	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();
	

	public HashMap source(HashMap params) throws Exception {

		HashMap dataMap = new HashMap();
		
		//------------  초기 param 설정 start --------------------------
		String group = StringUtils.defaultString((String) params.get("group")).toLowerCase();
		params.put("group", group);
		String group1 = StringUtils.defaultString((String) params.get("group1")).toLowerCase();
		params.put("group1", group1);


		Date today = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy.MM.dd");
		SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
		params.put("today", simpleDateFormat.format(today));
		params.put("current", simpleDateFormat1.format(today));
		
		List<HashMap> listTs = DocExcute.process("TS");
		List<HashMap> listVue = DocExcute.process("VUE");
		
		if (listVue != null && listVue.size() > 0) {
			dataMap.put("listTs", listTs);
		}
		
		if (listVue != null && listVue.size() > 0) {
			for (HashMap map : listVue) {
				if (map.get("kind").equals("VUE")) {
					List list = new ArrayList<>();
					list.add(map);
					dataMap.put("listVue", list);	
				} else if (map.get("kind").equals("POP")) {
					List list = new ArrayList<>();
					list.add(map);
					dataMap.put("listPop", list);
				}
				
			}
		}
		return dataMap;
	}
	
	public HashMap makeLangFile(HashMap params) throws Exception {
		
		HashMap dataMap = new HashMap(params);
		
		String lang_kind = StringUtils.defaultString((String) params.get("lang_kind"), "dev");
		LangExcute.process(lang_kind);
		
		return dataMap;
	}
	
	public HashMap readLang(HashMap params) throws Exception {
		
		HashMap dataMap = new HashMap();
		
		List<HashMap> listMap = LangExcute.readLang();
		dataMap.put("listMap", listMap);
		
		return dataMap;
	}
	
	public HashMap chgLangId(HashMap params) throws Exception {
		HashMap dataMap = new HashMap();
		
		List<HashMap> listMap = ChgLangId.process();
		dataMap.put("listMap", listMap);
		
		return dataMap;
	}
	
	public HashMap translation(HashMap params) throws Exception {
		
		HashMap dataMap = new HashMap();
		List<HashMap> listMap = ChgLangId.process();
		dataMap.put("listMap", listMap);
		return dataMap;
	}
	
}