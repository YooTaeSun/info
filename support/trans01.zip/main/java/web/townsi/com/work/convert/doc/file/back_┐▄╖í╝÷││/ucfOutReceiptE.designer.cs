namespace Lime.PA
{
    partial class ucfOutReceiptE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            try
            {
                System.Windows.Forms.Application.RemoveMessageFilter(this);
            }
            catch
            {
            }

            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Lime.Framework.DOPatientInfo doPatientInfo1 = new Lime.Framework.DOPatientInfo();
            Lime.PA.clsPatientRemark clsPatientRemark1 = new Lime.PA.clsPatientRemark();
            Lime.Framework.DOPatientInfo doPatientInfo2 = new Lime.Framework.DOPatientInfo();
            Lime.PA.clsPatientRemark clsPatientRemark2 = new Lime.PA.clsPatientRemark();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance23 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance24 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance25 = new Infragistics.Win.Appearance();
            Lime.PA.clsOutReceiptBreakDown clsOutReceiptBreakDown1 = new Lime.PA.clsOutReceiptBreakDown();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucfOutReceiptE));
            Lime.PA.clsOutRegistrationInfo clsOutRegistrationInfo1 = new Lime.PA.clsOutRegistrationInfo();
            Lime.PA.clsOutBillBreakdown clsOutBillBreakdown1 = new Lime.PA.clsOutBillBreakdown();
            Lime.PA.clsOutBillTemp clsOutBillTemp1 = new Lime.PA.clsOutBillTemp();
            Lime.PA.clsTraiLimitInfo clsTraiLimitInfo1 = new Lime.PA.clsTraiLimitInfo();
            Lime.PA.clsOutReceiptBreakDown clsOutReceiptBreakDown2 = new Lime.PA.clsOutReceiptBreakDown();
            Lime.PA.clsCardCashPermitInfo clsCardCashPermitInfo1 = new Lime.PA.clsCardCashPermitInfo();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance26 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance27 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance28 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance29 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance30 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab1 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            this.ultraTabPageControl1 = new Infragistics.Win.UltraWinTabControl.UltraTabPageControl();
            this.ucOutRecWatingList1 = new Lime.PA.ucOutRecWatingList();
            this.LxTitleLabel1 = new Lime.Framework.Controls.LxTitleLabel();
            this.chkFrvsRvst = new Lime.Framework.Controls.LxCheckBox();
            this.btnButtonList = new Lime.Framework.Controls.LxButtonList();
            this.lxPanel1 = new Lime.Framework.Controls.LxPanel();
            this.lxTitlePanel1 = new Lime.Framework.Controls.LxTitlePanel();
            this.ucOrderHisV1 = new Lime.PA.ucOrderHisV();
            this.lxPanel4 = new Lime.Framework.Controls.LxPanel();
            this.ucOremInf2 = new Lime.PA.ucOremInf();
            this.ucOremInf1 = new Lime.PA.ucOremInf();
            this.ucSameDayRegList1 = new Lime.PA.ucSameDayRegList();
            this.lxPanel2 = new Lime.Framework.Controls.LxPanel();
            this.btnNeedRereciept = new Lime.Framework.Controls.LxButton();
            this.btnNotCard = new Lime.Framework.Controls.LxButton();
            this.btnNonPermit = new Lime.Framework.Controls.LxButton();
            this.btnSearchMefeUnpr = new Lime.Framework.Controls.LxButton();
            this.ucOutReceiptBD1 = new Lime.PA.ucOutReceiptBD();
            this.ucOrecRegInf11 = new Lime.PA.ucOrecRegInf1();
            this.lxPanel3 = new Lime.Framework.Controls.LxPanel();
            this.lxPanel5 = new Lime.Framework.Controls.LxPanel();
            this.lxPanel8 = new Lime.Framework.Controls.LxPanel();
            this.ucOlocInf1 = new Lime.PA.ucOlocInf();
            this.lxPanel7 = new Lime.Framework.Controls.LxPanel();
            this.ucOappInf1 = new Lime.PA.ucOappInf();
            this.ucSpecialInf1 = new Lime.PA.ucSpecialInf();
            this.lxPanel6 = new Lime.Framework.Controls.LxPanel();
            this.ucOdisInf1 = new Lime.PA.ucOdisInf();
            this.ucObillInf11 = new Lime.PA.ucObillInf1();
            this.cboPermitCheckYn = new Lime.Framework.Controls.LxCheckBox();
            this.chkDisplayAmt = new Lime.Framework.Controls.LxCheckBox();
            this.lxPanel9 = new Lime.Framework.Controls.LxPanel();
            this.dteMdcrDd = new Lime.Framework.Controls.LxDateTimeEditor();
            this.chkForWhitePrint = new Lime.Framework.Controls.LxCheckBox();
            this.chkForPharmacy = new Lime.Framework.Controls.LxCheckBox();
            this.chkForPatient = new Lime.Framework.Controls.LxCheckBox();
            this.chkIlnsCd = new Lime.Framework.Controls.LxCheckBox();
            this.pnlWating = new Lime.Framework.Controls.LxPanel();
            this.tabWating = new Lime.Framework.Controls.LxTabControl();
            this.ultraTabSharedControlsPage1 = new Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage();
            this.chkAutoEmr = new Lime.Framework.Controls.LxCheckBox();
            this.btnPrintPrescription = new Lime.Framework.Controls.LxButton();
            ((System.ComponentModel.ISupportInitialize)(this.pnlTop)).BeginInit();
            this.pnlTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).BeginInit();
            this.pnlBase.SuspendLayout();
            this.ultraTabPageControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ucOutRecWatingList1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFrvsRvst)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnButtonList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel1)).BeginInit();
            this.lxPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitlePanel1)).BeginInit();
            this.lxTitlePanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ucOrderHisV1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel4)).BeginInit();
            this.lxPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ucSameDayRegList1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel2)).BeginInit();
            this.lxPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnNeedRereciept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNotCard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNonPermit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSearchMefeUnpr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ucOrecRegInf11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel3)).BeginInit();
            this.lxPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel5)).BeginInit();
            this.lxPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel8)).BeginInit();
            this.lxPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel7)).BeginInit();
            this.lxPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel6)).BeginInit();
            this.lxPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ucObillInf11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboPermitCheckYn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkDisplayAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel9)).BeginInit();
            this.lxPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dteMdcrDd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkForWhitePrint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkForPharmacy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkForPatient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkIlnsCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlWating)).BeginInit();
            this.pnlWating.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabWating)).BeginInit();
            this.tabWating.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkAutoEmr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnPrintPrescription)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTop
            // 
            this.pnlTop.Controls.Add(this.chkAutoEmr);
            this.pnlTop.Controls.Add(this.chkIlnsCd);
            this.pnlTop.Controls.Add(this.chkForPatient);
            this.pnlTop.Controls.Add(this.chkForPharmacy);
            this.pnlTop.Controls.Add(this.chkForWhitePrint);
            this.pnlTop.Controls.Add(this.lxPanel9);
            this.pnlTop.Controls.Add(this.chkDisplayAmt);
            this.pnlTop.Controls.Add(this.cboPermitCheckYn);
            this.pnlTop.Controls.Add(this.btnButtonList);
            this.pnlTop.Controls.Add(this.chkFrvsRvst);
            this.pnlTop.Size = new System.Drawing.Size(1920, 38);
            // 
            // pnlBase
            // 
            this.pnlBase.Controls.Add(this.lxPanel2);
            this.pnlBase.Controls.Add(this.lxPanel3);
            this.pnlBase.Controls.Add(this.lxPanel1);
            this.pnlBase.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlBase.Location = new System.Drawing.Point(28, 38);
            this.pnlBase.Size = new System.Drawing.Size(1892, 848);
            // 
            // ultraTabPageControl1
            // 
            this.ultraTabPageControl1.Controls.Add(this.ucOutRecWatingList1);
            this.ultraTabPageControl1.Location = new System.Drawing.Point(29, 1);
            this.ultraTabPageControl1.Name = "ultraTabPageControl1";
            this.ultraTabPageControl1.Size = new System.Drawing.Size(0, 846);
            // 
            // ucOutRecWatingList1
            // 
            this.ucOutRecWatingList1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.ucOutRecWatingList1.Caption = "ucOutRecWatingList1";
            this.ucOutRecWatingList1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucOutRecWatingList1.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.ucOutRecWatingList1.Icon = null;
            this.ucOutRecWatingList1.Location = new System.Drawing.Point(0, 0);
            this.ucOutRecWatingList1.Name = "ucOutRecWatingList1";
            this.ucOutRecWatingList1.Size = new System.Drawing.Size(0, 846);
            this.ucOutRecWatingList1.TabIndex = 0;
            this.ucOutRecWatingList1.WatingType = "F";
            // 
            // LxTitleLabel1
            // 
            appearance7.BackColor = System.Drawing.Color.Transparent;
            appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance7.FontData.Name = "맑은 고딕";
            appearance7.FontData.SizeInPoints = 9F;
            appearance7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance7.TextHAlignAsString = "Right";
            appearance7.TextVAlignAsString = "Middle";
            this.LxTitleLabel1.Appearance = appearance7;
            this.LxTitleLabel1.Location = new System.Drawing.Point(12, 8);
            this.LxTitleLabel1.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel1.Name = "LxTitleLabel1";
            this.LxTitleLabel1.Size = new System.Drawing.Size(41, 17);
            this.LxTitleLabel1.TabIndex = 10;
            this.LxTitleLabel1.Text = "일자";
            this.LxTitleLabel1.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel1.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // chkFrvsRvst
            // 
            appearance10.BackColor = System.Drawing.Color.Transparent;
            appearance10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.chkFrvsRvst.Appearance = appearance10;
            this.chkFrvsRvst.BackColor = System.Drawing.Color.Transparent;
            this.chkFrvsRvst.BackColorInternal = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.chkFrvsRvst.Location = new System.Drawing.Point(227, 10);
            this.chkFrvsRvst.Name = "chkFrvsRvst";
            this.chkFrvsRvst.Size = new System.Drawing.Size(118, 16);
            this.chkFrvsRvst.TabIndex = 13;
            this.chkFrvsRvst.Text = "초진재진변경";
            this.chkFrvsRvst.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.chkFrvsRvst.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.chkFrvsRvst.Visible = false;
            // 
            // btnButtonList
            // 
            this.btnButtonList.BackColor = System.Drawing.Color.White;
            this.btnButtonList.ButtonItems.AddRange(new Lime.Framework.Controls.ButtonItem[] {
            new Lime.Framework.Controls.ButtonItem(Lime.Framework.Controls.ButtonType.Clear, "초기화(F5)", "Clear", System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50))))), System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), true),
            new Lime.Framework.Controls.ButtonItem(Lime.Framework.Controls.ButtonType.Close, "닫 기", "Close", System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(85)))), ((int)(((byte)(100))))), System.Drawing.Color.White, true)});
            this.btnButtonList.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnButtonList.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.btnButtonList.Location = new System.Drawing.Point(1758, 5);
            this.btnButtonList.Name = "btnButtonList";
            this.btnButtonList.Size = new System.Drawing.Size(157, 28);
            this.btnButtonList.TabIndex = 14;
            // 
            // lxPanel1
            // 
            this.lxPanel1.BackColor = System.Drawing.Color.White;
            this.lxPanel1.Controls.Add(this.lxTitlePanel1);
            this.lxPanel1.Controls.Add(this.lxPanel4);
            this.lxPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.lxPanel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxPanel1.Location = new System.Drawing.Point(0, 0);
            this.lxPanel1.Name = "lxPanel1";
            this.lxPanel1.Size = new System.Drawing.Size(511, 848);
            this.lxPanel1.TabIndex = 22;
            // 
            // lxTitlePanel1
            // 
            this.lxTitlePanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.lxTitlePanel1.BottomBarVisible = false;
            this.lxTitlePanel1.BottomText = "";
            this.lxTitlePanel1.Controls.Add(this.ucOrderHisV1);
            this.lxTitlePanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lxTitlePanel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxTitlePanel1.Location = new System.Drawing.Point(0, 400);
            this.lxTitlePanel1.Name = "lxTitlePanel1";
            this.lxTitlePanel1.Padding = new System.Windows.Forms.Padding(3);
            this.lxTitlePanel1.Size = new System.Drawing.Size(511, 448);
            this.lxTitlePanel1.TabIndex = 23;
            this.lxTitlePanel1.TitleText = "처방 이력";
            // 
            // ucOrderHisV1
            // 
            this.ucOrderHisV1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.ucOrderHisV1.Caption = "ucOrderHisV1";
            this.ucOrderHisV1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucOrderHisV1.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.ucOrderHisV1.Icon = null;
            this.ucOrderHisV1.Location = new System.Drawing.Point(3, 35);
            this.ucOrderHisV1.Name = "ucOrderHisV1";
            this.ucOrderHisV1.Size = new System.Drawing.Size(505, 410);
            this.ucOrderHisV1.TabIndex = 2;
            // 
            // lxPanel4
            // 
            this.lxPanel4.BackColor = System.Drawing.Color.White;
            this.lxPanel4.Controls.Add(this.ucOremInf2);
            this.lxPanel4.Controls.Add(this.ucOremInf1);
            this.lxPanel4.Controls.Add(this.ucSameDayRegList1);
            this.lxPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.lxPanel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxPanel4.Location = new System.Drawing.Point(0, 0);
            this.lxPanel4.Name = "lxPanel4";
            this.lxPanel4.Size = new System.Drawing.Size(511, 400);
            this.lxPanel4.TabIndex = 21;
            // 
            // ucOremInf2
            // 
            this.ucOremInf2.BackColor = System.Drawing.Color.White;
            this.ucOremInf2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucOremInf2.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.ucOremInf2.Location = new System.Drawing.Point(263, 157);
            this.ucOremInf2.Name = "ucOremInf2";
            this.ucOremInf2.PatientInfo = doPatientInfo1;
            clsPatientRemark1.DEL_YN = "";
            clsPatientRemark1.OTPT_ADMS_DVCD = "";
            clsPatientRemark1.PCLR_MATR_SQNO = 0;
            clsPatientRemark1.PID = "";
            clsPatientRemark1.PT_CMHS_NO = 0;
            clsPatientRemark1.PT_PCLR_MATR = "";
            clsPatientRemark1.PTAF_MDCR_DVCD = "";
            clsPatientRemark1.RGST_DT = "";
            clsPatientRemark1.RGSTR_ID = "";
            clsPatientRemark1.UPDT_DT = "";
            clsPatientRemark1.UPDTR_ID = "";
            clsPatientRemark1.WRTN_DD = "";
            this.ucOremInf2.Remark = clsPatientRemark1;
            this.ucOremInf2.RemarkDvcd = "R";
            this.ucOremInf2.Size = new System.Drawing.Size(248, 243);
            this.ucOremInf2.TabIndex = 6;
            // 
            // ucOremInf1
            // 
            this.ucOremInf1.BackColor = System.Drawing.Color.White;
            this.ucOremInf1.Dock = System.Windows.Forms.DockStyle.Left;
            this.ucOremInf1.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.ucOremInf1.Location = new System.Drawing.Point(0, 157);
            this.ucOremInf1.Name = "ucOremInf1";
            this.ucOremInf1.PatientInfo = doPatientInfo2;
            clsPatientRemark2.DEL_YN = "";
            clsPatientRemark2.OTPT_ADMS_DVCD = "";
            clsPatientRemark2.PCLR_MATR_SQNO = 0;
            clsPatientRemark2.PID = "";
            clsPatientRemark2.PT_CMHS_NO = 0;
            clsPatientRemark2.PT_PCLR_MATR = "";
            clsPatientRemark2.PTAF_MDCR_DVCD = "";
            clsPatientRemark2.RGST_DT = "";
            clsPatientRemark2.RGSTR_ID = "";
            clsPatientRemark2.UPDT_DT = "";
            clsPatientRemark2.UPDTR_ID = "";
            clsPatientRemark2.WRTN_DD = "";
            this.ucOremInf1.Remark = clsPatientRemark2;
            this.ucOremInf1.RemarkDvcd = "P";
            this.ucOremInf1.Size = new System.Drawing.Size(263, 243);
            this.ucOremInf1.TabIndex = 5;
            // 
            // ucSameDayRegList1
            // 
            this.ucSameDayRegList1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.ucSameDayRegList1.Caption = "";
            this.ucSameDayRegList1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucSameDayRegList1.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.ucSameDayRegList1.Icon = null;
            this.ucSameDayRegList1.Location = new System.Drawing.Point(0, 0);
            this.ucSameDayRegList1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.ucSameDayRegList1.Name = "ucSameDayRegList1";
            this.ucSameDayRegList1.Size = new System.Drawing.Size(511, 157);
            this.ucSameDayRegList1.TabIndex = 20;
            // 
            // lxPanel2
            // 
            this.lxPanel2.BackColor = System.Drawing.Color.White;
            this.lxPanel2.Controls.Add(this.btnPrintPrescription);
            this.lxPanel2.Controls.Add(this.btnNeedRereciept);
            this.lxPanel2.Controls.Add(this.btnNotCard);
            this.lxPanel2.Controls.Add(this.btnNonPermit);
            this.lxPanel2.Controls.Add(this.btnSearchMefeUnpr);
            this.lxPanel2.Controls.Add(this.ucOutReceiptBD1);
            this.lxPanel2.Controls.Add(this.ucOrecRegInf11);
            this.lxPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lxPanel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxPanel2.Location = new System.Drawing.Point(511, 0);
            this.lxPanel2.Name = "lxPanel2";
            this.lxPanel2.Size = new System.Drawing.Size(869, 848);
            this.lxPanel2.TabIndex = 21;
            // 
            // btnNeedRereciept
            // 
            appearance14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance14.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance14.FontData.BoldAsString = "False";
            appearance14.FontData.Name = "맑은 고딕";
            appearance14.FontData.SizeInPoints = 9F;
            appearance14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(90)))), ((int)(((byte)(20)))));
            appearance14.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance14.TextHAlignAsString = "Center";
            appearance14.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance14.TextVAlignAsString = "Middle";
            this.btnNeedRereciept.Appearance = appearance14;
            this.btnNeedRereciept.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat;
            appearance15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance15.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance15.FontData.BoldAsString = "True";
            appearance15.FontData.Name = "맑은 고딕";
            appearance15.FontData.SizeInPoints = 9F;
            appearance15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance15.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance15.TextHAlignAsString = "Center";
            appearance15.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance15.TextVAlignAsString = "Middle";
            this.btnNeedRereciept.HotTrackAppearance = appearance15;
            this.btnNeedRereciept.Location = new System.Drawing.Point(436, 212);
            this.btnNeedRereciept.Name = "btnNeedRereciept";
            appearance16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance16.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance16.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance16.FontData.BoldAsString = "True";
            appearance16.FontData.Name = "맑은 고딕";
            appearance16.FontData.SizeInPoints = 8F;
            appearance16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance16.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance16.TextHAlignAsString = "Center";
            appearance16.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance16.TextVAlignAsString = "Middle";
            this.btnNeedRereciept.PressedAppearance = appearance16;
            this.btnNeedRereciept.Size = new System.Drawing.Size(106, 27);
            this.btnNeedRereciept.TabIndex = 22;
            this.btnNeedRereciept.Text = "재수납 대상";
            this.btnNeedRereciept.UseFlatMode = Infragistics.Win.DefaultableBoolean.False;
            this.btnNeedRereciept.UseHotTracking = Infragistics.Win.DefaultableBoolean.True;
            this.btnNeedRereciept.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.btnNeedRereciept.WrapText = false;
            // 
            // btnNotCard
            // 
            appearance17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance17.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance17.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance17.FontData.BoldAsString = "False";
            appearance17.FontData.Name = "맑은 고딕";
            appearance17.FontData.SizeInPoints = 9F;
            appearance17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(90)))), ((int)(((byte)(20)))));
            appearance17.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance17.TextHAlignAsString = "Center";
            appearance17.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance17.TextVAlignAsString = "Middle";
            this.btnNotCard.Appearance = appearance17;
            this.btnNotCard.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat;
            appearance18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance18.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance18.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance18.FontData.BoldAsString = "True";
            appearance18.FontData.Name = "맑은 고딕";
            appearance18.FontData.SizeInPoints = 9F;
            appearance18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance18.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance18.TextHAlignAsString = "Center";
            appearance18.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance18.TextVAlignAsString = "Middle";
            this.btnNotCard.HotTrackAppearance = appearance18;
            this.btnNotCard.Location = new System.Drawing.Point(544, 212);
            this.btnNotCard.Name = "btnNotCard";
            appearance19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance19.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance19.FontData.BoldAsString = "True";
            appearance19.FontData.Name = "맑은 고딕";
            appearance19.FontData.SizeInPoints = 8F;
            appearance19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance19.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance19.TextHAlignAsString = "Center";
            appearance19.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance19.TextVAlignAsString = "Middle";
            this.btnNotCard.PressedAppearance = appearance19;
            this.btnNotCard.Size = new System.Drawing.Size(106, 27);
            this.btnNotCard.TabIndex = 22;
            this.btnNotCard.Text = "미수납 카드건";
            this.btnNotCard.UseFlatMode = Infragistics.Win.DefaultableBoolean.False;
            this.btnNotCard.UseHotTracking = Infragistics.Win.DefaultableBoolean.True;
            this.btnNotCard.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.btnNotCard.WrapText = false;
            // 
            // btnNonPermit
            // 
            appearance20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance20.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance20.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance20.FontData.BoldAsString = "False";
            appearance20.FontData.Name = "맑은 고딕";
            appearance20.FontData.SizeInPoints = 9F;
            appearance20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(90)))), ((int)(((byte)(20)))));
            appearance20.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance20.TextHAlignAsString = "Center";
            appearance20.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance20.TextVAlignAsString = "Middle";
            this.btnNonPermit.Appearance = appearance20;
            this.btnNonPermit.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat;
            appearance21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance21.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance21.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance21.FontData.BoldAsString = "True";
            appearance21.FontData.Name = "맑은 고딕";
            appearance21.FontData.SizeInPoints = 9F;
            appearance21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance21.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance21.TextHAlignAsString = "Center";
            appearance21.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance21.TextVAlignAsString = "Middle";
            this.btnNonPermit.HotTrackAppearance = appearance21;
            this.btnNonPermit.Location = new System.Drawing.Point(651, 212);
            this.btnNonPermit.Name = "btnNonPermit";
            appearance22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance22.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance22.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance22.FontData.BoldAsString = "True";
            appearance22.FontData.Name = "맑은 고딕";
            appearance22.FontData.SizeInPoints = 8F;
            appearance22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance22.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance22.TextHAlignAsString = "Center";
            appearance22.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance22.TextVAlignAsString = "Middle";
            this.btnNonPermit.PressedAppearance = appearance22;
            this.btnNonPermit.Size = new System.Drawing.Size(106, 27);
            this.btnNonPermit.TabIndex = 20;
            this.btnNonPermit.Text = "의료급여미승인";
            this.btnNonPermit.UseFlatMode = Infragistics.Win.DefaultableBoolean.False;
            this.btnNonPermit.UseHotTracking = Infragistics.Win.DefaultableBoolean.True;
            this.btnNonPermit.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.btnNonPermit.WrapText = false;
            // 
            // btnSearchMefeUnpr
            // 
            appearance23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance23.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance23.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance23.FontData.BoldAsString = "False";
            appearance23.FontData.Name = "맑은 고딕";
            appearance23.FontData.SizeInPoints = 9F;
            appearance23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(90)))), ((int)(((byte)(20)))));
            appearance23.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance23.TextHAlignAsString = "Center";
            appearance23.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance23.TextVAlignAsString = "Middle";
            this.btnSearchMefeUnpr.Appearance = appearance23;
            this.btnSearchMefeUnpr.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat;
            appearance24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance24.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance24.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance24.FontData.BoldAsString = "True";
            appearance24.FontData.Name = "맑은 고딕";
            appearance24.FontData.SizeInPoints = 9F;
            appearance24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance24.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance24.TextHAlignAsString = "Center";
            appearance24.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance24.TextVAlignAsString = "Middle";
            this.btnSearchMefeUnpr.HotTrackAppearance = appearance24;
            this.btnSearchMefeUnpr.Location = new System.Drawing.Point(758, 212);
            this.btnSearchMefeUnpr.Name = "btnSearchMefeUnpr";
            appearance25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance25.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance25.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance25.FontData.BoldAsString = "True";
            appearance25.FontData.Name = "맑은 고딕";
            appearance25.FontData.SizeInPoints = 8F;
            appearance25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance25.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance25.TextHAlignAsString = "Center";
            appearance25.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance25.TextVAlignAsString = "Middle";
            this.btnSearchMefeUnpr.PressedAppearance = appearance25;
            this.btnSearchMefeUnpr.Size = new System.Drawing.Size(106, 27);
            this.btnSearchMefeUnpr.TabIndex = 20;
            this.btnSearchMefeUnpr.Text = "수가 단가 조회";
            this.btnSearchMefeUnpr.UseFlatMode = Infragistics.Win.DefaultableBoolean.False;
            this.btnSearchMefeUnpr.UseHotTracking = Infragistics.Win.DefaultableBoolean.True;
            this.btnSearchMefeUnpr.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.btnSearchMefeUnpr.WrapText = false;
            // 
            // ucOutReceiptBD1
            // 
            this.ucOutReceiptBD1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucOutReceiptBD1.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.ucOutReceiptBD1.Location = new System.Drawing.Point(0, 207);
            this.ucOutReceiptBD1.Margin = new System.Windows.Forms.Padding(3, 148, 3, 148);
            this.ucOutReceiptBD1.Name = "ucOutReceiptBD1";
            clsOutReceiptBreakDown1.ACTG_DD = "";
            clsOutReceiptBreakDown1.ACTG_DEPT_CD = "";
            clsOutReceiptBreakDown1.ACTN_MATL_DVCD = "";
            clsOutReceiptBreakDown1.ADED_VALU_TAX_AMT = 0;
            clsOutReceiptBreakDown1.ADTN_APLY_TIME = "";
            clsOutReceiptBreakDown1.ADTN_CMPT_AMT = 0;
            clsOutReceiptBreakDown1.AFRS_STAT_DVCD = "";
            clsOutReceiptBreakDown1.AOMD_MTHD_CD = "";
            clsOutReceiptBreakDown1.APLY_SQNO = 0;
            clsOutReceiptBreakDown1.BNDL_MEFE_CD = "";
            clsOutReceiptBreakDown1.BNDL_PRSC_SQNO = 0;
            clsOutReceiptBreakDown1.BYKN_ADTN_AMT = 0;
            clsOutReceiptBreakDown1.CLAM_CRTN_YN = "";
            clsOutReceiptBreakDown1.CLCL_AMT = 0;
            clsOutReceiptBreakDown1.CLCL_DVCD = "";
            clsOutReceiptBreakDown1.CLUR_DSBL_DVCD = "";
            clsOutReceiptBreakDown1.CLUS_DVCD = "";
            clsOutReceiptBreakDown1.CMPT_CD = "";
            clsOutReceiptBreakDown1.CMPT_DLWT_DVCD_1 = "";
            clsOutReceiptBreakDown1.CMPT_DLWT_DVCD_2 = "";
            clsOutReceiptBreakDown1.CMPT_DLWT_DVCD_3 = "";
            clsOutReceiptBreakDown1.CMPT_DLWT_DVCD_4 = "";
            clsOutReceiptBreakDown1.CNFR_CD = "";
            clsOutReceiptBreakDown1.CNFR_DVCD = "";
            clsOutReceiptBreakDown1.CNVR_PNT = 0D;
            clsOutReceiptBreakDown1.DCNT_AMT = 0;
            clsOutReceiptBreakDown1.DLVR_DEPT_CD = "";
            clsOutReceiptBreakDown1.DNFR_LEFT_LOW_CNTS = "";
            clsOutReceiptBreakDown1.DNFR_LFUP_CNTS = "";
            clsOutReceiptBreakDown1.DNFR_RGHT_LOW_CNTS = "";
            clsOutReceiptBreakDown1.DNFR_RGUP_CNTS = "";
            clsOutReceiptBreakDown1.EDI_CD = "";
            clsOutReceiptBreakDown1.ENTS_ENTD_DVCD = "";
            clsOutReceiptBreakDown1.ENTS_ENTD_INSTNO = "";
            clsOutReceiptBreakDown1.EXCP_RESN_CD = "";
            clsOutReceiptBreakDown1.FXAM_INCL_YN = "";
            clsOutReceiptBreakDown1.GRP_UNPR_APLY_YN = "";
            clsOutReceiptBreakDown1.HPMD_CLCL_DVCD = "";
            clsOutReceiptBreakDown1.HPMD_CLCL_QTY = 0D;
            clsOutReceiptBreakDown1.MDCN_UPLM_AMT = 0;
            clsOutReceiptBreakDown1.MDCN_UPLM_DIAM = 0;
            clsOutReceiptBreakDown1.MDCR_DD = "";
            clsOutReceiptBreakDown1.MEFE_CD = "";
            clsOutReceiptBreakDown1.MEFE_DVCD = "";
            clsOutReceiptBreakDown1.MEFE_NM = "";
            clsOutReceiptBreakDown1.NEW_RCPT_RQNO = 49;
            clsOutReceiptBreakDown1.NEW_ROW_STAT_DVCD = "";
            clsOutReceiptBreakDown1.NODY = 0;
            clsOutReceiptBreakDown1.NOTM = 0;
            clsOutReceiptBreakDown1.ONTM_QTY = 0D;
            clsOutReceiptBreakDown1.ORIG_CLCL_AMT = 0;
            clsOutReceiptBreakDown1.ORIG_PRSC_SQNO = 0;
            clsOutReceiptBreakDown1.ORIG_SQNO = 0;
            clsOutReceiptBreakDown1.ORMD_ANS_DVCD = "";
            clsOutReceiptBreakDown1.ORMD_ANS_ORIG_CD = "";
            clsOutReceiptBreakDown1.ORMD_ANS_ORIG_DVCD = "";
            clsOutReceiptBreakDown1.ORMD_SITE_CD = "";
            clsOutReceiptBreakDown1.ORMD_SITE_DVCD = "";
            clsOutReceiptBreakDown1.OUPR_GRNT_NO = "";
            clsOutReceiptBreakDown1.PAY_CLAM_AMT = 0D;
            clsOutReceiptBreakDown1.PAY_NOPY_DVCD = "";
            clsOutReceiptBreakDown1.PAY_USCH_AMT = 0D;
            clsOutReceiptBreakDown1.PCLR_MATR = "";
            clsOutReceiptBreakDown1.PID = "";
            clsOutReceiptBreakDown1.PRFT_CD = "";
            clsOutReceiptBreakDown1.PRSC_DVCD = "";
            clsOutReceiptBreakDown1.PRSC_SQNO = 0;
            clsOutReceiptBreakDown1.PT_CMHS_NO = 0;
            clsOutReceiptBreakDown1.RCPT_SQNO = 0;
            clsOutReceiptBreakDown1.REAL_PRDC_CD = "";
            clsOutReceiptBreakDown1.RGST_DT = "";
            clsOutReceiptBreakDown1.RGSTR_ID = "";
            clsOutReceiptBreakDown1.ROW_STAT_DVCD = "";
            clsOutReceiptBreakDown1.SBIT_DVCD = "";
            clsOutReceiptBreakDown1.SCNG_PAY_CD = "";
            clsOutReceiptBreakDown1.SCNG_PAY_CLAM_AMT = 0D;
            clsOutReceiptBreakDown1.SCNG_PAY_USCH_AMT = 0D;
            clsOutReceiptBreakDown1.SLCT_MCFE = 0;
            clsOutReceiptBreakDown1.SMCR_AMT = 0;
            clsOutReceiptBreakDown1.SMCR_RATE = 0D;
            clsOutReceiptBreakDown1.STATVAL1 = 1;
            clsOutReceiptBreakDown1.STATVAL2 = 1;
            clsOutReceiptBreakDown1.TIME_ADTN_DVCD = "";
            clsOutReceiptBreakDown1.TOTL_AOMD_QTY = 0D;
            clsOutReceiptBreakDown1.UNPR = 0;
            clsOutReceiptBreakDown1.VTRN_PT_YN = "";
            clsOutReceiptBreakDown1.VTRN_TAMT = 0;
            this.ucOutReceiptBD1.OutRecBD = clsOutReceiptBreakDown1;
            this.ucOutReceiptBD1.Size = new System.Drawing.Size(869, 641);
            this.ucOutReceiptBD1.TabIndex = 21;
            // 
            // ucOrecRegInf11
            // 
            this.ucOrecRegInf11.BackColor = System.Drawing.Color.White;
            this.ucOrecRegInf11.Caption = "";
            this.ucOrecRegInf11.Compare_ASST_TYCD = "";
            this.ucOrecRegInf11.Compare_CFSC_RGNO_CD = "";
            this.ucOrecRegInf11.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucOrecRegInf11.EMRM_MMCD_CD_bk = "";
            this.ucOrecRegInf11.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.ucOrecRegInf11.Icon = null;
            this.ucOrecRegInf11.Location = new System.Drawing.Point(0, 0);
            this.ucOrecRegInf11.Name = "ucOrecRegInf11";
            clsOutRegistrationInfo1.AFRS_STAT_DVCD = "";
            clsOutRegistrationInfo1.AGE = 0;
            clsOutRegistrationInfo1.APNT_PATH_DVCD = "";
            clsOutRegistrationInfo1.APNT_TIME = "";
            clsOutRegistrationInfo1.APNT_YN = "";
            clsOutRegistrationInfo1.ASCT_RGNO_CD = "";
            clsOutRegistrationInfo1.ASST_TYCD = "";
            clsOutRegistrationInfo1.BILL_COUNT = 0;
            clsOutRegistrationInfo1.CFSC_RGNO_CD = "";
            clsOutRegistrationInfo1.CHRN_DSSE_DVCD = "";
            clsOutRegistrationInfo1.CLAM_CRTN_DEL_RESN = "";
            clsOutRegistrationInfo1.CLAM_CRTN_YN = "";
            clsOutRegistrationInfo1.CLAM_REVW_YN = "";
            clsOutRegistrationInfo1.CLPH_TEL = "";
            clsOutRegistrationInfo1.CLUR_DSBL_DVCD = "";
            clsOutRegistrationInfo1.CMHS_DVCD = "";
            clsOutRegistrationInfo1.CMHS_MOTV_DVCD = "";
            clsOutRegistrationInfo1.CNST_REFR_YN = "";
            clsOutRegistrationInfo1.CNTT_PRSC_DVCD = "";
            clsOutRegistrationInfo1.DC_DD = "";
            clsOutRegistrationInfo1.DCNT_RDIA_CD = "";
            clsOutRegistrationInfo1.DCNT_RDIA_EMNO = "";
            clsOutRegistrationInfo1.DOBR = "";
            clsOutRegistrationInfo1.DRG_DVCD = "";
            clsOutRegistrationInfo1.DRG_NO = "";
            clsOutRegistrationInfo1.DY_WARD_YN = "";
            clsOutRegistrationInfo1.DYTM_CNTR_USE_YN = "";
            clsOutRegistrationInfo1.ECOI_CD = "";
            clsOutRegistrationInfo1.EMRM_MMCD_CD = "";
            clsOutRegistrationInfo1.EMRM_WTNG_YN = "";
            clsOutRegistrationInfo1.ENTS_ENTD_DVCD = "";
            clsOutRegistrationInfo1.ETC_USE_CNTS_1 = "";
            clsOutRegistrationInfo1.ETC_USE_CNTS_2 = "";
            clsOutRegistrationInfo1.ETC_USE_CNTS_3 = "";
            clsOutRegistrationInfo1.ETC_USE_CNTS_4 = "";
            clsOutRegistrationInfo1.ETC_USE_CNTS_5 = "";
            clsOutRegistrationInfo1.EXCP_RESN_CD = "";
            clsOutRegistrationInfo1.FCLT_APLY_CD = "";
            clsOutRegistrationInfo1.FCLT_APLY_YN = "";
            clsOutRegistrationInfo1.FRRN = "";
            clsOutRegistrationInfo1.FRVS_RVST_DVCD = "";
            clsOutRegistrationInfo1.FXAM_FXRT_DVCD = "";
            clsOutRegistrationInfo1.HIRA_REQ_NO = "";
            clsOutRegistrationInfo1.HIRA_SDBK_NO = "";
            clsOutRegistrationInfo1.HLLF_MNCS_BLCE = 0;
            clsOutRegistrationInfo1.HMCR_YN = "";
            clsOutRegistrationInfo1.INDP_MOMR_YN = "";
            clsOutRegistrationInfo1.INSN_CLAM_DEPT_CD = "";
            clsOutRegistrationInfo1.INSN_TYCD = "";
            clsOutRegistrationInfo1.ISCL_EMRM_MMCD_CD = "";
            clsOutRegistrationInfo1.MAIN_ILNS_CD = "";
            clsOutRegistrationInfo1.MCCH_CMPT_DVCD = "";
            clsOutRegistrationInfo1.MCSP_APNT_DVCD = "";
            clsOutRegistrationInfo1.MDCR_DD = "";
            clsOutRegistrationInfo1.MDCR_DEPT_CD = "";
            clsOutRegistrationInfo1.MDCR_DR_CD = "";
            clsOutRegistrationInfo1.MDCR_END_DT = "";
            clsOutRegistrationInfo1.MDCR_STRT_DT = "";
            clsOutRegistrationInfo1.MDCR_TIME = "";
            clsOutRegistrationInfo1.MOMR_AGE_DVCD = "";
            clsOutRegistrationInfo1.MTWM_BLCE = 0;
            clsOutRegistrationInfo1.MTWM_YN = "";
            clsOutRegistrationInfo1.NEW_PID_YN = "N";
            clsOutRegistrationInfo1.NRSN_CNFR_YN = "";
            clsOutRegistrationInfo1.OTHR_HSPT_HPTF_YN = "";
            clsOutRegistrationInfo1.OTPT_ADMS_DVCD = "";
            clsOutRegistrationInfo1.OTPT_DRG_YN = "";
            clsOutRegistrationInfo1.PAY_QLFC_DVCD = "";
            clsOutRegistrationInfo1.PID = "";
            clsOutRegistrationInfo1.PRSC_COUNT = 0;
            clsOutRegistrationInfo1.PRSC_NOTM = 0;
            clsOutRegistrationInfo1.PT_CMHS_NO = 0;
            clsOutRegistrationInfo1.PT_MDCR_STAT_DVCD = "";
            clsOutRegistrationInfo1.PT_NM = "";
            clsOutRegistrationInfo1.PT_PCLR_MATR = "";
            clsOutRegistrationInfo1.QLFC_RTRV_YN = "";
            clsOutRegistrationInfo1.RCPN_ADDR_CD = "";
            clsOutRegistrationInfo1.RCPN_AGE = 0;
            clsOutRegistrationInfo1.RCPN_SQNO = 0;
            clsOutRegistrationInfo1.RCPT_NOTM = 0;
            clsOutRegistrationInfo1.REAL_MDCR_DR_CD = "";
            clsOutRegistrationInfo1.REBURN = "";
            clsOutRegistrationInfo1.REFR_INSTNO = "";
            clsOutRegistrationInfo1.RGST_DT = "";
            clsOutRegistrationInfo1.RGSTR_ID = "";
            clsOutRegistrationInfo1.ROW_STAT_DVCD = "";
            clsOutRegistrationInfo1.RRNO = "";
            clsOutRegistrationInfo1.RRNS_FAFR_DVCD = "";
            clsOutRegistrationInfo1.SEX_DVCD = "";
            clsOutRegistrationInfo1.SMCR_YN = "";
            clsOutRegistrationInfo1.SNDT_TGPS_DVCD = "";
            clsOutRegistrationInfo1.SRRN = "";
            clsOutRegistrationInfo1.TAIC_PT_UNIQ_NO = "";
            clsOutRegistrationInfo1.TBRC_DVCD = "";
            clsOutRegistrationInfo1.TRAI_USPR_SHRT = 0;
            clsOutRegistrationInfo1.USCH_APLY_CD = "";
            clsOutRegistrationInfo1.VCNT_CLTP_YN = "";
            clsOutRegistrationInfo1.VCNT_PRTW_YN = "";
            clsOutRegistrationInfo1.VTRN_FALU_YN = "";
            clsOutRegistrationInfo1.VTRN_NON_QLFC_YN = "";
            clsOutRegistrationInfo1.VTRN_PT_YN = "";
            clsOutRegistrationInfo1.VTRN_USCH_DVCD = "";
            this.ucOrecRegInf11.OutRegInfo = clsOutRegistrationInfo1;
            this.ucOrecRegInf11.Size = new System.Drawing.Size(869, 207);
            this.ucOrecRegInf11.TabIndex = 13;
            // 
            // lxPanel3
            // 
            this.lxPanel3.BackColor = System.Drawing.Color.White;
            this.lxPanel3.Controls.Add(this.lxPanel5);
            this.lxPanel3.Controls.Add(this.ucObillInf11);
            this.lxPanel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.lxPanel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxPanel3.Location = new System.Drawing.Point(1380, 0);
            this.lxPanel3.Name = "lxPanel3";
            this.lxPanel3.Size = new System.Drawing.Size(512, 848);
            this.lxPanel3.TabIndex = 23;
            // 
            // lxPanel5
            // 
            this.lxPanel5.BackColor = System.Drawing.Color.White;
            this.lxPanel5.Controls.Add(this.lxPanel8);
            this.lxPanel5.Controls.Add(this.lxPanel7);
            this.lxPanel5.Controls.Add(this.lxPanel6);
            this.lxPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lxPanel5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxPanel5.Location = new System.Drawing.Point(0, 0);
            this.lxPanel5.Name = "lxPanel5";
            this.lxPanel5.Size = new System.Drawing.Size(512, 350);
            this.lxPanel5.TabIndex = 5;
            // 
            // lxPanel8
            // 
            this.lxPanel8.BackColor = System.Drawing.Color.White;
            this.lxPanel8.Controls.Add(this.ucOlocInf1);
            this.lxPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lxPanel8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxPanel8.Location = new System.Drawing.Point(279, 110);
            this.lxPanel8.Name = "lxPanel8";
            this.lxPanel8.Size = new System.Drawing.Size(233, 240);
            this.lxPanel8.TabIndex = 7;
            // 
            // ucOlocInf1
            // 
            this.ucOlocInf1.BackColor = System.Drawing.Color.White;
            this.ucOlocInf1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucOlocInf1.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.ucOlocInf1.Location = new System.Drawing.Point(0, 0);
            this.ucOlocInf1.Name = "ucOlocInf1";
            this.ucOlocInf1.Size = new System.Drawing.Size(233, 240);
            this.ucOlocInf1.TabIndex = 3;
            // 
            // lxPanel7
            // 
            this.lxPanel7.BackColor = System.Drawing.Color.White;
            this.lxPanel7.Controls.Add(this.ucOappInf1);
            this.lxPanel7.Controls.Add(this.ucSpecialInf1);
            this.lxPanel7.Dock = System.Windows.Forms.DockStyle.Left;
            this.lxPanel7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxPanel7.Location = new System.Drawing.Point(0, 110);
            this.lxPanel7.Name = "lxPanel7";
            this.lxPanel7.Size = new System.Drawing.Size(279, 240);
            this.lxPanel7.TabIndex = 6;
            // 
            // ucOappInf1
            // 
            this.ucOappInf1.BackColor = System.Drawing.Color.White;
            this.ucOappInf1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucOappInf1.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.ucOappInf1.IsDsch = false;
            this.ucOappInf1.Location = new System.Drawing.Point(0, 136);
            this.ucOappInf1.Name = "ucOappInf1";
            this.ucOappInf1.Size = new System.Drawing.Size(279, 104);
            this.ucOappInf1.TabIndex = 4;
            // 
            // ucSpecialInf1
            // 
            this.ucSpecialInf1.BackColor = System.Drawing.Color.White;
            this.ucSpecialInf1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucSpecialInf1.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.ucSpecialInf1.Location = new System.Drawing.Point(0, 0);
            this.ucSpecialInf1.Name = "ucSpecialInf1";
            this.ucSpecialInf1.Size = new System.Drawing.Size(279, 136);
            this.ucSpecialInf1.TabIndex = 1;
            // 
            // lxPanel6
            // 
            this.lxPanel6.BackColor = System.Drawing.Color.White;
            this.lxPanel6.Controls.Add(this.ucOdisInf1);
            this.lxPanel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.lxPanel6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxPanel6.Location = new System.Drawing.Point(0, 0);
            this.lxPanel6.Name = "lxPanel6";
            this.lxPanel6.Size = new System.Drawing.Size(512, 110);
            this.lxPanel6.TabIndex = 5;
            // 
            // ucOdisInf1
            // 
            this.ucOdisInf1.BackColor = System.Drawing.Color.White;
            this.ucOdisInf1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucOdisInf1.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.ucOdisInf1.Location = new System.Drawing.Point(0, 0);
            this.ucOdisInf1.Name = "ucOdisInf1";
            this.ucOdisInf1.Size = new System.Drawing.Size(512, 110);
            this.ucOdisInf1.TabIndex = 2;
            // 
            // ucObillInf11
            // 
            this.ucObillInf11.BackColor = System.Drawing.Color.White;
            clsOutBillBreakdown1.ADED_VALU_TAX_TAMT = 0;
            clsOutBillBreakdown1.AFRS_STAT_DVCD = "";
            clsOutBillBreakdown1.ASCT_RGNO_CD = "";
            clsOutBillBreakdown1.ASST_TYCD = "";
            clsOutBillBreakdown1.BANO = "";
            clsOutBillBreakdown1.BILL_NO = "";
            clsOutBillBreakdown1.BLDN_YN = "";
            clsOutBillBreakdown1.BLOD_RDIA_AMT = 0;
            clsOutBillBreakdown1.BNAC_DPPR_NM = "";
            clsOutBillBreakdown1.BNAC_DPST_DD = "";
            clsOutBillBreakdown1.BNAC_RCPT_AMT = 0;
            clsOutBillBreakdown1.BYKN_ADTN_AMT = 0;
            clsOutBillBreakdown1.CARD_RCPT_AMT = 0;
            clsOutBillBreakdown1.CASH_PRMT_YN = "";
            clsOutBillBreakdown1.CASH_RCPT_AMT = 0;
            clsOutBillBreakdown1.CLAM_AMT = 0;
            clsOutBillBreakdown1.CLAM_NOPY_TAMT = 0;
            clsOutBillBreakdown1.CLNC_UNCL_APLY_AMT = 0;
            clsOutBillBreakdown1.CT_USCH_AMT = 0;
            clsOutBillBreakdown1.CTTR_NO_CD = "";
            clsOutBillBreakdown1.CTTR_UNCL_APLY_AMT = 0;
            clsOutBillBreakdown1.DCNT_RDIA_AMT = 0;
            clsOutBillBreakdown1.DCNT_RDIA_CD = "";
            clsOutBillBreakdown1.DCNT_RDIA_EMNO = "";
            clsOutBillBreakdown1.DCNT_RESN = "";
            clsOutBillBreakdown1.DLWT_IP_ADDR = "";
            clsOutBillBreakdown1.DSBL_FUND_AMT = 0;
            clsOutBillBreakdown1.EMRG_SUPT_AMT = 0;
            clsOutBillBreakdown1.FRTM_BNAC_AMT = 0;
            clsOutBillBreakdown1.FRTM_CARD_RCPT_AMT = 0;
            clsOutBillBreakdown1.FRTM_CASH_RCPT_AMT = 0;
            clsOutBillBreakdown1.FRTM_DCNT_RDIA_AMT = 0;
            clsOutBillBreakdown1.FXAM_MCCS = 0;
            clsOutBillBreakdown1.FXAM_MCCS_REAL_AMT = 0;
            clsOutBillBreakdown1.GURN_BNAC_AMT = 0;
            clsOutBillBreakdown1.GURN_CARD_AMT = 0;
            clsOutBillBreakdown1.GURN_CASH_AMT = 0;
            clsOutBillBreakdown1.GURN_TAMT = 0;
            clsOutBillBreakdown1.GVRN_CLAM_AMT = 0;
            clsOutBillBreakdown1.HLLF_MNCS_BLCE = 0;
            clsOutBillBreakdown1.HLLF_MNCS_CLAM_AMT = 0;
            clsOutBillBreakdown1.HMPT_PAY_TAMT = 0;
            clsOutBillBreakdown1.INDP_MOMR_CLAM_AMT = 0;
            clsOutBillBreakdown1.INSN_100_TAMT = 0;
            clsOutBillBreakdown1.INSN_TYCD = "";
            clsOutBillBreakdown1.MDAD_PRMT_NO = "";
            clsOutBillBreakdown1.MDCN_UPLM_DIAM = 0;
            clsOutBillBreakdown1.MDCR_DD = "";
            clsOutBillBreakdown1.MDCR_DEPT_CD = "";
            clsOutBillBreakdown1.MDCR_DR_CD = "";
            clsOutBillBreakdown1.MRI_USCH_AMT = 0;
            clsOutBillBreakdown1.MTWM_BLCE = 0;
            clsOutBillBreakdown1.MTWM_CLAM_AMT = 0;
            clsOutBillBreakdown1.MTWM_I100_CLAM_AMT = 0;
            clsOutBillBreakdown1.MTWM_NOPY_CLAM_AMT = 0;
            clsOutBillBreakdown1.MTWM_PAY_CLAM_AMT = 0;
            clsOutBillBreakdown1.MTWM_SCPY_CLAM_AMT = 0;
            clsOutBillBreakdown1.NEW_RCPT_RQNO = 0;
            clsOutBillBreakdown1.NEW_ROW_STAT_DVCD = "";
            clsOutBillBreakdown1.NOPY_TAMT = 0;
            clsOutBillBreakdown1.OTPT_AMDT_DVCD = "";
            clsOutBillBreakdown1.PAY_CLAM_AMT = 0;
            clsOutBillBreakdown1.PAY_TAMT = 0;
            clsOutBillBreakdown1.PAY_USCH_AMT = 0;
            clsOutBillBreakdown1.PET_USCH_AMT = 0;
            clsOutBillBreakdown1.PFAN_AMT = 0;
            clsOutBillBreakdown1.PID = "";
            clsOutBillBreakdown1.PT_CMHS_NO = 0;
            clsOutBillBreakdown1.PT_SHAR_AMT = 0;
            clsOutBillBreakdown1.RCPT_DD = "";
            clsOutBillBreakdown1.RCPT_OCRR_UNIQ_NO = "";
            clsOutBillBreakdown1.RCPT_SQNO = 0;
            clsOutBillBreakdown1.RCPT_TIME = "";
            clsOutBillBreakdown1.RFND_RESN = "";
            clsOutBillBreakdown1.RGST_DT = "";
            clsOutBillBreakdown1.RGSTR_ID = "";
            clsOutBillBreakdown1.ROW_STAT_DVCD = "";
            clsOutBillBreakdown1.SCNG_PAY_CLAM_AMT = 0;
            clsOutBillBreakdown1.SCNG_PAY_TAMT = 0;
            clsOutBillBreakdown1.SCNG_PAY_USCH_AMT = 0;
            clsOutBillBreakdown1.SMCR_AMT = 0;
            clsOutBillBreakdown1.SPCL_DCNT_AMT = 0;
            clsOutBillBreakdown1.SPCL_DCNT_DVCD = "";
            clsOutBillBreakdown1.STATVAL1 = 1;
            clsOutBillBreakdown1.STATVAL2 = 1;
            clsOutBillBreakdown1.STATVAL3 = 1;
            clsOutBillBreakdown1.SUPT_AMT = 0;
            clsOutBillBreakdown1.TBRC_CTCT_SUPT_AMT = 0;
            clsOutBillBreakdown1.TOTL_MDCR_AMT = 0;
            clsOutBillBreakdown1.TRNC_AMT = 0;
            clsOutBillBreakdown1.UNCL_AMT = 0;
            clsOutBillBreakdown1.UNCL_BNAC_AMT = 0;
            clsOutBillBreakdown1.UNCL_CARD_AMT = 0;
            clsOutBillBreakdown1.UNCL_CASH_AMT = 0;
            clsOutBillBreakdown1.UNCL_CD = "";
            clsOutBillBreakdown1.UNCL_CUT_AMT = 0;
            clsOutBillBreakdown1.UNCL_RESN = "";
            clsOutBillBreakdown1.USCH_AMT = 0;
            clsOutBillBreakdown1.USCH_UPLM_AMT = 0;
            clsOutBillBreakdown1.VCNT_CLAM_AMT = 0;
            clsOutBillBreakdown1.VTRD_AMT = 0;
            clsOutBillBreakdown1.VTRD_APLY_DVCD = "";
            clsOutBillBreakdown1.VTRN_RNE_AMT = 0;
            clsOutBillBreakdown1.VTRN_TAMT = 0;
            this.ucObillInf11.BillBd = clsOutBillBreakdown1;
            clsOutBillTemp1.ADED_VALU_TAX_TAMT = 0;
            clsOutBillTemp1.ASCT_RGNO_CD = "";
            clsOutBillTemp1.ASST_TYCD = "";
            clsOutBillTemp1.BILL_NO = "";
            clsOutBillTemp1.BLDN_YN = "";
            clsOutBillTemp1.BLOD_RDIA_AMT = 0;
            clsOutBillTemp1.BNAC_RCPT_AMT = 0;
            clsOutBillTemp1.BYKN_ADTN_AMT = 0;
            clsOutBillTemp1.CARD_RCPT_AMT = 0;
            clsOutBillTemp1.CASH_RCPT_AMT = 0;
            clsOutBillTemp1.CFSC_RGNO_CD = "";
            clsOutBillTemp1.CLAM_NOPY_TAMT = 0;
            clsOutBillTemp1.CLNC_UNCL_APLY_AMT = 0;
            clsOutBillTemp1.CT_USCH_AMT = 0;
            clsOutBillTemp1.CTTR_NO_CD = "";
            clsOutBillTemp1.CTTR_UNCL_APLY_AMT = 0;
            clsOutBillTemp1.DCNT_RDIA_AMT = 0;
            clsOutBillTemp1.DCNT_RDIA_CD = "";
            clsOutBillTemp1.DCNT_RDIA_EMNO = "";
            clsOutBillTemp1.DSBL_FUND_AMT = 0;
            clsOutBillTemp1.DY_WARD_YN = "";
            clsOutBillTemp1.EMRG_SUPT_AMT = 0;
            clsOutBillTemp1.FRTM_BNAC_AMT = 0;
            clsOutBillTemp1.FRTM_CARD_RCPT_AMT = 0;
            clsOutBillTemp1.FRTM_CASH_RCPT_AMT = 0;
            clsOutBillTemp1.FRTM_DCNT_RDIA_AMT = 0;
            clsOutBillTemp1.FXAM_MCCS = 0;
            clsOutBillTemp1.FXAM_MCCS_REAL_AMT = 0;
            clsOutBillTemp1.GURN_BNAC_AMT = 0;
            clsOutBillTemp1.GURN_CARD_AMT = 0;
            clsOutBillTemp1.GURN_CASH_AMT = 0;
            clsOutBillTemp1.GVRN_CLAM_AMT = 0;
            clsOutBillTemp1.HLLF_MNCS_BLCE = 0;
            clsOutBillTemp1.HLLF_MNCS_CLAM_AMT = 0;
            clsOutBillTemp1.HMPT_PAY_TAMT = 0;
            clsOutBillTemp1.INDP_MOMR_CLAM_AMT = 0;
            clsOutBillTemp1.INDP_MOMR_YN = "";
            clsOutBillTemp1.INSN_100_TAMT = 0;
            clsOutBillTemp1.INSN_TYCD = "";
            clsOutBillTemp1.MDAD_PRMT_NO = "";
            clsOutBillTemp1.MDCN_UPLM_DIAM = 0;
            clsOutBillTemp1.MDCR_DD = "";
            clsOutBillTemp1.MDCR_DEPT_CD = "";
            clsOutBillTemp1.MDCR_DR_CD = "";
            clsOutBillTemp1.MOMR_AGE_DVCD = "";
            clsOutBillTemp1.MRI_USCH_AMT = 0;
            clsOutBillTemp1.MTWM_BLCE = 0;
            clsOutBillTemp1.MTWM_CLAM_AMT = 0;
            clsOutBillTemp1.MTWM_I100_CLAM_AMT = 0;
            clsOutBillTemp1.MTWM_NOPY_CLAM_AMT = 0;
            clsOutBillTemp1.MTWM_PAY_CLAM_AMT = 0;
            clsOutBillTemp1.MTWM_SCPY_CLAM_AMT = 0;
            clsOutBillTemp1.NOPY_TAMT = 0;
            clsOutBillTemp1.OTPT_DRG_YN = "";
            clsOutBillTemp1.PAY_CLAM_AMT = 0;
            clsOutBillTemp1.PAY_TAMT = 0;
            clsOutBillTemp1.PAY_USCH_AMT = 0;
            clsOutBillTemp1.PET_USCH_AMT = 0;
            clsOutBillTemp1.PFAN_AMT = 0;
            clsOutBillTemp1.PID = "";
            clsOutBillTemp1.PT_CMHS_NO = 0;
            clsOutBillTemp1.PT_SHAR_AMT = 0;
            clsOutBillTemp1.RCPT_SQNO = 0;
            clsOutBillTemp1.SCNG_PAY_CLAM_AMT = 0;
            clsOutBillTemp1.SCNG_PAY_TAMT = 0;
            clsOutBillTemp1.SCNG_PAY_USCH_AMT = 0;
            clsOutBillTemp1.SMCR_AMT = 0;
            clsOutBillTemp1.SPCF_AMT_CLCL_DVCD = "";
            clsOutBillTemp1.SPCL_DCNT_AMT = 0;
            clsOutBillTemp1.SUPT_AMT = 0;
            clsOutBillTemp1.TBRC_CTCT_SUPT_AMT = 0;
            clsOutBillTemp1.TOTL_MDCR_AMT = 0;
            clsOutBillTemp1.TOTL_SHAR_AMT = 0;
            clsOutBillTemp1.TRNC_AMT = 0;
            clsOutBillTemp1.UNCL_AMT = 0;
            clsOutBillTemp1.UNCL_CD = "";
            clsOutBillTemp1.USCH_APLY_CD = "";
            clsOutBillTemp1.USCH_UPLM_AMT = 0;
            clsOutBillTemp1.VCNT_CLAM_AMT = 0;
            clsOutBillTemp1.VTRD_AMT = 0;
            clsOutBillTemp1.VTRD_APLY_DVCD = "";
            clsOutBillTemp1.VTRN_PT_YN = "";
            clsOutBillTemp1.VTRN_RNE_AMT = 0;
            clsOutBillTemp1.VTRN_TAMT = 0;
            this.ucObillInf11.BillTp = clsOutBillTemp1;
            this.ucObillInf11.Caption = "";
            this.ucObillInf11.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ucObillInf11.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.ucObillInf11.Icon = null;
            clsTraiLimitInfo1.ASCT_SHAR_AMT = ((long)(0));
            clsTraiLimitInfo1.CMPY_DD = "";
            clsTraiLimitInfo1.OTPT_ADMS_DVCD = "";
            clsTraiLimitInfo1.PID = "";
            clsTraiLimitInfo1.PT_CMHS_NO = 0;
            clsTraiLimitInfo1.RCPT_DD = "";
            clsTraiLimitInfo1.RCPT_OCRR_UNIQ_NO = "";
            clsTraiLimitInfo1.RCPT_TIME = "";
            clsTraiLimitInfo1.RGST_DT = "";
            clsTraiLimitInfo1.RGSTR_ID = "";
            clsTraiLimitInfo1.TRAI_LIMT_SQNO = 0;
            this.ucObillInf11.LimitInfo = clsTraiLimitInfo1;
            this.ucObillInf11.Location = new System.Drawing.Point(0, 350);
            this.ucObillInf11.Name = "ucObillInf11";
            clsOutReceiptBreakDown2.ACTG_DD = "";
            clsOutReceiptBreakDown2.ACTG_DEPT_CD = "";
            clsOutReceiptBreakDown2.ACTN_MATL_DVCD = "";
            clsOutReceiptBreakDown2.ADED_VALU_TAX_AMT = 0;
            clsOutReceiptBreakDown2.ADTN_APLY_TIME = "";
            clsOutReceiptBreakDown2.ADTN_CMPT_AMT = 0;
            clsOutReceiptBreakDown2.AFRS_STAT_DVCD = "";
            clsOutReceiptBreakDown2.AOMD_MTHD_CD = "";
            clsOutReceiptBreakDown2.APLY_SQNO = 0;
            clsOutReceiptBreakDown2.BNDL_MEFE_CD = "";
            clsOutReceiptBreakDown2.BNDL_PRSC_SQNO = 0;
            clsOutReceiptBreakDown2.BYKN_ADTN_AMT = 0;
            clsOutReceiptBreakDown2.CLAM_CRTN_YN = "";
            clsOutReceiptBreakDown2.CLCL_AMT = 0;
            clsOutReceiptBreakDown2.CLCL_DVCD = "";
            clsOutReceiptBreakDown2.CLUR_DSBL_DVCD = "";
            clsOutReceiptBreakDown2.CLUS_DVCD = "";
            clsOutReceiptBreakDown2.CMPT_CD = "";
            clsOutReceiptBreakDown2.CMPT_DLWT_DVCD_1 = "";
            clsOutReceiptBreakDown2.CMPT_DLWT_DVCD_2 = "";
            clsOutReceiptBreakDown2.CMPT_DLWT_DVCD_3 = "";
            clsOutReceiptBreakDown2.CMPT_DLWT_DVCD_4 = "";
            clsOutReceiptBreakDown2.CNFR_CD = "";
            clsOutReceiptBreakDown2.CNFR_DVCD = "";
            clsOutReceiptBreakDown2.CNVR_PNT = 0D;
            clsOutReceiptBreakDown2.DCNT_AMT = 0;
            clsOutReceiptBreakDown2.DLVR_DEPT_CD = "";
            clsOutReceiptBreakDown2.DNFR_LEFT_LOW_CNTS = "";
            clsOutReceiptBreakDown2.DNFR_LFUP_CNTS = "";
            clsOutReceiptBreakDown2.DNFR_RGHT_LOW_CNTS = "";
            clsOutReceiptBreakDown2.DNFR_RGUP_CNTS = "";
            clsOutReceiptBreakDown2.EDI_CD = "";
            clsOutReceiptBreakDown2.ENTS_ENTD_DVCD = "";
            clsOutReceiptBreakDown2.ENTS_ENTD_INSTNO = "";
            clsOutReceiptBreakDown2.EXCP_RESN_CD = "";
            clsOutReceiptBreakDown2.FXAM_INCL_YN = "";
            clsOutReceiptBreakDown2.GRP_UNPR_APLY_YN = "";
            clsOutReceiptBreakDown2.HPMD_CLCL_DVCD = "";
            clsOutReceiptBreakDown2.HPMD_CLCL_QTY = 0D;
            clsOutReceiptBreakDown2.MDCN_UPLM_AMT = 0;
            clsOutReceiptBreakDown2.MDCN_UPLM_DIAM = 0;
            clsOutReceiptBreakDown2.MDCR_DD = "";
            clsOutReceiptBreakDown2.MEFE_CD = "";
            clsOutReceiptBreakDown2.MEFE_DVCD = "";
            clsOutReceiptBreakDown2.MEFE_NM = "";
            clsOutReceiptBreakDown2.NEW_RCPT_RQNO = 49;
            clsOutReceiptBreakDown2.NEW_ROW_STAT_DVCD = "";
            clsOutReceiptBreakDown2.NODY = 0;
            clsOutReceiptBreakDown2.NOTM = 0;
            clsOutReceiptBreakDown2.ONTM_QTY = 0D;
            clsOutReceiptBreakDown2.ORIG_CLCL_AMT = 0;
            clsOutReceiptBreakDown2.ORIG_PRSC_SQNO = 0;
            clsOutReceiptBreakDown2.ORIG_SQNO = 0;
            clsOutReceiptBreakDown2.ORMD_ANS_DVCD = "";
            clsOutReceiptBreakDown2.ORMD_ANS_ORIG_CD = "";
            clsOutReceiptBreakDown2.ORMD_ANS_ORIG_DVCD = "";
            clsOutReceiptBreakDown2.ORMD_SITE_CD = "";
            clsOutReceiptBreakDown2.ORMD_SITE_DVCD = "";
            clsOutReceiptBreakDown2.OUPR_GRNT_NO = "";
            clsOutReceiptBreakDown2.PAY_CLAM_AMT = 0D;
            clsOutReceiptBreakDown2.PAY_NOPY_DVCD = "";
            clsOutReceiptBreakDown2.PAY_USCH_AMT = 0D;
            clsOutReceiptBreakDown2.PCLR_MATR = "";
            clsOutReceiptBreakDown2.PID = "";
            clsOutReceiptBreakDown2.PRFT_CD = "";
            clsOutReceiptBreakDown2.PRSC_DVCD = "";
            clsOutReceiptBreakDown2.PRSC_SQNO = 0;
            clsOutReceiptBreakDown2.PT_CMHS_NO = 0;
            clsOutReceiptBreakDown2.RCPT_SQNO = 0;
            clsOutReceiptBreakDown2.REAL_PRDC_CD = "";
            clsOutReceiptBreakDown2.RGST_DT = "";
            clsOutReceiptBreakDown2.RGSTR_ID = "";
            clsOutReceiptBreakDown2.ROW_STAT_DVCD = "";
            clsOutReceiptBreakDown2.SBIT_DVCD = "";
            clsOutReceiptBreakDown2.SCNG_PAY_CD = "";
            clsOutReceiptBreakDown2.SCNG_PAY_CLAM_AMT = 0D;
            clsOutReceiptBreakDown2.SCNG_PAY_USCH_AMT = 0D;
            clsOutReceiptBreakDown2.SLCT_MCFE = 0;
            clsOutReceiptBreakDown2.SMCR_AMT = 0;
            clsOutReceiptBreakDown2.SMCR_RATE = 0D;
            clsOutReceiptBreakDown2.STATVAL1 = 1;
            clsOutReceiptBreakDown2.STATVAL2 = 1;
            clsOutReceiptBreakDown2.TIME_ADTN_DVCD = "";
            clsOutReceiptBreakDown2.TOTL_AOMD_QTY = 0D;
            clsOutReceiptBreakDown2.UNPR = 0;
            clsOutReceiptBreakDown2.VTRN_PT_YN = "";
            clsOutReceiptBreakDown2.VTRN_TAMT = 0;
            this.ucObillInf11.OutRecBd = clsOutReceiptBreakDown2;
            clsCardCashPermitInfo1.AFFECTEDROWS = 0;
            clsCardCashPermitInfo1.APP_CARD_BRCD_NO = "";
            clsCardCashPermitInfo1.BILL_NO = "";
            clsCardCashPermitInfo1.BNAC_AMT = 0;
            clsCardCashPermitInfo1.BNAC_PRMT_AMT = 0;
            clsCardCashPermitInfo1.CARD_AMT = 0;
            clsCardCashPermitInfo1.CARD_CASH_NO = "";
            clsCardCashPermitInfo1.CARD_CASH_PRMT_NO = "";
            clsCardCashPermitInfo1.CARD_CO_CD = "";
            clsCardCashPermitInfo1.CARD_PRMT_AMT = 0;
            clsCardCashPermitInfo1.CARD_VALD_DD = "";
            clsCardCashPermitInfo1.CASH_AMT = 0;
            clsCardCashPermitInfo1.CASH_CARD_DVCD = "";
            clsCardCashPermitInfo1.CASH_PRMT_AMT = 0;
            clsCardCashPermitInfo1.CCCS_OCRR_DVCD = "";
            clsCardCashPermitInfo1.CheckBillNo = false;
            clsCardCashPermitInfo1.CMPY_DD = "";
            clsCardCashPermitInfo1.CNCL_ORIG_DEAL_DD = "";
            clsCardCashPermitInfo1.CNCL_ORIG_PRMT_NO = "";
            clsCardCashPermitInfo1.CNCL_YN = "";
            clsCardCashPermitInfo1.DEAL_DVCD = "";
            clsCardCashPermitInfo1.DLWT_IP_ADDR = "100.105.100.19";
            clsCardCashPermitInfo1.ETC_USE_CNTS_1 = "";
            clsCardCashPermitInfo1.ETC_USE_CNTS_2 = "";
            clsCardCashPermitInfo1.ETC_USE_CNTS_3 = "";
            clsCardCashPermitInfo1.ETC_USE_CNTS_4 = "";
            clsCardCashPermitInfo1.ETC_USE_CNTS_5 = "";
            clsCardCashPermitInfo1.FORMNAME = "";
            clsCardCashPermitInfo1.INTM_CNTS_CD = "00";
            clsCardCashPermitInfo1.ISUE_CO_CD = "";
            clsCardCashPermitInfo1.ISUE_CO_NM = "";
            clsCardCashPermitInfo1.MSG_1 = "";
            clsCardCashPermitInfo1.MSG_2 = "";
            clsCardCashPermitInfo1.OLD_BILL_NO = "";
            clsCardCashPermitInfo1.PID = "";
            clsCardCashPermitInfo1.PRCH_CO_CD = "";
            clsCardCashPermitInfo1.PRCH_CO_NM = "";
            clsCardCashPermitInfo1.PRMT_DT = "";
            clsCardCashPermitInfo1.PRMT_RQST_DVCD = "";
            clsCardCashPermitInfo1.PRMT_SQNO = 0;
            clsCardCashPermitInfo1.PT_CMHS_NO = 0;
            clsCardCashPermitInfo1.RCPT_DD = "";
            clsCardCashPermitInfo1.RCPT_OCRR_UNIQ_NO = "";
            clsCardCashPermitInfo1.RCPT_SQNO = 0;
            clsCardCashPermitInfo1.RCPT_TIME = "";
            clsCardCashPermitInfo1.RGST_DT = "";
            clsCardCashPermitInfo1.RGSTR_ID = "";
            clsCardCashPermitInfo1.RQST_DD = "";
            clsCardCashPermitInfo1.SUCCESS = false;
            clsCardCashPermitInfo1.TOTAL_AMT = 0;
            this.ucObillInf11.PermitInfo = clsCardCashPermitInfo1;
            this.ucObillInf11.Size = new System.Drawing.Size(512, 498);
            this.ucObillInf11.SystemLocked = false;
            this.ucObillInf11.TabIndex = 2;
            // 
            // cboPermitCheckYn
            // 
            appearance9.BackColor = System.Drawing.Color.Transparent;
            appearance9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.cboPermitCheckYn.Appearance = appearance9;
            this.cboPermitCheckYn.BackColor = System.Drawing.Color.Transparent;
            this.cboPermitCheckYn.BackColorInternal = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.cboPermitCheckYn.Location = new System.Drawing.Point(339, 9);
            this.cboPermitCheckYn.Name = "cboPermitCheckYn";
            this.cboPermitCheckYn.Size = new System.Drawing.Size(120, 17);
            this.cboPermitCheckYn.TabIndex = 15;
            this.cboPermitCheckYn.Text = "현금승인확인여부";
            this.cboPermitCheckYn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboPermitCheckYn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.cboPermitCheckYn.Visible = false;
            // 
            // chkDisplayAmt
            // 
            appearance8.BackColor = System.Drawing.Color.Transparent;
            appearance8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.chkDisplayAmt.Appearance = appearance8;
            this.chkDisplayAmt.BackColor = System.Drawing.Color.Transparent;
            this.chkDisplayAmt.BackColorInternal = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.chkDisplayAmt.Location = new System.Drawing.Point(465, 9);
            this.chkDisplayAmt.Name = "chkDisplayAmt";
            this.chkDisplayAmt.Size = new System.Drawing.Size(120, 17);
            this.chkDisplayAmt.TabIndex = 15;
            this.chkDisplayAmt.Text = "금액표시기";
            this.chkDisplayAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.chkDisplayAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.chkDisplayAmt.Visible = false;
            // 
            // lxPanel9
            // 
            this.lxPanel9.BackColor = System.Drawing.Color.White;
            this.lxPanel9.Controls.Add(this.dteMdcrDd);
            this.lxPanel9.Controls.Add(this.LxTitleLabel1);
            this.lxPanel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxPanel9.Location = new System.Drawing.Point(3, 2);
            this.lxPanel9.Name = "lxPanel9";
            this.lxPanel9.Size = new System.Drawing.Size(218, 34);
            this.lxPanel9.TabIndex = 16;
            // 
            // dteMdcrDd
            // 
            appearance6.BackColor = System.Drawing.Color.White;
            appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance6.TextHAlignAsString = "Center";
            appearance6.TextVAlignAsString = "Middle";
            this.dteMdcrDd.Appearance = appearance6;
            this.dteMdcrDd.BackColor = System.Drawing.Color.White;
            this.dteMdcrDd.DateTime = new System.DateTime(2018, 2, 21, 0, 0, 0, 0);
            this.dteMdcrDd.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.dteMdcrDd.Location = new System.Drawing.Point(56, 4);
            this.dteMdcrDd.Name = "dteMdcrDd";
            this.dteMdcrDd.Size = new System.Drawing.Size(146, 27);
            this.dteMdcrDd.TabIndex = 11;
            this.dteMdcrDd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.dteMdcrDd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.dteMdcrDd.Value = new System.DateTime(2018, 2, 21, 0, 0, 0, 0);
            // 
            // chkForWhitePrint
            // 
            appearance5.BackColor = System.Drawing.Color.Transparent;
            appearance5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.chkForWhitePrint.Appearance = appearance5;
            this.chkForWhitePrint.BackColor = System.Drawing.Color.Transparent;
            this.chkForWhitePrint.BackColorInternal = System.Drawing.Color.Transparent;
            this.chkForWhitePrint.Checked = true;
            this.chkForWhitePrint.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkForWhitePrint.Location = new System.Drawing.Point(553, 7);
            this.chkForWhitePrint.Name = "chkForWhitePrint";
            this.chkForWhitePrint.Size = new System.Drawing.Size(67, 22);
            this.chkForWhitePrint.TabIndex = 18;
            this.chkForWhitePrint.Text = "순백지";
            this.chkForWhitePrint.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.chkForWhitePrint.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.chkForWhitePrint.Visible = false;
            // 
            // chkForPharmacy
            // 
            appearance4.BackColor = System.Drawing.Color.Transparent;
            appearance4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.chkForPharmacy.Appearance = appearance4;
            this.chkForPharmacy.BackColor = System.Drawing.Color.Transparent;
            this.chkForPharmacy.BackColorInternal = System.Drawing.Color.Transparent;
            this.chkForPharmacy.Checked = true;
            this.chkForPharmacy.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkForPharmacy.Location = new System.Drawing.Point(613, 7);
            this.chkForPharmacy.Name = "chkForPharmacy";
            this.chkForPharmacy.Size = new System.Drawing.Size(75, 22);
            this.chkForPharmacy.TabIndex = 18;
            this.chkForPharmacy.Text = "약국제출";
            this.chkForPharmacy.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.chkForPharmacy.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.chkForPharmacy.Visible = false;
            // 
            // chkForPatient
            // 
            appearance3.BackColor = System.Drawing.Color.Transparent;
            appearance3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.chkForPatient.Appearance = appearance3;
            this.chkForPatient.BackColor = System.Drawing.Color.Transparent;
            this.chkForPatient.BackColorInternal = System.Drawing.Color.Transparent;
            this.chkForPatient.Checked = true;
            this.chkForPatient.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkForPatient.Location = new System.Drawing.Point(691, 7);
            this.chkForPatient.Name = "chkForPatient";
            this.chkForPatient.Size = new System.Drawing.Size(73, 22);
            this.chkForPatient.TabIndex = 18;
            this.chkForPatient.Text = "환자보관";
            this.chkForPatient.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.chkForPatient.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.chkForPatient.Visible = false;
            // 
            // chkIlnsCd
            // 
            appearance2.BackColor = System.Drawing.Color.Transparent;
            appearance2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.chkIlnsCd.Appearance = appearance2;
            this.chkIlnsCd.BackColor = System.Drawing.Color.Transparent;
            this.chkIlnsCd.BackColorInternal = System.Drawing.Color.Transparent;
            this.chkIlnsCd.Checked = true;
            this.chkIlnsCd.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkIlnsCd.Location = new System.Drawing.Point(770, 7);
            this.chkIlnsCd.Name = "chkIlnsCd";
            this.chkIlnsCd.Size = new System.Drawing.Size(73, 22);
            this.chkIlnsCd.TabIndex = 18;
            this.chkIlnsCd.Text = "상병표시";
            this.chkIlnsCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.chkIlnsCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.chkIlnsCd.Visible = false;
            // 
            // pnlWating
            // 
            this.pnlWating.BackColor = System.Drawing.Color.White;
            this.pnlWating.Controls.Add(this.tabWating);
            this.pnlWating.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.pnlWating.Location = new System.Drawing.Point(0, 38);
            this.pnlWating.Name = "pnlWating";
            this.pnlWating.Size = new System.Drawing.Size(30, 848);
            this.pnlWating.TabIndex = 5;
            // 
            // tabWating
            // 
            appearance26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance26.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            appearance26.BorderColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            appearance26.BorderColor3DBase = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance26.FontData.BoldAsString = "True";
            appearance26.FontData.Name = "굴림";
            appearance26.FontData.SizeInPoints = 9F;
            appearance26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(34)))), ((int)(((byte)(184)))));
            appearance26.ImageBackground = ((System.Drawing.Image)(resources.GetObject("appearance26.ImageBackground")));
            appearance26.ImageBackgroundStyle = Infragistics.Win.ImageBackgroundStyle.Stretched;
            appearance26.TextHAlignAsString = "Center";
            appearance26.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance26.TextVAlignAsString = "Middle";
            this.tabWating.ActiveTabAppearance = appearance26;
            this.tabWating.AlphaBlendMode = Infragistics.Win.AlphaBlendMode.Disabled;
            appearance27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance27.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance27.BorderColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            appearance27.BorderColor3DBase = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance27.FontData.BoldAsString = "False";
            appearance27.FontData.Name = "굴림";
            appearance27.FontData.SizeInPoints = 9F;
            appearance27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            appearance27.TextHAlignAsString = "Center";
            appearance27.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance27.TextVAlignAsString = "Middle";
            this.tabWating.Appearance = appearance27;
            appearance28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance28.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance28.BorderColor3DBase = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(157)))));
            this.tabWating.ClientAreaAppearance = appearance28;
            this.tabWating.Controls.Add(this.ultraTabSharedControlsPage1);
            this.tabWating.Controls.Add(this.ultraTabPageControl1);
            this.tabWating.Dock = System.Windows.Forms.DockStyle.Fill;
            appearance29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance29.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            appearance29.BorderColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            appearance29.BorderColor3DBase = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance29.FontData.BoldAsString = "True";
            appearance29.FontData.Name = "굴림";
            appearance29.FontData.SizeInPoints = 10F;
            appearance29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(34)))), ((int)(((byte)(184)))));
            appearance29.TextHAlignAsString = "Center";
            appearance29.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance29.TextVAlignAsString = "Middle";
            this.tabWating.HotTrackAppearance = appearance29;
            this.tabWating.Location = new System.Drawing.Point(0, 0);
            this.tabWating.MaxVisibleTabRows = 1;
            this.tabWating.MultiRowSelectionStyle = Infragistics.Win.UltraWinTabs.MultiRowSelectionStyle.HighlightTab;
            this.tabWating.Name = "tabWating";
            this.tabWating.SharedControlsPage = this.ultraTabSharedControlsPage1;
            this.tabWating.Size = new System.Drawing.Size(30, 848);
            this.tabWating.SpaceAfterTabs = new Infragistics.Win.DefaultableInteger(0);
            this.tabWating.SpaceBeforeTabs = new Infragistics.Win.DefaultableInteger(0);
            this.tabWating.Style = Infragistics.Win.UltraWinTabControl.UltraTabControlStyle.VisualStudio;
            appearance30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            this.tabWating.TabHeaderAreaAppearance = appearance30;
            this.tabWating.TabIndex = 0;
            this.tabWating.TabOrientation = Infragistics.Win.UltraWinTabs.TabOrientation.LeftTop;
            this.tabWating.TabPadding = new System.Drawing.Size(0, 15);
            ultraTab1.TabPage = this.ultraTabPageControl1;
            ultraTab1.Text = "외래대기자";
            this.tabWating.Tabs.AddRange(new Infragistics.Win.UltraWinTabControl.UltraTab[] {
            ultraTab1});
            this.tabWating.TabSize = new System.Drawing.Size(0, 28);
            this.tabWating.TextOrientation = Infragistics.Win.UltraWinTabs.TextOrientation.HorizontalPlus270;
            this.tabWating.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.tabWating.UseHotTracking = Infragistics.Win.DefaultableBoolean.True;
            this.tabWating.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // ultraTabSharedControlsPage1
            // 
            this.ultraTabSharedControlsPage1.Location = new System.Drawing.Point(-10000, -10000);
            this.ultraTabSharedControlsPage1.Name = "ultraTabSharedControlsPage1";
            this.ultraTabSharedControlsPage1.Size = new System.Drawing.Size(0, 846);
            // 
            // chkAutoEmr
            // 
            appearance1.BackColor = System.Drawing.Color.Transparent;
            appearance1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.chkAutoEmr.Appearance = appearance1;
            this.chkAutoEmr.BackColor = System.Drawing.Color.Transparent;
            this.chkAutoEmr.BackColorInternal = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.chkAutoEmr.Dock = System.Windows.Forms.DockStyle.Right;
            this.chkAutoEmr.Location = new System.Drawing.Point(1662, 5);
            this.chkAutoEmr.Name = "chkAutoEmr";
            this.chkAutoEmr.Size = new System.Drawing.Size(96, 28);
            this.chkAutoEmr.TabIndex = 20;
            this.chkAutoEmr.Text = "자동EMR조회";
            this.chkAutoEmr.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.chkAutoEmr.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // btnPrintPrescription
            // 
            appearance11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance11.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance11.FontData.BoldAsString = "False";
            appearance11.FontData.Name = "맑은 고딕";
            appearance11.FontData.SizeInPoints = 9F;
            appearance11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(90)))), ((int)(((byte)(20)))));
            appearance11.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance11.TextHAlignAsString = "Center";
            appearance11.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance11.TextVAlignAsString = "Middle";
            this.btnPrintPrescription.Appearance = appearance11;
            this.btnPrintPrescription.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat;
            appearance12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance12.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance12.FontData.BoldAsString = "True";
            appearance12.FontData.Name = "맑은 고딕";
            appearance12.FontData.SizeInPoints = 9F;
            appearance12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance12.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance12.TextHAlignAsString = "Center";
            appearance12.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance12.TextVAlignAsString = "Middle";
            this.btnPrintPrescription.HotTrackAppearance = appearance12;
            this.btnPrintPrescription.Location = new System.Drawing.Point(322, 212);
            this.btnPrintPrescription.Name = "btnPrintPrescription";
            appearance13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance13.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance13.FontData.BoldAsString = "True";
            appearance13.FontData.Name = "맑은 고딕";
            appearance13.FontData.SizeInPoints = 8F;
            appearance13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance13.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance13.TextHAlignAsString = "Center";
            appearance13.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance13.TextVAlignAsString = "Middle";
            this.btnPrintPrescription.PressedAppearance = appearance13;
            this.btnPrintPrescription.Size = new System.Drawing.Size(112, 27);
            this.btnPrintPrescription.TabIndex = 23;
            this.btnPrintPrescription.Text = "원내처방전 재발행";
            this.btnPrintPrescription.UseFlatMode = Infragistics.Win.DefaultableBoolean.False;
            this.btnPrintPrescription.UseHotTracking = Infragistics.Win.DefaultableBoolean.True;
            this.btnPrintPrescription.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.btnPrintPrescription.WrapText = false;
            // 
            // ucfOutReceiptE
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.pnlWating);
            this.Name = "ucfOutReceiptE";
            this.Size = new System.Drawing.Size(1920, 886);
            this.Controls.SetChildIndex(this.pnlTop, 0);
            this.Controls.SetChildIndex(this.pnlBase, 0);
            this.Controls.SetChildIndex(this.pnlWating, 0);
            ((System.ComponentModel.ISupportInitialize)(this.pnlTop)).EndInit();
            this.pnlTop.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).EndInit();
            this.pnlBase.ResumeLayout(false);
            this.ultraTabPageControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ucOutRecWatingList1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkFrvsRvst)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnButtonList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel1)).EndInit();
            this.lxPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lxTitlePanel1)).EndInit();
            this.lxTitlePanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ucOrderHisV1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel4)).EndInit();
            this.lxPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ucSameDayRegList1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel2)).EndInit();
            this.lxPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnNeedRereciept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNotCard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNonPermit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSearchMefeUnpr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ucOrecRegInf11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel3)).EndInit();
            this.lxPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel5)).EndInit();
            this.lxPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel8)).EndInit();
            this.lxPanel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel7)).EndInit();
            this.lxPanel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel6)).EndInit();
            this.lxPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ucObillInf11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboPermitCheckYn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkDisplayAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel9)).EndInit();
            this.lxPanel9.ResumeLayout(false);
            this.lxPanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dteMdcrDd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkForWhitePrint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkForPharmacy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkForPatient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkIlnsCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlWating)).EndInit();
            this.pnlWating.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tabWating)).EndInit();
            this.tabWating.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chkAutoEmr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnPrintPrescription)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ucSpecialInf ucSpecialInf1;
        private ucOdisInf ucOdisInf1;
        private ucOlocInf ucOlocInf1;
        private ucOappInf ucOappInf1;
        private Framework.Controls.LxTitleLabel LxTitleLabel1;
        private ucObillInf1 ucObillInf11;
        private ucOrecRegInf1 ucOrecRegInf11;
        private Framework.Controls.LxCheckBox chkFrvsRvst;
        private ucOutReceiptBD ucOutReceiptBD1;
        private Framework.Controls.LxButtonList btnButtonList;
        private Framework.Controls.LxPanel lxPanel2;
        private Framework.Controls.LxPanel lxPanel3;
        private Framework.Controls.LxPanel lxPanel1;
        private Framework.Controls.LxCheckBox cboPermitCheckYn;
        private Framework.Controls.LxPanel lxPanel5;
        private Framework.Controls.LxPanel lxPanel8;
        private Framework.Controls.LxPanel lxPanel7;
        private Framework.Controls.LxPanel lxPanel6;
        private Framework.Controls.LxPanel lxPanel9;
        private Framework.Controls.LxCheckBox chkDisplayAmt;
        private Framework.Controls.LxDateTimeEditor dteMdcrDd;
        private Framework.Controls.LxCheckBox chkForWhitePrint;
        private Framework.Controls.LxCheckBox chkForPatient;
        private Framework.Controls.LxCheckBox chkForPharmacy;
        private Framework.Controls.LxCheckBox chkIlnsCd;
        private Framework.Controls.LxTitlePanel lxTitlePanel1;
        private Framework.Controls.LxPanel lxPanel4;
        private ucOremInf ucOremInf2;
        private ucOremInf ucOremInf1;
        private ucSameDayRegList ucSameDayRegList1;
        private Framework.Controls.LxPanel pnlWating;
        private Framework.Controls.LxTabControl tabWating;
        private Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage ultraTabSharedControlsPage1;
        private Infragistics.Win.UltraWinTabControl.UltraTabPageControl ultraTabPageControl1;
        private ucOutRecWatingList ucOutRecWatingList1;
        private Framework.Controls.LxButton btnSearchMefeUnpr;
        private Framework.Controls.LxButton btnNonPermit;
        private Framework.Controls.LxCheckBox chkAutoEmr;
        private Framework.Controls.LxButton btnNotCard;
        private ucOrderHisV ucOrderHisV1;
        private Framework.Controls.LxButton btnNeedRereciept;
        private Framework.Controls.LxButton btnPrintPrescription;
    }
}