

<script setup lang="ts">
import { ref, reactive, onMounted, defineExpose, computed } from "vue";
import { $ref, $computed } from 'vue/macros'
import { DateTime } from "@/app/framework/CommonService/DateTime";
import { DataTable } from "@/app/framework/DataType/DataTable";
import { COMBO_ADD_ITEM_TYPE, CRUD_TYPE } from "@/app/framework/DataType/PublicEnum";
import { DOPack } from "@/app/framework/DataObject/DOPack";
import { DBService } from "@/app/framework/DBService/DBService";
import { ConfigService } from "@/app/framework/ConfigService/ConfigService";
import { StringService } from "@/app/framework/CommonService/StringService";
import { DateTimeService } from "@/app/framework/CommonService/DateTimeService";
import { LogService } from "@/app/framework/CommonService/LogService";
import { UserList } from "@/app/framework/DataService/UserList";
import { OverallCodeList } from "@/app/framework/DataService/OverallCodeList";
import { ClinicList } from "@/app/framework/DataService/ClinicList";
import { ButtonType } from "@/app/framework/Controls/TypeClass/ButtonList/ButtonType";
import { ORBizCommon } from "@/app/framework/BusinessService/ORBizCommon";
import { Function } from "@/app/framework/SqlPack/Function/Function";
import { Procedure } from "@/app/framework/SqlPack/Procedure/Procedure";
import { Int } from "@/app/utils/Int";
import { decimal } from "@/app/utils/decimal.extensions";
import { MessageBoxButtons } from "@/app/utils/MessageBoxButtons";
import { MessageBoxIcon } from "@/app/utils/MessageBoxIcon";
import { DialogResult } from "@/app/utils/DialogResult";
import { BizCommon } from "@/app/utils/BizCommon";
import LxMessageComp from "@/app/framework/Controls/LxMessage/_index.vue";
import Keys = System.Windows.Forms.Keys;
import Color = System.Drawing.Color;
import { System } from "@/app/utils/System";
import { DialogResult } from "@/app/utils/DialogResult";
import LxTextBox from "@/app/framework/Controls/LxTextBox/_index.vue";
// import LxTitleLabel from "@/app/framework/Controls/LxTitleLabel/_index.vue";
import LxDateTimePicker from "@/app/framework/Controls/LxDateTimePicker/_index.vue";
// import LxTitlePanel from "@/app/framework/Controls/LxTitlePanel/index.vue";
import LxSpread from "@/app/framework/Controls/LxSpread/_index.vue";
import { SheetView } from "@/app/framework/DataType/SheetView";
// import LxPanel from "@/app/framework/Controls/LxPanel/_index.vue";
import { LxButtonList } from "@/app/framework/Controls/LxButtonList/_index.vue";
import { CellType } from "@/app/framework/DataType/CellType";
import DockStyle = System.Windows.Forms.DockStyle;
import { CellHorizontalAlignment, CellVerticalAlignment, VerticalPosition, HorizontalPosition } from "@/app/framework/Controls/LxSpread/LxSpreadNS";

        const txtPtNm = $ref(null); //LxTextBox
        const lxTitleLabel2 = $ref(null); //LxTitleLabel
        const txtPid = $ref(null); //LxTextBox
        const lxTitleLabel1 = $ref(null); //LxTitleLabel
        const lxTitleLabel3 = $ref(null); //LxTitleLabel
        const dteMdcrDate = $ref(null); //LxDateTimeEditor
        const lxTitlePanel3 = $ref(null); //LxTitlePanel
        const lxTitlePanel2 = $ref(null); //LxTitlePanel
        const sprMefeInfo = $ref(null); //LxSpread
        const sprMefeInfo_Sheet1 = new SheetView(); //SheetView
        const sprMefe = $ref(null); //LxSpread
        const sprMefe_Sheet1 = new SheetView(); //SheetView
        private LxSplitContainer lxSplitContainer1;
        private Lime.BusinessControls.ucMefeAutoComplete ucMefeAutoComplete1;
        const txtMefeSearch = $ref(null); //LxTextBox
        const lxPanel1 = $ref(null); //LxPanel
        const lxButtonList1 = $ref(null); //LxButtonList

/* Life Cycles */
onMounted(() => {
  InitializeComponent();
  Controls = [
    /*lxTextBox*/
    , txtPtNm, txtPid, txtMefeSearch
     /*lxDateTimeEditor*/
    , dteMdcrDate
];
  OnLoad();
});
const InitializeComponent = () => {
            const textCellType1 = new CellType.TextCellType();
            const textCellType2 = new CellType.TextCellType();
            const comboBoxCellType1 = new CellType.ComboBoxCellType();
            const checkBoxCellType1 = new CellType.CheckBoxCellType();
            const checkBoxCellType2 = new CellType.CheckBoxCellType();
            const textCellType3 = new CellType.TextCellType();
            const textCellType4 = new CellType.TextCellType();
            const checkBoxCellType3 = new CellType.CheckBoxCellType();
            const textCellType5 = new CellType.TextCellType();
            const numberCellType1 = new CellType.NumberCellType();
            const numberCellType2 = new CellType.NumberCellType();
            const numberCellType3 = new CellType.NumberCellType();
            const numberCellType4 = new CellType.NumberCellType();
            const textCellType6 = new CellType.TextCellType();
            const textCellType7 = new CellType.TextCellType();
            const textCellType8 = new CellType.TextCellType();
            const numberCellType5 = new CellType.NumberCellType();
            const textCellType9 = new CellType.TextCellType();
            const comboBoxCellType2 = new CellType.ComboBoxCellType();
            const textCellType10 = new CellType.TextCellType();
            const checkBoxCellType4 = new CellType.CheckBoxCellType();
            const checkBoxCellType5 = new CellType.CheckBoxCellType();
            const checkBoxCellType6 = new CellType.CheckBoxCellType();
            const comboBoxCellType3 = new CellType.ComboBoxCellType();
            const checkBoxCellType7 = new CellType.CheckBoxCellType();
            const checkBoxCellType8 = new CellType.CheckBoxCellType();
            const textCellType11 = new CellType.TextCellType();
            const textCellType12 = new CellType.TextCellType();
            const comboBoxCellType4 = new CellType.ComboBoxCellType();
            const comboBoxCellType5 = new CellType.ComboBoxCellType();
            const textCellType13 = new CellType.TextCellType();
            const textCellType14 = new CellType.TextCellType();
            const textCellType15 = new CellType.TextCellType();
            const maskCellType1 = new CellType.MaskCellType();
            const maskCellType2 = new CellType.MaskCellType();
            const comboBoxCellType6 = new CellType.ComboBoxCellType();
            const maskCellType3 = new CellType.MaskCellType();
            const comboBoxCellType7 = new CellType.ComboBoxCellType();
            const textCellType16 = new CellType.TextCellType();
            const textCellType17 = new CellType.TextCellType();
            const textCellType18 = new CellType.TextCellType();
            const textCellType19 = new CellType.TextCellType();
            const textCellType20 = new CellType.TextCellType();
            const textCellType21 = new CellType.TextCellType();
            const textCellType22 = new CellType.TextCellType();
            const textCellType23 = new CellType.TextCellType();
            const textCellType24 = new CellType.TextCellType();
            const textCellType25 = new CellType.TextCellType();
            const textCellType26 = new CellType.TextCellType();
            const textCellType27 = new CellType.TextCellType();
            const textCellType28 = new CellType.TextCellType();
            const textCellType29 = new CellType.TextCellType();
            const textCellType30 = new CellType.TextCellType();
            const textCellType31 = new CellType.TextCellType();
            const textCellType32 = new CellType.TextCellType();
            const textCellType33 = new CellType.TextCellType();
            const numberCellType6 = new CellType.NumberCellType();
            const numberCellType7 = new CellType.NumberCellType();
            const textCellType34 = new CellType.TextCellType();
            const textCellType35 = new CellType.TextCellType();
            const textCellType36 = new CellType.TextCellType();
            const textCellType37 = new CellType.TextCellType();
            const textCellType38 = new CellType.TextCellType();
            const textCellType39 = new CellType.TextCellType();
            const textCellType40 = new CellType.TextCellType();
            const textCellType41 = new CellType.TextCellType();
            const textCellType42 = new CellType.TextCellType();
            const textCellType43 = new CellType.TextCellType();
            const textCellType44 = new CellType.TextCellType();
            const textCellType45 = new CellType.TextCellType();
            const textCellType46 = new CellType.TextCellType();
            const textCellType47 = new CellType.TextCellType();
            const textCellType48 = new CellType.TextCellType();
            const textCellType49 = new CellType.TextCellType();
            const textCellType50 = new CellType.TextCellType();
            const textCellType51 = new CellType.TextCellType();
            const textCellType52 = new CellType.TextCellType();
            const textCellType53 = new CellType.TextCellType();
            const textCellType54 = new CellType.TextCellType();
            const textCellType55 = new CellType.TextCellType();
            const textCellType56 = new CellType.TextCellType();
            const textCellType57 = new CellType.TextCellType();
            const textCellType58 = new CellType.TextCellType();
            const textCellType59 = new CellType.TextCellType();
            const textCellType60 = new CellType.TextCellType();
            const textCellType61 = new CellType.TextCellType();
            const textCellType62 = new CellType.TextCellType();
            const textCellType63 = new CellType.TextCellType();
            const textCellType64 = new CellType.TextCellType();
            const textCellType65 = new CellType.TextCellType();
            const textCellType66 = new CellType.TextCellType();
            const textCellType67 = new CellType.TextCellType();
            const textCellType68 = new CellType.TextCellType();
            const textCellType69 = new CellType.TextCellType();
            const textCellType70 = new CellType.TextCellType();
            const textCellType71 = new CellType.TextCellType();
            const textCellType72 = new CellType.TextCellType();
            const textCellType73 = new CellType.TextCellType();
            const textCellType74 = new CellType.TextCellType();
            const textCellType75 = new CellType.TextCellType();
            const textCellType76 = new CellType.TextCellType();
            const textCellType77 = new CellType.TextCellType();
            const textCellType78 = new CellType.TextCellType();
            const textCellType79 = new CellType.TextCellType();
            const textCellType80 = new CellType.TextCellType();
            const textCellType81 = new CellType.TextCellType();
            const textCellType82 = new CellType.TextCellType();
            const textCellType83 = new CellType.TextCellType();
            const textCellType84 = new CellType.TextCellType();
            const textCellType85 = new CellType.TextCellType();
            const textCellType86 = new CellType.TextCellType();
            const textCellType87 = new CellType.TextCellType();
            const textCellType88 = new CellType.TextCellType();
            const textCellType89 = new CellType.TextCellType();
            const textCellType90 = new CellType.TextCellType();
            const textCellType91 = new CellType.TextCellType();
            const textCellType92 = new CellType.TextCellType();
            const textCellType93 = new CellType.TextCellType();
            const textCellType94 = new CellType.TextCellType();
            const textCellType95 = new CellType.TextCellType();
            const textCellType96 = new CellType.TextCellType();
            const textCellType97 = new CellType.TextCellType();
            const textCellType98 = new CellType.TextCellType();
            const textCellType99 = new CellType.TextCellType();
            const textCellType100 = new CellType.TextCellType();
            const textCellType101 = new CellType.TextCellType();
            const textCellType102 = new CellType.TextCellType();
            const numberCellType8 = new CellType.NumberCellType();
            const textCellType103 = new CellType.TextCellType();
            const textCellType104 = new CellType.TextCellType();
            const textCellType105 = new CellType.TextCellType();
            const textCellType106 = new CellType.TextCellType();
            const textCellType107 = new CellType.TextCellType();
            const textCellType108 = new CellType.TextCellType();
            const textCellType109 = new CellType.TextCellType();
            const textCellType110 = new CellType.TextCellType();
            const textCellType111 = new CellType.TextCellType();
            // lxTitleLabel1
            // lxTitleLabel1.Name = "lxTitleLabel1";
            // lxTitleLabel1.TabIndex = 0;
            // lxTitleLabel1.Text = "환자번호";
            // txtPid
            txtPid.Name = "txtPid";
            txtPid.ReadOnly = true;
            txtPid.TabIndex = 1;
            // lxTitleLabel2
            // lxTitleLabel2.Name = "lxTitleLabel2";
            // lxTitleLabel2.TabIndex = 0;
            // lxTitleLabel2.Text = "환자명";
            // txtPtNm
            txtPtNm.Name = "txtPtNm";
            txtPtNm.ReadOnly = true;
            txtPtNm.TabIndex = 1;
            // lxTitleLabel3
            // lxTitleLabel3.Name = "lxTitleLabel3";
            // lxTitleLabel3.TabIndex = 0;
            // lxTitleLabel3.Text = "처방일자";
            // dteMdcrDate
            dteMdcrDate.Name = "dteMdcrDate";
            dteMdcrDate.ReadOnly = true;
            dteMdcrDate.TabIndex = 2;
            // lxPanel1
            // lxPanel1.Dock = DockStyle.Top;
            // lxPanel1.Name = "lxPanel1";
            // lxPanel1.TabIndex = 16;
            // lxButtonList1
            lxButtonList1.ButtonItems.AddRange(new Controls.ButtonItem[] {
            lxButtonList1.Dock = DockStyle.Right;
            lxButtonList1.Name = "lxButtonList1";
            lxButtonList1.TabIndex = 3;
            // lxTitlePanel2
            lxTitlePanel2.BottomBarVisible = false;
            lxTitlePanel2.BottomText = "";
            lxTitlePanel2.Dock = DockStyle.Fill;
            lxTitlePanel2.Name = "lxTitlePanel2";
            lxTitlePanel2.TabIndex = 0;
            lxTitlePanel2.TitleText = "수가정보";
            // sprMefeInfo
            sprMefeInfo.Dock = DockStyle.Fill;
            sprMefeInfo.Name = "sprMefeInfo";
            sprMefeInfo_Sheet1});
            sprMefeInfo.TabIndex = 2;
            // sprMefeInfo_Sheet1
            sprMefeInfo_Sheet1.Reset();
            sprMefeInfo_Sheet1.SheetName = "Sheet1";
            sprMefeInfo_Sheet1.Columns.Get(0).CellType = textCellType1;
            sprMefeInfo_Sheet1.Columns.Get(0).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefeInfo_Sheet1.Columns.Get(0).Label = "수가코드";
            sprMefeInfo_Sheet1.Columns.Get(0).Tag = "MEFE_CD";
            sprMefeInfo_Sheet1.Columns.Get(0).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefeInfo_Sheet1.Columns.Get(0).Width = 82;
            sprMefeInfo_Sheet1.Columns.Get(1).CellType = textCellType2;
            sprMefeInfo_Sheet1.Columns.Get(1).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefeInfo_Sheet1.Columns.Get(1).Label = "수가명";
            sprMefeInfo_Sheet1.Columns.Get(1).Tag = "MEFE_NM";
            sprMefeInfo_Sheet1.Columns.Get(1).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefeInfo_Sheet1.Columns.Get(1).Width = 300;
            // lxTitlePanel3
            lxTitlePanel3.BottomBarVisible = false;
            lxTitlePanel3.BottomText = "";
            lxTitlePanel3.Dock = DockStyle.Fill;
            lxTitlePanel3.Name = "lxTitlePanel3";
            lxTitlePanel3.TabIndex = 0;
            lxTitlePanel3.TitleText = "처방정보";
            ucMefeAutoComplete1.TabIndex = 1;
            // sprMefe
            sprMefe.Dock = DockStyle.Fill;
            sprMefe.Name = "sprMefe";
            sprMefe_Sheet1});
            sprMefe.TabIndex = 0;
            sprMefe.TabStripRatio = 0.503109882515549;
            sprMefe.TextTipDelay = 10;
            sprMefe.UseAlternatingRowsColor = false;
            sprMefe.UseCRUDColor = false;
            sprMefe.UseLimeStyle = false;
            sprMefe.CellClick += new CellClickEventHandler(sprMefe_CellClick_1);
            // sprMefe_Sheet1
            sprMefe_Sheet1.Reset();
            sprMefe_Sheet1.SheetName = "Sheet1";
            sprMefe_Sheet1.Columns.Get(0).Locked = false;
            sprMefe_Sheet1.Columns.Get(0).Tag = "A";
            sprMefe_Sheet1.Columns.Get(0).Width = 0;
            sprMefe_Sheet1.Columns.Get(1).CellType = comboBoxCellType1;
            sprMefe_Sheet1.Columns.Get(1).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(1).Label = "구분";
            sprMefe_Sheet1.Columns.Get(1).Tag = "PRSC_DVCD";
            sprMefe_Sheet1.Columns.Get(1).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(1).Width = 40;
            sprMefe_Sheet1.Columns.Get(2).CellType = checkBoxCellType1;
            sprMefe_Sheet1.Columns.Get(2).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(2).Label = "T";
            sprMefe_Sheet1.Columns.Get(2).Tag = "TEL_PRSC_FLAG";
            sprMefe_Sheet1.Columns.Get(2).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(2).Width = 24;
            sprMefe_Sheet1.Columns.Get(3).CellType = checkBoxCellType2;
            sprMefe_Sheet1.Columns.Get(3).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(3).Label = "F";
            sprMefe_Sheet1.Columns.Get(3).Tag = "FREE_PRSC_CD";
            sprMefe_Sheet1.Columns.Get(3).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(3).Width = 24;
            sprMefe_Sheet1.Columns.Get(4).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(4).Label = "\r\n";
            sprMefe_Sheet1.Columns.Get(4).Locked = true;
            sprMefe_Sheet1.Columns.Get(4).Tag = "MSG_VIEW";
            sprMefe_Sheet1.Columns.Get(4).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(4).Width = 10;
            sprMefe_Sheet1.Columns.Get(5).CellType = textCellType3;
            sprMefe_Sheet1.Columns.Get(5).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(5).Label = "처방코드";
            sprMefe_Sheet1.Columns.Get(5).Tag = "PRSC_CD";
            sprMefe_Sheet1.Columns.Get(5).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(5).Width = 84;
            sprMefe_Sheet1.Columns.Get(6).CellType = textCellType4;
            sprMefe_Sheet1.Columns.Get(6).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(6).Label = "처방명칭";
            sprMefe_Sheet1.Columns.Get(6).Tag = "PRSC_NM";
            sprMefe_Sheet1.Columns.Get(6).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(6).Width = 330;
            sprMefe_Sheet1.Columns.Get(7).CellType = checkBoxCellType3;
            sprMefe_Sheet1.Columns.Get(7).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(7).Label = "선택";
            sprMefe_Sheet1.Columns.Get(7).Tag = "FLAG";
            sprMefe_Sheet1.Columns.Get(7).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(7).Width = 34;
            sprMefe_Sheet1.Columns.Get(8).CellType = textCellType5;
            sprMefe_Sheet1.Columns.Get(8).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(8).Label = "1회량";
            sprMefe_Sheet1.Columns.Get(8).Tag = "PRSC_INPT_QTY";
            sprMefe_Sheet1.Columns.Get(8).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(8).Width = 57;
            sprMefe_Sheet1.Columns.Get(9).CellType = numberCellType1;
            sprMefe_Sheet1.Columns.Get(9).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(9).Label = "\r\n";
            sprMefe_Sheet1.Columns.Get(9).Tag = "ONTM_QTY";
            sprMefe_Sheet1.Columns.Get(9).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(9).Width = 57;
            sprMefe_Sheet1.Columns.Get(10).CellType = numberCellType2;
            sprMefe_Sheet1.Columns.Get(10).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(10).Label = "횟수";
            sprMefe_Sheet1.Columns.Get(10).Tag = "NOTM";
            sprMefe_Sheet1.Columns.Get(10).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(10).Width = 34;
            sprMefe_Sheet1.Columns.Get(11).CellType = numberCellType3;
            sprMefe_Sheet1.Columns.Get(11).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(11).Label = "Acting";
            sprMefe_Sheet1.Columns.Get(11).Locked = true;
            sprMefe_Sheet1.Columns.Get(11).Tag = "ACTN_ACTG_NOTM";
            sprMefe_Sheet1.Columns.Get(11).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(11).Visible = false;
            sprMefe_Sheet1.Columns.Get(11).Width = 46;
            sprMefe_Sheet1.Columns.Get(12).CellType = numberCellType4;
            sprMefe_Sheet1.Columns.Get(12).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(12).Label = "일수";
            sprMefe_Sheet1.Columns.Get(12).Tag = "NODY";
            sprMefe_Sheet1.Columns.Get(12).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(12).Width = 34;
            textCellType6.CharacterSet = CellType.CharacterSet.AlphaNumeric;
            sprMefe_Sheet1.Columns.Get(13).CellType = textCellType6;
            sprMefe_Sheet1.Columns.Get(13).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(13).Label = "용법";
            sprMefe_Sheet1.Columns.Get(13).Tag = "AOMD_MTHD_CD";
            sprMefe_Sheet1.Columns.Get(13).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(13).Width = 34;
            sprMefe_Sheet1.Columns.Get(14).CellType = textCellType7;
            sprMefe_Sheet1.Columns.Get(14).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(14).Label = "MIX";
            sprMefe_Sheet1.Columns.Get(14).Tag = "MIX_YN";
            sprMefe_Sheet1.Columns.Get(14).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(14).Width = 32;
            textCellType8.CharacterSet = CellType.CharacterSet.AlphaNumeric;
            sprMefe_Sheet1.Columns.Get(15).CellType = textCellType8;
            sprMefe_Sheet1.Columns.Get(15).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(15).Label = "예외";
            sprMefe_Sheet1.Columns.Get(15).Tag = "EXCP_RESN_CD";
            sprMefe_Sheet1.Columns.Get(15).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(15).Width = 34;
            sprMefe_Sheet1.Columns.Get(16).CellType = numberCellType5;
            sprMefe_Sheet1.Columns.Get(16).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(16).Label = "함량";
            sprMefe_Sheet1.Columns.Get(16).Tag = "CTNT";
            sprMefe_Sheet1.Columns.Get(16).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(16).Width = 40;
            sprMefe_Sheet1.Columns.Get(17).CellType = textCellType9;
            sprMefe_Sheet1.Columns.Get(17).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(17).Label = "간격";
            sprMefe_Sheet1.Columns.Get(17).Tag = "AOMD_ITVL_VALU";
            sprMefe_Sheet1.Columns.Get(17).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(17).Visible = false;
            sprMefe_Sheet1.Columns.Get(17).Width = 34;
            sprMefe_Sheet1.Columns.Get(18).CellType = comboBoxCellType2;
            sprMefe_Sheet1.Columns.Get(18).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(18).Label = "속도";
            sprMefe_Sheet1.Columns.Get(18).Tag = "AOMD_VLCT_VALU";
            sprMefe_Sheet1.Columns.Get(18).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(18).Visible = false;
            sprMefe_Sheet1.Columns.Get(18).Width = 54;
            sprMefe_Sheet1.Columns.Get(19).CellType = textCellType10;
            sprMefe_Sheet1.Columns.Get(19).HorizontalAlignment = CellHorizontalAlignment.Right;
            sprMefe_Sheet1.Columns.Get(19).Label = "금액";
            sprMefe_Sheet1.Columns.Get(19).Tag = "PRICE";
            sprMefe_Sheet1.Columns.Get(19).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(20).CellType = checkBoxCellType4;
            sprMefe_Sheet1.Columns.Get(20).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(20).Label = "P";
            sprMefe_Sheet1.Columns.Get(20).Tag = "PWDR_YN";
            sprMefe_Sheet1.Columns.Get(20).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(20).Width = 24;
            sprMefe_Sheet1.Columns.Get(21).CellType = checkBoxCellType5;
            sprMefe_Sheet1.Columns.Get(21).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(21).Label = "이동";
            sprMefe_Sheet1.Columns.Get(21).Tag = "MOVE_PHTG_YN";
            sprMefe_Sheet1.Columns.Get(21).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(21).Width = 34;
            sprMefe_Sheet1.Columns.Get(22).CellType = checkBoxCellType6;
            sprMefe_Sheet1.Columns.Get(22).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(22).Label = "선";
            sprMefe_Sheet1.Columns.Get(22).Tag = "PRV_ACTG_YN";
            sprMefe_Sheet1.Columns.Get(22).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(22).Width = 24;
            sprMefe_Sheet1.Columns.Get(23).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(23).Label = "\r\n";
            sprMefe_Sheet1.Columns.Get(23).Tag = "SUB_ADMS_VIEW";
            sprMefe_Sheet1.Columns.Get(23).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(23).Width = 10;
            sprMefe_Sheet1.Columns.Get(24).CellType = comboBoxCellType3;
            sprMefe_Sheet1.Columns.Get(24).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(24).Label = "급비구분";
            sprMefe_Sheet1.Columns.Get(24).Tag = "PNPY_DVCD";
            sprMefe_Sheet1.Columns.Get(24).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(25).CellType = checkBoxCellType7;
            sprMefe_Sheet1.Columns.Get(25).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(25).Label = "접수";
            sprMefe_Sheet1.Columns.Get(25).Locked = true;
            sprMefe_Sheet1.Columns.Get(25).Tag = "SUPT_DEPT_RCPN_YN";
            sprMefe_Sheet1.Columns.Get(25).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(25).Visible = false;
            sprMefe_Sheet1.Columns.Get(25).Width = 34;
            sprMefe_Sheet1.Columns.Get(26).CellType = checkBoxCellType8;
            sprMefe_Sheet1.Columns.Get(26).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(26).Label = "결과";
            sprMefe_Sheet1.Columns.Get(26).Locked = true;
            sprMefe_Sheet1.Columns.Get(26).Tag = "RSLT_DFNT_YN";
            sprMefe_Sheet1.Columns.Get(26).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(26).Visible = false;
            sprMefe_Sheet1.Columns.Get(26).Width = 34;
            sprMefe_Sheet1.Columns.Get(27).CellType = textCellType11;
            sprMefe_Sheet1.Columns.Get(27).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(27).Label = "접";
            sprMefe_Sheet1.Columns.Get(27).Locked = true;
            sprMefe_Sheet1.Columns.Get(27).Tag = "SUPT_DEPT_RCPN_YN_VIEW";
            sprMefe_Sheet1.Columns.Get(27).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(27).Width = 15;
            sprMefe_Sheet1.Columns.Get(28).CellType = textCellType12;
            sprMefe_Sheet1.Columns.Get(28).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(28).Label = "결";
            sprMefe_Sheet1.Columns.Get(28).Locked = true;
            sprMefe_Sheet1.Columns.Get(28).Tag = "RSLT_DFNT_YN_VIEW";
            sprMefe_Sheet1.Columns.Get(28).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(28).Width = 15;
            sprMefe_Sheet1.Columns.Get(29).CellType = comboBoxCellType4;
            sprMefe_Sheet1.Columns.Get(29).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(29).Label = "등록자";
            sprMefe_Sheet1.Columns.Get(29).Locked = true;
            sprMefe_Sheet1.Columns.Get(29).Tag = "RGSTR_ID";
            sprMefe_Sheet1.Columns.Get(29).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(30).CellType = comboBoxCellType5;
            sprMefe_Sheet1.Columns.Get(30).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(30).Label = "PickUp자";
            sprMefe_Sheet1.Columns.Get(30).Locked = true;
            sprMefe_Sheet1.Columns.Get(30).Tag = "PCUP_TGPS_ID";
            sprMefe_Sheet1.Columns.Get(30).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(30).Width = 61;
            sprMefe_Sheet1.Columns.Get(31).CellType = textCellType13;
            sprMefe_Sheet1.Columns.Get(31).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(31).Label = "    특이사항";
            sprMefe_Sheet1.Columns.Get(31).Tag = "PRSC_PCFT";
            sprMefe_Sheet1.Columns.Get(31).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(31).Width = 329;
            sprMefe_Sheet1.Columns.Get(32).CellType = textCellType14;
            sprMefe_Sheet1.Columns.Get(32).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(32).Label = "S";
            sprMefe_Sheet1.Columns.Get(32).Tag = "PNOD_PRSC_PSND";
            sprMefe_Sheet1.Columns.Get(32).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(32).Width = 40;
            sprMefe_Sheet1.Columns.Get(33).CellType = textCellType15;
            sprMefe_Sheet1.Columns.Get(33).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(33).Label = "E";
            sprMefe_Sheet1.Columns.Get(33).Tag = "PNOD_PRSC_INOD";
            sprMefe_Sheet1.Columns.Get(33).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(33).Width = 40;
            sprMefe_Sheet1.Columns.Get(34).CellType = maskCellType1;
            sprMefe_Sheet1.Columns.Get(34).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(34).Label = "등록일시";
            sprMefe_Sheet1.Columns.Get(34).Tag = "RGST_DT";
            sprMefe_Sheet1.Columns.Get(34).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(34).Width = 130;
            sprMefe_Sheet1.Columns.Get(35).CellType = maskCellType2;
            sprMefe_Sheet1.Columns.Get(35).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(35).Label = "수정일시";
            sprMefe_Sheet1.Columns.Get(35).Tag = "UPDT_DT";
            sprMefe_Sheet1.Columns.Get(35).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(35).Width = 130;
            sprMefe_Sheet1.Columns.Get(36).CellType = comboBoxCellType6;
            sprMefe_Sheet1.Columns.Get(36).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(36).Label = "수정자";
            sprMefe_Sheet1.Columns.Get(36).Tag = "UPDTR_ID";
            sprMefe_Sheet1.Columns.Get(36).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(37).CellType = maskCellType3;
            sprMefe_Sheet1.Columns.Get(37).HorizontalAlignment = CellHorizontalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(37).Label = "PickUp일시";
            sprMefe_Sheet1.Columns.Get(37).Tag = "PCUP_DT";
            sprMefe_Sheet1.Columns.Get(37).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(37).Width = 130;
            sprMefe_Sheet1.Columns.Get(38).CellType = comboBoxCellType7;
            sprMefe_Sheet1.Columns.Get(38).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(38).Label = "!PYDS_ITCN_DEPT_CD";
            sprMefe_Sheet1.Columns.Get(38).Tag = "PYDS_ITCN_DEPT_CD";
            sprMefe_Sheet1.Columns.Get(38).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(38).Visible = false;
            sprMefe_Sheet1.Columns.Get(38).Width = 80;
            sprMefe_Sheet1.Columns.Get(39).CellType = textCellType16;
            sprMefe_Sheet1.Columns.Get(39).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(39).Label = "!MSG_DVCD";
            sprMefe_Sheet1.Columns.Get(39).Tag = "MSG_DVCD";
            sprMefe_Sheet1.Columns.Get(39).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(39).Visible = false;
            sprMefe_Sheet1.Columns.Get(40).CellType = textCellType17;
            sprMefe_Sheet1.Columns.Get(40).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(40).Label = "PID";
            sprMefe_Sheet1.Columns.Get(40).Tag = "PID";
            sprMefe_Sheet1.Columns.Get(40).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(40).Visible = false;
            sprMefe_Sheet1.Columns.Get(41).CellType = textCellType18;
            sprMefe_Sheet1.Columns.Get(41).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(41).Label = "PT_CMHS_NO";
            sprMefe_Sheet1.Columns.Get(41).Tag = "PT_CMHS_NO";
            sprMefe_Sheet1.Columns.Get(41).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(41).Visible = false;
            sprMefe_Sheet1.Columns.Get(42).CellType = textCellType19;
            sprMefe_Sheet1.Columns.Get(42).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(42).Label = "MDCR_DD";
            sprMefe_Sheet1.Columns.Get(42).Tag = "MDCR_DD";
            sprMefe_Sheet1.Columns.Get(42).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(42).Visible = false;
            sprMefe_Sheet1.Columns.Get(43).CellType = textCellType20;
            sprMefe_Sheet1.Columns.Get(43).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(43).Label = "PRSC_SQNO";
            sprMefe_Sheet1.Columns.Get(43).Tag = "PRSC_SQNO";
            sprMefe_Sheet1.Columns.Get(43).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(43).Visible = false;
            sprMefe_Sheet1.Columns.Get(44).CellType = textCellType21;
            sprMefe_Sheet1.Columns.Get(44).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(44).Label = "PRSC_UNIQ_NO";
            sprMefe_Sheet1.Columns.Get(44).Tag = "PRSC_UNIQ_NO";
            sprMefe_Sheet1.Columns.Get(44).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(44).Visible = false;
            sprMefe_Sheet1.Columns.Get(45).CellType = textCellType22;
            sprMefe_Sheet1.Columns.Get(45).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(45).Label = "PRSC_SORT_SEQ";
            sprMefe_Sheet1.Columns.Get(45).Tag = "PRSC_SORT_SEQ";
            sprMefe_Sheet1.Columns.Get(45).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(45).Visible = false;
            sprMefe_Sheet1.Columns.Get(46).CellType = textCellType23;
            sprMefe_Sheet1.Columns.Get(46).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(46).Label = "OTPT_ADMS_DVCD";
            sprMefe_Sheet1.Columns.Get(46).Tag = "OTPT_ADMS_DVCD";
            sprMefe_Sheet1.Columns.Get(46).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(46).Visible = false;
            sprMefe_Sheet1.Columns.Get(47).CellType = textCellType24;
            sprMefe_Sheet1.Columns.Get(47).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(47).Label = "PRSC_TIME";
            sprMefe_Sheet1.Columns.Get(47).Tag = "PRSC_TIME";
            sprMefe_Sheet1.Columns.Get(47).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(47).Visible = false;
            sprMefe_Sheet1.Columns.Get(48).CellType = textCellType25;
            sprMefe_Sheet1.Columns.Get(48).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(48).Label = "MDCR_DEPT_CD";
            sprMefe_Sheet1.Columns.Get(48).Tag = "MDCR_DEPT_CD";
            sprMefe_Sheet1.Columns.Get(48).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(48).Visible = false;
            sprMefe_Sheet1.Columns.Get(49).CellType = textCellType26;
            sprMefe_Sheet1.Columns.Get(49).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(49).Label = "MDCR_DR_CD";
            sprMefe_Sheet1.Columns.Get(49).Tag = "MDCR_DR_CD";
            sprMefe_Sheet1.Columns.Get(49).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(49).Visible = false;
            sprMefe_Sheet1.Columns.Get(50).CellType = textCellType27;
            sprMefe_Sheet1.Columns.Get(50).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(50).Label = "REAL_PRDC_CD";
            sprMefe_Sheet1.Columns.Get(50).Tag = "REAL_PRDC_CD";
            sprMefe_Sheet1.Columns.Get(50).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(50).Visible = false;
            sprMefe_Sheet1.Columns.Get(51).CellType = textCellType28;
            sprMefe_Sheet1.Columns.Get(51).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(51).Label = "DLVR_DEPT_CD";
            sprMefe_Sheet1.Columns.Get(51).Tag = "DLVR_DEPT_CD";
            sprMefe_Sheet1.Columns.Get(51).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(51).Visible = false;
            sprMefe_Sheet1.Columns.Get(52).CellType = textCellType29;
            sprMefe_Sheet1.Columns.Get(52).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(52).Label = "ACTG_DEPT_CD";
            sprMefe_Sheet1.Columns.Get(52).Tag = "ACTG_DEPT_CD";
            sprMefe_Sheet1.Columns.Get(52).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(52).Visible = false;
            sprMefe_Sheet1.Columns.Get(53).CellType = textCellType30;
            sprMefe_Sheet1.Columns.Get(53).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(53).Label = "VIST_PLCE_CD";
            sprMefe_Sheet1.Columns.Get(53).Tag = "VIST_PLCE_CD";
            sprMefe_Sheet1.Columns.Get(53).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(53).Visible = false;
            sprMefe_Sheet1.Columns.Get(54).CellType = textCellType31;
            sprMefe_Sheet1.Columns.Get(54).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(54).Label = "WARD_CD";
            sprMefe_Sheet1.Columns.Get(54).Tag = "WARD_CD";
            sprMefe_Sheet1.Columns.Get(54).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(54).Visible = false;
            sprMefe_Sheet1.Columns.Get(55).CellType = textCellType32;
            sprMefe_Sheet1.Columns.Get(55).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(55).Label = "PRSC_LCLS_CD";
            sprMefe_Sheet1.Columns.Get(55).Tag = "PRSC_LCLS_CD";
            sprMefe_Sheet1.Columns.Get(55).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(55).Visible = false;
            sprMefe_Sheet1.Columns.Get(56).CellType = textCellType33;
            sprMefe_Sheet1.Columns.Get(56).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(56).Label = "PRSC_MCLS_CD";
            sprMefe_Sheet1.Columns.Get(56).Tag = "PRSC_MCLS_CD";
            sprMefe_Sheet1.Columns.Get(56).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(56).Visible = false;
            sprMefe_Sheet1.Columns.Get(57).CellType = numberCellType6;
            sprMefe_Sheet1.Columns.Get(57).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(57).Label = "APLY_ONTM_QTY";
            sprMefe_Sheet1.Columns.Get(57).Tag = "APLY_ONTM_QTY";
            sprMefe_Sheet1.Columns.Get(57).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(57).Visible = false;
            sprMefe_Sheet1.Columns.Get(58).CellType = numberCellType7;
            sprMefe_Sheet1.Columns.Get(58).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(58).Label = "TOTL_AOMD_QTY";
            sprMefe_Sheet1.Columns.Get(58).Tag = "TOTL_AOMD_QTY";
            sprMefe_Sheet1.Columns.Get(58).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(58).Visible = false;
            sprMefe_Sheet1.Columns.Get(59).CellType = textCellType34;
            sprMefe_Sheet1.Columns.Get(59).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(59).Label = "CC_AOMD_QTY";
            sprMefe_Sheet1.Columns.Get(59).Tag = "CC_AOMD_QTY";
            sprMefe_Sheet1.Columns.Get(59).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(59).Visible = false;
            sprMefe_Sheet1.Columns.Get(60).CellType = textCellType35;
            sprMefe_Sheet1.Columns.Get(60).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(60).Label = "PNOD_PRSC_UNIQ_NO";
            sprMefe_Sheet1.Columns.Get(60).Tag = "PNOD_PRSC_UNIQ_NO";
            sprMefe_Sheet1.Columns.Get(60).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(60).Visible = false;
            sprMefe_Sheet1.Columns.Get(61).CellType = textCellType36;
            sprMefe_Sheet1.Columns.Get(61).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(61).Label = "AOMD_UNIT_VALU";
            sprMefe_Sheet1.Columns.Get(61).Tag = "AOMD_UNIT_VALU";
            sprMefe_Sheet1.Columns.Get(61).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(61).Visible = false;
            sprMefe_Sheet1.Columns.Get(62).CellType = textCellType37;
            sprMefe_Sheet1.Columns.Get(62).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(62).Label = "ORIG_AOMD_MTHD_CD";
            sprMefe_Sheet1.Columns.Get(62).Tag = "ORIG_AOMD_MTHD_CD";
            sprMefe_Sheet1.Columns.Get(62).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(62).Visible = false;
            sprMefe_Sheet1.Columns.Get(63).CellType = textCellType38;
            sprMefe_Sheet1.Columns.Get(63).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(63).Label = "MDCT_NO";
            sprMefe_Sheet1.Columns.Get(63).Tag = "MDCT_NO";
            sprMefe_Sheet1.Columns.Get(63).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(63).Visible = false;
            sprMefe_Sheet1.Columns.Get(64).CellType = textCellType39;
            sprMefe_Sheet1.Columns.Get(64).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(64).Label = "OUPR_GRNT_NO";
            sprMefe_Sheet1.Columns.Get(64).Tag = "OUPR_GRNT_NO";
            sprMefe_Sheet1.Columns.Get(64).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(64).Visible = false;
            sprMefe_Sheet1.Columns.Get(65).CellType = textCellType40;
            sprMefe_Sheet1.Columns.Get(65).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(65).Label = "SMCR_APLY_YN";
            sprMefe_Sheet1.Columns.Get(65).Tag = "SMCR_APLY_YN";
            sprMefe_Sheet1.Columns.Get(65).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(65).Visible = false;
            sprMefe_Sheet1.Columns.Get(66).CellType = textCellType41;
            sprMefe_Sheet1.Columns.Get(66).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(66).Label = "HOPE_DD";
            sprMefe_Sheet1.Columns.Get(66).Tag = "HOPE_DD";
            sprMefe_Sheet1.Columns.Get(66).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(66).Visible = false;
            sprMefe_Sheet1.Columns.Get(67).CellType = textCellType42;
            sprMefe_Sheet1.Columns.Get(67).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(67).Label = "DC_PRSC_DVCD";
            sprMefe_Sheet1.Columns.Get(67).Tag = "DC_PRSC_DVCD";
            sprMefe_Sheet1.Columns.Get(67).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(67).Visible = false;
            sprMefe_Sheet1.Columns.Get(68).CellType = textCellType43;
            sprMefe_Sheet1.Columns.Get(68).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(68).Label = "ORIG_PT_CMHS_NO";
            sprMefe_Sheet1.Columns.Get(68).Tag = "ORIG_PT_CMHS_NO";
            sprMefe_Sheet1.Columns.Get(68).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(68).Visible = false;
            sprMefe_Sheet1.Columns.Get(69).CellType = textCellType44;
            sprMefe_Sheet1.Columns.Get(69).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(69).Label = "ORIG_MDCR_DD";
            sprMefe_Sheet1.Columns.Get(69).Tag = "ORIG_MDCR_DD";
            sprMefe_Sheet1.Columns.Get(69).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(69).Visible = false;
            sprMefe_Sheet1.Columns.Get(70).CellType = textCellType45;
            sprMefe_Sheet1.Columns.Get(70).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(70).Label = "ORIG_PRSC_SQNO";
            sprMefe_Sheet1.Columns.Get(70).Tag = "ORIG_PRSC_SQNO";
            sprMefe_Sheet1.Columns.Get(70).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(70).Visible = false;
            sprMefe_Sheet1.Columns.Get(71).CellType = textCellType46;
            sprMefe_Sheet1.Columns.Get(71).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(71).Label = "DEL_YN";
            sprMefe_Sheet1.Columns.Get(71).Tag = "DEL_YN";
            sprMefe_Sheet1.Columns.Get(71).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(71).Visible = false;
            sprMefe_Sheet1.Columns.Get(72).CellType = textCellType47;
            sprMefe_Sheet1.Columns.Get(72).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(72).Label = "RCPT_YN";
            sprMefe_Sheet1.Columns.Get(72).Tag = "RCPT_YN";
            sprMefe_Sheet1.Columns.Get(72).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(72).Visible = false;
            sprMefe_Sheet1.Columns.Get(73).CellType = textCellType48;
            sprMefe_Sheet1.Columns.Get(73).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(73).Label = "CLCL_HOLD_YN";
            sprMefe_Sheet1.Columns.Get(73).Tag = "CLCL_HOLD_YN";
            sprMefe_Sheet1.Columns.Get(73).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(73).Visible = false;
            sprMefe_Sheet1.Columns.Get(74).CellType = textCellType49;
            sprMefe_Sheet1.Columns.Get(74).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(74).Label = "OP_DVCD";
            sprMefe_Sheet1.Columns.Get(74).Tag = "OP_DVCD";
            sprMefe_Sheet1.Columns.Get(74).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(74).Visible = false;
            sprMefe_Sheet1.Columns.Get(75).CellType = textCellType50;
            sprMefe_Sheet1.Columns.Get(75).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(75).Label = "PRSC_TIME_DVCD";
            sprMefe_Sheet1.Columns.Get(75).Tag = "PRSC_TIME_DVCD";
            sprMefe_Sheet1.Columns.Get(75).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(75).Visible = false;
            sprMefe_Sheet1.Columns.Get(76).Label = "EMRG_ADTN_YN";
            sprMefe_Sheet1.Columns.Get(76).Tag = "EMRG_ADTN_YN";
            sprMefe_Sheet1.Columns.Get(76).Visible = false;
            sprMefe_Sheet1.Columns.Get(77).CellType = textCellType51;
            sprMefe_Sheet1.Columns.Get(77).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(77).Label = "ANST_MTHD_DVCD";
            sprMefe_Sheet1.Columns.Get(77).Tag = "ANST_MTHD_DVCD";
            sprMefe_Sheet1.Columns.Get(77).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(77).Visible = false;
            sprMefe_Sheet1.Columns.Get(78).CellType = textCellType52;
            sprMefe_Sheet1.Columns.Get(78).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(78).Label = "ANST_INHL_PRDT_CD";
            sprMefe_Sheet1.Columns.Get(78).Tag = "ANST_INHL_PRDT_CD";
            sprMefe_Sheet1.Columns.Get(78).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(78).Visible = false;
            sprMefe_Sheet1.Columns.Get(79).CellType = textCellType53;
            sprMefe_Sheet1.Columns.Get(79).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(79).Label = "ANST_TIME";
            sprMefe_Sheet1.Columns.Get(79).Tag = "ANST_TIME";
            sprMefe_Sheet1.Columns.Get(79).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(79).Visible = false;
            sprMefe_Sheet1.Columns.Get(80).CellType = textCellType54;
            sprMefe_Sheet1.Columns.Get(80).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(80).Label = "CNFR_DVCD";
            sprMefe_Sheet1.Columns.Get(80).Tag = "CNFR_DVCD";
            sprMefe_Sheet1.Columns.Get(80).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(80).Visible = false;
            sprMefe_Sheet1.Columns.Get(81).CellType = textCellType55;
            sprMefe_Sheet1.Columns.Get(81).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(81).Label = "CNFR_CD";
            sprMefe_Sheet1.Columns.Get(81).Tag = "CNFR_CD";
            sprMefe_Sheet1.Columns.Get(81).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(81).Visible = false;
            sprMefe_Sheet1.Columns.Get(82).CellType = textCellType56;
            sprMefe_Sheet1.Columns.Get(82).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(82).Label = "TRFS_PLCE_CD";
            sprMefe_Sheet1.Columns.Get(82).Tag = "TRFS_PLCE_CD";
            sprMefe_Sheet1.Columns.Get(82).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(82).Visible = false;
            sprMefe_Sheet1.Columns.Get(83).CellType = textCellType57;
            sprMefe_Sheet1.Columns.Get(83).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(83).Label = "PRSC_CLSF_CD";
            sprMefe_Sheet1.Columns.Get(83).Tag = "PRSC_CLSF_CD";
            sprMefe_Sheet1.Columns.Get(83).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(83).Visible = false;
            sprMefe_Sheet1.Columns.Get(84).CellType = textCellType58;
            sprMefe_Sheet1.Columns.Get(84).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(84).Label = "DNFR_RGUP_CNTS";
            sprMefe_Sheet1.Columns.Get(84).Tag = "DNFR_RGUP_CNTS";
            sprMefe_Sheet1.Columns.Get(84).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(84).Visible = false;
            sprMefe_Sheet1.Columns.Get(85).CellType = textCellType59;
            sprMefe_Sheet1.Columns.Get(85).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(85).Label = "DNFR_LFUP_CNTS";
            sprMefe_Sheet1.Columns.Get(85).Tag = "DNFR_LFUP_CNTS";
            sprMefe_Sheet1.Columns.Get(85).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(85).Visible = false;
            sprMefe_Sheet1.Columns.Get(86).CellType = textCellType60;
            sprMefe_Sheet1.Columns.Get(86).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(86).Label = "DNFR_RGHT_LOW_CNTS";
            sprMefe_Sheet1.Columns.Get(86).Tag = "DNFR_RGHT_LOW_CNTS";
            sprMefe_Sheet1.Columns.Get(86).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(86).Visible = false;
            sprMefe_Sheet1.Columns.Get(87).CellType = textCellType61;
            sprMefe_Sheet1.Columns.Get(87).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(87).Label = "DNFR_LEFT_LOW_CNTS";
            sprMefe_Sheet1.Columns.Get(87).Tag = "DNFR_LEFT_LOW_CNTS";
            sprMefe_Sheet1.Columns.Get(87).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(87).Visible = false;
            sprMefe_Sheet1.Columns.Get(88).CellType = textCellType62;
            sprMefe_Sheet1.Columns.Get(88).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(88).Label = "PRSC_INPS_DVCD";
            sprMefe_Sheet1.Columns.Get(88).Tag = "PRSC_INPS_DVCD";
            sprMefe_Sheet1.Columns.Get(88).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(88).Visible = false;
            sprMefe_Sheet1.Columns.Get(89).CellType = textCellType63;
            sprMefe_Sheet1.Columns.Get(89).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(89).Label = "MAIN_INGR_CD";
            sprMefe_Sheet1.Columns.Get(89).Tag = "MAIN_INGR_CD";
            sprMefe_Sheet1.Columns.Get(89).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(89).Visible = false;
            sprMefe_Sheet1.Columns.Get(90).CellType = textCellType64;
            sprMefe_Sheet1.Columns.Get(90).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(90).Label = "SPCM_CD";
            sprMefe_Sheet1.Columns.Get(90).Tag = "SPCM_CD";
            sprMefe_Sheet1.Columns.Get(90).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(90).Visible = false;
            sprMefe_Sheet1.Columns.Get(91).CellType = textCellType65;
            sprMefe_Sheet1.Columns.Get(91).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(91).Label = "SPCM_RCPN_YN";
            sprMefe_Sheet1.Columns.Get(91).Tag = "SPCM_RCPN_YN";
            sprMefe_Sheet1.Columns.Get(91).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(91).Visible = false;
            sprMefe_Sheet1.Columns.Get(92).CellType = textCellType66;
            sprMefe_Sheet1.Columns.Get(92).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(92).Label = "SPCM_RCPN_DT";
            sprMefe_Sheet1.Columns.Get(92).Tag = "SPCM_RCPN_DT";
            sprMefe_Sheet1.Columns.Get(92).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(92).Visible = false;
            sprMefe_Sheet1.Columns.Get(93).CellType = textCellType67;
            sprMefe_Sheet1.Columns.Get(93).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(93).Label = "SPCM_RCPS_ID";
            sprMefe_Sheet1.Columns.Get(93).Tag = "SPCM_RCPS_ID";
            sprMefe_Sheet1.Columns.Get(93).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(93).Visible = false;
            sprMefe_Sheet1.Columns.Get(94).CellType = textCellType68;
            sprMefe_Sheet1.Columns.Get(94).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(94).Label = "SPCM_RCPN_NO";
            sprMefe_Sheet1.Columns.Get(94).Tag = "SPCM_RCPN_NO";
            sprMefe_Sheet1.Columns.Get(94).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(94).Visible = false;
            sprMefe_Sheet1.Columns.Get(95).Label = "SPCM_PRNT_YN";
            sprMefe_Sheet1.Columns.Get(95).Tag = "SPCM_PRNT_YN";
            sprMefe_Sheet1.Columns.Get(95).Visible = false;
            sprMefe_Sheet1.Columns.Get(96).CellType = textCellType69;
            sprMefe_Sheet1.Columns.Get(96).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(96).Label = "PCUP_YN";
            sprMefe_Sheet1.Columns.Get(96).Tag = "PCUP_YN";
            sprMefe_Sheet1.Columns.Get(96).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(96).Visible = false;
            sprMefe_Sheet1.Columns.Get(97).CellType = textCellType70;
            sprMefe_Sheet1.Columns.Get(97).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(97).Label = "PCUP_DEPT_CD";
            sprMefe_Sheet1.Columns.Get(97).Tag = "PCUP_DEPT_CD";
            sprMefe_Sheet1.Columns.Get(97).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(97).Visible = false;
            sprMefe_Sheet1.Columns.Get(98).CellType = textCellType71;
            sprMefe_Sheet1.Columns.Get(98).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(98).Label = "PRSC_STOP_DVCD";
            sprMefe_Sheet1.Columns.Get(98).Tag = "PRSC_STOP_DVCD";
            sprMefe_Sheet1.Columns.Get(98).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(98).Visible = false;
            sprMefe_Sheet1.Columns.Get(99).CellType = textCellType72;
            sprMefe_Sheet1.Columns.Get(99).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(99).Label = "PTAF_CLCL_APLY_YN";
            sprMefe_Sheet1.Columns.Get(99).Tag = "PTAF_CLCL_APLY_YN";
            sprMefe_Sheet1.Columns.Get(99).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(99).Visible = false;
            sprMefe_Sheet1.Columns.Get(100).CellType = textCellType73;
            sprMefe_Sheet1.Columns.Get(100).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(100).Label = "PTAF_CLCL_ACTG_DT";
            sprMefe_Sheet1.Columns.Get(100).Tag = "PTAF_CLCL_ACTG_DT";
            sprMefe_Sheet1.Columns.Get(100).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(100).Visible = false;
            sprMefe_Sheet1.Columns.Get(101).CellType = textCellType74;
            sprMefe_Sheet1.Columns.Get(101).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(101).Label = "PTAF_CLCL_ACTR_ID";
            sprMefe_Sheet1.Columns.Get(101).Tag = "PTAF_CLCL_ACTR_ID";
            sprMefe_Sheet1.Columns.Get(101).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(101).Visible = false;
            sprMefe_Sheet1.Columns.Get(102).CellType = textCellType75;
            sprMefe_Sheet1.Columns.Get(102).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(102).Label = "SUPT_DEPT_APNT_YN";
            sprMefe_Sheet1.Columns.Get(102).Tag = "SUPT_DEPT_APNT_YN";
            sprMefe_Sheet1.Columns.Get(102).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(102).Visible = false;
            sprMefe_Sheet1.Columns.Get(103).CellType = textCellType76;
            sprMefe_Sheet1.Columns.Get(103).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(103).Label = "SPDP_APNT_TIME";
            sprMefe_Sheet1.Columns.Get(103).Tag = "SPDP_APNT_TIME";
            sprMefe_Sheet1.Columns.Get(103).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(103).Visible = false;
            sprMefe_Sheet1.Columns.Get(104).CellType = textCellType77;
            sprMefe_Sheet1.Columns.Get(104).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(104).Label = "EXAP_MARK_CNTS";
            sprMefe_Sheet1.Columns.Get(104).Tag = "EXAP_MARK_CNTS";
            sprMefe_Sheet1.Columns.Get(104).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(104).Visible = false;
            sprMefe_Sheet1.Columns.Get(105).CellType = textCellType78;
            sprMefe_Sheet1.Columns.Get(105).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(105).Label = "SUPT_DEPT_RCPN_DT";
            sprMefe_Sheet1.Columns.Get(105).Tag = "SUPT_DEPT_RCPN_DT";
            sprMefe_Sheet1.Columns.Get(105).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(105).Visible = false;
            sprMefe_Sheet1.Columns.Get(106).CellType = textCellType79;
            sprMefe_Sheet1.Columns.Get(106).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(106).Label = "SUPT_DEPT_RCPS_ID";
            sprMefe_Sheet1.Columns.Get(106).Tag = "SUPT_DEPT_RCPS_ID";
            sprMefe_Sheet1.Columns.Get(106).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(106).Visible = false;
            sprMefe_Sheet1.Columns.Get(107).CellType = textCellType80;
            sprMefe_Sheet1.Columns.Get(107).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(107).Label = "SPDP_ACTR_ID";
            sprMefe_Sheet1.Columns.Get(107).Tag = "SPDP_ACTR_ID";
            sprMefe_Sheet1.Columns.Get(107).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(107).Visible = false;
            sprMefe_Sheet1.Columns.Get(108).CellType = textCellType81;
            sprMefe_Sheet1.Columns.Get(108).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(108).Label = "PHTG_YN";
            sprMefe_Sheet1.Columns.Get(108).Tag = "PHTG_YN";
            sprMefe_Sheet1.Columns.Get(108).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(108).Visible = false;
            sprMefe_Sheet1.Columns.Get(109).CellType = textCellType82;
            sprMefe_Sheet1.Columns.Get(109).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(109).Label = "PHTG_RGST_DT";
            sprMefe_Sheet1.Columns.Get(109).Tag = "PHTG_RGST_DT";
            sprMefe_Sheet1.Columns.Get(109).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(109).Visible = false;
            sprMefe_Sheet1.Columns.Get(110).CellType = textCellType83;
            sprMefe_Sheet1.Columns.Get(110).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(110).Label = "PHTG_RGST_ID";
            sprMefe_Sheet1.Columns.Get(110).Tag = "PHTG_RGST_ID";
            sprMefe_Sheet1.Columns.Get(110).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(110).Visible = false;
            sprMefe_Sheet1.Columns.Get(111).CellType = textCellType84;
            sprMefe_Sheet1.Columns.Get(111).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(111).Label = "RSLT_YN";
            sprMefe_Sheet1.Columns.Get(111).Tag = "RSLT_YN";
            sprMefe_Sheet1.Columns.Get(111).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(111).Visible = false;
            sprMefe_Sheet1.Columns.Get(112).CellType = textCellType85;
            sprMefe_Sheet1.Columns.Get(112).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(112).Label = "RSLT_RGST_DT";
            sprMefe_Sheet1.Columns.Get(112).Tag = "RSLT_RGST_DT";
            sprMefe_Sheet1.Columns.Get(112).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(112).Visible = false;
            sprMefe_Sheet1.Columns.Get(113).CellType = textCellType86;
            sprMefe_Sheet1.Columns.Get(113).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(113).Label = "RSLT_RGSTR_ID";
            sprMefe_Sheet1.Columns.Get(113).Tag = "RSLT_RGSTR_ID";
            sprMefe_Sheet1.Columns.Get(113).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(113).Visible = false;
            sprMefe_Sheet1.Columns.Get(114).CellType = textCellType87;
            sprMefe_Sheet1.Columns.Get(114).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(114).Label = "RSLT_DFNT_DT";
            sprMefe_Sheet1.Columns.Get(114).Tag = "RSLT_DFNT_DT";
            sprMefe_Sheet1.Columns.Get(114).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(114).Visible = false;
            sprMefe_Sheet1.Columns.Get(115).CellType = textCellType88;
            sprMefe_Sheet1.Columns.Get(115).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(115).Label = "RSLT_SPFR_ID";
            sprMefe_Sheet1.Columns.Get(115).Tag = "RSLT_SPFR_ID";
            sprMefe_Sheet1.Columns.Get(115).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(115).Visible = false;
            sprMefe_Sheet1.Columns.Get(116).CellType = textCellType89;
            sprMefe_Sheet1.Columns.Get(116).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(116).Label = "MDED_REFR_YN";
            sprMefe_Sheet1.Columns.Get(116).Tag = "MDED_REFR_YN";
            sprMefe_Sheet1.Columns.Get(116).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(116).Visible = false;
            sprMefe_Sheet1.Columns.Get(117).CellType = textCellType90;
            sprMefe_Sheet1.Columns.Get(117).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(117).Label = "DRST_SPCL_APLY_YN";
            sprMefe_Sheet1.Columns.Get(117).Tag = "DRST_SPCL_APLY_YN";
            sprMefe_Sheet1.Columns.Get(117).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(117).Visible = false;
            sprMefe_Sheet1.Columns.Get(118).CellType = textCellType91;
            sprMefe_Sheet1.Columns.Get(118).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(118).Label = "INSL_DODY";
            sprMefe_Sheet1.Columns.Get(118).Tag = "INSL_DODY";
            sprMefe_Sheet1.Columns.Get(118).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(118).Visible = false;
            sprMefe_Sheet1.Columns.Get(119).CellType = textCellType92;
            sprMefe_Sheet1.Columns.Get(119).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(119).Label = "MLAP_PRSC_YN";
            sprMefe_Sheet1.Columns.Get(119).Tag = "MLAP_PRSC_YN";
            sprMefe_Sheet1.Columns.Get(119).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(119).Visible = false;
            sprMefe_Sheet1.Columns.Get(120).CellType = textCellType93;
            sprMefe_Sheet1.Columns.Get(120).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(120).Label = "PRSC_APLY_CMHS_NO";
            sprMefe_Sheet1.Columns.Get(120).Tag = "PRSC_APLY_CMHS_NO";
            sprMefe_Sheet1.Columns.Get(120).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(120).Visible = false;
            sprMefe_Sheet1.Columns.Get(121).CellType = textCellType94;
            sprMefe_Sheet1.Columns.Get(121).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(121).Label = "PRSC_LAST_DD";
            sprMefe_Sheet1.Columns.Get(121).Tag = "PRSC_LAST_DD";
            sprMefe_Sheet1.Columns.Get(121).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(121).Visible = false;
            sprMefe_Sheet1.Columns.Get(122).CellType = textCellType95;
            sprMefe_Sheet1.Columns.Get(122).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(122).Label = "DUR_RESN";
            sprMefe_Sheet1.Columns.Get(122).Tag = "DUR_RESN";
            sprMefe_Sheet1.Columns.Get(122).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(122).Visible = false;
            sprMefe_Sheet1.Columns.Get(123).CellType = textCellType96;
            sprMefe_Sheet1.Columns.Get(123).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(123).Label = "SPLN_MDTR_DVCD";
            sprMefe_Sheet1.Columns.Get(123).Tag = "SPLN_MDTR_DVCD";
            sprMefe_Sheet1.Columns.Get(123).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(123).Visible = false;
            sprMefe_Sheet1.Columns.Get(124).CellType = textCellType97;
            sprMefe_Sheet1.Columns.Get(124).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(124).Label = "SPLN_MFMT_BNOT_VOL";
            sprMefe_Sheet1.Columns.Get(124).Tag = "SPLN_MFMT_BNOT_VOL";
            sprMefe_Sheet1.Columns.Get(124).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(124).Visible = false;
            sprMefe_Sheet1.Columns.Get(125).CellType = textCellType98;
            sprMefe_Sheet1.Columns.Get(125).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(125).Label = "ORMD_ANS_YN";
            sprMefe_Sheet1.Columns.Get(125).Tag = "ORMD_ANS_YN";
            sprMefe_Sheet1.Columns.Get(125).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(125).Visible = false;
            sprMefe_Sheet1.Columns.Get(126).CellType = textCellType99;
            sprMefe_Sheet1.Columns.Get(126).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(126).Label = "ORMD_ANS_CD";
            sprMefe_Sheet1.Columns.Get(126).Tag = "ORMD_ANS_CD";
            sprMefe_Sheet1.Columns.Get(126).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(126).Visible = false;
            sprMefe_Sheet1.Columns.Get(127).CellType = textCellType100;
            sprMefe_Sheet1.Columns.Get(127).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(127).Label = "ORMD_ANS_NM";
            sprMefe_Sheet1.Columns.Get(127).Tag = "ORMD_ANS_NM";
            sprMefe_Sheet1.Columns.Get(127).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(127).Visible = false;
            sprMefe_Sheet1.Columns.Get(128).CellType = textCellType101;
            sprMefe_Sheet1.Columns.Get(128).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(128).Label = "ORMD_SITE_APLY_YN";
            sprMefe_Sheet1.Columns.Get(128).Tag = "ORMD_SITE_APLY_YN";
            sprMefe_Sheet1.Columns.Get(128).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(128).Visible = false;
            sprMefe_Sheet1.Columns.Get(129).CellType = textCellType102;
            sprMefe_Sheet1.Columns.Get(129).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(129).Label = "ORMD_SITE_APLY_CD";
            sprMefe_Sheet1.Columns.Get(129).Tag = "ORMD_SITE_APLY_CD";
            sprMefe_Sheet1.Columns.Get(129).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(129).Visible = false;
            sprMefe_Sheet1.Columns.Get(130).CellType = numberCellType8;
            sprMefe_Sheet1.Columns.Get(130).Label = "DC_PRSC_QTY";
            sprMefe_Sheet1.Columns.Get(130).Tag = "DC_PRSC_QTY";
            sprMefe_Sheet1.Columns.Get(130).Visible = false;
            sprMefe_Sheet1.Columns.Get(131).Label = "ORIG_PRSC_DVCD";
            sprMefe_Sheet1.Columns.Get(131).Tag = "ORIG_PRSC_DVCD";
            sprMefe_Sheet1.Columns.Get(131).Visible = false;
            sprMefe_Sheet1.Columns.Get(132).CellType = textCellType103;
            sprMefe_Sheet1.Columns.Get(132).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(132).Label = "ETC_USE_CNTS_1";
            sprMefe_Sheet1.Columns.Get(132).Tag = "ETC_USE_CNTS_1";
            sprMefe_Sheet1.Columns.Get(132).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(132).Visible = false;
            sprMefe_Sheet1.Columns.Get(133).CellType = textCellType104;
            sprMefe_Sheet1.Columns.Get(133).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(133).Label = "ETC_USE_CNTS_2";
            sprMefe_Sheet1.Columns.Get(133).Tag = "ETC_USE_CNTS_2";
            sprMefe_Sheet1.Columns.Get(133).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(133).Visible = false;
            sprMefe_Sheet1.Columns.Get(134).CellType = textCellType105;
            sprMefe_Sheet1.Columns.Get(134).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(134).Label = "ETC_USE_CNTS_3";
            sprMefe_Sheet1.Columns.Get(134).Tag = "ETC_USE_CNTS_3";
            sprMefe_Sheet1.Columns.Get(134).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(134).Visible = false;
            sprMefe_Sheet1.Columns.Get(135).CellType = textCellType106;
            sprMefe_Sheet1.Columns.Get(135).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(135).Label = "ETC_USE_CNTS_4";
            sprMefe_Sheet1.Columns.Get(135).Tag = "ETC_USE_CNTS_4";
            sprMefe_Sheet1.Columns.Get(135).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(135).Visible = false;
            sprMefe_Sheet1.Columns.Get(136).CellType = textCellType107;
            sprMefe_Sheet1.Columns.Get(136).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(136).Label = "ETC_USE_CNTS_5";
            sprMefe_Sheet1.Columns.Get(136).Tag = "ETC_USE_CNTS_5";
            sprMefe_Sheet1.Columns.Get(136).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(136).Visible = false;
            sprMefe_Sheet1.Columns.Get(137).CellType = textCellType108;
            sprMefe_Sheet1.Columns.Get(137).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(137).Label = "DLWT_IP_ADDR";
            sprMefe_Sheet1.Columns.Get(137).Tag = "DLWT_IP_ADDR";
            sprMefe_Sheet1.Columns.Get(137).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(137).Visible = false;
            sprMefe_Sheet1.Columns.Get(138).Label = "PYDS_ITCNR_ID";
            sprMefe_Sheet1.Columns.Get(138).Tag = "PYDS_ITCNR_ID";
            sprMefe_Sheet1.Columns.Get(138).Visible = false;
            sprMefe_Sheet1.Columns.Get(139).Label = "PYDS_ITCN_DT";
            sprMefe_Sheet1.Columns.Get(139).Tag = "PYDS_ITCN_DT";
            sprMefe_Sheet1.Columns.Get(139).Visible = false;
            sprMefe_Sheet1.Columns.Get(140).Label = "PYDS_ITCN_CNFR_YN";
            sprMefe_Sheet1.Columns.Get(140).Tag = "PYDS_ITCN_CNFR_YN";
            sprMefe_Sheet1.Columns.Get(140).Visible = false;
            sprMefe_Sheet1.Columns.Get(141).Label = "PYDS_ITCN_CNFR_DT";
            sprMefe_Sheet1.Columns.Get(141).Tag = "PYDS_ITCN_CNFR_DT";
            sprMefe_Sheet1.Columns.Get(141).Visible = false;
            sprMefe_Sheet1.Columns.Get(142).CellType = textCellType109;
            sprMefe_Sheet1.Columns.Get(142).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(142).Label = "PRSC_INPT_DVCD";
            sprMefe_Sheet1.Columns.Get(142).Tag = "PRSC_INPT_DVCD";
            sprMefe_Sheet1.Columns.Get(142).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(142).Visible = false;
            sprMefe_Sheet1.Columns.Get(143).Label = "DEF_ROW";
            sprMefe_Sheet1.Columns.Get(143).Tag = "DEF_ROW";
            sprMefe_Sheet1.Columns.Get(143).Visible = false;
            sprMefe_Sheet1.Columns.Get(144).Label = "OLD_PRSC_CD";
            sprMefe_Sheet1.Columns.Get(144).Tag = "OLD_PRSC_CD";
            sprMefe_Sheet1.Columns.Get(144).Visible = false;
            sprMefe_Sheet1.Columns.Get(145).Label = "OLD_PRSC_NM";
            sprMefe_Sheet1.Columns.Get(145).Tag = "OLD_PRSC_NM";
            sprMefe_Sheet1.Columns.Get(145).Visible = false;
            sprMefe_Sheet1.Columns.Get(146).Label = "TITLECODE";
            sprMefe_Sheet1.Columns.Get(146).Tag = "TITLECODE";
            sprMefe_Sheet1.Columns.Get(146).Visible = false;
            sprMefe_Sheet1.Columns.Get(147).Label = "!POPUP_DVCD";
            sprMefe_Sheet1.Columns.Get(147).Tag = "POPUP_DVCD";
            sprMefe_Sheet1.Columns.Get(147).Visible = false;
            sprMefe_Sheet1.Columns.Get(148).Label = "!OPINION_SQNO";
            sprMefe_Sheet1.Columns.Get(148).Tag = "OPINION_SQNO";
            sprMefe_Sheet1.Columns.Get(148).Visible = false;
            sprMefe_Sheet1.Columns.Get(149).Label = "!MECO_DVCD";
            sprMefe_Sheet1.Columns.Get(149).Tag = "MECO_DVCD";
            sprMefe_Sheet1.Columns.Get(149).Visible = false;
            sprMefe_Sheet1.Columns.Get(150).Label = "!PRSC_INTP_NM";
            sprMefe_Sheet1.Columns.Get(150).Tag = "PRSC_INTP_NM";
            sprMefe_Sheet1.Columns.Get(150).Visible = false;
            sprMefe_Sheet1.Columns.Get(151).Label = "!PRSC_LCLS_NM";
            sprMefe_Sheet1.Columns.Get(151).Tag = "PRSC_LCLS_NM";
            sprMefe_Sheet1.Columns.Get(151).Visible = false;
            sprMefe_Sheet1.Columns.Get(152).Label = "!FILTER_COL";
            sprMefe_Sheet1.Columns.Get(152).Tag = "FILTER_COL";
            sprMefe_Sheet1.Columns.Get(152).Visible = false;
            sprMefe_Sheet1.Columns.Get(153).Label = "!SAME_ORDER";
            sprMefe_Sheet1.Columns.Get(153).Tag = "SAME_ORDER";
            sprMefe_Sheet1.Columns.Get(153).Visible = false;
            sprMefe_Sheet1.Columns.Get(154).Label = "!보험100본인부담코드";
            sprMefe_Sheet1.Columns.Get(154).Tag = "I100_USCH_CD";
            sprMefe_Sheet1.Columns.Get(154).Visible = false;
            sprMefe_Sheet1.Columns.Get(155).CellType = textCellType110;
            sprMefe_Sheet1.Columns.Get(155).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(155).Label = "!HGRS_MDPR_DVCD";
            sprMefe_Sheet1.Columns.Get(155).Tag = "HGRS_MDPR_DVCD";
            sprMefe_Sheet1.Columns.Get(155).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(155).Visible = false;
            sprMefe_Sheet1.Columns.Get(156).CellType = textCellType111;
            sprMefe_Sheet1.Columns.Get(156).HorizontalAlignment = CellHorizontalAlignment.Left;
            sprMefe_Sheet1.Columns.Get(156).Label = "!HGAL_MDPR_DVCD";
            sprMefe_Sheet1.Columns.Get(156).Tag = "HGAL_MDPR_DVCD";
            sprMefe_Sheet1.Columns.Get(156).VerticalAlignment = CellVerticalAlignment.Center;
            sprMefe_Sheet1.Columns.Get(156).Visible = false;
            lxSplitContainer1.TabIndex = 6;
            // txtMefeSearch
            txtMefeSearch.Name = "txtMefeSearch";
            txtMefeSearch.TabIndex = 2;
}


    
        // #region Define : Member

        let m_PID:string = String.Empty;     // 환자번호
        let m_PT_CMHS_NO:string = String.Empty;     // 환자내원번호
        let m_MDCR_DD:string = String.Empty;     // 처방일자
        let m_MDCR_DEPT_CD:string = String.Empty;     // 진료부서
        let m_MDCR_DR_CD:string = String.Empty;     // 진료의
        let m_INSN_TYCD:string = String.Empty;     // 보험유형
        let m_ASST_TYCD:string = String.Empty;     // 유형보조
        let m_FRVS_RVST_DVCD:string = String.Empty;     // 초진재진구분
        let m_OTPT_ADMS_DVCD:string = String.Empty;     // 외입구분
        let m_ADMS_DD:string = String.Empty;     // 입원일자
        let m_DSCH_DD:string = String.Empty;     // 퇴원일자
        let m_WARD_CD:string = String.Empty;     // 병동구분
        let m_STHS_DSCH_DVCD:string = String.Empty;     // 주입원구분
        let m_ROOM_CD:string = String.Empty;     // 병실
        let m_DRG_YN:string = String.Empty;     // DRG구분
        let m_RCPN_SQNO:string = String.Empty;     // 내원일련번호
        let m_FEMME_PID:string = String.Empty;     // 임부여부
        let m_MAIN_SUB_ADMS_DVCD:string = String.Empty;

        private Font m_Boldfont = new Font("맑은 고딕", 10F, FontStyle.Bold);

        // 처방 스프레드 작동설정
        let m_MouseOrKeyBoardArrow:boolean = false;
        let m_Mefe_AutoComplete:boolean = false;             // 처방 자동완성기능 사용여부
        let m_SelectionDvcd:boolean = false;            // Selection 구분

        // 처방 클래스 생성
        private clsEntryOrder m_EntryOrder = new clsEntryOrder();

        public delegate void popDschRecEntryOrder_Calculate();
        public event popDschRecEntryOrder_Calculate OnpopDschRecEntryOrder_Calculate;

        let m_IsSaved:boolean = false;
        const IsSaved = $computed({
          get()  { return m_IsSaved; }, 
          set(value: any)  { m_IsSaved = value; }
        });

        // #endregion Define : Member

        // #region Construction

        constructor()
        {
            InitializeComponent();
        }

        constructor(pid:string, pt_cmhs_no:string, mdcr_dd:string, otpt_adms_dvcd:string)
            : this()
        {
            m_PID = pid;
            m_PT_CMHS_NO = pt_cmhs_no;
            m_MDCR_DD = mdcr_dd;
            m_OTPT_ADMS_DVCD = otpt_adms_dvcd;
        }

        // #endregion Construction

        // #region Screen Load

        const OnLoad = () => 
        {
             // base.OnLoad(e);

            if (DesignMode)
                return;

            Initialize();
            InitializeEvent();
            InitializeControl();

            SelectData();
        }

        // #endregion Screen Load

        // #region Method : Initialize Method

        const Initialize = () => 
        {
            try
            {
                txtPid.Text = m_PID;
                dteMdcrDate.Text = m_MDCR_DD;

                if (!this.PatientInfo.Load(m_PID))
                    throw new Error($"인적정보를 조회하는 중 에러가 발생했습니다.\r\n  - 환자번호 : {m_PID}");

                let sqltext:string = m_OTPT_ADMS_DVCD.Equals("O") ? SQL.OR.Sql.SelectOPPatientInfoO() : SQL.OR.Sql.SelectOPPatientInfoI();

                // 외래는 처방일자 수정 불가.
                dteMdcrDate.ReadOnly = m_OTPT_ADMS_DVCD.Equals("O");

                let dt:DataTable = new DataTable();
                if (!await DBService.ExecuteDataTable(sqltext, /*ref*/ dt, m_PID, m_PT_CMHS_NO, PatientInfo.SRRN_ECPT, m_MDCR_DD))
                    throw new Error("환자의 외래/입원 정보를 조회하는 중 에러가 발생했습니다.");

                if (dt.Rows.Count.Equals(0))
                {
                    await LxMessage.ShowError("환자의 외래/입원 정보를 조회하는 중 에러가 발생했습니다.\r\n외래/입원 정보가 존재하지 않습니다.");
                    return;
                }

                txtPtNm.Text = dt.Rows[0]["PT_NM"].ToString();
                m_MDCR_DEPT_CD = dt.Rows[0]["MDCR_DEPT_CD"].ToString();
                m_MDCR_DR_CD = dt.Rows[0]["MDCR_DR_CD"].ToString();
                m_INSN_TYCD = dt.Rows[0]["INSN_TYCD"].ToString();
                m_ASST_TYCD = dt.Rows[0]["ASST_TYCD"].ToString();

                if (m_OTPT_ADMS_DVCD == "O")
                {
                    m_FRVS_RVST_DVCD = dt.Rows[0]["FRVS_RVST_DVCD"].ToString();
                }
                else if (m_OTPT_ADMS_DVCD == "I")
                {
                    m_ADMS_DD = dt.Rows[0]["ADMS_DD"].ToString();
                    m_DSCH_DD = dt.Rows[0]["DSCH_DD"].ToString();
                    m_WARD_CD = dt.Rows[0]["WARD_CD"].ToString();
                    m_STHS_DSCH_DVCD = dt.Rows[0]["STHS_DSCH_DVCD"].ToString();
                    m_ROOM_CD = dt.Rows[0]["ROOM_CD"].ToString();
                    m_DRG_YN = dt.Rows[0]["DRG_YN"].ToString();
                    m_RCPN_SQNO = dt.Rows[0]["RCPN_SQNO"].ToString();
                    m_FEMME_PID = dt.Rows[0]["FEMME_PID"].ToString();
                    m_MAIN_SUB_ADMS_DVCD = dt.Rows[0]["MAIN_SUB_ADMS_DVCD"].ToString();
                }
            }
            catch (ex)
            {
                let error:string = DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                await LxMessage.ShowError(ex.Message + error);
            }
        }

        const InitializeEvent = () => 
        {
            // 처방정보
            sprMefe.MouseDown += sprMefe_MouseDown;
            sprMefe.ChangeExpand += sprMefe_ChangeExpand;
            sprMefe.EnterCell += sprMefe_EnterCell;
            sprMefe.CellClick += sprMefe_CellClick;
            sprMefe.ButtonClicked += sprMefe_ButtonClicked;
            sprMefe.DialogKey += sprMefe_DialogKey;
            sprMefe.CellDoubleClick += sprMefe_CellDoubleClick;
            sprMefe.TextTipFetch += sprMefe_TextTipFetch;
            sprMefe.SelectionChanged += sprMefe_SelectionChanged;
            sprMefe.SelectionChanging += sprMefe_SelectionChanging;
            sprMefe.EditModeOn += sprMefe_EditModeOn;
            sprMefe.EditModeOff += sprMefe_EditModeOff;

            ucMefeAutoComplete1.OnSetMefeData += ucMefeAutoComplete1_OnSetMefeData;
            ucMefeAutoComplete1.OnSetClose += ucMefeAutoComplete1_OnSetClose;

            txtMefeSearch.KeyDown += txtMefeSearch_KeyDown;

            sprMefeInfo.CellDoubleClick += sprMefeInfo_CellDoubleClick;

            lxButtonList1.ButtonClick += btnButtonList_ButtonClick;

            // Context 메뉴
            ContextMenuClick += ucfMfefCdE_ContextMenuClick;
            dteMdcrDate.ValueChanged += (s, e) =>
            {
                if (!m_DSCH_DD.Equals("29991231") && dteMdcrDate.DateTime > DateTimeService.ConvertDateTime(m_DSCH_DD))
                {
                    await LxMessage.ShowError("처방일자가 퇴원일자보다 미래일 수 없습니다.");
                    return;
                }

                if (dteMdcrDate.DateTime < DateTimeService.ConvertDateTime(m_ADMS_DD))
                {
                    await LxMessage.ShowError("처방일자가 입원일자보다 과거일 수 없습니다.");
                    return;
                }

                if (dteMdcrDate.IsDateValid)
                    SelectData();

                // 퇴원일자가 정해졌는데 퇴원일자 외의 처방을 수정하려고 하는 경우는, 불가 메시지를 띄운다.
                if (await ConfigService.GetConfigValueDirect("PA", "RECEIPT_DSCH", "SAVE_PRSC_ONLY_DSCH_DD", false))
                {
                    if (m_DSCH_DD != "29991231" && m_DSCH_DD != dteMdcrDate.DateTime.ToString("yyyyMMdd") &&
                        !clsNRCommon.CheckSaveData_PAAREBMA(m_PID, m_PT_CMHS_NO, dteMdcrDate.DateTime.ToString("yyyyMMdd"), true))
                    {
                        return;
                    }
                }
            };
        }

        const InitializeControl = () => 
        {
            sprMefe.EditModePermanent = false;
            sprMefeInfo.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.ExtendedSelect;

            m_Mefe_AutoComplete = DOPack.UserInfo.UserConfig.GetConfigValue("PRSC_AUTO_COMPLETE", "USE_YN").ToString().Equals("Y");

            ucMefeAutoComplete1.Search_Row_Count = 10;
            ucMefeAutoComplete1.Mefe_AutoComplete = m_Mefe_AutoComplete;
            ucMefeAutoComplete1.Height = 305;

            sprMefe.SetComboItems("PRSC_DVCD", await OverallCodeList.GetDataList("OPRSC_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.None);
            sprMefe.SetComboItems("PNPY_DVCD", await OverallCodeList.GetDataList("PAY_NOPY_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.None);
            sprMefe.SetComboItems("AOMD_VLCT_VALU", await OverallCodeList.GetDataList("AOMD_VLCT_VALU"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.AddNone);
            sprMefe.SetComboItems("PYDS_ITCN_DEPT_CD", await ClinicList.GetDataList(), "DEPT_CD", "DEPT_HNM", COMBO_ADD_ITEM_TYPE.AddNone);
            sprMefe.SetComboItems("RGSTR_ID", await UserList.GetDataList(), "USER_CD", "USER_NM", COMBO_ADD_ITEM_TYPE.AddNone);
            sprMefe.SetComboItems("UPDTR_ID", await UserList.GetDataList(), "USER_CD", "USER_NM", COMBO_ADD_ITEM_TYPE.AddNone);
            sprMefe.SetComboItems("PCUP_TGPS_ID", await UserList.GetDataList(), "USER_CD", "USER_NM", COMBO_ADD_ITEM_TYPE.AddNone);

            // RowHeight
            sprMefe.ActiveSheet.SetRowHeight(0, 20);
            sprMefe.ActiveSheet.ColumnHeader.Rows[0].Height = 20;

            sprMefe.SelectionBlockOptions = SelectionBlockOptions.Cells | SelectionBlockOptions.Columns | SelectionBlockOptions.Rows;
            sprMefe.ActiveSheet.OperationMode = OperationMode.Normal;
            sprMefe.ActiveSheet.SelectionPolicy = SelectionPolicy.Range;
            sprMefe.ActiveSheet.SelectionUnit = SelectionUnit.Row;
            sprMefe.ActiveSheet.SelectionStyle = SelectionStyles.SelectionRenderer;

            sprMefe.ActiveSheet.FrozenColumnCount = sprMefe.GetTagToColumnIndex("FLAG");

            sprMefe.ActiveSheet.AlternatingRows.Get(1).ResetBackColor();

            sprMefe.ActiveSheet.Columns["EXCP_RESN_CD"].Visible = false;

            lxButtonList1.ButtonItems.Clear();
            lxButtonList1.ButtonItems.Add(ButtonType.Select, "조 회", "Select");
            lxButtonList1.ButtonItems.Add(ButtonType.Delete, "삭 제", "Delete");
            lxButtonList1.ButtonItems.Add(ButtonType.Custom1, "D/C", "Custom1");
            lxButtonList1.ButtonItems.Add(ButtonType.Save, "저 장", "Save");
            if (m_OTPT_ADMS_DVCD == "I")
                lxButtonList1.ButtonItems.Add(ButtonType.Custom2, "계 산", "Custom2", Color.Red, Color.White);
            lxButtonList1.ButtonItems.Add(ButtonType.Close, "닫 기", "Close");
            lxButtonList1.InitializeButtons();
        }

        // #endregion Method : Initialize Method

        // #region Method : Private Method

        const SelectData = () => 
        {
            // 수가마스터 조회
            SelectBIMFCDMA();

            // 처방내역 조회
            SelectORORDRRT();
        }

        const SelectBIMFCDMA = () => 
        {
            try
            {
                sprMefeInfo.ActiveSheet.Rows.Count = 0;

                let dt:DataTable = new DataTable();
                if (!await DBService.ExecuteDataTable(SQL.PA.Sql.SelectCertificateBIMFCDMA(), /*ref*/ dt, m_MDCR_DD, "Z2", "Z1"))
                    throw new Error("진단서 수가를 조회하는 중 에러가 발생했습니다.");

                sprMefeInfo.FillDataTag(dt);

                if (sprMefeInfo.ActiveSheet.RowCount > 0)
                    sprMefeInfo.ActiveSheet.AddSelection(0, 0, 1, sprMefeInfo.ActiveSheet.ColumnCount);
            }
            catch (ex)
            {
                let error:string = DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                await LxMessage.ShowError(ex.Message + error);
            }
        }

        const SelectORORDRRT = () => 
        {
            try
            {
                m_MDCR_DD = dteMdcrDate.Text.Replace("-", String.Empty);

                sprMefe.ActiveSheet.Rows.Count = 0;

                let use_mcls_yn:string = await ConfigService.GetConfigValueDirect("OR", "SELECT_OPTION", "USE_YN", "N");

                let sqltext:string = use_mcls_yn == "M" ?
                                    String.Format(SQL.OR.Sql.SelectORORDRRT_Main_Not_Mcls(), m_PID, m_PT_CMHS_NO, m_MDCR_DD, m_INSN_TYCD, m_ASST_TYCD) + " AND A.PRSC_LCLS_CD = 'Z2' AND A.PRSC_MCLS_CD = 'Z1' " :
                                 use_mcls_yn == "N" ?
                                    String.Format(SQL.OR.Sql.SelectORORDRRT_Title(), m_PID, m_PT_CMHS_NO, m_MDCR_DD, m_INSN_TYCD, m_ASST_TYCD) + " AND A.PRSC_LCLS_CD = 'Z2' AND A.PRSC_MCLS_CD = 'Z1' " : String.Empty;

                if (String.IsNullOrWhiteSpace(sqltext))
                {
                    await LxMessage.ShowError("잘 못된 접근입니다.\r\n옵션 조회 중 에러가 발생했습니다.");
                    return;
                }    

                let dt:DataTable = new DataTable();
                if (!await DBService.ExecuteDataTable(sqltext, /*ref*/ dt))
                    throw new Error("처방내역 조회 중 에러가 발생했습니다.");

                sprMefe.FillDataTag(dt);

                // 외래 및 입원에 따른 칼럼 Visible 처리
                if (m_OTPT_ADMS_DVCD == "O")
                {
                    sprMefe.ActiveSheet.Columns["TEL_PRSC_FLAG"].Visible = false;
                    sprMefe.ActiveSheet.Columns["EXCP_RESN_CD"].Visible = true;
                    sprMefe.ActiveSheet.Columns["PNOD_PRSC_PSND"].Visible = false;
                    sprMefe.ActiveSheet.Columns["PNOD_PRSC_INOD"].Visible = false;
                    sprMefe.ActiveSheet.Columns["PCUP_DT"].Visible = false;
                    sprMefe.ActiveSheet.Columns["PCUP_TGPS_ID"].Visible = false;
                    sprMefe.ActiveSheet.Columns["SUB_ADMS_VIEW"].Visible = false;
                }
                else
                {
                    sprMefe.ActiveSheet.Columns["TEL_PRSC_FLAG"].Visible = true;
                    sprMefe.ActiveSheet.Columns["EXCP_RESN_CD"].Visible = false;
                    sprMefe.ActiveSheet.Columns["PNOD_PRSC_PSND"].Visible = true;
                    sprMefe.ActiveSheet.Columns["PNOD_PRSC_INOD"].Visible = true;
                    sprMefe.ActiveSheet.Columns["PCUP_DT"].Visible = true;
                    sprMefe.ActiveSheet.Columns["PCUP_TGPS_ID"].Visible = true;
                    sprMefe.ActiveSheet.Columns["SUB_ADMS_VIEW"].Visible = true;
                }

                SetTitleMefeData(sprMefe);

                ORBizCommon.SetOrderColor(sprMefe, m_PID, m_OTPT_ADMS_DVCD, m_PT_CMHS_NO);

                SetDefaultAppendRow(sprMefe, 100);
            }
            catch (ex)
            {
                let error:string = DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                await LxMessage.ShowError(ex.Message + error);
            }
        }

        /// <summary>
        /// 처방 Spread의 Title 설정한다.
        /// </summary>
        const SetTitleMefeData = (spr) => 
        {
            let PRSC_LCLS_CD:string = String.Empty;
            let PRSC_NM:string = String.Empty;
            let TITLECODE:string = String.Empty;
            let PRSC_INPT_DVCD:string = String.Empty;
            let ward_cd:string = String.Empty;
            let titleonum:number = 0;
            let titletnum:number = 0;

            for (let i:number = 0; i < spr.ActiveSheet.RowCount; i++)
            {
                TITLECODE = spr.GetValue(i, "TITLECODE").ToString();
                ward_cd = spr.GetValue(i, "WARD_CD").ToString();

                if (TITLECODE == "0")
                {
                    titleonum = 0;
                    titletnum = 0;
                }
                else
                {
                    // 2018-07-10 김남훈 병동 처방 구분으로 수정
                    if (!(PRSC_LCLS_CD == spr.GetValue(i, "PRSC_LCLS_CD").ToString()) || !(PRSC_INPT_DVCD == spr.GetValue(i, "PRSC_INPT_DVCD").ToString()))
                    {
                        if (PRSC_INPT_DVCD == "1" && m_OTPT_ADMS_DVCD == "I")
                        {
                            if (ward_cd == spr.GetValue(i, "WARD_CD").ToString())
                            {
                                PRSC_LCLS_CD = spr.GetValue(i, "PRSC_LCLS_CD").ToString();
                                PRSC_INPT_DVCD = spr.GetValue(i, "PRSC_INPT_DVCD").ToString();
                                titleonum++;
                                titletnum = 0;
                            }
                        }
                        else
                        {
                            PRSC_LCLS_CD = spr.GetValue(i, "PRSC_LCLS_CD").ToString();
                            PRSC_INPT_DVCD = spr.GetValue(i, "PRSC_INPT_DVCD").ToString();
                            titleonum++;
                            titletnum = 0;
                        }
                    }
                }

                switch (TITLECODE)
                {
                    case "0":
                        spr.SetText(i, "PRSC_NM", "         " + spr.GetValue(i, "PRSC_NM").ToString());
                        spr.ActiveSheet.Rows[i].Font = m_Boldfont;
                        spr.ActiveSheet.Rows[i].ForeColor = Color.FromArgb(42, 0, 102);
                        break;

                    case "1":
                        spr.SetText(i, "PRSC_NM", "    " + titleonum.ToString() + ". " + spr.GetValue(i, "PRSC_NM").ToString());
                        spr.ActiveSheet.Rows[i].Font = m_Boldfont;
                        spr.ActiveSheet.Rows[i].ForeColor = Color.Purple;
                        break;

                    case "2":
                        titletnum++;
                        spr.SetText(i, "PRSC_NM", titleonum.ToString() + "-" + titletnum.ToString() + ". " + spr.GetValue(i, "PRSC_NM").ToString());
                        spr.ActiveSheet.Rows[i].Font = m_Boldfont;
                        spr.ActiveSheet.Rows[i].ForeColor = Color.Blue;
                        break;

                    case "3":
                        continue;
                }
            }
        }

        /// <summary>
        /// 기본로우를 추가해준다.
        /// </summary>
        const SetDefaultAppendRow = (spr, count:number) => 
        {
            let activerow:number = spr.ActiveSheet.RowCount;

            spr.AppendRow(activerow - 1, count + activerow);

            for (let i:number = activerow; i < spr.ActiveSheet.RowCount; i++)
            {
                m_EntryOrder.SetDefaultData(spr, i, m_OTPT_ADMS_DVCD);
                spr.SetCRUDToRow(i, CRUD_TYPE.Create);
            }

            spr.SetActiveRow(0);
            spr.ShowRow(0, 0, VerticalPosition.Nearest);
            spr.ShowColumn(0, 0, HorizontalPosition.Nearest);
        }

        const SelectionClear = () => 
        {
            sprMefe.ActiveSheet.ClearSelection();
        }

        /// <summary>
        /// Row 추가 후 입력할 Row를 반환한다.
        /// </summary>
        /// <returns></returns>
        const GetAppendRow = (spr) => 
        {
            let row:number = 0;

            if (m_EntryOrder.GetRowCount(spr) <= 0)
            {
                if (spr.ActiveSheet.RowCount > 0)
                {
                    row = m_EntryOrder.GetFindAppendRow(spr);
                    spr.ShowRow(0, row, VerticalPosition.Nearest);
                    spr.ActiveSheet.AddSelection(row, 0, 1, spr.ActiveSheet.ColumnCount);
                }
                else
                {
                    m_EntryOrder.AppendData(spr, m_OTPT_ADMS_DVCD, -1);
                    row = spr.ActiveSheet.ActiveRowIndex;
                    spr.ShowRow(0, row, VerticalPosition.Nearest);
                    spr.ActiveSheet.AddSelection(row, 0, 1, spr.ActiveSheet.ColumnCount);
                }
            }
            else
            {
                row = m_EntryOrder.GetFindAppendRow(spr);

                if (row >= 0)
                {
                    spr.SetActiveRow(row);
                    spr.ShowRow(0, row, VerticalPosition.Nearest);
                    spr.ActiveSheet.AddSelection(row, 0, 1, spr.ActiveSheet.ColumnCount);
                }
                else
                {
                    if (spr.ActiveSheet.RowCount > 0)
                        spr.SetActiveRow(spr.ActiveSheet.RowCount - 1);

                    m_EntryOrder.AppendData(spr, m_OTPT_ADMS_DVCD, spr.ActiveSheet.RowCount - 1);
                    row = spr.ActiveSheet.ActiveRowIndex;
                    spr.ShowRow(0, row, VerticalPosition.Nearest);
                    spr.ActiveSheet.AddSelection(row, 0, 1, spr.ActiveSheet.ColumnCount);
                }
            }

            return row;
        }

        /// <summary>
        /// 지정 칼럼의 해당 Row를 OldValue로 설정한다.
        /// </summary>
        const SetRowOldValue = (spr, row:number, col:number) => 
        {
            for (let i:number = 0; i < spr.ActiveSheet.ColumnCount; i++)
            {
                if (spr.ActiveSheet.Columns[i].Tag.ToString() == "PRSC_CD" ||
                    spr.ActiveSheet.Columns[i].Tag.ToString() == "PRSC_NM" ||
                    spr.ActiveSheet.Columns[i].Tag.ToString() == "PRSC_LCLS_CD" ||
                    spr.ActiveSheet.Columns[i].Tag.ToString() == "PRSC_MCLS_CD" ||
                    spr.ActiveSheet.Columns[i].Tag.ToString() == "PRSC_CLSF_CD" ||
                    spr.ActiveSheet.Columns[i].Tag.ToString() == "AOMD_MTHD_CD" ||
                    spr.ActiveSheet.Columns[i].Tag.ToString() == "FREE_PRSC_CD" ||
                    spr.ActiveSheet.Columns[i].Tag.ToString() == "PRSC_INPT_QTY" ||
                    spr.ActiveSheet.Columns[i].Tag.ToString() == "ONTM_QTY" ||
                    spr.ActiveSheet.Columns[i].Tag.ToString() == "NOTM" ||
                    spr.ActiveSheet.Columns[i].Tag.ToString() == "NODY" ||
                    spr.ActiveSheet.Columns[i].Tag.ToString() == "MOVE_PHTG_YN" ||
                    spr.ActiveSheet.Columns[i].Tag.ToString() == "PWDR_YN")
                    spr.SetText(row, i, spr.GetOldValue(row, i).ToString());
            }

            spr.SetActiveRow(row);
            spr.SetActiveCell(row, col);
            spr.ShowRow(0, row, VerticalPosition.Nearest);
        }

        const SetMefeAutoCompleteView = (view:boolean) => 
        {
            ucMefeAutoComplete1.Visible = view;
        }

        const SetEnterCell = () => 
        {
            if (sprMefe.ActiveSheet.RowCount <= 0)
                return;

            sprMefe.EditModeReplace = true;

            let i:number = sprMefe.ActiveSheet.ActiveRowIndex;

            let prsc_cd:string = String.Empty;
            let prsc_nm:string = String.Empty;
            let tag:string = sprMefe.ActiveSheet.Columns.Get(sprMefe.ActiveSheet.ActiveColumnIndex).Tag.ToString();
            let titlecode:string = sprMefe.GetValue(i, "TITLECODE").ToString();
            let prsc_lcls_cd:string = sprMefe.GetValue(i, "PRSC_LCLS_CD").ToString();
            let dc_prsc_dvcd:string = sprMefe.GetValue(i, "DC_PRSC_DVCD").ToString();
            let prsc_search_language:string = DOPack.UserInfo.UserConfig.GetConfigValue("PRSC_SEARCH_LANGUAGE", "LANGUAGE").ToString();

            sprMefe.ImeMode = System.Windows.Forms.ImeMode.NoControl;

            if (m_Mefe_AutoComplete && ucMefeAutoComplete1.Visible == true)
            {
                if (tag == "PRSC_CD" || tag == "PRSC_NM")
                {
                    prsc_cd = sprMefe.GetValue(i, "PRSC_CD").ToString();
                    prsc_nm = sprMefe.GetValue(i, "PRSC_NM").ToString();

                    if (!String.IsNullOrWhiteSpace(prsc_cd) && !String.IsNullOrWhiteSpace(prsc_nm))
                        return;

                    // Row 초기화
                    SetRowOldValue(sprMefe, i, sprMefe.ActiveSheet.ActiveColumnIndex);

                    // 변경된 것은 다시 적용시켜준다.
                    if (sprMefe.GetCRUDFromRow() == CRUD_TYPE.Update)
                    {
                        ORBizCommon.SetRowMefeData(sprMefe, i);
                    }
                }
            }

            SetMefeAutoCompleteView(false);

            if (dc_prsc_dvcd == "D" || dc_prsc_dvcd == "F")
            {
                sprMefe.ActiveSheet.ActiveColumn.Locked = true;
                return;
            }

            if (titlecode == "0" || titlecode == "1" || titlecode == "2" || tag == "MSG_VIEW" || tag == "CTNT" || tag == "RSLT_DFNT_YN_VIEW" || tag == "SUPT_DEPT_RCPN_YN_VIEW")
            {
                if (tag == "FLAG" || tag == "PRSC_PCFT")
                    sprMefe.ActiveSheet.ActiveColumn.Locked = false;
                else
                    sprMefe.ActiveSheet.ActiveColumn.Locked = true;
            }
            else
            {
                if (tag == "FLAG")
                {
                    sprMefe.ActiveSheet.ActiveColumn.Locked = false;
                    return;
                }

                if (sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Create && (tag == "PRSC_CD" || tag == "PRSC_NM"))
                {
                    if (!String.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_CD").ToString()) && !String.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_NM").ToString()))
                        sprMefe.ActiveSheet.ActiveColumn.Locked = true;
                    else
                        sprMefe.ActiveSheet.ActiveColumn.Locked = false;
                }
                else
                    sprMefe.ActiveSheet.ActiveColumn.Locked = true;

                if (sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Create && (tag == "PRSC_INPT_QTY"))
                    sprMefe.ActiveSheet.ActiveColumn.Locked = false;
            }
        }

        /// <summary>
        /// 처방을 설정한다.
        /// </summary>
        /// <returns>(1)변경완료/(0)변경 실패, 포커스 이동 O/(-1)변경 실패, 포커스 이동 X</returns>
        const SetChangeMefeInfo = () => 
        {
            let PRSC_CD:string = String.Empty;
            let PRSC_NM:string = String.Empty;
            let OLD_PRSC_CD:string = String.Empty;
            let OLD_PRSC_NM:string = String.Empty;
            let getflag:boolean = false;
            let setflag:boolean = false;
            let errmsg:string = String.Empty;
            let data:string = String.Empty;
            let searchdata:string = String.Empty;
            let tag:string = sprMefe.ActiveSheet.Columns.Get(sprMefe.ActiveSheet.ActiveColumnIndex).Tag.ToString();

            let count:number = 0;

            let dt:DataTable = new DataTable();

            if (m_Mefe_AutoComplete && ucMefeAutoComplete1.Visible == true)
            {
                PRSC_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CD").ToString();
                PRSC_NM = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_NM").ToString();

                if (!String.IsNullOrWhiteSpace(PRSC_CD) && !String.IsNullOrWhiteSpace(PRSC_NM))
                    return 1;

                // Row 초기화
                SetRowOldValue(sprMefe, sprMefe.ActiveSheet.ActiveRowIndex, sprMefe.ActiveSheet.ActiveColumnIndex);

                // 변경된 것은 다시 적용시켜준다.
                if (sprMefe.GetCRUDFromRow() == CRUD_TYPE.Update)
                {
                    ORBizCommon.SetRowMefeData(sprMefe, sprMefe.ActiveSheet.ActiveRowIndex);
                }

                SetMefeAutoCompleteView(false);

                return 1;
            }

            if (sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "FREE_PRSC_CD").ToString() == "Y")
                return 1;

            PRSC_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CD").ToString();
            PRSC_NM = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_NM").ToString();

            if (sprMefe.GetCRUDFromRow() == CRUD_TYPE.Create || sprMefe.GetCRUDFromRow() == CRUD_TYPE.Update)
            {
                OLD_PRSC_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "OLD_PRSC_CD").ToString();
                OLD_PRSC_NM = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "OLD_PRSC_NM").ToString();
            }
            else
            {
                OLD_PRSC_CD = sprMefe.GetOldValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CD").ToString();
                OLD_PRSC_NM = sprMefe.GetOldValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_NM").ToString();
            }

            // 코드 및 명 바뀌었을 때
            if (!(PRSC_CD == OLD_PRSC_CD && PRSC_NM == OLD_PRSC_NM))
            {
                switch (tag)
                {
                    case "PRSC_CD":
                        // 코드가 널일때는 체크하지 않는다. 최종확인은 저장할 때
                        if (String.IsNullOrWhiteSpace(PRSC_CD))
                            return 1;

                        data = PRSC_CD;
                        searchdata = "%" + PRSC_CD + "%";
                        tag = "MEFE_CD";
                        break;

                    case "PRSC_NM":
                        // 명이 널일때는 체크하지 않는다. 최종확인은 저장할 때
                        if (String.IsNullOrWhiteSpace(PRSC_NM))
                            return 1;

                        data = PRSC_NM;
                        searchdata = "%" + PRSC_NM.ToUpper() + "%";
                        tag = "MEFE_INDX_NM";

                        break;
                }

                count = await DBService.ExecuteInteger(SQL.BI.Sql.SelectCountColumnBIMFCDMA(), tag
                                                                                       , searchdata
                                                                                       , m_OTPT_ADMS_DVCD
                                                                                       , m_MDCR_DD);

                switch (count)
                {
                    case 0:

                        errmsg = "해당 처방코드가 없습니다. 확인해주세요";
                        getflag = false;
                        break;

                    case 1:
                        // 한건이면 바로 조회
                        await DBService.ExecuteDataTable(SQL.BI.Sql.SelectColumnBIMFCDMA(), /*ref*/ dt
                                                                                    , tag
                                                                                    , searchdata
                                                                                    , m_OTPT_ADMS_DVCD
                                                                                    , m_MDCR_DD);

                        // 처방코드를 적용한다.
                        sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CD", dt.Rows[0]["MEFE_CD"].ToString());
                        getflag = true;
                        break;

                    default:
                        if (SetPopMefeInfo(tag, data, true, /*ref*/ errmsg))
                            getflag = true;
                        else
                        {
                            getflag = false;
                        }

                        break;
                }

                // 처방이 변경되었을 때
                if (getflag)
                {
                    if (CheckChangeMefeInfo())
                        setflag = true;
                    else
                        setflag = false;
                }

                // 처방 확인 중 오류
                if (!setflag)
                {
                    // Row 초기화
                    SetRowOldValue(sprMefe, sprMefe.ActiveSheet.ActiveRowIndex, sprMefe.ActiveSheet.ActiveColumnIndex);

                    // 변경된 것은 다시 적용시켜준다.
                    if (sprMefe.GetCRUDFromRow() == CRUD_TYPE.Update)
                    {
                        ORBizCommon.SetRowMefeData(sprMefe, sprMefe.ActiveSheet.ActiveRowIndex);
                    }

                    return -1;
                }
            }
            return 1;
        }

        /// <summary>
        /// 계산용량을 설정한다.
        /// </summary>
        /// <returns>(1)변경완료/(0)변경 실패, 포커스 이동 O/(-1)변경 실패, 포커스 이동 X</returns>
        const SetChangeInptQty = () => 
        {
            try
            {
                let PRSC_INPT_QTY:string = String.Empty;
                let PRSC_LCLS_CD:string = String.Empty;
                let PRSC_MCLS_CD:string = String.Empty;
                let PRSC_CLSF_CD:string = String.Empty;
                let PRSC_CD:string = String.Empty;
                let AOMD_MTHD_CD:string = String.Empty;
                let B_NOTM:string = String.Empty;
                let CTNT:number = decimal.Parse("1.0");
                let calc_init_qty:number = decimal.Parse("1.0");
                let NOTM:number = 0;
                let errmsg:string = String.Empty;
                let dt:DataTable = new DataTable();

                PRSC_INPT_QTY = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_INPT_QTY").ToString();
                PRSC_CLSF_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CLSF_CD").ToString();
                PRSC_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CD").ToString();
                PRSC_LCLS_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_LCLS_CD").ToString();
                PRSC_MCLS_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_MCLS_CD").ToString();
                B_NOTM = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "NOTM").ToString();

                if (PRSC_CLSF_CD == "1" || PRSC_CLSF_CD == "2" || PRSC_CLSF_CD == "3" || PRSC_CLSF_CD == "4")
                {
                    if (await DBService.ExecuteDataTable(SQL.BI.Sql.SelectColumnBIMFCDMA(), /*ref*/ dt
                                                                                    , "MEFE_CD"
                                                                                    , PRSC_CD
                                                                                    , "%"
                                                                                    , m_MDCR_DD))
                    {
                        if (dt.Rows.Count <= 0)
                        {
                            sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_INPT_QTY", "1");
                            sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "ONTM_QTY", "1");
                            return 0;
                        }

                        // 데이터테이블 정보 변수에 담는다.
                        for (let i:number = 0; i < dt.Columns.Count; i++)
                        {
                            switch (dt.Columns[i].ColumnName)
                            {
                                case "CTNT":
                                    CTNT = decimal.Parse(dt.Rows[0][i].ToString());
                                    break;
                            }
                        }
                    }
                    else
                    {
                        sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_INPT_QTY", "1");
                        sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "ONTM_QTY", "1");
                        return 0;
                    }

                    if (m_EntryOrder.CalcInptQty(PRSC_INPT_QTY, CTNT, /*ref*/ calc_init_qty, /*ref*/ NOTM, /*ref*/ errmsg))
                    {
                        sprMefe.SetValue(sprMefe.ActiveSheet.ActiveRowIndex, "ONTM_QTY", calc_init_qty);

                        if (NOTM >= 1)
                            sprMefe.SetValue(sprMefe.ActiveSheet.ActiveRowIndex, "NOTM", NOTM);


                        // 1회량이 1보다 클 때 투여방법 설정
                        if (calc_init_qty > 0 && NOTM > 0)
                        {
                            AOMD_MTHD_CD = ORBizCommon.GetDefaultMedicineUsage(PRSC_CD, m_MDCR_DD, NOTM);

                            if (!(String.IsNullOrWhiteSpace(AOMD_MTHD_CD)))
                                sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "AOMD_MTHD_CD", AOMD_MTHD_CD);
                            else
                                sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "AOMD_MTHD_CD", "");
                        }
                    }
                    else
                    {
                        await LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_INPT_QTY", "1");
                        sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "ONTM_QTY", "1");
                        return 0;
                    }
                }
                else
                {
                    if (await DBService.ExecuteDataTable(SQL.BI.Sql.SelectColumnBIMFCDMA(), /*ref*/ dt
                                                                                    , "MEFE_CD"
                                                                                    , PRSC_CD
                                                                                    , "%"
                                                                                    , m_MDCR_DD))
                    {
                        if (dt.Rows.Count <= 0)
                        {
                            sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_INPT_QTY", "1");
                            sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "ONTM_QTY", "1");
                            return 0;
                        }

                        // 데이터테이블 정보 변수에 담는다.
                        for (let i:number = 0; i < dt.Columns.Count; i++)
                        {
                            switch (dt.Columns[i].ColumnName)
                            {
                                case "CTNT":
                                    if (String.IsNullOrWhiteSpace(dt.Rows[0][i].ToString()))
                                        CTNT = 0;
                                    else
                                        CTNT = decimal.Parse(dt.Rows[0][i].ToString());
                                    break;
                            }
                        }
                    }
                    else
                    {
                        sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_INPT_QTY", "1");
                        sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "ONTM_QTY", "1");
                        return 0;
                    }

                    // 재료의 Cast만 / 처방 가능
                    //if((PRSC_INPT_QTY.IndexOf('/') >= 0) && PRSC_LCLS_CD + PRSC_MCLS_CD != "I015")
                    //{
                    //await LxMessage.Show("약/주사가 아닌 경우 재료의 Cast,Splint만 / 처방 가능합니다.");
                    //sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_INPT_QTY", "1");
                    //sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "ONTM_QTY", "1");
                    //return 0;
                    //}
                    // 2018-08-02 김남훈 함량 있는것만 / 처방 가능하도록
                    if (PRSC_INPT_QTY.IndexOf('/') >= 0 && (String.IsNullOrWhiteSpace(sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "CTNT").ToString()) || sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "CTNT").ToString() == "0"))
                    {
                        await LxMessage.Show("함량있는 경우만 / 처방 가능합니다.");
                        sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_INPT_QTY", "1");
                        sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "ONTM_QTY", "1");
                        return 0;
                    }

                    if (PRSC_INPT_QTY.IndexOf('/') > 0)
                    {
                        await LxMessage.Show("/ 다음에 정수 입력만 가능합니다.");
                        sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_INPT_QTY", "1");
                        sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "ONTM_QTY", "1");
                        return 0;
                    }

                    if (PRSC_INPT_QTY.IndexOf('/') >= 0)
                    {
                        if (m_EntryOrder.CalcInptQty(PRSC_INPT_QTY, CTNT, /*ref*/ calc_init_qty, /*ref*/ NOTM, /*ref*/ errmsg))
                        {
                            sprMefe.SetValue(sprMefe.ActiveSheet.ActiveRowIndex, "ONTM_QTY", calc_init_qty);
                        }
                        else
                        {
                            await LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_INPT_QTY", "1");
                            sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "ONTM_QTY", "1");
                            return 0;
                        }
                    }
                    else
                        sprMefe.SetValue(sprMefe.ActiveSheet.ActiveRowIndex, "ONTM_QTY", PRSC_INPT_QTY);
                }

                return 1;
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                return 0;
            }
        }

        /// <summary>
        /// 처방조회 화면을 띄운다.
        /// </summary>
        /// <param name="col"></param>
        /// <param name="data"></param>
        /// <param name="errmsg"></param>
        /// <returns></returns>
        const SetPopMefeInfo = (col:string, data:string, setflag:boolean, /*ref*/ string errmsg) => 
        {
            popSearchMefe pop = null;
            Point poppoint = new Point();
            let dt:DataTable = new DataTable();

            if (setflag)
            {
                pop = new popSearchMefe(col, data, m_OTPT_ADMS_DVCD, true);
                if (pop.ShowDialog() == DialogResult.OK)
                {
                    // 코드만 설정한다. 코드를 불러와 설정.
                    sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CD", pop.MEFE_CD);
                }
                else
                {
                    errmsg = "처방을 선택 해 주세요.";
                    pop.Dispose();
                    return false;
                }

                pop.Dispose();
            }
            else
            {
                //pop = new popSearchMefe("%", false);
                //pop.OnSetData += pop_OnSetData;
                //poppoint = new Point((Width - pop.Width) <= 0 ? 0 : Width - pop.Width, (TopLevelControl.Height - pop.Height) <= 0 ? 0 : TopLevelControl.Height - pop.Height);
                //pop.SetLocation(poppoint);
                //pop.ShowDialog();
            }
            pop.Dispose();
            return true;
        }

        /// <summary>
        /// 해당 Row를 클리어한다.
        /// </summary>
        const SetRowClear = (spr, row:number) => 
        {
            for (let i:number = 0; i < spr.ActiveSheet.ColumnCount; i++)
            {
                spr.SetText(row, i, "");
            }

            m_EntryOrder.SetDefaultData(spr, row, m_OTPT_ADMS_DVCD);

            spr.SetActiveRow(row);
            spr.ShowRow(0, row, VerticalPosition.Nearest);
        }


        const SetOrderCheckColor = (spr) => 
        {
            // 먼저 선택된 처방을 설정한다.
            for (let i:number = 0; i < spr.ActiveSheet.RowCount; i++)
            {
                if (spr.GetValue(i, "FLAG").ToString() == "Y")
                    spr.ActiveSheet.Rows[i].BackColor = Color.LightSteelBlue;
                else
                    spr.ActiveSheet.Rows[i].BackColor = spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PID"].Index].BackColor;
            }

            //spr.ActiveSheet.AddSelection(spr.ActiveSheet.ActiveRowIndex, 0, 1, spr.ActiveSheet.Columns.Count);

            // 다시 처방표시 색상을 설정한다.
            //SetOrderColor(spr);
        }

        const SetMefeAutoCompletePostion = (row:number, col:number) => 
        {
            let autox:number = 0;
            let autoy:number = 0;
            let parentheight:number = 0;

            Rectangle position = sprMefe.GetCellRectangle(sprMefe.GetRootWorkbook().GetActiveRowViewportIndex(), sprMefe.GetRootWorkbook().GetActiveColumnViewportIndex(), row, col);

            autox = position.X;
            // Spread Height = 20, AutoComplete와의 거리 5, TitlePanel의 Title길이 33
            autoy = position.Y + 58;

            // 2018-08-31 김남훈 표시된 자동완성기능이 판낼의 길이보다 길 때 위로 올린다.
            // TitlePanel의 Title길이 30
            parentheight = ucMefeAutoComplete1.Parent.Height;

            if (autoy + ucMefeAutoComplete1.Height > parentheight)
                autoy = position.Y - ucMefeAutoComplete1.Height + 30;

            ucMefeAutoComplete1.Location = new Point(autox, autoy);
        }

        const SetFlagColumn = () => 
        {

            let prsc_lcls_cd:string = String.Empty;
            let prsc_mcls_cd:string = String.Empty;
            let prsc_cd:string = String.Empty;
            let row:number = sprMefe.ActiveSheet.ActiveRowIndex;
            let chek_ord:number = 0;
            CRUD_TYPE rowtype = CRUD_TYPE.Read;

            for (let i:number = 0; i < sprMefe.ActiveSheet.RowCount; i++)
            {
                prsc_lcls_cd = sprMefe.GetValue(i, "PRSC_LCLS_CD").ToString();
                prsc_mcls_cd = sprMefe.GetValue(i, "PRSC_MCLS_CD").ToString();
                prsc_cd = sprMefe.GetValue(i, "PRSC_CD").ToString();
                rowtype = sprMefe.GetCRUDFromRow(i);

                // 내복약과 동시에 선택 가능한 외용코드 확인
                chek_ord = await DBService.ExecuteInteger(Function.SelectFN_BI_READ_BISPORDTCNT(), "CHEKORD"
                                                                                               , prsc_cd
                                                                                               , m_MDCR_DD);

                // 일반경구제
                // 마약(경구, 외용)
                // 향정(경구, 외용)
                // 일반시럽제
                // 내복약과 동시에 선택 가능한 외용코드
                if (rowtype == CRUD_TYPE.Create && prsc_lcls_cd == "30" && (prsc_mcls_cd == "10" || prsc_mcls_cd == "30" || prsc_mcls_cd == "40" ||
                                                                           prsc_mcls_cd == "50" || chek_ord >= 1))
                    sprMefe.SetText(i, "FLAG", "Y");
            }
        }

        /// <summary>
        /// TEL Order를 설정한다.
        /// </summary>
        const SetTelOrder = () => 
        {
            let prsc_cd:string = String.Empty;
            let titlecode:string = String.Empty;
            let dc_prsc_dvcd:string = String.Empty;
            let prsc_lcls_cd:string = String.Empty;
            let start:number = 0;
            let end:number = 0;
            let chekflag:boolean = false;
            CRUD_TYPE rowtype = CRUD_TYPE.Read;

            if (m_OTPT_ADMS_DVCD != "I")
                return;

            // 체크가 되었다면
            if (BizCommon.CheckChooseColumn(sprMefe, "FLAG"))
            {
                start = 0;
                end = sprMefe.ActiveSheet.RowCount;
                chekflag = true;
            }
            else
            {
                start = sprMefe.ActiveSheet.ActiveRowIndex;
                end = start + 1;
                chekflag = false;
            }

            if (StringService.SubString(DOPack.UserInfo.OCTY_DVCD, 1) == "N")
            {
                for (let i:number = start; i < end; i++)
                {
                    titlecode = sprMefe.GetValue(i, "TITLECODE").ToString();

                    if (titlecode != "3")
                        continue;

                    if (sprMefe.GetValue(i, "FLAG").ToString() == "Y" || chekflag == false)
                    {
                        prsc_cd = sprMefe.GetValue(i, "PRSC_CD").ToString();
                        rowtype = sprMefe.GetCRUDFromRow(i);

                        if (String.IsNullOrWhiteSpace(prsc_cd))
                            continue;

                        //if(rowtype != CRUD_TYPE.Create)
                        //    continue;

                        dc_prsc_dvcd = sprMefe.GetValue(i, "DC_PRSC_DVCD").ToString();

                        if (dc_prsc_dvcd == "D" || dc_prsc_dvcd == "F")
                            continue;

                        prsc_lcls_cd = sprMefe.GetValue(i, "PRSC_LCLS_CD").ToString();

                        //if(prsc_lcls_cd == "20" || prsc_lcls_cd == "30")
                        //{
                        //    await LxMessage.Show("구두처방에서 약/주사는 입력 할 수 없습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //    return;
                        //}

                        sprMefe.SetText(i, "TEL_PRSC_FLAG", "Y");
                        if (sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Read)
                        {
                            sprMefe.SetCRUDToRow(i, CRUD_TYPE.Update);
                            sprMefe.SetCRUDCell(i, "TEL_PRSC_FLAG", CRUD_TYPE.Update);
                        }
                        else if (sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Update)
                            sprMefe.SetCRUDCell(i, "TEL_PRSC_FLAG", CRUD_TYPE.Update);
                    }
                }
            }
        }

        const SetPopMefeMessage = () => 
        {
            let prsc_cd:string = String.Empty;
            let prsc_nm:string = String.Empty;

            prsc_cd = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CD").ToString();
            prsc_nm = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_NM").ToString();

            popMefeMessage pop = new popMefeMessage(prsc_cd, prsc_nm, m_MDCR_DD);
            pop.ShowDialog(this);
            pop.Dispose();
        }

        /// <summary>
        /// Power를 설정한다.
        /// </summary>
        /// <returns></returns>
        const SetChangePowder = () => 
        {
            let PWDR_YN:string = String.Empty;
            let PRSC_CD:string = String.Empty;
            let PRSC_LCLS_CD:string = String.Empty;
            let PRSC_CLSF_CD:string = String.Empty;
            let errmsg:string = String.Empty;
            let mefeinfo = null;

            try
            {
                PWDR_YN = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PWDR_YN").ToString();
                PRSC_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CD").ToString();
                PRSC_LCLS_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_LCLS_CD").ToString();
                PRSC_CLSF_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CLSF_CD").ToString();

                if (String.IsNullOrWhiteSpace(PRSC_CD))
                {
                    sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PWDR_YN", "N");
                    return true;
                }

                mefeinfo = ORBizCommon.GetMefeInfo(PRSC_CD, m_MDCR_DD, "E", /*ref*/ errmsg);
                if (mefeinfo == null)
                {
                    errmsg = "처방코드 : " + PRSC_CD + "\r\n수가정보가 없어 처방입력 할 수 없습니다.\r\n보험심사팀으로 문의 바랍니다.";
                    sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PWDR_YN", "N");
                    return false;
                }

                if (!(mefeinfo["PRSC_LCLS_CD"].ToString() == "30"))
                {
                    await LxMessage.Show("약 처방이 아닌 경우는 파우더 체크 할 수 없습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PWDR_YN", "N");
                    return false;
                }
                else
                {
                    if (await ConfigService.GetConfigValueString("OR", "PRSC_ENTRY_OPTION", "DRUG_DEMO_YN") == "Y")
                    {
                        if (await DBService.ExecuteScalar(Function.FN_PM_READ_PMMFCDMA(), PRSC_CD, m_MDCR_DD, "POWD_YN").ToString() != "Y")
                        {
                            await LxMessage.Show("약국에서 산제 연동된 약이 아닌 경우는 파우더 체크 할 수 없습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PWDR_YN", "N");
                            return false;
                        }
                    }
                }

                //if(mefeinfo["DIVN_IMPB_YN"].ToString() == "Y")
                //{
                //    await LxMessage.Show("서방형제제의 경우 파우더 체크 할 수 없습니다. 약제과로 연락해 주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //    sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PWDR_YN", "N");
                //    return false;
                //}

                return true;
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
        }

        /// <summary>
        /// 이동촬영 여부를 설정한다.
        /// </summary>
        const SetChangeMovePhotograph = () => 
        {
            let PWDR_YN:string = String.Empty;
            let PRSC_CD:string = String.Empty;
            let PRSC_LCLS_CD:string = String.Empty;
            let PRSC_CLSF_CD:string = String.Empty;
            let errmsg:string = String.Empty;
            let mefeinfo = null;

            try
            {
                PWDR_YN = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PWDR_YN").ToString();
                PRSC_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CD").ToString();
                PRSC_LCLS_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_LCLS_CD").ToString();
                PRSC_CLSF_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CLSF_CD").ToString();

                if (String.IsNullOrWhiteSpace(PRSC_CD))
                {
                    sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "MOVE_PHTG_YN", "N");
                    return true;
                }

                mefeinfo = ORBizCommon.GetMefeInfo(PRSC_CD, m_MDCR_DD, "E", /*ref*/ errmsg);
                if (mefeinfo == null)
                {
                    errmsg = "처방코드 : " + PRSC_CD + "\r\n수가정보가 없어 처방입력 할 수 없습니다.\r\n보험심사팀으로 문의 바랍니다.";
                    sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "MOVE_PHTG_YN", "N");
                    return false;
                }

                if (!(PRSC_CLSF_CD == "1" || ((PRSC_LCLS_CD == "50" || PRSC_LCLS_CD == "A0" || PRSC_LCLS_CD == "70") && mefeinfo["MOVE_PHTG_PSBL_YN"].ToString() == "Y")))
                {
                    await LxMessage.Show("체크 할 수 있는 항목이 아닙니다. 심사과로 연락해 주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "MOVE_PHTG_YN", "N");
                    return false;
                }

                return true;
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
        }

        /// <summary>
        /// 선수행여부를 설정한다.(ChangeExpand)
        /// </summary>
        /// <returns>(1)변경완료/(0)변경 실패, 포커스 이동 O/(-1)변경 실패, 포커스 이동 X</returns>
        const SetChangePrvActgYn = () => 
        {
            let PRSC_CD:string = String.Empty;
            let PRSC_LCLS_CD:string = String.Empty;
            let PRSC_MCLS_CD:string = String.Empty;

            PRSC_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CD").ToString();
            PRSC_LCLS_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_LCLS_CD").ToString();

            if (String.IsNullOrWhiteSpace(PRSC_CD))
            {
                sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRV_ACTG_YN", "N");
                return 0;
            }

            // 진단검사, 병리검사, 방사선은 선수행 불가, 특정코드는 가능
            // 기능검사(A0) 중 심장검사(E0) 선수행 불가능
            if ((PRSC_LCLS_CD == "40" || PRSC_LCLS_CD == "42" || PRSC_LCLS_CD == "50") || (PRSC_LCLS_CD == "A0" && PRSC_MCLS_CD == "E0"))
            {
                if (await DBService.ExecuteInteger(Function.SelectFN_BI_READ_BISPORDTCNT(), "EXMNRAORD"
                                                                                        , PRSC_CD
                                                                                        , m_MDCR_DD) <= 0)
                {
                    sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRV_ACTG_YN", "N");
                    return 0;
                }
            }

            return 1;
        }

        /// <summary>
        /// 용법 설정화면을 띄운다.
        /// </summary>
        /// <returns></returns>
        const SetPopMediUsageInfo = (prsc_clsf_cd:string, /*ref*/ string aomd_mthd_cd, /*ref*/ string aomd_mthd_nm, /*ref*/ string errmsg) => 
        {
            popMediUsage pop = new popMediUsage(prsc_clsf_cd);
            if (pop.ShowDialog() == DialogResult.OK)
            {
                aomd_mthd_cd = pop.AOMD_MTHD_CD;
                aomd_mthd_nm = pop.AOMD_MTHD_NM;
            }
            else
            {
                errmsg = "용법을 선택 해 주세요.";
                pop.Dispose();
                return false;
            }

            pop.Dispose();
            return true;
        }

        /// <summary>
        /// .
        /// 용법관리를 설정한다.(DoubleClick or ContextMenu)
        /// </summary>
        /// <param name="prsc_clsf_cd">처방구분코드</param>
        /// <param name="errmsg">에러메세지</param>
        /// <returns></returns>
        const SetMediUsageInfo = (prsc_clsf_cd:string, /*ref*/ string errmsg) => 
        {
            let AOMD_MTHD_CD:string = String.Empty;
            let AOMD_MTHD_NM:string = String.Empty;
            let NOTM_CHEK_YN:string = String.Empty;
            let APLY_NOTM:string = String.Empty;
            let PRSC_INPT_QTY:string = String.Empty;
            let ORIG_AOMD_MTHD_CD:string = String.Empty;
            let PRSC_CD:string = String.Empty;
            let PRSC_NM:string = String.Empty;
            let apc_text:string = String.Empty;
            let apc_aomd_yn:boolean = false;
            let calc_init_qty:number = 0;
            let set_notm:number = 0;
            let pos:number = 0;
            let apc_count:number = 0;

            try
            {
                // 내복약, 외용약, 기타약품, 주사약은 용법이 필요없다.
                if (prsc_clsf_cd == "1" || prsc_clsf_cd == "2" || prsc_clsf_cd == "3" || prsc_clsf_cd == "4")
                {
                    // 팝업으로 용법 코드를 가져온다.
                    if (!(SetPopMediUsageInfo(prsc_clsf_cd, /*ref*/ AOMD_MTHD_CD, /*ref*/ AOMD_MTHD_NM, /*ref*/ errmsg)))
                    {
                        return false;
                    }

                    if (!(ORBizCommon.CheckMedicineUsage(AOMD_MTHD_CD, prsc_clsf_cd, /*ref*/ NOTM_CHEK_YN, /*ref*/ APLY_NOTM, /*ref*/ errmsg)))
                    {
                        return false;
                    }

                    // 2018-11-21 김남훈 APC 용법은 미리 원처방 투여방법을 선택받는다.
                    if (AOMD_MTHD_CD.IndexOf("APC") >= 0)
                    {
                        if (BizCommon.CheckChooseColumn(sprMefe, "FLAG"))
                        {
                            for (let i:number = 0; i < sprMefe.ActiveSheet.RowCount; i++)
                            {
                                if (sprMefe.GetValue(i, "FLAG").ToString() == "Y")
                                {
                                    apc_count++;

                                    if (!apc_aomd_yn)
                                    {
                                        apc_aomd_yn = true;
                                        PRSC_CD = sprMefe.GetValue(i, "PRSC_CD").ToString();
                                        PRSC_NM = sprMefe.GetValue(i, "PRSC_NM").ToString();
                                        APLY_NOTM = sprMefe.GetValue(i, "NOTM").ToString();
                                    }
                                }
                            }

                            if (apc_aomd_yn)
                            {
                                if (apc_count > 1)
                                    apc_text = " 외 " + apc_count.ToString() + "건";
                                else
                                    apc_text = "";

                                popOriginalMediUsage pop = new popOriginalMediUsage(prsc_clsf_cd, PRSC_CD + "  " + PRSC_NM + apc_text, Int.Parse(APLY_NOTM));
                                if (pop.ShowDialog() == DialogResult.OK)
                                    ORIG_AOMD_MTHD_CD = pop.AOMD_MTHD_CD;

                                pop.Dispose();
                            }
                        }
                        else
                        {
                            PRSC_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CD").ToString();
                            PRSC_NM = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_NM").ToString();
                            APLY_NOTM = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "NOTM").ToString();

                            apc_aomd_yn = true;

                            popOriginalMediUsage pop = new popOriginalMediUsage(prsc_clsf_cd, PRSC_CD + "  " + PRSC_NM, Int.Parse(APLY_NOTM));
                            if (pop.ShowDialog() == DialogResult.OK)
                                ORIG_AOMD_MTHD_CD = pop.AOMD_MTHD_CD;

                            pop.Dispose();

                        }
                    }

                    if (BizCommon.CheckChooseColumn(sprMefe, "FLAG"))
                    {
                        for (let i:number = 0; i < sprMefe.ActiveSheet.RowCount; i++)
                        {
                            if (!(sprMefe.GetValue(i, "TITLECODE").ToString() == "3"))
                                continue;

                            if (sprMefe.GetValue(i, "FLAG").ToString() == "Y")
                            {
                                // 2018-08-02 김남훈 일수변경될 때 슬러시 처방이면 변경된 일수를 1회량 일수에 넣어준다.
                                if (NOTM_CHEK_YN == "Y")
                                {
                                    sprMefe.SetText(i, "NOTM", APLY_NOTM);

                                    if (sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Read)
                                    {
                                        sprMefe.SetCRUDToRow(i, CRUD_TYPE.Update);
                                        sprMefe.SetCRUDCell(i, "NOTM", CRUD_TYPE.Update);
                                    }
                                    else if (sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Update)
                                        sprMefe.SetCRUDCell(i, "NOTM", CRUD_TYPE.Update);

                                    PRSC_INPT_QTY = sprMefe.GetValue(i, "PRSC_INPT_QTY").ToString();

                                    pos = PRSC_INPT_QTY.IndexOf("/");

                                    if (pos > 0 && StringService.IsNumeric(StringService.SubString(PRSC_INPT_QTY, 0, pos)))
                                    {
                                        PRSC_INPT_QTY = StringService.SubString(PRSC_INPT_QTY, 0, pos + 1) + APLY_NOTM;

                                        if (m_EntryOrder.CalcInptQty(PRSC_INPT_QTY, 0, /*ref*/ calc_init_qty, /*ref*/ set_notm, /*ref*/ errmsg))
                                        {
                                            sprMefe.SetValue(i, "ONTM_QTY", calc_init_qty);
                                            sprMefe.SetText(i, "PRSC_INPT_QTY", PRSC_INPT_QTY);

                                            if (sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Read)
                                            {
                                                sprMefe.SetCRUDCell(i, "ONTM_QTY", CRUD_TYPE.Update);
                                                sprMefe.SetCRUDCell(i, "PRSC_INPT_QTY", CRUD_TYPE.Update);
                                            }
                                            else if (sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Update)
                                            {
                                                sprMefe.SetCRUDCell(i, "ONTM_QTY", CRUD_TYPE.Update);
                                                sprMefe.SetCRUDCell(i, "PRSC_INPT_QTY", CRUD_TYPE.Update);
                                            }
                                        }
                                    }
                                }

                                sprMefe.SetText(i, "AOMD_MTHD_CD", AOMD_MTHD_CD);
                                if (sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Read)
                                {
                                    sprMefe.SetCRUDToRow(i, CRUD_TYPE.Update);
                                    sprMefe.SetCRUDCell(i, "AOMD_MTHD_CD", CRUD_TYPE.Update);
                                }
                                else if (sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Update)
                                    sprMefe.SetCRUDCell(i, "AOMD_MTHD_CD", CRUD_TYPE.Update);

                                if (apc_aomd_yn)
                                {
                                    sprMefe.SetText(i, "ORIG_AOMD_MTHD_CD", ORIG_AOMD_MTHD_CD);

                                    if (sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Read)
                                    {
                                        sprMefe.SetCRUDToRow(i, CRUD_TYPE.Update);
                                        sprMefe.SetCRUDCell(i, "ORIG_AOMD_MTHD_CD", CRUD_TYPE.Update);
                                    }
                                    else if (sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Update)
                                        sprMefe.SetCRUDCell(i, "ORIG_AOMD_MTHD_CD", CRUD_TYPE.Update);
                                }

                            }
                        }
                    }
                    else
                    {
                        if (!(sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "TITLECODE").ToString() == "3"))
                        {
                            errmsg = "처방타이틀에 적용할 수 없습니다.";
                            return false;
                        }

                        // 2018-08-02 김남훈 일수변경될 때 슬러시 처방이면 변경된 일수를 1회량 일수에 넣어준다.
                        if (NOTM_CHEK_YN == "Y")
                        {
                            sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "NOTM", APLY_NOTM);

                            if (sprMefe.GetCRUDFromRow(sprMefe.ActiveSheet.ActiveRowIndex) == CRUD_TYPE.Read)
                            {
                                sprMefe.SetCRUDToRow(sprMefe.ActiveSheet.ActiveRowIndex, CRUD_TYPE.Update);
                                sprMefe.SetCRUDCell(sprMefe.ActiveSheet.ActiveRowIndex, "NOTM", CRUD_TYPE.Update);
                            }
                            else if (sprMefe.GetCRUDFromRow(sprMefe.ActiveSheet.ActiveRowIndex) == CRUD_TYPE.Update)
                                sprMefe.SetCRUDCell(sprMefe.ActiveSheet.ActiveRowIndex, "NOTM", CRUD_TYPE.Update);

                            PRSC_INPT_QTY = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_INPT_QTY").ToString();

                            pos = PRSC_INPT_QTY.IndexOf("/");

                            if (pos > 0 && StringService.IsNumeric(StringService.SubString(PRSC_INPT_QTY, 0, pos)))
                            {
                                PRSC_INPT_QTY = StringService.SubString(PRSC_INPT_QTY, 0, pos + 1) + APLY_NOTM;

                                if (m_EntryOrder.CalcInptQty(PRSC_INPT_QTY, 0, /*ref*/ calc_init_qty, /*ref*/ set_notm, /*ref*/ errmsg))
                                {
                                    sprMefe.SetValue(sprMefe.ActiveSheet.ActiveRowIndex, "ONTM_QTY", calc_init_qty);
                                    sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_INPT_QTY", PRSC_INPT_QTY);

                                    if (sprMefe.GetCRUDFromRow(sprMefe.ActiveSheet.ActiveRowIndex) == CRUD_TYPE.Read)
                                    {
                                        sprMefe.SetCRUDCell(sprMefe.ActiveSheet.ActiveRowIndex, "ONTM_QTY", CRUD_TYPE.Update);
                                        sprMefe.SetCRUDCell(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_INPT_QTY", CRUD_TYPE.Update);
                                    }
                                    else if (sprMefe.GetCRUDFromRow(sprMefe.ActiveSheet.ActiveRowIndex) == CRUD_TYPE.Update)
                                    {
                                        sprMefe.SetCRUDCell(sprMefe.ActiveSheet.ActiveRowIndex, "ONTM_QTY", CRUD_TYPE.Update);
                                        sprMefe.SetCRUDCell(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_INPT_QTY", CRUD_TYPE.Update);
                                    }
                                }
                            }
                        }

                        sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "AOMD_MTHD_CD", AOMD_MTHD_CD);

                        if (apc_aomd_yn)
                        {
                            sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "ORIG_AOMD_MTHD_CD", ORIG_AOMD_MTHD_CD);

                            if (sprMefe.GetCRUDFromRow(sprMefe.ActiveSheet.ActiveRowIndex) == CRUD_TYPE.Read)
                            {
                                sprMefe.SetCRUDToRow(sprMefe.ActiveSheet.ActiveRowIndex, CRUD_TYPE.Update);
                                sprMefe.SetCRUDCell(sprMefe.ActiveSheet.ActiveRowIndex, "ORIG_AOMD_MTHD_CD", CRUD_TYPE.Update);
                            }
                            else if (sprMefe.GetCRUDFromRow(sprMefe.ActiveSheet.ActiveRowIndex) == CRUD_TYPE.Update)
                                sprMefe.SetCRUDCell(sprMefe.ActiveSheet.ActiveRowIndex, "ORIG_AOMD_MTHD_CD", CRUD_TYPE.Update);
                        }

                    }
                }
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// 예외사유코드를 설정한다.(DoubleClick or ContextMenu)
        /// </summary>
        /// <param name="prsc_clsf_cd">처방구분코드</param>
        /// <param name="errmsg">에러메세지</param>
        /// <returns></returns>
        const SetExcepCdInfo = (prsc_clsf_cd:string, /*ref*/ string errmsg) => 
        {
            let PRSC_CD:string = String.Empty;
            let EXCP_RESN_CD:string = String.Empty;
            let EXCP_RESN_NM:string = String.Empty;
            let PRSC_LCLS_CD:string = String.Empty;
            let PRSC_MCLS_CD:string = String.Empty;
            let PRSC_INPT_DVCD:string = String.Empty;

            try
            {
                // 내복약, 외용약, 기타약품, 주사약은 예외사유코드 제외
                if (prsc_clsf_cd == "1" || prsc_clsf_cd == "2" || prsc_clsf_cd == "3" || prsc_clsf_cd == "4")
                {
                    if (!(SetPopExcepCdInfo(EXCP_RESN_CD, /*ref*/ EXCP_RESN_NM, /*ref*/ errmsg)))
                    {
                        return false;
                    }

                    if (BizCommon.CheckChooseColumn(sprMefe, "FLAG"))
                    {
                        for (let i:number = 0; i < sprMefe.ActiveSheet.RowCount; i++)
                        {
                            PRSC_LCLS_CD = sprMefe.GetValue(i, "PRSC_LCLS_CD").ToString();
                            PRSC_MCLS_CD = sprMefe.GetValue(i, "PRSC_MCLS_CD").ToString();

                            if (!(sprMefe.GetValue(i, "TITLECODE").ToString() == "3"))
                                continue;

                            if (sprMefe.GetValue(i, "FLAG").ToString() == "Y")
                            {
                                sprMefe.SetText(i, "EXCP_RESN_CD", EXCP_RESN_CD);
                                if (sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Read)
                                {
                                    sprMefe.SetCRUDToRow(i, CRUD_TYPE.Update);
                                    sprMefe.SetCRUDCell(i, "EXCP_RESN_CD", CRUD_TYPE.Update);
                                }
                                else if (sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Update)
                                    sprMefe.SetCRUDCell(i, "EXCP_RESN_CD", CRUD_TYPE.Update);

                                PRSC_CD = sprMefe.GetValue(i, "PRSC_CD").ToString();

                                // 2018-11-20 김남훈 선처치 설정처방일 때 선처치 설정
                                if (await DBService.ExecuteInteger(Function.SelectFN_BI_READ_BISPORDTCNT(), "PRV_PRSC"
                                                                                                        , PRSC_CD
                                                                                                        , m_MDCR_DD) > 0)
                                    sprMefe.SetText(i, "PRV_ACTG_YN", "Y");
                                else
                                {
                                    // 외래 선수행 설정(옵션처리)
                                    // 약이거나 주사일 때
                                    // 예외사유코드가 있을 때 Y
                                    if (await ConfigService.GetConfigValueString("OR", "ALL_OPA_PRV_ACTG_YN", "USE_YN").ToString() == "Y" && await ConfigService.GetConfigValueString("OR", "ALL_OPA_PRV_ACTG_YN", m_MDCR_DEPT_CD).ToString() == "Y")
                                    {
                                        if (m_OTPT_ADMS_DVCD == "I")
                                            PRSC_INPT_DVCD = "99";
                                        else if (m_OTPT_ADMS_DVCD == "O")
                                            PRSC_INPT_DVCD = "00";

                                        if (m_OTPT_ADMS_DVCD == "O")
                                        {
                                            if (!String.IsNullOrWhiteSpace(EXCP_RESN_CD) && EXCP_RESN_CD != "NO" && PRSC_INPT_DVCD != "2" && !((PRSC_LCLS_CD == "20" || PRSC_LCLS_CD == "30") && PRSC_MCLS_CD == "30"))
                                                sprMefe.SetText(i, "PRV_ACTG_YN", "Y");
                                            else
                                                sprMefe.SetText(i, "PRV_ACTG_YN", "N");
                                        }
                                    }

                                    // 입원 선수행 설정(옵션처리)
                                    if (await ConfigService.GetConfigValueString("OR", "ALL_IPA_PRV_ACTG_YN", "USE_YN").ToString() == "Y" && await ConfigService.GetConfigValueString("OR", "ALL_IPA_PRV_ACTG_YN", DOPack.UserInfo.DEPT_CD).ToString() == "Y")
                                    {
                                        if (m_OTPT_ADMS_DVCD == "I")
                                        {
                                            if (!((PRSC_LCLS_CD == "20" || PRSC_LCLS_CD == "30") && PRSC_MCLS_CD == "30"))
                                                sprMefe.SetText(i, "PRV_ACTG_YN", "Y");
                                            else
                                                sprMefe.SetText(i, "PRV_ACTG_YN", "N");
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        if (!(sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "TITLECODE").ToString() == "3"))
                        {
                            errmsg = "처방타이틀에 적용할 수 없습니다.";
                            return false;
                        }

                        PRSC_LCLS_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_LCLS_CD").ToString();
                        PRSC_MCLS_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_MCLS_CD").ToString();

                        sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "EXCP_RESN_CD", EXCP_RESN_CD);
                        if (sprMefe.GetCRUDFromRow(sprMefe.ActiveSheet.ActiveRowIndex) == CRUD_TYPE.Read)
                        {
                            sprMefe.SetCRUDToRow(sprMefe.ActiveSheet.ActiveRowIndex, CRUD_TYPE.Update);
                            sprMefe.SetCRUDCell(sprMefe.ActiveSheet.ActiveRowIndex, "EXCP_RESN_CD", CRUD_TYPE.Update);
                        }
                        else if (sprMefe.GetCRUDFromRow(sprMefe.ActiveSheet.ActiveRowIndex) == CRUD_TYPE.Update)
                            sprMefe.SetCRUDCell(sprMefe.ActiveSheet.ActiveRowIndex, "EXCP_RESN_CD", CRUD_TYPE.Update);

                        PRSC_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CD").ToString();

                        // 2018-11-20 김남훈 선처치 설정처방일 때 선처치 설정
                        if (await DBService.ExecuteInteger(Function.SelectFN_BI_READ_BISPORDTCNT(), "PRV_PRSC"
                                                                                                , PRSC_CD
                                                                                                , m_MDCR_DD) > 0)
                            sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRV_ACTG_YN", "Y");
                        else
                        {
                            // 외래 선수행 설정(옵션처리)
                            // 약이거나 주사일 때
                            // 예외사유코드가 있을 때 Y
                            if (await ConfigService.GetConfigValueString("OR", "ALL_OPA_PRV_ACTG_YN", "USE_YN").ToString() == "Y" && await ConfigService.GetConfigValueString("OR", "ALL_OPA_PRV_ACTG_YN", m_MDCR_DEPT_CD).ToString() == "Y")
                            {
                                if (m_OTPT_ADMS_DVCD == "I")
                                    PRSC_INPT_DVCD = "99";
                                else if (m_OTPT_ADMS_DVCD == "O")
                                    PRSC_INPT_DVCD = "00";

                                if (m_OTPT_ADMS_DVCD == "O")
                                {
                                    if (!String.IsNullOrWhiteSpace(EXCP_RESN_CD) && EXCP_RESN_CD != "NO" && PRSC_INPT_DVCD != "2" && !((PRSC_LCLS_CD == "20" || PRSC_LCLS_CD == "30") && PRSC_MCLS_CD == "30"))
                                        sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRV_ACTG_YN", "Y");
                                    else
                                        sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRV_ACTG_YN", "N");
                                }
                            }

                            // 입원 선수행 설정(옵션처리)
                            if (await ConfigService.GetConfigValueString("OR", "ALL_IPA_PRV_ACTG_YN", "USE_YN").ToString() == "Y" && await ConfigService.GetConfigValueString("OR", "ALL_IPA_PRV_ACTG_YN", DOPack.UserInfo.DEPT_CD).ToString() == "Y")
                            {
                                if (m_OTPT_ADMS_DVCD == "I")
                                {
                                    if (!((PRSC_LCLS_CD == "20" || PRSC_LCLS_CD == "30") && PRSC_MCLS_CD == "30"))
                                        sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRV_ACTG_YN", "Y");
                                    else
                                        sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRV_ACTG_YN", "N");
                                }
                            }
                        }
                    }

                }
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// 예외사유 팝업을 띄운다
        /// </summary>
        /// <param name="errmsg">ErrorMessage</param>
        /// <returns>성공여부</returns>
        const SetPopExcepCdInfo = (excp_resn_cd:string, /*ref*/ string excp_resn_cnts, /*ref*/ string errmsg) => 
        {
            popExcepCd pop = new popExcepCd();
            if (pop.ShowDialog() == DialogResult.OK)
            {
                excp_resn_cd = pop.EXCP_RESN_CD;
                excp_resn_cnts = pop.EXCP_RESN_CNTS;
            }
            else
            {
                errmsg = "예외사유를 선택 해 주세요.";
                pop.Dispose();
                return false;
            }

            pop.Dispose();
            return true;
        }

        /// <summary>
        /// DC처방(Context Menu)
        /// </summary>
        const SetDcOrder = () => 
        {
            try
            {
                let titlecode:string = String.Empty;
                let prsc_cd:string = String.Empty;
                let mdcr_dd:string = String.Empty;
                let prsc_sqno:string = String.Empty;
                let pnod_prsc_uniq_no:string = String.Empty;
                let prsc_clsf_cd:string = String.Empty;
                let prsc_lcls_cd:string = String.Empty;
                let prsc_mcls_cd:string = String.Empty;
                let prsc_dvcd:string = String.Empty;
                let aomd_mthd_cd:string = String.Empty;
                let prsc_inpt_dvcd:string = String.Empty;
                let mded_refr_yn:string = String.Empty;
                let pwdr_yn:string = String.Empty;
                let ontm_qty:string = String.Empty;
                let notm:string = String.Empty;
                let nody:string = String.Empty;
                let prsc_uniq_no:string = String.Empty;
                let prsc_pcft:string = String.Empty;
                let excp_resn_cd:string = String.Empty;
                let dc_prsc_qty:string = String.Empty;
                let errmsg:string = String.Empty;
                let dlwtuniqno:string = String.Empty;
                let error_dvcd:string = String.Empty;
                let error_cnts:string = String.Empty;
                let dc_prsc_dvcd:string = String.Empty;
                let start:number = 0;
                let end:number = 0;
                let row:number = 0;
                let sqno:number = 0;
                let dc_count:number = 0;
                let chekflag:boolean = false;
                let dt:DataTable = new DataTable();
                let dcorder:DataTable = new DataTable();
                let pickup:DataTable = new DataTable();

                if (m_OTPT_ADMS_DVCD == "I")
                {
                    if (!await DBService.ExecuteDataTable(SQL.OR.Sql.SelectOPPatientInfoI(), /*ref*/ dt, m_PID, m_PT_CMHS_NO, PatientInfo.SRRN_ECPT, m_MDCR_DD))
                        throw new Error("환자 입원정보를 조회하는 중 에러가 발생했습니다.");

                    if (dt.Rows.Count.Equals(0))
                    {
                        await LxMessage.ShowError("환자 입원정보가 없어 저장할 수 없습니다.");
                        return;
                    }

                    if (dt.Rows[0]["STHS_DSCH_DVCD"].ToString() == "T")
                    {
                        await LxMessage.ShowError("퇴원환자 입니다.\r\n처방을 삭제할 수 없습니다.");
                        return;
                    }

                    let dsch_dd:string = dt.Rows[0]["DSCH_DD"].ToString();

                    // 퇴원일자가 정해졌는데 퇴원일자 외의 처방을 수정하려고 하는 경우는, 불가 메시지를 띄운다.
                    if (await ConfigService.GetConfigValueDirect("PA", "RECEIPT_DSCH", "SAVE_PRSC_ONLY_DSCH_DD", false))
                    {
                        if (dsch_dd != "29991231" && dsch_dd != dteMdcrDate.DateTime.ToString("yyyyMMdd") && 
                            !clsNRCommon.CheckSaveData_PAAREBMA(m_PID, m_PT_CMHS_NO, dteMdcrDate.DateTime.ToString("yyyyMMdd"), true))
                        {
                            return;
                        }
                    }
                }
                else if (m_OTPT_ADMS_DVCD == "O")
                {
                    if (!await DBService.ExecuteDataTable(SQL.OR.Sql.SelectOPPatientInfoO(), /*ref*/ dt, m_PID, m_PT_CMHS_NO, PatientInfo.SRRN_ECPT, m_MDCR_DD))
                        throw new Error("환자 내원정보를 조회하는 중 에러가 발생했습니다.");

                    if (dt.Rows.Count.Equals(0))
                    {
                        await LxMessage.ShowError("환자 내원정보가 없어 저장할 수 없습니다.");
                        return;
                    }
                }

                // 체크가 되었다면
                if (BizCommon.CheckChooseColumn(sprMefe, "FLAG"))
                {
                    start = 0;
                    end = sprMefe.ActiveSheet.RowCount;
                    chekflag = true;
                }
                else
                {
                    start = sprMefe.ActiveSheet.ActiveRowIndex;
                    end = start + 1;
                    chekflag = false;
                }

                // DC할 데이터테이블의 칼럼 생성
                for (let i:number = 0; i < sprMefe.ActiveSheet.ColumnCount; i++)
                {
                    dcorder.Columns.Add(sprMefe.ActiveSheet.Columns.Get(i).Tag.ToString());
                }

                for (let i:number = start; i < end; i++)
                {
                    titlecode = sprMefe.GetValue(i, "TITLECODE").ToString();
                    prsc_cd = sprMefe.GetValue(i, "PRSC_CD").ToString();

                    if (titlecode != "3")
                        continue;

                    if (String.IsNullOrWhiteSpace(prsc_cd))
                        continue;

                    if (sprMefe.GetValue(i, "FLAG").ToString() == "Y" || chekflag == false)
                    {
                        mdcr_dd = sprMefe.GetValue(i, "MDCR_DD").ToString();
                        prsc_sqno = sprMefe.GetValue(i, "PRSC_SQNO").ToString();
                        pnod_prsc_uniq_no = sprMefe.GetValue(i, "PNOD_PRSC_UNIQ_NO").ToString();
                        prsc_clsf_cd = sprMefe.GetValue(i, "PRSC_CLSF_CD").ToString();
                        prsc_lcls_cd = sprMefe.GetValue(i, "PRSC_LCLS_CD").ToString();
                        prsc_mcls_cd = sprMefe.GetValue(i, "PRSC_MCLS_CD").ToString();
                        prsc_dvcd = sprMefe.GetValue(i, "PRSC_DVCD").ToString();
                        aomd_mthd_cd = sprMefe.GetValue(i, "AOMD_MTHD_CD").ToString();
                        prsc_inpt_dvcd = sprMefe.GetValue(i, "PRSC_INPT_DVCD").ToString();
                        mded_refr_yn = sprMefe.GetValue(i, "MDED_REFR_YN").ToString();
                        pwdr_yn = sprMefe.GetValue(i, "PWDR_YN").ToString();
                        ontm_qty = sprMefe.GetValue(i, "ONTM_QTY").ToString();
                        notm = sprMefe.GetValue(i, "NOTM").ToString();
                        nody = sprMefe.GetValue(i, "NODY").ToString();
                        prsc_uniq_no = sprMefe.GetValue(i, "PRSC_UNIQ_NO").ToString();
                        prsc_pcft = sprMefe.GetValue(i, "PRSC_PCFT").ToString();
                        excp_resn_cd = sprMefe.GetValue(i, "EXCP_RESN_CD").ToString();
                        dc_prsc_dvcd = sprMefe.GetValue(i, "DC_PRSC_DVCD").ToString();

                        if (String.IsNullOrWhiteSpace(prsc_clsf_cd))
                            prsc_clsf_cd = "A";

                        if (String.IsNullOrWhiteSpace(ontm_qty))
                            ontm_qty = "0";

                        if (String.IsNullOrWhiteSpace(notm))
                            notm = "0";

                        if (String.IsNullOrWhiteSpace(nody))
                            nody = "0";

                        if (sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Create)
                        {
                            await LxMessage.ShowInformation($"처방코드 : {prsc_cd}\r\n선택한 정보는 저장되지 않은 처방이므로 삭제처리 하시기 바랍니다.");
                            return;
                        }

                        if (dc_prsc_dvcd == "D" || dc_prsc_dvcd == "F")
                            continue;

                        // DC Datatable 데이터 생성
                        dcorder.Rows.Add();
                        row = dcorder.Rows.Count - 1;
                        for (let j:number = 0; j < sprMefe.ActiveSheet.ColumnCount; j++)
                        {
                            dcorder.Rows[row][j] = sprMefe.GetOldValue(i, j).ToString();
                        }

                        dcorder.Rows[row]["PRSC_SQNO"] = "0";
                        dcorder.Rows[row]["NODY"] = (decimal.Parse(nody) * -1).ToString();
                        dcorder.Rows[row]["DC_PRSC_DVCD"] = "D";
                        dcorder.Rows[row]["PRSC_PCFT"] = prsc_pcft;

                        // 실제 DC 수량 입력
                        dc_prsc_qty = (decimal.Parse(ontm_qty) * decimal.Parse(notm)).ToString();

                        if (m_OTPT_ADMS_DVCD == "O")
                        {
                            dcorder.Rows[row]["RCPT_YN"] = "Y";
                        }
                        else
                        {
                            dcorder.Rows[row]["WARD_CD"] = m_WARD_CD;
                        }

                        dcorder.Rows[row]["DC_PRSC_QTY"] = dc_prsc_qty;
                        dcorder.Rows[row]["ORIG_PRSC_SQNO"] = prsc_sqno;
                        dcorder.Rows[row]["PCUP_YN"] = "N";
                        dcorder.Rows[row]["PCUP_DT"] = "";
                        dcorder.Rows[row]["PCUP_TGPS_ID"] = "";
                        dcorder.Rows[row]["PCUP_DEPT_CD"] = "";
                    }
                }

                if (await LxMessage.ShowQuestion("선택한 처방을 D/C 하시겠습니까?").Equals(DialogResult.No))
                    return;

                let currentdate:string = DateTime.Now.ToString("yyyyMMddHHmmss");

                // DBService.BeginTransaction ();

                if (!m_EntryOrder.SaveDCORORDRRT(dcorder, null, "OR_BASE_DC", m_OTPT_ADMS_DVCD, m_PID, m_PT_CMHS_NO, mdcr_dd, m_MDCR_DEPT_CD, m_MDCR_DR_CD, "", currentdate, /*ref*/ dc_count, /*ref*/ errmsg))
                    throw new Error($"D/C 처방 저장 중 에러가 발생했습니다.\r\n{errmsg}");

                if (dc_count.Equals(0))
                    throw new Error("D/C 저장된 내역이 없습니다.");

                if (m_OTPT_ADMS_DVCD == "I")
                {
                    if (!await DBService.ExecuteDataTable(SQL.OR.Sql.SelectPickUpORORDRRT("ETC"), /*ref*/ pickup, m_PID, m_PT_CMHS_NO, currentdate, DOPack.UserInfo.USER_CD))
                        throw new Error("자동 픽업할 내역을 조회하는 중 에러가 발생했습니다.");

                    if (pickup.Rows.Count > 0)
                    {
                        for (let i:number = 0; i < pickup.Rows.Count; i++)
                        {
                            prsc_sqno = pickup.Rows[i]["PRSC_SQNO"].ToString();

                            sqno++;

                            if (!ORBizCommon.InsertORSQTPIFSub(m_PID, m_PT_CMHS_NO, pickup.Rows[i]["MDCR_DD"].ToString(), "PICKUP", /*ref*/ dlwtuniqno, sqno.ToString(), prsc_sqno, currentdate))
                                throw new Error("자동 픽업내역을 임시테이블에 저장하는 중 에러가 발생했습니다.");
                        }

                        // 전자서명
                        if (!EMBizCommon.SetESignOrderPickUp(m_PID, dlwtuniqno, /*ref*/ errmsg))
                            throw new Error($"전자서명 중 에러가 발생했습니다.\r\n[EMBizCommon.SetESignOrderPickUp]\r\n{errmsg}");

                        // 픽업 진행
                        if (!Procedure.PR_NR_PRC_PCUPPRC(m_PID                      // 환자등록번호
                                                                , m_PT_CMHS_NO               // 환자내원번호
                                                                , m_WARD_CD                  // 병동코드
                                                                , dlwtuniqno.ToString()    // 픽업의뢰고유번호
                                                                , currentdate               // 픽업일시
                                                                , m_MDCR_DR_CD             // 픽업자
                                                                , m_MDCR_DEPT_CD           // 픽업부서(주부서)
                                                                , /*ref*/ error_dvcd            // 에러Flag
                                                                , /*ref*/ error_cnts))          // 에러내용
                            throw new Error("자동 픽업 중 에러가 발생했습니다.");

                        if (!String.IsNullOrWhiteSpace(error_dvcd))
                            throw new Error($"자동 픽업 중 에러가 발생했습니다.\r\n  - 에러코드 : {error_dvcd}\r\n{error_cnts}");
                    }
                }
                else if (m_OTPT_ADMS_DVCD == "O")
                {
                    for (let i:number = 0; i < dcorder.Rows.Count; i++)
                    {
                        // 수납구분을 업데이트한다
                        if (!await DBService.ExecuteNonQuery(SQL.OR.Sql.UpdateRcptYnORORDRRT(), m_PID
                                                                                       , m_PT_CMHS_NO
                                                                                       , m_MDCR_DD
                                                                                       , dcorder.Rows[i]["ORIG_PRSC_SQNO"].ToString()))
                            throw new Error("D/C 처방 수납구분을 저장하는 중 에러가 발생했습니다.");
                    }
                }

                // 저장
                // DBService.CommitTransaction ();

                m_IsSaved = true;

                // TODO : 초음파 주/부 설정( 첫번째 부위 초음파 100%, 두번째 부위 50% )

                await LxMessage.ShowInformation("D/C 되었습니다.", 3);

                SelectData();
            }
            catch (ex)
            {
                let error:string = DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                // if(DBService.IsTransaction)
                    // DBService.RollbackTransaction();

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                await LxMessage.ShowError(ex.Message + error);
            }
        }

        /// <summary>
        /// 처방을 삭제한다.
        /// </summary>
        const DeleteOrderData = () => 
        {
            try
            {
                let FLAG:string = String.Empty;
                let TITLECODE:string = String.Empty;
                let PRSC_DVCD:string = String.Empty;
                let PRSC_CD:string = String.Empty;
                let PRSC_NM:string = String.Empty;
                let PRSC_SQNO:string = String.Empty;
                let DC_PRSC_DVCD:string = String.Empty;
                let PNOD_PRSC_UNIQ_NO:string = String.Empty;
                let PRSC_LCLS_CD:string = String.Empty;
                let PRSC_MCLS_CD:string = String.Empty;
                let PRSC_UNIQ_NO:string = String.Empty;
                let EXCP_RESN_CD:string = String.Empty;
                let sono:number = 0;
                let del_count:number = 0;
                let chekflag:boolean = false;
                let errmsg:string = String.Empty;
                let order_count:number = 0;
                let oo_order_count:number = 0;
                let oi_order_count:number = 0;
                let i_order_count:number = 0;
                let t_order_count:number = 0;
                let multiple_prsc_row:number = -1;
                let dt:DataTable = new DataTable();

                if (m_OTPT_ADMS_DVCD == "I")
                {
                    if (!await DBService.ExecuteDataTable(SQL.OR.Sql.SelectOPPatientInfoI(), /*ref*/ dt, m_PID, m_PT_CMHS_NO, PatientInfo.SRRN_ECPT, m_MDCR_DD))
                        throw new Error("환자 입원정보를 조회하는 중 에러가 발생했습니다.");

                    if (dt.Rows.Count.Equals(0))
                    {
                        await LxMessage.ShowError("환자 입원정보가 없어 저장할 수 없습니다.");
                        return;
                    }

                    if (dt.Rows[0]["STHS_DSCH_DVCD"].ToString() == "T")
                    {
                        await LxMessage.ShowError("퇴원환자 입니다.\r\n처방을 삭제할 수 없습니다.");
                        return;
                    }

                    let dsch_dd:string = dt.Rows[0]["DSCH_DD"].ToString();

                    // 퇴원일자가 정해졌는데 퇴원일자 외의 처방을 수정하려고 하는 경우는, 불가 메시지를 띄운다.
                    if (await ConfigService.GetConfigValueDirect("PA", "RECEIPT_DSCH", "SAVE_PRSC_ONLY_DSCH_DD", false))
                    {
                        if (dsch_dd != "29991231" && dsch_dd != dteMdcrDate.DateTime.ToString("yyyyMMdd") &&
                            !clsNRCommon.CheckSaveData_PAAREBMA(m_PID, m_PT_CMHS_NO, dteMdcrDate.DateTime.ToString("yyyyMMdd"), true))
                        {
                            return;
                        }
                    }
                }
                else if (m_OTPT_ADMS_DVCD == "O")
                {
                    if (!await DBService.ExecuteDataTable(SQL.OR.Sql.SelectOPPatientInfoO(), /*ref*/ dt, m_PID, m_PT_CMHS_NO, PatientInfo.SRRN_ECPT, m_MDCR_DD))
                        throw new Error("환자 내원정보를 조회하는 중 에러가 발생했습니다.");

                    if (dt.Rows.Count.Equals(0))
                    {
                        await LxMessage.ShowError("환자 내원정보가 없어 저장할 수 없습니다.");
                        return;
                    }
                }

                let start:number = 0;
                let end:number = 0;

                // 삭제가능한지 처방체크
                if (BizCommon.CheckChooseColumn(sprMefe, "FLAG"))
                {
                    start = 0;
                    end = sprMefe.ActiveSheet.RowCount;
                    chekflag = true;
                }
                else
                {
                    start = sprMefe.ActiveSheet.ActiveRowIndex;
                    end = sprMefe.ActiveSheet.ActiveRowIndex + 1;
                    chekflag = false;
                }

                if (await LxMessage.ShowQuestion("처방을 삭제 하시겠습니까?").Equals(DialogResult.No))
                    return;

                let currentdate:string = DateTime.Now.ToString("yyyyMMddHHmmss");

                // DBService.BeginTransaction ();

                for (let i:number = start; i < end; i++)
                {
                    FLAG = chekflag ? sprMefe.GetValue(i, "FLAG").ToString() : "Y";

                    if (FLAG == "N")
                        continue;

                    TITLECODE = sprMefe.GetValue(i, "TITLECODE").ToString();
                    if (!(TITLECODE == "3"))
                    {
                        sprMefe.RemoveRow(i);
                        i--;
                        end--;
                        continue;
                    }

                    if (sprMefe.GetCRUDFromRow(i) != CRUD_TYPE.Create)
                        throw new Error("저장된 처방은 D/C 처리해 주세요.");

                    PRSC_DVCD = sprMefe.GetValue(i, "PRSC_DVCD").ToString();
                    PRSC_CD = sprMefe.GetValue(i, "PRSC_CD").ToString();
                    PRSC_SQNO = sprMefe.GetValue(i, "PRSC_SQNO").ToString();
                    DC_PRSC_DVCD = sprMefe.GetValue(i, "DC_PRSC_DVCD").ToString();
                    PNOD_PRSC_UNIQ_NO = sprMefe.GetValue(i, "PNOD_PRSC_UNIQ_NO").ToString();
                    PRSC_LCLS_CD = sprMefe.GetValue(i, "PRSC_LCLS_CD").ToString();
                    PRSC_MCLS_CD = sprMefe.GetValue(i, "PRSC_MCLS_CD").ToString();
                    PRSC_UNIQ_NO = sprMefe.GetValue(i, "PRSC_UNIQ_NO").ToString();
                    EXCP_RESN_CD = sprMefe.GetValue(i, "EXCP_RESN_CD").ToString();

                    if (String.IsNullOrWhiteSpace(PRSC_SQNO) || PRSC_SQNO == "0")
                    {
                        sprMefe.RemoveRow(i);
                        i--;
                        end--;
                        continue;
                    }
                    // 일련번호가 들어가있어도 저장된 처방인지 확인한다
                    if (!await DBService.ExecuteDataTable(SQL.OR.Sql.DeleteCheckOrder(), /*ref*/ dt, m_PID, m_PT_CMHS_NO, m_MDCR_DD, PRSC_SQNO))
                        throw new Error("저장된 처방 정보 조회 중 에러가 발생했습니다.");

                    if (dt.Rows.Count <= 0)
                    {
                        sprMefe.RemoveRow(i);
                        i--;
                        end--;
                        continue;
                    }

                    // 처방삭제
                    if (!m_EntryOrder.DeleteOrderData(m_OTPT_ADMS_DVCD, m_PID, m_PT_CMHS_NO, m_MDCR_DD, PRSC_SQNO, PNOD_PRSC_UNIQ_NO, currentdate, /*ref*/ errmsg))
                        throw new Error("처방 삭제 중 에러가 발생했습니다.");

                    del_count++;
                    sprMefe.RemoveRow(i);
                    i--;
                    end--;
                }

                // DBService.CommitTransaction ();
            }
            catch (ex)
            {
                let error:string = DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                // if(DBService.IsTransaction)
                    // DBService.RollbackTransaction();

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                await LxMessage.ShowError(ex.Message + error);
            }
        }

        /// <summary>
        /// Row를 이동
        /// </summary>
        /// <param name="move_dvcd">이동구분</param>
        const SetRowMove = (move_dvcd:string) => 
        {
            let prsc_lcls_cd:string = String.Empty;
            let prsc_inpt_dvcd:string = String.Empty;
            let chek_prsc_lcls_cd:string = String.Empty;
            let chek_prsc_inpt_dvcd:string = String.Empty;
            let start:number = 0;
            let end:number = 0;
            let moverow:number = 0;
            let toprow:number = 0;
            let bottomrow:number = 0;
            let chekflag:boolean = false;
            let moveflag:boolean = true;

            try
            {
                //this.SuspendLayout();
                if (await ConfigService.GetConfigValueString("OR", "SELECT_OPTION", "USE_YN").ToString() == "M")
                {
                    // 체크가 되었다면 같은 분류끼리 체크가 되어있는지 확인
                    if (BizCommon.CheckChooseColumn(sprMefe, "FLAG"))
                    {
                        start = 0;
                        end = sprMefe.ActiveSheet.RowCount;
                        chekflag = true;

                        // 같은 분류가 체크 되었는지 확인.
                        for (let i:number = 0; i < sprMefe.ActiveSheet.RowCount; i++)
                        {
                            if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                                continue;

                            if (sprMefe.GetValue(i, "FLAG").ToString() == "Y")
                            {
                                prsc_lcls_cd = sprMefe.GetValue(i, "PRSC_LCLS_CD").ToString();
                                prsc_inpt_dvcd = sprMefe.GetValue(i, "PRSC_INPT_DVCD").ToString();

                                if (String.IsNullOrWhiteSpace(chek_prsc_lcls_cd) && String.IsNullOrWhiteSpace(chek_prsc_inpt_dvcd))
                                {
                                    chek_prsc_lcls_cd = prsc_lcls_cd;
                                    chek_prsc_inpt_dvcd = prsc_inpt_dvcd;
                                }
                                else
                                {
                                    if (!(chek_prsc_lcls_cd == prsc_lcls_cd && chek_prsc_inpt_dvcd == prsc_inpt_dvcd))
                                    {
                                        moveflag = false;
                                        break;
                                    }
                                }
                            }
                        }

                        if (moveflag == false)
                        {
                            await LxMessage.Show("같은 분류를 선택해야 합니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                    }
                    else
                    {
                        start = sprMefe.ActiveSheet.ActiveRowIndex;
                        end = start + 1;
                        chekflag = false;

                        prsc_lcls_cd = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_LCLS_CD").ToString();
                        prsc_inpt_dvcd = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_INPT_DVCD").ToString();
                    }

                    switch (move_dvcd)
                    {
                        case "TOP":
                            // 이동할 Row를 찾는다.
                            for (let i:number = 0; i < sprMefe.ActiveSheet.RowCount; i++)
                            {
                                if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                                    continue;

                                chek_prsc_lcls_cd = sprMefe.GetValue(i, "PRSC_LCLS_CD").ToString();
                                chek_prsc_inpt_dvcd = sprMefe.GetValue(i, "PRSC_INPT_DVCD").ToString();

                                if (chek_prsc_lcls_cd == prsc_lcls_cd && chek_prsc_inpt_dvcd == prsc_inpt_dvcd)
                                {
                                    moverow = i;
                                    break;
                                }
                            }

                            start = moverow;

                            if (chekflag)
                            {
                                for (let i:number = end - 1; i >= start; i--)
                                {
                                    if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                                        continue;

                                    if (sprMefe.GetValue(i, "FLAG").ToString() == "Y" || chekflag == false)
                                    {
                                        sprMefe.MoveRow(moverow, i, 1);
                                        i++;
                                        start++;
                                    }
                                }
                            }
                            else
                                sprMefe.MoveRow(moverow, sprMefe.ActiveSheet.ActiveRowIndex, 1);

                            sprMefe.SetActiveRow(moverow);
                            sprMefe.ShowRow(0, moverow, VerticalPosition.Nearest);
                            break;
                        case "UP":
                            // 이동할 Row를 찾는다.
                            for (let i:number = 0; i < sprMefe.ActiveSheet.RowCount; i++)
                            {
                                if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                                    continue;

                                chek_prsc_lcls_cd = sprMefe.GetValue(i, "PRSC_LCLS_CD").ToString();
                                chek_prsc_inpt_dvcd = sprMefe.GetValue(i, "PRSC_INPT_DVCD").ToString();

                                if (chek_prsc_lcls_cd == prsc_lcls_cd && chek_prsc_inpt_dvcd == prsc_inpt_dvcd)
                                {
                                    moverow = i;
                                    break;
                                }
                            }

                            if (chekflag)
                            {
                                for (let i:number = start; i < end; i++)
                                {
                                    if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                                        continue;

                                    if (sprMefe.GetValue(i, "FLAG").ToString() == "Y" || chekflag == false)
                                    {

                                        if (moverow == i)
                                        {
                                            toprow = ((toprow == 0) ? i : toprow);
                                            moverow++;
                                            continue;
                                        }

                                        toprow = ((toprow == 0) ? i - 1 : toprow);

                                        if (i <= 0)
                                            return;
                                        else
                                            sprMefe.MoveRow(i - 1, i, 1);
                                    }
                                }

                                if (toprow > 0)
                                {
                                    sprMefe.SetActiveRow(toprow);
                                    sprMefe.ShowRow(0, toprow, VerticalPosition.Nearest);
                                }
                            }
                            else
                            {
                                if (sprMefe.ActiveSheet.ActiveRowIndex > moverow)
                                {
                                    sprMefe.MoveRow(sprMefe.ActiveSheet.ActiveRowIndex - 1, sprMefe.ActiveSheet.ActiveRowIndex, 1);
                                    sprMefe.SetActiveRow(sprMefe.ActiveSheet.ActiveRowIndex);
                                    sprMefe.ShowRow(0, sprMefe.ActiveSheet.ActiveRowIndex, VerticalPosition.Nearest);
                                }
                            }
                            break;
                        case "DOWN":
                            // 이동할 Row를 찾는다.
                            for (let i:number = sprMefe.ActiveSheet.RowCount - 1; i >= 0; i--)
                            {
                                if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                                    continue;

                                chek_prsc_lcls_cd = sprMefe.GetValue(i, "PRSC_LCLS_CD").ToString();
                                chek_prsc_inpt_dvcd = sprMefe.GetValue(i, "PRSC_INPT_DVCD").ToString();

                                if (chek_prsc_lcls_cd == prsc_lcls_cd && chek_prsc_inpt_dvcd == prsc_inpt_dvcd)
                                {
                                    moverow = i;
                                    break;
                                }
                            }

                            if (chekflag)
                            {
                                for (let i:number = end - 1; i >= start; i--)
                                {
                                    if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                                        continue;

                                    if (sprMefe.GetValue(i, "FLAG").ToString() == "Y" || chekflag == false)
                                    {

                                        if (moverow == i)
                                        {
                                            bottomrow = ((bottomrow == 0) ? i : bottomrow);
                                            moverow--;
                                            continue;
                                        }

                                        bottomrow = ((bottomrow == 0) ? i + 1 : bottomrow);

                                        if (i + 1 >= sprMefe.ActiveSheet.RowCount)
                                            return;
                                        else
                                            sprMefe.MoveRow(i + 1, i, 1);
                                    }
                                }

                                sprMefe.SetActiveRow(bottomrow);
                                sprMefe.ShowRow(0, bottomrow, VerticalPosition.Nearest);
                            }
                            else
                            {
                                if (sprMefe.ActiveSheet.ActiveRowIndex < moverow)
                                {
                                    sprMefe.MoveRow(sprMefe.ActiveSheet.ActiveRowIndex + 1, sprMefe.ActiveSheet.ActiveRowIndex, 1);
                                    sprMefe.SetActiveRow(sprMefe.ActiveSheet.ActiveRowIndex);
                                    sprMefe.ShowRow(0, sprMefe.ActiveSheet.ActiveRowIndex, VerticalPosition.Nearest);
                                }
                            }
                            break;
                        case "BOTTOM":
                            // 이동할 Row를 찾는다.
                            for (let i:number = sprMefe.ActiveSheet.RowCount - 1; i >= 0; i--)
                            {
                                if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                                    continue;

                                chek_prsc_lcls_cd = sprMefe.GetValue(i, "PRSC_LCLS_CD").ToString();
                                chek_prsc_inpt_dvcd = sprMefe.GetValue(i, "PRSC_INPT_DVCD").ToString();

                                if (chek_prsc_lcls_cd == prsc_lcls_cd && chek_prsc_inpt_dvcd == prsc_inpt_dvcd)
                                {
                                    moverow = i;
                                    break;
                                }
                            }

                            end = moverow;

                            if (chekflag)
                            {
                                for (let i:number = start; i < end; i++)
                                {
                                    if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                                        continue;

                                    if (sprMefe.GetValue(i, "FLAG").ToString() == "Y" || chekflag == false)
                                    {
                                        if (sprMefe.GetValue(i, "FLAG").ToString() == "Y" || chekflag == false)
                                        {
                                            sprMefe.MoveRow(moverow, i, 1);
                                            i--;
                                            end--;
                                        }
                                    }
                                }
                            }
                            else
                                sprMefe.MoveRow(moverow, sprMefe.ActiveSheet.ActiveRowIndex, 1);

                            sprMefe.SetActiveRow(moverow);
                            sprMefe.ShowRow(0, moverow, VerticalPosition.Nearest);
                            break;
                    }
                }
                else if (await ConfigService.GetConfigValueString("OR", "SELECT_OPTION", "USE_YN").ToString() == "N")
                {
                    // 체크가 되었다면 같은 분류끼리 체크가 되어있는지 확인
                    if (BizCommon.CheckChooseColumn(sprMefe, "FLAG"))
                    {
                        start = 0;
                        end = sprMefe.ActiveSheet.RowCount;
                        chekflag = true;
                    }
                    else
                    {
                        start = sprMefe.ActiveSheet.ActiveRowIndex;
                        end = start + 1;
                        chekflag = false;
                    }

                    switch (move_dvcd)
                    {
                        case "TOP":
                            // 이동할 Row를 찾는다.
                            for (let i:number = 0; i < sprMefe.ActiveSheet.RowCount; i++)
                            {
                                if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                                    continue;

                                moverow = i;
                                break;
                            }

                            start = moverow;

                            if (chekflag)
                            {
                                for (let i:number = end - 1; i >= start; i--)
                                {
                                    if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                                        continue;

                                    if (sprMefe.GetValue(i, "FLAG").ToString() == "Y" || chekflag == false)
                                    {
                                        sprMefe.MoveRow(moverow, i, 1);
                                        i++;
                                        start++;
                                    }
                                }
                            }
                            else
                                sprMefe.MoveRow(moverow, sprMefe.ActiveSheet.ActiveRowIndex, 1);

                            sprMefe.SetActiveRow(moverow);
                            sprMefe.ShowRow(0, moverow, VerticalPosition.Nearest);
                            break;
                        case "UP":
                            // 이동할 Row를 찾는다.
                            for (let i:number = 0; i < sprMefe.ActiveSheet.RowCount; i++)
                            {
                                if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                                    continue;

                                moverow = i;
                                break;
                            }

                            if (chekflag)
                            {
                                for (let i:number = start; i < end; i++)
                                {
                                    if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                                        continue;

                                    if (sprMefe.GetValue(i, "FLAG").ToString() == "Y" || chekflag == false)
                                    {

                                        if (moverow == i)
                                        {
                                            toprow = ((toprow == 0) ? i : toprow);
                                            moverow++;
                                            continue;
                                        }

                                        toprow = ((toprow == 0) ? i - 1 : toprow);

                                        if (i <= 0)
                                            return;
                                        else
                                            sprMefe.MoveRow(i - 1, i, 1);
                                    }
                                }

                                if (toprow > 0)
                                {
                                    sprMefe.SetActiveRow(toprow);
                                    sprMefe.ShowRow(0, toprow, VerticalPosition.Nearest);
                                }
                            }
                            else
                            {
                                if (sprMefe.ActiveSheet.ActiveRowIndex > moverow)
                                {
                                    sprMefe.MoveRow(sprMefe.ActiveSheet.ActiveRowIndex - 1, sprMefe.ActiveSheet.ActiveRowIndex, 1);
                                    sprMefe.SetActiveRow(sprMefe.ActiveSheet.ActiveRowIndex);
                                    sprMefe.ShowRow(0, sprMefe.ActiveSheet.ActiveRowIndex, VerticalPosition.Nearest);
                                }
                            }
                            break;
                        case "DOWN":
                            // 이동할 Row를 찾는다.
                            for (let i:number = sprMefe.ActiveSheet.RowCount - 1; i >= 0; i--)
                            {
                                if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                                    continue;

                                if (String.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_CD").ToString()))
                                    continue;

                                moverow = i;
                                break;
                            }

                            if (chekflag)
                            {
                                for (let i:number = end - 1; i >= start; i--)
                                {
                                    if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                                        continue;

                                    if (sprMefe.GetValue(i, "FLAG").ToString() == "Y" || chekflag == false)
                                    {

                                        if (moverow == i)
                                        {
                                            bottomrow = ((bottomrow == 0) ? i : bottomrow);
                                            moverow--;
                                            continue;
                                        }

                                        bottomrow = ((bottomrow == 0) ? i + 1 : bottomrow);

                                        if (i + 1 >= sprMefe.ActiveSheet.RowCount)
                                            return;
                                        else
                                            sprMefe.MoveRow(i + 1, i, 1);
                                    }
                                }

                                sprMefe.SetActiveRow(bottomrow);
                                sprMefe.ShowRow(0, bottomrow, VerticalPosition.Nearest);
                            }
                            else
                            {
                                if (sprMefe.ActiveSheet.ActiveRowIndex < moverow)
                                {
                                    sprMefe.MoveRow(sprMefe.ActiveSheet.ActiveRowIndex + 1, sprMefe.ActiveSheet.ActiveRowIndex, 1);
                                    sprMefe.SetActiveRow(sprMefe.ActiveSheet.ActiveRowIndex);
                                    sprMefe.ShowRow(0, sprMefe.ActiveSheet.ActiveRowIndex, VerticalPosition.Nearest);
                                }
                            }
                            break;
                        case "BOTTOM":
                            // 이동할 Row를 찾는다.
                            for (let i:number = sprMefe.ActiveSheet.RowCount - 1; i >= 0; i--)
                            {
                                if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                                    continue;

                                if (String.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_CD").ToString()))
                                    continue;

                                moverow = i;
                                break;
                            }

                            end = moverow;

                            if (chekflag)
                            {
                                for (let i:number = start; i < end; i++)
                                {
                                    if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                                        continue;

                                    if (sprMefe.GetValue(i, "FLAG").ToString() == "Y" || chekflag == false)
                                    {
                                        if (sprMefe.GetValue(i, "FLAG").ToString() == "Y" || chekflag == false)
                                        {
                                            sprMefe.MoveRow(moverow, i, 1);
                                            i--;
                                            end--;
                                        }
                                    }
                                }
                            }
                            else
                                sprMefe.MoveRow(moverow, sprMefe.ActiveSheet.ActiveRowIndex, 1);

                            sprMefe.SetActiveRow(moverow);
                            sprMefe.ShowRow(0, moverow, VerticalPosition.Nearest);
                            break;
                    }
                }
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
            }
            finally
            {
                ResumeLayout();
            }
        }

        const UnSetFlag = () => 
        {
            for (let i:number = 0; i < sprMefe.ActiveSheet.RowCount; i++)
            {
                sprMefe.SetText(i, "FLAG", "N");
            }

            SetOrderCheckColor(sprMefe);
        }

        /// <summary>
        /// 처방이 추가 및 변경되었을 때 확인한다.
        /// </summary>
        /// <returns></returns>
        const CheckChangeMefeInfo = () => 
        {
            let PRSC_CD:string = String.Empty;
            let PRSC_LCLS_CD:string = String.Empty;
            let PRSC_MCLS_CD:string = String.Empty;
            let PRSC_CLSF_CD:string = String.Empty;
            let GRP_PRSC_APLY_YN:string = String.Empty;
            let errmsg:string = String.Empty;
            let dt:DataTable = new DataTable();
            let row:number = sprMefe.ActiveSheet.ActiveRowIndex;

            PRSC_CD = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CD").ToString();

            // 처방을 조회한다.
            if (!(await DBService.ExecuteDataTable(SQL.BI.Sql.SelectColumnBIMFCDMA(), /*ref*/ dt
                                                                             , "MEFE_CD"
                                                                             , PRSC_CD
                                                                             , m_OTPT_ADMS_DVCD
                                                                             , m_MDCR_DD)))
            {
                errmsg = "처방 조회 중 오류가 발생했습니다.";
                await LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                SetRowClear(sprMefe, sprMefe.ActiveSheet.ActiveRowIndex);
                return false;
            }

            // 대분류, 중분류, 처방구분코드, 그룹적용여부 설정
            PRSC_LCLS_CD = dt.Rows[0]["PRSC_LCLS_CD"].ToString();
            PRSC_MCLS_CD = dt.Rows[0]["PRSC_MCLS_CD"].ToString();
            PRSC_CLSF_CD = dt.Rows[0]["PRSC_CLSF_CD"].ToString();
            GRP_PRSC_APLY_YN = dt.Rows[0]["GRP_PRSC_APLY_YN"].ToString();

            if (!(PRSC_LCLS_CD == "Z2" && PRSC_MCLS_CD == "Z1"))
            {
                errmsg = "진단서 처방만 입력 가능합니다.";
                await LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                SetRowClear(sprMefe, sprMefe.ActiveSheet.ActiveRowIndex);
                return false;
            }

            sprMefe.SetValue(row, "PID", m_PID);
            sprMefe.SetValue(row, "PT_CMHS_NO", m_PT_CMHS_NO);
            sprMefe.SetValue(row, "MDCR_DD", m_MDCR_DD);
            if (m_OTPT_ADMS_DVCD == "I")
                sprMefe.SetValue(row, "PRSC_DVCD", "I");
            else
                sprMefe.SetValue(row, "PRSC_DVCD", "O");
            sprMefe.SetValue(row, "DLVR_DEPT_CD", dt.Rows[0]["DLVR_DEPT_CD"]);
            sprMefe.SetValue(row, "VIST_PLCE_CD", dt.Rows[0]["VIST_PLCE_CD"]);
            sprMefe.SetValue(row, "PRSC_LCLS_CD", dt.Rows[0]["PRSC_LCLS_CD"]);
            sprMefe.SetValue(row, "PRSC_MCLS_CD", dt.Rows[0]["PRSC_MCLS_CD"]);
            sprMefe.SetValue(row, "PRSC_CD", dt.Rows[0]["MEFE_CD"]);
            sprMefe.SetValue(row, "PRSC_NM", dt.Rows[0]["MEFE_HNM"]);
            sprMefe.SetValue(row, "PRSC_INPT_QTY", "1");
            sprMefe.SetValue(row, "ONTM_QTY", "1");
            sprMefe.SetValue(row, "NOTM", "1");
            sprMefe.SetValue(row, "NODY", "1");
            sprMefe.SetValue(row, "AOMD_UNIT_VALU", StringService.SubString(dt.Rows[0]["CTNT_UNIT_VALU"].ToString() + dt.Rows[0]["SPEC_VALU"].ToString(), 30));

            let pnpyDvcd:string = String.Empty;
            switch (m_INSN_TYCD)
            {
                case "11":
                    pnpyDvcd = dt.Rows[0]["HLNS_PAY_DVCD"].ToString();
                    break;

                case "21":
                case "22":
                    pnpyDvcd = dt.Rows[0]["MDAD_PAY_DVCD"].ToString();
                    break;

                case "31":
                    pnpyDvcd = dt.Rows[0]["INCS_PAY_DVCD"].ToString();
                    break;

                case "41":
                    pnpyDvcd = dt.Rows[0]["TRAI_PAY_DVCD"].ToString();
                    break;

                default:
                    pnpyDvcd = dt.Rows[0]["GNRL_PAY_DVCD"].ToString();
                    break;
            }

            sprMefe.SetValue(row, "PNPY_DVCD", pnpyDvcd);

            sprMefe.SetValue(row, "DC_PRSC_DVCD", "A");
            sprMefe.SetValue(row, "HOPE_DD", m_MDCR_DD);
            sprMefe.SetValue(row, "PRV_ACTG_YN", "N");
            sprMefe.SetValue(row, "RCPT_YN", "N");
            sprMefe.SetValue(row, "CLCL_HOLD_YN", "N");
            sprMefe.SetValue(row, "PWDR_YN", "N");
            sprMefe.SetValue(row, "MOVE_PHTG_YN", "N");
            sprMefe.SetValue(row, "PRSC_CLSF_CD", dt.Rows[0]["PRSC_CLSF_CD"]);
            sprMefe.SetValue(row, "PRSC_APLY_CMHS_NO", m_PT_CMHS_NO);
            sprMefe.SetValue(row, "CNFR_DVCD", dt.Rows[0]["CNFR_DVCD"]);

            ORBizCommon.SetRowMefeData(sprMefe, sprMefe.ActiveSheet.ActiveRowIndex);
            m_EntryOrder.SetPrice(sprMefe,
                                  m_PID,
                                  row,
                                  sprMefe.GetValue(row, "PRSC_CD").ToString(),
                                  m_MDCR_DD,
                                  m_INSN_TYCD,
                                  m_ASST_TYCD,
                                  sprMefe.GetValue(row, "ONTM_QTY").ToString(),
                                  sprMefe.GetValue(row, "NOTM").ToString(),
                                  sprMefe.GetValue(row, "NODY").ToString(),
                                  sprMefe.GetValue(row, "PNPY_DVCD").ToString());
            SetEnterCell();

            return true;
        }

        const SetPostCallPrscNmEditMode = () => 
        {
            sprMefe.EditMode = true;
        }

        const SetPostCallSprDetailFocus = () => 
        {
            let row:number = sprMefe.ActiveSheet.ActiveRowIndex;

            BizCommon.SetRowFocus(sprMefe, row + 1, "PRSC_NM");
            sprMefe.EditModeReplace = true;
            sprMefe.ActiveSheet.ActiveColumn.Locked = false;
            sprMefe.EditMode = true;
        }

        const SetPostCallSprMefe = () => 
        {
            let row:number = sprMefe.ActiveSheet.ActiveRowIndex;

            BizCommon.SetRowFocus(sprMefe, row);
        }

        const sprMefeChangeEvent = () => 
        {
            let tag:string = sprMefe.ActiveSheet.Columns.Get(sprMefe.ActiveSheet.ActiveColumnIndex).Tag.ToString();
            let titlecode:string = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "TITLECODE").ToString();

            if (String.IsNullOrWhiteSpace(m_PID) || String.IsNullOrWhiteSpace(m_PT_CMHS_NO))
            {
                await LxMessage.Show("환자를 먼저 조회하세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return -1;
            }

            if (!(tag == "FLAG" || tag == "PRSC_PCFT" || titlecode == "3"))
                return 1;

            switch (tag)
            {
                case "PRSC_CD":
                case "PRSC_NM":
                    return SetChangeMefeInfo();
                case "PRSC_INPT_QTY":
                    return SetChangeInptQty();
            }

            return 1;
        }
        
        /// <summary>
        /// 처방을 저장한다.
        /// </summary>
        const SaveData = (after_work:boolean = true) => 
        {
            // ChangeExpand 입력중인 이벤트 확인
            if (sprMefeChangeEvent() < 0)
                return false;

            try
            {
                let dt:DataTable = new DataTable();

                if (m_OTPT_ADMS_DVCD == "I")
                {
                    if (!await DBService.ExecuteDataTable(SQL.OR.Sql.SelectOPPatientInfoI(), /*ref*/ dt, m_PID, m_PT_CMHS_NO, PatientInfo.SRRN_ECPT, m_MDCR_DD))
                        throw new Error("환자 입원정보를 조회하는 중 에러가 발생했습니다.");

                    if (dt.Rows.Count.Equals(0))
                    {
                        await LxMessage.ShowError("환자 입원정보가 없어 저장할 수 없습니다.");
                        return false;
                    }

                    if (dt.Rows[0]["STHS_DSCH_DVCD"].ToString() == "T")
                    {
                        await LxMessage.ShowError("퇴원환자 입니다.\r\n처방을 삭제할 수 없습니다.");
                        return false;
                    }

                    let dsch_dd:string = dt.Rows[0]["DSCH_DD"].ToString();

                    if ((dt.Rows[0]["ADMS_DD"].ToString().CompareTo(dteMdcrDate.Text.Replace("-", String.Empty)) > 0) ||
                        (dsch_dd.CompareTo(dteMdcrDate.Text.Replace("-", String.Empty)) < 0))
                    {
                        await LxMessage.ShowError("입원기간을 확인하세요.\r\n입원기간에 맞게 처방일자를 선택하세요.");
                        return false;
                    }

                    // 퇴원일자가 정해졌는데 퇴원일자 외의 처방을 수정하려고 하는 경우는, 불가 메시지를 띄운다.
                    if (await ConfigService.GetConfigValueDirect("PA", "RECEIPT_DSCH", "SAVE_PRSC_ONLY_DSCH_DD", false))
                    {
                        if (dsch_dd != "29991231" && dsch_dd != dteMdcrDate.DateTime.ToString("yyyyMMdd") &&
                            !clsNRCommon.CheckSaveData_PAAREBMA(m_PID, m_PT_CMHS_NO, dteMdcrDate.DateTime.ToString("yyyyMMdd"), true))
                        {
                            //await LxMessage.ShowError("퇴원일이 확정된 경우, 퇴원일 처방만 수정 가능합니다.\r\n퇴원일 외의 처방은 심사과에 수정 요청해 주세요.\r\n(퇴원일 확정시 퇴원일 이전 처방은 심사 중 또는 완료되었기 때문)");
                            return false;
                        }
                    }
                }
                else if (m_OTPT_ADMS_DVCD == "O")
                {
                    if (!await DBService.ExecuteDataTable(SQL.OR.Sql.SelectOPPatientInfoO(), /*ref*/ dt, m_PID, m_PT_CMHS_NO, PatientInfo.SRRN_ECPT, m_MDCR_DD))
                        throw new Error("환자 내원정보를 조회하는 중 에러가 발생했습니다.");

                    if (dt.Rows.Count.Equals(0))
                    {
                        await LxMessage.ShowError("환자 내원정보가 없어 저장할 수 없습니다.");
                        return false;
                    }
                }

                Enabled = false;

                let error_dvcd:string = String.Empty;
                let error_cnts:string = String.Empty;

                let sqno:number = 0;
                let pickup:DataTable = new DataTable();

                let dlwtuniqno:string = "";
                let errmsg:string = "";
                let prsc_inpt_dvcd:string = m_OTPT_ADMS_DVCD.Equals("I") ? "99" : "00";
                let currentdate:string = DateTime.Now.ToString("yyyyMMddHHmmss");

                // DBService.BeginTransaction ();

                // 입원 처방저장
                if (!m_EntryOrder.SaveORORDRRT(sprMefe, "PA_SAVE_CERTIFICATE", m_OTPT_ADMS_DVCD, m_PID, m_PT_CMHS_NO, m_MDCR_DD, prsc_inpt_dvcd, m_MDCR_DEPT_CD, m_MDCR_DR_CD, m_MDCR_DR_CD, m_WARD_CD, m_MAIN_SUB_ADMS_DVCD, "N", "", currentdate, /*ref*/ errmsg))
                    throw new Error($"처방 저장 중 에러가 발생했습니다.\r\n{errmsg}");

                if (m_OTPT_ADMS_DVCD == "I")
                {
                    if (!await DBService.ExecuteDataTable(SQL.OR.Sql.SelectPickUpORORDRRT("ETC"), /*ref*/ pickup, m_PID, m_PT_CMHS_NO, currentdate, DOPack.UserInfo.USER_CD))
                        throw new Error("자동 픽업할 내역을 조회하는 중 에러가 발생했습니다.");

                    if (pickup.Rows.Count > 0)
                    {
                        for (let i:number = 0; i < pickup.Rows.Count; i++)
                        {
                            let prsc_sqno:string = pickup.Rows[i]["PRSC_SQNO"].ToString();

                            sqno++;

                            if (!ORBizCommon.InsertORSQTPIFSub(m_PID, m_PT_CMHS_NO, pickup.Rows[i]["MDCR_DD"].ToString(), "PICKUP", /*ref*/ dlwtuniqno, sqno.ToString(), prsc_sqno, currentdate))
                                throw new Error("자동 픽업내역을 임시테이블에 저장하는 중 에러가 발생했습니다.");
                        }

                        // 전자서명
                        if (!EMBizCommon.SetESignOrderPickUp(m_PID, dlwtuniqno, /*ref*/ errmsg))
                            throw new Error($"전자서명 중 에러가 발생했습니다.\r\n[EMBizCommon.SetESignOrderPickUp]\r\n{errmsg}");

                        // 픽업 진행
                        if (!Procedure.PR_NR_PRC_PCUPPRC(m_PID                      // 환자등록번호
                                                              , m_PT_CMHS_NO               // 환자내원번호
                                                              , m_WARD_CD                  // 병동코드
                                                              , dlwtuniqno.ToString()    // 픽업의뢰고유번호
                                                              , currentdate                // 픽업일시
                                                              , m_MDCR_DR_CD             // 픽업자
                                                              , m_MDCR_DEPT_CD           // 픽업부서(주부서)
                                                              , /*ref*/ error_dvcd            // 에러Flag
                                                              , /*ref*/ error_cnts))          // 에러내용
                            throw new Error("자동 픽업 중 에러가 발생했습니다.");

                        if (!String.IsNullOrWhiteSpace(error_dvcd))
                            throw new Error($"자동 픽업 중 에러가 발생했습니다.\r\n  - 에러코드 : {error_dvcd}\r\n{error_cnts}");
                    }
                }

                // 최종 저장한다.
                // DBService.CommitTransaction ();

                if (m_OTPT_ADMS_DVCD == "I")
                {
                    if (!String.IsNullOrWhiteSpace(dlwtuniqno))
                        clsNRPickupProcess.CheckPickupInfo(m_PID, m_PT_CMHS_NO, dlwtuniqno);
                }

                await LxMessage.ShowInformation("저장 되었습니다.", 3);

                m_IsSaved = true;

                SelectData();
                return true;
            }
            catch (ex)
            {
                let error:string = DBService.HasError ? String.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                // if(DBService.IsTransaction)
                    // DBService.RollbackTransaction();

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                await LxMessage.ShowError(ex.Message + error);
                return false;
            }
            finally
            {
                Enabled = true;
            }
        }

        // #endregion Method : Private Method

        // #region Event : Event Process

        const sprMefe_MouseDown = (sender:object, MouseEventArgs e) => 
        {
            m_MouseOrKeyBoardArrow = true;
        }

        const sprMefe_ChangeExpand = (sender:object, ChangeExpandEventArgs e) => 
        {
            let old_prsc_cd:string = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "OLD_PRSC_CD").ToString();
            let prsc_cd:string = String.Empty;
            let tag:string = sprMefe.ActiveSheet.Columns.Get(sprMefe.ActiveSheet.ActiveColumnIndex).Tag.ToString();
            let titlecode:string = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "TITLECODE").ToString();
            let event_dvcd:number = 0;
            let row:number = sprMefe.ActiveSheet.ActiveRowIndex;

            event_dvcd = sprMefeChangeEvent();

            switch (tag)
            {
                case "PRSC_DVCD":
                    if (event_dvcd == -1)
                        e.HoldFocus = true;
                    break;
                case "PRSC_CD":
                case "PRSC_NM":

                    SetMefeAutoCompleteView(false);

                    if (event_dvcd == -1)
                    {
                        e.HoldFocus = true;
                        if (tag == "PRSC_NM")
                            PostCallService.PostCall(SetPostCallPrscNmEditMode);
                    }
                    else
                    {
                        if (!m_MouseOrKeyBoardArrow)
                        {
                            if (await ConfigService.GetConfigValueString("OR", "FOCUS_MOVE", "ROW_MOVE") == "Y")
                            {
                                e.HoldFocus = true;
                                row = GetAppendRow(sprMefe);
                                sprMefe.SetActiveCell(row, "PRSC_NM");
                                sprMefe.ShowRow(0, row, VerticalPosition.Nearest);
                                sprMefe.ActiveSheet.AddSelection(row, 0, 1, sprMefe.ActiveSheet.ColumnCount);
                                PostCallService.PostCall(SetPostCallPrscNmEditMode);
                            }
                            else
                            {
                                prsc_cd = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CD").ToString();

                                if (String.IsNullOrWhiteSpace(old_prsc_cd) && !String.IsNullOrWhiteSpace(prsc_cd))
                                {
                                    e.HoldFocus = true;
                                    BizCommon.SetRowFocus(sprMefe, row, "PRSC_INPT_QTY");
                                }
                                m_MouseOrKeyBoardArrow = false;
                            }
                        }
                    }
                    break;
                case "PRSC_INPT_QTY":
                    if (event_dvcd == -1)
                        e.HoldFocus = true;
                    else
                    {
                        m_EntryOrder.SetPrice(sprMefe,
                                                  m_PID,
                                                  row,
                                                  sprMefe.GetValue(row, "PRSC_CD").ToString(),
                                                  m_MDCR_DD,
                                                  m_INSN_TYCD,
                                                  m_ASST_TYCD,
                                                  sprMefe.GetValue(row, "ONTM_QTY").ToString(),
                                                  sprMefe.GetValue(row, "NOTM").ToString(),
                                                  sprMefe.GetValue(row, "NODY").ToString(),
                                                  sprMefe.GetValue(row, "PNPY_DVCD").ToString());

                        if (!m_MouseOrKeyBoardArrow)
                        {
                            e.HoldFocus = true;
                            BizCommon.SetRowFocus(sprMefe, row, "NOTM");
                            m_MouseOrKeyBoardArrow = false;
                        }
                    }
                    break;
                case "NOTM":
                    if (event_dvcd == -1)
                        e.HoldFocus = true;

                    m_EntryOrder.SetPrice(sprMefe,
                                          m_PID,
                                          row,
                                          sprMefe.GetValue(row, "PRSC_CD").ToString(),
                                          m_MDCR_DD,
                                          m_INSN_TYCD,
                                          m_ASST_TYCD,
                                          sprMefe.GetValue(row, "ONTM_QTY").ToString(),
                                          sprMefe.GetValue(row, "NOTM").ToString(),
                                          sprMefe.GetValue(row, "NODY").ToString(),
                                          sprMefe.GetValue(row, "PNPY_DVCD").ToString());
                    break;
                case "NODY":
                    m_EntryOrder.SetPrice(sprMefe,
                                          m_PID,
                                          row,
                                          sprMefe.GetValue(row, "PRSC_CD").ToString(),
                                          m_MDCR_DD,
                                          m_INSN_TYCD,
                                          m_ASST_TYCD,
                                          sprMefe.GetValue(row, "ONTM_QTY").ToString(),
                                          sprMefe.GetValue(row, "NOTM").ToString(),
                                          sprMefe.GetValue(row, "NODY").ToString(),
                                          sprMefe.GetValue(row, "PNPY_DVCD").ToString());
                    break;
                case "AOMD_MTHD_CD":
                    if (event_dvcd == -1)
                        e.HoldFocus = true;
                    break;
                case "EXCP_RESN_CD":
                    if (event_dvcd == -1)
                        e.HoldFocus = true;
                    break;
                case "PNPY_DVCD":
                    if (event_dvcd == -1)
                        e.HoldFocus = true;
                    break;
                case "PRSC_PCFT":
                    if (event_dvcd == -1)
                        e.HoldFocus = true;
                    break;
            }
            SetEnterCell();
        }

        const sprMefe_EnterCell = (sender:object, FarPoint.Win.Spread.EnterCellEventArgs e) => 
        {
            SetEnterCell();
        }

        const sprMefe_CellClick = (sender:object, e /*FarPoint.Win.Spread.CellClickEventArgs*/) => 
        {
            let tag:string = String.Empty;

            tag = sprMefe.ActiveSheet.Columns.Get(e.Column).Tag.ToString();

            if (e.ColumnHeader)
                e.Cancel = true;

            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                //sprMefe.SetActiveRow(e.Row);
                BizCommon.SetRowFocus(sprMefe, e.Row);
                sprMefe.ActiveSheet.AddSelection(e.Row, 0, 1, sprMefe.ActiveSheet.ColumnCount);

                ShowContextMenu("SET_PAORDERPOP");
            }
            else if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                if (Control.ModifierKeys == Keys.Control)
                {
                    if (tag == "FLAG")
                        return;

                    let flag:string = String.Empty;

                    flag = sprMefe.GetValue(e.Row, "FLAG").ToString();

                    if (flag == "Y")
                        sprMefe.SetText(e.Row, "FLAG", "N");
                    else
                        sprMefe.SetText(e.Row, "FLAG", "Y");

                    SetOrderCheckColor(sprMefe);
                }
                else
                {
                    m_MouseOrKeyBoardArrow = true;

                    if (e.ColumnHeader)
                    {
                        PostCallService.PostCall(SelectionClear);

                        switch (tag)
                        {
                            // 횟수
                            case "NOTM":
                                ShowContextMenu("HEADER_NOTM");
                                break;
                            // 일수
                            case "NODY":
                                ShowContextMenu("HEADER_NODY");
                                break;
                            // 믹스구분
                            case "MIX_YN":
                                m_EntryOrder.SetMix(sprMefe);
                                break;
                            // 선택 타이틀
                            case "FLAG":
                                SetFlagColumn();
                                break;
                            // TEL ORDER
                            case "TEL_PRSC_FLAG":
                                SetTelOrder();
                                break;
                        }
                    }
                    else
                    {
                        switch (tag)
                        {
                            case "MSG_VIEW":
                                let hgrs_mdpr_dvcd:string = String.Empty;
                                let hgal_mdpr_dvcd:string = String.Empty;

                                if (sprMefe.ActiveSheet.RowCount <= 0)
                                    return;

                                hgrs_mdpr_dvcd = sprMefe.GetValue(e.Row, "HGRS_MDPR_DVCD").ToString();
                                hgal_mdpr_dvcd = sprMefe.GetValue(e.Row, "HGAL_MDPR_DVCD").ToString();

                                if (sprMefe.GetValue(e.Row, "MSG_DVCD").ToString() == "Y" || (!String.IsNullOrWhiteSpace(hgrs_mdpr_dvcd) || hgrs_mdpr_dvcd != "N") || (!String.IsNullOrWhiteSpace(hgal_mdpr_dvcd) || hgal_mdpr_dvcd != "N"))
                                    PostCallService.PostCall(SetPopMefeMessage);

                                break;
                        }

                    }
                }
            }

            SetEnterCell();
        }

        const sprMefe_ButtonClicked = (sender:object, e /*FarPoint.Win.Spread.EditorNotifyEventArgs*/) => 
        {
            let tag:string = sprMefe.ActiveSheet.Columns.Get(sprMefe.ActiveSheet.ActiveColumnIndex).Tag.ToString();
            let titlecode:string = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "TITLECODE").ToString();
            let PRSC_INPT_DVCD:string = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_INPT_DVCD").ToString();
            let PRSC_LCLS_CD:string = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_LCLS_CD").ToString();
            let PRSC_MCLS_CD:string = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_MCLS_CD").ToString();
            let prsc_cd:string = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CD").ToString();
            let data:string = String.Empty;
            let errmsg:string = String.Empty;
            let otptadmsrecinfo = null;

            // 외래, 입원정보를 불러온다.
            otptadmsrecinfo = m_EntryOrder.GetOtptAdmsRecInfo(m_OTPT_ADMS_DVCD, m_PID, Int.Parse(m_PT_CMHS_NO), m_MDCR_DD, /*ref*/ errmsg);
            if (otptadmsrecinfo == null)
            {
                if (String.IsNullOrWhiteSpace(errmsg))
                {
                    errmsg = "환자 접수정보 조회 중 오류가 발생했습니다.";
                    await LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                return;
            }

            let row:number = 0;

            let dt:DataTable = new DataTable();

            // 체크박스 설정
            if (tag == "FLAG")
            {
                data = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "FLAG").ToString();
                switch (titlecode)
                {
                    case "0":
                        for (let i:number = 0; i < sprMefe.ActiveSheet.RowCount; i++)
                        {
                            if (PRSC_INPT_DVCD == sprMefe.GetValue(i, "PRSC_INPT_DVCD").ToString())
                            {
                                sprMefe.SetText(i, "FLAG", data);

                                // 2018-07-09 김남훈 속도로 인한 하드코딩
                                if (data == "Y")
                                    sprMefe.ActiveSheet.Rows[i].BackColor = Color.LightSteelBlue;
                                else
                                    sprMefe.ActiveSheet.Rows[i].BackColor = sprMefe.ActiveSheet.Cells[i, sprMefe.ActiveSheet.Columns["PID"].Index].BackColor;
                            }
                        }
                        break;
                    case "1":
                        for (let i:number = 0; i < sprMefe.ActiveSheet.RowCount; i++)
                        {
                            if (PRSC_LCLS_CD == sprMefe.GetValue(i, "PRSC_LCLS_CD").ToString() && PRSC_INPT_DVCD == sprMefe.GetValue(i, "PRSC_INPT_DVCD").ToString())
                            {
                                sprMefe.SetText(i, "FLAG", data);

                                // 2018-07-09 김남훈 속도로 인한 하드코딩
                                if (data == "Y")
                                    sprMefe.ActiveSheet.Rows[i].BackColor = Color.LightSteelBlue;
                                else
                                    sprMefe.ActiveSheet.Rows[i].BackColor = sprMefe.ActiveSheet.Cells[i, sprMefe.ActiveSheet.Columns["PID"].Index].BackColor;
                            }
                        }
                        break;

                    case "2":
                        for (let i:number = 0; i < sprMefe.ActiveSheet.RowCount; i++)
                        {
                            if (PRSC_LCLS_CD == sprMefe.GetValue(i, "PRSC_LCLS_CD").ToString() && PRSC_MCLS_CD == sprMefe.GetValue(i, "PRSC_MCLS_CD").ToString())
                            {
                                sprMefe.SetText(i, "FLAG", data);

                                // 2018-07-09 김남훈 속도로 인한 하드코딩
                                if (data == "Y")
                                    sprMefe.ActiveSheet.Rows[i].BackColor = Color.LightSteelBlue;
                                else
                                    sprMefe.ActiveSheet.Rows[i].BackColor = sprMefe.ActiveSheet.Cells[i, sprMefe.ActiveSheet.Columns["PID"].Index].BackColor;
                            }
                        }
                        break;
                }

                sprMefe.ActiveSheet.Rows[e.Row].BackColor = sprMefe.GetValue(e.Row, "FLAG").ToString().Equals("Y") ? 
                                                            Color.LightSteelBlue : 
                                                            sprMefe.ActiveSheet.Cells[e.Row, sprMefe.ActiveSheet.Columns["PID"].Index].BackColor;
            }
            // 프리오더 설정
            else if (tag == "FREE_PRSC_CD")
            {
                let prsc_dvcd:string = String.Empty;

                row = sprMefe.ActiveSheet.ActiveRowIndex;
                prsc_dvcd = sprMefe.GetValue(row, "PRSC_DVCD").ToString();

                if (!String.IsNullOrWhiteSpace(prsc_cd))
                {
                    sprMefe.SetText(row, "FREE_PRSC_CD", "N");
                    return;
                }

                data = sprMefe.GetValue(row, "FREE_PRSC_CD").ToString();
                if (data == "Y")
                {
                    OrderOpinionService opinion = new OrderOpinionService();
                    if (!m_EntryOrder.SetMefeInfoAppendData(this, sprMefe, row, DOPack.PatientInfo, otptadmsrecinfo, SystemCode, m_PID, Int.Parse(m_PT_CMHS_NO), m_OTPT_ADMS_DVCD, m_OTPT_ADMS_DVCD,
                                                           m_MDCR_DD, m_MDCR_DEPT_CD, "-", "", m_OTPT_ADMS_DVCD, "", "N", "1", 1, 1, 1, "", "", "", "N", "", "", "Y", "Y", "", "", Int.Parse(m_PT_CMHS_NO), "FREE", "99", true, /*ref*/ opinion, /*ref*/ errmsg))
                    {
                        await LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        SetRowClear(sprMefe, row);
                        return;
                    }

                    sprMefe.SetText(row, "PRSC_NM", "");

                    if (prsc_dvcd == "S")
                        sprMefe.SetText(row, "PRSC_DVCD", prsc_dvcd);

                    BizCommon.SetRowFocus(sprMefe, row, "PRSC_NM");
                    sprMefe.EditModeReplace = false;
                    sprMefe.EditMode = true;
                }
                else
                {
                    SetRowClear(sprMefe, row);
                }

                SetEnterCell();
            }
            // 파우더구분 설정
            else if (tag == "PWDR_YN")
            {
                SetChangePowder();
            }
            else if (tag == "MOVE_PHTG_YN")
            {
                SetChangeMovePhotograph();
            }
            // TEL ORDER 설정
            else if (tag == "TEL_PRSC_FLAG")
            {
                let tel_prsc_flag:string = String.Empty;
                let pcup_yn:string = String.Empty;
                let dc_prsc_dvcd:string = String.Empty;

                row = sprMefe.ActiveSheet.ActiveRowIndex;

                tel_prsc_flag = sprMefe.GetOldValue(row, "TEL_PRSC_FLAG").ToString();

                // 간호사
                if (StringService.SubString(DOPack.UserInfo.OCTY_DVCD, 1) == "N")
                {
                    if (tel_prsc_flag == "Y")
                    {
                        prsc_cd = sprMefe.GetValue(row, "PRSC_CD").ToString();

                        if (String.IsNullOrWhiteSpace(prsc_cd) || String.IsNullOrWhiteSpace(PRSC_LCLS_CD))
                        {
                            sprMefe.SetText(row, "TEL_PRSC_FLAG", tel_prsc_flag);
                            return;
                        }

                        pcup_yn = sprMefe.GetValue(row, "PCUP_YN").ToString();
                        dc_prsc_dvcd = sprMefe.GetValue(row, "DC_PRSC_DVCD").ToString();

                        if (String.IsNullOrWhiteSpace(pcup_yn))
                            pcup_yn = "N";
                        if (String.IsNullOrWhiteSpace(dc_prsc_dvcd))
                            dc_prsc_dvcd = "A";

                        if (pcup_yn == "Y" || dc_prsc_dvcd != "A")
                        {
                            sprMefe.SetText(row, "TEL_PRSC_FLAG", tel_prsc_flag);
                            return;
                        }
                    }
                }
                else
                {
                    sprMefe.SetText(row, "TEL_PRSC_FLAG", tel_prsc_flag);
                    return;
                }
            }
            // 선수행 설정
            else if (tag == "PRV_ACTG_YN")
            {
                SetChangePrvActgYn();
            }
        }

        const sprMefe_DialogKey = (sender:object, FarPoint.Win.Spread.DialogKeyEventArgs e) => 
        {
            let prsc_cd:string = String.Empty;
            let tag:string = sprMefe.ActiveSheet.Columns.Get(sprMefe.ActiveSheet.ActiveColumnIndex).Tag.ToString();
            let row:number = sprMefe.ActiveSheet.ActiveRowIndex;

            if (e.KeyCode == Keys.Down || e.KeyCode == Keys.Up)
            {
                if (m_Mefe_AutoComplete && ucMefeAutoComplete1.Visible == true)
                {
                    e.Handled = true;

                    if (e.KeyCode == Keys.Up)
                        return;

                    if (ucMefeAutoComplete1.RowCount > 1 && ucMefeAutoComplete1.GetRow() + 1 < ucMefeAutoComplete1.RowCount)
                    {
                        ucMefeAutoComplete1.SetRow(ucMefeAutoComplete1.GetRow() + 1);
                        ucMefeAutoComplete1.AddSelection(ucMefeAutoComplete1.GetRow());
                    }

                    ucMefeAutoComplete1.Focus();
                }
                else
                    m_MouseOrKeyBoardArrow = true;
            }
            else if (e.KeyCode == Keys.Enter)
            {
                if (m_Mefe_AutoComplete && ucMefeAutoComplete1.Visible == true)
                {
                    prsc_cd = ucMefeAutoComplete1.GetString(ucMefeAutoComplete1.GetRow(), "MEFE_CD");

                    if (String.IsNullOrWhiteSpace(prsc_cd))
                        return;

                    sprMefe.SetText(row, "PRSC_CD", prsc_cd);

                    CheckChangeMefeInfo();
                }
                else
                {
                    if (tag == "NODY")
                    {
                        // 일수 Enter 시 다음 입력 Row설정
                        if (!m_MouseOrKeyBoardArrow)
                        {
                            if (m_EntryOrder.GetFindAppendRow(sprMefe) == row + 1)
                            {
                                PostCallService.PostCall(SetPostCallSprDetailFocus);
                                m_MouseOrKeyBoardArrow = false;
                            }
                        }
                    }
                }
            }
            else
            {
                if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down || e.KeyCode == Keys.Right || e.KeyCode == Keys.Left)
                    m_MouseOrKeyBoardArrow = true;
                else if (e.KeyCode == Keys.Escape)
                {
                    if (m_Mefe_AutoComplete && ucMefeAutoComplete1.Visible == true)
                    {
                        sprMefe.SetText(row, "PRSC_CD", "");
                        sprMefe.SetText(row, "PRSC_NM", "");
                    }

                    UnSetFlag();
                    sprMefe.ActiveSheet.AddSelection(sprMefe.ActiveSheet.ActiveRowIndex, 0, 1, sprMefe.ActiveSheet.Columns.Count);
                    SetMefeAutoCompleteView(false);
                }
                else if (e.KeyCode == Keys.Delete)
                {
                    DeleteOrderData();
                    sprMefe.ActiveSheet.ClearSelection();
                    SetEnterCell();
                }
                else
                {
                    m_MouseOrKeyBoardArrow = false;
                }
            }
        }

        const sprMefe_CellDoubleClick = (sender:object, e /*FarPoint.Win.Spread.CellClickEventArgs*/) => 
        {
            let errmsg:string = String.Empty;
            let tag:string = sprMefe.ActiveSheet.Columns.Get(sprMefe.ActiveSheet.ActiveColumnIndex).Tag.ToString();
            let titlecode:string = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "TITLECODE").ToString();
            let data:string = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, tag).ToString();
            let PRSC_CLSF_CD:string = String.Empty;

            if (!(tag == "FLAG" || titlecode == "3"))
                return;

            switch (tag)
            {
                case "AOMD_MTHD_CD":

                    if (m_EntryOrder.CheckBeforeInputCpctNotmIotm(sprMefe, Name, "S", /*ref*/ PRSC_CLSF_CD, /*ref*/ errmsg))
                    {
                        if (!(SetMediUsageInfo(PRSC_CLSF_CD, /*ref*/ errmsg)))
                        {
                            //await LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            //e.Cancel = true;
                        }
                    }
                    else
                    {
                        await LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        e.Cancel = true;
                    }
                    UnSetFlag();
                    break;
                case "EXCP_RESN_CD":

                    if (m_EntryOrder.CheckBeforeInputCpctNotmIotm(sprMefe, Name, "S", /*ref*/ PRSC_CLSF_CD, /*ref*/ errmsg))
                    {
                        if (!(SetExcepCdInfo(PRSC_CLSF_CD, /*ref*/ errmsg)))
                        {
                            //await LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            //e.Cancel = true;
                        }
                    }
                    else
                    {
                        await LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        e.Cancel = true;
                    }
                    UnSetFlag();
                    break;
            }
        }

        const sprMefe_TextTipFetch = (sender:object, e /*FarPoint.Win.Spread.TextTipFetchEventArgs*/) => 
        {
            try
            {
                let tag:string = sprMefe.ActiveSheet.Columns.Get(e.Column).Tag.ToString();
                let aomd_mthd_cd:string = sprMefe.GetValue(e.Row, "AOMD_MTHD_CD").ToString();
                let orig_aomd_mthd_cd:string = sprMefe.GetValue(e.Row, "ORIG_AOMD_MTHD_CD").ToString();
                let prsc_clsf_cd:string = sprMefe.GetValue(e.Row, "PRSC_CLSF_CD").ToString();
                let excp_resn_cd:string = String.Empty;
                let prsc_lcls_cd:string = String.Empty;

                let dt:DataTable = new DataTable();
                let or_dt:DataTable = new DataTable();

                if (e.ColumnHeader)
                    return;
                if (e.ColumnFooter)
                    return;
                if (e.RowHeader)
                    return;

                if (tag == "AOMD_MTHD_CD")
                {
                    if (String.IsNullOrWhiteSpace(aomd_mthd_cd))
                        return;

                    e.ShowTip = true;
                    e.View.TextTipAppearance.Font = new Font("맑은 고딕", 10f, FontStyle.Bold);
                    e.View.TextTipAppearance.ForeColor = Color.Black;

                    if (!await DBService.ExecuteDataTable(SQL.OR.Sql.SelectColumnPMMTHDMA(), /*ref*/ dt
                                                                                    , aomd_mthd_cd
                                                                                    , prsc_clsf_cd))
                        return;

                    if (dt.Rows.Count <= 0)
                        return;

                    if (dt.Rows[0]["AOMD_MTHD_CD"].ToString().Contains("APC"))
                    {
                        if (!String.IsNullOrWhiteSpace(orig_aomd_mthd_cd))
                        {
                            if (!await DBService.ExecuteDataTable(SQL.OR.Sql.SelectColumnPMMTHDMA(), /*ref*/ or_dt
                                                                                             , orig_aomd_mthd_cd
                                                                                             , prsc_clsf_cd))
                                return;

                            if (or_dt.Rows.Count <= 0)
                                e.TipText = dt.Rows[0]["AOMD_MTHD_NM"].ToString() + " / 없는 용법";

                            e.TipText = dt.Rows[0]["AOMD_MTHD_NM"].ToString() + " / " + or_dt.Rows[0]["AOMD_MTHD_NM"].ToString();
                        }
                        else
                            e.TipText = dt.Rows[0]["AOMD_MTHD_NM"].ToString() + " / 입력안됨";
                    }
                    else
                        e.TipText = dt.Rows[0]["AOMD_MTHD_NM"].ToString();
                }
                // 2018-05-29 박민규 그룹수가 표시
                // 2018-10-12 김남훈 처방코드일때만 보험정보가 보이게 설정
                else if (tag == "PRSC_CD" || tag == "PRSC_NM")
                {
                    m_EntryOrder.TextTipGroupDetailCode(sprMefe, e, "PRSC_CD", tag, m_MDCR_DD);
                }
                else if (tag == "PNPY_DVCD")
                {
                    let pnpy_dvcd:string = String.Empty;
                    let pnpy_dvcd_nm:string = String.Empty;
                    let i100_usch_cd:string = String.Empty;

                    pnpy_dvcd = sprMefe.GetValue(e.Row, "PNPY_DVCD").ToString();

                    pnpy_dvcd_nm = await DBService.ExecuteScalar(Function.SelectFN_BI_READ_BICDINDT(), "PAY_NOPY_DVCD", pnpy_dvcd, m_MDCR_DD, "LWRN_OVRL_CDNM").ToString();

                    // 보험100일 때 보험100/50, 100/80 표시
                    if (pnpy_dvcd == "2")
                    {
                        i100_usch_cd = sprMefe.GetValue(e.Row, "I100_USCH_CD").ToString();

                        if (i100_usch_cd == "01" || i100_usch_cd == "02")
                        {
                            if (!await DBService.ExecuteDataTable(SQL.OR.Sql.SelectBICICDMA(), /*ref*/ dt, i100_usch_cd, m_MDCR_DD))
                                return;

                            if (dt.Rows.Count > 0)
                                pnpy_dvcd_nm += "(" + dt.Rows[0]["SCNG_PAY_CDNM"].ToString() + ")";
                        }

                    }

                    e.ShowTip = true;
                    e.View.TextTipAppearance.Font = new Font("맑은 고딕", 10f, FontStyle.Bold);
                    e.View.TextTipAppearance.ForeColor = Color.Black;
                    e.TipText = pnpy_dvcd_nm;
                }
                else if (tag == "PRV_ACTG_YN")
                {
                    let prv_actg_yn:string = sprMefe.GetValue(e.Row, "PRV_ACTG_YN").ToString();
                    let rcpt_yn:string = sprMefe.GetValue(e.Row, "RCPT_YN").ToString();
                    let ptaf_clcl_aply_yn:string = sprMefe.GetValue(e.Row, "PTAF_CLCL_APLY_YN").ToString();

                    if (rcpt_yn == "Y" || ptaf_clcl_aply_yn == "Y" || prv_actg_yn == "Y")
                    {
                        e.ShowTip = true;
                        e.View.TextTipAppearance.Font = new Font("맑은 고딕", 10f, FontStyle.Bold);
                        e.View.TextTipAppearance.ForeColor = Color.Black;
                        e.TipText = "외래에서 시행된 처방입니다.";
                    }
                }
                else if (tag == "EXCP_RESN_CD")
                {
                    if (m_OTPT_ADMS_DVCD == "O")
                    {
                        prsc_lcls_cd = sprMefe.GetValue(e.Row, "PRSC_LCLS_CD").ToString();

                        if (prsc_lcls_cd == "20" || prsc_lcls_cd == "30")
                        {
                            excp_resn_cd = sprMefe.GetValue(e.Row, "EXCP_RESN_CD").ToString();

                            if (excp_resn_cd == "NO")
                            {
                                e.ShowTip = true;
                                e.View.TextTipAppearance.Font = new Font("맑은 고딕", 10f, FontStyle.Bold);
                                e.View.TextTipAppearance.ForeColor = Color.Black;
                                e.TipText = "원외 처방입니다.";
                            }
                            else
                            {
                                e.ShowTip = true;
                                e.View.TextTipAppearance.Font = new Font("맑은 고딕", 10f, FontStyle.Bold);
                                e.View.TextTipAppearance.ForeColor = Color.Black;
                                e.TipText = "원내 처방입니다.";
                            }
                        }
                    }
                }
            }
            catch (ex)
            {
                LogService.ErrorLog(ex.Message);
                return;
            }
        }

        const sprMefe_SelectionChanged = (sender:object, SelectionChangedEventArgs e) => 
        {
            //sprMefe.ButtonClicked += sprMefe_ButtonClicked;

            //m_SelectionDvcd = false;

            let flag:string = String.Empty;

            if (e.Range.RowCount <= 1)
            {
                if (!m_SelectionDvcd)
                    return;
            }

            UnSetFlag();

            for (let i:number = e.Range.Row; i < e.Range.Row + e.Range.RowCount; i++)
            {
                flag = sprMefe.GetValue(i, "FLAG").ToString();

                if (flag == "Y")
                    continue;

                sprMefe.SetText(i, "FLAG", "Y");
            }

            SetOrderCheckColor(sprMefe);

            m_SelectionDvcd = false;
        }

        const sprMefe_SelectionChanging = (sender:object, SelectionChangingEventArgs e) => 
        {
            let flag:string = String.Empty;

            if (e.Range.RowCount <= 1)
                return;
            else if (e.Range.RowCount == 2)
                m_SelectionDvcd = true;

            UnSetFlag();

            for (let i:number = e.Range.Row; i < e.Range.Row + e.Range.RowCount; i++)
            {
                flag = sprMefe.GetValue(i, "FLAG").ToString();

                if (flag == "Y")
                    continue;

                sprMefe.SetText(i, "FLAG", "Y");
            }

            SetOrderCheckColor(sprMefe);
        }

        const sprMefe_EditModeOn = (sender:object, e) => 
        {
            KeyEventHandler keyup = sprMefe_KeyUp;
            sprMefe.EditingControl.ImeMode = sprMefe.ImeMode;
            sprMefe.EditingControl.KeyUp += keyup;
            //sprMefe.EditingControl.DoubleClick += EditingControl_DoubleClick;
        }

        const sprMefe_EditModeOff = (sender:object, e) => 
        {
            KeyEventHandler keyup = sprMefe_KeyUp;
            sprMefe.EditingControl.KeyUp -= keyup;
            //sprMefe.EditingControl.DoubleClick -= EditingControl_DoubleClick;
        }

        const sprMefe_KeyUp = (sender:object, e /*KeyEventArgs*/) => 
        {
            let prsc_cd:string = String.Empty;
            let prsc_nm:string = String.Empty;
            let def_row:string = String.Empty;
            let tag:string = sprMefe.ActiveSheet.Columns.Get(sprMefe.ActiveSheet.ActiveColumnIndex).Tag.ToString();

            if (!m_Mefe_AutoComplete)
                return;

            // 2018-08-28 처방 자동완성기능 추가
            if (tag == "PRSC_CD" || tag == "PRSC_NM")
            {
                if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Left || e.KeyCode == Keys.Right || e.KeyCode == Keys.Up || e.KeyCode == Keys.Down || e.KeyCode == Keys.Tab)
                    return;

                //e.KeyChar
                prsc_cd = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CD").ToString();
                prsc_nm = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_NM").ToString();
                def_row = sprMefe.GetValue(sprMefe.ActiveSheet.ActiveRowIndex, "DEF_ROW").ToString();

                if (def_row != "Y")
                    return;

                if (tag == "PRSC_CD")
                {
                    if (String.IsNullOrWhiteSpace(prsc_cd))
                    {
                        SetMefeAutoCompleteView(false);
                        return;
                    }

                    ucMefeAutoComplete1.SelectAutoCompleteData(m_MDCR_DD, m_OTPT_ADMS_DVCD, "MEFE_CD", prsc_cd);
                }
                if (tag == "PRSC_NM")
                {
                    if (prsc_cd == "-")
                        return;

                    if (String.IsNullOrWhiteSpace(prsc_nm))
                    {
                        SetMefeAutoCompleteView(false);
                        return;
                    }

                    ucMefeAutoComplete1.SelectAutoCompleteData(m_MDCR_DD, m_OTPT_ADMS_DVCD, "MEFE_INDX_NM", prsc_nm.ToUpper());
                }

                SetMefeAutoCompletePostion(sprMefe.ActiveSheet.ActiveRowIndex, sprMefe.ActiveSheet.ActiveColumnIndex);

                if (!ucMefeAutoComplete1.Visible)
                    ucMefeAutoComplete1.Visible = true;
            }
        }

        const ucMefeAutoComplete1_OnSetMefeData = (mefe_cd:string) => 
        {
            let row:number = sprMefe.ActiveSheet.ActiveRowIndex;

            sprMefe.SetText(row, "PRSC_CD", mefe_cd);

            if (CheckChangeMefeInfo())
            {
                // 성공했다면 Row추가
                row = GetAppendRow(sprMefe);
                m_EntryOrder.SetDefaultData(sprMefe, row, m_OTPT_ADMS_DVCD);
                sprMefe.SetActiveCell(row, "PRSC_NM");
                sprMefe.ShowRow(0, row, VerticalPosition.Nearest);
                sprMefe.Focus();
                PostCallService.PostCall(SetEnterCell);
                PostCallService.PostCall(SetPostCallSprMefe);
            }
        }

        const ucMefeAutoComplete1_OnSetClose = () => 
        {
            sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_CD", "");
            sprMefe.SetText(sprMefe.ActiveSheet.ActiveRowIndex, "PRSC_NM", "");

            SetMefeAutoCompleteView(false);

            sprMefe.Focus();
        }

        const txtMefeSearch_KeyDown = (sender:object, e /*KeyEventArgs*/) => 
        {
            if (e.KeyCode != Keys.Enter)
                return;

            let strtrow:number = 0;
            let Data:string = String.Empty;

            if (sprMefeInfo.ActiveSheet.RowCount < 0)
                return;

            strtrow = sprMefeInfo.ActiveSheet.ActiveRowIndex;
            Data = txtMefeSearch.Text;

            for (let i:number = strtrow + 1; i < sprMefeInfo.ActiveSheet.RowCount; i++)
            {
                if (sprMefeInfo.GetValue(i, "MEFE_CD").ToString().IndexOf(Data) >= 0 || sprMefeInfo.GetValue(i, "MEFE_NM").ToString().IndexOf(Data) >= 0)
                {
                    BizCommon.SetRowFocus(sprMefeInfo, i);
                    return;
                }
            }

            if (!(strtrow == 1))
            {
                for (let i:number = 0; i < strtrow; i++)
                {
                    if (sprMefeInfo.GetValue(i, "MEFE_CD").ToString().IndexOf(Data) >= 0 || sprMefeInfo.GetValue(i, "MEFE_NM").ToString().IndexOf(Data) >= 0)
                    {
                        BizCommon.SetRowFocus(sprMefeInfo, i);
                        return;
                    }
                }
            }
        }

        const sprMefeInfo_CellDoubleClick = (sender:object, CellClickEventArgs e) => 
        {
            let prsc_cd:string = String.Empty;
            let row:number = 0;
            let appendrow:number = 0;

            if (sprMefeInfo.ActiveSheet.RowCount <= 0)
                return;

            row = sprMefeInfo.ActiveSheet.ActiveRowIndex;
            prsc_cd = sprMefeInfo.GetValue(row, "MEFE_CD").ToString();

            appendrow = GetAppendRow(sprMefe);

            sprMefe.SetText(appendrow, "PRSC_CD", prsc_cd);

            sprMefe.ActiveSheet.ActiveRowIndex = appendrow;

            CheckChangeMefeInfo();
        }

        const btnButtonList_ButtonClick = (sender:object, e /*ButtonClickEventArgs*/) => 
        {
            switch (e.ButtonType)
            {
                // 조회
                case ButtonType.Select:
                    SelectData();
                    break;

                // 삭제
                case ButtonType.Delete:
                    DeleteOrderData();
                    sprMefe.ActiveSheet.ClearSelection();
                    SetEnterCell();
                    break;

                // D/C
                case ButtonType.Custom1:
                    SetDcOrder();
                    break;

                // 저장
                case ButtonType.Save:
                    SaveData();
                    break;

                // 계산
                case ButtonType.Custom2:
                    OnpopDschRecEntryOrder_Calculate?.Invoke();
                    break;

                // 닫기
                case ButtonType.Close:
                    Close();
                    break;
            }
        }

        const ucfMfefCdE_ContextMenuClick = (e /*ContextMenuClickEventArgs*/) => 
        {
            let count:number = 0;
            let row:number = 0;
            let start:number = 0;
            let end:number = 0;
            let FLAG:string = String.Empty;
            let PRSC_CLSF_CD:string = String.Empty;
            let errmsg:string = String.Empty;
            let OpinionValue:string = String.Empty;
            let OpinionAplySqnoValue:string = String.Empty;
            let today:string = DateTime.Now.ToString("yyyyMMdd");
            let save_dvcd:boolean = false;
            let chekflag:boolean = false;

            try
            {
                switch (e.MenuCode)
                {
                    // 처방삭제
                    case "DELETE":
                        DeleteOrderData();
                        sprMefe.ActiveSheet.ClearSelection();
                        SetEnterCell();
                        break;
                    // 추가
                    case "ADD":
                        row = sprMefe.AppendRow(sprMefe.ActiveSheet.ActiveRowIndex);
                        m_EntryOrder.SetDefaultData(sprMefe, row, m_OTPT_ADMS_DVCD);
                        BizCommon.SetRowFocus(sprMefe, row, "PRSC_CD");
                        SetEnterCell();
                        break;

                    case "SET_DC":
                        SetDcOrder();
                        break;
                    // 선택 취소
                    case "SET_SELECT_CANCEL":
                        UnSetFlag();
                        break;
                    // 처방라인이동 맨 위로
                    case "SET_TOP":
                        SetRowMove("TOP");
                        break;
                    // 처방라인이동 위로
                    case "SET_UP":
                        SetRowMove("UP");
                        break;
                    // 처방라인이동 아래로
                    case "SET_DOWN":
                        SetRowMove("DOWN");
                        break;
                    // 처방라인이동 맨 아래로
                    case "SET_BOTTOM":
                        SetRowMove("BOTTOM");
                        break;
                }
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
            }
            finally
            {
                switch (e.MenuCode)
                {
                    // MIX 설정
                    case "SETMIX":
                    // MIX 설정 취소
                    case "SETMIXCANCEL":
                    // 파우더 설정
                    case "SETPOWDER":
                    // 횟수/일수/1회량/용법
                    case "MEDINFO":
                    // 용법설정
                    case "SET_AOMD_MTHD_CD":
                    // 예외사유코드 설정
                    case "SET_EXCP_RESN_CD":
                    // 검체코드 설정
                    case "SET_SPCM_CD":
                    // 일수설정
                    case "SET_NODY_001":
                    case "SET_NODY_002":
                    case "SET_NODY_003":
                    case "SET_NODY_004":
                    case "SET_NODY_005":
                    case "SET_NODY_006":
                    case "SET_NODY_007":
                    case "SET_NODY_008":
                    case "SET_NODY_009":
                    case "SET_NODY_010":
                    case "SET_NODY_014":
                    case "SET_NODY_015":
                    case "SET_NODY_021":
                    case "SET_NODY_028":
                    case "SET_NODY_030":
                    case "SET_NODY_042":
                    case "SET_NODY_045":
                    case "SET_NODY_056":
                    case "SET_NODY_060":
                    case "SET_NODY_090":
                    case "SET_NODY_120":
                    case "SET_NODY_180":
                    case "SET_NODY_SET":
                    // 횟수 설정
                    case "SET_NOTM_001":
                    case "SET_NOTM_002":
                    case "SET_NOTM_003":
                    case "SET_NOTM_004":
                    case "SET_NOTM_005":
                    case "SET_NOTM_006":
                    case "SET_NOTM_007":
                    case "SET_NOTM_008":
                    case "SET_NOTM_009":
                    case "SET_NOTM_010":
                    // 처방구분
                    case "PRSC_DVCD_E":
                    case "PRSC_DVCD_I":
                    case "PRSC_DVCD_N":
                    case "PRSC_DVCD_O":
                    case "PRSC_DVCD_P":
                    case "PRSC_DVCD_S":
                    case "PRSC_DVCD_T":
                    case "PRSC_DVCD_W":
                    // 처방 Title설정
                    case "SET_DAILY_01":
                    case "SET_ADMISSION_02":
                    case "SET_PRE_OP_03":
                    case "SET_OP_04":
                    case "SET_POST_OP_05":
                    case "SET_PCA_06":
                    case "SET_PRE_ND_07":
                    case "SET_POST_ND_08":
                    case "SET_ER_09":
                    case "SET_DISCHARGE_99":
                    // 비급여 변경
                    case "SET_PNPY_DVCD":
                    // OP/주/야/응급가산 변경
                    case "SET_OP_WK_NT_ER":
                    // Resume 처방
                    case "SET_RESUME":
                    // DC처방
                    case "SET_DC":
                    // 선택 Repeat 설정
                    case "SET_REPEAT":
                    // STOP 처방
                    case "SET_STOP":
                    // HOLD 처방
                    case "SET_HOLD":
                    // TEL ORDER 선택
                    case "SET_TELORDER":
                    // 이중보험
                    case "SET_DUPINSN":
                        UnSetFlag();
                        break;
                }
            }
        }

        // #endregion Event : Event Process

        const sprMefe_CellClick_1 = (sender:object, CellClickEventArgs e) => 
        {

        }
   
/* Expose */
defineExpose({ });
</script>

<template>
<LxTextBox ref="txtPtNm"></LxTextBox>
<LxTitleLabel ref="lxTitleLabel2"></LxTitleLabel>
<LxTextBox ref="txtPid"></LxTextBox>
<LxTitleLabel ref="lxTitleLabel1"></LxTitleLabel>
<LxTitleLabel ref="lxTitleLabel3"></LxTitleLabel>
/*LxDateTimeEditor LxDateTimePicker로 대체*/ 
<LxDateTimePicker ref="dteMdcrDate" :style="'width: 130px'></LxDateTimePicker>
<LxTitlePanel ref="lxTitlePanel3"></LxTitlePanel>
<LxTitlePanel ref="lxTitlePanel2"></LxTitlePanel>
<LxSpread ref="sprMefeInfo"></LxSpread>
<LxSpread ref="sprMefe"></LxSpread>
<LxTextBox ref="txtMefeSearch"></LxTextBox>
<LxPanel ref="lxPanel1"></LxPanel>
<LxButtonList ref="lxButtonList1"></LxButtonList>
</template>
