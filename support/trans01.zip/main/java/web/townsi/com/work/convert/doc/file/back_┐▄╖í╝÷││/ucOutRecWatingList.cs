//********************************************************************************
// Class 명 : ucOutRecWatingList
// 역    할 : 수납대기자리스트
// 작 성 자 : PGH
// 작 성 일 : 2017-09-18
//********************************************************************************
// 수정내역 : 
//********************************************************************************
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    [ToolboxItem(true)]
    public partial class ucOutRecWatingList : BaseUserControl
    {
        #region Enum : Private Enum

        private enum COL
        {
            PID
            , PT_NM
            , FRRN
            , SRRN
            , AGE
            , SEX_DVCD
            , MDCR_DEPT_CD
            , DEPT_NM
            , MDCR_DR_CD
            , USER_NM
            , MDCR_TIME
            , INSN_TYCD
            , INSN_TYNM
            , ASST_TYCD
            , ASST_TYNM
            , FRVS_RVST_DVCD
            , CMHS_DVCD
            , MCCH_CMPT_DVCD
            , PT_MDCR_STAT_DVCD
            , DY_WARD_YN
            , DCNT_RDIA_CD
            , CFSC_RGNO_CD
            , ECOI_CD
            , RGST_DT
            , RGSTR_ID
            , MDCR_DD
            , PT_CMHS_NO
        }

        private enum COLSHEET2
        {
            CLAM_CRTN_YN
            , PID
            , PT_CMHS_NO
            , PT_NM
            , MDCR_DD
            , OBIL_RGST_DT
            , OPAT_RGST_DT
            , MDCR_DEPT_CD
            , DEPT_NM
            , MDCR_DR_CD
            , MDCR_DR_NM
            , OBIL_INSN_TYCD
            , OPAT_ASST_TYCD
            , OBIL_RGSTR_ID
            , OBIL_USER_NM
            , OPAT_RGSTR_ID
            , OPAT_USER_NM
            , REMARK
            , AFRS_STAT_DVCD
            , AFRS_STAT_CDNM
        }

        #endregion Private Enum

        #region Define : Event

        public delegate void OnPatientSelected(object sender, clsPatientSelected patientinfo);
        public event OnPatientSelected PatientSelected;

        public delegate void FocusLeave();
        public event FocusLeave OnFocusLeave;

        #endregion Define : Event

        #region Define : Member

        private string m_MdcrDd = String.Empty;
        private string m_SearchFlag = String.Empty;
        private string m_WatingType = String.Empty; // P : PoupUp, F : Form에 포함.
        private bool m_AutoVisible = true;  // 자동 숨기기
        private string m_strSort = String.Empty;
        private string m_MultiCheck = "N";

        // 임상시험센터 Lime 이용
        bool m_l090_lime_accept = ConfigService.GetConfigValueBool("%", "L090_LIME_ACCEPT", "L090_LIME_ACCEPT");

        #endregion

        #region Define : Member Property

        public string WatingType
        {
            get { return m_WatingType; }
            set { m_WatingType = value; }
        }

        public bool AutoVisible
        {
            get { return m_AutoVisible; }
        }

        #endregion

        #region Contruction

        public ucOutRecWatingList()
        {
            InitializeComponent();
        }

        #endregion Construction

        #region Screen Load

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode) return;

            this.FirstFocusControl = txtSearch;

            Initialize();
            InitializeSpread();
            InitializeEvent();
            InitializeSpreadCombo();
            InitializeButtonList();

            if (this.GetContextMenu("OUT_RECEIPT_WAIT") == null)
                this.CreateContextMenu("OUT_RECEIPT_WAIT");

            // 진료대기
            tbsWatingList.Tabs[1].Selected = true;
        }

        #endregion OnLoad

        #region Method : Initialize Method

        private void Initialize()
        {
            cboSelName.Items.Add("MDCR_DD", "진료일");
            cboSelName.Items.Add("CMHS_DD", "내원일");
            cboSelName.Items.Add("RGST_DT", "변경일");
            cboSelName.SelectValue("MDCR_DD");

            cboMdcrDeptCd.SetComboItems(ClinicList.GetDataList(), "DEPT_CD", "DEPT_HNM", COMBO_ADD_ITEM_TYPE.AddAll);
            cboMdcrDeptCd.SelectedValue = "%";

            txtSearch.ImeMode = System.Windows.Forms.ImeMode.Hangul;
            cboSelName.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.OnMouseEnter;
            cboMdcrDeptCd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;

            txtSearch.NullTextAppearance.ForeColor = Color.Gray;
            txtSearch.NullText = "환자번호 또는 이름";

            m_MultiCheck = ConfigService.GetConfigValueString("PA", "MULTI_DEPT_CHECK", "MULTI_DEPT_CHECK", "N");

            if (m_MultiCheck == "Y")
            {
                this.cboMdcrDeptCd.Dispose();   //보더가 겹침현상이 일어나서 걍 죽이자!
                this.ucMultiDeptCheck1.Visible = true;
                this.ucMultiDeptCheck1.SetMultiDeptCheck(this.Name, "PA.INI");
            }
            else
            {
                this.cboMdcrDeptCd.Visible = true;
                this.ucMultiDeptCheck1.Dispose();
            }

            SelectAllPatientList();
        }

        private void InitializeSpread()
        {
            /*
             * SprWatingList_Sheet1
             */
            this.sprWatingList.SetSpreadSheet(this.sprWatingList.ActiveSheet, FarPoint.Win.Spread.Model.SelectionPolicy.Single, FarPoint.Win.Spread.Model.SelectionUnit.Cell, FarPoint.Win.Spread.SelectionStyles.Both, FarPoint.Win.Spread.OperationMode.RowMode, false, false, FarPoint.Win.Spread.ButtonDrawModes.CurrentCell, true, true, FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded, FarPoint.Win.Spread.ScrollBarPolicy.Always, true, false, false, false);
            // PT_MDCR_STAT_DVCD
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.PID, "PID", "환자번호", 75, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.PT_NM, "PT_NM", "환자이름", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.FRRN, "FRRN", "주민번호", 60, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.SRRN, "SRRN", "!주민번호뒷번호 ", 30, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.AGE, "AGE", "연령", 34, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.NumberCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.SEX_DVCD, "SEX_DVCD", "성별", 34, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.MDCR_DD, "MDCR_DD", "진료일자", 75, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.MaskCellTypeYMD);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.MDCR_DEPT_CD, "MDCR_DEPT_CD", "!진료부서", 70, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.DEPT_NM, "DEPT_NM", "진료부서", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.MDCR_DR_CD, "MDCR_DR_CD", "!진료의사", 60, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.USER_NM, "USER_NM", "진료의", 50, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.MDCR_TIME, "MDCR_TIME", "접수시간", 40, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.MaskCellTypeHM);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.INSN_TYCD, "INSN_TYCD", "!보험유형", 70, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.INSN_TYNM, "INSN_TYNM", "보험유형", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.ASST_TYCD, "ASST_TYCD", "!보조유형", 80, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.ComboBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.ASST_TYNM, "ASST_TYNM", "보조유형", 80, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.FRVS_RVST_DVCD, "FRVS_RVST_DVCD", "초재진", 50, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.ComboBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.CMHS_DVCD, "CMHS_DVCD", "내원구분", 60, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.ComboBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.MCCH_CMPT_DVCD, "MCCH_CMPT_DVCD", "산정구분", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.ComboBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.PT_MDCR_STAT_DVCD, "PT_MDCR_STAT_DVCD", "진료상태", 60, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.ComboBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.DY_WARD_YN, "DY_WARD_YN", "낮병동", 50, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.ComboBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.DCNT_RDIA_CD, "DCNT_RDIA_CD", "할인코드", 60, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.ComboBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.CFSC_RGNO_CD, "CFSC_RGNO_CD", "특정기호", 60, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.ComboBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.ECOI_CD, "ECOI_CD", "상외외인", 60, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.ComboBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.RGST_DT, "RGST_DT", "등록일시", 130, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.MaskCellTypeYMDHMS);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.RGSTR_ID, "RGSTR_ID", "등록자", 60, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.ComboBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.ActiveSheet, (int)COL.PT_CMHS_NO, "PT_CMHS_NO", "!환자내원번호", 50, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);

            this.sprWatingList.AutoFitColumnSize = false;
            this.sprWatingList.AutoFitColumnName = "PT_NM";
            this.sprWatingList.AutoFitColumnType = LxSpread.AUTO_FIT_COLUMN_TYPE.OneColumn;
            this.sprWatingList.AutoFirstAppendRow = false;
            this.sprWatingList.AutoLastAppendRow = false;
            this.sprWatingList.ActiveSheet.ColumnCount = (int)COL.PT_CMHS_NO + 1;
            this.sprWatingList.ActiveSheet.RowCount = 0;
            this.sprWatingList.ActiveSheet.ColumnHeader.Rows[0].Height = 28;
            this.sprWatingList.ActiveSheet.RowHeader.Visible = false;
            this.sprWatingList.UseCRUD = false;
            this.sprWatingList.TabStripPolicy = FarPoint.Win.Spread.TabStripPolicy.Never;

            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.PID).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.PT_NM).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.FRRN).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.SRRN).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.AGE).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.SEX_DVCD).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.MDCR_DEPT_CD).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.DEPT_NM).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.MDCR_DR_CD).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.USER_NM).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.MDCR_TIME).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.INSN_TYCD).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.INSN_TYNM).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.ASST_TYCD).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.ASST_TYNM).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.FRVS_RVST_DVCD).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.CMHS_DVCD).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.MCCH_CMPT_DVCD).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.DY_WARD_YN).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.DCNT_RDIA_CD).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.CFSC_RGNO_CD).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.ECOI_CD).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.MDCR_DD).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.RGST_DT).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.RGSTR_ID).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.PT_MDCR_STAT_DVCD).Locked = true;
            this.sprWatingList.ActiveSheet.Columns.Get((int)COL.PT_CMHS_NO).Locked = true;

            /*
             * SprWatingList_Sheet2
             */
            this.sprWatingList.SetSpreadSheet(this.sprWatingList.Sheets[1], FarPoint.Win.Spread.Model.SelectionPolicy.Single, FarPoint.Win.Spread.Model.SelectionUnit.Cell, FarPoint.Win.Spread.SelectionStyles.Both, FarPoint.Win.Spread.OperationMode.RowMode, false, false, FarPoint.Win.Spread.ButtonDrawModes.CurrentCell, true, true, FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded, FarPoint.Win.Spread.ScrollBarPolicy.Always, true, false, false, false);

            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.CLAM_CRTN_YN, "CLAM_CRTN_YN", "청구", 34, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.PID, "PID", "환자번호", 60, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.PT_CMHS_NO, "PT_CMHS_NO", "!환자내원번호", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.PT_NM, "PT_NM", "환자명", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.MDCR_DD, "MDCR_DD", "진료일자", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.OBIL_RGST_DT, "OBIL_RGST_DT", "수납일시", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.OPAT_RGST_DT, "OPAT_RGST_DT", "변경일시", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.MDCR_DEPT_CD, "MDCR_DEPT_CD", "!진료부서", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.DEPT_NM, "DEPT_NM", "진료부서", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.MDCR_DR_CD, "MDCR_DR_CD", "!진료의사", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.MDCR_DR_NM, "MDCR_DR_NM", "진료의사", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.OBIL_INSN_TYCD, "OBIL_INSN_TYCD", "수납유형", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.OPAT_ASST_TYCD, "OPAT_ASST_TYCD", "변경유형", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.OBIL_RGSTR_ID, "OBIL_RGSTR_ID", "!수납자", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.OBIL_USER_NM, "OBIL_USER_NM", "수납자", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.OPAT_RGSTR_ID, "OPAT_RGSTR_ID", "!변경자", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.OPAT_USER_NM, "OPAT_USER_NM", "변경자", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.REMARK, "REMARK", "수납특이사항", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.AFRS_STAT_DVCD, "AFRS_STAT_DVCD", "!업무상태", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprWatingList.SetSpreadSheetColumn(this.sprWatingList.Sheets[1], (int)COLSHEET2.AFRS_STAT_CDNM, "AFRS_STAT_CDNM", "업무상태", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);

            this.sprWatingList.AutoFitColumnSize = false;
            this.sprWatingList.AutoFitColumnName = "PT_NM";
            this.sprWatingList.AutoFitColumnType = LxSpread.AUTO_FIT_COLUMN_TYPE.OneColumn;
            this.sprWatingList.AutoFirstAppendRow = false;
            this.sprWatingList.AutoLastAppendRow = false;
            this.sprWatingList.Sheets[1].ColumnCount = (int)COLSHEET2.AFRS_STAT_CDNM + 1;
            this.sprWatingList.Sheets[1].RowCount = 0;
            this.sprWatingList.Sheets[1].ColumnHeader.Rows[0].Height = 22;
            this.sprWatingList.Sheets[1].RowHeader.Visible = false;
            this.sprWatingList.UseCRUD = false;
            this.sprWatingList.TabStripPolicy = FarPoint.Win.Spread.TabStripPolicy.Never;

            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.CLAM_CRTN_YN).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.PID).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.PT_CMHS_NO).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.PT_NM).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.MDCR_DD).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.OBIL_RGST_DT).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.OPAT_RGST_DT).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.MDCR_DEPT_CD).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.DEPT_NM).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.MDCR_DR_CD).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.MDCR_DR_NM).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.OBIL_INSN_TYCD).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.OPAT_ASST_TYCD).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.OBIL_RGSTR_ID).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.OBIL_USER_NM).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.OPAT_RGSTR_ID).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.OPAT_USER_NM).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.REMARK).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.AFRS_STAT_DVCD).Locked = true;
            this.sprWatingList.Sheets[1].Columns.Get((int)COLSHEET2.AFRS_STAT_CDNM).Locked = true;
        }

        private void InitializeEvent()
        {
            sprWatingList.KeyDown += sprWatingList_KeyDown;
            sprWatingList.CellClick += sprWatingList_CellClick;
            tbsWatingList.SelectedTabChanged += tbsWatingList_SelectedTabChanged;
            cboMdcrDeptCd.SelectionChangeCommitted += cboMdcrDeptCd_SelectionChangeCommitted;
            txtSearch.KeyDown += txtSearch_KeyDown;
            dteStrtDd.ValueChanged += dteStrtDd_ValueChanged;
            btnButtonList.ButtonClick += btnButtonList_ButtonClick;
            ContextMenuClick += ucOutRecWatingList_ContextMenuClick;
            chk70017002.CheckedChanged += chk70017002_CheckedChanged;
            this.ucMultiDeptCheck1.ValueChange += ucMultiDeptCheck1_ValueChange;
        }

        private void InitializeSpreadCombo()
        {
            sprWatingList.SetComboItems("FRVS_RVST_DVCD", OverallCodeList.GetDataList("FRVS_RVST_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            sprWatingList.SetComboItems("CMHS_DVCD", OverallCodeList.GetDataList("CMHS_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            sprWatingList.SetComboItems("MCCH_CMPT_DVCD", OverallCodeList.GetDataList("MCCH_CMPT_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            sprWatingList.SetComboItems("DY_WARD_YN", OverallCodeList.GetDataList("ECOI_CD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            sprWatingList.SetComboItems("FRVS_RVST_DVCD", OverallCodeList.GetDataList("FRVS_RVST_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            sprWatingList.SetComboItems("ASST_TYCD", OverallCodeList.GetDataList("ASST_TYCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            sprWatingList.SetComboItems("CFSC_RGNO_CD", clsPACommon.GetDtCbo("CFSC_CD", "", DateTimeService.NowDateFormatString()), "CFSC_CD", "CFSC_CD_CNTS");
            sprWatingList.SetComboItems("DCNT_RDIA_CD", clsPACommon.GetDtCbo("DCNT_CD", "", DateTimeService.NowDateFormatString()), "DCNT_CD", "DCNT_CDNM");
            sprWatingList.SetComboItems("RGSTR_ID", UserList.GetDataList(), "USER_CD", "USER_NM");
            sprWatingList.SetComboItems("PT_MDCR_STAT_DVCD", OverallCodeList.GetDataList("PT_MDCR_STAT_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            //DCNT_RDIA_CD
            //CFSC_RGNO_CD

        }

        private void InitializeButtonList()
        {
            this.btnButtonList.ButtonItems.Clear();

            if (this.m_WatingType.Equals("P"))
            {
                // 팝업
                this.btnButtonList.ButtonItems.Add(ButtonType.Select, "조 회", "Select");
                this.btnButtonList.ButtonItems.Add(ButtonType.Check, "선 택", "Check");
                this.btnButtonList.ButtonItems.Add(ButtonType.Close, "종 료", "Close");
            }
            else
            {
                // 왼쪽 대기자
                if (this.m_AutoVisible)
                    this.btnButtonList.ButtonItems.Add(ButtonType.Custom1, "고 정", "Custom1");
                else
                    this.btnButtonList.ButtonItems.Add(ButtonType.Custom1, "숨기기", "Custom1");
            }

            this.btnButtonList.InitializeButtons();
        }

        private int GetReceiptCompleteCount()
        {
            int i = sprWatingList.ActiveSheet.ActiveRowIndex;
            if (i.Equals(-1))
                return 0;

            int receipt_count = DBService.ExecuteInteger(SQL.PA.Sql.SelectCountPAOBILBDActive(sprWatingList.ActiveSheet.Cells[i, (int)COL.PID].Value.ToString(), sprWatingList.ActiveSheet.Cells[i, (int)COL.PT_CMHS_NO].Value.ToString()));
            if (receipt_count == null || receipt_count.Equals(0))
                return 0;

            return receipt_count;
        }

        private void MoveReceiptComplete()
        {
            try
            {
                int i = sprWatingList.ActiveSheet.ActiveRowIndex;
                if (i < 0)
                    return;

                // 아직 수납한 내역이 없으면 리턴.
                if (this.GetReceiptCompleteCount() <= 0)
                    return;

                string pid = sprWatingList.ActiveSheet.Cells[i, (int)COL.PID].Value.ToString();
                string pt_cmhs_no = sprWatingList.ActiveSheet.Cells[i, (int)COL.PT_CMHS_NO].Value.ToString();

                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectReceiptPrscNotmRcptNotm(pid, pt_cmhs_no), ref dt))
                    throw new Exception("이미 수납한 내역을 조회하는 중 에러가 발생했습니다.");

                if (dt.Rows.Count.Equals(0))
                    throw new Exception("수납내역이 존재하지 않습니다.");

                int.TryParse(dt.Rows[0]["PRSC_NOTM"].ToString(), out int prsc_notm);
                int.TryParse(dt.Rows[0]["RCPT_NOTM"].ToString(), out int rcpt_notm);

                if (prsc_notm <= rcpt_notm)
                    throw new Exception("선택한 환자는 이미 [수납완료]로 변경되었습니다.");

                if (!LxMessage.ShowQuestion("선택한 환자를 [수납완료]로 변경하시겠습니까?").Equals(DialogResult.Yes))
                    return;

                string currentdate = DateTime.Now.ToString("yyyyMMddHHmmss");

                DBService.BeginTransaction();

                // 수납횟수보다 처방횟수가 많은 데이터가 존재하는 지 확인한다.
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePAOPATRT_RcptNotm(pid, pt_cmhs_no)))
                    throw new Exception("선택한 환자를 [수납대기] => [수납완료]로 변경하는 중 오류가 발생했습니다.");

                if (DBService.AffectedRows <= 0)
                    throw new Exception("선택한 환자는 이미 [수납완료]로 변경되었습니다.");

                Lime.BusinessControls.clsCommon.SaveADPRLGIF("PA_CHNG_STAT", string.Format("[OUT_RECEIPT_MOVE_COMP] PID:{0}/PT_CMHS_NO:{1}/PRSC_NOTM:{2}/RCPT_NOTM:{3}", pid, pt_cmhs_no, prsc_notm, rcpt_notm), currentdate);
                
                // 재수납 대상 환자여부를 Y로 Update한다.
                clsPACommon.UpdatePAORCHMA(pid, pt_cmhs_no, currentdate);

                DBService.CommitTransaction();

                // 재조회
                this.SetWatingListToSpr(tbsWatingList.SelectedTab.Index);

                LxMessage.ShowInformation("[수납완료]로 변경되었습니다.", 3);
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                if (DBService.IsTransaction)
                    DBService.RollbackTransaction();

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        private void Appointment()
        {
            try
            {
                int row = sprWatingList.ActiveSheet.ActiveRowIndex;
                if (row < 0)
                    return;

                sprWatingList.SetActiveRow(row);

                ScreenParameters param = new ScreenParameters();
                param.Add("pid", sprWatingList.GetText(row, "PID"));
                param.Add("otptadmsdvcd", "O");
                param.Add("deptcd", sprWatingList.GetText(row, "MDCR_DEPT_CD"));
                param.Add("drcd", sprWatingList.GetText(row, "MDCR_DR_CD"));

                this.CallPopUp(this, "Lime.PA.dll", "Lime.PA.ucfDrAppMaE", "의사별예약관리", param);
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        #endregion Method : Initialize Method

        #region Method : Public Method

        public void Clear()
        {
            int tabindex = tbsWatingList.SelectedTab.Index;
            string sItems = ucMultiDeptCheck1.GetCheckedItemsInWhere();
            DataTable dtWating = new DataTable();

            dteStrtDd.DateTime = DateTimeService.ConvertDateTime(DateTimeService.NowDateFormatString());
            dteEndDd.DateTime = DateTimeService.ConvertDateTime(DateTimeService.NowDateFormatString());
            txtSearch.Text = String.Empty;
            cboMdcrDeptCd.SelectedValue = "%";

            dtWating = GetWatingList("0", cboSelName.SelectedValue, dteStrtDd.DateTimeValue.ToString("yyyyMMdd"), chk70017002.Checked, sItems, m_l090_lime_accept);
            tbsWatingList.Tabs[0].Text = "진료대기[" + dtWating.Rows.Count.ToString() + "명]";
            dtWating.Clear();

            dtWating = GetWatingList("2", cboSelName.SelectedValue, dteStrtDd.DateTimeValue.ToString("yyyyMMdd"), chk70017002.Checked, sItems, m_l090_lime_accept);
            tbsWatingList.Tabs[2].Text = "진료완료[" + dtWating.Rows.Count.ToString() + "명]";

            sprWatingList.ShowColumn(0, 0, FarPoint.Win.Spread.HorizontalPosition.Nearest);

            SetWatingListToSpr(tabindex);
        }

        public void SetDate(string mdcrdd)
        {
            this.m_MdcrDd = mdcrdd;
            dteStrtDd.DateTime = DateTimeService.ConvertDateTime(mdcrdd);
            dteEndDd.DateTime = DateTimeService.ConvertDateTime(mdcrdd);
            SelectedTabChanged("RECWAIT", tbsWatingList.SelectedTab.Index);
        }

        /// <summary>
        /// 수납대기자를 조회한다.
        /// </summary>
        /// <param name="tabindex"></param>
        public void SetWatingListToSpr(int tabindex)
        {
            string condition = String.Empty;
            string sorttext = String.Empty;
            string sItems = ucMultiDeptCheck1.GetCheckedItemsInWhere();

            try
            {
                int i = 0;

                string tabtext = String.Empty;
                sprWatingList.Clear();
                DataRow[] rows = null;
                DataTable dtWating = GetWatingList(tabindex.ToString(), cboSelName.SelectedValue, dteStrtDd.DateTimeValue.ToString("yyyyMMdd"), chk70017002.Checked, sItems, m_l090_lime_accept);

                if (tabindex == 0)
                {
                    tabtext = "진료대기";
                }
                else if (tabindex == 1)
                {
                    tabtext = "수납대기";
                }
                else if (tabindex == 2)
                {
                    tabtext = "수납완료";
                }

                tbsWatingList.Tabs[tabindex].Text = tabtext + "[" + dtWating.Rows.Count.ToString() + "명]";

                if (tabindex.Equals(3))
                {
                    condition += StringService.IsNull(condition) ? "" : " AND ";
                    condition += " NOTREC_CNT > 0 ";
                }

                if (m_MultiCheck == "Y")
                {
                    if (!string.IsNullOrEmpty(sItems))
                    {
                        condition += StringService.IsNull(condition) ? "" : " AND ";
                        condition += string.Format(" MDCR_DEPT_CD IN ({0})", sItems);
                    }
                }
                else
                {
                    if (cboMdcrDeptCd.SelectedValue != "%")
                    {
                        condition += StringService.IsNull(condition) ? "" : " AND ";
                        condition += string.Format(" MDCR_DEPT_CD LIKE '{0}'", cboMdcrDeptCd.SelectedValue);
                    }
                }


                if (StringService.IsNotNull(m_SearchFlag) && StringService.IsNotNull(txtSearch.Text.Trim()))
                {
                    condition += StringService.IsNull(condition) ? "" : " AND ";
                    condition += string.Format(" {0} LIKE '%{1}%'", m_SearchFlag, txtSearch.Text.Trim());
                }

                sorttext = " MDCR_TIME";

                rows = dtWating.Select(condition, sorttext);

                foreach (DataRow row in rows)
                {
                    i = sprWatingList.AppendRow();
                    sprWatingList.SetText(i, "PID", row["PID"].ToString());
                    sprWatingList.SetText(i, "PT_NM", row["PT_NM"].ToString());
                    sprWatingList.SetText(i, "FRRN", row["FRRN"].ToString());
                    sprWatingList.SetText(i, "SRRN", row["SRRN"].ToString());
                    sprWatingList.SetText(i, "AGE", row["AGE"].ToString());
                    sprWatingList.SetText(i, "SEX_DVCD", row["SEX_DVCD"].ToString());
                    sprWatingList.SetText(i, "MDCR_DEPT_CD", row["MDCR_DEPT_CD"].ToString());
                    sprWatingList.SetText(i, "DEPT_NM", row["DEPT_NM"].ToString());
                    sprWatingList.SetText(i, "MDCR_DR_CD", row["MDCR_DR_CD"].ToString());
                    sprWatingList.SetText(i, "USER_NM", row["USER_NM"].ToString());
                    sprWatingList.SetText(i, "MDCR_TIME", row["MDCR_TIME"].ToString());
                    sprWatingList.SetText(i, "INSN_TYCD", row["INSN_TYCD"].ToString());
                    sprWatingList.SetText(i, "INSN_TYNM", row["INSN_TYNM"].ToString());
                    sprWatingList.SetText(i, "ASST_TYCD", row["ASST_TYCD"].ToString());
                    sprWatingList.SetText(i, "ASST_TYNM", row["ASST_TYNM"].ToString());
                    sprWatingList.SetText(i, "FRVS_RVST_DVCD", row["FRVS_RVST_DVCD"].ToString());
                    sprWatingList.SetText(i, "CMHS_DVCD", row["CMHS_DVCD"].ToString());
                    sprWatingList.SetText(i, "MCCH_CMPT_DVCD", row["MCCH_CMPT_DVCD"].ToString());
                    sprWatingList.SetText(i, "PT_MDCR_STAT_DVCD", row["PT_MDCR_STAT_DVCD"].ToString());
                    sprWatingList.SetText(i, "DY_WARD_YN", row["DY_WARD_YN"].ToString());
                    sprWatingList.SetText(i, "DCNT_RDIA_CD", row["DCNT_RDIA_CD"].ToString());
                    sprWatingList.SetText(i, "CFSC_RGNO_CD", row["CFSC_RGNO_CD"].ToString());
                    sprWatingList.SetText(i, "ECOI_CD", row["ECOI_CD"].ToString());
                    sprWatingList.SetText(i, "MDCR_DD", row["MDCR_DD"].ToString());
                    sprWatingList.SetText(i, "RGST_DT", row["RGST_DT"].ToString());
                    sprWatingList.SetText(i, "RGSTR_ID", row["RGSTR_ID"].ToString());
                    sprWatingList.SetText(i, "PT_CMHS_NO", row["PT_CMHS_NO"].ToString());
                }

                // 진료상태구분에 따른 색 지정 진료중 : Blue, 진료완료 : Red, 귀가 : Green
                SetSpreadColor();
            }
            catch (Exception ex)
            {
                LxMessage.Show("대기자 조회중 오류를 발생하였습니다. \r\n [ SetWatingListToSpr ] 오류메시지 : " + ex.Message, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 유형변경대기자리스트
        /// </summary>
        /// <param name="tabindex"></param>
        private void SetTypeChangeWatingListToSpr(int tabindex)
        {
            try
            {
                int i = 0;

                sprWatingList.Clear();

                DataTable dtWating = new DataTable();

                dtWating = GetTypeChangeWatingList(cboSelName.SelectedValue, dteStrtDd.DateTimeValue.ToString("yyyyMMdd"), dteEndDd.DateTimeValue.ToString("yyyyMMdd"));

                foreach (DataRow row in dtWating.Rows)
                {
                    i = sprWatingList.AppendRow();

                    sprWatingList.SetText(i, "CLAM_CRTN_YN", row["CLAM_CRTN_YN"].ToString());
                    sprWatingList.SetText(i, "PID", row["PID"].ToString());
                    sprWatingList.SetText(i, "PT_CMHS_NO", row["PT_CMHS_NO"].ToString());
                    sprWatingList.SetText(i, "PT_NM", row["PT_NM"].ToString());
                    sprWatingList.SetText(i, "MDCR_DD", row["MDCR_DD"].ToString());
                    sprWatingList.SetText(i, "OBIL_RGST_DT", row["OBIL_RGST_DT"].ToString());
                    sprWatingList.SetText(i, "OPAT_RGST_DT", row["OPAT_RGST_DT"].ToString());
                    sprWatingList.SetText(i, "MDCR_DEPT_CD", row["MDCR_DEPT_CD"].ToString());
                    sprWatingList.SetText(i, "DEPT_NM", row["DEPT_NM"].ToString());
                    sprWatingList.SetText(i, "MDCR_DR_CD", row["MDCR_DR_CD"].ToString());
                    sprWatingList.SetText(i, "MDCR_DR_NM", row["MDCR_DR_NM"].ToString());
                    sprWatingList.SetText(i, "OBIL_INSN_TYCD ", row["OBIL_INSN_TYCD "].ToString());
                    sprWatingList.SetText(i, "OPAT_ASST_TYCD", row["OPAT_ASST_TYCD"].ToString());
                    sprWatingList.SetText(i, "OBIL_RGSTR_ID", row["OBIL_RGSTR_ID"].ToString());
                    sprWatingList.SetText(i, "OBIL_USER_NM", row["OBIL_USER_NM"].ToString());
                    sprWatingList.SetText(i, "OPAT_RGSTR_ID", row["OPAT_RGSTR_ID"].ToString());
                    sprWatingList.SetText(i, "OPAT_USER_NM", row["OPAT_USER_NM"].ToString());
                    sprWatingList.SetText(i, "REMARK", row["REMARK"].ToString());
                    sprWatingList.SetText(i, "AFRS_STAT_DVCD", row["AFRS_STAT_DVCD"].ToString());
                    sprWatingList.SetText(i, "AFRS_STAT_CDNM", row["AFRS_STAT_CDNM"].ToString());
                    sprWatingList.SetText(i, "BILL_NO", row["BILL_NO"].ToString());
                }

                if (sprWatingList.ActiveSheet.Rows.Count < 1)
                {
                    txtSearch.Focus();
                }
                else
                {
                    sprWatingList.Focus();
                    sprWatingList.ActiveSheet.ActiveRowIndex = 0;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        public void SetCurrentRow(string pid)
        {
            sprWatingList.ShowColumn(0, 0, FarPoint.Win.Spread.HorizontalPosition.Nearest);
            for (int i = 0; i < sprWatingList.ActiveSheet.RowCount; i++)
            {
                if (sprWatingList.GetText(i, "PID").ToString().Equals(pid))
                {
                    sprWatingList.ActiveSheet.ActiveRowIndex = i;
                    sprWatingList.ShowRow(0, i, FarPoint.Win.Spread.VerticalPosition.Nearest);
                    return;
                }
            }
        }

        /// <summary>
        /// 진료대기, 수납대기, 수납완료 환자리스트를 조회한다.
        /// </summary>
        private void SelectAllPatientList()
        {
            try
            {
                int select_tab = tbsWatingList.SelectedTab.Index;

                DateTime isdate = new DateTime();

                if (DateTime.TryParse(dteStrtDd.DateTimeValue.ToString("yyyy-MM-dd"), out isdate))
                {
                    //현재 선택된 TAB을 제외하고 먼저 조회한다. 어차피 마지막에 현재 선택된 탭을 조회해야 한다. - 2번 조회 안하게
                    for (int tabcnt = 0; tabcnt < tbsWatingList.Tabs.Count; tabcnt++)
                    {
                        if (select_tab != tabcnt)
                            SelectedTabChanged("RECWAIT", tabcnt);
                    }

                    SelectedTabChanged("RECWAIT", select_tab);
                }
            }
            catch (Exception ex)
            {
                LxMessage.Show(ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void SaveDeptIni()
        {
            try
            {
                if (m_MultiCheck == "Y")
                    ucMultiDeptCheck1.SaveIni(this.Name, "PA.INI");
            }
            catch (Exception ex)
            {
                LxMessage.Show(ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Method : Private Method

        /// <summary>
        /// 수납 대기자 명단을 가져온다.
        /// </summary>
        /// <param name="watingdvcd"></param>
        /// <param name="dateaplynm"></param>
        /// <param name="mdcrdd"></param>
        /// <param name="hphc"></param>
        /// <param name="multidept"></param>
        /// <param name="l090_lime_accept"></param>
        /// <returns></returns>
        private DataTable GetWatingList(string watingdvcd, string dateaplynm, string mdcrdd, bool hphc, string multidept, bool l090_lime_accept)
        {

            DataTable dtWating = new DataTable();
            try
            {

                if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOPATRT_Wating(watingdvcd, dateaplynm, mdcrdd, hphc, multidept, l090_lime_accept)
                                             , ref dtWating))
                {
                    if (dtWating.Rows.Count > 0)
                    {
                        return dtWating;
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
            return dtWating;
        }

        /// <summary>
        /// 유형변경 미수납 명단을 가져온다.
        /// </summary>
        /// <param name="watingdvcd"></param>
        /// <param name="dateaplynm"></param>
        /// <param name="mdcrdd"></param>
        /// <returns></returns>
        private DataTable GetTypeChangeWatingList(string dateaplynm, string strtdd, string enddd)
        {
            DataTable dtWating = new DataTable();

            if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectTypeChangeWating(), ref dtWating, dateaplynm
                                                                                            , strtdd
                                                                                            , enddd))
            {
                if (dtWating.Rows.Count > 0)
                {
                    return dtWating;
                }
            }

            return dtWating;
        }

        private void SelectedTabChanged(string dvcd, int tabindex)
        {
            if (dvcd.Equals("INSNCHNG"))
            {
                this.sprWatingList.ActiveSheetIndex = 1;
                dteEndDd.Visible = true;
                lblMdcrDept.Visible = false;
                cboMdcrDeptCd.Visible = false;
                txtSearch.Visible = false;
                lblSearch.Visible = false;
                SetTypeChangeWatingListToSpr(tabindex);
            }
            else if (dvcd.Equals("RECWAIT"))
            {
                this.sprWatingList.ActiveSheetIndex = 0;
                dteEndDd.Visible = false;
                lblMdcrDept.Visible = true;
                cboMdcrDeptCd.Visible = true;
                txtSearch.Visible = true;
                lblSearch.Visible = true;
                SetWatingListToSpr(tabindex);
            }
        }

        private void OnWatingEvent(LxSpread spr, int row)
        {
            try
            {
                SelectedPatient(spr, row
                              , spr.GetText(row, "PID")
                              , spr.GetText(row, "PT_CMHS_NO")
                              , spr.GetText(row, "MDCR_DD").Replace("-", ""));
            }
            catch (Exception ex)
            {
                LxMessage.Show(ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ReturnSelectedPatient()
        {
            try
            {
                OnWatingEvent(sprWatingList, sprWatingList.ActiveSheet.ActiveRowIndex);
            }
            catch (Exception ex)
            {
                LxMessage.Show(ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SelectWating()
        {
            try
            {
                string convertvalue = String.Empty;
                m_SearchFlag = String.Empty;
                if (StringService.IsNotNull(txtSearch.Text.Trim()))
                {
                    convertvalue = DBService.ExecuteScalar(SqlPack.Function.FN_PA_PRC_CONVERTPID(), txtSearch.Text.Trim()).ToString();
                    if (StringService.IsNumeric(convertvalue))
                        m_SearchFlag = "PID";
                    else
                        m_SearchFlag = "PT_NM";

                    txtSearch.Text = convertvalue;
                }

                SetWatingListToSpr(tbsWatingList.SelectedTab.Index);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        private void SetSpreadColor()
        {
            for (int i = 0; i < sprWatingList.ActiveSheet.RowCount; i++)
            {
                string pt_mdcr_stat_dvcd = sprWatingList.GetValue(i, "PT_MDCR_STAT_DVCD").ToString();

                sprWatingList.Sheets[0].Cells[i, 0, i, sprWatingList.Sheets[0].ColumnCount - 1].ForeColor = pt_mdcr_stat_dvcd.Equals("3") || pt_mdcr_stat_dvcd.Equals("4") ? Color.Blue :
                                                                                                            pt_mdcr_stat_dvcd.Equals("5") ? Color.Red :
                                                                                                            pt_mdcr_stat_dvcd.Equals("6") ? Color.Green :
                                                                                                            pt_mdcr_stat_dvcd.Equals("9") ? Color.Magenta :
                                                                                                            Color.FromArgb(30, 30, 30);
            }
        }

        private void SelectedPatient(LxSpread spr, int row, string pid, string pt_cmhs_no, string mdcr_dd)
        {
            try
            {
                if (row < 0) return;
                if (PatientSelected == null) return;

                clsPatientSelected patient_info = new clsPatientSelected();

                patient_info.pid = pid;
                patient_info.pt_cmhs_no = pt_cmhs_no;
                patient_info.mdcr_dd = mdcr_dd;

                PatientSelected(this, patient_info);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        #endregion Method : Private Method

        #region Event : Event Process

        /// <summary>
        /// 단축키사용
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="keyData"></param>
        /// <returns></returns>
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            Keys key = keyData & ~(Keys.Shift | Keys.Control);
            switch (key)
            {
                case Keys.Escape:                           // 종료
                    if (this.m_WatingType.Equals("P")) break;

                    this.ParentForm.DialogResult = DialogResult.Cancel;
                    Close();
                    break;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void btnButtonList_ButtonClick(object sender, ButtonClickEventArgs e)
        {
            switch (e.ButtonType)
            {
                case ButtonType.Clear:
                    Clear();
                    break;
                case ButtonType.Select:
                    int tabindex = tbsWatingList.SelectedTab.Index;
                    SelectedTabChanged("RECWAIT", tabindex);
                    break;
                case ButtonType.Check:
                    ReturnSelectedPatient();
                    break;
                case ButtonType.Custom1:
                    if (m_AutoVisible)
                    {
                        m_AutoVisible = false;
                    }
                    else
                    {
                        m_AutoVisible = true;

                    }

                    InitializeButtonList();
                    break;
                case ButtonType.Close:
                    this.ParentForm.DialogResult = DialogResult.Cancel;
                    Close();
                    break;
            }
        }

        private void sprWatingList_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (sprWatingList.ActiveSheet.ActiveRowIndex >= 0)
                    OnWatingEvent((LxSpread)sender, sprWatingList.ActiveSheet.ActiveRowIndex);
            }
        }

        private void tbsWatingList_SelectedTabChanged(object sender, Infragistics.Win.UltraWinTabControl.SelectedTabChangedEventArgs e)
        {
            switch (e.Tab.Index)
            {
                case 0:
                case 1:
                case 2:
                case 3:
                    SelectedTabChanged("RECWAIT", e.Tab.Index);
                    break;
                case 4:
                    SelectedTabChanged("INSNCHNG", e.Tab.Index);
                    break;
            }
        }

        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                SelectWating();
            }
        }

        private void sprWatingList_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader)
            {

                if (m_strSort.Equals("") || m_strSort.Equals("A"))
                {
                    this.sprWatingList.ActiveSheet.AutoSortColumn(e.Column, true, false);
                    m_strSort = "D";
                }
                else
                {
                    this.sprWatingList.ActiveSheet.AutoSortColumn(e.Column, false, false);
                    m_strSort = "A";
                }
                return;
            }

            if (e.RowHeader) return;

            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                sprWatingList.SetActiveRow(e.Row);
                sprWatingList.SetActiveCell(e.Row, e.Column);

                if (this.ContextMenuToolBar.Tools != null)
                {
                    int index = tbsWatingList.SelectedTab.Index;

                    // 수납대기 에서만 유효하다.
                    if (this.ContextMenuToolBar.Tools.Exists("MOVE_COMP"))
                    {
                        this.ContextMenuToolBar.Tools["MOVE_COMP"].SharedProps.Enabled = false;

                        if (index.Equals(1) && GetReceiptCompleteCount() > 0)
                            this.ContextMenuToolBar.Tools["MOVE_COMP"].SharedProps.Enabled = true;
                    }

                    // 수납대기 또는 수납완료 에서만 유효하다.
                    if (this.ContextMenuToolBar.Tools.Exists("MOVE_WAIT"))
                    {
                        this.ContextMenuToolBar.Tools["MOVE_WAIT"].SharedProps.Enabled = false;

                        if (index.Equals(1) || index.Equals(2))
                            this.ContextMenuToolBar.Tools["MOVE_WAIT"].SharedProps.Enabled = true;
                    }
                }

                this.ShowContextMenu("OUT_RECEIPT_WAIT");
            }
            else
            {
                if (e.Row >= 0)
                    OnWatingEvent((LxSpread)sender, e.Row);
            }
        }

        private void dteStrtDd_ValueChanged(object sender, EventArgs e)
        {
            if (dteStrtDd.IsDateValid)
                SelectAllPatientList();
        }

        private void ucOutRecWatingList_TimeEvent10Second(object sender, EventArgs e)
        {
            this.Clear();
        }

        private void cboMdcrDeptCd_SelectionChangeCommitted(object sender, EventArgs e)
        {
            SetWatingListToSpr(tbsWatingList.SelectedTab.Index);
        }

        private void ucOutRecWatingList_ContextMenuClick(ContextMenuClickEventArgs e)
        {
            switch (e.MenuCode)
            {
                // 예약등록
                case "APPREG":
                    Appointment();
                    break;

                // 수납완료로 변경
                case "MOVE_COMP":
                    MoveReceiptComplete();
                    break;

                // 진료대기로 변경
                case "MOVE_WAIT":
                    MoveWait();
                    break;
            }
        }

        private void MoveWait()
        {
            try
            {
                int i = sprWatingList.ActiveSheet.ActiveRowIndex;
                if (i < 0)
                    return;

                string pid = sprWatingList.ActiveSheet.Cells[i, (int)COL.PID].Value.ToString();
                string pt_cmhs_no = sprWatingList.ActiveSheet.Cells[i, (int)COL.PT_CMHS_NO].Value.ToString();

                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOPATRT(pid, pt_cmhs_no), ref dt))
                    throw new Exception("접수정보 조회 중 에러가 발생했습니다.");

                if (dt.Rows.Count.Equals(0))
                    throw new Exception("접수정보 조회 중 에러가 발생했습니다.\r\n접수 내역이 없습니다.");

                string rcpn_sqno = dt.Rows[0]["RCPN_SQNO"].ToString();

                if (!LxMessage.ShowQuestion("선택한 환자를 [진료대기]로 변경하시겠습니까?\r\n\r\n★주의★\r\n진료과에서도 [진료대기]로 변경되어 보여집니다.").Equals(DialogResult.Yes))
                    return;

                string error_dvcd = string.Empty;
                string error_cnts = string.Empty;

                DBService.BeginTransaction();

                // 환자진료상태구분코드
                if (!SqlPack.Procedure.PR_PA_PRC_PAOPATRTCH(pid, pt_cmhs_no, rcpn_sqno, "PT_MDCR_STAT_DVCD", "2", DOPack.UserInfo.USER_CD, ref error_dvcd, ref error_cnts))
                    throw new Exception("환자진료상태구분을[진료대기]로 변경하는 중 에러가 발생했습니다.");

                if (!string.IsNullOrWhiteSpace(error_cnts))
                    throw new Exception($"환자진료상태구분을 [진료대기]로 변경하는 중 에러가 발생했습니다.\r\n{error_cnts}");

                // 처방횟수
                if (!SqlPack.Procedure.PR_PA_PRC_PAOPATRTCH(pid, pt_cmhs_no, rcpn_sqno, "PRSC_NOTM", "0", DOPack.UserInfo.USER_CD, ref error_dvcd, ref error_cnts))
                    throw new Exception("처방횟수를 0으로 변경하는 중 에러가 발생했습니다.");

                if (!string.IsNullOrWhiteSpace(error_cnts))
                    throw new Exception($"처방횟수를 0으로 변경하는 중 에러가 발생했습니다.\r\n{error_cnts}");

                // 수납횟수
                if (!SqlPack.Procedure.PR_PA_PRC_PAOPATRTCH(pid, pt_cmhs_no, rcpn_sqno, "RCPT_NOTM", "0", DOPack.UserInfo.USER_CD, ref error_dvcd, ref error_cnts))
                    throw new Exception("수납횟수를 0으로 변경하는 중 에러가 발생했습니다.");

                if (!string.IsNullOrWhiteSpace(error_cnts))
                    throw new Exception($"수납횟수를 0으로 변경하는 중 에러가 발생했습니다.\r\n{error_cnts}");

                // DID 진료대기자에도 업데이트
                if (ConfigService.GetConfigValueDirect("PA", "RECEIPT", "MOVE_WAIT_UPDATE_DID", "N").Equals("Y"))
                {
                    dt.Reset();
                    if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectORWATPMA(pid, pt_cmhs_no), ref dt))
                        throw new Exception("진료대기자 조회 중 에러가 발생했습니다.");

                    if (dt.Rows.Count > 0)
                    {
                        string orwatpma_sort_seq = DBService.ExecuteScalar(SQL.PA.Sql.SelectORWATPMA_MaxSortSeq(dt.Rows[0]["MDCR_DD"].ToString(), dt.Rows[0]["MDCR_DR_CD"].ToString(), "OR", dt.Rows[0]["ETC_USE_CNTS_1"].ToString())).ToString();

                        orwatpma_sort_seq = string.IsNullOrWhiteSpace(orwatpma_sort_seq) ? "100" : orwatpma_sort_seq;

                        if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateORWATPMA(pid, pt_cmhs_no, orwatpma_sort_seq)))
                            throw new Exception("진료대기자의 완료구분을 [진료대기]로 변경하는 중 에러가 발생했습니다.");
                    }
                }

                DBService.CommitTransaction();

                // 재조회
                this.SetWatingListToSpr(tbsWatingList.SelectedTab.Index);

                LxMessage.ShowInformation("[진료대기]로 변경되었습니다.", 3);
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                if (DBService.IsTransaction)
                    DBService.RollbackTransaction();

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        private void chk70017002_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                SetWatingListToSpr(tbsWatingList.SelectedTab.Index);
            }
            catch (Exception ex)
            {
                LxMessage.Show(ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        void ucMultiDeptCheck1_ValueChange()
        {
            SelectAllPatientList();
        }

        #endregion Event : Event Process

        public class clsPatientSelected
        {
            public string pid { get; set; }
            public string pt_cmhs_no { get; set; }
            public string mdcr_dd { get; set; }
        }
    }
}