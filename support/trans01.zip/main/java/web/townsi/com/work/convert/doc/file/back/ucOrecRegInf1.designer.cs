namespace Lime.PA
{
    partial class ucOrecRegInf1
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance23 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance24 = new Infragistics.Win.Appearance();
            Infragistics.Win.ValueListItem valueListItem3 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem4 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.Appearance appearance25 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance26 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance27 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance28 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance29 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance30 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance31 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance32 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance33 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance34 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance35 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance36 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance37 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance38 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance39 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance40 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance41 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance42 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance43 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance44 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance45 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance46 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance47 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance48 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance49 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance50 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance51 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance52 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance53 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance54 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance55 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance56 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance57 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance58 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance59 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance60 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance61 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance62 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance63 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance64 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance65 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance66 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance67 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance68 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance69 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance70 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance71 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance72 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance73 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance74 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance75 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance76 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance77 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance78 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance79 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance80 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance81 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance82 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance83 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance84 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance85 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance86 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance87 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance88 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance89 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance90 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance91 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance92 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance93 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance94 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance95 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance96 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance97 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance98 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance99 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance100 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance101 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance102 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance103 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance104 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance105 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance106 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance107 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance108 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance109 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance110 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance111 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance112 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance113 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance114 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance115 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance116 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance117 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance118 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance119 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance120 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance121 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance122 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance123 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance124 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance125 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance126 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance127 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance128 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance129 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance130 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance131 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance132 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance133 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance134 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance135 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance136 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance137 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance138 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance139 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance140 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance141 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance142 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance143 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance144 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance145 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance146 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance147 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinEditors.EditorButton editorButton1 = new Infragistics.Win.UltraWinEditors.EditorButton();
            Infragistics.Win.Appearance appearance148 = new Infragistics.Win.Appearance();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucOrecRegInf1));
            Infragistics.Win.Appearance appearance149 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance150 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance151 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance152 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance153 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance154 = new Infragistics.Win.Appearance();
            this.lxTitlePanel1 = new Lime.Framework.Controls.LxTitlePanel();
            this.lblIncsDr = new Lime.Framework.Controls.LxLabel();
            this.lblPtMdcrStatDvcd9 = new Lime.Framework.Controls.LxLabel();
            this.lblDisasterSupt = new Lime.Framework.Controls.LxLabel();
            this.lblPregnant = new Lime.Framework.Controls.LxLabel();
            this.lblMediParams = new Lime.Framework.Controls.LxLabel();
            this.lblMDCAREHSPTHSPTZYN = new Lime.Framework.Controls.LxLabel();
            this.lblForceChange = new Lime.Framework.Controls.LxLabel();
            this.btnNhic = new Lime.Framework.Controls.LxButton();
            this.lxPanel1 = new Lime.Framework.Controls.LxPanel();
            this.cboEcoiCd = new Lime.Framework.Controls.LxComboBox();
            this.txtTbrcDvcd = new Lime.Framework.Controls.LxTextBox();
            this.cboEmrmMmcdCd = new Lime.Framework.Controls.LxComboBox();
            this.lblEmrmMmcdCd = new Lime.Framework.Controls.LxTitleLabel();
            this.lblClphTel = new Lime.Framework.Controls.LxTitleLabel();
            this.txtClphTel = new Lime.Framework.Controls.LxTextBox();
            this.cboDYNT_DVCD_DRG = new Lime.Framework.Controls.LxComboBox();
            this.lxTitleLabel8 = new Lime.Framework.Controls.LxTitleLabel();
            this.chkReBurn = new Lime.Framework.Controls.LxCheckBox();
            this.txtTraiUsprShrt = new Lime.Framework.Controls.LxTextBox();
            this.txtAsctRgnoCd = new Lime.Framework.Controls.LxTextBox();
            this.lxLabel1 = new Lime.Framework.Controls.LxLabel();
            this.cboRealMdcrDrCd = new Lime.Framework.Controls.LxDoctorListCombo();
            this.cboMdcrDrCd = new Lime.Framework.Controls.LxDoctorListCombo();
            this.lxTextBox3 = new Lime.Framework.Controls.LxTextBox();
            this.cboDcntRdiaCd = new Lime.Framework.Controls.LxComboBox();
            this.cboCmhsDvcd = new Lime.Framework.Controls.LxOverallCombo();
            this.txtSrrn = new Lime.Framework.Controls.LxTextBox();
            this.cboMcchCmptDvcd = new Lime.Framework.Controls.LxOverallCombo();
            this.txtFrrn = new Lime.Framework.Controls.LxTextBox();
            this.cboFrvsRvstDvcd = new Lime.Framework.Controls.LxOverallCombo();
            this.chkOthrInstRefrYn = new Lime.Framework.Controls.LxCheckBox();
            this.cboInsnTycd = new Lime.Framework.Controls.LxOverallCombo();
            this.LxTitleLabel3 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtMdadPrmtNo = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel4 = new Lime.Framework.Controls.LxTitleLabel();
            this.cboDyWardYn = new Lime.Framework.Controls.LxComboBox();
            this.txtUschAplyCd = new Lime.Framework.Controls.LxTextBox();
            this.cboUschAplyCd = new Lime.Framework.Controls.LxComboBox();
            this.txtFrvsRvstDvcd = new Lime.Framework.Controls.LxTextBox();
            this.cboExcpResnCd = new Lime.Framework.Controls.LxComboBox();
            this.txtInsnTycd = new Lime.Framework.Controls.LxTextBox();
            this.cboMdcrDeptCd = new Lime.Framework.Controls.LxComboBox();
            this.txtFcltAplyYn1 = new Lime.Framework.Controls.LxTextBox();
            this.lblOthrInstRefrYn = new Lime.Framework.Controls.LxTitleLabel();
            this.txtFcltAplyYn2 = new Lime.Framework.Controls.LxTextBox();
            this.cboAsstTycd = new Lime.Framework.Controls.LxComboBox();
            this.LxTitleLabel6 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtRrno = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel5 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtSmcrDvcd = new Lime.Framework.Controls.LxTextBox();
            this.lblPid = new Lime.Framework.Controls.LxTitleLabel();
            this.lblFcltAplyYn = new Lime.Framework.Controls.LxTitleLabel();
            this.txtHllfMncsBlce = new Lime.Framework.Controls.LxTextBox();
            this.txtCmhsPathDvcd = new Lime.Framework.Controls.LxTextBox();
            this.lblPtNm = new Lime.Framework.Controls.LxTitleLabel();
            this.txtMdcrDrCd = new Lime.Framework.Controls.LxTextBox();
            this.txtHllfMncsClamAmt = new Lime.Framework.Controls.LxTextBox();
            this.txtMdcrDeptCd = new Lime.Framework.Controls.LxTextBox();
            this.txtOldHllfMncsBlce = new Lime.Framework.Controls.LxTextBox();
            this.lblFrrn = new Lime.Framework.Controls.LxTitleLabel();
            this.txtMcchCmptDvcd = new Lime.Framework.Controls.LxTextBox();
            this.mskMdcrTime = new Lime.Framework.Controls.LxMaskedEdit();
            this.txtExcpResnCd = new Lime.Framework.Controls.LxTextBox();
            this.lblMdcrDd = new Lime.Framework.Controls.LxTitleLabel();
            this.txtAsstTycd = new Lime.Framework.Controls.LxTextBox();
            this.mskMdcrDd = new Lime.Framework.Controls.LxMaskedEdit();
            this.txtDyWardYn = new Lime.Framework.Controls.LxTextBox();
            this.lblEcoiCd = new Lime.Framework.Controls.LxTitleLabel();
            this.lblDyWardYn = new Lime.Framework.Controls.LxTitleLabel();
            this.lblExcpResnCd = new Lime.Framework.Controls.LxTitleLabel();
            this.lblTbrcDvcd = new Lime.Framework.Controls.LxTitleLabel();
            this.txtCfscRgnoCd = new Lime.Framework.Controls.LxTextBox();
            this.lxTitleLabel7 = new Lime.Framework.Controls.LxTitleLabel();
            this.lblHllfMncsBlce = new Lime.Framework.Controls.LxTitleLabel();
            this.LxTitleLabel1 = new Lime.Framework.Controls.LxTitleLabel();
            this.lblMdcrDeptCd = new Lime.Framework.Controls.LxTitleLabel();
            this.lblCmhsDvcd = new Lime.Framework.Controls.LxTitleLabel();
            this.lblOldHllfMncsBlce = new Lime.Framework.Controls.LxTitleLabel();
            this.lblAsstTycd = new Lime.Framework.Controls.LxTitleLabel();
            this.LxTitleLabel2 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtAge = new Lime.Framework.Controls.LxTextBox();
            this.lblMcchCmptDvcd = new Lime.Framework.Controls.LxTitleLabel();
            this.lblInsnTycd = new Lime.Framework.Controls.LxTitleLabel();
            this.lblFrvsRvstDvcd = new Lime.Framework.Controls.LxTitleLabel();
            this.lblUschAplyCd = new Lime.Framework.Controls.LxTitleLabel();
            this.txtSexDvcd = new Lime.Framework.Controls.LxTextBox();
            this.lblVcodeCd = new Lime.Framework.Controls.LxTitleLabel();
            this.txtPid = new Lime.Framework.Controls.LxTextBox();
            this.txtPtNm = new Lime.Framework.Controls.LxTextBox();
            this.cboSmcrYn = new Lime.Framework.Controls.LxComboBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).BeginInit();
            this.pnlBase.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitlePanel1)).BeginInit();
            this.lxTitlePanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lblIncsDr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPtMdcrStatDvcd9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblDisasterSupt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPregnant)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblMediParams)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblMDCAREHSPTHSPTZYN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblForceChange)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNhic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel1)).BeginInit();
            this.lxPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboEcoiCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTbrcDvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboEmrmMmcdCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblEmrmMmcdCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblClphTel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtClphTel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDYNT_DVCD_DRG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitleLabel8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkReBurn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTraiUsprShrt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAsctRgnoCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboRealMdcrDrCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboMdcrDrCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTextBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDcntRdiaCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboCmhsDvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSrrn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboMcchCmptDvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrrn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboFrvsRvstDvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOthrInstRefrYn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboInsnTycd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMdadPrmtNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDyWardYn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUschAplyCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboUschAplyCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrvsRvstDvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboExcpResnCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInsnTycd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboMdcrDeptCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFcltAplyYn1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblOthrInstRefrYn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFcltAplyYn2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboAsstTycd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRrno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSmcrDvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblFcltAplyYn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHllfMncsBlce)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCmhsPathDvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPtNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMdcrDrCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHllfMncsClamAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMdcrDeptCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOldHllfMncsBlce)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblFrrn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMcchCmptDvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mskMdcrTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtExcpResnCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblMdcrDd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAsstTycd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mskMdcrDd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDyWardYn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblEcoiCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblDyWardYn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblExcpResnCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTbrcDvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCfscRgnoCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitleLabel7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblHllfMncsBlce)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblMdcrDeptCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCmhsDvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblOldHllfMncsBlce)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblAsstTycd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAge)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblMcchCmptDvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblInsnTycd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblFrvsRvstDvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblUschAplyCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSexDvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblVcodeCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPtNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboSmcrYn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBase
            // 
            this.pnlBase.Controls.Add(this.lxTitlePanel1);
            this.pnlBase.Size = new System.Drawing.Size(854, 209);
            // 
            // lxTitlePanel1
            // 
            this.lxTitlePanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.lxTitlePanel1.BottomBarVisible = false;
            this.lxTitlePanel1.BottomText = "";
            this.lxTitlePanel1.Controls.Add(this.lblIncsDr);
            this.lxTitlePanel1.Controls.Add(this.lblPtMdcrStatDvcd9);
            this.lxTitlePanel1.Controls.Add(this.lblDisasterSupt);
            this.lxTitlePanel1.Controls.Add(this.lblPregnant);
            this.lxTitlePanel1.Controls.Add(this.lblMediParams);
            this.lxTitlePanel1.Controls.Add(this.lblMDCAREHSPTHSPTZYN);
            this.lxTitlePanel1.Controls.Add(this.lblForceChange);
            this.lxTitlePanel1.Controls.Add(this.btnNhic);
            this.lxTitlePanel1.Controls.Add(this.lxPanel1);
            this.lxTitlePanel1.Controls.Add(this.cboSmcrYn);
            this.lxTitlePanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lxTitlePanel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxTitlePanel1.Location = new System.Drawing.Point(0, 0);
            this.lxTitlePanel1.Name = "lxTitlePanel1";
            this.lxTitlePanel1.Padding = new System.Windows.Forms.Padding(3);
            this.lxTitlePanel1.Size = new System.Drawing.Size(854, 209);
            this.lxTitlePanel1.TabIndex = 7;
            this.lxTitlePanel1.TitleText = "환자정보";
            // 
            // lblIncsDr
            // 
            appearance1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance1.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance1.FontData.BoldAsString = "True";
            appearance1.FontData.Name = "맑은 고딕";
            appearance1.FontData.SizeInPoints = 9F;
            appearance1.ForeColor = System.Drawing.Color.Red;
            appearance1.TextHAlignAsString = "Left";
            appearance1.TextVAlignAsString = "Middle";
            this.lblIncsDr.Appearance = appearance1;
            this.lblIncsDr.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.None;
            this.lblIncsDr.Location = new System.Drawing.Point(167, 8);
            this.lblIncsDr.Name = "lblIncsDr";
            this.lblIncsDr.Size = new System.Drawing.Size(80, 21);
            this.lblIncsDr.TabIndex = 41;
            this.lblIncsDr.Text = "★산재지정의";
            this.lblIncsDr.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblIncsDr.UseLimeStyle = false;
            this.lblIncsDr.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.lblIncsDr.Visible = false;
            // 
            // lblPtMdcrStatDvcd9
            // 
            this.lblPtMdcrStatDvcd9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            appearance2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance2.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance2.FontData.BoldAsString = "True";
            appearance2.FontData.Name = "맑은 고딕";
            appearance2.FontData.SizeInPoints = 9F;
            appearance2.ForeColor = System.Drawing.Color.Red;
            appearance2.TextHAlignAsString = "Left";
            appearance2.TextVAlignAsString = "Middle";
            this.lblPtMdcrStatDvcd9.Appearance = appearance2;
            this.lblPtMdcrStatDvcd9.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.None;
            this.lblPtMdcrStatDvcd9.Location = new System.Drawing.Point(247, 8);
            this.lblPtMdcrStatDvcd9.Name = "lblPtMdcrStatDvcd9";
            this.lblPtMdcrStatDvcd9.Size = new System.Drawing.Size(54, 21);
            this.lblPtMdcrStatDvcd9.TabIndex = 41;
            this.lblPtMdcrStatDvcd9.Text = "★과취소";
            this.lblPtMdcrStatDvcd9.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblPtMdcrStatDvcd9.UseLimeStyle = false;
            this.lblPtMdcrStatDvcd9.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.lblPtMdcrStatDvcd9.Visible = false;
            // 
            // lblDisasterSupt
            // 
            this.lblDisasterSupt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            appearance3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance3.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance3.FontData.BoldAsString = "True";
            appearance3.FontData.Name = "맑은 고딕";
            appearance3.FontData.SizeInPoints = 9F;
            appearance3.ForeColor = System.Drawing.Color.Red;
            appearance3.TextHAlignAsString = "Left";
            appearance3.TextVAlignAsString = "Middle";
            this.lblDisasterSupt.Appearance = appearance3;
            this.lblDisasterSupt.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.None;
            this.lblDisasterSupt.Location = new System.Drawing.Point(301, 8);
            this.lblDisasterSupt.Name = "lblDisasterSupt";
            this.lblDisasterSupt.Size = new System.Drawing.Size(150, 21);
            this.lblDisasterSupt.TabIndex = 41;
            this.lblDisasterSupt.Text = "★재난지원 (코로나 재택)";
            this.lblDisasterSupt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblDisasterSupt.UseLimeStyle = false;
            this.lblDisasterSupt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.lblDisasterSupt.Visible = false;
            // 
            // lblPregnant
            // 
            this.lblPregnant.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            appearance4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance4.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance4.FontData.BoldAsString = "True";
            appearance4.FontData.Name = "맑은 고딕";
            appearance4.FontData.SizeInPoints = 9F;
            appearance4.ForeColor = System.Drawing.Color.Red;
            appearance4.TextHAlignAsString = "Left";
            appearance4.TextVAlignAsString = "Middle";
            this.lblPregnant.Appearance = appearance4;
            this.lblPregnant.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.None;
            this.lblPregnant.Location = new System.Drawing.Point(451, 8);
            this.lblPregnant.Name = "lblPregnant";
            this.lblPregnant.Size = new System.Drawing.Size(43, 21);
            this.lblPregnant.TabIndex = 40;
            this.lblPregnant.Text = "★임부";
            this.toolTip1.SetToolTip(this.lblPregnant, "임부 등록된 환자");
            this.lblPregnant.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblPregnant.UseLimeStyle = false;
            this.lblPregnant.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.lblPregnant.Visible = false;
            // 
            // lblMediParams
            // 
            this.lblMediParams.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            appearance5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance5.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance5.FontData.BoldAsString = "True";
            appearance5.FontData.Name = "맑은 고딕";
            appearance5.FontData.SizeInPoints = 9F;
            appearance5.ForeColor = System.Drawing.Color.Red;
            appearance5.TextHAlignAsString = "Left";
            appearance5.TextVAlignAsString = "Middle";
            this.lblMediParams.Appearance = appearance5;
            this.lblMediParams.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.None;
            this.lblMediParams.Location = new System.Drawing.Point(105, 7);
            this.lblMediParams.Name = "lblMediParams";
            this.lblMediParams.Size = new System.Drawing.Size(67, 23);
            this.lblMediParams.TabIndex = 39;
            this.lblMediParams.Text = "LIME유저";
            this.lblMediParams.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblMediParams.UseLimeStyle = false;
            this.lblMediParams.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.lblMediParams.Visible = false;
            // 
            // lblMDCAREHSPTHSPTZYN
            // 
            this.lblMDCAREHSPTHSPTZYN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            appearance6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance6.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance6.FontData.BoldAsString = "True";
            appearance6.FontData.Name = "맑은 고딕";
            appearance6.FontData.SizeInPoints = 9F;
            appearance6.ForeColor = System.Drawing.Color.Red;
            appearance6.TextHAlignAsString = "Left";
            appearance6.TextVAlignAsString = "Middle";
            this.lblMDCAREHSPTHSPTZYN.Appearance = appearance6;
            this.lblMDCAREHSPTHSPTZYN.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.None;
            this.lblMDCAREHSPTHSPTZYN.Location = new System.Drawing.Point(494, 8);
            this.lblMDCAREHSPTHSPTZYN.Name = "lblMDCAREHSPTHSPTZYN";
            this.lblMDCAREHSPTHSPTZYN.Size = new System.Drawing.Size(110, 21);
            this.lblMDCAREHSPTHSPTZYN.TabIndex = 39;
            this.lblMDCAREHSPTHSPTZYN.Text = "★요양병원 입원중";
            this.toolTip1.SetToolTip(this.lblMDCAREHSPTHSPTZYN, "Y.요양병원에 입원 중인 환자입니다. 의료급여의뢰서가 없을 시 진료비를 전액 부담하게 됨을 안내하세요.");
            this.lblMDCAREHSPTHSPTZYN.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblMDCAREHSPTHSPTZYN.UseLimeStyle = false;
            this.lblMDCAREHSPTHSPTZYN.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.lblMDCAREHSPTHSPTZYN.Visible = false;
            // 
            // lblForceChange
            // 
            this.lblForceChange.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            appearance7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance7.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance7.FontData.BoldAsString = "True";
            appearance7.FontData.Name = "맑은 고딕";
            appearance7.FontData.SizeInPoints = 9F;
            appearance7.ForeColor = System.Drawing.Color.Blue;
            appearance7.TextHAlignAsString = "Left";
            appearance7.TextVAlignAsString = "Middle";
            this.lblForceChange.Appearance = appearance7;
            this.lblForceChange.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.None;
            this.lblForceChange.Location = new System.Drawing.Point(610, 8);
            this.lblForceChange.Name = "lblForceChange";
            this.lblForceChange.Size = new System.Drawing.Size(238, 21);
            this.lblForceChange.TabIndex = 38;
            this.lblForceChange.Text = "※ 보조유형 또는 산정특례가 강제 적용 됨";
            this.lblForceChange.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblForceChange.UseLimeStyle = false;
            this.lblForceChange.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.lblForceChange.Visible = false;
            // 
            // btnNhic
            // 
            appearance8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance8.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance8.FontData.BoldAsString = "False";
            appearance8.FontData.Name = "맑은 고딕";
            appearance8.FontData.SizeInPoints = 9F;
            appearance8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(90)))), ((int)(((byte)(20)))));
            appearance8.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance8.TextHAlignAsString = "Center";
            appearance8.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance8.TextVAlignAsString = "Middle";
            this.btnNhic.Appearance = appearance8;
            this.btnNhic.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat;
            appearance9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance9.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance9.FontData.BoldAsString = "True";
            appearance9.FontData.Name = "맑은 고딕";
            appearance9.FontData.SizeInPoints = 9F;
            appearance9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance9.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance9.TextHAlignAsString = "Center";
            appearance9.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance9.TextVAlignAsString = "Middle";
            this.btnNhic.HotTrackAppearance = appearance9;
            this.btnNhic.Location = new System.Drawing.Point(826, 11);
            this.btnNhic.Name = "btnNhic";
            appearance10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance10.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance10.FontData.BoldAsString = "True";
            appearance10.FontData.Name = "맑은 고딕";
            appearance10.FontData.SizeInPoints = 8F;
            appearance10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance10.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance10.TextHAlignAsString = "Center";
            appearance10.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance10.TextVAlignAsString = "Middle";
            this.btnNhic.PressedAppearance = appearance10;
            this.btnNhic.Size = new System.Drawing.Size(10, 27);
            this.btnNhic.TabIndex = 29;
            this.btnNhic.Text = "자격조회";
            this.btnNhic.UseFlatMode = Infragistics.Win.DefaultableBoolean.False;
            this.btnNhic.UseHotTracking = Infragistics.Win.DefaultableBoolean.True;
            this.btnNhic.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.btnNhic.Visible = false;
            this.btnNhic.WrapText = false;
            // 
            // lxPanel1
            // 
            this.lxPanel1.BackColor = System.Drawing.Color.White;
            this.lxPanel1.Controls.Add(this.cboEcoiCd);
            this.lxPanel1.Controls.Add(this.txtTbrcDvcd);
            this.lxPanel1.Controls.Add(this.cboEmrmMmcdCd);
            this.lxPanel1.Controls.Add(this.lblEmrmMmcdCd);
            this.lxPanel1.Controls.Add(this.lblClphTel);
            this.lxPanel1.Controls.Add(this.txtClphTel);
            this.lxPanel1.Controls.Add(this.cboDYNT_DVCD_DRG);
            this.lxPanel1.Controls.Add(this.lxTitleLabel8);
            this.lxPanel1.Controls.Add(this.chkReBurn);
            this.lxPanel1.Controls.Add(this.txtTraiUsprShrt);
            this.lxPanel1.Controls.Add(this.txtAsctRgnoCd);
            this.lxPanel1.Controls.Add(this.lxLabel1);
            this.lxPanel1.Controls.Add(this.cboRealMdcrDrCd);
            this.lxPanel1.Controls.Add(this.cboMdcrDrCd);
            this.lxPanel1.Controls.Add(this.lxTextBox3);
            this.lxPanel1.Controls.Add(this.cboDcntRdiaCd);
            this.lxPanel1.Controls.Add(this.cboCmhsDvcd);
            this.lxPanel1.Controls.Add(this.txtSrrn);
            this.lxPanel1.Controls.Add(this.cboMcchCmptDvcd);
            this.lxPanel1.Controls.Add(this.txtFrrn);
            this.lxPanel1.Controls.Add(this.cboFrvsRvstDvcd);
            this.lxPanel1.Controls.Add(this.chkOthrInstRefrYn);
            this.lxPanel1.Controls.Add(this.cboInsnTycd);
            this.lxPanel1.Controls.Add(this.LxTitleLabel3);
            this.lxPanel1.Controls.Add(this.txtMdadPrmtNo);
            this.lxPanel1.Controls.Add(this.LxTitleLabel4);
            this.lxPanel1.Controls.Add(this.cboDyWardYn);
            this.lxPanel1.Controls.Add(this.txtUschAplyCd);
            this.lxPanel1.Controls.Add(this.cboUschAplyCd);
            this.lxPanel1.Controls.Add(this.txtFrvsRvstDvcd);
            this.lxPanel1.Controls.Add(this.cboExcpResnCd);
            this.lxPanel1.Controls.Add(this.txtInsnTycd);
            this.lxPanel1.Controls.Add(this.cboMdcrDeptCd);
            this.lxPanel1.Controls.Add(this.txtFcltAplyYn1);
            this.lxPanel1.Controls.Add(this.lblOthrInstRefrYn);
            this.lxPanel1.Controls.Add(this.txtFcltAplyYn2);
            this.lxPanel1.Controls.Add(this.cboAsstTycd);
            this.lxPanel1.Controls.Add(this.LxTitleLabel6);
            this.lxPanel1.Controls.Add(this.txtRrno);
            this.lxPanel1.Controls.Add(this.LxTitleLabel5);
            this.lxPanel1.Controls.Add(this.txtSmcrDvcd);
            this.lxPanel1.Controls.Add(this.lblPid);
            this.lxPanel1.Controls.Add(this.lblFcltAplyYn);
            this.lxPanel1.Controls.Add(this.txtHllfMncsBlce);
            this.lxPanel1.Controls.Add(this.txtCmhsPathDvcd);
            this.lxPanel1.Controls.Add(this.lblPtNm);
            this.lxPanel1.Controls.Add(this.txtMdcrDrCd);
            this.lxPanel1.Controls.Add(this.txtHllfMncsClamAmt);
            this.lxPanel1.Controls.Add(this.txtMdcrDeptCd);
            this.lxPanel1.Controls.Add(this.txtOldHllfMncsBlce);
            this.lxPanel1.Controls.Add(this.lblFrrn);
            this.lxPanel1.Controls.Add(this.txtMcchCmptDvcd);
            this.lxPanel1.Controls.Add(this.mskMdcrTime);
            this.lxPanel1.Controls.Add(this.txtExcpResnCd);
            this.lxPanel1.Controls.Add(this.lblMdcrDd);
            this.lxPanel1.Controls.Add(this.txtAsstTycd);
            this.lxPanel1.Controls.Add(this.mskMdcrDd);
            this.lxPanel1.Controls.Add(this.txtDyWardYn);
            this.lxPanel1.Controls.Add(this.lblEcoiCd);
            this.lxPanel1.Controls.Add(this.lblDyWardYn);
            this.lxPanel1.Controls.Add(this.lblExcpResnCd);
            this.lxPanel1.Controls.Add(this.lblTbrcDvcd);
            this.lxPanel1.Controls.Add(this.txtCfscRgnoCd);
            this.lxPanel1.Controls.Add(this.lxTitleLabel7);
            this.lxPanel1.Controls.Add(this.lblHllfMncsBlce);
            this.lxPanel1.Controls.Add(this.LxTitleLabel1);
            this.lxPanel1.Controls.Add(this.lblMdcrDeptCd);
            this.lxPanel1.Controls.Add(this.lblCmhsDvcd);
            this.lxPanel1.Controls.Add(this.lblOldHllfMncsBlce);
            this.lxPanel1.Controls.Add(this.lblAsstTycd);
            this.lxPanel1.Controls.Add(this.LxTitleLabel2);
            this.lxPanel1.Controls.Add(this.txtAge);
            this.lxPanel1.Controls.Add(this.lblMcchCmptDvcd);
            this.lxPanel1.Controls.Add(this.lblInsnTycd);
            this.lxPanel1.Controls.Add(this.lblFrvsRvstDvcd);
            this.lxPanel1.Controls.Add(this.lblUschAplyCd);
            this.lxPanel1.Controls.Add(this.txtSexDvcd);
            this.lxPanel1.Controls.Add(this.lblVcodeCd);
            this.lxPanel1.Controls.Add(this.txtPid);
            this.lxPanel1.Controls.Add(this.txtPtNm);
            this.lxPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lxPanel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxPanel1.Location = new System.Drawing.Point(3, 35);
            this.lxPanel1.Name = "lxPanel1";
            this.lxPanel1.Size = new System.Drawing.Size(848, 171);
            this.lxPanel1.TabIndex = 28;
            // 
            // cboEcoiCd
            // 
            appearance11.BackColor = System.Drawing.Color.White;
            appearance11.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance11.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboEcoiCd.Appearance = appearance11;
            this.cboEcoiCd.BackColor = System.Drawing.Color.White;
            this.cboEcoiCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance12.BackColor = System.Drawing.Color.Transparent;
            appearance12.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance12.BorderColor = System.Drawing.Color.Transparent;
            appearance12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance12.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboEcoiCd.ButtonAppearance = appearance12;
            this.cboEcoiCd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboEcoiCd.Location = new System.Drawing.Point(85, 143);
            this.cboEcoiCd.Name = "cboEcoiCd";
            appearance13.BackColor = System.Drawing.Color.White;
            appearance13.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance13.ForeColor = System.Drawing.Color.DarkGray;
            appearance13.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboEcoiCd.NullTextAppearance = appearance13;
            this.cboEcoiCd.ReadOnly = true;
            this.cboEcoiCd.SelectedValue = "";
            this.cboEcoiCd.Size = new System.Drawing.Size(116, 21);
            this.cboEcoiCd.TabIndex = 38;
            this.cboEcoiCd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboEcoiCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboEcoiCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtTbrcDvcd
            // 
            appearance14.BackColor = System.Drawing.Color.White;
            appearance14.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance14.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtTbrcDvcd.Appearance = appearance14;
            this.txtTbrcDvcd.AutoSize = false;
            this.txtTbrcDvcd.BackColor = System.Drawing.Color.White;
            this.txtTbrcDvcd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtTbrcDvcd.Location = new System.Drawing.Point(350, 143);
            this.txtTbrcDvcd.Name = "txtTbrcDvcd";
            appearance15.BackColor = System.Drawing.Color.White;
            appearance15.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance15.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtTbrcDvcd.NullTextAppearance = appearance15;
            this.txtTbrcDvcd.Size = new System.Drawing.Size(98, 22);
            this.txtTbrcDvcd.TabIndex = 11;
            this.txtTbrcDvcd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtTbrcDvcd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboEmrmMmcdCd
            // 
            appearance16.BackColor = System.Drawing.Color.White;
            appearance16.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance16.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance16.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboEmrmMmcdCd.Appearance = appearance16;
            this.cboEmrmMmcdCd.AutoSize = false;
            this.cboEmrmMmcdCd.BackColor = System.Drawing.Color.White;
            this.cboEmrmMmcdCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance17.BackColor = System.Drawing.Color.Transparent;
            appearance17.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance17.BorderColor = System.Drawing.Color.Transparent;
            appearance17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance17.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboEmrmMmcdCd.ButtonAppearance = appearance17;
            this.cboEmrmMmcdCd.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.OnMouseEnter;
            this.cboEmrmMmcdCd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboEmrmMmcdCd.Location = new System.Drawing.Point(453, 90);
            this.cboEmrmMmcdCd.Name = "cboEmrmMmcdCd";
            appearance18.BackColor = System.Drawing.Color.White;
            appearance18.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance18.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance18.ForeColor = System.Drawing.Color.DarkGray;
            appearance18.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboEmrmMmcdCd.NullTextAppearance = appearance18;
            this.cboEmrmMmcdCd.SelectedValue = "";
            this.cboEmrmMmcdCd.Size = new System.Drawing.Size(156, 22);
            this.cboEmrmMmcdCd.TabIndex = 37;
            this.cboEmrmMmcdCd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboEmrmMmcdCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboEmrmMmcdCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblEmrmMmcdCd
            // 
            appearance19.BackColor = System.Drawing.Color.Transparent;
            appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance19.FontData.Name = "맑은 고딕";
            appearance19.FontData.SizeInPoints = 9F;
            appearance19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance19.TextHAlignAsString = "Right";
            appearance19.TextVAlignAsString = "Middle";
            this.lblEmrmMmcdCd.Appearance = appearance19;
            this.lblEmrmMmcdCd.Location = new System.Drawing.Point(382, 90);
            this.lblEmrmMmcdCd.Margin = new System.Windows.Forms.Padding(0);
            this.lblEmrmMmcdCd.Name = "lblEmrmMmcdCd";
            this.lblEmrmMmcdCd.Size = new System.Drawing.Size(66, 22);
            this.lblEmrmMmcdCd.TabIndex = 36;
            this.lblEmrmMmcdCd.Tag = "C";
            this.lblEmrmMmcdCd.Text = "응급실주과";
            this.lblEmrmMmcdCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblEmrmMmcdCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblClphTel
            // 
            appearance20.BackColor = System.Drawing.Color.Transparent;
            appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance20.FontData.Name = "맑은 고딕";
            appearance20.FontData.SizeInPoints = 9F;
            appearance20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance20.TextHAlignAsString = "Right";
            appearance20.TextVAlignAsString = "Middle";
            this.lblClphTel.Appearance = appearance20;
            this.lblClphTel.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblClphTel.Location = new System.Drawing.Point(615, 9);
            this.lblClphTel.Margin = new System.Windows.Forms.Padding(0);
            this.lblClphTel.Name = "lblClphTel";
            this.lblClphTel.Size = new System.Drawing.Size(54, 23);
            this.lblClphTel.TabIndex = 34;
            this.lblClphTel.Text = "휴대전화";
            this.lblClphTel.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblClphTel.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtClphTel
            // 
            appearance21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance21.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance21.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance21.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance21.TextHAlignAsString = "Left";
            this.txtClphTel.Appearance = appearance21;
            this.txtClphTel.AutoSize = false;
            this.txtClphTel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtClphTel.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtClphTel.EnterKeyToTab = true;
            this.txtClphTel.Location = new System.Drawing.Point(672, 9);
            this.txtClphTel.MaxLength = 15;
            this.txtClphTel.Name = "txtClphTel";
            appearance22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance22.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance22.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance22.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtClphTel.NullTextAppearance = appearance22;
            this.txtClphTel.ReadOnly = true;
            this.txtClphTel.Size = new System.Drawing.Size(167, 23);
            this.txtClphTel.TabIndex = 35;
            this.txtClphTel.UseByteMaxLength = true;
            this.txtClphTel.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtClphTel.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboDYNT_DVCD_DRG
            // 
            appearance23.BackColor = System.Drawing.Color.White;
            appearance23.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance23.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance23.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboDYNT_DVCD_DRG.Appearance = appearance23;
            this.cboDYNT_DVCD_DRG.AutoSize = false;
            this.cboDYNT_DVCD_DRG.BackColor = System.Drawing.Color.White;
            this.cboDYNT_DVCD_DRG.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance24.BackColor = System.Drawing.Color.Transparent;
            appearance24.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance24.BorderColor = System.Drawing.Color.Transparent;
            appearance24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance24.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboDYNT_DVCD_DRG.ButtonAppearance = appearance24;
            this.cboDYNT_DVCD_DRG.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.OnMouseEnter;
            this.cboDYNT_DVCD_DRG.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboDYNT_DVCD_DRG.EnterKeyToTab = true;
            valueListItem3.DataValue = "Y";
            valueListItem3.DisplayText = "예";
            valueListItem4.DataValue = "N";
            valueListItem4.DisplayText = "아니오";
            this.cboDYNT_DVCD_DRG.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem3,
            valueListItem4});
            this.cboDYNT_DVCD_DRG.Location = new System.Drawing.Point(492, 142);
            this.cboDYNT_DVCD_DRG.Name = "cboDYNT_DVCD_DRG";
            appearance25.BackColor = System.Drawing.Color.White;
            appearance25.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance25.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance25.ForeColor = System.Drawing.Color.DarkGray;
            appearance25.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboDYNT_DVCD_DRG.NullTextAppearance = appearance25;
            this.cboDYNT_DVCD_DRG.ReadOnly = true;
            this.cboDYNT_DVCD_DRG.SelectedValue = "";
            this.cboDYNT_DVCD_DRG.Size = new System.Drawing.Size(117, 23);
            this.cboDYNT_DVCD_DRG.TabIndex = 33;
            this.cboDYNT_DVCD_DRG.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboDYNT_DVCD_DRG.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboDYNT_DVCD_DRG.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lxTitleLabel8
            // 
            appearance26.BackColor = System.Drawing.Color.Transparent;
            appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance26.FontData.Name = "맑은 고딕";
            appearance26.FontData.SizeInPoints = 9F;
            appearance26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance26.TextHAlignAsString = "Right";
            appearance26.TextVAlignAsString = "Middle";
            this.lxTitleLabel8.Appearance = appearance26;
            this.lxTitleLabel8.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.lxTitleLabel8.Location = new System.Drawing.Point(453, 142);
            this.lxTitleLabel8.Margin = new System.Windows.Forms.Padding(0);
            this.lxTitleLabel8.Name = "lxTitleLabel8";
            this.lxTitleLabel8.Size = new System.Drawing.Size(35, 23);
            this.lxTitleLabel8.TabIndex = 32;
            this.lxTitleLabel8.Text = "주/야";
            this.lxTitleLabel8.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lxTitleLabel8.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // chkReBurn
            // 
            appearance27.BackColor = System.Drawing.Color.Transparent;
            appearance27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.chkReBurn.Appearance = appearance27;
            this.chkReBurn.BackColor = System.Drawing.Color.Transparent;
            this.chkReBurn.BackColorInternal = System.Drawing.Color.Transparent;
            this.chkReBurn.Enabled = false;
            this.chkReBurn.Location = new System.Drawing.Point(9, 36);
            this.chkReBurn.Name = "chkReBurn";
            this.chkReBurn.Size = new System.Drawing.Size(16, 19);
            this.chkReBurn.TabIndex = 31;
            this.chkReBurn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.chkReBurn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.chkReBurn.Visible = false;
            // 
            // txtTraiUsprShrt
            // 
            appearance28.BackColor = System.Drawing.Color.White;
            appearance28.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance28.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance28.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtTraiUsprShrt.Appearance = appearance28;
            this.txtTraiUsprShrt.BackColor = System.Drawing.Color.White;
            this.txtTraiUsprShrt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtTraiUsprShrt.Enabled = false;
            this.txtTraiUsprShrt.Location = new System.Drawing.Point(909, 92);
            this.txtTraiUsprShrt.Name = "txtTraiUsprShrt";
            appearance29.BackColor = System.Drawing.Color.White;
            appearance29.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance29.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance29.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtTraiUsprShrt.NullTextAppearance = appearance29;
            this.txtTraiUsprShrt.Size = new System.Drawing.Size(83, 23);
            this.txtTraiUsprShrt.TabIndex = 30;
            this.txtTraiUsprShrt.TabStop = false;
            this.txtTraiUsprShrt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtTraiUsprShrt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.txtTraiUsprShrt.Visible = false;
            // 
            // txtAsctRgnoCd
            // 
            appearance30.BackColor = System.Drawing.Color.White;
            appearance30.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance30.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance30.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtAsctRgnoCd.Appearance = appearance30;
            this.txtAsctRgnoCd.BackColor = System.Drawing.Color.White;
            this.txtAsctRgnoCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtAsctRgnoCd.Enabled = false;
            this.txtAsctRgnoCd.Location = new System.Drawing.Point(909, 63);
            this.txtAsctRgnoCd.Name = "txtAsctRgnoCd";
            appearance31.BackColor = System.Drawing.Color.White;
            appearance31.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance31.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance31.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtAsctRgnoCd.NullTextAppearance = appearance31;
            this.txtAsctRgnoCd.Size = new System.Drawing.Size(83, 23);
            this.txtAsctRgnoCd.TabIndex = 30;
            this.txtAsctRgnoCd.TabStop = false;
            this.txtAsctRgnoCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtAsctRgnoCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.txtAsctRgnoCd.Visible = false;
            // 
            // lxLabel1
            // 
            appearance32.BackColor = System.Drawing.Color.Transparent;
            appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance32.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance32.FontData.Name = "맑은 고딕";
            appearance32.FontData.SizeInPoints = 9F;
            appearance32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance32.TextHAlignAsString = "Left";
            appearance32.TextVAlignAsString = "Middle";
            this.lxLabel1.Appearance = appearance32;
            this.lxLabel1.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.None;
            this.lxLabel1.Location = new System.Drawing.Point(526, 115);
            this.lxLabel1.Name = "lxLabel1";
            this.lxLabel1.Size = new System.Drawing.Size(10, 21);
            this.lxLabel1.TabIndex = 29;
            this.lxLabel1.Text = "/";
            this.lxLabel1.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lxLabel1.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboRealMdcrDrCd
            // 
            appearance33.BackColor = System.Drawing.Color.White;
            appearance33.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance33.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance33.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboRealMdcrDrCd.Appearance = appearance33;
            this.cboRealMdcrDrCd.BackColor = System.Drawing.Color.White;
            this.cboRealMdcrDrCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance34.BackColor = System.Drawing.Color.Transparent;
            appearance34.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance34.BorderColor = System.Drawing.Color.Transparent;
            appearance34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance34.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboRealMdcrDrCd.ButtonAppearance = appearance34;
            this.cboRealMdcrDrCd.ComboAddItemType = Lime.Framework.COMBO_ADD_ITEM_TYPE.None;
            this.cboRealMdcrDrCd.DefaultSelectValue = "";
            this.cboRealMdcrDrCd.DeptCD = "";
            this.cboRealMdcrDrCd.DisplayDept = false;
            this.cboRealMdcrDrCd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboRealMdcrDrCd.Location = new System.Drawing.Point(752, 64);
            this.cboRealMdcrDrCd.Name = "cboRealMdcrDrCd";
            appearance35.BackColor = System.Drawing.Color.White;
            appearance35.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance35.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance35.ForeColor = System.Drawing.Color.DarkGray;
            appearance35.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboRealMdcrDrCd.NullTextAppearance = appearance35;
            this.cboRealMdcrDrCd.ReadOnly = true;
            this.cboRealMdcrDrCd.SelectedValue = "";
            this.cboRealMdcrDrCd.Size = new System.Drawing.Size(87, 21);
            this.cboRealMdcrDrCd.TabIndex = 28;
            this.cboRealMdcrDrCd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboRealMdcrDrCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboRealMdcrDrCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboMdcrDrCd
            // 
            appearance36.BackColor = System.Drawing.Color.White;
            appearance36.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance36.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance36.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboMdcrDrCd.Appearance = appearance36;
            this.cboMdcrDrCd.BackColor = System.Drawing.Color.White;
            this.cboMdcrDrCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance37.BackColor = System.Drawing.Color.Transparent;
            appearance37.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance37.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance37.BorderColor = System.Drawing.Color.Transparent;
            appearance37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance37.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboMdcrDrCd.ButtonAppearance = appearance37;
            this.cboMdcrDrCd.ComboAddItemType = Lime.Framework.COMBO_ADD_ITEM_TYPE.None;
            this.cboMdcrDrCd.DefaultSelectValue = "";
            this.cboMdcrDrCd.DeptCD = "";
            this.cboMdcrDrCd.DisplayDept = false;
            this.cboMdcrDrCd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboMdcrDrCd.Location = new System.Drawing.Point(606, 64);
            this.cboMdcrDrCd.Name = "cboMdcrDrCd";
            appearance38.BackColor = System.Drawing.Color.White;
            appearance38.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance38.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance38.ForeColor = System.Drawing.Color.DarkGray;
            appearance38.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboMdcrDrCd.NullTextAppearance = appearance38;
            this.cboMdcrDrCd.ReadOnly = true;
            this.cboMdcrDrCd.SelectedValue = "";
            this.cboMdcrDrCd.Size = new System.Drawing.Size(87, 21);
            this.cboMdcrDrCd.TabIndex = 28;
            this.cboMdcrDrCd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboMdcrDrCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboMdcrDrCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lxTextBox3
            // 
            appearance39.BackColor = System.Drawing.Color.White;
            appearance39.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance39.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance39.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance39.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxTextBox3.Appearance = appearance39;
            this.lxTextBox3.AutoSize = false;
            this.lxTextBox3.BackColor = System.Drawing.Color.White;
            this.lxTextBox3.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.lxTextBox3.Location = new System.Drawing.Point(297, 196);
            this.lxTextBox3.MaxLength = 23;
            this.lxTextBox3.Name = "lxTextBox3";
            appearance40.BackColor = System.Drawing.Color.White;
            appearance40.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance40.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance40.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance40.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxTextBox3.NullTextAppearance = appearance40;
            this.lxTextBox3.Size = new System.Drawing.Size(86, 22);
            this.lxTextBox3.TabIndex = 26;
            this.lxTextBox3.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lxTextBox3.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboDcntRdiaCd
            // 
            appearance41.BackColor = System.Drawing.Color.White;
            appearance41.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance41.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance41.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboDcntRdiaCd.Appearance = appearance41;
            this.cboDcntRdiaCd.AutoSize = false;
            this.cboDcntRdiaCd.BackColor = System.Drawing.Color.White;
            this.cboDcntRdiaCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance42.BackColor = System.Drawing.Color.Transparent;
            appearance42.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance42.BorderColor = System.Drawing.Color.Transparent;
            appearance42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance42.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboDcntRdiaCd.ButtonAppearance = appearance42;
            this.cboDcntRdiaCd.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.OnMouseEnter;
            this.cboDcntRdiaCd.Location = new System.Drawing.Point(89, 196);
            this.cboDcntRdiaCd.Name = "cboDcntRdiaCd";
            appearance43.BackColor = System.Drawing.Color.White;
            appearance43.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance43.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance43.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance43.ForeColor = System.Drawing.Color.DarkGray;
            appearance43.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboDcntRdiaCd.NullTextAppearance = appearance43;
            this.cboDcntRdiaCd.SelectedValue = "";
            this.cboDcntRdiaCd.Size = new System.Drawing.Size(127, 22);
            this.cboDcntRdiaCd.TabIndex = 20;
            this.cboDcntRdiaCd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboDcntRdiaCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboDcntRdiaCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboCmhsDvcd
            // 
            this.cboCmhsDvcd.AddItemType = Lime.Framework.COMBO_ADD_ITEM_TYPE.None;
            appearance44.BackColor = System.Drawing.Color.White;
            appearance44.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance44.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance44.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance44.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance44.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboCmhsDvcd.Appearance = appearance44;
            this.cboCmhsDvcd.AutoSize = false;
            this.cboCmhsDvcd.BackColor = System.Drawing.Color.White;
            this.cboCmhsDvcd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance45.BackColor = System.Drawing.Color.Transparent;
            appearance45.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance45.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance45.BorderColor = System.Drawing.Color.Transparent;
            appearance45.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance45.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboCmhsDvcd.ButtonAppearance = appearance45;
            this.cboCmhsDvcd.DefaultSelectValue = "";
            this.cboCmhsDvcd.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.OnMouseEnter;
            this.cboCmhsDvcd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboCmhsDvcd.Location = new System.Drawing.Point(453, 63);
            this.cboCmhsDvcd.Name = "cboCmhsDvcd";
            appearance46.BackColor = System.Drawing.Color.White;
            appearance46.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance46.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance46.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance46.ForeColor = System.Drawing.Color.DarkGray;
            appearance46.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboCmhsDvcd.NullTextAppearance = appearance46;
            this.cboCmhsDvcd.OverallCode = "CMHS_DVCD";
            this.cboCmhsDvcd.SelectedValue = "";
            this.cboCmhsDvcd.Size = new System.Drawing.Size(105, 22);
            this.cboCmhsDvcd.TabIndex = 27;
            this.cboCmhsDvcd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboCmhsDvcd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboCmhsDvcd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtSrrn
            // 
            appearance47.BackColor = System.Drawing.Color.White;
            appearance47.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance47.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance47.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance47.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtSrrn.Appearance = appearance47;
            this.txtSrrn.AutoSize = false;
            this.txtSrrn.BackColor = System.Drawing.Color.White;
            this.txtSrrn.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtSrrn.Location = new System.Drawing.Point(181, 230);
            this.txtSrrn.Name = "txtSrrn";
            appearance48.BackColor = System.Drawing.Color.White;
            appearance48.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance48.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance48.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance48.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance48.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtSrrn.NullTextAppearance = appearance48;
            this.txtSrrn.Size = new System.Drawing.Size(61, 22);
            this.txtSrrn.TabIndex = 5;
            this.txtSrrn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtSrrn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboMcchCmptDvcd
            // 
            this.cboMcchCmptDvcd.AddItemType = Lime.Framework.COMBO_ADD_ITEM_TYPE.None;
            appearance49.BackColor = System.Drawing.Color.White;
            appearance49.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance49.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance49.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance49.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance49.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboMcchCmptDvcd.Appearance = appearance49;
            this.cboMcchCmptDvcd.AutoSize = false;
            this.cboMcchCmptDvcd.BackColor = System.Drawing.Color.White;
            this.cboMcchCmptDvcd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance50.BackColor = System.Drawing.Color.Transparent;
            appearance50.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance50.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance50.BorderColor = System.Drawing.Color.Transparent;
            appearance50.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance50.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboMcchCmptDvcd.ButtonAppearance = appearance50;
            this.cboMcchCmptDvcd.DefaultSelectValue = "";
            this.cboMcchCmptDvcd.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.OnMouseEnter;
            this.cboMcchCmptDvcd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboMcchCmptDvcd.Location = new System.Drawing.Point(252, 63);
            this.cboMcchCmptDvcd.Name = "cboMcchCmptDvcd";
            appearance51.BackColor = System.Drawing.Color.White;
            appearance51.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance51.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance51.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance51.ForeColor = System.Drawing.Color.DarkGray;
            appearance51.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboMcchCmptDvcd.NullTextAppearance = appearance51;
            this.cboMcchCmptDvcd.OverallCode = "MCCH_CMPT_DVCD";
            this.cboMcchCmptDvcd.SelectedValue = "";
            this.cboMcchCmptDvcd.Size = new System.Drawing.Size(127, 22);
            this.cboMcchCmptDvcd.TabIndex = 27;
            this.cboMcchCmptDvcd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboMcchCmptDvcd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboMcchCmptDvcd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtFrrn
            // 
            appearance52.BackColor = System.Drawing.Color.White;
            appearance52.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance52.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance52.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFrrn.Appearance = appearance52;
            this.txtFrrn.AutoSize = false;
            this.txtFrrn.BackColor = System.Drawing.Color.White;
            this.txtFrrn.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtFrrn.Location = new System.Drawing.Point(117, 230);
            this.txtFrrn.Name = "txtFrrn";
            appearance53.BackColor = System.Drawing.Color.White;
            appearance53.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance53.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance53.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance53.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFrrn.NullTextAppearance = appearance53;
            this.txtFrrn.Size = new System.Drawing.Size(61, 22);
            this.txtFrrn.TabIndex = 4;
            this.txtFrrn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtFrrn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboFrvsRvstDvcd
            // 
            this.cboFrvsRvstDvcd.AddItemType = Lime.Framework.COMBO_ADD_ITEM_TYPE.None;
            appearance54.BackColor = System.Drawing.Color.White;
            appearance54.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance54.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance54.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance54.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboFrvsRvstDvcd.Appearance = appearance54;
            this.cboFrvsRvstDvcd.AutoSize = false;
            this.cboFrvsRvstDvcd.BackColor = System.Drawing.Color.White;
            this.cboFrvsRvstDvcd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance55.BackColor = System.Drawing.Color.Transparent;
            appearance55.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance55.BorderColor = System.Drawing.Color.Transparent;
            appearance55.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance55.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboFrvsRvstDvcd.ButtonAppearance = appearance55;
            this.cboFrvsRvstDvcd.DefaultSelectValue = "";
            this.cboFrvsRvstDvcd.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.OnMouseEnter;
            this.cboFrvsRvstDvcd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboFrvsRvstDvcd.Location = new System.Drawing.Point(85, 63);
            this.cboFrvsRvstDvcd.Name = "cboFrvsRvstDvcd";
            appearance56.BackColor = System.Drawing.Color.White;
            appearance56.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance56.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance56.ForeColor = System.Drawing.Color.DarkGray;
            appearance56.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboFrvsRvstDvcd.NullTextAppearance = appearance56;
            this.cboFrvsRvstDvcd.OverallCode = "FRVS_RVST_DVCD";
            this.cboFrvsRvstDvcd.SelectedValue = "";
            this.cboFrvsRvstDvcd.Size = new System.Drawing.Size(103, 22);
            this.cboFrvsRvstDvcd.TabIndex = 27;
            this.cboFrvsRvstDvcd.Tag = "";
            this.cboFrvsRvstDvcd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboFrvsRvstDvcd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboFrvsRvstDvcd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // chkOthrInstRefrYn
            // 
            appearance57.BackColor = System.Drawing.Color.Transparent;
            appearance57.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.chkOthrInstRefrYn.Appearance = appearance57;
            this.chkOthrInstRefrYn.AutoSize = true;
            this.chkOthrInstRefrYn.BackColor = System.Drawing.Color.Transparent;
            this.chkOthrInstRefrYn.BackColorInternal = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.chkOthrInstRefrYn.Location = new System.Drawing.Point(449, 299);
            this.chkOthrInstRefrYn.Name = "chkOthrInstRefrYn";
            this.chkOthrInstRefrYn.Size = new System.Drawing.Size(59, 21);
            this.chkOthrInstRefrYn.TabIndex = 14;
            this.chkOthrInstRefrYn.Text = "타기관";
            this.chkOthrInstRefrYn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.chkOthrInstRefrYn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboInsnTycd
            // 
            this.cboInsnTycd.AddItemType = Lime.Framework.COMBO_ADD_ITEM_TYPE.None;
            appearance58.BackColor = System.Drawing.Color.White;
            appearance58.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance58.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance58.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance58.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboInsnTycd.Appearance = appearance58;
            this.cboInsnTycd.AutoSize = false;
            this.cboInsnTycd.BackColor = System.Drawing.Color.White;
            this.cboInsnTycd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance59.BackColor = System.Drawing.Color.Transparent;
            appearance59.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance59.BorderColor = System.Drawing.Color.Transparent;
            appearance59.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance59.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboInsnTycd.ButtonAppearance = appearance59;
            this.cboInsnTycd.DefaultSelectValue = "";
            this.cboInsnTycd.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.OnMouseEnter;
            this.cboInsnTycd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboInsnTycd.Location = new System.Drawing.Point(85, 36);
            this.cboInsnTycd.Name = "cboInsnTycd";
            appearance60.BackColor = System.Drawing.Color.White;
            appearance60.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance60.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance60.ForeColor = System.Drawing.Color.DarkGray;
            appearance60.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboInsnTycd.NullTextAppearance = appearance60;
            this.cboInsnTycd.OverallCode = "INSN_TYCD";
            this.cboInsnTycd.ReadOnly = true;
            this.cboInsnTycd.SelectedValue = "";
            this.cboInsnTycd.Size = new System.Drawing.Size(103, 22);
            this.cboInsnTycd.TabIndex = 27;
            this.cboInsnTycd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboInsnTycd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboInsnTycd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel3
            // 
            appearance61.BackColor = System.Drawing.Color.Transparent;
            appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance61.FontData.Name = "맑은 고딕";
            appearance61.FontData.SizeInPoints = 9F;
            appearance61.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance61.TextHAlignAsString = "Right";
            appearance61.TextVAlignAsString = "Middle";
            this.LxTitleLabel3.Appearance = appearance61;
            this.LxTitleLabel3.Location = new System.Drawing.Point(833, 302);
            this.LxTitleLabel3.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel3.Name = "LxTitleLabel3";
            this.LxTitleLabel3.Size = new System.Drawing.Size(29, 18);
            this.LxTitleLabel3.TabIndex = 0;
            this.LxTitleLabel3.Text = "결핵";
            this.LxTitleLabel3.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel3.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtMdadPrmtNo
            // 
            appearance62.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance62.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance62.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance62.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance62.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtMdadPrmtNo.Appearance = appearance62;
            this.txtMdadPrmtNo.AutoSize = false;
            this.txtMdadPrmtNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtMdadPrmtNo.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtMdadPrmtNo.Location = new System.Drawing.Point(85, 116);
            this.txtMdadPrmtNo.MaxLength = 23;
            this.txtMdadPrmtNo.Name = "txtMdadPrmtNo";
            appearance63.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance63.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance63.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance63.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance63.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtMdadPrmtNo.NullTextAppearance = appearance63;
            this.txtMdadPrmtNo.ReadOnly = true;
            this.txtMdadPrmtNo.Size = new System.Drawing.Size(230, 22);
            this.txtMdadPrmtNo.TabIndex = 26;
            this.txtMdadPrmtNo.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtMdadPrmtNo.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel4
            // 
            appearance64.BackColor = System.Drawing.Color.Transparent;
            appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance64.FontData.Name = "맑은 고딕";
            appearance64.FontData.SizeInPoints = 9F;
            appearance64.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance64.TextHAlignAsString = "Right";
            appearance64.TextVAlignAsString = "Middle";
            this.LxTitleLabel4.Appearance = appearance64;
            this.LxTitleLabel4.Location = new System.Drawing.Point(647, 196);
            this.LxTitleLabel4.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel4.Name = "LxTitleLabel4";
            this.LxTitleLabel4.Size = new System.Drawing.Size(54, 18);
            this.LxTitleLabel4.TabIndex = 0;
            this.LxTitleLabel4.Text = "선택진료";
            this.LxTitleLabel4.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel4.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboDyWardYn
            // 
            appearance65.BackColor = System.Drawing.Color.White;
            appearance65.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance65.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance65.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance65.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance65.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboDyWardYn.Appearance = appearance65;
            this.cboDyWardYn.AutoSize = false;
            this.cboDyWardYn.BackColor = System.Drawing.Color.White;
            this.cboDyWardYn.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance66.BackColor = System.Drawing.Color.Transparent;
            appearance66.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance66.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance66.BorderColor = System.Drawing.Color.Transparent;
            appearance66.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance66.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboDyWardYn.ButtonAppearance = appearance66;
            this.cboDyWardYn.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.OnMouseEnter;
            this.cboDyWardYn.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboDyWardYn.Location = new System.Drawing.Point(245, 142);
            this.cboDyWardYn.Name = "cboDyWardYn";
            appearance67.BackColor = System.Drawing.Color.White;
            appearance67.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance67.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance67.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance67.ForeColor = System.Drawing.Color.DarkGray;
            appearance67.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboDyWardYn.NullTextAppearance = appearance67;
            this.cboDyWardYn.SelectedValue = "";
            this.cboDyWardYn.Size = new System.Drawing.Size(70, 22);
            this.cboDyWardYn.TabIndex = 25;
            this.cboDyWardYn.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboDyWardYn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboDyWardYn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtUschAplyCd
            // 
            appearance68.BackColor = System.Drawing.Color.White;
            appearance68.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance68.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance68.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance68.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance68.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtUschAplyCd.Appearance = appearance68;
            this.txtUschAplyCd.AutoSize = false;
            this.txtUschAplyCd.BackColor = System.Drawing.Color.White;
            this.txtUschAplyCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtUschAplyCd.Location = new System.Drawing.Point(66, 325);
            this.txtUschAplyCd.Name = "txtUschAplyCd";
            appearance69.BackColor = System.Drawing.Color.White;
            appearance69.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance69.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance69.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance69.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance69.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtUschAplyCd.NullTextAppearance = appearance69;
            this.txtUschAplyCd.Size = new System.Drawing.Size(282, 22);
            this.txtUschAplyCd.TabIndex = 13;
            this.txtUschAplyCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtUschAplyCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboUschAplyCd
            // 
            appearance70.BackColor = System.Drawing.Color.White;
            appearance70.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance70.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance70.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance70.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance70.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboUschAplyCd.Appearance = appearance70;
            this.cboUschAplyCd.AutoSize = false;
            this.cboUschAplyCd.BackColor = System.Drawing.Color.White;
            this.cboUschAplyCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance71.BackColor = System.Drawing.Color.Transparent;
            appearance71.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance71.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance71.BorderColor = System.Drawing.Color.Transparent;
            appearance71.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance71.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboUschAplyCd.ButtonAppearance = appearance71;
            this.cboUschAplyCd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboUschAplyCd.Location = new System.Drawing.Point(85, 90);
            this.cboUschAplyCd.Name = "cboUschAplyCd";
            appearance72.BackColor = System.Drawing.Color.White;
            appearance72.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance72.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance72.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance72.ForeColor = System.Drawing.Color.DarkGray;
            appearance72.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboUschAplyCd.NullTextAppearance = appearance72;
            this.cboUschAplyCd.ReadOnly = true;
            this.cboUschAplyCd.SelectedValue = "";
            this.cboUschAplyCd.Size = new System.Drawing.Size(294, 22);
            this.cboUschAplyCd.TabIndex = 24;
            this.cboUschAplyCd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboUschAplyCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboUschAplyCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtFrvsRvstDvcd
            // 
            appearance73.BackColor = System.Drawing.Color.White;
            appearance73.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance73.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance73.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance73.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance73.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFrvsRvstDvcd.Appearance = appearance73;
            this.txtFrvsRvstDvcd.AutoSize = false;
            this.txtFrvsRvstDvcd.BackColor = System.Drawing.Color.White;
            this.txtFrvsRvstDvcd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtFrvsRvstDvcd.Location = new System.Drawing.Point(104, 298);
            this.txtFrvsRvstDvcd.Name = "txtFrvsRvstDvcd";
            appearance74.BackColor = System.Drawing.Color.White;
            appearance74.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance74.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance74.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance74.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance74.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFrvsRvstDvcd.NullTextAppearance = appearance74;
            this.txtFrvsRvstDvcd.Size = new System.Drawing.Size(93, 22);
            this.txtFrvsRvstDvcd.TabIndex = 8;
            this.txtFrvsRvstDvcd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtFrvsRvstDvcd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboExcpResnCd
            // 
            appearance75.BackColor = System.Drawing.Color.White;
            appearance75.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance75.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance75.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance75.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance75.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboExcpResnCd.Appearance = appearance75;
            this.cboExcpResnCd.AutoSize = false;
            this.cboExcpResnCd.BackColor = System.Drawing.Color.White;
            this.cboExcpResnCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance76.BackColor = System.Drawing.Color.Transparent;
            appearance76.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance76.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance76.BorderColor = System.Drawing.Color.Transparent;
            appearance76.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance76.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboExcpResnCd.ButtonAppearance = appearance76;
            this.cboExcpResnCd.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.OnMouseEnter;
            this.cboExcpResnCd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboExcpResnCd.Location = new System.Drawing.Point(672, 90);
            this.cboExcpResnCd.Name = "cboExcpResnCd";
            appearance77.BackColor = System.Drawing.Color.White;
            appearance77.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance77.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance77.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance77.ForeColor = System.Drawing.Color.DarkGray;
            appearance77.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboExcpResnCd.NullTextAppearance = appearance77;
            this.cboExcpResnCd.ReadOnly = true;
            this.cboExcpResnCd.SelectedValue = "";
            this.cboExcpResnCd.Size = new System.Drawing.Size(167, 22);
            this.cboExcpResnCd.TabIndex = 23;
            this.cboExcpResnCd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboExcpResnCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboExcpResnCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtInsnTycd
            // 
            appearance78.BackColor = System.Drawing.Color.White;
            appearance78.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance78.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance78.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance78.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance78.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtInsnTycd.Appearance = appearance78;
            this.txtInsnTycd.AutoSize = false;
            this.txtInsnTycd.BackColor = System.Drawing.Color.White;
            this.txtInsnTycd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtInsnTycd.Location = new System.Drawing.Point(104, 258);
            this.txtInsnTycd.Name = "txtInsnTycd";
            appearance79.BackColor = System.Drawing.Color.White;
            appearance79.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance79.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance79.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance79.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance79.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtInsnTycd.NullTextAppearance = appearance79;
            this.txtInsnTycd.Size = new System.Drawing.Size(93, 22);
            this.txtInsnTycd.TabIndex = 1;
            this.txtInsnTycd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtInsnTycd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboMdcrDeptCd
            // 
            appearance80.BackColor = System.Drawing.Color.White;
            appearance80.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance80.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance80.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance80.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance80.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboMdcrDeptCd.Appearance = appearance80;
            this.cboMdcrDeptCd.AutoSize = false;
            this.cboMdcrDeptCd.BackColor = System.Drawing.Color.White;
            this.cboMdcrDeptCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance81.BackColor = System.Drawing.Color.Transparent;
            appearance81.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance81.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance81.BorderColor = System.Drawing.Color.Transparent;
            appearance81.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance81.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboMdcrDeptCd.ButtonAppearance = appearance81;
            this.cboMdcrDeptCd.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.OnMouseEnter;
            this.cboMdcrDeptCd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboMdcrDeptCd.Location = new System.Drawing.Point(453, 36);
            this.cboMdcrDeptCd.Name = "cboMdcrDeptCd";
            appearance82.BackColor = System.Drawing.Color.White;
            appearance82.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance82.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance82.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance82.ForeColor = System.Drawing.Color.DarkGray;
            appearance82.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboMdcrDeptCd.NullTextAppearance = appearance82;
            this.cboMdcrDeptCd.ReadOnly = true;
            this.cboMdcrDeptCd.SelectedValue = "";
            this.cboMdcrDeptCd.Size = new System.Drawing.Size(156, 22);
            this.cboMdcrDeptCd.TabIndex = 20;
            this.cboMdcrDeptCd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboMdcrDeptCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboMdcrDeptCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtFcltAplyYn1
            // 
            appearance83.BackColor = System.Drawing.Color.White;
            appearance83.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance83.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance83.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance83.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance83.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFcltAplyYn1.Appearance = appearance83;
            this.txtFcltAplyYn1.AutoSize = false;
            this.txtFcltAplyYn1.BackColor = System.Drawing.Color.White;
            this.txtFcltAplyYn1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtFcltAplyYn1.Location = new System.Drawing.Point(482, 232);
            this.txtFcltAplyYn1.Name = "txtFcltAplyYn1";
            appearance84.BackColor = System.Drawing.Color.White;
            appearance84.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance84.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance84.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance84.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance84.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFcltAplyYn1.NullTextAppearance = appearance84;
            this.txtFcltAplyYn1.Size = new System.Drawing.Size(42, 22);
            this.txtFcltAplyYn1.TabIndex = 18;
            this.txtFcltAplyYn1.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtFcltAplyYn1.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblOthrInstRefrYn
            // 
            appearance85.BackColor = System.Drawing.Color.Transparent;
            appearance85.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance85.FontData.Name = "맑은 고딕";
            appearance85.FontData.SizeInPoints = 9F;
            appearance85.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance85.TextHAlignAsString = "Right";
            appearance85.TextVAlignAsString = "Middle";
            this.lblOthrInstRefrYn.Appearance = appearance85;
            this.lblOthrInstRefrYn.Location = new System.Drawing.Point(25, 262);
            this.lblOthrInstRefrYn.Margin = new System.Windows.Forms.Padding(0);
            this.lblOthrInstRefrYn.Name = "lblOthrInstRefrYn";
            this.lblOthrInstRefrYn.Size = new System.Drawing.Size(42, 18);
            this.lblOthrInstRefrYn.TabIndex = 0;
            this.lblOthrInstRefrYn.Text = "타기관";
            this.lblOthrInstRefrYn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblOthrInstRefrYn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtFcltAplyYn2
            // 
            appearance86.BackColor = System.Drawing.Color.White;
            appearance86.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance86.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance86.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance86.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance86.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFcltAplyYn2.Appearance = appearance86;
            this.txtFcltAplyYn2.AutoSize = false;
            this.txtFcltAplyYn2.BackColor = System.Drawing.Color.White;
            this.txtFcltAplyYn2.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtFcltAplyYn2.Location = new System.Drawing.Point(530, 232);
            this.txtFcltAplyYn2.Name = "txtFcltAplyYn2";
            appearance87.BackColor = System.Drawing.Color.White;
            appearance87.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance87.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance87.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance87.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance87.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFcltAplyYn2.NullTextAppearance = appearance87;
            this.txtFcltAplyYn2.Size = new System.Drawing.Size(48, 22);
            this.txtFcltAplyYn2.TabIndex = 19;
            this.txtFcltAplyYn2.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtFcltAplyYn2.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboAsstTycd
            // 
            appearance88.BackColor = System.Drawing.Color.White;
            appearance88.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance88.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance88.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance88.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance88.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboAsstTycd.Appearance = appearance88;
            this.cboAsstTycd.AutoSize = false;
            this.cboAsstTycd.BackColor = System.Drawing.Color.White;
            this.cboAsstTycd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance89.BackColor = System.Drawing.Color.Transparent;
            appearance89.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance89.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance89.BorderColor = System.Drawing.Color.Transparent;
            appearance89.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance89.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboAsstTycd.ButtonAppearance = appearance89;
            this.cboAsstTycd.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.OnMouseEnter;
            this.cboAsstTycd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboAsstTycd.Location = new System.Drawing.Point(252, 36);
            this.cboAsstTycd.Name = "cboAsstTycd";
            appearance90.BackColor = System.Drawing.Color.White;
            appearance90.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance90.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance90.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance90.ForeColor = System.Drawing.Color.DarkGray;
            appearance90.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboAsstTycd.NullTextAppearance = appearance90;
            this.cboAsstTycd.ReadOnly = true;
            this.cboAsstTycd.SelectedValue = "";
            this.cboAsstTycd.Size = new System.Drawing.Size(127, 22);
            this.cboAsstTycd.TabIndex = 20;
            this.cboAsstTycd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboAsstTycd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboAsstTycd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel6
            // 
            appearance91.BackColor = System.Drawing.Color.Transparent;
            appearance91.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance91.FontData.Name = "맑은 고딕";
            appearance91.FontData.SizeInPoints = 9F;
            appearance91.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance91.TextHAlignAsString = "Right";
            appearance91.TextVAlignAsString = "Middle";
            this.LxTitleLabel6.Appearance = appearance91;
            this.LxTitleLabel6.Location = new System.Drawing.Point(236, 199);
            this.LxTitleLabel6.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel6.Name = "LxTitleLabel6";
            this.LxTitleLabel6.Size = new System.Drawing.Size(54, 18);
            this.LxTitleLabel6.TabIndex = 0;
            this.LxTitleLabel6.Text = "할인직원";
            this.LxTitleLabel6.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel6.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtRrno
            // 
            appearance92.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance92.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance92.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance92.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance92.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance92.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtRrno.Appearance = appearance92;
            this.txtRrno.AutoSize = false;
            this.txtRrno.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtRrno.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtRrno.Location = new System.Drawing.Point(453, 9);
            this.txtRrno.Name = "txtRrno";
            appearance93.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance93.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance93.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance93.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance93.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance93.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtRrno.NullTextAppearance = appearance93;
            this.txtRrno.ReadOnly = true;
            this.txtRrno.Size = new System.Drawing.Size(105, 22);
            this.txtRrno.TabIndex = 4;
            this.txtRrno.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtRrno.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel5
            // 
            appearance94.BackColor = System.Drawing.Color.Transparent;
            appearance94.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance94.FontData.Name = "맑은 고딕";
            appearance94.FontData.SizeInPoints = 9F;
            appearance94.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance94.TextHAlignAsString = "Right";
            appearance94.TextVAlignAsString = "Middle";
            this.LxTitleLabel5.Appearance = appearance94;
            this.LxTitleLabel5.Location = new System.Drawing.Point(26, 196);
            this.LxTitleLabel5.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel5.Name = "LxTitleLabel5";
            this.LxTitleLabel5.Size = new System.Drawing.Size(54, 18);
            this.LxTitleLabel5.TabIndex = 0;
            this.LxTitleLabel5.Text = "할인코드";
            this.LxTitleLabel5.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel5.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtSmcrDvcd
            // 
            appearance95.BackColor = System.Drawing.Color.White;
            appearance95.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance95.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance95.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance95.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance95.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtSmcrDvcd.Appearance = appearance95;
            this.txtSmcrDvcd.AutoSize = false;
            this.txtSmcrDvcd.BackColor = System.Drawing.Color.White;
            this.txtSmcrDvcd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtSmcrDvcd.Location = new System.Drawing.Point(564, 258);
            this.txtSmcrDvcd.Name = "txtSmcrDvcd";
            appearance96.BackColor = System.Drawing.Color.White;
            appearance96.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance96.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance96.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance96.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance96.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtSmcrDvcd.NullTextAppearance = appearance96;
            this.txtSmcrDvcd.Size = new System.Drawing.Size(44, 22);
            this.txtSmcrDvcd.TabIndex = 1;
            this.txtSmcrDvcd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtSmcrDvcd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblPid
            // 
            appearance97.BackColor = System.Drawing.Color.Transparent;
            appearance97.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance97.FontData.Name = "맑은 고딕";
            appearance97.FontData.SizeInPoints = 9F;
            appearance97.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance97.TextHAlignAsString = "Right";
            appearance97.TextVAlignAsString = "Middle";
            this.lblPid.Appearance = appearance97;
            this.lblPid.Location = new System.Drawing.Point(28, 9);
            this.lblPid.Margin = new System.Windows.Forms.Padding(0);
            this.lblPid.Name = "lblPid";
            this.lblPid.Size = new System.Drawing.Size(54, 22);
            this.lblPid.TabIndex = 0;
            this.lblPid.Text = "환자번호";
            this.lblPid.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblPid.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblFcltAplyYn
            // 
            appearance98.BackColor = System.Drawing.Color.Transparent;
            appearance98.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance98.FontData.Name = "맑은 고딕";
            appearance98.FontData.SizeInPoints = 9F;
            appearance98.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance98.TextHAlignAsString = "Right";
            appearance98.TextVAlignAsString = "Middle";
            this.lblFcltAplyYn.Appearance = appearance98;
            this.lblFcltAplyYn.Location = new System.Drawing.Point(424, 234);
            this.lblFcltAplyYn.Margin = new System.Windows.Forms.Padding(0);
            this.lblFcltAplyYn.Name = "lblFcltAplyYn";
            this.lblFcltAplyYn.Size = new System.Drawing.Size(54, 18);
            this.lblFcltAplyYn.TabIndex = 0;
            this.lblFcltAplyYn.Text = "시설유무";
            this.lblFcltAplyYn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblFcltAplyYn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtHllfMncsBlce
            // 
            appearance99.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance99.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance99.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance99.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance99.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance99.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance99.TextHAlignAsString = "Right";
            this.txtHllfMncsBlce.Appearance = appearance99;
            this.txtHllfMncsBlce.AutoSize = false;
            this.txtHllfMncsBlce.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtHllfMncsBlce.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtHllfMncsBlce.Location = new System.Drawing.Point(538, 116);
            this.txtHllfMncsBlce.Name = "txtHllfMncsBlce";
            appearance100.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance100.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance100.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance100.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance100.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance100.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtHllfMncsBlce.NullTextAppearance = appearance100;
            this.txtHllfMncsBlce.ReadOnly = true;
            this.txtHllfMncsBlce.Size = new System.Drawing.Size(71, 22);
            this.txtHllfMncsBlce.TabIndex = 15;
            this.txtHllfMncsBlce.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtHllfMncsBlce.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtCmhsPathDvcd
            // 
            appearance101.BackColor = System.Drawing.Color.White;
            appearance101.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance101.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance101.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance101.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance101.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtCmhsPathDvcd.Appearance = appearance101;
            this.txtCmhsPathDvcd.AutoSize = false;
            this.txtCmhsPathDvcd.BackColor = System.Drawing.Color.White;
            this.txtCmhsPathDvcd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtCmhsPathDvcd.Location = new System.Drawing.Point(703, 258);
            this.txtCmhsPathDvcd.Name = "txtCmhsPathDvcd";
            appearance102.BackColor = System.Drawing.Color.White;
            appearance102.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance102.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance102.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance102.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance102.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtCmhsPathDvcd.NullTextAppearance = appearance102;
            this.txtCmhsPathDvcd.Size = new System.Drawing.Size(117, 22);
            this.txtCmhsPathDvcd.TabIndex = 7;
            this.txtCmhsPathDvcd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtCmhsPathDvcd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblPtNm
            // 
            appearance103.BackColor = System.Drawing.Color.Transparent;
            appearance103.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance103.FontData.Name = "맑은 고딕";
            appearance103.FontData.SizeInPoints = 9F;
            appearance103.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance103.TextHAlignAsString = "Right";
            appearance103.TextVAlignAsString = "Middle";
            this.lblPtNm.Appearance = appearance103;
            this.lblPtNm.Location = new System.Drawing.Point(195, 9);
            this.lblPtNm.Margin = new System.Windows.Forms.Padding(0);
            this.lblPtNm.Name = "lblPtNm";
            this.lblPtNm.Size = new System.Drawing.Size(54, 22);
            this.lblPtNm.TabIndex = 0;
            this.lblPtNm.Text = "환자명";
            this.lblPtNm.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblPtNm.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtMdcrDrCd
            // 
            appearance104.BackColor = System.Drawing.Color.White;
            appearance104.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance104.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance104.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance104.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance104.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtMdcrDrCd.Appearance = appearance104;
            this.txtMdcrDrCd.AutoSize = false;
            this.txtMdcrDrCd.BackColor = System.Drawing.Color.White;
            this.txtMdcrDrCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtMdcrDrCd.Location = new System.Drawing.Point(510, 258);
            this.txtMdcrDrCd.Name = "txtMdcrDrCd";
            appearance105.BackColor = System.Drawing.Color.White;
            appearance105.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance105.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance105.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance105.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance105.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtMdcrDrCd.NullTextAppearance = appearance105;
            this.txtMdcrDrCd.Size = new System.Drawing.Size(48, 22);
            this.txtMdcrDrCd.TabIndex = 1;
            this.txtMdcrDrCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtMdcrDrCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtHllfMncsClamAmt
            // 
            appearance106.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance106.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance106.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance106.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance106.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance106.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance106.TextHAlignAsString = "Right";
            this.txtHllfMncsClamAmt.Appearance = appearance106;
            this.txtHllfMncsClamAmt.AutoSize = false;
            this.txtHllfMncsClamAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtHllfMncsClamAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtHllfMncsClamAmt.Location = new System.Drawing.Point(672, 143);
            this.txtHllfMncsClamAmt.Name = "txtHllfMncsClamAmt";
            appearance107.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance107.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance107.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance107.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance107.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance107.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtHllfMncsClamAmt.NullTextAppearance = appearance107;
            this.txtHllfMncsClamAmt.ReadOnly = true;
            this.txtHllfMncsClamAmt.Size = new System.Drawing.Size(167, 22);
            this.txtHllfMncsClamAmt.TabIndex = 16;
            this.txtHllfMncsClamAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtHllfMncsClamAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtMdcrDeptCd
            // 
            appearance108.BackColor = System.Drawing.Color.White;
            appearance108.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance108.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance108.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance108.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance108.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtMdcrDeptCd.Appearance = appearance108;
            this.txtMdcrDeptCd.AutoSize = false;
            this.txtMdcrDeptCd.BackColor = System.Drawing.Color.White;
            this.txtMdcrDeptCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtMdcrDeptCd.Location = new System.Drawing.Point(407, 258);
            this.txtMdcrDeptCd.Name = "txtMdcrDeptCd";
            appearance109.BackColor = System.Drawing.Color.White;
            appearance109.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance109.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance109.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance109.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance109.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtMdcrDeptCd.NullTextAppearance = appearance109;
            this.txtMdcrDeptCd.Size = new System.Drawing.Size(97, 22);
            this.txtMdcrDeptCd.TabIndex = 3;
            this.txtMdcrDeptCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtMdcrDeptCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtOldHllfMncsBlce
            // 
            appearance110.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance110.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance110.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance110.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance110.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance110.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance110.TextHAlignAsString = "Right";
            this.txtOldHllfMncsBlce.Appearance = appearance110;
            this.txtOldHllfMncsBlce.AutoSize = false;
            this.txtOldHllfMncsBlce.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtOldHllfMncsBlce.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtOldHllfMncsBlce.Location = new System.Drawing.Point(453, 116);
            this.txtOldHllfMncsBlce.Name = "txtOldHllfMncsBlce";
            appearance111.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance111.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance111.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance111.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance111.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance111.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtOldHllfMncsBlce.NullTextAppearance = appearance111;
            this.txtOldHllfMncsBlce.ReadOnly = true;
            this.txtOldHllfMncsBlce.Size = new System.Drawing.Size(70, 22);
            this.txtOldHllfMncsBlce.TabIndex = 16;
            this.txtOldHllfMncsBlce.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtOldHllfMncsBlce.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblFrrn
            // 
            appearance112.BackColor = System.Drawing.Color.Transparent;
            appearance112.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance112.FontData.Name = "맑은 고딕";
            appearance112.FontData.SizeInPoints = 9F;
            appearance112.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance112.TextHAlignAsString = "Right";
            appearance112.TextVAlignAsString = "Middle";
            this.lblFrrn.Appearance = appearance112;
            this.lblFrrn.Location = new System.Drawing.Point(394, 9);
            this.lblFrrn.Margin = new System.Windows.Forms.Padding(0);
            this.lblFrrn.Name = "lblFrrn";
            this.lblFrrn.Size = new System.Drawing.Size(54, 22);
            this.lblFrrn.TabIndex = 0;
            this.lblFrrn.Text = "주민번호";
            this.lblFrrn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblFrrn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtMcchCmptDvcd
            // 
            appearance113.BackColor = System.Drawing.Color.White;
            appearance113.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance113.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance113.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance113.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance113.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtMcchCmptDvcd.Appearance = appearance113;
            this.txtMcchCmptDvcd.AutoSize = false;
            this.txtMcchCmptDvcd.BackColor = System.Drawing.Color.White;
            this.txtMcchCmptDvcd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtMcchCmptDvcd.Location = new System.Drawing.Point(236, 298);
            this.txtMcchCmptDvcd.Name = "txtMcchCmptDvcd";
            appearance114.BackColor = System.Drawing.Color.White;
            appearance114.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance114.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance114.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance114.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance114.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtMcchCmptDvcd.NullTextAppearance = appearance114;
            this.txtMcchCmptDvcd.Size = new System.Drawing.Size(92, 22);
            this.txtMcchCmptDvcd.TabIndex = 9;
            this.txtMcchCmptDvcd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtMcchCmptDvcd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // mskMdcrTime
            // 
            appearance115.BackColor = System.Drawing.Color.White;
            appearance115.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance115.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance115.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance115.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance115.ForeColorDisabled = System.Drawing.Color.DarkGray;
            appearance115.TextHAlignAsString = "Center";
            this.mskMdcrTime.Appearance = appearance115;
            this.mskMdcrTime.AutoSize = false;
            this.mskMdcrTime.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.mskMdcrTime.EditAs = Infragistics.Win.UltraWinMaskedEdit.EditAsType.UseSpecifiedMask;
            this.mskMdcrTime.InputMask = "hh:mm";
            this.mskMdcrTime.Location = new System.Drawing.Point(777, 36);
            this.mskMdcrTime.Name = "mskMdcrTime";
            this.mskMdcrTime.NonAutoSizeHeight = 21;
            this.mskMdcrTime.PromptChar = ' ';
            this.mskMdcrTime.ReadOnly = true;
            this.mskMdcrTime.Size = new System.Drawing.Size(62, 22);
            this.mskMdcrTime.TabIndex = 5;
            this.mskMdcrTime.Text = ":";
            this.mskMdcrTime.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.mskMdcrTime.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtExcpResnCd
            // 
            appearance116.BackColor = System.Drawing.Color.White;
            appearance116.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance116.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance116.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance116.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance116.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtExcpResnCd.Appearance = appearance116;
            this.txtExcpResnCd.AutoSize = false;
            this.txtExcpResnCd.BackColor = System.Drawing.Color.White;
            this.txtExcpResnCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtExcpResnCd.Location = new System.Drawing.Point(702, 286);
            this.txtExcpResnCd.Name = "txtExcpResnCd";
            appearance117.BackColor = System.Drawing.Color.White;
            appearance117.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance117.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance117.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance117.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance117.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtExcpResnCd.NullTextAppearance = appearance117;
            this.txtExcpResnCd.Size = new System.Drawing.Size(117, 22);
            this.txtExcpResnCd.TabIndex = 12;
            this.txtExcpResnCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtExcpResnCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblMdcrDd
            // 
            appearance118.BackColor = System.Drawing.Color.Transparent;
            appearance118.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance118.FontData.Name = "맑은 고딕";
            appearance118.FontData.SizeInPoints = 9F;
            appearance118.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance118.TextHAlignAsString = "Right";
            appearance118.TextVAlignAsString = "Middle";
            this.lblMdcrDd.Appearance = appearance118;
            this.lblMdcrDd.Location = new System.Drawing.Point(615, 36);
            this.lblMdcrDd.Margin = new System.Windows.Forms.Padding(0);
            this.lblMdcrDd.Name = "lblMdcrDd";
            this.lblMdcrDd.Size = new System.Drawing.Size(54, 22);
            this.lblMdcrDd.TabIndex = 0;
            this.lblMdcrDd.Text = "진료일자";
            this.lblMdcrDd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblMdcrDd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtAsstTycd
            // 
            appearance119.BackColor = System.Drawing.Color.White;
            appearance119.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance119.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance119.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance119.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance119.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtAsstTycd.Appearance = appearance119;
            this.txtAsstTycd.AutoSize = false;
            this.txtAsstTycd.BackColor = System.Drawing.Color.White;
            this.txtAsstTycd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtAsstTycd.Location = new System.Drawing.Point(236, 258);
            this.txtAsstTycd.Name = "txtAsstTycd";
            appearance120.BackColor = System.Drawing.Color.White;
            appearance120.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance120.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance120.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance120.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance120.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtAsstTycd.NullTextAppearance = appearance120;
            this.txtAsstTycd.Size = new System.Drawing.Size(92, 22);
            this.txtAsstTycd.TabIndex = 2;
            this.txtAsstTycd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtAsstTycd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // mskMdcrDd
            // 
            appearance121.BackColor = System.Drawing.Color.White;
            appearance121.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance121.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance121.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance121.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance121.ForeColorDisabled = System.Drawing.Color.DarkGray;
            appearance121.TextHAlignAsString = "Center";
            this.mskMdcrDd.Appearance = appearance121;
            this.mskMdcrDd.AutoSize = false;
            this.mskMdcrDd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.mskMdcrDd.EditAs = Infragistics.Win.UltraWinMaskedEdit.EditAsType.UseSpecifiedMask;
            this.mskMdcrDd.InputMask = "yyyy-mm-dd";
            this.mskMdcrDd.Location = new System.Drawing.Point(672, 36);
            this.mskMdcrDd.Name = "mskMdcrDd";
            this.mskMdcrDd.NonAutoSizeHeight = 21;
            this.mskMdcrDd.PromptChar = ' ';
            this.mskMdcrDd.ReadOnly = true;
            this.mskMdcrDd.Size = new System.Drawing.Size(102, 22);
            this.mskMdcrDd.TabIndex = 6;
            this.mskMdcrDd.Text = "--";
            this.mskMdcrDd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.mskMdcrDd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtDyWardYn
            // 
            appearance122.BackColor = System.Drawing.Color.White;
            appearance122.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance122.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance122.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance122.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance122.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtDyWardYn.Appearance = appearance122;
            this.txtDyWardYn.AutoSize = false;
            this.txtDyWardYn.BackColor = System.Drawing.Color.White;
            this.txtDyWardYn.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtDyWardYn.Location = new System.Drawing.Point(752, 218);
            this.txtDyWardYn.Name = "txtDyWardYn";
            appearance123.BackColor = System.Drawing.Color.White;
            appearance123.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance123.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance123.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance123.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance123.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtDyWardYn.NullTextAppearance = appearance123;
            this.txtDyWardYn.Size = new System.Drawing.Size(56, 22);
            this.txtDyWardYn.TabIndex = 10;
            this.txtDyWardYn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtDyWardYn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblEcoiCd
            // 
            appearance124.BackColor = System.Drawing.Color.Transparent;
            appearance124.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance124.FontData.Name = "맑은 고딕";
            appearance124.FontData.SizeInPoints = 9F;
            appearance124.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance124.TextHAlignAsString = "Right";
            appearance124.TextVAlignAsString = "Middle";
            this.lblEcoiCd.Appearance = appearance124;
            this.lblEcoiCd.Location = new System.Drawing.Point(29, 142);
            this.lblEcoiCd.Margin = new System.Windows.Forms.Padding(0);
            this.lblEcoiCd.Name = "lblEcoiCd";
            this.lblEcoiCd.Size = new System.Drawing.Size(54, 22);
            this.lblEcoiCd.TabIndex = 0;
            this.lblEcoiCd.Tag = "";
            this.lblEcoiCd.Text = "상해외인";
            this.lblEcoiCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblEcoiCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblDyWardYn
            // 
            appearance125.BackColor = System.Drawing.Color.Transparent;
            appearance125.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance125.FontData.Name = "맑은 고딕";
            appearance125.FontData.SizeInPoints = 9F;
            appearance125.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance125.TextHAlignAsString = "Right";
            appearance125.TextVAlignAsString = "Middle";
            this.lblDyWardYn.Appearance = appearance125;
            this.lblDyWardYn.Location = new System.Drawing.Point(200, 142);
            this.lblDyWardYn.Margin = new System.Windows.Forms.Padding(0);
            this.lblDyWardYn.Name = "lblDyWardYn";
            this.lblDyWardYn.Size = new System.Drawing.Size(42, 22);
            this.lblDyWardYn.TabIndex = 0;
            this.lblDyWardYn.Tag = "C";
            this.lblDyWardYn.Text = "낮병동";
            this.lblDyWardYn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblDyWardYn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblExcpResnCd
            // 
            appearance126.BackColor = System.Drawing.Color.Transparent;
            appearance126.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance126.FontData.Name = "맑은 고딕";
            appearance126.FontData.SizeInPoints = 9F;
            appearance126.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance126.TextHAlignAsString = "Right";
            appearance126.TextVAlignAsString = "Middle";
            this.lblExcpResnCd.Appearance = appearance126;
            this.lblExcpResnCd.Location = new System.Drawing.Point(615, 90);
            this.lblExcpResnCd.Margin = new System.Windows.Forms.Padding(0);
            this.lblExcpResnCd.Name = "lblExcpResnCd";
            this.lblExcpResnCd.Size = new System.Drawing.Size(54, 22);
            this.lblExcpResnCd.TabIndex = 0;
            this.lblExcpResnCd.Text = "예외사유";
            this.lblExcpResnCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblExcpResnCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblTbrcDvcd
            // 
            appearance127.BackColor = System.Drawing.Color.Transparent;
            appearance127.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance127.FontData.Name = "맑은 고딕";
            appearance127.FontData.SizeInPoints = 9F;
            appearance127.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance127.TextHAlignAsString = "Right";
            appearance127.TextVAlignAsString = "Middle";
            this.lblTbrcDvcd.Appearance = appearance127;
            this.lblTbrcDvcd.Location = new System.Drawing.Point(318, 143);
            this.lblTbrcDvcd.Margin = new System.Windows.Forms.Padding(0);
            this.lblTbrcDvcd.Name = "lblTbrcDvcd";
            this.lblTbrcDvcd.Size = new System.Drawing.Size(29, 22);
            this.lblTbrcDvcd.TabIndex = 0;
            this.lblTbrcDvcd.Text = "결핵";
            this.lblTbrcDvcd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblTbrcDvcd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtCfscRgnoCd
            // 
            appearance128.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance128.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance128.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance128.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance128.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance128.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtCfscRgnoCd.Appearance = appearance128;
            this.txtCfscRgnoCd.AutoSize = false;
            this.txtCfscRgnoCd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtCfscRgnoCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtCfscRgnoCd.Location = new System.Drawing.Point(672, 117);
            this.txtCfscRgnoCd.Name = "txtCfscRgnoCd";
            appearance129.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance129.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance129.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance129.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance129.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance129.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtCfscRgnoCd.NullTextAppearance = appearance129;
            this.txtCfscRgnoCd.ReadOnly = true;
            this.txtCfscRgnoCd.Size = new System.Drawing.Size(167, 22);
            this.txtCfscRgnoCd.TabIndex = 17;
            this.txtCfscRgnoCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtCfscRgnoCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lxTitleLabel7
            // 
            appearance130.BackColor = System.Drawing.Color.Transparent;
            appearance130.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance130.FontData.Name = "맑은 고딕";
            appearance130.FontData.SizeInPoints = 9F;
            appearance130.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance130.TextHAlignAsString = "Right";
            appearance130.TextVAlignAsString = "Middle";
            this.lxTitleLabel7.Appearance = appearance130;
            this.lxTitleLabel7.Location = new System.Drawing.Point(696, 63);
            this.lxTitleLabel7.Margin = new System.Windows.Forms.Padding(0);
            this.lxTitleLabel7.Name = "lxTitleLabel7";
            this.lxTitleLabel7.Size = new System.Drawing.Size(54, 22);
            this.lxTitleLabel7.TabIndex = 0;
            this.lxTitleLabel7.Text = "실진료의";
            this.lxTitleLabel7.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lxTitleLabel7.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblHllfMncsBlce
            // 
            appearance131.BackColor = System.Drawing.Color.Transparent;
            appearance131.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance131.FontData.Name = "맑은 고딕";
            appearance131.FontData.SizeInPoints = 9F;
            appearance131.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance131.TextHAlignAsString = "Right";
            appearance131.TextVAlignAsString = "Middle";
            this.lblHllfMncsBlce.Appearance = appearance131;
            this.lblHllfMncsBlce.Location = new System.Drawing.Point(615, 143);
            this.lblHllfMncsBlce.Margin = new System.Windows.Forms.Padding(0);
            this.lblHllfMncsBlce.Name = "lblHllfMncsBlce";
            this.lblHllfMncsBlce.Size = new System.Drawing.Size(54, 22);
            this.lblHllfMncsBlce.TabIndex = 0;
            this.lblHllfMncsBlce.Text = "청구액";
            this.lblHllfMncsBlce.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblHllfMncsBlce.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel1
            // 
            appearance132.BackColor = System.Drawing.Color.Transparent;
            appearance132.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance132.FontData.Name = "맑은 고딕";
            appearance132.FontData.SizeInPoints = 9F;
            appearance132.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance132.TextHAlignAsString = "Right";
            appearance132.TextVAlignAsString = "Middle";
            this.LxTitleLabel1.Appearance = appearance132;
            this.LxTitleLabel1.Location = new System.Drawing.Point(563, 63);
            this.LxTitleLabel1.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel1.Name = "LxTitleLabel1";
            this.LxTitleLabel1.Size = new System.Drawing.Size(42, 22);
            this.LxTitleLabel1.TabIndex = 0;
            this.LxTitleLabel1.Text = "진료의";
            this.LxTitleLabel1.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel1.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblMdcrDeptCd
            // 
            appearance133.BackColor = System.Drawing.Color.Transparent;
            appearance133.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance133.FontData.Name = "맑은 고딕";
            appearance133.FontData.SizeInPoints = 9F;
            appearance133.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance133.TextHAlignAsString = "Right";
            appearance133.TextVAlignAsString = "Middle";
            this.lblMdcrDeptCd.Appearance = appearance133;
            this.lblMdcrDeptCd.Location = new System.Drawing.Point(394, 36);
            this.lblMdcrDeptCd.Margin = new System.Windows.Forms.Padding(0);
            this.lblMdcrDeptCd.Name = "lblMdcrDeptCd";
            this.lblMdcrDeptCd.Size = new System.Drawing.Size(54, 22);
            this.lblMdcrDeptCd.TabIndex = 0;
            this.lblMdcrDeptCd.Text = "진료과";
            this.lblMdcrDeptCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblMdcrDeptCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblCmhsDvcd
            // 
            appearance134.BackColor = System.Drawing.Color.Transparent;
            appearance134.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance134.FontData.Name = "맑은 고딕";
            appearance134.FontData.SizeInPoints = 9F;
            appearance134.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance134.TextHAlignAsString = "Right";
            appearance134.TextVAlignAsString = "Middle";
            this.lblCmhsDvcd.Appearance = appearance134;
            this.lblCmhsDvcd.Location = new System.Drawing.Point(394, 63);
            this.lblCmhsDvcd.Margin = new System.Windows.Forms.Padding(0);
            this.lblCmhsDvcd.Name = "lblCmhsDvcd";
            this.lblCmhsDvcd.Size = new System.Drawing.Size(54, 22);
            this.lblCmhsDvcd.TabIndex = 0;
            this.lblCmhsDvcd.Tag = "C";
            this.lblCmhsDvcd.Text = "내원구분";
            this.lblCmhsDvcd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblCmhsDvcd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblOldHllfMncsBlce
            // 
            appearance135.BackColor = System.Drawing.Color.Transparent;
            appearance135.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance135.FontData.Name = "맑은 고딕";
            appearance135.FontData.SizeInPoints = 9F;
            appearance135.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance135.TextHAlignAsString = "Right";
            appearance135.TextVAlignAsString = "Middle";
            this.lblOldHllfMncsBlce.Appearance = appearance135;
            this.lblOldHllfMncsBlce.Location = new System.Drawing.Point(323, 116);
            this.lblOldHllfMncsBlce.Margin = new System.Windows.Forms.Padding(0);
            this.lblOldHllfMncsBlce.Name = "lblOldHllfMncsBlce";
            this.lblOldHllfMncsBlce.Size = new System.Drawing.Size(125, 22);
            this.lblOldHllfMncsBlce.TabIndex = 0;
            this.lblOldHllfMncsBlce.Text = "이전/현재 건생비잔액";
            this.lblOldHllfMncsBlce.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblOldHllfMncsBlce.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblAsstTycd
            // 
            appearance136.BackColor = System.Drawing.Color.Transparent;
            appearance136.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance136.FontData.Name = "맑은 고딕";
            appearance136.FontData.SizeInPoints = 9F;
            appearance136.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance136.TextHAlignAsString = "Right";
            appearance136.TextVAlignAsString = "Middle";
            this.lblAsstTycd.Appearance = appearance136;
            this.lblAsstTycd.Location = new System.Drawing.Point(195, 36);
            this.lblAsstTycd.Margin = new System.Windows.Forms.Padding(0);
            this.lblAsstTycd.Name = "lblAsstTycd";
            this.lblAsstTycd.Size = new System.Drawing.Size(54, 22);
            this.lblAsstTycd.TabIndex = 0;
            this.lblAsstTycd.Text = "유형보조";
            this.lblAsstTycd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblAsstTycd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel2
            // 
            appearance137.BackColor = System.Drawing.Color.Transparent;
            appearance137.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance137.FontData.Name = "맑은 고딕";
            appearance137.FontData.SizeInPoints = 9F;
            appearance137.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance137.TextHAlignAsString = "Right";
            appearance137.TextVAlignAsString = "Middle";
            this.LxTitleLabel2.Appearance = appearance137;
            this.LxTitleLabel2.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.LxTitleLabel2.Location = new System.Drawing.Point(4, 116);
            this.LxTitleLabel2.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel2.Name = "LxTitleLabel2";
            this.LxTitleLabel2.Size = new System.Drawing.Size(79, 22);
            this.LxTitleLabel2.TabIndex = 0;
            this.LxTitleLabel2.Text = "진료확인번호";
            this.LxTitleLabel2.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel2.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtAge
            // 
            appearance138.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance138.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance138.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance138.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance138.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance138.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance138.TextHAlignAsString = "Center";
            this.txtAge.Appearance = appearance138;
            this.txtAge.AutoSize = false;
            this.txtAge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtAge.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtAge.Location = new System.Drawing.Point(582, 9);
            this.txtAge.Name = "txtAge";
            appearance139.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance139.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance139.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance139.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance139.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance139.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtAge.NullTextAppearance = appearance139;
            this.txtAge.ReadOnly = true;
            this.txtAge.Size = new System.Drawing.Size(27, 22);
            this.txtAge.TabIndex = 1;
            this.txtAge.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtAge.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblMcchCmptDvcd
            // 
            appearance140.BackColor = System.Drawing.Color.Transparent;
            appearance140.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance140.FontData.Name = "맑은 고딕";
            appearance140.FontData.SizeInPoints = 9F;
            appearance140.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance140.TextHAlignAsString = "Right";
            appearance140.TextVAlignAsString = "Middle";
            this.lblMcchCmptDvcd.Appearance = appearance140;
            this.lblMcchCmptDvcd.Location = new System.Drawing.Point(195, 63);
            this.lblMcchCmptDvcd.Margin = new System.Windows.Forms.Padding(0);
            this.lblMcchCmptDvcd.Name = "lblMcchCmptDvcd";
            this.lblMcchCmptDvcd.Size = new System.Drawing.Size(54, 22);
            this.lblMcchCmptDvcd.TabIndex = 0;
            this.lblMcchCmptDvcd.Tag = "C";
            this.lblMcchCmptDvcd.Text = "산정구분";
            this.lblMcchCmptDvcd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblMcchCmptDvcd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblInsnTycd
            // 
            appearance141.BackColor = System.Drawing.Color.Transparent;
            appearance141.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance141.FontData.Name = "맑은 고딕";
            appearance141.FontData.SizeInPoints = 9F;
            appearance141.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance141.TextHAlignAsString = "Right";
            appearance141.TextVAlignAsString = "Middle";
            this.lblInsnTycd.Appearance = appearance141;
            this.lblInsnTycd.Location = new System.Drawing.Point(28, 36);
            this.lblInsnTycd.Margin = new System.Windows.Forms.Padding(0);
            this.lblInsnTycd.Name = "lblInsnTycd";
            this.lblInsnTycd.Size = new System.Drawing.Size(54, 22);
            this.lblInsnTycd.TabIndex = 0;
            this.lblInsnTycd.Text = "보험유형";
            this.lblInsnTycd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblInsnTycd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblFrvsRvstDvcd
            // 
            appearance142.BackColor = System.Drawing.Color.Transparent;
            appearance142.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance142.FontData.Name = "맑은 고딕";
            appearance142.FontData.SizeInPoints = 9F;
            appearance142.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance142.TextHAlignAsString = "Right";
            appearance142.TextVAlignAsString = "Middle";
            this.lblFrvsRvstDvcd.Appearance = appearance142;
            this.lblFrvsRvstDvcd.Location = new System.Drawing.Point(28, 63);
            this.lblFrvsRvstDvcd.Margin = new System.Windows.Forms.Padding(0);
            this.lblFrvsRvstDvcd.Name = "lblFrvsRvstDvcd";
            this.lblFrvsRvstDvcd.Size = new System.Drawing.Size(54, 22);
            this.lblFrvsRvstDvcd.TabIndex = 0;
            this.lblFrvsRvstDvcd.Tag = "C";
            this.lblFrvsRvstDvcd.Text = "초재구분";
            this.lblFrvsRvstDvcd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblFrvsRvstDvcd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblUschAplyCd
            // 
            appearance143.BackColor = System.Drawing.Color.Transparent;
            appearance143.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance143.FontData.Name = "맑은 고딕";
            appearance143.FontData.SizeInPoints = 9F;
            appearance143.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance143.TextHAlignAsString = "Right";
            appearance143.TextVAlignAsString = "Middle";
            this.lblUschAplyCd.Appearance = appearance143;
            this.lblUschAplyCd.Location = new System.Drawing.Point(28, 90);
            this.lblUschAplyCd.Margin = new System.Windows.Forms.Padding(0);
            this.lblUschAplyCd.Name = "lblUschAplyCd";
            this.lblUschAplyCd.Size = new System.Drawing.Size(54, 22);
            this.lblUschAplyCd.TabIndex = 0;
            this.lblUschAplyCd.Text = "본인부담";
            this.lblUschAplyCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblUschAplyCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtSexDvcd
            // 
            appearance144.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance144.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance144.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance144.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance144.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance144.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance144.TextHAlignAsString = "Center";
            this.txtSexDvcd.Appearance = appearance144;
            this.txtSexDvcd.AutoSize = false;
            this.txtSexDvcd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtSexDvcd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtSexDvcd.Location = new System.Drawing.Point(559, 9);
            this.txtSexDvcd.Name = "txtSexDvcd";
            appearance145.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance145.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance145.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance145.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance145.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance145.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtSexDvcd.NullTextAppearance = appearance145;
            this.txtSexDvcd.ReadOnly = true;
            this.txtSexDvcd.Size = new System.Drawing.Size(22, 22);
            this.txtSexDvcd.TabIndex = 1;
            this.txtSexDvcd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtSexDvcd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblVcodeCd
            // 
            appearance146.BackColor = System.Drawing.Color.Transparent;
            appearance146.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance146.FontData.Name = "맑은 고딕";
            appearance146.FontData.SizeInPoints = 9F;
            appearance146.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance146.TextHAlignAsString = "Right";
            appearance146.TextVAlignAsString = "Middle";
            this.lblVcodeCd.Appearance = appearance146;
            this.lblVcodeCd.Location = new System.Drawing.Point(615, 117);
            this.lblVcodeCd.Margin = new System.Windows.Forms.Padding(0);
            this.lblVcodeCd.Name = "lblVcodeCd";
            this.lblVcodeCd.Size = new System.Drawing.Size(54, 22);
            this.lblVcodeCd.TabIndex = 0;
            this.lblVcodeCd.Text = "특정기호";
            this.lblVcodeCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblVcodeCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtPid
            // 
            appearance147.BackColor = System.Drawing.Color.White;
            appearance147.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance147.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance147.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance147.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance147.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtPid.Appearance = appearance147;
            this.txtPid.AutoSize = false;
            this.txtPid.BackColor = System.Drawing.Color.White;
            this.txtPid.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance148.BackColor = System.Drawing.Color.Transparent;
            appearance148.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance148.BorderColor = System.Drawing.Color.Transparent;
            appearance148.BorderColor2 = System.Drawing.Color.Transparent;
            appearance148.Image = ((object)(resources.GetObject("appearance148.Image")));
            appearance148.ImageHAlign = Infragistics.Win.HAlign.Right;
            appearance148.ImageVAlign = Infragistics.Win.VAlign.Middle;
            editorButton1.Appearance = appearance148;
            editorButton1.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Button;
            editorButton1.Width = 18;
            this.txtPid.ButtonsRight.Add(editorButton1);
            this.txtPid.EnterKeyToTab = true;
            this.txtPid.ImeMode = System.Windows.Forms.ImeMode.Hangul;
            this.txtPid.Location = new System.Drawing.Point(85, 9);
            this.txtPid.Margin = new System.Windows.Forms.Padding(0);
            this.txtPid.MaxLength = 10;
            this.txtPid.Name = "txtPid";
            appearance149.BackColor = System.Drawing.Color.White;
            appearance149.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance149.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance149.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance149.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance149.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtPid.NullTextAppearance = appearance149;
            this.txtPid.Size = new System.Drawing.Size(103, 22);
            this.txtPid.TabIndex = 0;
            this.txtPid.UseByteMaxLength = true;
            this.txtPid.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtPid.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtPtNm
            // 
            appearance150.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance150.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance150.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance150.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance150.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance150.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtPtNm.Appearance = appearance150;
            this.txtPtNm.AutoSize = false;
            this.txtPtNm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtPtNm.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtPtNm.Location = new System.Drawing.Point(252, 9);
            this.txtPtNm.Name = "txtPtNm";
            appearance151.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance151.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance151.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance151.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance151.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance151.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtPtNm.NullTextAppearance = appearance151;
            this.txtPtNm.ReadOnly = true;
            this.txtPtNm.Size = new System.Drawing.Size(127, 22);
            this.txtPtNm.TabIndex = 6;
            this.txtPtNm.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtPtNm.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboSmcrYn
            // 
            appearance152.BackColor = System.Drawing.Color.White;
            appearance152.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance152.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance152.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance152.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance152.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboSmcrYn.Appearance = appearance152;
            this.cboSmcrYn.AutoSize = false;
            this.cboSmcrYn.BackColor = System.Drawing.Color.White;
            this.cboSmcrYn.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance153.BackColor = System.Drawing.Color.Transparent;
            appearance153.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance153.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance153.BorderColor = System.Drawing.Color.Transparent;
            appearance153.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance153.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboSmcrYn.ButtonAppearance = appearance153;
            this.cboSmcrYn.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.OnMouseEnter;
            this.cboSmcrYn.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboSmcrYn.Location = new System.Drawing.Point(810, 16);
            this.cboSmcrYn.Name = "cboSmcrYn";
            appearance154.BackColor = System.Drawing.Color.White;
            appearance154.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance154.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance154.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance154.ForeColor = System.Drawing.Color.DarkGray;
            appearance154.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboSmcrYn.NullTextAppearance = appearance154;
            this.cboSmcrYn.ReadOnly = true;
            this.cboSmcrYn.SelectedValue = "";
            this.cboSmcrYn.Size = new System.Drawing.Size(14, 22);
            this.cboSmcrYn.TabIndex = 20;
            this.cboSmcrYn.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboSmcrYn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboSmcrYn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.cboSmcrYn.Visible = false;
            // 
            // ucOrecRegInf1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Name = "ucOrecRegInf1";
            this.Size = new System.Drawing.Size(854, 209);
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).EndInit();
            this.pnlBase.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lxTitlePanel1)).EndInit();
            this.lxTitlePanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lblIncsDr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPtMdcrStatDvcd9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblDisasterSupt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPregnant)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblMediParams)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblMDCAREHSPTHSPTZYN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblForceChange)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnNhic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel1)).EndInit();
            this.lxPanel1.ResumeLayout(false);
            this.lxPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboEcoiCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTbrcDvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboEmrmMmcdCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblEmrmMmcdCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblClphTel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtClphTel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDYNT_DVCD_DRG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitleLabel8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkReBurn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTraiUsprShrt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAsctRgnoCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboRealMdcrDrCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboMdcrDrCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTextBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDcntRdiaCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboCmhsDvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSrrn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboMcchCmptDvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrrn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboFrvsRvstDvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkOthrInstRefrYn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboInsnTycd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMdadPrmtNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDyWardYn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUschAplyCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboUschAplyCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrvsRvstDvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboExcpResnCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInsnTycd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboMdcrDeptCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFcltAplyYn1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblOthrInstRefrYn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFcltAplyYn2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboAsstTycd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRrno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSmcrDvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblFcltAplyYn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHllfMncsBlce)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCmhsPathDvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPtNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMdcrDrCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHllfMncsClamAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMdcrDeptCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOldHllfMncsBlce)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblFrrn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMcchCmptDvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mskMdcrTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtExcpResnCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblMdcrDd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAsstTycd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mskMdcrDd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDyWardYn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblEcoiCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblDyWardYn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblExcpResnCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTbrcDvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCfscRgnoCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitleLabel7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblHllfMncsBlce)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblMdcrDeptCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCmhsDvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblOldHllfMncsBlce)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblAsstTycd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAge)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblMcchCmptDvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblInsnTycd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblFrvsRvstDvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblUschAplyCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSexDvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblVcodeCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPtNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboSmcrYn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public Framework.Controls.LxTitleLabel lblPid;
        public Framework.Controls.LxTitleLabel lblInsnTycd;
        public Framework.Controls.LxTitleLabel lblFrvsRvstDvcd;
        public Framework.Controls.LxTitleLabel lblUschAplyCd;
        public Framework.Controls.LxTitleLabel lblVcodeCd;
        public Framework.Controls.LxTextBox txtPid;
        public Framework.Controls.LxTextBox txtInsnTycd;
        public Framework.Controls.LxTextBox txtFrvsRvstDvcd;
        public Framework.Controls.LxTextBox txtUschAplyCd;
        public Framework.Controls.LxTextBox txtCfscRgnoCd;
        public Framework.Controls.LxTitleLabel lblPtNm;
        public Framework.Controls.LxTextBox txtPtNm;
        public Framework.Controls.LxTitleLabel lblAsstTycd;
        public Framework.Controls.LxTextBox txtAsstTycd;
        public Framework.Controls.LxTitleLabel lblMcchCmptDvcd;
        public Framework.Controls.LxTextBox txtMcchCmptDvcd;
        public Framework.Controls.LxTitleLabel lblFcltAplyYn;
        public Framework.Controls.LxTextBox txtFcltAplyYn2;
        public Framework.Controls.LxTitleLabel lblFrrn;
        public Framework.Controls.LxTextBox txtSexDvcd;
        public Framework.Controls.LxTextBox txtAge;
        public Framework.Controls.LxTitleLabel lblMdcrDeptCd;
        public Framework.Controls.LxTextBox txtMdcrDeptCd;
        public Framework.Controls.LxTextBox txtMdcrDrCd;
        public Framework.Controls.LxTextBox txtSmcrDvcd;
        public Framework.Controls.LxTitleLabel lblOldHllfMncsBlce;
        public Framework.Controls.LxTextBox txtCmhsPathDvcd;
        public Framework.Controls.LxTitleLabel lblOthrInstRefrYn;
        public Framework.Controls.LxCheckBox chkOthrInstRefrYn;
        public Framework.Controls.LxTitleLabel lblMdcrDd;
        public Framework.Controls.LxMaskedEdit mskMdcrDd;
        public Framework.Controls.LxMaskedEdit mskMdcrTime;
        public Framework.Controls.LxTitleLabel lblDyWardYn;
        public Framework.Controls.LxTextBox txtDyWardYn;
        public Framework.Controls.LxTitleLabel lblExcpResnCd;
        public Framework.Controls.LxTextBox txtExcpResnCd;
        public Framework.Controls.LxTitleLabel lblHllfMncsBlce;
        public Framework.Controls.LxTitleLabel lblTbrcDvcd;
        public Framework.Controls.LxTitleLabel lblCmhsDvcd;
        public Framework.Controls.LxTextBox txtFcltAplyYn1;
        public Framework.Controls.LxTextBox txtOldHllfMncsBlce;
        public Framework.Controls.LxTextBox txtHllfMncsBlce;
        private Framework.Controls.LxTitlePanel lxTitlePanel1;
        private Framework.Controls.LxTextBox txtSrrn;
        private Framework.Controls.LxTextBox txtFrrn;
        private Framework.Controls.LxTextBox txtMdadPrmtNo;
        private Framework.Controls.LxComboBox cboDyWardYn;
        private Framework.Controls.LxComboBox cboUschAplyCd;
        private Framework.Controls.LxComboBox cboMdcrDeptCd;
        private Framework.Controls.LxComboBox cboSmcrYn;
        private Framework.Controls.LxComboBox cboAsstTycd;
        public Framework.Controls.LxTitleLabel LxTitleLabel1;
        public Framework.Controls.LxTitleLabel LxTitleLabel2;
        private Framework.Controls.LxOverallCombo cboCmhsDvcd;
        private Framework.Controls.LxOverallCombo cboMcchCmptDvcd;
        private Framework.Controls.LxOverallCombo cboFrvsRvstDvcd;
        private Framework.Controls.LxOverallCombo cboInsnTycd;
        public Framework.Controls.LxTextBox txtHllfMncsClamAmt;
        public Framework.Controls.LxTitleLabel LxTitleLabel3;
        private Framework.Controls.LxTextBox txtRrno;
        public Framework.Controls.LxTitleLabel LxTitleLabel4;
        private Framework.Controls.LxTextBox lxTextBox3;
        private Framework.Controls.LxComboBox cboDcntRdiaCd;
        public Framework.Controls.LxTitleLabel LxTitleLabel6;
        public Framework.Controls.LxTitleLabel LxTitleLabel5;
        public Framework.Controls.LxTitleLabel lblEcoiCd;
        private Framework.Controls.LxPanel lxPanel1;
        private Framework.Controls.LxDoctorListCombo cboMdcrDrCd;
        private Framework.Controls.LxLabel lxLabel1;
        private Framework.Controls.LxComboBox cboExcpResnCd;
        private Framework.Controls.LxTextBox txtAsctRgnoCd;
        private Framework.Controls.LxButton btnNhic;
        private Framework.Controls.LxTextBox txtTraiUsprShrt;
        public Framework.Controls.LxCheckBox chkReBurn;
        public Framework.Controls.LxComboBox cboDYNT_DVCD_DRG;
        public Framework.Controls.LxTitleLabel lxTitleLabel8;
        public Framework.Controls.LxTitleLabel lblClphTel;
        public Framework.Controls.LxTextBox txtClphTel;
        public Framework.Controls.LxTitleLabel lblEmrmMmcdCd;
        private Framework.Controls.LxComboBox cboEmrmMmcdCd;
        private Framework.Controls.LxTextBox txtTbrcDvcd;
        public Framework.Controls.LxLabel lblForceChange;
        private Framework.Controls.LxComboBox cboEcoiCd;
        private Framework.Controls.LxDoctorListCombo cboRealMdcrDrCd;
        public Framework.Controls.LxTitleLabel lxTitleLabel7;
        public Framework.Controls.LxLabel lblMDCAREHSPTHSPTZYN;
        private System.Windows.Forms.ToolTip toolTip1;
        private Framework.Controls.LxLabel lblMediParams;
        private Framework.Controls.LxLabel lblPregnant;
        private Framework.Controls.LxLabel lblDisasterSupt;
        private Framework.Controls.LxLabel lblPtMdcrStatDvcd9;
        private Framework.Controls.LxLabel lblIncsDr;
    }
}
