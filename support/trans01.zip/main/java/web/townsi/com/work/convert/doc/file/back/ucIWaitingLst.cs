﻿// Class 명 : ucIWaitingLst
// 역    할 : 입원결정서을 작성한 입원예정내역을 보여준다. UserControl
// 작 성 자 : 박계훈
// 작 성 일 : 2017-11-08
//********************************************************************************
// 수정내역 : 
//********************************************************************************
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;


namespace Lime.PA
{
    [ToolboxItem(true)]
    public partial class ucIWaitingLst : BaseUserControl
    {
        #region Define : Event
        public delegate void AdmsDecPatSelect(string pid, int ptcmhsno, string admsPrarDd);
        public event AdmsDecPatSelect OnAdmsDecPatSelect;

        public delegate void ParentControlClearEventHandler();
        public event ParentControlClearEventHandler ParentControlClear;
        #endregion

        #region Define : Member
        clsAdmsDecisionInfo m_AdmsDecInfo = new clsAdmsDecisionInfo();    // 입원결정서정보
        ucIAdmissionInf m_UcIAdmsInf = null;                         // 입원결정추가정보
        #endregion  Define : Member

        #region Define : Member Property
        public clsAdmsDecisionInfo AdmsDecInfo
        {
            get { return m_AdmsDecInfo; }
            set { m_AdmsDecInfo = value; }
        }

        public ucIAdmissionInf UcIAdmsInf
        {
            get { return m_UcIAdmsInf; }
            set { m_UcIAdmsInf = value; }
        }

        // 입원결정
        private bool m_DisplayDate = true;
        public bool DisplayDate
        {
            get
            {
                return m_DisplayDate;
            }

            set
            {
                m_DisplayDate = value;
                lxPanel1.Visible = m_DisplayDate;

                if (!m_DisplayDate)
                {
                    chkAdmsPrarDd.Checked = true;
                    dteAdmsPrarDd.DateTime = DateTime.Today;
                }
            }
        }

        // 입원 예정일
        public string PID { get { return m_PID; } set { m_PID = value; } }
        public DateTime AplyDd { get => chkAdmsPrarDd.Checked ? dteAdmsPrarDd.DateTime : DateTime.Today; }

        #endregion Define : Member Property

        #region Construction

        public ucIWaitingLst()
        {
            InitializeComponent();
        }
        #endregion Construction

        #region Screen Load
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode)
                return;

            Initialize();
        }
        #endregion  Screen Load

        #region Method : Initialize

        private void Initialize()
        {
            chkAdmsPrarDd.Checked = false;
            dteAdmsPrarDd.Enabled = false;

            sprAdmsWait.SetComboItems("MDCR_DEPT_CD", DeptList.GetDataList(), "DEPT_CD", "DEPT_HNM");
            sprAdmsWait.SetComboItems("MDCR_DR_CD", UserList.GetDataList(), "USER_CD", "USER_NM");
            sprAdmsWait.SetComboItems("VIA_REGN_CNTS", OverallCodeList.GetDataList("VIA_REGN_CNTS"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            sprAdmsWait.SetComboItems("ROOM_GRAD_CD", OverallCodeList.GetDataList("DCS_ROOM_GRAD_CD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            sprAdmsWait.SetComboItems("WARD_CD", DeptList.GetDataList(), "DEPT_CD", "DEPT_HNM");

            sprAdmsWait.CellClick += sprAdmsWait_CellClick;
            sprAdmsWait.RowChanged += sprAdmsWait_RowChanged;
            chkAdmsPrarDd.CheckedChanged += chkAdmsPrarDd_CheckedChanged;
            dteAdmsPrarDd.ValueChanged += dteAdmsPrarDd_ValueChanged;
            sprAdmsWait.CellDoubleClick += sprAdmsWait_CellDoubleClick;
        }

        #endregion  Method : Initialize

        #region Method : Public Method
        public void Clear()
        {
            sprAdmsWait.ActiveSheet.Rows.Count = 0;

            SelectData();
        }
        /// <summary>
        /// 입원결정서를 작성한 입원예정리스트를 보여준다.
        /// </summary>
        public void SelectData()
        {
            AdmsDecInfo.PTAF_DPMT_CNFR_YN = "N";

            sprAdmsWait.ClearNotDoEvents();

            // 예정일자에 체크가 되지 않은 경우, 시스템 날짜의 오늘 + (어제 * 응급의학과)를 보여주고
            // 예정일자에 체크가 된 경우, 예정일자의 값만 보여준다.
            DataTable dt = new DataTable();
            dt = AdmsDecInfo.LoadList(chkAdmsPrarDd.Checked ? dteAdmsPrarDd.Text.Replace("-", "").Replace("_", "") : "");
            sprAdmsWait.RowChanged -= sprAdmsWait_RowChanged;
            sprAdmsWait.FillDataTag(dt);
            sprAdmsWait.RowChanged += sprAdmsWait_RowChanged;
            SelectPatient();
        }

        public bool DeleteAdmsDecisionInfo()
        {
            try
            {
                int currentrow = 0;
                string pid = String.Empty;
                string ptcmhsno = String.Empty;
                string mdcrdd = String.Empty;
                string ptafdpmtcnfryn = String.Empty;

                currentrow = sprAdmsWait.ActiveSheet.ActiveRowIndex;

                if (currentrow.Equals(-1))
                    return false;

                pid = sprAdmsWait.GetValue(currentrow, "PID").ToString();

                if (StringService.IsNull(pid))
                {
                    throw new Exception("환자를 선택하여 주세요.");
                }
                ptafdpmtcnfryn = sprAdmsWait.GetValue(currentrow, "PTAF_DPMT_CNFR_YN").ToString();

                if (ptafdpmtcnfryn.Equals("Y"))
                {
                    throw new Exception("원무확정이 되어 있어서 삭제할 수 없습니다.");
                }

                ptcmhsno = sprAdmsWait.GetValue(currentrow, "PT_CMHS_NO").ToString();
                mdcrdd = sprAdmsWait.GetValue(currentrow, "MDCR_DD").ToString();

                string temp = string.Format("{0}환자 (환자번호 : {1})의\r\n{2}년 {3}월 {4}일의 입원예정 항목을\r\n삭제하시겠습니까?"
                                            , sprAdmsWait.GetValue(currentrow, "PT_NM").ToString()
                                            , pid
                                            , mdcrdd.Length.Equals(8) ? mdcrdd.Substring(0, 4) : ""
                                            , mdcrdd.Length.Equals(8) ? mdcrdd.Substring(4, 2) : ""
                                            , mdcrdd.Length.Equals(8) ? mdcrdd.Substring(6, 2) : "");

                if (!LxMessage.ShowQuestion(temp).Equals(DialogResult.Yes))
                    return false;

                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateDelYnOfPAIDECRT(), pid
                                                                                , ptcmhsno
                                                                                , mdcrdd
                                                                                , "D"
                                                                                , DateTimeService.NowDateTimeNoneSeperatorString()
                                                                                , DOPack.UserInfo.USER_CD))
                {
                    throw new Exception(string.Format("오류내용 : [{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));
                }
                // 삭제 후 재조회
                SelectData();
                return true;
            }
            catch (Exception ex)
            {
                DBService.RollbackTransaction();
                LxMessage.Show(ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        #endregion Method : Public Method

        #region Method : Private Method

        private void SelectedAdmsWaitPatient(int currentrow)
        {
            string pid = String.Empty;
            int ptcmhsno = 0;
            string admsPrarDd = String.Empty;

            int.TryParse(sprAdmsWait.GetValue(currentrow, "PT_CMHS_NO").ToString(), out ptcmhsno);
            pid = sprAdmsWait.GetValue(currentrow, "PID").ToString();
            admsPrarDd = sprAdmsWait.GetValue(currentrow, "ADMS_PRAR_DD").ToString();

            DataTable dt = sprAdmsWait.ToDataTable();

            if (OnAdmsDecPatSelect != null)
            {
                OnAdmsDecPatSelect(pid, ptcmhsno, admsPrarDd);
            }
        }

        private void SelectPatient()
        {
            int i = sprAdmsWait.ActiveSheet.ActiveRowIndex;
            if (i.Equals(-1))
                return;

            string pid = sprAdmsWait.GetText(i, "PID");
            int ptcmhsno = int.Parse(sprAdmsWait.GetValue(i, "PT_CMHS_NO").ToString());
            string mdcrdd = sprAdmsWait.GetValue(i, "MDCR_DD").ToString().Replace("-", "");

            UcIAdmsInf.SetAdmsDecisionInfo(pid, ptcmhsno, mdcrdd);
        }

        #endregion Method : Private Method

        #region Event : Event Process

        private void sprAdmsWait_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            ((LxSpread)sender).MultiCellSelectRowBackColor(e.Row);
        }

        private void sprAdmsWait_RowChanged(object sender, LxSpread.RowChangedEventArgs e)
        {
            SelectPatient();
        }

        private void sprAdmsWait_CellDoubleClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader) return;
            if (e.RowHeader) return;

            SelectPatient();
            SelectedAdmsWaitPatient(e.Row);
        }

        private void Control_CheckedChanged(object sender, EventArgs e)
        {
            SelectData();
        }

        void dteAdmsPrarDd_ValueChanged(object sender, EventArgs e)
        {
            // 8자리가 입력된 경우만 재조회함
            if (!dteAdmsPrarDd.Text.Replace("-", "").Replace("_", "").Length.Equals(8))
                return;

            // 스프레드 조회
            SelectData();
        }

        private void chkAdmsPrarDd_CheckedChanged(object sender, EventArgs e)
        {
            dteAdmsPrarDd.Enabled = chkAdmsPrarDd.Checked;

            if (!dteAdmsPrarDd.Enabled)
            {
                dteAdmsPrarDd.ValueChanged -= dteAdmsPrarDd_ValueChanged;
                dteAdmsPrarDd.DateTime = DateTime.Today;
                dteAdmsPrarDd.ValueChanged += dteAdmsPrarDd_ValueChanged;
            }

            // 스프레드 조회
            SelectData();
        }

        #endregion Event : Event Process
    }
}
