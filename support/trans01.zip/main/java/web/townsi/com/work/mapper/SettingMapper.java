package web.townsi.com.work.mapper;

import java.lang.invoke.MethodHandles;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository
public class SettingMapper {
	
//	@Autowired
//	@Qualifier("sqlSessionMysql01")
//	protected SqlSessionTemplate sqlSessionTibero01;
	
	@Autowired
	@Qualifier("sqlSessionMssql")
	protected SqlSessionTemplate sqlSessionMssql;
//	
//	@Autowired
//	@Qualifier("sqlSessionPostgresql01")
//	protected SqlSessionTemplate sqlSessionPostgresql01;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	private final static String PACKAGE_NAME = MethodHandles.lookup().lookupClass().getPackage().getName() + ".";
	private final static String CLASS_NAME =  "."+ MethodHandles.lookup().lookupClass().getSimpleName() + ".";
	
	private SqlSessionTemplate getSqlSession(HashMap params) {
		String dbName = StringUtils.defaultString((String)params.get("dbName"), "MYSQL");
		SqlSessionTemplate sqlSession = null;
		if (dbName.equals("MYSQL")) {
//			sqlSession = this.sqlSessionTibero01;
		} else if (dbName.equals("POSTGRESQL")) {
//			sqlSession = this.sqlSessionPostgresql01;
		} else if (dbName.equals("MSSQL")) {
			sqlSession = this.sqlSessionMssql;
		} else {
//			sqlSession = this.sqlSessionTibero01;
		}
		return sqlSession;
	}	
	
	private String getNamespace(HashMap params) {
		String dbName = StringUtils.defaultString((String)params.get("dbName"), "MSSQL");
		String pName = "";
		if (dbName.equals("MYSQL")) {
			pName = "mysql";
		} else if (dbName.equals("POSTGRESQL")) {
			pName = "postgresql";
		} else if (dbName.equals("MSSQL")) {
			pName = "mssql";
		} else {
			pName = "mysql";
		}
		return this.PACKAGE_NAME + pName + CLASS_NAME;
	}

//    public Object insert(String queryId, Object params) {
//    	return sqlSession.insert(NAMESPACE + queryId, params);
//    }
//    public Object update(String queryId, Object params) {
//    	SqlSessionTemplate sqlSession = getSqlSession(params);
//    	return sqlSession.update(NAMESPACE + queryId, params);
//    }
//    public Object delete(String queryId, Object params) {
//    	SqlSessionTemplate sqlSession = getSqlSession(params);
//    	return sqlSession.delete(NAMESPACE + queryId, params);
//    }
//	public List selectList(String queryId, Object params) {
//		return sqlSession.selectList(NAMESPACE + queryId, params);
//	}
//	public Object selectOne(String queryId, Object params) {
//		return sqlSession.selectOne(NAMESPACE + queryId, params);
//	}
//	

	public List<HashMap> selectTableInfo(HashMap params){
		SqlSessionTemplate sqlSession = getSqlSession(params);
		return sqlSession.selectList(this.getNamespace(params) + "selectTableInfo", params);
	}

	public List<HashMap> selectTableList(HashMap params){
		SqlSessionTemplate sqlSession = getSqlSession(params);
		return sqlSession.selectList(this.getNamespace(params) + "selectTableList", params);
	}

	public HashMap selectSqlInfo(HashMap params){
		SqlSessionTemplate sqlSession = getSqlSession(params);
		return sqlSession.selectOne(this.getNamespace(params) + "selectSqlInfo", params);
	}

	public String selectTableComment(HashMap params){
		SqlSessionTemplate sqlSession = getSqlSession(params);
		return sqlSession.selectOne(this.getNamespace(params) + "selectTableComment", params);
	}
	
	public int selectTableAutoIncrement(HashMap params){
		SqlSessionTemplate sqlSession = getSqlSession(params);
		return sqlSession.selectOne(this.getNamespace(params) + "selectTableAutoIncrement", params);
	}
}