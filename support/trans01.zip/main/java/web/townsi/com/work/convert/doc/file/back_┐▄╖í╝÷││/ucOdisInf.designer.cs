namespace Lime.PA
{
    partial class ucOdisInf
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            FarPoint.Win.Spread.EnhancedScrollBarRenderer enhancedScrollBarRenderer1 = new FarPoint.Win.Spread.EnhancedScrollBarRenderer();
            FarPoint.Win.Spread.EnhancedScrollBarRenderer enhancedScrollBarRenderer2 = new FarPoint.Win.Spread.EnhancedScrollBarRenderer();
            FarPoint.Win.Spread.CellType.TextCellType textCellType1 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType2 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType3 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType4 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType5 = new FarPoint.Win.Spread.CellType.TextCellType();
            this.sprDiseaseInfo = new Lime.Framework.Controls.LxSpread();
            this.sprDiseaseInfo_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.lxTitlePanel1 = new Lime.Framework.Controls.LxTitlePanel();
            ((System.ComponentModel.ISupportInitialize)(this.sprDiseaseInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprDiseaseInfo_Sheet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitlePanel1)).BeginInit();
            this.lxTitlePanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // sprDiseaseInfo
            // 
            this.sprDiseaseInfo.AccessibleDescription = "sprDiseaseInfo, Sheet1, Row 0, Column 0, ";
            this.sprDiseaseInfo.AllowEditorReservedLocations = false;
            this.sprDiseaseInfo.AllowUserZoom = false;
            this.sprDiseaseInfo.AutoFirstAppendRow = false;
            this.sprDiseaseInfo.AutoFitColumnName = "ILNS_HNM";
            this.sprDiseaseInfo.AutoFitColumnType = Lime.Framework.Controls.LxSpread.AUTO_FIT_COLUMN_TYPE.OneColumn;
            this.sprDiseaseInfo.AutoLastAppendRow = false;
            this.sprDiseaseInfo.BackColor = System.Drawing.Color.White;
            this.sprDiseaseInfo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.sprDiseaseInfo.ButtonDrawMode = FarPoint.Win.Spread.ButtonDrawModes.CurrentCell;
            this.sprDiseaseInfo.ColumnSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never;
            this.sprDiseaseInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sprDiseaseInfo.EditModePermanent = true;
            this.sprDiseaseInfo.EditModeReplace = true;
            this.sprDiseaseInfo.FocusRenderer = new FarPoint.Win.Spread.EnhancedFocusIndicatorRenderer(1);
            this.sprDiseaseInfo.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.sprDiseaseInfo.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.sprDiseaseInfo.HorizontalScrollBar.Name = "";
            enhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            enhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(190)))), ((int)(((byte)(190)))));
            this.sprDiseaseInfo.HorizontalScrollBar.Renderer = enhancedScrollBarRenderer1;
            this.sprDiseaseInfo.HorizontalScrollBar.TabIndex = 10;
            this.sprDiseaseInfo.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            
            
            this.sprDiseaseInfo.Location = new System.Drawing.Point(3, 35);
            this.sprDiseaseInfo.Name = "sprDiseaseInfo";
            
            this.sprDiseaseInfo.RowSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never;
            this.sprDiseaseInfo.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Both;
            this.sprDiseaseInfo.ScrollTipPolicy = FarPoint.Win.Spread.ScrollTipPolicy.Both;
            this.sprDiseaseInfo.SelectionBlockOptions = FarPoint.Win.Spread.SelectionBlockOptions.Rows;
            
            this.sprDiseaseInfo.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            
            this.sprDiseaseInfo_Sheet1});
            this.sprDiseaseInfo.Size = new System.Drawing.Size(590, 164);
            this.sprDiseaseInfo.TabIndex = 0;
            this.sprDiseaseInfo.UseMultiCellCopyPaste = true;
            this.sprDiseaseInfo.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.sprDiseaseInfo.VerticalScrollBar.Name = "";
            enhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            enhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(190)))), ((int)(((byte)(190)))));
            this.sprDiseaseInfo.VerticalScrollBar.Renderer = enhancedScrollBarRenderer2;
            this.sprDiseaseInfo.VerticalScrollBar.TabIndex = 11;
            this.sprDiseaseInfo.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            // 
            // sprDiseaseInfo_Sheet1
            // 
            this.sprDiseaseInfo_Sheet1.Reset();
            this.sprDiseaseInfo_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.sprDiseaseInfo_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            
            
            this.sprDiseaseInfo_Sheet1.ColumnCount = 5;
            this.sprDiseaseInfo_Sheet1.RowCount = 0;
            this.sprDiseaseInfo_Sheet1.ActiveColumnIndex = -1;
            this.sprDiseaseInfo_Sheet1.ActiveRowIndex = -1;
            this.sprDiseaseInfo_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "구분";
            this.sprDiseaseInfo_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "코드";
            this.sprDiseaseInfo_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "특정기호";
            this.sprDiseaseInfo_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "상병";
            this.sprDiseaseInfo_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "!ILNS_DVCD";
            this.sprDiseaseInfo_Sheet1.Columns.Get(0).CellType = textCellType1;
            this.sprDiseaseInfo_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.sprDiseaseInfo_Sheet1.Columns.Get(0).Label = "구분";
            this.sprDiseaseInfo_Sheet1.Columns.Get(0).Locked = true;
            this.sprDiseaseInfo_Sheet1.Columns.Get(0).Tag = "ILNS_DVNM";
            this.sprDiseaseInfo_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprDiseaseInfo_Sheet1.Columns.Get(0).Width = 35F;
            this.sprDiseaseInfo_Sheet1.Columns.Get(1).CellType = textCellType2;
            this.sprDiseaseInfo_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.sprDiseaseInfo_Sheet1.Columns.Get(1).Label = "코드";
            this.sprDiseaseInfo_Sheet1.Columns.Get(1).Locked = true;
            this.sprDiseaseInfo_Sheet1.Columns.Get(1).Tag = "ILNS_CD";
            this.sprDiseaseInfo_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprDiseaseInfo_Sheet1.Columns.Get(1).Width = 50F;
            this.sprDiseaseInfo_Sheet1.Columns.Get(2).CellType = textCellType3;
            this.sprDiseaseInfo_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.sprDiseaseInfo_Sheet1.Columns.Get(2).Label = "특정기호";
            this.sprDiseaseInfo_Sheet1.Columns.Get(2).Locked = true;
            this.sprDiseaseInfo_Sheet1.Columns.Get(2).Tag = "CFSC_CD";
            this.sprDiseaseInfo_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprDiseaseInfo_Sheet1.Columns.Get(3).CellType = textCellType4;
            this.sprDiseaseInfo_Sheet1.Columns.Get(3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.sprDiseaseInfo_Sheet1.Columns.Get(3).Label = "상병";
            this.sprDiseaseInfo_Sheet1.Columns.Get(3).Locked = true;
            this.sprDiseaseInfo_Sheet1.Columns.Get(3).Tag = "ILNS_HNM";
            this.sprDiseaseInfo_Sheet1.Columns.Get(3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprDiseaseInfo_Sheet1.Columns.Get(3).Width = 250F;
            this.sprDiseaseInfo_Sheet1.Columns.Get(4).CellType = textCellType5;
            this.sprDiseaseInfo_Sheet1.Columns.Get(4).Label = "!ILNS_DVCD";
            this.sprDiseaseInfo_Sheet1.Columns.Get(4).Locked = true;
            this.sprDiseaseInfo_Sheet1.Columns.Get(4).Tag = "ILNS_DVCD";
            
            this.sprDiseaseInfo_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.sprDiseaseInfo_Sheet1.RowHeader.Visible = false;
            this.sprDiseaseInfo_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // lxTitlePanel1
            // 
            this.lxTitlePanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.lxTitlePanel1.BottomBarVisible = false;
            this.lxTitlePanel1.BottomText = "";
            this.lxTitlePanel1.Controls.Add(this.sprDiseaseInfo);
            this.lxTitlePanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lxTitlePanel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxTitlePanel1.Location = new System.Drawing.Point(0, 0);
            this.lxTitlePanel1.Name = "lxTitlePanel1";
            this.lxTitlePanel1.Padding = new System.Windows.Forms.Padding(3);
            this.lxTitlePanel1.Size = new System.Drawing.Size(596, 202);
            this.lxTitlePanel1.TabIndex = 1;
            this.lxTitlePanel1.TitleText = "상병내역";
            // 
            // ucOdisInf
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.lxTitlePanel1);
            this.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.Name = "ucOdisInf";
            this.Size = new System.Drawing.Size(596, 202);
            ((System.ComponentModel.ISupportInitialize)(this.sprDiseaseInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprDiseaseInfo_Sheet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitlePanel1)).EndInit();
            this.lxTitlePanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Framework.Controls.LxSpread sprDiseaseInfo;
        private FarPoint.Win.Spread.SheetView sprDiseaseInfo_Sheet1;
        private Framework.Controls.LxTitlePanel lxTitlePanel1;
    }
}
