//****************************************************
// Class 명 : ucIAdmissionInf
// 역    할 : 입원결정서정보를 보여준다. UserControl
// 작 성 자 : 박계훈
// 작 성 일 : 2017-11-08
//****************************************************
using System;
using System.ComponentModel;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;

namespace Lime.PA
{
    [ToolboxItem(true)]
    public partial class ucIAdmissionInf : UserControl
    {
        // 입원결정서정보
        clsAdmsDecisionInfo m_AdmsDecInfo = new clsAdmsDecisionInfo();
        public clsAdmsDecisionInfo AdmsDecInfo
        {
            get { return m_AdmsDecInfo; }
            set { m_AdmsDecInfo = value; }
        }

        #region Construction

        public ucIAdmissionInf()
        {
            InitializeComponent();
        }

        #endregion Construction

        #region Screen Load

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode)
                return;

            Clear();
        }

        #endregion  Screen Load

        #region Method : Public Method

        public void Clear()
        {
            rdoOxygYes.Checked = false;
            rdoOxygNo.Checked = false;

            rdoIsltYes.Checked = false;
            rdoIsltNo.Checked = false;

            rdoSuctYes.Checked = false;
            rdoSuctNo.Checked = false;

            rdoDrgYes.Checked = false;
            rdoDrgNo.Checked = false;

            rdoNrsExstYes.Checked = false;
            rdoNrsExstNo.Checked = false;

            rdoIjrmViaYes.Checked = false;
            rdoIjrmViaNo.Checked = false;

            txtAdmsDcsnPcft.Text = "";
        }

        /// <summary>
        /// 입원결정서 추가정보를 설정한다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="mdcrdd"></param>
        public void SetAdmsDecisionInfo(string pid, int ptcmhsno, string mdcrdd)
        {
            try
            {
                Clear();

                AdmsDecInfo.PID = pid;
                AdmsDecInfo.PT_CMHS_NO = ptcmhsno;
                AdmsDecInfo.MDCR_DD = mdcrdd;

                if (!AdmsDecInfo.Load())
                    return;

                if (AdmsDecInfo.OXYG_YN.Equals("Y"))        // 산소여부
                    rdoOxygYes.Checked = true;
                else if (AdmsDecInfo.OXYG_YN.Equals("N"))
                    rdoOxygNo.Checked = true;

                if (AdmsDecInfo.ISLT_YN.Equals("Y"))        // 격리여부
                    rdoIsltYes.Checked = true;
                else if (AdmsDecInfo.ISLT_YN.Equals("N"))
                    rdoIsltNo.Checked = true;

                if (AdmsDecInfo.SUCT_YN.Equals("Y"))        // 흡입여부
                    rdoSuctYes.Checked = true;
                else if (AdmsDecInfo.SUCT_YN.Equals("N"))
                    rdoSuctNo.Checked = true;

                if (AdmsDecInfo.DRG_YN.Equals("Y"))         // DRG여부
                    rdoDrgYes.Checked = true;
                else if (AdmsDecInfo.DRG_YN.Equals("N"))
                    rdoDrgNo.Checked = true;

                if (AdmsDecInfo.NRS_EXST_YN.Equals("Y"))    //간호간병통합서비스여부
                    rdoNrsExstYes.Checked = true;
                else if (AdmsDecInfo.NRS_EXST_YN.Equals("N"))
                    rdoNrsExstNo.Checked = true;

                if (AdmsDecInfo.IJRM_VIA_YN.Equals("Y"))   //주사실경유여부
                    rdoIjrmViaYes.Checked = true;
                else if (AdmsDecInfo.IJRM_VIA_YN.Equals("N"))
                    rdoIjrmViaNo.Checked = true;

                txtAdmsDcsnPcft.Text = AdmsDecInfo.ADMS_DCSN_PCFT;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog("SetAdmsDecisionInfo\r\n" + ex);
            }
        }

        /// <summary>
        /// 격리실여부를 확인하여 병실구분, 병실등급을 재설정한다.
        /// </summary>
        /// <param name="roomdvcd">병실구분</param>
        /// <param name="roomgradcd">병실등급</param>
        /// <param name="newroomdvcd"></param>
        /// <param name="newroomgradcd"></param>
        public bool CheckIsolationRoom(string roomdvcd, string roomgradcd, ref string newroomdvcd, ref string newroomgradcd)
        {

            if (AdmsDecInfo.IsLoaded && AdmsDecInfo.ISLT_YN.Equals("Y") && !roomgradcd.Equals("4"))
            {
                if (roomdvcd.Equals("A") && roomdvcd.Equals("C") && roomdvcd.Equals("E"))
                {
                    if (roomdvcd.Equals("A"))
                        newroomdvcd = "K";
                    else if (roomdvcd.Equals("C"))
                        newroomdvcd = "L";
                    else
                        newroomdvcd = "M";

                    newroomgradcd = roomgradcd;
                    return true;
                }
                else
                {
                    if (OverallCodeList.GetColumnValue("ROOM_GRAD_CD", roomgradcd, "ETC_USE_CNTS_2").ToString().Equals("1"))
                        newroomdvcd = "G";
                    else if (OverallCodeList.GetColumnValue("ROOM_GRAD_CD", roomgradcd, "ETC_USE_CNTS_2").ToString().Equals("2"))
                        newroomdvcd = "J";
                    else
                        newroomdvcd = "F";

                    newroomgradcd = "4";
                    return true;
                }

            }
            return false;
        }

        #endregion Method : Public Method
    }
}
