//                                                                                
// Class 명 : clsTraiLimitInfo
// 역    할 : 자보한도금관리
// 작 성 자 : PGH
// 작 성 일 : 2017-10-12
//                                                                                
// 수정내역 : 
//                                                                                
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public class clsTraiLimitInfo
    {
        #region Define : Member
        private string m_PID = String.Empty;    //환자등록번호                     VARCHAR2(10)
        private int m_TRAI_LIMT_SQNO = 0;               //자보한도일련번호                 NUMBER(5, 0)
        private string m_OTPT_ADMS_DVCD = String.Empty;    //외래입원구분코드                 VARCHAR2(2)
        private int m_PT_CMHS_NO = 0;               //환자내원번호                     NUMBER(10, 0)
        private string m_RCPT_OCRR_UNIQ_NO = String.Empty;    //수납발생고유번호                 VARCHAR2(13)
        private string m_CMPY_DD = String.Empty;    //정산일자                         VARCHAR2(8)
        private long m_ASCT_SHAR_AMT = 0;              //조합부담금액                     NUMBER(10, 0)
        private string m_RCPT_DD = String.Empty;    //수납일자                         VARCHAR2(8)
        private string m_RCPT_TIME = String.Empty;    //수납시간                         VARCHAR2(4)
        private string m_RGST_DT = String.Empty;    //등록일시                         VARCHAR2(14)
        private string m_RGSTR_ID = String.Empty;    //등록자ID                         VARCHAR2(10)
        #endregion Define : Member

        #region Define : Member Property
        public string PID { get { return m_PID; } set { m_PID = value; } }
        public int TRAI_LIMT_SQNO { get { return m_TRAI_LIMT_SQNO; } set { m_TRAI_LIMT_SQNO = value; } }
        public string OTPT_ADMS_DVCD { get { return m_OTPT_ADMS_DVCD; } set { m_OTPT_ADMS_DVCD = value; } }
        public int PT_CMHS_NO { get { return m_PT_CMHS_NO; } set { m_PT_CMHS_NO = value; } }
        public string RCPT_OCRR_UNIQ_NO { get { return m_RCPT_OCRR_UNIQ_NO; } set { m_RCPT_OCRR_UNIQ_NO = value; } }
        public string CMPY_DD { get { return m_CMPY_DD; } set { m_CMPY_DD = value; } }
        public long ASCT_SHAR_AMT { get { return m_ASCT_SHAR_AMT; } set { m_ASCT_SHAR_AMT = value; } }
        public string RCPT_DD { get { return m_RCPT_DD; } set { m_RCPT_DD = value; } }
        public string RCPT_TIME { get { return m_RCPT_TIME; } set { m_RCPT_TIME = value; } }
        public string RGST_DT { get { return m_RGST_DT; } set { m_RGST_DT = value; } }
        public string RGSTR_ID { get { return m_RGSTR_ID; } set { m_RGSTR_ID = value; } }
        #endregion Define : Member Property

        #region Construction
        public clsTraiLimitInfo()
        {
            Clear();
        }
        #endregion Construction

        #region Method : Initialize Method
        public void Clear()
        {
            m_PID = String.Empty;
            m_TRAI_LIMT_SQNO = 0;
            m_OTPT_ADMS_DVCD = String.Empty;
            m_PT_CMHS_NO = 0;
            m_RCPT_OCRR_UNIQ_NO = String.Empty;
            m_CMPY_DD = String.Empty;
            m_ASCT_SHAR_AMT = 0;
            m_RCPT_DD = String.Empty;
            m_RCPT_TIME = String.Empty;
            m_RGST_DT = String.Empty;
            m_RGSTR_ID = String.Empty;
        }
        #endregion Method : Initialize Method

        #region Method : Public Method

        #region Method : SelectData Method

        /// <summary>
        /// 자보한금액이 발생되어 있는지 확인한다.
        /// </summary>
        /// <returns></returns>
        public int SelectCountOfPaTlimMa()
        {
            return DBService.ExecuteInteger(SQL.PA.Sql.SelectCountOfPATLIMMA(), m_PID
                                                                         , m_OTPT_ADMS_DVCD
                                                                         , m_PT_CMHS_NO.ToString()
                                                                         , m_CMPY_DD);
        }

        /// <summary>
        /// 급여청구금액을 반환합니다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="payclamamt"></param>
        /// <returns></returns>
        public void GetTraiLimitAmt(string pid, int ptcmhsno, ref long payclamamt)
        {
            long.TryParse(DBService.ExecuteScalar(SQL.PA.Sql.SelectPayClamAmtOfPAOBILBD(), pid
                                                                                         , ptcmhsno.ToString()).ToString(), out payclamamt);
        }

        #endregion Method : SelectData Method

        #region Method : SaveData Method

        /// <summary>
        /// 환자의 자보한도액을 발생시킨다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public int SavePATLIMMA(string insntycd, string assttycd, ref string msg)
        {

            if (insntycd.Equals("41") && !assttycd.Equals("99"))        //자보인 경우 발생
            {
                if (this.SelectCountOfPaTlimMa() == 0)
                {
                    if (!this.InsertPaTlimMa(ref msg))
                    {
                        return -1;
                    }
                }
                else
                {
                    if (!this.UpdatePaTlimMa(ref msg))
                    {
                        return -2;
                    }
                }
            }
            else
            {
                if (this.SelectCountOfPaTlimMa() >= 1)
                {
                    if (!this.DeletePaTlimMa(ref msg))                             //자보가 아닌경우 발생된 자보한도액이 있으면 삭제
                    {
                        return -3;
                    }
                }
            }
            return 1;
        }
        /// <summary>
        /// 자보한도금액이 없다면 새로 생성한다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool InsertPaTlimMa(ref string msg)
        {
            bool success = true;
            int trailimtsqno = 0;

            trailimtsqno = DBService.ExecuteInteger(SQL.PA.Sql.SelectMaxSqnoOfPATLIMMA(), m_PID);

            trailimtsqno++;

            if (!DBService.ExecuteNonQuery(SQL.PA.BaseSql.Insert.PATLIMMA(), m_PID
                                                                         , trailimtsqno.ToString()
                                                                         , m_OTPT_ADMS_DVCD
                                                                         , m_PT_CMHS_NO.ToString()
                                                                         , m_RCPT_OCRR_UNIQ_NO
                                                                         , m_CMPY_DD
                                                                         , m_ASCT_SHAR_AMT.ToString()
                                                                         , m_RCPT_DD
                                                                         , m_RCPT_TIME
                                                                         , m_RGST_DT
                                                                         , m_RGSTR_ID))
            {
                msg = "자보한도액관리 저장중 오류 발생 \r\n Error Message : " + DBService.ErrorMessage;
                success = false;
            }
            return success;
        }
        /// <summary>
        /// 이미 발생되어있으면 변경한다
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool UpdatePaTlimMa(ref string msg)
        {
            bool success = true;
            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePATLIMMA(), m_PID
                                                                       , m_OTPT_ADMS_DVCD
                                                                       , m_PT_CMHS_NO.ToString()
                                                                       , m_CMPY_DD
                                                                       , m_ASCT_SHAR_AMT.ToString()
                                                                       , m_RCPT_DD
                                                                       , m_RCPT_TIME))
            {
                msg = "자보한도액관리 변경중 오류 발생 \r\n Error Message : " + DBService.ErrorMessage;
                success = false;
            }
            return success;
        }
        /// <summary>
        /// 이미 발생된 자보한도액을 삭제한다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool DeletePaTlimMa(ref string msg)
        {

            bool success = true;
            try
            {
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.DeletePATLIMMA(), m_PID
                                                                          , m_OTPT_ADMS_DVCD
                                                                          , m_PT_CMHS_NO.ToString()
                                                                          , m_CMPY_DD))
                {
                    msg = "자보한도액관리 삭제중 오류 발생 \r\n Error Message : " + DBService.ErrorMessage;
                    success = false;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
            return success;
        }
        #endregion Method : SaveData Method
        #endregion Method : Public Method

        #region Method : Private Method

        #endregion Method : Private Method


    }
}

