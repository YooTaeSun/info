package web.townsi.com.work.setting.biz.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;
import web.townsi.com.utils.ListUtil;
import web.townsi.com.work.mapper.SettingMapper;
import web.townsi.com.work.setting.biz.SettingBiz;
import web.townsi.com.work.setting.biz.SettingToBiz;

/**
* SettingServiceImpl
* @author 유태선
* @since 2020.08.31
* @version 1.0
* @see
* </pre>
*/
@SuppressWarnings({"rawtypes","unchecked","unused"})
@Service
public class SettingToBizImpl implements SettingToBiz {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private SettingBiz settingBiz;

	@Autowired
	private SettingMapper settingMapper;


	public static String LINE = "\n";
	public static String SPACE_CNT = "    ";
	public static String SLASH = File.separator;// lastIndexOf("/")


	public static String rTxt  = "#{txt}";

	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();


	public HashMap makeTo(HashMap params) throws Exception {
		HashMap dataMap = new HashMap();
		HashMap replaceMap = new HashMap();
		StringBuilder dtoMemer = new StringBuilder(500);
		StringBuilder dtoSearcgMemer = new StringBuilder(500);
		StringBuilder dtoMethod = new StringBuilder(500);
		StringBuilder conParam = new StringBuilder(500);
		StringBuilder conParamBody = new StringBuilder(500);

		String column_name = "";
		String mem_vari = "";
		String column_comment = "";
		String camel_column_name = "";
		String set_get_column_name = "";
		String w_type = "";
		String pk = "";
		String is_nullable = "";

		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String upperTableName = StringUtils.defaultString((String) params.get("upperTableName"));
		String lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		String camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		String tableSchema = StringUtils.defaultString((String) params.get("tableSchema"));
		String camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String group1 = StringUtils.defaultString((String) params.get("group1"));
		String author = StringUtils.defaultString((String) params.get("author"));
		String desc = StringUtils.defaultString((String) params.get("desc"));
		String today = StringUtils.defaultString((String) params.get("today"));
		String current = StringUtils.defaultString((String) params.get("current"));
		String voComment = StringUtils.defaultString((String) params.get("voComment"),"Y_NEXT");
		String sort = StringUtils.defaultString((String) params.get("sort"));
		String taskName = StringUtils.defaultString((String) params.get("taskName"));
		String taskNameFirstUpperName = StringUtils.defaultString((String) params.get("taskNameFirstUpperName"));
		String packageNm = StringUtils.defaultString((String) params.get("packageNm"));
		String tableNewName = StringUtils.defaultString((String) params.get("tableNewName"));
		String tableNewFirstUpperName = StringUtils.defaultString((String) params.get("tableNewFirstUpperName"));
		
		HashMap entityObj = (HashMap) params.get("entityObj");
		String objName = tableName;
		if(entityObj != null && !entityObj.isEmpty()) {
			String tableName2 = StringUtils.defaultString((String) entityObj.get(tableName),"");
			if(!tableName2.isEmpty()) {
				objName = tableName2;
			}
		}
		
		List<HashMap> list = settingBiz.selectTableInfo(params,
				  StringUtils.defaultString((String)params.get("dbName"))
				, StringUtils.defaultString((String)params.get("tableSchema"))
			    , StringUtils.defaultString((String)params.get("tableName"))
				);
		
		
		String pkType = "";

		if(ListUtil.isNotEmpty(list)) {

			for (HashMap rs : list) {
				column_name = (String) rs.get("columnName");
				column_comment = (String) rs.get("columnComment");
				camel_column_name = (String) rs.get("camelColumnName");
				mem_vari = (String) rs.get("memVari");
				w_type = (String) rs.get("wType");
				is_nullable = (String) rs.get("isNullable");

				String camelColumnFirstUpperName = camel_column_name.substring(0,1).toUpperCase() + camel_column_name.substring(1);

				set_get_column_name = (String) rs.get("setGetColumnName");

//				dtoMemer.append(LINE);
				pk = StringUtils.defaultString((String) rs.get("pk")).toLowerCase();
				if("pk".equals(pk)) {
					conParam = conParam.append(","  + mem_vari.replaceAll("private ", "").replaceAll(";", ""));
//					conParamBody = conParamBody.append("\n\t\tthis." + camel_column_name  + " = " + camel_column_name + ";");
					pkType = w_type;
				}


//				if(!StringUtils.isEmpty(column_comment)) {
//
//					dtoMemer.append("\t/**"  + "" + LINE);
//					if("pk".equals(pk)) {
//						dtoMemer.append("\t * " +column_comment + "(PK)" + LINE);	
//					}else {
//						dtoMemer.append("\t * " +column_comment + "" + LINE);
//					}
//					
////					dtoMemer.append("\t */" + "" + LINE);
////					if("pk".equals(pk)) {
////						dtoMemer.append("\t@Id" + LINE);
////						dtoMemer.append("\t@GeneratedValue(strategy = GenerationType.IDENTITY)" + LINE);
////					}
////					if(column_name.equals("FRST_RGST_DT") || column_name.equals("LAST_UPDT_DT")) {
////						dtoMemer.append("\t@Column(name = \""+ column_name  +"\", insertable = false, updatable = false)" + LINE);
////					}else {
////						dtoMemer.append("\t@Column(name = \""+ column_name  +"\")" + LINE);	
////					}
////					HashMap columnObj = (HashMap) entityObj.get(column_name);
////					if(columnObj != null && !columnObj.isEmpty()) {
////						dtoMemer.append("\tprivate "+ columnObj.get("type") + " " + columnObj.get("name")+ LINE+ LINE);
////					}else {
////						
////						dtoMemer.append("\t"+ mem_vari+ LINE+ LINE);
////					}
////					
////					dtoSearcgMemer.append("\tprivate "+ w_type + " search" + camelColumnFirstUpperName + ";");
////					dtoSearcgMemer.append("\t/* search" + column_comment + " */" +  LINE);
//				
//				}
			}
		}

		if(!taskName.isEmpty()) {
		}
		replaceMap.put("#camelTableFirstUpperName#",taskNameFirstUpperName);
		
		replaceMap.put("#camelTableName#",camelTableName);
		replaceMap.put("#dtoContent#", dtoMemer.toString());
		replaceMap.put("#searchDtoContent#", dtoSearcgMemer.toString());
		replaceMap.put("#lowerTableName#", lowerTableName.replaceAll("_", ""));
		replaceMap.put("#group#", group);
		replaceMap.put("#desc#", desc);
		replaceMap.put("#group1#", group1);
		replaceMap.put("#author#", author);
		replaceMap.put("#today#", today);
		replaceMap.put("#current#",current);
		replaceMap.put("#dtoMethod#",dtoMethod.toString());
		replaceMap.put("#upperTableName#",upperTableName);
		
		replaceMap.put("#pkType#",pkType);
		replaceMap.put("#objName#",objName);
		replaceMap.put("#objNameFirstUpper#", objName.substring(0,1).toUpperCase() + objName.substring(1));
		replaceMap.put("#packageNm#",packageNm);
		replaceMap.put("#tableNewName#", tableNewName);
		replaceMap.put("#tableNewFirstUpperName#", tableNewFirstUpperName);
		

		String rfullPath = SITE_WEB_ROOT + "/copy/SampleTo.java";

		String wfullPath = "";
		wfullPath = SITE_WEB_ROOT + "/new/" + tableSchema + "/" + tableName+"/"+tableNewFirstUpperName+"Mapper.java";

		String str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);

		dataMap.put("str", str);
		dataMap.put("fullPath", wfullPath);
		list = null;
		return dataMap;
	}
	
}