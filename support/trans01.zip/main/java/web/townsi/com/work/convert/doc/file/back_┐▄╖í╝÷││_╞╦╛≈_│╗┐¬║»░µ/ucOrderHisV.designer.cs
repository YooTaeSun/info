namespace Lime.PA
{
    partial class ucOrderHisV
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucOrderHisV));
            FarPoint.Win.Spread.EnhancedScrollBarRenderer enhancedScrollBarRenderer1 = new FarPoint.Win.Spread.EnhancedScrollBarRenderer();
            FarPoint.Win.Spread.EnhancedScrollBarRenderer enhancedScrollBarRenderer2 = new FarPoint.Win.Spread.EnhancedScrollBarRenderer();
            FarPoint.Win.Spread.CellType.TextCellType textCellType1 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType2 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.MaskCellType maskCellType1 = new FarPoint.Win.Spread.CellType.MaskCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType1 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType2 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.MaskCellType maskCellType2 = new FarPoint.Win.Spread.CellType.MaskCellType();
            FarPoint.Win.Spread.CellType.ComboBoxCellType comboBoxCellType1 = new FarPoint.Win.Spread.CellType.ComboBoxCellType();
            FarPoint.Win.Spread.CellType.ComboBoxCellType comboBoxCellType2 = new FarPoint.Win.Spread.CellType.ComboBoxCellType();
            FarPoint.Win.Spread.CellType.CheckBoxCellType checkBoxCellType1 = new FarPoint.Win.Spread.CellType.CheckBoxCellType();
            FarPoint.Win.Spread.CellType.CheckBoxCellType checkBoxCellType2 = new FarPoint.Win.Spread.CellType.CheckBoxCellType();
            FarPoint.Win.Spread.CellType.MaskCellType maskCellType3 = new FarPoint.Win.Spread.CellType.MaskCellType();
            FarPoint.Win.Spread.CellType.MaskCellType maskCellType4 = new FarPoint.Win.Spread.CellType.MaskCellType();
            FarPoint.Win.Spread.CellType.CheckBoxCellType checkBoxCellType3 = new FarPoint.Win.Spread.CellType.CheckBoxCellType();
            FarPoint.Win.Spread.EnhancedScrollBarRenderer enhancedScrollBarRenderer3 = new FarPoint.Win.Spread.EnhancedScrollBarRenderer();
            FarPoint.Win.Spread.EnhancedScrollBarRenderer enhancedScrollBarRenderer4 = new FarPoint.Win.Spread.EnhancedScrollBarRenderer();
            FarPoint.Win.Spread.CellType.TextCellType textCellType3 = new FarPoint.Win.Spread.CellType.TextCellType();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            this.sprSub = new Lime.Framework.Controls.LxSpread();
            this.sprSub_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.sprMain = new Lime.Framework.Controls.LxSpread();
            this.sprMain_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.lxSplitter1 = new Lime.Framework.Controls.LxSplitter();
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).BeginInit();
            this.pnlBase.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sprSub)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprSub_Sheet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprMain_Sheet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxSplitter1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBase
            // 
            this.pnlBase.Controls.Add(this.sprSub);
            this.pnlBase.Controls.Add(this.lxSplitter1);
            this.pnlBase.Controls.Add(this.sprMain);
            this.pnlBase.Size = new System.Drawing.Size(543, 296);
            // 
            // sprSub
            // 
            this.sprSub.AccessibleDescription = "sprSub, Sheet1, Row 0, Column 0, ";
            this.sprSub.AllowEditorReservedLocations = false;
            this.sprSub.AllowUserZoom = false;
            this.sprSub.AutoFirstAppendRow = false;
            this.sprSub.AutoLastAppendRow = false;
            this.sprSub.BackColor = System.Drawing.Color.White;
            this.sprSub.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sprSub.ButtonDrawMode = FarPoint.Win.Spread.ButtonDrawModes.CurrentCell;
            this.sprSub.ColumnSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never;
            this.sprSub.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sprSub.EditModePermanent = true;
            this.sprSub.EditModeReplace = true;
            this.sprSub.FocusRenderer = new FarPoint.Win.Spread.CustomFocusIndicatorRenderer(((System.Drawing.Bitmap)(resources.GetObject("sprSub.FocusRenderer"))), 2);
            this.sprSub.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.sprSub.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.sprSub.HorizontalScrollBar.Name = "";
            enhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            enhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(190)))), ((int)(((byte)(190)))));
            this.sprSub.HorizontalScrollBar.Renderer = enhancedScrollBarRenderer1;
            this.sprSub.HorizontalScrollBar.TabIndex = 28;
            this.sprSub.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.sprSub.Location = new System.Drawing.Point(104, 0);
            this.sprSub.Name = "sprSub";
            this.sprSub.RowSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never;
            this.sprSub.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Both;
            this.sprSub.ScrollTipPolicy = FarPoint.Win.Spread.ScrollTipPolicy.Both;
            this.sprSub.SelectionBlockOptions = FarPoint.Win.Spread.SelectionBlockOptions.Rows;
            this.sprSub.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.sprSub_Sheet1});
            this.sprSub.Size = new System.Drawing.Size(439, 296);
            this.sprSub.TabIndex = 8;
            this.sprSub.UseMultiCellCopyPaste = true;
            this.sprSub.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.sprSub.VerticalScrollBar.Name = "";
            enhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            enhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(190)))), ((int)(((byte)(190)))));
            this.sprSub.VerticalScrollBar.Renderer = enhancedScrollBarRenderer2;
            this.sprSub.VerticalScrollBar.TabIndex = 29;
            this.sprSub.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            // 
            // sprSub_Sheet1
            // 
            this.sprSub_Sheet1.Reset();
            this.sprSub_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.sprSub_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.sprSub_Sheet1.ColumnCount = 13;
            this.sprSub_Sheet1.RowCount = 1;
            this.sprSub_Sheet1.Cells.Get(0, 8).Value = false;
            this.sprSub_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "처방코드";
            this.sprSub_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "처방명";
            this.sprSub_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "처방일자";
            this.sprSub_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "수량";
            this.sprSub_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "일수";
            this.sprSub_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "최종일자";
            this.sprSub_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "!진료과목";
            this.sprSub_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "!진료의";
            this.sprSub_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "!접수";
            this.sprSub_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "!예약";
            this.sprSub_Sheet1.ColumnHeader.Cells.Get(0, 10).Value = "!예약일자";
            this.sprSub_Sheet1.ColumnHeader.Cells.Get(0, 11).Value = "!예약시간";
            this.sprSub_Sheet1.ColumnHeader.Cells.Get(0, 12).Value = "!결과";
            this.sprSub_Sheet1.Columns.Get(0).CellType = textCellType1;
            this.sprSub_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.sprSub_Sheet1.Columns.Get(0).Label = "처방코드";
            this.sprSub_Sheet1.Columns.Get(0).Locked = true;
            this.sprSub_Sheet1.Columns.Get(0).Tag = "PRSC_CD";
            this.sprSub_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(1).CellType = textCellType2;
            this.sprSub_Sheet1.Columns.Get(1).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.sprSub_Sheet1.Columns.Get(1).Label = "처방명";
            this.sprSub_Sheet1.Columns.Get(1).Locked = true;
            this.sprSub_Sheet1.Columns.Get(1).Tag = "PRSC_NM";
            this.sprSub_Sheet1.Columns.Get(1).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(1).Width = 170F;
            maskCellType1.Mask = "##-##-##";
            this.sprSub_Sheet1.Columns.Get(2).CellType = maskCellType1;
            this.sprSub_Sheet1.Columns.Get(2).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(2).Label = "처방일자";
            this.sprSub_Sheet1.Columns.Get(2).Locked = true;
            this.sprSub_Sheet1.Columns.Get(2).Tag = "NY_MDCR_DD";
            this.sprSub_Sheet1.Columns.Get(2).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(2).Width = 56F;
            numberCellType1.DecimalPlaces = 4;
            numberCellType1.FixedPoint = false;
            this.sprSub_Sheet1.Columns.Get(3).CellType = numberCellType1;
            this.sprSub_Sheet1.Columns.Get(3).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(3).Label = "수량";
            this.sprSub_Sheet1.Columns.Get(3).Locked = true;
            this.sprSub_Sheet1.Columns.Get(3).Tag = "QTY";
            this.sprSub_Sheet1.Columns.Get(3).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(3).Width = 36F;
            numberCellType2.DecimalPlaces = 0;
            this.sprSub_Sheet1.Columns.Get(4).CellType = numberCellType2;
            this.sprSub_Sheet1.Columns.Get(4).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(4).Label = "일수";
            this.sprSub_Sheet1.Columns.Get(4).Locked = true;
            this.sprSub_Sheet1.Columns.Get(4).Tag = "NODY";
            this.sprSub_Sheet1.Columns.Get(4).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(4).Width = 36F;
            maskCellType2.Mask = "##-##-##";
            this.sprSub_Sheet1.Columns.Get(5).CellType = maskCellType2;
            this.sprSub_Sheet1.Columns.Get(5).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(5).Label = "최종일자";
            this.sprSub_Sheet1.Columns.Get(5).Locked = true;
            this.sprSub_Sheet1.Columns.Get(5).Tag = "NY_PRSC_LAST_DD";
            this.sprSub_Sheet1.Columns.Get(5).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(5).Width = 56F;
            comboBoxCellType1.ButtonAlign = FarPoint.Win.ButtonAlign.Right;
            this.sprSub_Sheet1.Columns.Get(6).CellType = comboBoxCellType1;
            this.sprSub_Sheet1.Columns.Get(6).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.sprSub_Sheet1.Columns.Get(6).Label = "!진료과목";
            this.sprSub_Sheet1.Columns.Get(6).Locked = true;
            this.sprSub_Sheet1.Columns.Get(6).Tag = "MDCR_DEPT_CD";
            this.sprSub_Sheet1.Columns.Get(6).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(6).Width = 110F;
            comboBoxCellType2.ButtonAlign = FarPoint.Win.ButtonAlign.Right;
            this.sprSub_Sheet1.Columns.Get(7).CellType = comboBoxCellType2;
            this.sprSub_Sheet1.Columns.Get(7).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.sprSub_Sheet1.Columns.Get(7).Label = "!진료의";
            this.sprSub_Sheet1.Columns.Get(7).Locked = true;
            this.sprSub_Sheet1.Columns.Get(7).Tag = "MDCR_DR_CD";
            this.sprSub_Sheet1.Columns.Get(7).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(7).Width = 80F;
            this.sprSub_Sheet1.Columns.Get(8).CellType = checkBoxCellType1;
            this.sprSub_Sheet1.Columns.Get(8).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(8).Label = "!접수";
            this.sprSub_Sheet1.Columns.Get(8).Locked = true;
            this.sprSub_Sheet1.Columns.Get(8).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(8).Width = 34F;
            this.sprSub_Sheet1.Columns.Get(9).CellType = checkBoxCellType2;
            this.sprSub_Sheet1.Columns.Get(9).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(9).Label = "!예약";
            this.sprSub_Sheet1.Columns.Get(9).Locked = true;
            this.sprSub_Sheet1.Columns.Get(9).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(9).Width = 34F;
            maskCellType3.Mask = "####-##-##";
            this.sprSub_Sheet1.Columns.Get(10).CellType = maskCellType3;
            this.sprSub_Sheet1.Columns.Get(10).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(10).Label = "!예약일자";
            this.sprSub_Sheet1.Columns.Get(10).Locked = true;
            this.sprSub_Sheet1.Columns.Get(10).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(10).Width = 75F;
            maskCellType4.Mask = "##:##";
            this.sprSub_Sheet1.Columns.Get(11).CellType = maskCellType4;
            this.sprSub_Sheet1.Columns.Get(11).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(11).Label = "!예약시간";
            this.sprSub_Sheet1.Columns.Get(11).Locked = true;
            this.sprSub_Sheet1.Columns.Get(11).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(12).CellType = checkBoxCellType3;
            this.sprSub_Sheet1.Columns.Get(12).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(12).Label = "!결과";
            this.sprSub_Sheet1.Columns.Get(12).Locked = true;
            this.sprSub_Sheet1.Columns.Get(12).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprSub_Sheet1.Columns.Get(12).Width = 34F;
            this.sprSub_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.sprSub_Sheet1.RowHeader.Visible = false;
            this.sprSub_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // sprMain
            // 
            this.sprMain.AccessibleDescription = "";
            this.sprMain.AllowEditorReservedLocations = false;
            this.sprMain.AllowUserZoom = false;
            this.sprMain.AutoFirstAppendRow = false;
            this.sprMain.AutoLastAppendRow = false;
            this.sprMain.BackColor = System.Drawing.Color.White;
            this.sprMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sprMain.ButtonDrawMode = FarPoint.Win.Spread.ButtonDrawModes.CurrentCell;
            this.sprMain.ColumnSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never;
            this.sprMain.Dock = System.Windows.Forms.DockStyle.Left;
            this.sprMain.EditModePermanent = true;
            this.sprMain.EditModeReplace = true;
            this.sprMain.FocusRenderer = new FarPoint.Win.Spread.CustomFocusIndicatorRenderer(((System.Drawing.Bitmap)(resources.GetObject("sprMain.FocusRenderer"))), 2);
            this.sprMain.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.sprMain.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.sprMain.HorizontalScrollBar.Name = "";
            enhancedScrollBarRenderer3.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer3.ArrowHoveredColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer3.ArrowSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            enhancedScrollBarRenderer3.ButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer3.ButtonBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer3.ButtonHoveredBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer3.ButtonHoveredBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer3.ButtonSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer3.ButtonSelectedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer3.TrackBarBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer3.TrackBarSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(190)))), ((int)(((byte)(190)))));
            this.sprMain.HorizontalScrollBar.Renderer = enhancedScrollBarRenderer3;
            this.sprMain.HorizontalScrollBar.TabIndex = 20;
            this.sprMain.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.sprMain.Location = new System.Drawing.Point(0, 0);
            this.sprMain.Name = "sprMain";
            this.sprMain.RowSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never;
            this.sprMain.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Both;
            this.sprMain.ScrollTipPolicy = FarPoint.Win.Spread.ScrollTipPolicy.Both;
            this.sprMain.SelectionBlockOptions = FarPoint.Win.Spread.SelectionBlockOptions.Rows;
            this.sprMain.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.sprMain_Sheet1});
            this.sprMain.Size = new System.Drawing.Size(101, 296);
            this.sprMain.TabIndex = 6;
            this.sprMain.UseMultiCellCopyPaste = true;
            this.sprMain.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.sprMain.VerticalScrollBar.Name = "";
            enhancedScrollBarRenderer4.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer4.ArrowHoveredColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer4.ArrowSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            enhancedScrollBarRenderer4.ButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer4.ButtonBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer4.ButtonHoveredBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer4.ButtonHoveredBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer4.ButtonSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer4.ButtonSelectedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer4.TrackBarBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer4.TrackBarSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(190)))), ((int)(((byte)(190)))));
            this.sprMain.VerticalScrollBar.Renderer = enhancedScrollBarRenderer4;
            this.sprMain.VerticalScrollBar.TabIndex = 21;
            this.sprMain.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            // 
            // sprMain_Sheet1
            // 
            this.sprMain_Sheet1.Reset();
            this.sprMain_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.sprMain_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.sprMain_Sheet1.ColumnCount = 2;
            this.sprMain_Sheet1.RowCount = 1;
            this.sprMain_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "분류명";
            this.sprMain_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "!LWRN_OVRL_CD";
            this.sprMain_Sheet1.Columns.Get(0).CellType = textCellType3;
            this.sprMain_Sheet1.Columns.Get(0).HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
            this.sprMain_Sheet1.Columns.Get(0).Label = "분류명";
            this.sprMain_Sheet1.Columns.Get(0).Locked = true;
            this.sprMain_Sheet1.Columns.Get(0).Tag = "LWRN_OVRL_CDNM";
            this.sprMain_Sheet1.Columns.Get(0).VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            this.sprMain_Sheet1.Columns.Get(0).VisualStyles = FarPoint.Win.VisualStyles.Auto;
            this.sprMain_Sheet1.Columns.Get(0).Width = 85F;
            this.sprMain_Sheet1.Columns.Get(1).Label = "!LWRN_OVRL_CD";
            this.sprMain_Sheet1.Columns.Get(1).Locked = true;
            this.sprMain_Sheet1.Columns.Get(1).Tag = "LWRN_OVRL_CD";
            this.sprMain_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.sprMain_Sheet1.RowHeader.Visible = false;
            this.sprMain_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // lxSplitter1
            // 
            appearance1.BackColor = System.Drawing.Color.White;
            appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance1.BorderColor = System.Drawing.Color.Black;
            this.lxSplitter1.Appearance = appearance1;
            this.lxSplitter1.BackColor = System.Drawing.Color.White;
            this.lxSplitter1.BorderStyle = Infragistics.Win.UIElementBorderStyle.None;
            appearance2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(210)))), ((int)(((byte)(210)))));
            appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            this.lxSplitter1.ButtonAppearance = appearance2;
            this.lxSplitter1.ButtonStyle = Infragistics.Win.UIElementButtonStyle.FlatBorderless;
            appearance3.BackColor = System.Drawing.Color.White;
            appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            this.lxSplitter1.CollapsedAppearance = appearance3;
            appearance4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(210)))), ((int)(((byte)(210)))));
            appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            this.lxSplitter1.CollapsedButtonAppearance = appearance4;
            appearance5.BackColor = System.Drawing.Color.White;
            appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            this.lxSplitter1.HotTrackingAppearance = appearance5;
            appearance6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(210)))), ((int)(((byte)(210)))));
            appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            this.lxSplitter1.HotTrackingButtonAppearance = appearance6;
            this.lxSplitter1.Location = new System.Drawing.Point(101, 0);
            this.lxSplitter1.Name = "lxSplitter1";
            this.lxSplitter1.RestoreExtent = 101;
            this.lxSplitter1.Size = new System.Drawing.Size(3, 296);
            this.lxSplitter1.TabIndex = 7;
            // 
            // ucOrderHisV
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Name = "ucOrderHisV";
            this.Size = new System.Drawing.Size(543, 296);
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).EndInit();
            this.pnlBase.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sprSub)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprSub_Sheet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprMain_Sheet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxSplitter1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Framework.Controls.LxSpread sprSub;
        private FarPoint.Win.Spread.SheetView sprSub_Sheet1;
        private Framework.Controls.LxSpread sprMain;
        private FarPoint.Win.Spread.SheetView sprMain_Sheet1;
        private Framework.Controls.LxSplitter lxSplitter1;

    }
}
