using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Lime.Framework
{
    public class ZTEST2
    {
    
    	public string MdcrDd { set { m_MdcrDd = value; } }
    
		public        string Pid
        {
            get { return m_Pid; }
        }
        public int PtCmhsNo
        {
            set { m_PtCmhsNo = value; }
        }

		public string MdcrDd2
		{ 
			get { return m_PtCmhsNo; }
			set { m_MdcrDd = value; }
		}

        public int PtCmhsNo
        {
            get { return m_PtCmhsNo; }
            set { m_PtCmhsNo = value; }
        }
        
        private void InitializeSpread()
        {
        	SelectData(this.m_Pid, m_MdcrDd);
        }
        
        private void InitializeSpread()
        {
        	// if (!String.IsNullOrWhiteSpace(txtCttrUnclAplyAmt.Text.Replace(",", "")) && txtCttrUnclAplyAmt.Tag != null && !string.IsNullOrWhiteSpace(txtCttrUnclAplyAmt.Tag.ToString()))
        	//                           , ucDschBiLLinfo1.txtPtSharAmt.Text.Replace(",", ""), ucDschBiLLinfo1.txtUschUplmAmt.Text.Replace(",", ""), insntycd, assttycd
            /*
             * sprSameDayRegList
             */
            this.sprSameDayRegList.SetSpreadSheet(this.sprSameDayRegList.ActiveSheet, FarPoint.Win.Spread.Model.SelectionPolicy.Single, FarPoint.Win.Spread.Model.SelectionUnit.Cell, FarPoint.Win.Spread.SelectionStyles.Both, FarPoint.Win.Spread.OperationMode.RowMode, false, false, FarPoint.Win.Spread.ButtonDrawModes.CurrentCell, true, true, FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded, FarPoint.Win.Spread.ScrollBarPolicy.Always, true, false, false, false);

            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.PID, "PID", "!환자등록번호", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.PT_NM, "PT_NM", "!환자명", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.PT_CMHS_NO, "PT_CMHS_NO", "!환자내원번호", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.MDCR_DEPT_CD, "MDCR_DEPT_CD", "!진료부서", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.DEPT_NM, "DEPT_NM", "진료부서", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.MDCR_DR_CD, "MDCR_DR_CD", "!진료의사", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.DR_NM, "DR_NM", "진료의사", 60, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);

		}        
        
        
        
        
         
        
        


        