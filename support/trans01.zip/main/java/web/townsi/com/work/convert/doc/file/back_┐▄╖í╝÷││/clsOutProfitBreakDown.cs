//                                                                                
// Class 명 : clsOutProfitBreakDown
// 역    할 : 외래수익코드집계내역
// 작 성 자 : PGH
// 작 성 일 : 2017-09-14
//                                                                                
// 수정내역 : 
//                                                                                
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public class clsOutProfitBreakDown
    {
        #region Define Variable Member
        private string m_PID = String.Empty;    //환자등록번호                     VARCHAR2(10)
        private int m_PT_CMHS_NO = 0;               //환자내원번호                     NUMBER(10, 0)
        private int m_RCPT_SQNO = 0;               //수납일련번호                     NUMBER(5, 0)
        private string m_PRFT_CD = String.Empty;    //수익코드                         VARCHAR2(4)
        private string m_MDCR_DD = String.Empty;    //진료일자                         VARCHAR2(8)
        private string m_BILL_NO = String.Empty;    //영수증번호                       VARCHAR2(10)
        private string m_INSN_TYCD = String.Empty;    //보험유형코드                     VARCHAR2(2)
        private string m_ASST_TYCD = String.Empty;    //보조유형코드                     VARCHAR2(2)
        private string m_ASCT_RGNO_CD = String.Empty;    //조합기호코드                     VARCHAR2(20)
        private string m_MDCR_DEPT_CD = String.Empty;    //진료부서코드                     VARCHAR2(10)
        private string m_MDCR_DR_CD = String.Empty;    //진료의사코드                     VARCHAR2(10)
        private int m_PAY_MATL_AMT = 0;               //급여재료금액                     NUMBER(10, 0)
        private int m_PAY_ACTN_AMT = 0;               //급여행위금액                     NUMBER(10, 0)
        private int m_PAY_BYKN_ADTN_AMT = 0;               //급여종별가산금액                 NUMBER(10, 0)
        private int m_INSN_100_MATL_AMT = 0;               //보험100재료금액                  NUMBER(10, 0)
        private int m_INSN_100_ACTN_AMT = 0;               //보험100행위금액                  NUMBER(10, 0)
        private int m_I100_HSBK_ADTN_AMT = 0;               //보험100종별가산금액              NUMBER(10, 0)
        private int m_SCNG_PAY_MATL_AMT = 0;               //선별급여재료금액                 NUMBER(10, 0)
        private int m_SCNG_PAY_ACTN_AMT = 0;               //선별급여행위금액                 NUMBER(10, 0)
        private int m_SCPY_BYKN_ADTN_AMT = 0;               //선별급여종별가산금액             NUMBER(10, 0)
        private int m_CLAM_NOPY_MATL_AMT = 0;               //청구비급여재료금액               NUMBER(10, 0)
        private int m_CLAM_NOPY_ACTN_AMT = 0;               //청구비급여행위금액               NUMBER(10, 0)
        private int m_CCPY_HSBK_ADTN_AMT = 0;               //청구비급여종별가산금액           NUMBER(10, 0)
        private int m_NOPY_MATL_AMT = 0;               //비급여재료금액                   NUMBER(10, 0)
        private int m_NOPY_ACTN_AMT = 0;               //비급여행위금액                   NUMBER(10, 0)
        private int m_NOPY_BYKN_ADTN_AMT = 0;               //비급여종별가산금액               NUMBER(10, 0)
        private int m_SMCR_AMT = 0;               //선택진료금액                     NUMBER(10, 0)
        private int m_MDCN_UPLM_DIAM = 0;               //약제상한차액                     NUMBER(10, 0)
        private double m_PAY_ACTN_USCH_AMT = 0;               //급여행위본인부담금액             NUMBER(10, 0)
        private double m_PAY_ACTN_CLAM_AMT = 0;               //급여행위청구금액                 NUMBER(10, 0)
        private double m_PAY_MATL_USCH_AMT = 0;               //급여재료본인부담금액             NUMBER(10, 0)
        private double m_PAY_MATL_CLAM_AMT = 0;               //급여재료청구금액                 NUMBER(10, 0)
        private double m_SCPY_MATL_USCH_AMT = 0;               //선별급여재료본인부담금액         NUMBER(10, 0)
        private double m_SCPY_MATL_CLAM_AMT = 0;               //선별급여재료청구금액             NUMBER(10, 0)
        private double m_SCPY_ACTN_USCH_AMT = 0;               //선별급여행위본인부담금액         NUMBER(10, 0)
        private double m_SCPY_ACTN_CLAM_AMT = 0;               //선별급여행위청구금액             NUMBER(10, 0)
        private string m_RCPT_DD = String.Empty;    //수납일자                         VARCHAR2(8)
        private string m_RCPT_TIME = String.Empty;    //수납시간                         VARCHAR2(4)
        private string m_AFRS_STAT_DVCD = String.Empty;    //업무구분코드                     VARCHAR2(2)
        private string m_ROW_STAT_DVCD = String.Empty;    //행상태구분코드                   VARCHAR2(2)
        private string m_DLWT_IP_ADDR = String.Empty;    //처리IP주소                       VARCHAR2(10)
        private string m_RGST_DT = String.Empty;    //등록일시                         VARCHAR2(14)
        private string m_RGSTR_ID = String.Empty;    //등록자ID                         VARCHAR2(10)
        private int m_NEW_RCPT_RQNO = 0;               //새로운 수납일련번호
        private string m_NEW_ROW_STAT_DVCD = String.Empty;

        private int m_GVRN_CLAM_AMT = 0;

        private int m_STATVAL1 = 1;             //행상태구분에 따른 값 ROW_STAT_DVCD = 'D' -> -1, ROW_STAT_DVCD = 'A' -> 1, ROW_STAT_DVCD = 'F' -> 0
        private int m_STATVAL2 = 1;             // 0, -1, 1

        #endregion

        #region Member Property
        public string PID { get { return m_PID; } set { m_PID = value; } }
        public int PT_CMHS_NO { get { return m_PT_CMHS_NO; } set { m_PT_CMHS_NO = value; } }
        public int RCPT_SQNO { get { return m_RCPT_SQNO; } set { m_RCPT_SQNO = value; } }
        public string PRFT_CD { get { return m_PRFT_CD; } set { m_PRFT_CD = value; } }
        public string MDCR_DD { get { return m_MDCR_DD; } set { m_MDCR_DD = value; } }
        public string BILL_NO { get { return m_BILL_NO; } set { m_BILL_NO = value; } }
        public string INSN_TYCD { get { return m_INSN_TYCD; } set { m_INSN_TYCD = value; } }
        public string ASST_TYCD { get { return m_ASST_TYCD; } set { m_ASST_TYCD = value; } }
        public string ASCT_RGNO_CD { get { return m_ASCT_RGNO_CD; } set { m_ASCT_RGNO_CD = value; } }
        public string MDCR_DEPT_CD { get { return m_MDCR_DEPT_CD; } set { m_MDCR_DEPT_CD = value; } }
        public string MDCR_DR_CD { get { return m_MDCR_DR_CD; } set { m_MDCR_DR_CD = value; } }
        public int PAY_MATL_AMT { get { return m_PAY_MATL_AMT; } set { m_PAY_MATL_AMT = value; } }
        public int PAY_ACTN_AMT { get { return m_PAY_ACTN_AMT; } set { m_PAY_ACTN_AMT = value; } }
        public int PAY_BYKN_ADTN_AMT { get { return m_PAY_BYKN_ADTN_AMT; } set { m_PAY_BYKN_ADTN_AMT = value; } }
        public int INSN_100_MATL_AMT { get { return m_INSN_100_MATL_AMT; } set { m_INSN_100_MATL_AMT = value; } }
        public int INSN_100_ACTN_AMT { get { return m_INSN_100_ACTN_AMT; } set { m_INSN_100_ACTN_AMT = value; } }
        public int I100_HSBK_ADTN_AMT { get { return m_I100_HSBK_ADTN_AMT; } set { m_I100_HSBK_ADTN_AMT = value; } }
        public int SCNG_PAY_MATL_AMT { get { return m_SCNG_PAY_MATL_AMT; } set { m_SCNG_PAY_MATL_AMT = value; } }
        public int SCNG_PAY_ACTN_AMT { get { return m_SCNG_PAY_ACTN_AMT; } set { m_SCNG_PAY_ACTN_AMT = value; } }
        public int SCPY_BYKN_ADTN_AMT { get { return m_SCPY_BYKN_ADTN_AMT; } set { m_SCPY_BYKN_ADTN_AMT = value; } }
        public int CLAM_NOPY_MATL_AMT { get { return m_CLAM_NOPY_MATL_AMT; } set { m_CLAM_NOPY_MATL_AMT = value; } }
        public int CLAM_NOPY_ACTN_AMT { get { return m_CLAM_NOPY_ACTN_AMT; } set { m_CLAM_NOPY_ACTN_AMT = value; } }
        public int CCPY_HSBK_ADTN_AMT { get { return m_CCPY_HSBK_ADTN_AMT; } set { m_CCPY_HSBK_ADTN_AMT = value; } }
        public int NOPY_MATL_AMT { get { return m_NOPY_MATL_AMT; } set { m_NOPY_MATL_AMT = value; } }
        public int NOPY_ACTN_AMT { get { return m_NOPY_ACTN_AMT; } set { m_NOPY_ACTN_AMT = value; } }
        public int NOPY_BYKN_ADTN_AMT { get { return m_NOPY_BYKN_ADTN_AMT; } set { m_NOPY_BYKN_ADTN_AMT = value; } }
        public int SMCR_AMT { get { return m_SMCR_AMT; } set { m_SMCR_AMT = value; } }
        public int MDCN_UPLM_DIAM { get { return m_MDCN_UPLM_DIAM; } set { m_MDCN_UPLM_DIAM = value; } }
        public double PAY_ACTN_USCH_AMT { get { return m_PAY_ACTN_USCH_AMT; } set { m_PAY_ACTN_USCH_AMT = value; } }
        public double PAY_ACTN_CLAM_AMT { get { return m_PAY_ACTN_CLAM_AMT; } set { m_PAY_ACTN_CLAM_AMT = value; } }
        public double PAY_MATL_USCH_AMT { get { return m_PAY_MATL_USCH_AMT; } set { m_PAY_MATL_USCH_AMT = value; } }
        public double PAY_MATL_CLAM_AMT { get { return m_PAY_MATL_CLAM_AMT; } set { m_PAY_MATL_CLAM_AMT = value; } }
        public double SCPY_MATL_USCH_AMT { get { return m_SCPY_MATL_USCH_AMT; } set { m_SCPY_MATL_USCH_AMT = value; } }
        public double SCPY_MATL_CLAM_AMT { get { return m_SCPY_MATL_CLAM_AMT; } set { m_SCPY_MATL_CLAM_AMT = value; } }
        public double SCPY_ACTN_USCH_AMT { get { return m_SCPY_ACTN_USCH_AMT; } set { m_SCPY_ACTN_USCH_AMT = value; } }
        public double SCPY_ACTN_CLAM_AMT { get { return m_SCPY_ACTN_CLAM_AMT; } set { m_SCPY_ACTN_CLAM_AMT = value; } }
        public string RCPT_DD { get { return m_RCPT_DD; } set { m_RCPT_DD = value; } }
        public string RCPT_TIME { get { return m_RCPT_TIME; } set { m_RCPT_TIME = value; } }
        public string AFRS_STAT_DVCD { get { return m_AFRS_STAT_DVCD; } set { m_AFRS_STAT_DVCD = value; } }
        public string ROW_STAT_DVCD { get { return m_ROW_STAT_DVCD; } set { m_ROW_STAT_DVCD = value; } }
        public string DLWT_IP_ADDR { get { return m_DLWT_IP_ADDR; } set { m_DLWT_IP_ADDR = value; } }
        public string RGST_DT { get { return m_RGST_DT; } set { m_RGST_DT = value; } }
        public string RGSTR_ID { get { return m_RGSTR_ID; } set { m_RGSTR_ID = value; } }
        public int GVRN_CLAM_AMT { get { return m_GVRN_CLAM_AMT; } set { m_GVRN_CLAM_AMT = value; } }

        public int NEW_RCPT_RQNO { get { return m_NEW_RCPT_RQNO; } set { m_NEW_RCPT_RQNO = value; } }
        public string NEW_ROW_STAT_DVCD { get { return m_NEW_ROW_STAT_DVCD; } set { m_NEW_ROW_STAT_DVCD = value; } }

        public int STATVAL1 { get { return m_STATVAL1; } set { m_STATVAL1 = value; } }
        public int STATVAL2 { get { return m_STATVAL2; } set { m_STATVAL2 = value; } }
        #endregion

        #region Contructor
        public clsOutProfitBreakDown()
        {
            Clear();
        }
        #endregion

        #region Method General
        public void Clear()
        {
            m_PID = String.Empty;
            m_PT_CMHS_NO = 0;
            m_RCPT_SQNO = 0;
            m_PRFT_CD = String.Empty;
            m_MDCR_DD = String.Empty;
            m_BILL_NO = String.Empty;
            m_INSN_TYCD = String.Empty;
            m_ASST_TYCD = String.Empty;
            m_ASCT_RGNO_CD = String.Empty;
            m_MDCR_DEPT_CD = String.Empty;
            m_MDCR_DR_CD = String.Empty;
            m_PAY_MATL_AMT = 0;
            m_PAY_ACTN_AMT = 0;
            m_PAY_BYKN_ADTN_AMT = 0;
            m_INSN_100_MATL_AMT = 0;
            m_INSN_100_ACTN_AMT = 0;
            m_I100_HSBK_ADTN_AMT = 0;
            m_SCNG_PAY_MATL_AMT = 0;
            m_SCNG_PAY_ACTN_AMT = 0;
            m_SCPY_BYKN_ADTN_AMT = 0;
            m_CLAM_NOPY_MATL_AMT = 0;
            m_CLAM_NOPY_ACTN_AMT = 0;
            m_CCPY_HSBK_ADTN_AMT = 0;
            m_NOPY_MATL_AMT = 0;
            m_NOPY_ACTN_AMT = 0;
            m_NOPY_BYKN_ADTN_AMT = 0;
            m_SMCR_AMT = 0;
            m_MDCN_UPLM_DIAM = 0;
            m_PAY_ACTN_USCH_AMT = 0;
            m_PAY_ACTN_CLAM_AMT = 0;
            m_PAY_MATL_USCH_AMT = 0;
            m_PAY_MATL_CLAM_AMT = 0;
            m_SCPY_MATL_USCH_AMT = 0;
            m_SCPY_MATL_CLAM_AMT = 0;
            m_SCPY_ACTN_USCH_AMT = 0;
            m_SCPY_ACTN_CLAM_AMT = 0;
            m_RCPT_DD = String.Empty;
            m_RCPT_TIME = String.Empty;
            m_AFRS_STAT_DVCD = String.Empty;
            m_ROW_STAT_DVCD = String.Empty;
            m_DLWT_IP_ADDR = String.Empty;
            m_RGST_DT = String.Empty;
            m_RGSTR_ID = String.Empty;
            m_NEW_RCPT_RQNO = 0;
            m_NEW_ROW_STAT_DVCD = String.Empty;

            m_GVRN_CLAM_AMT = 0;

            m_STATVAL1 = 1;
            m_STATVAL2 = 1;
        }
        #endregion

        #region Method : Insert Update Delete
        /// <summary>
        /// 외래수익코드별집계내역을 DataTable에 담아서 PaOpraBd Insert.
        /// </summary>
        /// <returns></returns>
        public bool SavePaOpraBd(ref string msg)
        {
            try
            {
                DataTable dtPaOpraBd = new DataTable();

                if (m_NEW_ROW_STAT_DVCD.Equals("A") && m_AFRS_STAT_DVCD.Equals("9"))
                {
                    DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOPRABD(true), ref dtPaOpraBd, m_PID
                                                                                              , m_PT_CMHS_NO.ToString()
                                                                                              , m_ROW_STAT_DVCD);
                }
                else
                {
                    DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOPRABD(false), ref dtPaOpraBd, m_PID
                                                                                               , m_PT_CMHS_NO.ToString()
                                                                                               , m_RCPT_SQNO.ToString()
                                                                                               , m_ROW_STAT_DVCD);
                }

                if (dtPaOpraBd.Rows.Count > 0)
                {
                    return InsertPaOpraBd(dtPaOpraBd, ref msg);
                }

                return false;
            }
            catch (Exception ex)
            {
                msg = "외래수익코드별집계내역 저장 중 오류를 발생했습니다.\r\n " +
                      "Method :  [SavePaOpraBd] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }
            return true;
        }

        public bool SavePaOpraBd_Uncl(ref string msg)
        {
            try
            {
                DataTable dtPaOpraBd = new DataTable();

                DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOPRABD(true), ref dtPaOpraBd, m_PID
                                                                                          , m_PT_CMHS_NO.ToString()
                                                                                          , m_ROW_STAT_DVCD);

                if (dtPaOpraBd.Rows.Count > 0)
                {
                    return InsertPaOpraBd(dtPaOpraBd, ref msg);
                }
                // SEO 수정6******************************************************
                return false;
            }
            catch (Exception ex)
            {
                msg = "외래수익코드별집계내역 저장 중 오류를 발생했습니다.\r\n " +
                      "Method :  [SavePaOpraBd] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }
            return true;
        }

        /// <summary>
        /// 외래수익코드별집계내역 Insert
        /// </summary>
        /// <param name="dtpaoprabd"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        private bool InsertPaOpraBd(DataTable dtpaoprabd, ref string msg)
        {
            try
            {
                foreach (DataRow row in dtpaoprabd.Rows)
                {
                    if (!DBService.ExecuteNonQuery(SQL.PA.BaseSql.Insert.PAOPRABD(), row["PID"].ToString()
                                                                                   , row["PT_CMHS_NO"].ToString()
                                                                                   , m_NEW_RCPT_RQNO.ToString()
                                                                                   , row["PRFT_CD"].ToString()
                                                                                   , row["MDCR_DD"].ToString()
                                                                                   , m_BILL_NO
                                                                                   , row["INSN_TYCD"].ToString()
                                                                                   , row["ASST_TYCD"].ToString()
                                                                                   , row["ASCT_RGNO_CD"].ToString()
                                                                                   , row["MDCR_DEPT_CD"].ToString()
                                                                                   , row["MDCR_DR_CD"].ToString()
                                                                                   , (int.Parse(row["PAY_MATL_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (int.Parse(row["PAY_ACTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (int.Parse(row["PAY_BYKN_ADTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (int.Parse(row["INSN_100_MATL_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (int.Parse(row["INSN_100_ACTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (int.Parse(row["I100_HSBK_ADTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (int.Parse(row["SCNG_PAY_MATL_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (int.Parse(row["SCNG_PAY_ACTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (int.Parse(row["SCPY_BYKN_ADTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (int.Parse(row["CLAM_NOPY_MATL_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (int.Parse(row["CLAM_NOPY_ACTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (int.Parse(row["CCPY_HSBK_ADTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (int.Parse(row["NOPY_MATL_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (int.Parse(row["NOPY_ACTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (int.Parse(row["NOPY_BYKN_ADTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (int.Parse(row["SMCR_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (int.Parse(row["MDCN_UPLM_DIAM"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (double.Parse(row["PAY_ACTN_USCH_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (double.Parse(row["PAY_ACTN_CLAM_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (double.Parse(row["PAY_MATL_USCH_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (double.Parse(row["PAY_MATL_CLAM_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (double.Parse(row["SCPY_MATL_USCH_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (double.Parse(row["SCPY_MATL_CLAM_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (double.Parse(row["SCPY_ACTN_USCH_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , (double.Parse(row["SCPY_ACTN_CLAM_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   , row["RCPT_DD"].ToString()
                                                                                   , row["RCPT_TIME"].ToString()
                                                                                   , m_AFRS_STAT_DVCD
                                                                                   , m_NEW_ROW_STAT_DVCD
                                                                                   , m_DLWT_IP_ADDR
                                                                                   , m_RGST_DT
                                                                                   , m_RGSTR_ID
                                                                                   , (int.Parse(row["GVRN_CLAM_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                   ))
                        throw new Exception("외래수익코드집계내역 저장 중 에러가 발생했습니다.");
                }
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                if (DBService.IsTransaction)
                    DBService.RollbackTransaction();

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                msg = ex.Message + error;

                return false;
            }

            return true;
        }

        /// <summary>
        /// 외래영수내역 행상태구분코드 UPDATE
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool UpdateRowStatDvcdOfPaOpraBd(ref string msg)
        {
            bool success = true;

            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePAOPRABD_RowStatDvcd(), this.PID
                                                                                  , this.PT_CMHS_NO.ToString()
                                                                                  , this.ROW_STAT_DVCD
                                                                                  , this.NEW_ROW_STAT_DVCD))
            {
                success = false;
                msg = DBService.ErrorMessage + "\r\n 외래수익코드별집계내역의 행상태구분코드 변경중 오류가 발생하였습니다. 확인하시기 바랍니다.";
                DBService.RollbackTransaction();
            }
            return success;
        }
        #endregion
    }
}