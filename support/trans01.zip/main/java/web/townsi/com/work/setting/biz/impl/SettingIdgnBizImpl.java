package web.townsi.com.work.setting.biz.impl;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;
import web.townsi.com.work.mapper.SettingMapper;
import web.townsi.com.work.setting.biz.SettingBiz;
import web.townsi.com.work.setting.biz.SettingIdgnBiz;

@SuppressWarnings({"rawtypes","unchecked","unused"})
@Service
public class SettingIdgnBizImpl implements SettingIdgnBiz {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private SettingBiz settingBiz;

	@Autowired
	private SettingMapper settingMapper;


	public static String READ_LINE = "\n";
	public static String TAB = "\t";
	public static String SLASH = File.separator;// lastIndexOf("/")


	public static String rTxt  = "#{txt}";

	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();

	@Override
	public HashMap makeIdgn(HashMap params) throws Exception {

		HashMap dataMap = new HashMap();

		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String upperTableName = StringUtils.defaultString((String) params.get("upperTableName"));
		String lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		String camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		String tableSchema = StringUtils.defaultString((String) params.get("tableSchema"));
		String camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String modelComment = StringUtils.defaultString((String) params.get("modelComment"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String group1 = StringUtils.defaultString((String) params.get("group1"));
		String author = StringUtils.defaultString((String) params.get("author"));
		String today = StringUtils.defaultString((String) params.get("today"));
		String current = StringUtils.defaultString((String) params.get("current"));
		String menu = StringUtils.defaultString((String) params.get("menu"));
		String programId = StringUtils.defaultString((String) params.get("programId"));

		List<HashMap> list = settingBiz.selectTableInfo(params,
				  StringUtils.defaultString((String)params.get("dbName"))
				, StringUtils.defaultString((String)params.get("tableSchema"))
			    , StringUtils.defaultString((String)params.get("tableName"))
				);

		HashMap replaceMap = new HashMap();
		replaceMap.put("#group#",group);
		replaceMap.put("#group#",group);
		replaceMap.put("#group1#", group1);
		replaceMap.put("#author#", author);
		replaceMap.put("#today#", today);
		replaceMap.put("#current#",current);
		replaceMap.put("#menu#",menu);
		replaceMap.put("#programId#",programId);
		replaceMap.put("#camelTableFirstUpperName#",camelTableFirstUpperName);
		replaceMap.put("#camelTableName#",camelTableName);
		replaceMap.put("#prefix#","AB");
		replaceMap.put("#cipers#","");

		//AppStartingEvent.java --> copyArray
		String rfullPath = SITE_WEB_ROOT + "/copy/context-idgn-sample.xml";
		String wfullPath = SITE_WEB_ROOT + "/new/" + tableSchema + "/" + camelTableName+"/context-idgn-"+camelTableName+".xml";

		String str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);
		dataMap.put("mapperStr", str);
		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}

}