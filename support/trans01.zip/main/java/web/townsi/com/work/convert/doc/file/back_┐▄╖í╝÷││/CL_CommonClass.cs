using System;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using FarPoint.Win.Spread.CellType;
using Lime.Framework.Controls;
using Lime.SqlPack;
using SQL = Lime.SqlPack.CL;

namespace Lime.Framework.BusinessService
{
    public class CL_CommonClass
    {
        #region Test용 Timer

        private static string m_ClassName = string.Empty;
        private static Stopwatch stopwatch;
        public static void TimerStart(string ClassName)
        {
            m_ClassName = ClassName;

            stopwatch = new Stopwatch();
            stopwatch.Restart();
        }
        public static void TimerStop()
        {
            stopwatch.Stop();
        }
        public static void TimerElapsed(string Title = "TimerElapsed")
        {
            string Msg = stopwatch.Elapsed.ToString();
            LogService.ErrorLog(Msg);
        }

        #endregion

        #region StackTrace

        public static void StackTrace_CL(string ClassName)
        {
            // 2020-08-25 SJH
            return;

            int StackDepth = 0;
            int StackCount = 1;
            StackDepth = ClassName.Equals("StackTrace") ? 2 : 1;
            System.Text.StringBuilder SB = new System.Text.StringBuilder();
            System.Reflection.MethodBase method = new System.Diagnostics.StackTrace().GetFrame(StackDepth).GetMethod();

            SB.Clear();

            do
            {
                try
                {
                    method = new System.Diagnostics.StackTrace().GetFrame(StackDepth).GetMethod();
                    System.Reflection.ParameterInfo[] param = method.GetParameters();

                    string MethodName = string.Format("\r\n{0} : {1}.{2}", StackCount.ToString().PadLeft(5, '0'), method.ReflectedType.FullName, method.Name);
                    string ParamName = string.Empty;

                    for (int ParamLoop = 0; ParamLoop < param.Length; ParamLoop++)
                        ParamName += param[ParamLoop].ParameterType.Name.ToString() + " " + param[ParamLoop].Name + ", ";

                    ParamName = ParamName.Trim();
                    ParamName = ParamName.Length > 0 ? ParamName.Substring(0, ParamName.Length - 1) : string.Empty;
                    MethodName = string.Format("{0} ({1})", MethodName, ParamName);
                    SB.AppendLine(MethodName);

                    StackDepth++;
                    StackCount++;
                }
                catch
                {
                    break;
                }
            }
            while (true);

            Debug_WriteLine(string.Format(@"
★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
[{0}]
★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
", ClassName), SB.ToString());

            try
            {
                //DBService.ExecuteNonQuery(Lime.SqlPack.ErrorLog.InsertErrorLog(DateTime.Now.ToString("yyyyMMddHHmmssfff"), StringService.SubStringByte(SB.ToString(), 0, 4000).Replace("'", "''"), DOPack.UserInfo.USER_CD));
            }
            catch { }

        }
        #endregion

        #region ErrorCaption
        public static string ErrorCaption(string ClassName)
        {
            try
            {
                string Caption = string.Empty;

                System.Reflection.MethodBase method = new System.Diagnostics.StackTrace().GetFrame(1).GetMethod();
                System.Reflection.ParameterInfo[] param = method.GetParameters();
                string ParamName = string.Empty;

                for (int ParamLoop = 0; ParamLoop < param.Length; ParamLoop++)
                    ParamName += param[ParamLoop].ParameterType.Name.ToString() + " " + param[ParamLoop].Name + ", ";

                ParamName = ParamName.Trim();
                ParamName = ParamName.Length > 0 ? ParamName.Substring(0, ParamName.Length - 1) : string.Empty;

                Caption = string.Format("오류 - [{0} - {1}({2})]", ClassName, method.Name, ParamName);

                return Caption;
            }
            catch (Exception ex)
            {
                LxMessage.Show(ex.Message);
                return string.Empty;
            }
        }
        #endregion

        #region Debug WriteLine

        public static void Debug_WriteLine(string Msg)
        {
            LogService.ErrorLog(Msg);
        }

        public static void Debug_WriteLine(string Title, string Msg)
        {
            LogService.ErrorLog(Msg);
        }

        #endregion

        #region Get LogFile
        private static popProgress pop = new popProgress();
        private static string ServerPath = string.Empty;
        // API 함수 선언 
        [System.Runtime.InteropServices.DllImport("mpr.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        public static extern int WNetUseConnection(IntPtr hwndOwner, [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Struct)] ref NETRESOURCE lpNetResource, string lpPassword, string lpUserID, uint dwFlags, StringBuilder lpAccessName, ref int lpBufferSize, out uint lpResult);
        // API 함수 선언 (공유해제) 
        [System.Runtime.InteropServices.DllImport("mpr.dll", EntryPoint = "WNetCancelConnection2", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        public static extern int WNetCancelConnection2A(string lpName, int dwFlags, int fForce);

        public static void GetLogFile()
        {
            try
            {
                string Server = HospitalConfig.CurrentHospitalConfig.HospitalCode.Equals("WOOSONG") ? @"\\122.199.146.7" :
                                HospitalConfig.CurrentHospitalConfig.HospitalCode.Equals("BUCHON") ? @"\\122.199.163.23" : string.Empty;

                if (string.IsNullOrWhiteSpace(Server)) return;

                ConnectRemoteServer(Server);

                ServerPath = HospitalConfig.CurrentHospitalConfig.HospitalCode.Equals("WOOSONG") ? @"\\122.199.146.7\Lime_Document\80.Log&Error\" :
                             HospitalConfig.CurrentHospitalConfig.HospitalCode.Equals("BUCHON") ? @"\\122.199.163.23\Lime_Document\80.Log&Error\" : string.Empty;

                if (string.IsNullOrWhiteSpace(ServerPath)) return;

                ServerPath += "[CL-" + DOPack.UserInfo.USER_CD + "-" + DateTime.Now.ToString("yyyyMMddHHmmss") + "]";

                if (!Directory.Exists(ServerPath))
                    Directory.CreateDirectory(ServerPath);

                string ClientPath = @"C:\Lime\Log";

                if (!Directory.Exists(ClientPath))
                    Directory.CreateDirectory(ClientPath);

                DirectoryInfo dirs = new DirectoryInfo(ClientPath);

                if (pop == null || pop.IsDisposed)
                    pop = new popProgress();

                pop.Show();

                GetDirInfo(dirs);

                CencelRemoteServer(Server);

                pop.Dispose();
            }
            catch (Exception ex)
            {
                pop.Dispose();

                LxMessage.Show("LogFile 보내는 중 오류.", ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public static void GetDirInfo(DirectoryInfo DirInfo)
        {
            FileInfo[] fileinfo = DirInfo.GetFiles();

            int PbarValue = 0;

            foreach (FileInfo file in fileinfo)
            {
                PbarValue++;
                pop.SetTitleProgressBar(file.FullName, PbarValue, fileinfo.Length);

                CopyFile(file);
            }

            DirectoryInfo[] dirs = DirInfo.GetDirectories();

            foreach (DirectoryInfo dir in dirs)
            {
                GetDirInfo(dir);
            }
        }
        public static void CopyFile(FileInfo fileinfo)
        {
            File.Copy(fileinfo.FullName, ServerPath + @"\" + fileinfo.Name);
            File.Delete(fileinfo.FullName);
        }

        // 구조체 선언 
        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential, CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        public struct NETRESOURCE
        {
            public uint dwScope;
            public uint dwType;
            public uint dwDisplayType;
            public uint dwUsage;
            public string lpLocalName;
            public string lpRemoteName;
            public string lpComment;
            public string lpProvider;
        }
        // 공유연결 
        public static int ConnectRemoteServer(string server)
        {
            int capacity = 64;
            uint flags = 0;
            System.Text.StringBuilder sb = new System.Text.StringBuilder(capacity);
            NETRESOURCE ns = new NETRESOURCE();
            ns.dwType = 1;              // 공유 디스크 
            ns.lpLocalName = "";   // 로컬 드라이브 지정하지 않음 
            ns.lpRemoteName = server;
            ns.lpProvider = null;
            int result = 0;
            result = WNetUseConnection(IntPtr.Zero, ref ns, "1234!@#$qwerQWER", "Lime", flags, sb, ref capacity, out uint resultFlags);
            return result;
        }

        // 공유해제 
        public static void CencelRemoteServer(string server)
        {
            WNetCancelConnection2A(server, 1, 0);
        }
        #endregion

        #region ModifyCheck
        /// <summary>
        /// 수정여부
        /// </summary>
        /// <param name="Celltype">셀 타입</param>
        /// <param name="CellValue">현제 값</param>
        /// <param name="CellOldValue">과거 값</param>
        /// <returns>True : 수정안됨 False : 수정됨</returns>
        public static bool CheckModify(object Celltype, object CellValue, object CellOldValue)
        {
            try
            {
                ImageCellType CelltypeImage = new ImageCellType();
                MaskCellType CelltypeMask = new MaskCellType();
                TextCellType CelltypeTextBox = new TextCellType();
                ButtonCellType CelltypeButton = new ButtonCellType();
                NumberCellType CelltypeNumber = new NumberCellType();
                SliderCellType CelltypeSlider = new SliderCellType();
                PercentCellType CelltypePercent = new PercentCellType();
                GeneralCellType CelltypeGeneral = new GeneralCellType();
                CheckBoxCellType CelltypeCheckBox = new CheckBoxCellType();
                DateTimeCellType CelltypeDateTime = new DateTimeCellType();
                ComboBoxCellType CelltypeComboBox = new ComboBoxCellType();
                CurrencyCellType CelltypeCurrency = new CurrencyCellType();
                ProgressCellType CelltypeProgress = new ProgressCellType();
                MultiOptionCellType CelltypeMultiOption = new MultiOptionCellType();

                Celltype = Celltype == null ? string.Empty : Celltype;
                CellValue = CellValue == null ? string.Empty : CellValue;
                CellOldValue = CellOldValue == null ? string.Empty : CellOldValue;

                if (Celltype is ImageCellType)
                {
                    return CellValue.Equals(CellOldValue);
                }
                else if (Celltype is MaskCellType)
                {
                    return CellValue.Equals(CellOldValue);
                }
                else if (Celltype is TextCellType)
                {
                    return CellValue.Equals(CellOldValue);
                }
                else if (Celltype is ButtonCellType)
                {
                    return CellValue.Equals(CellOldValue);
                }
                else if (Celltype is NumberCellType)
                {

                    decimal.TryParse(CellValue.ToString(), out decimal CelVal);
                    decimal.TryParse(CellOldValue.ToString(), out decimal CelOldVal);

                    return CelVal.ToString("#,###.####").Equals(CelOldVal.ToString("#,###.####"));
                }
                else if (Celltype is SliderCellType)
                {
                    return CellValue.Equals(CellOldValue);
                }
                else if (Celltype is PercentCellType)
                {
                    return CellValue.Equals(CellOldValue);
                }
                else if (Celltype is GeneralCellType)
                {
                    return CellValue.Equals(CellOldValue);
                }
                else if (Celltype is CheckBoxCellType)
                {
                    if ((bool)CellValue)
                        return CellOldValue.Equals("Y");
                    else if (!(bool)CellValue)
                        return CellOldValue.Equals("N");
                }
                else if (Celltype is DateTimeCellType)
                {
                    return CellValue.Equals(CellOldValue);
                }
                else if (Celltype is ComboBoxCellType)
                {
                    return CellValue.Equals(CellOldValue);
                }
                else if (Celltype is CurrencyCellType)
                {

                    decimal.TryParse(CellValue.ToString(), out decimal CelVal);
                    decimal.TryParse(CellOldValue.ToString(), out decimal CelOldVal);

                    return CelVal.ToString("#,###.####").Equals(CelOldVal.ToString("#,###.####"));
                }
                else if (Celltype is ProgressCellType)
                {
                    return CellValue.Equals(CellOldValue);
                }
                else if (Celltype is MultiOptionCellType)
                {
                    return CellValue.Equals(CellOldValue);
                }

                return true;
            }
            catch (Exception ex)
            {
                Debug_WriteLine("CL_CommonClass - ChedkModify()", ex.Message);

                return true; // 비교 불가 수정 안된걸로 봄..
            }
        }
        #endregion

        #region Popup Location
        public static Point CalPopupLocation(Size popupsize)
        {
            // TODO : 

            Point PopupLocation = new Point();

            int SelectMonitor = 0;
            Screen[] sc = Screen.AllScreens;

            if (sc.Length < 2)
                SelectMonitor = 0;

            int MouseX = Cursor.Position.X;
            int MouseY = Cursor.Position.Y;

            bool Top = MouseY < (sc[SelectMonitor].WorkingArea.Height / 2) ? true : false;
            bool Left = MouseX < (sc[SelectMonitor].WorkingArea.Width / 2) ? true : false;

            int X = MouseX + popupsize.Width;
            int Y = MouseY + popupsize.Height;

            PopupLocation.X = (Left) ? MouseX + 10 : MouseX - 10;
            PopupLocation.Y = (Top) ? MouseY + 10 : MouseY - 10;


            //if (sc[SelectMonitor].WorkingArea.Width - (MouseX + popupsize.Width) < 0 || sc[SelectMonitor].WorkingArea.Height - (MouseY + popupsize.Height) < 0)

            //this.StartPosition = FormStartPosition.Manual;
            //this.Location = sc[mSelectMonitor].Bounds.Location;
            //Point p = new Point(sc[mSelectMonitor].Bounds.Location.X, sc[mSelectMonitor].Bounds.Location.Y);
            //Location = p;
            //this.WindowState = FormWindowState.Maximized;

            return PopupLocation;
        }
        #endregion

        #region DataBase

        /// <summary>
        /// 부서의 보험청구부서를 가져온다.
        /// </summary>
        /// <param name="deptcode"></param>
        /// <returns></returns>
        public static string GET_CLAM_DEPT_CODE(string deptcode)
        {
            object RetVal = null;
            RetVal = DBService.ExecuteScalar(SQL.Sql.get_popTransOrder_Select_INSN_CLAM_DEPT_CD(), deptcode);
            if (DBService.HasError)
                LogService.ErrorLog(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

            if (RetVal != null)
                return RetVal.ToString();
            else
                return string.Empty;
        }

        /// <summary>
        /// 병원등록정보(종별지수)를 가져온다.
        /// </summary>
        /// <param name="Date"></param>
        /// <returns></returns>
        public static string GET_BYKN_INDX(string Date)
        {
            string RetVal = DBService.ExecuteScalar(SQL.Sql.GetUcfClJudgeMainHospInfo(), Date).ToString();
            if (DBService.HasError)
                throw new Exception("종별지수를 조회하는 중 에러가 발생했습니다.");

            return RetVal;
        }

        /// <summary>
        /// 병원가산율을 읽는다.
        /// </summary>
        /// <param name="pid">환자등록번호</param>
        /// <param name="pt_cmhs_no">내원번호</param>
        /// <param name="mdcr_dr_cd">진료의코드</param>
        /// <param name="insn_tycd">보험유형</param>
        /// <param name="asst_tycd">유형보조</param>
        /// <param name="aply_dd">기준일</param>
        /// <returns></returns>
        public static decimal GET_BYKN_ADTR(string pid, string pt_cmhs_no, string mdcr_dr_cd, string insn_tycd, string asst_tycd, string aply_dd)
        {
            decimal BYKN_ADTR = 0;
            object RetVal = DBService.ExecuteScalar(SQL.Sql.ucfCLJudgeMain_BITPCLMA_BYKN_ADTR(), insn_tycd, asst_tycd, aply_dd);
            if (DBService.HasError)
                LogService.ErrorLog(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

            if (RetVal != null)
                decimal.TryParse(RetVal.ToString(), out BYKN_ADTR);

            //****************************************************************************************************
            // 산재지정의 종별가산율을 읽는다.
            //****************************************************************************************************
            // 계산적용코드관리에서 산재관리의사 지정 적용 여부를 읽는다
            // 2021-01-28 SJH 현재, 오송만 적용됨
            if (DBService.ExecuteScalar(Function.SelectFN_BI_READ_BICARAMA(), "INCS_DV_YN", aply_dd, "A", "1", "").ToString().Equals("Y"))
            {
                // 산재인지 후유인지 체크, 의사가 산재지정의인지 체크, PATRTEIF(환자접수기타정보) 에 '0' 인지 체크
                // 청구심사도 patrteif 읽어야 할 듯 (외래/입원 둘 다 있으니...)
                if (insn_tycd.Equals("31") && asst_tycd.Equals("00") &&
                    !DBService.ExecuteScalar(Function.FN_PA_READ_INCSAFFRDVCD(pid, aply_dd)).ToString().Equals("H") &&
                     DBService.ExecuteScalar(Function.FN_CL_READ_INCSDRYN(aply_dd, mdcr_dr_cd)).ToString().Equals("Y") &&
                    !DBService.ExecuteScalar(Function.FN_PA_READ_PATRTEIF(), pid, pt_cmhs_no, "ETC_USE_CNTS_23").ToString().Equals("1"))
                {
                    string lsbykn_adtr = DBService.ExecuteScalar(Function.FN_CL_READ_SPCLRATE1(aply_dd, "INCS01")).ToString();
                    decimal.TryParse(lsbykn_adtr, out BYKN_ADTR);
                }
            }

            return BYKN_ADTR;
        }

        /// <summary>
        /// 상한가 적용유무 구분을 가져온다. (컬럼명 : 실거래가 계산)
        /// </summary>
        /// <param name="OrderCode"></param>
        /// <param name="OrderDate"></param>
        /// <returns></returns>
        public static string GET_REAL_DEAL_CLCL_YN(string OrderCode, string OrderDate)
        {
            object RetVal = DBService.ExecuteScalar(SQL.Sql.GetRealDealCLCL_YN(), OrderCode, OrderDate);
            if (DBService.HasError)
                LogService.ErrorLog(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

            if (RetVal != null)
                return RetVal.ToString();
            else
                return string.Empty;
        }

        /// <summary>
        /// 건강보험단가를 가져온다.
        /// </summary>
        /// <param name="OrderCode"></param>
        /// <param name="OrderDate"></param>
        /// <returns></returns>
        public static decimal GET_HLNS_UNPR(string OrderCode, string OrderDate)
        {
            object RetVal = null;
            decimal HLNS_UNPR = 0;
            RetVal = DBService.ExecuteScalar(SQL.Sql.GetHLNS_UNPR(), OrderCode, OrderDate);
            if (DBService.HasError)
                LogService.ErrorLog(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

            if (RetVal != null)
                decimal.TryParse(RetVal.ToString(), out HLNS_UNPR);

            return HLNS_UNPR;
        }

        /// <summary>
        /// 보훈여부를 가져온다
        /// </summary>
        /// <param name="PID"></param>
        /// <param name="PT_CMHS_NO"></param>
        /// <param name="DATE"></param>
        /// <returns></returns>
        public static string GET_VTRN_PT_YN(string PID, string PT_CMHS_NO, string DATE)
        {
            object RetVal = null;
            RetVal = DBService.ExecuteScalar(SQL.Sql.GET_VTRN_PT_YN(), PID, PT_CMHS_NO, DATE);
            if (DBService.HasError)
                LogService.ErrorLog(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

            if (RetVal != null)
                return RetVal.ToString();
            else
                return string.Empty;
        }

        /// <summary>
        /// 부가가치세 적용여부
        /// </summary>
        /// <param name="OrderCode"></param>
        /// <param name="Date"></param>
        /// <returns></returns>
        public static string GET_VAT_APLY_YN(string OrderCode, string Date)
        {
            object RetVal = null;
            RetVal = DBService.ExecuteScalar(SQL.Sql.Get_VAT_APLY_YN(), OrderCode, Date);
            if (DBService.HasError)
                LogService.ErrorLog(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

            if (RetVal != null)
                return RetVal.ToString();
            else
                return string.Empty;
        }

        /// <summary>
        /// 부가가치세 적용 여부를 가져온다.
        /// </summary>
        /// <param name="OrderCode"></param>
        /// <param name="Date"></param>
        /// <param name="VTRN_PT_YN"></param>
        /// <returns></returns>
        public static string GET_VAT_APLY_YN(string OrderCode, string Date, string INSN_TYCD, string VTRN_PT_YN)
        {
            object RetVal = null;
            RetVal = DBService.ExecuteScalar(SQL.Sql.GetHLNS_I100_USCH_CD(), OrderCode, Date, INSN_TYCD, VTRN_PT_YN);
            if (DBService.HasError)
                LogService.ErrorLog(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

            if (RetVal != null)
                return RetVal.ToString();
            else
                return string.Empty;
        }

        /// <summary>
        /// 그룹여부, 
        /// </summary>
        /// <param name="OrderCode"></param>
        /// <param name="Date"></param>
        /// <param name="GRP_YN"></param>
        /// <param name="CHNG_PSBL_YN"></param>
        /// <returns></returns>
        public static bool GET_BIMFCDMA_GRP_YN_PYDV_CHNG_PSBL_YN(string OrderCode, string Date, ref string GRP_YN, ref string PYDV_CHNG_PSBL_YN)
        {
            try
            {
                GRP_YN = "S";
                PYDV_CHNG_PSBL_YN = string.Empty;
                DataTable RetTable = new DataTable();

                if (!DBService.ExecuteDataTable(SQL.Sql.Get_BIMFCDMA_GRP_YN_PYDV_CHNG_PSBL_YN(), ref RetTable, OrderCode, Date))
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                if (RetTable == null || RetTable.Rows.Count < 1) return false;

                GRP_YN = RetTable.Rows[0]["GRP_YN"].ToString();
                PYDV_CHNG_PSBL_YN = RetTable.Rows[0]["PYDV_CHNG_PSBL_YN"].ToString();

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
        }

        /// <summary>
        /// 확인코드명을 가져온다
        /// </summary>
        /// <param name="CLAM_CNFR_CD"></param>
        /// <param name="DATE"></param>
        /// <returns></returns>
        public static string GET_CLAM_CNFR_CD_NAME(string CLAM_CNFR_CD, string DATE)
        {
            object RetVal = null;
            RetVal = DBService.ExecuteScalar(SQL.Sql.GET_CLAM_CNFR_CD_NAME(), CLAM_CNFR_CD, DATE);
            if (DBService.HasError)
                LogService.ErrorLog(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

            if (RetVal != null)
                return RetVal.ToString();
            else
                return string.Empty;
        }

        /// <summary>
        /// 기초코드 정보를 가져온다
        /// </summary>
        /// <param name="OVRL_CD"></param>
        /// <param name="LWRN_OVRL_CD"></param>
        /// <param name="APLY_DD"></param>
        /// <param name="READ_COLUMN"></param>
        /// <returns></returns>
        public static string GET_FN_BI_READ_BICDINDT(string OVRL_CD, string LWRN_OVRL_CD, string APLY_DD, string READ_COLUMN)
        {
            object RetVal = null;

            RetVal = DBService.ExecuteScalar(SQL.Sql.FN_BI_READ_BICDINDT(), OVRL_CD, LWRN_OVRL_CD, APLY_DD, READ_COLUMN);
            if (DBService.HasError)
                LogService.ErrorLog(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

            if (RetVal != null)
                return RetVal.ToString();
            else
                return string.Empty;
        }

        /// <summary>
        /// 산정특례(중증) 적용 대상자의 중증대상기간을 체크한다.
        /// </summary>
        /// <param name="PID"></param>
        /// <param name="DATE"></param>
        /// <param name="ReturnMessage"></param>
        /// <returns></returns>
        public static bool Check_PAPSDSMA_Date(string PID, string StartDate, string EndDate, string ASST_TYCD, ref string APLY_DD, ref string VALD_DD, ref string SEVR_NO, ref string ReturnMessage)
        {
            try
            {
                DataTable RetTable = new DataTable();

                APLY_DD = string.Empty;
                VALD_DD = string.Empty;
                SEVR_NO = string.Empty;
                ReturnMessage = string.Empty;

                switch (ASST_TYCD)
                {
                    case "H":
                    case "H0":
                        if (!DBService.ExecuteDataTable(SQL.Sql.Check_PAPSDSMA_Date_H_H0(), ref RetTable, PID, StartDate, EndDate))
                            throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                        if (RetTable == null || RetTable.Rows.Count < 1)
                        {
                            ReturnMessage = "적용가능 희귀난치(산정특례) 등록정보가 존재하지 않습니다.";
                            return false;
                        }
                        else
                        {
                            APLY_DD = RetTable.Rows[0]["APLY_DD"].ToString();
                            VALD_DD = RetTable.Rows[0]["VALD_DD"].ToString();
                            SEVR_NO = RetTable.Rows[0]["SEVR_NO"].ToString();
                            ReturnMessage = string.Format("적용가능 희귀난치(산정특례) 등록정보는\r\n{0} 부터 {1} 까지 [중증번호 : {2}] 입니다.", APLY_DD.Insert(4, "-").Insert(7, "-")
                                                                                                                                            , VALD_DD.Insert(4, "-").Insert(7, "-")
                                                                                                                                            , SEVR_NO);
                        }
                        break;
                    case "HV":
                        if (!DBService.ExecuteDataTable(SQL.Sql.Check_PAPSDSMA_Date_HV(), ref RetTable, PID, StartDate, EndDate))
                            throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                        if (RetTable == null || RetTable.Rows.Count < 1)
                        {
                            ReturnMessage = "적용가능 심장/뇌혈관질환 등록정보가 존재하지 않습니다.";
                            return false;
                        }
                        else
                        {
                            APLY_DD = RetTable.Rows[0]["APLY_DD"].ToString();
                            VALD_DD = RetTable.Rows[0]["VALD_DD"].ToString();
                            SEVR_NO = RetTable.Rows[0]["SEVR_NO"].ToString();
                            ReturnMessage = string.Format("적용가능 심장/뇌혈관질환 등록정보는\r\n{0} 부터 {1} 까지 [중증번호 : {2}] 입니다.", APLY_DD.Insert(4, "-").Insert(7, "-")
                                                                                                                                         , VALD_DD.Insert(4, "-").Insert(7, "-")
                                                                                                                                         , SEVR_NO);
                        }
                        break;
                    case "V1":
                        if (!DBService.ExecuteDataTable(SQL.Sql.Check_PAPSDSMA_Date_V1(), ref RetTable, PID, StartDate, EndDate))
                            throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                        if (RetTable == null || RetTable.Rows.Count < 1)
                        {
                            ReturnMessage = "적용가능 희귀난치(산정특례) 등록정보가 존재하지 않습니다.";
                            return false;
                        }
                        else
                        {
                            APLY_DD = RetTable.Rows[0]["APLY_DD"].ToString();
                            VALD_DD = RetTable.Rows[0]["VALD_DD"].ToString();
                            SEVR_NO = RetTable.Rows[0]["SEVR_NO"].ToString();
                            ReturnMessage = string.Format("적용가능 희귀난치(산정특례) 등록정보는\r\n{0} 부터 {1} 까지 [중증번호 : {2}] 입니다.", APLY_DD.Insert(4, "-").Insert(7, "-")
                                                                                                                                            , VALD_DD.Insert(4, "-").Insert(7, "-")
                                                                                                                                            , SEVR_NO);
                        }
                        break;
                    case "V2":
                    case "E2":
                    case "F2":
                    case "FV":
                        if (!DBService.ExecuteDataTable(SQL.Sql.Check_PAPSDSMA_Date_V2_E2_F2_FV(), ref RetTable, PID, StartDate, EndDate))
                            throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                        if (RetTable == null || RetTable.Rows.Count < 1)
                        {
                            ReturnMessage = "적용가능 암중증 등록정보가 존재하지 않습니다.";
                            return false;
                        }
                        else
                        {
                            APLY_DD = RetTable.Rows[0]["APLY_DD"].ToString();
                            VALD_DD = RetTable.Rows[0]["VALD_DD"].ToString();
                            SEVR_NO = RetTable.Rows[0]["SEVR_NO"].ToString();
                            ReturnMessage = string.Format("적용가능 암중증 등록정보는\r\n{0} 부터 {1} 까지 [중증번호 : {2}] 입니다.", APLY_DD.Insert(4, "-").Insert(7, "-")
                                                                                                                                 , VALD_DD.Insert(4, "-").Insert(7, "-")
                                                                                                                                 , SEVR_NO);
                        }
                        break;
                    case "V3":
                    case "E3":
                    case "F3":
                    case "FF":
                        if (!DBService.ExecuteDataTable(SQL.Sql.Check_PAPSDSMA_Date_V3_E3_F3_FF(), ref RetTable, PID, StartDate, EndDate))
                            throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                        if (RetTable == null || RetTable.Rows.Count < 1)
                        {
                            ReturnMessage = "적용가능 심장/뇌혈관질환 등록정보가 존재하지 않습니다.";
                            return false;
                        }
                        else
                        {
                            APLY_DD = RetTable.Rows[0]["APLY_DD"].ToString();
                            VALD_DD = RetTable.Rows[0]["VALD_DD"].ToString();
                            SEVR_NO = RetTable.Rows[0]["SEVR_NO"].ToString();
                            ReturnMessage = string.Format("적용가능 심장/뇌혈관질환 등록정보는\r\n{0} 부터 {1} 까지 [중증번호 : {2}] 입니다.", APLY_DD.Insert(4, "-").Insert(7, "-")
                                                                                                                                         , VALD_DD.Insert(4, "-").Insert(7, "-")
                                                                                                                                         , SEVR_NO);
                        }
                        break;
                    case "V4":
                    case "E4":
                    case "F4":
                        if (!DBService.ExecuteDataTable(SQL.Sql.Check_PAPSDSMA_Date_V4_E4_F4(), ref RetTable, PID, StartDate, EndDate))
                            throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                        if (RetTable == null || RetTable.Rows.Count < 1)
                        {
                            ReturnMessage = "적용가능 중증화상 등록정보가 존재하지 않습니다.";
                            return false;
                        }
                        else
                        {
                            APLY_DD = RetTable.Rows[0]["APLY_DD"].ToString();
                            VALD_DD = RetTable.Rows[0]["VALD_DD"].ToString();
                            SEVR_NO = RetTable.Rows[0]["SEVR_NO"].ToString();
                            ReturnMessage = string.Format("적용가능 중증화상 등록정보는\r\n{0} 부터 {1} 까지 [중증번호 : {2}] 입니다.", APLY_DD.Insert(4, "-").Insert(7, "-")
                                                                                                                                   , VALD_DD.Insert(4, "-").Insert(7, "-")
                                                                                                                                   , SEVR_NO);
                        }
                        break;
                    case "VH":
                        if (!DBService.ExecuteDataTable(SQL.Sql.Check_PAPSDSMA_Date_VH(), ref RetTable, PID, StartDate, EndDate))
                            throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                        if (RetTable == null || RetTable.Rows.Count < 1)
                        {
                            ReturnMessage = "적용가능 심장/뇌혈관질환 등록정보가 존재하지 않습니다.";
                            return false;
                        }
                        else
                        {
                            APLY_DD = RetTable.Rows[0]["APLY_DD"].ToString();
                            VALD_DD = RetTable.Rows[0]["VALD_DD"].ToString();
                            SEVR_NO = RetTable.Rows[0]["SEVR_NO"].ToString();
                            ReturnMessage = string.Format("적용가능 희귀난치(산정특례) 등록정보는\r\n{0} 부터 {1} 까지 [중증번호 : {2}] 입니다.", APLY_DD.Insert(4, "-").Insert(7, "-")
                                                                                                                                            , VALD_DD.Insert(4, "-").Insert(7, "-")
                                                                                                                                            , SEVR_NO);
                        }
                        break;
                    case "E1":
                    case "F1":
                        if (!DBService.ExecuteDataTable(SQL.Sql.Check_PAPSDSMA_Date_E1_F1(), ref RetTable, PID, StartDate, EndDate))
                            throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                        if (RetTable == null || RetTable.Rows.Count < 1)
                        {
                            ReturnMessage = "적용가능 심장/뇌혈관질환 등록정보가 존재하지 않습니다.";
                            return false;
                        }
                        else
                        {
                            APLY_DD = RetTable.Rows[0]["APLY_DD"].ToString();
                            VALD_DD = RetTable.Rows[0]["VALD_DD"].ToString();
                            SEVR_NO = RetTable.Rows[0]["SEVR_NO"].ToString();
                            ReturnMessage = string.Format("적용가능 희귀난치(산정특례) 등록정보는\r\n{0} 부터 {1} 까지 [중증번호 : {2}] 입니다.", APLY_DD.Insert(4, "-").Insert(7, "-")
                                                                                                                                            , VALD_DD.Insert(4, "-").Insert(7, "-")
                                                                                                                                            , SEVR_NO);
                        }
                        break;

                    default:
                        break;
                }

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
        }

        /// <summary>
        /// 선별급여 콤보데이터를 가져온다
        /// </summary>
        /// <param name="Date"></param>
        /// <returns></returns>
        public static DataTable Get_SCNG_PAY_ComboData(string Date)
        {
            DataTable RetTable = new DataTable();

            if (!DBService.ExecuteDataTable(SQL.Sql.Get_SCNG_PAY_ComboData(), ref RetTable, Date))
                throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

            return RetTable;
        }

        /// <summary>
        /// 예외사유코드
        /// </summary>
        /// <param name="SearchDate"></param>
        /// <returns></returns>
        public static DataTable GetBIEXCDMA(bool onlyME_Today)
        {
            DataTable dt = new DataTable();
            DBService.ExecuteDataTable(SQL.Sql.Get_BIEXCDMA(onlyME_Today), ref dt);
            return dt;
        }
        
        public static string Get_Clam_Uniq_No(string IV_OTPT_ADMS_DVCD, string IV_CLAM_DD, string IV_CLAM_DVCD, string IV_CLAM_TYPE_DVCD, string IV_WK_MM_UNIT_DVCD)
        {
            try
            {
                IV_OTPT_ADMS_DVCD = string.IsNullOrWhiteSpace(IV_OTPT_ADMS_DVCD) ? string.Empty : IV_OTPT_ADMS_DVCD;
                IV_CLAM_DD = string.IsNullOrWhiteSpace(IV_CLAM_DD) ? string.Empty : IV_CLAM_DD;
                IV_CLAM_DVCD = string.IsNullOrWhiteSpace(IV_CLAM_DVCD) ? string.Empty : IV_CLAM_DVCD;
                IV_CLAM_TYPE_DVCD = string.IsNullOrWhiteSpace(IV_CLAM_TYPE_DVCD) ? string.Empty : IV_CLAM_TYPE_DVCD;
                IV_WK_MM_UNIT_DVCD = string.IsNullOrWhiteSpace(IV_WK_MM_UNIT_DVCD) ? string.Empty : IV_WK_MM_UNIT_DVCD;

                object RetVal = null;
                RetVal = DBService.ExecuteScalar(Function.FN_CL_READ_CLAMUNIQNO(), IV_OTPT_ADMS_DVCD,
                                                                                   IV_CLAM_DD,
                                                                                   IV_CLAM_DVCD,
                                                                                   IV_CLAM_TYPE_DVCD,
                                                                                   IV_WK_MM_UNIT_DVCD);
                if (DBService.HasError)
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                if (RetVal != null)
                    return RetVal.ToString();
                else
                    return string.Empty;
            }
            catch (Exception ex)
            {
                Debug_WriteLine(ex.Message);
                return string.Empty;
            }
        }

        public static DataTable GetDoctorList(string OCTY_DVCD = "")
        {
            try
            {
                DataTable DoctorList = new DataTable();

                OCTY_DVCD = OCTY_DVCD.Equals("D") ? " AND A.OCTY_DVCD IN ( 'D0', 'D1', 'D2', 'D3', 'D9' )" : string.Empty;

                if (!DBService.ExecuteDataTable(string.Format(SQL.Sql.GetDoctorList(), OCTY_DVCD), ref DoctorList))
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                return DoctorList;
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                //LxMessage.ShowError(ex.Message + error);
                return null;
            }
        }

        #endregion

        #region Working
        /// <summary>
        /// 병원 종별 구분 1.종합전문 , 2.종합병원, 3.병원, 4.의원 -> 3.4는 분야별 청구 안함. 통합 청구함.
        /// </summary>
        /// <returns></returns>
        public static bool Claim_Type()
        {
            string BYKN_DVCD = DOPack.HospitalInfo.BYKN_DVCD;

            switch (BYKN_DVCD)
            {
                case "1":
                case "2":
                    return true;
                case "3":
                case "4":
                default:
                    return false;
            }
        }
        /// <summary>
        /// [ 변경일 산정 방법 ]
        /// - 해당 청구월에 수가 적용일이다.
        /// - 수가 적용일보다 이후에 처방이 되었다.
        /// - 청구 년월을 기준점으로 하지 않고 심사시에 처방시작일 기준으로 해당월에 수가 변경이 있으면 변경일을 넣는 것
        /// - 해당 명세서의 진료기간의 시작일자를 기준으로 해당 처방의 현재 수가 적용일이 진료기간의 시작일보다 이후에 있으면 모두 변경일 기재함
        ///   변경일을 수가 시작일로 하지 말고 처방일로 해야된다
        /// - 간호등급과 연관해서 산청 추가
        /// </summary>
        /// <param name="MEFE_CD"></param>
        /// <param name="PRSC_STRT_DD"></param>
        /// <param name="ls_sdate_inf"></param>
        /// <param name="EDI_CHNG_DD"></param>
        public static void F_EDI_CHANGE_DATE(string MEFE_CD, string PRSC_STRT_DD, string ls_sdate_inf, ref string EDI_CHNG_DD)
        {
            object RetVal = null;
            DataTable MefeInfo = new DataTable();

            EDI_CHNG_DD = string.Empty;

            if (!DBService.ExecuteDataTable(SQL.Sql.F_EDI_CHANGE_DATE_MefeInfo(), ref MefeInfo, MEFE_CD, PRSC_STRT_DD))
                throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

            string ls_sdate_bas = string.Empty;
            string ls_bohang_bas = string.Empty;
            string ls_bomook_bas = string.Empty;

            if (MefeInfo == null || MefeInfo.Rows.Count < 1)
            {
                EDI_CHNG_DD = "*";
            }
            else
            {
                ls_sdate_bas = MefeInfo.Rows[0]["APLY_STRT_DD"].ToString().Trim();
                ls_bohang_bas = MefeInfo.Rows[0]["HLNS_CLUS_DVCD"].ToString().Trim();
                ls_bomook_bas = MefeInfo.Rows[0]["HLNS_SBIT_DVCD"].ToString().Trim();

                if (string.IsNullOrWhiteSpace(ls_sdate_bas))
                {
                    EDI_CHNG_DD = "*";
                }
                else if (ls_sdate_bas.CompareTo(ls_sdate_inf) >= 0)
                {
                    EDI_CHNG_DD = PRSC_STRT_DD;
                }
                else
                {
                    EDI_CHNG_DD = "*";
                }
            }

            ls_bohang_bas = string.IsNullOrWhiteSpace(ls_bohang_bas) ? "*" : ls_bohang_bas;
            ls_bomook_bas = string.IsNullOrWhiteSpace(ls_bomook_bas) ? "*" : ls_bomook_bas;

            if (EDI_CHNG_DD.Equals("*") && ls_bohang_bas.Equals("02"))
            {
                //****************************************************************************************************
                // 현재
                //****************************************************************************************************
                string ls_sdate_hos = string.Empty;
                string NurseClass = string.Empty; // 간호관리등급
                string NurseClass_ICU = string.Empty; // 성인중환자실 간호관리등급
                string NurseClass_BabyICU = string.Empty; // 신생아중환자실 간호관리등급

                // 간호관리등급
                RetVal = null;
                RetVal = DBService.ExecuteScalar(SQL.Sql.Select_NurseManageClass_BICARAMA(), "NURSEDGR1", PRSC_STRT_DD, "A");
                if (DBService.HasError)
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                if (RetVal != null)
                    NurseClass = RetVal.ToString();

                // 성인중환자실 간호관리등급
                RetVal = null;
                RetVal = DBService.ExecuteScalar(SQL.Sql.Select_NurseManageClass_BICARAMA(), "NURAICUDGR", PRSC_STRT_DD, "A");
                if (DBService.HasError)
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                if (RetVal != null)
                    NurseClass_ICU = RetVal.ToString();

                // 신생아중환자실 간호관리등급
                RetVal = null;
                RetVal = DBService.ExecuteScalar(SQL.Sql.Select_NurseManageClass_BICARAMA(), "NURBICUDGR", PRSC_STRT_DD, "A");
                if (DBService.HasError)
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                if (RetVal != null)
                    NurseClass_BabyICU = RetVal.ToString();

                // 적용시작일자
                RetVal = null;
                RetVal = DBService.ExecuteScalar(SQL.Sql.Select_NurseManageClass_BICARAMA_Aply_Strt_dd(), "NURSEDGR2", PRSC_STRT_DD, "A");
                if (DBService.HasError)
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                if (RetVal != null)
                    ls_sdate_hos = RetVal.ToString();

                ls_sdate_hos = string.IsNullOrWhiteSpace(ls_sdate_hos) ? PRSC_STRT_DD : ls_sdate_hos;
                NurseClass = string.IsNullOrWhiteSpace(NurseClass) ? "*" : NurseClass;
                NurseClass_ICU = string.IsNullOrWhiteSpace(NurseClass_ICU) ? "*" : NurseClass_ICU;
                NurseClass_BabyICU = string.IsNullOrWhiteSpace(NurseClass_BabyICU) ? "*" : NurseClass_BabyICU;

                //****************************************************************************************************
                // 이전
                //****************************************************************************************************
                string NurseClass_Pre = string.Empty; // 간호관리등급
                string NurseClass_ICU_Pre = string.Empty; // 성인중환자실 간호관리등급
                string NurseClass_BabyICU_Pre = string.Empty; // 신생아중환자실 간호관리등급

                // 간호관리등급
                RetVal = null;
                RetVal = DBService.ExecuteScalar(SQL.Sql.Select_NurseManageClass_BICARAMA(), "NURSEDGR1", ls_sdate_hos, "A");
                if (DBService.HasError)
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                if (RetVal != null)
                    NurseClass_Pre = RetVal.ToString();

                // 성인중환자실 간호관리등급
                RetVal = null;
                RetVal = DBService.ExecuteScalar(SQL.Sql.Select_NurseManageClass_BICARAMA(), "NURAICUDGR", ls_sdate_hos, "A");
                if (DBService.HasError)
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                if (RetVal != null)
                    NurseClass_ICU_Pre = RetVal.ToString();

                // 신생아중환자실 간호관리등급
                RetVal = null;
                RetVal = DBService.ExecuteScalar(SQL.Sql.Select_NurseManageClass_BICARAMA(), "NURBICUDGR", ls_sdate_hos, "A");
                if (DBService.HasError)
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                if (RetVal != null)
                    NurseClass_BabyICU_Pre = RetVal.ToString();

                switch (ls_bomook_bas)
                {
                    case "01": // 일반, 내/소/정, 격리, 신생아
                    case "02": // 일반, 내/소/정, 격리, 신생아
                    case "04": // 일반, 내/소/정, 격리, 신생아
                    case "05": // 일반, 내/소/정, 격리, 신생아

                        if (NurseClass != NurseClass_Pre && ls_sdate_hos.CompareTo(ls_sdate_inf) >= 0)
                            EDI_CHNG_DD = PRSC_STRT_DD;
                        break;
                    case "03": // 집중 치료실
                        // 성인(소아)과 신생아 집중치료실을 구분해야한다. ( edicode로 구분함. 5번째 자리 '1'.신생아 )
                        if (MEFE_CD.Length >= 5 && MEFE_CD.Substring(4, 1).Equals("1"))
                        {
                            if (NurseClass_BabyICU != NurseClass_BabyICU_Pre && ls_sdate_hos.CompareTo(PRSC_STRT_DD) >= 0)
                                EDI_CHNG_DD = PRSC_STRT_DD;
                        }
                        else
                        {
                            if (NurseClass_ICU != NurseClass_ICU_Pre && ls_sdate_hos.CompareTo(PRSC_STRT_DD) >= 0)
                                EDI_CHNG_DD = PRSC_STRT_DD;
                        }
                        break;

                    default:
                        break;
                }
            }
        }
        public static void PID_Division(string PID, ref string PID1, ref string PID2)
        {
            try
            {
                PID1 = string.Empty;
                PID2 = string.Empty;
                PID1 = PID.Length >= 5 ? PID.Substring(0, 5) : PID;
                PID2 = PID.Length >= 9 ? PID.Substring(5, 4) : PID1;
            }
            catch
            {
                PID1 = string.Empty;
                PID2 = PID1;
            }
        }
        /// <summary>
        /// 선별급여
        /// </summary>
        /// <param name="MEFE_CD"></param>
        /// <param name="DATE"></param>
        /// <returns></returns>
        public static string Select_YN(string MEFE_CD, string DATE)
        {
            try
            {
                object RetVal = null;

                DATE = string.IsNullOrWhiteSpace(DATE) ? DateTime.Now.ToString("yyyyMMdd") : DATE;

                RetVal = DBService.ExecuteScalar(SQL.Sql.CL_CommonClass_Select_YN(), MEFE_CD, DATE);
                if (DBService.HasError)
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                if (RetVal != null)
                    return RetVal.ToString();
                return string.Empty;
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                //LxMessage.ShowError(ex.Message + error);
                return string.Empty;
            }
        }
        public static string Get_CD_DVCD(string MEFE_CD)
        {
            try
            {
                object RetVal = null;

                RetVal = DBService.ExecuteScalar(SQL.Sql.CL_CommonClass_Get_CD_DVCD(), MEFE_CD, DateTime.Now.ToString("yyyyMMdd"));
                if (DBService.HasError)
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                if (RetVal != null)
                    return RetVal.ToString();
                return string.Empty;
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                //LxMessage.ShowError(ex.Message + error);
                return string.Empty;
            }
        }
        public static string Get_ECOI_CD(string PID, string PT_CMHS_NO, string MDCR_DD)
        {
            try
            {
                object RetVal = null;

                //****************************************************************************************************
                // 입원변경정보 테이블(PAIPCHMA)에서 상해구분코드(ECOI_CD)를 가져온다
                //****************************************************************************************************
                RetVal = DBService.ExecuteScalar(SQL.Sql.Get_ECOI_CD(), PID, PT_CMHS_NO, MDCR_DD);
                if (DBService.HasError)
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                if (RetVal != null)
                    return RetVal.ToString();
                else
                    return string.Empty;
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
                return string.Empty;
            }
        }
        public static string Get_PAIPCHMA_Item(string PID, string PT_CMHS_NO, string Date, string column)
        {
            try
            {
                if (PID == null) PID = string.Empty;
                if (PT_CMHS_NO == null) PT_CMHS_NO = string.Empty;
                if (Date == null) Date = string.Empty;
                if (string.IsNullOrWhiteSpace(PID) || string.IsNullOrWhiteSpace(PT_CMHS_NO) || string.IsNullOrWhiteSpace(Date))
                    return string.Empty;

                object RetVal = null;
                RetVal = DBService.ExecuteScalar($@"SELECT {column}
                                                      FROM PAIPCHMA
                                                     WHERE PID        = '{PID}'
                                                       AND PT_CMHS_NO = {PT_CMHS_NO}
                                                       AND '{Date}'      BETWEEN APLY_STRT_DD AND APLY_END_DD
                                                       AND ROWNUM = 1 ").ToString();
                if (DBService.HasError)
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                if (RetVal != null)
                    return RetVal.ToString();

                return string.Empty;
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                return string.Empty;
            }
        }
        public static DataTable Get_SBIT_DVCD_ComboData(string OVRL_CD, string CLUS_DVCD)
        {
            try
            {
                if (CLUS_DVCD == null) CLUS_DVCD = string.Empty;

                DataTable RetTable = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.Sql.Get_SBIT_DVCD_ComboData(OVRL_CD, CLUS_DVCD), ref RetTable))
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                return RetTable;
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                //LxMessage.ShowError(ex.Message + error);
                return null;
            }
        }

        public static bool ucCLIPRSBD_CLILSPBD_Exist(string CLAM_UNIQ_NO, string PID, string CLAM_SQNO, string CLAM_PRSC_SQNO, ref Color CR)
        {
            try
            {
                int Exist = 0;

                object RetVal = DBService.ExecuteScalar(SQL.Sql.ucCLIPRSBD_CLILSPBD_Exist(), CLAM_UNIQ_NO, PID, CLAM_SQNO, CLAM_PRSC_SQNO);

                if (DBService.HasError)
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                if (RetVal != null)
                    int.TryParse(RetVal.ToString(), out Exist);

                if (Exist > 0)
                {
                    CR = Color.FromArgb(160, 255, 200);
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                //LxMessage.ShowError(ex.Message + error);
                return false;
            }
        }
        public static bool ucCLIPRSBD_CLILMEBD_Exist(string CLAM_UNIQ_NO, string PID, string CLAM_SQNO, string CLAM_PRSC_SQNO, ref Color CR)
        {
            try
            {
                int Exist = 0;

                object RetVal = DBService.ExecuteScalar(SQL.Sql.ucCLIPRSBD_CLILMEBD_Exist(), CLAM_UNIQ_NO, PID, CLAM_SQNO, CLAM_PRSC_SQNO);

                if (DBService.HasError)
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                if (RetVal != null)
                    int.TryParse(RetVal.ToString(), out Exist);

                if (Exist > 0)
                {
                    CR = Color.FromArgb(255, 255, 190);
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                //LxMessage.ShowError(ex.Message + error);
                return false;
            }
        }
        public static bool ucCLIPRSBD_CLDOCLBD_Exist(string CLAM_UNIQ_NO, string PID, string CLAM_SQNO, string CLAM_PRSC_SQNO, ref Color CR)
        {
            try
            {
                int Exist = 0;

                object RetVal = DBService.ExecuteScalar(SQL.Sql.ucCLIPRSBD_CLDOCLBD_Exist(), CLAM_UNIQ_NO, PID, CLAM_SQNO, CLAM_PRSC_SQNO);

                if (DBService.HasError)
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                if (RetVal != null)
                    int.TryParse(RetVal.ToString(), out Exist);

                if (Exist > 0)
                {
                    CR = Color.FromArgb(255, 150, 150);
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                //LxMessage.ShowError(ex.Message + error);
                return false;
            }
        }

        public static string GetSex(string PID)
        {
            var SEX = DBService.ExecuteScalar(SQL.Sql.GetSex(), PID);
            if (DBService.HasError)
                Debug_WriteLine(ErrorCaption("CL_CommonClass"), string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

            return SEX?.ToString()?.Trim() ?? string.Empty;
        }
        public static string Get_PT_NM(string PID)
        {
            StringBuilder lsSQL = new StringBuilder();
            lsSQL.Clear();
            lsSQL.AppendLine(" SELECT PT_NM       ");
            lsSQL.AppendLine("   FROM PAPATHIN    ");
            lsSQL.AppendLine("  WHERE PID = '{0}' ");

            var PT_NM = DBService.ExecuteScalar(lsSQL.ToString(), PID);
            if (DBService.HasError)
                Debug_WriteLine(ErrorCaption("CL_CommonClass"), string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

            return PT_NM?.ToString()?.Trim() ?? string.Empty;
        }

        public static bool Get_MAKE_CMPT_CD(string EDI_CD, string CMPT_CD, ref string Temp_EDI_CD_CMPT_CD)
        {
            object retVal = DBService.ExecuteScalar(Lime.SqlPack.Function.FN_CL_PRC_EDICODE(EDI_CD, CMPT_CD));
            if (DBService.HasError || retVal == null)
            {
                LxMessage.ShowError(string.Format("가산코드 적용에 실패하였습니다.\r\n   - 가산코드 : {0} \r\n   - EDI코드 : {1} ", CMPT_CD, EDI_CD));
                return false;
            }

            Temp_EDI_CD_CMPT_CD = retVal.ToString();
            return true;


            /*
            string one   = string.Empty;
            string two   = string.Empty;
            string three = string.Empty;

            string RetValue = string.Empty;

            if (EDI_CD.Length >= 5)
            {
                EDI_CD = StringService.PadRight(EDI_CD, 8, '0', true);

                if (EDI_CD.Substring(5, 1) != "0")
                    one = EDI_CD.Substring(5, 1);
                else if (CMPT_CD.Length > 0)
                    one = CMPT_CD.Substring(0, 1);

                if (EDI_CD.Substring(6, 1) != "0")
                    two = EDI_CD.Substring(6, 1);
                else if (CMPT_CD.Length > 1)
                    two = CMPT_CD.Substring(1, 1);

                if (EDI_CD.Substring(7, 1) != "0")
                    three = EDI_CD.Substring(7, 1);
                else if (CMPT_CD.Length > 2)
                    three = CMPT_CD.Substring(2, 1);
            }

            RetValue = one + two + three;
            return RetValue;
            */
        }
        #endregion

        #region Controls
        public static void ClearControls(Control control)
        {
            LxTextBox txt = new LxTextBox();
            LxComboBox cbo = new LxComboBox();
            LxMaskedEdit edi = new LxMaskedEdit();
            LxCheckBox chk = new LxCheckBox();
            LxDateTimeEditor dtp = new LxDateTimeEditor();

            foreach (Control ctl in control.Controls)
            {
                if (ctl.HasChildren)
                    ClearControls(ctl);

                if (ctl is LxTextBox)
                {
                    txt = ctl as LxTextBox;
                    txt.Text = string.Empty;
                }
                else if (ctl is LxComboBox)
                {
                    cbo = ctl as LxComboBox;
                    cbo.SelectedValue = string.Empty;
                }
                else if (ctl is LxMaskedEdit)
                {
                    edi = ctl as LxMaskedEdit;
                    edi.Text = string.Empty;
                }
                else if (ctl is LxCheckBox)
                {
                    chk = ctl as LxCheckBox;
                    chk.Checked = false;
                }
                else if (ctl is LxDateTimeEditor)
                {
                    dtp = ctl as LxDateTimeEditor;
                    dtp.DateTime = DateTime.Now;
                }
            }
        }
        public static void FindControls(Control control)
        {
            StringBuilder Text = new StringBuilder();
            Text.Clear();

            foreach (Control ctl in control.Controls)
            {
                if (ctl.HasChildren)
                    FindControls(ctl);

                Text.AppendLine(ctl.Name.PadRight(30, ' ') + ctl.Text);
            }

            //Debug_WriteLine(Text.ToString());
        }
        public static void FindControls_ReadOnly(Control control, bool onlyread)
        {
            LxTextBox txt = new LxTextBox();
            LxRichTextBox ric = new LxRichTextBox();
            LxMaskedEdit msk = new LxMaskedEdit();
            LxDateTimeEditor dtp = new LxDateTimeEditor();
            LxComboBox cbo = new LxComboBox();

            foreach (Control ctl in control.Controls)
            {
                if (ctl.HasChildren)
                    FindControls_ReadOnly(ctl, onlyread);

                if (ctl is LxTextBox)
                {
                    txt = ctl as LxTextBox;
                    txt.ReadOnly = onlyread;
                }
                else if (ctl is LxRichTextBox)
                {
                    ric = ctl as LxRichTextBox;
                    ric.ReadOnly = onlyread;
                }
                else if (ctl is LxMaskedEdit)
                {
                    msk = ctl as LxMaskedEdit;
                    msk.ReadOnly = onlyread;
                }
                else if (ctl is LxDateTimeEditor)
                {
                    dtp = ctl as LxDateTimeEditor;
                    dtp.ReadOnly = onlyread;
                }
                else if (ctl is LxComboBox)
                {
                    cbo = ctl as LxComboBox;
                    cbo.ReadOnly = onlyread;
                }
            }
        }
        #endregion

        #region Image
        public static byte[] GetSignIMegaBytes(string usercd)
        {
            System.IO.MemoryStream ms = new System.IO.MemoryStream();

            try
            {
                byte[] sign = new byte[0];
                DOSignInfo signinfo = new DOSignInfo(usercd);

                signinfo.SignImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);

            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return ms.ToArray();
        }
        #endregion

        public static Image MakeStringImage(object loData)
        {
            Font lFont = new Font("굴림", 8.5f, FontStyle.Bold);
            StringFormat lStringFormat = new StringFormat();
            SolidBrush lFontBrush = new SolidBrush(Color.White);
            SolidBrush lBackBrush = new SolidBrush(Color.FromArgb(200, 255, 131, 20));    // Color.FromArgb(238, 93, 0));  // Color.Orange);
            Pen lPen = new Pen(lFontBrush, 0.1f);

            lStringFormat.Alignment = StringAlignment.Center;
            lStringFormat.LineAlignment = StringAlignment.Center;
            lStringFormat.Trimming = StringTrimming.EllipsisCharacter;

            Bitmap lBMP = new Bitmap(100, 100); // new Bitmap(liWidth, liHeight);
            Graphics G = Graphics.FromImage(lBMP);
            SizeF sz = G.VisibleClipBounds.Size;
            RectangleF lRectF = new RectangleF(0, 0, lBMP.Width, lBMP.Height);

            G.Clear(Color.Transparent);
            G.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SingleBitPerPixelGridFit;

            // 원 그리기
            G.DrawEllipse(lPen, 0, 0, 14, 18);
            // 원 채우기
            G.FillEllipse(lBackBrush, lRectF);
            // 글자 그리기
            G.DrawString(loData.ToString().Trim(), lFont, lFontBrush, lRectF, lStringFormat);

            lFontBrush.Dispose();

            // 글자 회전
            lBMP.RotateFlip(RotateFlipType.RotateNoneFlipNone);

            return lBMP;
        }

        public static DataTable GetDataTable_POA_DVCD()
        {
            DataTable dt = new DataTable();

            if (!DBService.ExecuteDataTable(Lime.SqlPack.CL.Sql.SelectBICDINDT_POA_DVCD(), ref dt))
                throw new Exception("POA 마스터를 조회하는 중 에러가 발생했습니다.");

            return dt;
        }
    }
}