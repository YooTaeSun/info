namespace Lime.BusinessControls
{
    partial class ucPatientInfoModE
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.ValueListItem valueListItem1 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem2 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem3 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance23 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance24 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance25 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance26 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance27 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance28 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance29 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance30 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance31 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance32 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance33 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance34 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance35 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance36 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance37 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance38 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance39 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance40 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance41 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance42 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance43 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinEditors.EditorButton editorButton1 = new Infragistics.Win.UltraWinEditors.EditorButton();
            Infragistics.Win.Appearance appearance44 = new Infragistics.Win.Appearance();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucPatientInfoModE));
            Infragistics.Win.Appearance appearance45 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance46 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance47 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance48 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance49 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance50 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance51 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance52 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance53 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance54 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance55 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance56 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance57 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance58 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance59 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance60 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance61 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance62 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance63 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance64 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance65 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinEditors.EditorButton editorButton2 = new Infragistics.Win.UltraWinEditors.EditorButton();
            Infragistics.Win.Appearance appearance66 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance67 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance68 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance69 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinEditors.EditorButton editorButton3 = new Infragistics.Win.UltraWinEditors.EditorButton();
            Infragistics.Win.Appearance appearance70 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance71 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance72 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance73 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance74 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance75 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance76 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance77 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance78 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinEditors.EditorButton editorButton4 = new Infragistics.Win.UltraWinEditors.EditorButton();
            Infragistics.Win.Appearance appearance79 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance80 = new Infragistics.Win.Appearance();
            this.pnlTop = new Lime.Framework.Controls.LxPanel();
            this.lxButtonList1 = new Lime.Framework.Controls.LxButtonList();
            this.ttpPtInfo = new Lime.Framework.Controls.LxTitlePanel();
            this.LxTitleLabel24 = new Lime.Framework.Controls.LxTitleLabel();
            this.LxTitleLabel25 = new Lime.Framework.Controls.LxTitleLabel();
            this.LxTitleLabel4 = new Lime.Framework.Controls.LxTitleLabel();
            this.LxTitleLabel1 = new Lime.Framework.Controls.LxTitleLabel();
            this.mskDethDd = new Lime.Framework.Controls.LxMaskedEdit();
            this.LxTitleLabel7 = new Lime.Framework.Controls.LxTitleLabel();
            this.cboDethPlceDvcd = new Lime.Framework.Controls.LxComboBox();
            this.LxTitleLabel14 = new Lime.Framework.Controls.LxTitleLabel();
            this.chkSmsCnsnYn = new Lime.Framework.Controls.LxCheckBox();
            this.LxTitleLabel18 = new Lime.Framework.Controls.LxTitleLabel();
            this.chkDelYn = new Lime.Framework.Controls.LxCheckBox();
            this.LxTitleLabel21 = new Lime.Framework.Controls.LxTitleLabel();
            this.cboIndvInfoCnsnYn = new Lime.Framework.Controls.LxComboBox();
            this.LxTitleLabel8 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtDongAddr = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel15 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtDetlAddr = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel19 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtEmalAddr = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel10 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtFrnrNm = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel9 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtClphTel = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel16 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtPtNm = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel11 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtAge = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel17 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtSex = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel22 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtItdtEmnm = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel20 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtDobr = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel12 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtAddrBldgNo = new Lime.Framework.Controls.LxTextBox();
            this.txtNatnCd = new Lime.Framework.Controls.LxTextBox();
            this.txtItdtEmno = new Lime.Framework.Controls.LxTextBox();
            this.txtSrrn_SrrnEcpt = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel13 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtEtcTel1 = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel2 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtFrrn = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel3 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtNatnCdnm = new Lime.Framework.Controls.LxTextBox();
            this.lblNatnCd = new Lime.Framework.Controls.LxTitleLabel();
            this.txtAddrCd = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel5 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtHousTel = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel6 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtPtPclrMatr = new Lime.Framework.Controls.LxTextBox();
            this.txtPID = new Lime.Framework.Controls.LxTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).BeginInit();
            this.pnlBase.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pnlTop)).BeginInit();
            this.pnlTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxButtonList1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ttpPtInfo)).BeginInit();
            this.ttpPtInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mskDethDd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDethPlceDvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSmsCnsnYn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkDelYn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboIndvInfoCnsnYn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDongAddr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDetlAddr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEmalAddr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrnrNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtClphTel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPtNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAge)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtItdtEmnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDobr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddrBldgNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNatnCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtItdtEmno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSrrn_SrrnEcpt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEtcTel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrrn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNatnCdnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblNatnCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddrCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHousTel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPtPclrMatr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBase
            // 
            this.pnlBase.Controls.Add(this.ttpPtInfo);
            this.pnlBase.Location = new System.Drawing.Point(0, 38);
            this.pnlBase.Size = new System.Drawing.Size(909, 317);
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.Controls.Add(this.lxButtonList1);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Padding = new System.Windows.Forms.Padding(5);
            this.pnlTop.Size = new System.Drawing.Size(909, 38);
            this.pnlTop.TabIndex = 2;
            // 
            // lxButtonList1
            // 
            this.lxButtonList1.BackColor = System.Drawing.Color.White;
            this.lxButtonList1.ButtonItems.AddRange(new Lime.Framework.Controls.ButtonItem[] {
            new Lime.Framework.Controls.ButtonItem(Lime.Framework.Controls.ButtonType.Select, "코드로작성", "Select", System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50))))), System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), true)});
            this.lxButtonList1.Dock = System.Windows.Forms.DockStyle.Right;
            this.lxButtonList1.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.lxButtonList1.Location = new System.Drawing.Point(807, 5);
            this.lxButtonList1.MaximumSize = new System.Drawing.Size(1000, 28);
            this.lxButtonList1.Name = "lxButtonList1";
            this.lxButtonList1.Size = new System.Drawing.Size(97, 28);
            this.lxButtonList1.TabIndex = 9;
            // 
            // ttpPtInfo
            // 
            this.ttpPtInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.ttpPtInfo.BottomBarVisible = false;
            this.ttpPtInfo.BottomText = "";
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel24);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel25);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel4);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel1);
            this.ttpPtInfo.Controls.Add(this.mskDethDd);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel7);
            this.ttpPtInfo.Controls.Add(this.cboDethPlceDvcd);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel14);
            this.ttpPtInfo.Controls.Add(this.chkSmsCnsnYn);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel18);
            this.ttpPtInfo.Controls.Add(this.chkDelYn);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel21);
            this.ttpPtInfo.Controls.Add(this.cboIndvInfoCnsnYn);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel8);
            this.ttpPtInfo.Controls.Add(this.txtDongAddr);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel15);
            this.ttpPtInfo.Controls.Add(this.txtDetlAddr);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel19);
            this.ttpPtInfo.Controls.Add(this.txtEmalAddr);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel10);
            this.ttpPtInfo.Controls.Add(this.txtFrnrNm);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel9);
            this.ttpPtInfo.Controls.Add(this.txtClphTel);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel16);
            this.ttpPtInfo.Controls.Add(this.txtPtNm);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel11);
            this.ttpPtInfo.Controls.Add(this.txtAge);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel17);
            this.ttpPtInfo.Controls.Add(this.txtSex);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel22);
            this.ttpPtInfo.Controls.Add(this.txtItdtEmnm);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel20);
            this.ttpPtInfo.Controls.Add(this.txtDobr);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel12);
            this.ttpPtInfo.Controls.Add(this.txtAddrBldgNo);
            this.ttpPtInfo.Controls.Add(this.txtNatnCd);
            this.ttpPtInfo.Controls.Add(this.txtItdtEmno);
            this.ttpPtInfo.Controls.Add(this.txtSrrn_SrrnEcpt);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel13);
            this.ttpPtInfo.Controls.Add(this.txtEtcTel1);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel2);
            this.ttpPtInfo.Controls.Add(this.txtFrrn);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel3);
            this.ttpPtInfo.Controls.Add(this.txtNatnCdnm);
            this.ttpPtInfo.Controls.Add(this.lblNatnCd);
            this.ttpPtInfo.Controls.Add(this.txtAddrCd);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel5);
            this.ttpPtInfo.Controls.Add(this.txtHousTel);
            this.ttpPtInfo.Controls.Add(this.LxTitleLabel6);
            this.ttpPtInfo.Controls.Add(this.txtPtPclrMatr);
            this.ttpPtInfo.Controls.Add(this.txtPID);
            this.ttpPtInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ttpPtInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.ttpPtInfo.Location = new System.Drawing.Point(0, 0);
            this.ttpPtInfo.Name = "ttpPtInfo";
            this.ttpPtInfo.Padding = new System.Windows.Forms.Padding(3);
            this.ttpPtInfo.Size = new System.Drawing.Size(909, 317);
            this.ttpPtInfo.TabIndex = 8;
            this.ttpPtInfo.TitleText = "환자정보";
            // 
            // LxTitleLabel24
            // 
            appearance1.BackColor = System.Drawing.Color.Transparent;
            appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance1.FontData.Name = "맑은 고딕";
            appearance1.FontData.SizeInPoints = 9F;
            appearance1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance1.TextHAlignAsString = "Right";
            appearance1.TextVAlignAsString = "Middle";
            this.LxTitleLabel24.Appearance = appearance1;
            this.LxTitleLabel24.Location = new System.Drawing.Point(693, 247);
            this.LxTitleLabel24.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel24.Name = "LxTitleLabel24";
            this.LxTitleLabel24.Size = new System.Drawing.Size(79, 18);
            this.LxTitleLabel24.TabIndex = 6;
            this.LxTitleLabel24.Text = "소개직원번호";
            this.LxTitleLabel24.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel24.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.LxTitleLabel24.Visible = false;
            // 
            // LxTitleLabel25
            // 
            appearance2.BackColor = System.Drawing.Color.Transparent;
            appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance2.FontData.Name = "맑은 고딕";
            appearance2.FontData.SizeInPoints = 9F;
            appearance2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance2.TextHAlignAsString = "Right";
            appearance2.TextVAlignAsString = "Middle";
            this.LxTitleLabel25.Appearance = appearance2;
            this.LxTitleLabel25.Location = new System.Drawing.Point(546, 222);
            this.LxTitleLabel25.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel25.Name = "LxTitleLabel25";
            this.LxTitleLabel25.Size = new System.Drawing.Size(54, 18);
            this.LxTitleLabel25.TabIndex = 6;
            this.LxTitleLabel25.Text = "건물번호";
            this.LxTitleLabel25.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel25.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.LxTitleLabel25.Visible = false;
            // 
            // LxTitleLabel4
            // 
            appearance3.BackColor = System.Drawing.Color.Transparent;
            appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance3.FontData.Name = "맑은 고딕";
            appearance3.FontData.SizeInPoints = 9F;
            appearance3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance3.TextHAlignAsString = "Right";
            appearance3.TextVAlignAsString = "Middle";
            this.LxTitleLabel4.Appearance = appearance3;
            this.LxTitleLabel4.Location = new System.Drawing.Point(716, 222);
            this.LxTitleLabel4.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel4.Name = "LxTitleLabel4";
            this.LxTitleLabel4.Size = new System.Drawing.Size(54, 18);
            this.LxTitleLabel4.TabIndex = 6;
            this.LxTitleLabel4.Text = "국가코드";
            this.LxTitleLabel4.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel4.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.LxTitleLabel4.Visible = false;
            // 
            // LxTitleLabel1
            // 
            appearance4.BackColor = System.Drawing.Color.Transparent;
            appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance4.FontData.Name = "맑은 고딕";
            appearance4.FontData.SizeInPoints = 9F;
            appearance4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance4.TextHAlignAsString = "Right";
            appearance4.TextVAlignAsString = "Middle";
            this.LxTitleLabel1.Appearance = appearance4;
            this.LxTitleLabel1.Location = new System.Drawing.Point(7, 39);
            this.LxTitleLabel1.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel1.Name = "LxTitleLabel1";
            this.LxTitleLabel1.Size = new System.Drawing.Size(54, 23);
            this.LxTitleLabel1.TabIndex = 0;
            this.LxTitleLabel1.Text = "환자번호";
            this.LxTitleLabel1.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel1.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // mskDethDd
            // 
            appearance5.BackColor = System.Drawing.Color.White;
            appearance5.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance5.ForeColorDisabled = System.Drawing.Color.DarkGray;
            appearance5.TextHAlignAsString = "Center";
            this.mskDethDd.Appearance = appearance5;
            this.mskDethDd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.mskDethDd.EditAs = Infragistics.Win.UltraWinMaskedEdit.EditAsType.UseSpecifiedMask;
            this.mskDethDd.EnterKeyToTab = true;
            this.mskDethDd.InputMask = "####-##-##";
            this.mskDethDd.Location = new System.Drawing.Point(63, 167);
            this.mskDethDd.Name = "mskDethDd";
            this.mskDethDd.NonAutoSizeHeight = 23;
            this.mskDethDd.PromptChar = ' ';
            this.mskDethDd.Size = new System.Drawing.Size(110, 23);
            this.mskDethDd.TabIndex = 19;
            this.mskDethDd.Tag = "DETH_DD";
            this.mskDethDd.Text = "--";
            this.mskDethDd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.mskDethDd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel7
            // 
            appearance6.BackColor = System.Drawing.Color.Transparent;
            appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance6.FontData.Name = "맑은 고딕";
            appearance6.FontData.SizeInPoints = 9F;
            appearance6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance6.TextHAlignAsString = "Right";
            appearance6.TextVAlignAsString = "Middle";
            this.LxTitleLabel7.Appearance = appearance6;
            this.LxTitleLabel7.Location = new System.Drawing.Point(214, 39);
            this.LxTitleLabel7.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel7.Name = "LxTitleLabel7";
            this.LxTitleLabel7.Size = new System.Drawing.Size(42, 23);
            this.LxTitleLabel7.TabIndex = 0;
            this.LxTitleLabel7.Text = "환자명";
            this.LxTitleLabel7.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel7.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboDethPlceDvcd
            // 
            appearance7.BackColor = System.Drawing.Color.White;
            appearance7.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance7.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboDethPlceDvcd.Appearance = appearance7;
            this.cboDethPlceDvcd.BackColor = System.Drawing.Color.White;
            this.cboDethPlceDvcd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance8.BackColor = System.Drawing.Color.Transparent;
            appearance8.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance8.BorderColor = System.Drawing.Color.Transparent;
            appearance8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance8.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboDethPlceDvcd.ButtonAppearance = appearance8;
            this.cboDethPlceDvcd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboDethPlceDvcd.EnterKeyToTab = true;
            this.cboDethPlceDvcd.Location = new System.Drawing.Point(257, 169);
            this.cboDethPlceDvcd.Name = "cboDethPlceDvcd";
            appearance9.BackColor = System.Drawing.Color.White;
            appearance9.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance9.ForeColor = System.Drawing.Color.DarkGray;
            appearance9.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboDethPlceDvcd.NullTextAppearance = appearance9;
            this.cboDethPlceDvcd.SelectedValue = "";
            this.cboDethPlceDvcd.Size = new System.Drawing.Size(121, 21);
            this.cboDethPlceDvcd.TabIndex = 20;
            this.cboDethPlceDvcd.Tag = "DETH_PLCE_DVCD";
            this.cboDethPlceDvcd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboDethPlceDvcd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboDethPlceDvcd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel14
            // 
            appearance10.BackColor = System.Drawing.Color.Transparent;
            appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance10.FontData.Name = "맑은 고딕";
            appearance10.FontData.SizeInPoints = 9F;
            appearance10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance10.TextHAlignAsString = "Right";
            appearance10.TextVAlignAsString = "Middle";
            this.LxTitleLabel14.Appearance = appearance10;
            this.LxTitleLabel14.Location = new System.Drawing.Point(190, 71);
            this.LxTitleLabel14.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel14.Name = "LxTitleLabel14";
            this.LxTitleLabel14.Size = new System.Drawing.Size(66, 23);
            this.LxTitleLabel14.TabIndex = 0;
            this.LxTitleLabel14.Text = "휴대폰번호";
            this.LxTitleLabel14.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel14.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // chkSmsCnsnYn
            // 
            appearance11.BackColor = System.Drawing.Color.Transparent;
            appearance11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.chkSmsCnsnYn.Appearance = appearance11;
            this.chkSmsCnsnYn.AutoSize = true;
            this.chkSmsCnsnYn.BackColor = System.Drawing.Color.Transparent;
            this.chkSmsCnsnYn.BackColorInternal = System.Drawing.Color.Transparent;
            this.chkSmsCnsnYn.EnterKeyToTab = true;
            this.chkSmsCnsnYn.Location = new System.Drawing.Point(801, 80);
            this.chkSmsCnsnYn.Name = "chkSmsCnsnYn";
            this.chkSmsCnsnYn.Size = new System.Drawing.Size(14, 13);
            this.chkSmsCnsnYn.TabIndex = 11;
            this.chkSmsCnsnYn.Tag = "SMS_CNSN_YN";
            this.chkSmsCnsnYn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.chkSmsCnsnYn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel18
            // 
            appearance12.BackColor = System.Drawing.Color.Transparent;
            appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance12.FontData.Name = "맑은 고딕";
            appearance12.FontData.SizeInPoints = 9F;
            appearance12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance12.TextHAlignAsString = "Right";
            appearance12.TextVAlignAsString = "Middle";
            this.LxTitleLabel18.Appearance = appearance12;
            this.LxTitleLabel18.Location = new System.Drawing.Point(190, 135);
            this.LxTitleLabel18.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel18.Name = "LxTitleLabel18";
            this.LxTitleLabel18.Size = new System.Drawing.Size(66, 23);
            this.LxTitleLabel18.TabIndex = 0;
            this.LxTitleLabel18.Text = "외국인성명";
            this.LxTitleLabel18.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel18.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // chkDelYn
            // 
            appearance13.BackColor = System.Drawing.Color.Transparent;
            appearance13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.chkDelYn.Appearance = appearance13;
            this.chkDelYn.AutoSize = true;
            this.chkDelYn.BackColor = System.Drawing.Color.Transparent;
            this.chkDelYn.BackColorInternal = System.Drawing.Color.Transparent;
            this.chkDelYn.EnterKeyToTab = true;
            this.chkDelYn.Location = new System.Drawing.Point(443, 175);
            this.chkDelYn.Name = "chkDelYn";
            this.chkDelYn.Size = new System.Drawing.Size(14, 13);
            this.chkDelYn.TabIndex = 21;
            this.chkDelYn.Tag = "DEL_YN";
            this.chkDelYn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.chkDelYn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel21
            // 
            appearance14.BackColor = System.Drawing.Color.Transparent;
            appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance14.FontData.Name = "맑은 고딕";
            appearance14.FontData.SizeInPoints = 9F;
            appearance14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance14.TextHAlignAsString = "Right";
            appearance14.TextVAlignAsString = "Middle";
            this.LxTitleLabel21.Appearance = appearance14;
            this.LxTitleLabel21.Location = new System.Drawing.Point(202, 167);
            this.LxTitleLabel21.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel21.Name = "LxTitleLabel21";
            this.LxTitleLabel21.Size = new System.Drawing.Size(54, 23);
            this.LxTitleLabel21.TabIndex = 0;
            this.LxTitleLabel21.Text = "사망장소";
            this.LxTitleLabel21.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel21.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboIndvInfoCnsnYn
            // 
            appearance15.BackColor = System.Drawing.Color.White;
            appearance15.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance15.ForeColorDisabled = System.Drawing.Color.DarkGray;
            appearance15.TextHAlignAsString = "Center";
            this.cboIndvInfoCnsnYn.Appearance = appearance15;
            this.cboIndvInfoCnsnYn.BackColor = System.Drawing.Color.White;
            this.cboIndvInfoCnsnYn.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance16.BackColor = System.Drawing.Color.Transparent;
            appearance16.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance16.BorderColor = System.Drawing.Color.Transparent;
            appearance16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance16.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboIndvInfoCnsnYn.ButtonAppearance = appearance16;
            this.cboIndvInfoCnsnYn.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboIndvInfoCnsnYn.EnterKeyToTab = true;
            valueListItem1.DataValue = "Y";
            valueListItem1.DisplayText = "Yes";
            valueListItem2.DataValue = "N";
            valueListItem2.DisplayText = "No";
            valueListItem3.DataValue = "D";
            valueListItem3.DisplayText = "거부";
            this.cboIndvInfoCnsnYn.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem1,
            valueListItem2,
            valueListItem3});
            this.cboIndvInfoCnsnYn.Location = new System.Drawing.Point(676, 72);
            this.cboIndvInfoCnsnYn.Name = "cboIndvInfoCnsnYn";
            appearance17.BackColor = System.Drawing.Color.White;
            appearance17.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance17.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance17.ForeColor = System.Drawing.Color.DarkGray;
            appearance17.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboIndvInfoCnsnYn.NullTextAppearance = appearance17;
            this.cboIndvInfoCnsnYn.SelectedValue = "";
            this.cboIndvInfoCnsnYn.Size = new System.Drawing.Size(66, 21);
            this.cboIndvInfoCnsnYn.TabIndex = 10;
            this.cboIndvInfoCnsnYn.Tag = "INDV_INFO_CNSN_YN";
            this.cboIndvInfoCnsnYn.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboIndvInfoCnsnYn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboIndvInfoCnsnYn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel8
            // 
            appearance18.BackColor = System.Drawing.Color.Transparent;
            appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance18.FontData.Name = "맑은 고딕";
            appearance18.FontData.SizeInPoints = 9F;
            appearance18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance18.TextHAlignAsString = "Right";
            appearance18.TextVAlignAsString = "Middle";
            this.LxTitleLabel8.Appearance = appearance18;
            this.LxTitleLabel8.Location = new System.Drawing.Point(387, 39);
            this.LxTitleLabel8.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel8.Name = "LxTitleLabel8";
            this.LxTitleLabel8.Size = new System.Drawing.Size(54, 23);
            this.LxTitleLabel8.TabIndex = 0;
            this.LxTitleLabel8.Text = "주민번호";
            this.LxTitleLabel8.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel8.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtDongAddr
            // 
            appearance19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance19.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance19.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtDongAddr.Appearance = appearance19;
            this.txtDongAddr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtDongAddr.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtDongAddr.EnterKeyToTab = true;
            this.txtDongAddr.Location = new System.Drawing.Point(190, 103);
            this.txtDongAddr.Name = "txtDongAddr";
            appearance20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance20.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance20.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance20.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtDongAddr.NullTextAppearance = appearance20;
            this.txtDongAddr.ReadOnly = true;
            this.txtDongAddr.Size = new System.Drawing.Size(397, 23);
            this.txtDongAddr.TabIndex = 13;
            this.txtDongAddr.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtDongAddr.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel15
            // 
            appearance21.BackColor = System.Drawing.Color.Transparent;
            appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance21.FontData.Name = "맑은 고딕";
            appearance21.FontData.SizeInPoints = 9F;
            appearance21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance21.TextHAlignAsString = "Right";
            appearance21.TextVAlignAsString = "Middle";
            this.LxTitleLabel15.Appearance = appearance21;
            this.LxTitleLabel15.Location = new System.Drawing.Point(387, 71);
            this.LxTitleLabel15.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel15.Name = "LxTitleLabel15";
            this.LxTitleLabel15.Size = new System.Drawing.Size(54, 23);
            this.LxTitleLabel15.TabIndex = 0;
            this.LxTitleLabel15.Text = "기타전화";
            this.LxTitleLabel15.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel15.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtDetlAddr
            // 
            appearance22.BackColor = System.Drawing.Color.White;
            appearance22.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance22.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance22.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtDetlAddr.Appearance = appearance22;
            this.txtDetlAddr.BackColor = System.Drawing.Color.White;
            this.txtDetlAddr.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtDetlAddr.EnterKeyToTab = true;
            this.txtDetlAddr.ImeMode = System.Windows.Forms.ImeMode.Hangul;
            this.txtDetlAddr.Location = new System.Drawing.Point(596, 103);
            this.txtDetlAddr.MaxLength = 200;
            this.txtDetlAddr.Name = "txtDetlAddr";
            appearance23.BackColor = System.Drawing.Color.White;
            appearance23.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance23.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance23.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtDetlAddr.NullTextAppearance = appearance23;
            this.txtDetlAddr.Size = new System.Drawing.Size(307, 23);
            this.txtDetlAddr.TabIndex = 14;
            this.txtDetlAddr.Tag = "DETL_ADDR";
            this.txtDetlAddr.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtDetlAddr.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel19
            // 
            appearance24.BackColor = System.Drawing.Color.Transparent;
            appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance24.FontData.Name = "맑은 고딕";
            appearance24.FontData.SizeInPoints = 9F;
            appearance24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance24.TextHAlignAsString = "Right";
            appearance24.TextVAlignAsString = "Middle";
            this.LxTitleLabel19.Appearance = appearance24;
            this.LxTitleLabel19.Location = new System.Drawing.Point(399, 135);
            this.LxTitleLabel19.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel19.Name = "LxTitleLabel19";
            this.LxTitleLabel19.Size = new System.Drawing.Size(42, 23);
            this.LxTitleLabel19.TabIndex = 0;
            this.LxTitleLabel19.Text = "이메일";
            this.LxTitleLabel19.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel19.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtEmalAddr
            // 
            appearance25.BackColor = System.Drawing.Color.White;
            appearance25.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance25.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance25.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtEmalAddr.Appearance = appearance25;
            this.txtEmalAddr.BackColor = System.Drawing.Color.White;
            this.txtEmalAddr.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtEmalAddr.EnterKeyToTab = true;
            this.txtEmalAddr.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.txtEmalAddr.Location = new System.Drawing.Point(443, 135);
            this.txtEmalAddr.MaxLength = 50;
            this.txtEmalAddr.Name = "txtEmalAddr";
            appearance26.BackColor = System.Drawing.Color.White;
            appearance26.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance26.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance26.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtEmalAddr.NullTextAppearance = appearance26;
            this.txtEmalAddr.Size = new System.Drawing.Size(144, 23);
            this.txtEmalAddr.TabIndex = 17;
            this.txtEmalAddr.Tag = "EMAL_ADDR";
            this.txtEmalAddr.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtEmalAddr.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel10
            // 
            appearance27.BackColor = System.Drawing.Color.Transparent;
            appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance27.FontData.Name = "맑은 고딕";
            appearance27.FontData.SizeInPoints = 9F;
            appearance27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance27.TextHAlignAsString = "Right";
            appearance27.TextVAlignAsString = "Middle";
            this.LxTitleLabel10.Appearance = appearance27;
            this.LxTitleLabel10.Location = new System.Drawing.Point(509, 40);
            this.LxTitleLabel10.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel10.Name = "LxTitleLabel10";
            this.LxTitleLabel10.Size = new System.Drawing.Size(10, 18);
            this.LxTitleLabel10.TabIndex = 0;
            this.LxTitleLabel10.Text = "-";
            this.LxTitleLabel10.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel10.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtFrnrNm
            // 
            appearance28.BackColor = System.Drawing.Color.White;
            appearance28.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance28.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance28.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFrnrNm.Appearance = appearance28;
            this.txtFrnrNm.BackColor = System.Drawing.Color.White;
            this.txtFrnrNm.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtFrnrNm.EnterKeyToTab = true;
            this.txtFrnrNm.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.txtFrnrNm.Location = new System.Drawing.Point(257, 135);
            this.txtFrnrNm.MaxLength = 50;
            this.txtFrnrNm.Name = "txtFrnrNm";
            appearance29.BackColor = System.Drawing.Color.White;
            appearance29.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance29.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance29.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFrnrNm.NullTextAppearance = appearance29;
            this.txtFrnrNm.Size = new System.Drawing.Size(121, 23);
            this.txtFrnrNm.TabIndex = 16;
            this.txtFrnrNm.Tag = "FRNR_NM";
            this.txtFrnrNm.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtFrnrNm.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel9
            // 
            appearance30.BackColor = System.Drawing.Color.Transparent;
            appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance30.FontData.Name = "맑은 고딕";
            appearance30.FontData.SizeInPoints = 9F;
            appearance30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance30.TextHAlignAsString = "Right";
            appearance30.TextVAlignAsString = "Middle";
            this.LxTitleLabel9.Appearance = appearance30;
            this.LxTitleLabel9.Location = new System.Drawing.Point(621, 39);
            this.LxTitleLabel9.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel9.Name = "LxTitleLabel9";
            this.LxTitleLabel9.Size = new System.Drawing.Size(54, 23);
            this.LxTitleLabel9.TabIndex = 0;
            this.LxTitleLabel9.Text = "생년월일";
            this.LxTitleLabel9.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel9.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtClphTel
            // 
            appearance31.BackColor = System.Drawing.Color.White;
            appearance31.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance31.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance31.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance31.TextHAlignAsString = "Left";
            this.txtClphTel.Appearance = appearance31;
            this.txtClphTel.BackColor = System.Drawing.Color.White;
            this.txtClphTel.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtClphTel.EnterKeyToTab = true;
            this.txtClphTel.Location = new System.Drawing.Point(257, 71);
            this.txtClphTel.MaxLength = 15;
            this.txtClphTel.Name = "txtClphTel";
            appearance32.BackColor = System.Drawing.Color.White;
            appearance32.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance32.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance32.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtClphTel.NullTextAppearance = appearance32;
            this.txtClphTel.Size = new System.Drawing.Size(121, 23);
            this.txtClphTel.TabIndex = 8;
            this.txtClphTel.Tag = "CLPH_TEL";
            this.txtClphTel.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtClphTel.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel16
            // 
            appearance33.BackColor = System.Drawing.Color.Transparent;
            appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance33.FontData.Name = "맑은 고딕";
            appearance33.FontData.SizeInPoints = 9F;
            appearance33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance33.TextHAlignAsString = "Right";
            appearance33.TextVAlignAsString = "Middle";
            this.LxTitleLabel16.Appearance = appearance33;
            this.LxTitleLabel16.Location = new System.Drawing.Point(596, 71);
            this.LxTitleLabel16.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel16.Name = "LxTitleLabel16";
            this.LxTitleLabel16.Size = new System.Drawing.Size(79, 23);
            this.LxTitleLabel16.TabIndex = 0;
            this.LxTitleLabel16.Text = "개인정보수집";
            this.LxTitleLabel16.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel16.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtPtNm
            // 
            appearance34.BackColor = System.Drawing.Color.White;
            appearance34.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance34.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance34.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtPtNm.Appearance = appearance34;
            this.txtPtNm.BackColor = System.Drawing.Color.White;
            this.txtPtNm.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtPtNm.EnterKeyToTab = true;
            this.txtPtNm.ImeMode = System.Windows.Forms.ImeMode.Hangul;
            this.txtPtNm.Location = new System.Drawing.Point(257, 39);
            this.txtPtNm.MaxLength = 50;
            this.txtPtNm.Name = "txtPtNm";
            appearance35.BackColor = System.Drawing.Color.White;
            appearance35.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance35.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance35.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtPtNm.NullTextAppearance = appearance35;
            this.txtPtNm.Size = new System.Drawing.Size(121, 23);
            this.txtPtNm.TabIndex = 1;
            this.txtPtNm.Tag = "PT_NM";
            this.txtPtNm.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtPtNm.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel11
            // 
            appearance36.BackColor = System.Drawing.Color.Transparent;
            appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance36.FontData.Name = "맑은 고딕";
            appearance36.FontData.SizeInPoints = 9F;
            appearance36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance36.TextHAlignAsString = "Right";
            appearance36.TextVAlignAsString = "Middle";
            this.LxTitleLabel11.Appearance = appearance36;
            this.LxTitleLabel11.Location = new System.Drawing.Point(745, 39);
            this.LxTitleLabel11.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel11.Name = "LxTitleLabel11";
            this.LxTitleLabel11.Size = new System.Drawing.Size(29, 23);
            this.LxTitleLabel11.TabIndex = 0;
            this.LxTitleLabel11.Text = "성별";
            this.LxTitleLabel11.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel11.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtAge
            // 
            appearance37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance37.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance37.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance37.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance37.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance37.TextHAlignAsString = "Center";
            this.txtAge.Appearance = appearance37;
            this.txtAge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtAge.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtAge.EnterKeyToTab = true;
            this.txtAge.Location = new System.Drawing.Point(850, 39);
            this.txtAge.MaxLength = 3;
            this.txtAge.Name = "txtAge";
            appearance38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance38.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance38.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance38.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtAge.NullTextAppearance = appearance38;
            this.txtAge.ReadOnly = true;
            this.txtAge.Size = new System.Drawing.Size(33, 23);
            this.txtAge.TabIndex = 6;
            this.txtAge.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtAge.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel17
            // 
            appearance39.BackColor = System.Drawing.Color.Transparent;
            appearance39.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance39.FontData.Name = "맑은 고딕";
            appearance39.FontData.SizeInPoints = 9F;
            appearance39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance39.TextHAlignAsString = "Right";
            appearance39.TextVAlignAsString = "Middle";
            this.LxTitleLabel17.Appearance = appearance39;
            this.LxTitleLabel17.Location = new System.Drawing.Point(745, 71);
            this.LxTitleLabel17.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel17.Name = "LxTitleLabel17";
            this.LxTitleLabel17.Size = new System.Drawing.Size(54, 23);
            this.LxTitleLabel17.TabIndex = 0;
            this.LxTitleLabel17.Text = "SMS동의";
            this.LxTitleLabel17.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel17.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtSex
            // 
            appearance40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance40.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance40.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance40.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance40.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance40.TextHAlignAsString = "Center";
            this.txtSex.Appearance = appearance40;
            this.txtSex.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtSex.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtSex.EnterKeyToTab = true;
            this.txtSex.Location = new System.Drawing.Point(776, 39);
            this.txtSex.MaxLength = 2;
            this.txtSex.Name = "txtSex";
            appearance41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance41.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance41.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance41.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtSex.NullTextAppearance = appearance41;
            this.txtSex.ReadOnly = true;
            this.txtSex.Size = new System.Drawing.Size(39, 23);
            this.txtSex.TabIndex = 5;
            this.txtSex.Tag = "SEX_DVCD";
            this.txtSex.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtSex.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel22
            // 
            appearance42.BackColor = System.Drawing.Color.Transparent;
            appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance42.FontData.Name = "맑은 고딕";
            appearance42.FontData.SizeInPoints = 9F;
            appearance42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance42.TextHAlignAsString = "Right";
            appearance42.TextVAlignAsString = "Middle";
            this.LxTitleLabel22.Appearance = appearance42;
            this.LxTitleLabel22.Location = new System.Drawing.Point(387, 167);
            this.LxTitleLabel22.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel22.Name = "LxTitleLabel22";
            this.LxTitleLabel22.Size = new System.Drawing.Size(54, 23);
            this.LxTitleLabel22.TabIndex = 0;
            this.LxTitleLabel22.Text = "삭제여부";
            this.LxTitleLabel22.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel22.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtItdtEmnm
            // 
            appearance43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance43.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance43.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance43.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance43.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance43.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtItdtEmnm.Appearance = appearance43;
            this.txtItdtEmnm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtItdtEmnm.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance44.BackColor = System.Drawing.Color.Transparent;
            appearance44.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance44.BorderColor = System.Drawing.Color.Transparent;
            appearance44.BorderColor2 = System.Drawing.Color.Transparent;
            appearance44.Image = ((object)(resources.GetObject("appearance44.Image")));
            appearance44.ImageHAlign = Infragistics.Win.HAlign.Right;
            appearance44.ImageVAlign = Infragistics.Win.VAlign.Middle;
            editorButton1.Appearance = appearance44;
            editorButton1.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Button;
            editorButton1.Width = 18;
            this.txtItdtEmnm.ButtonsRight.Add(editorButton1);
            this.txtItdtEmnm.Location = new System.Drawing.Point(676, 135);
            this.txtItdtEmnm.Name = "txtItdtEmnm";
            appearance45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance45.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance45.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance45.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance45.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance45.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtItdtEmnm.NullTextAppearance = appearance45;
            this.txtItdtEmnm.ReadOnly = true;
            this.txtItdtEmnm.Size = new System.Drawing.Size(139, 23);
            this.txtItdtEmnm.TabIndex = 18;
            this.txtItdtEmnm.Tag = "ITDT_EMNM";
            this.txtItdtEmnm.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtItdtEmnm.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel20
            // 
            appearance46.BackColor = System.Drawing.Color.Transparent;
            appearance46.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance46.FontData.Name = "맑은 고딕";
            appearance46.FontData.SizeInPoints = 9F;
            appearance46.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance46.TextHAlignAsString = "Right";
            appearance46.TextVAlignAsString = "Middle";
            this.LxTitleLabel20.Appearance = appearance46;
            this.LxTitleLabel20.Location = new System.Drawing.Point(596, 135);
            this.LxTitleLabel20.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel20.Name = "LxTitleLabel20";
            this.LxTitleLabel20.Size = new System.Drawing.Size(79, 23);
            this.LxTitleLabel20.TabIndex = 0;
            this.LxTitleLabel20.Text = "소개직원번호";
            this.LxTitleLabel20.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel20.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtDobr
            // 
            appearance47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance47.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance47.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance47.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance47.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance47.TextHAlignAsString = "Center";
            this.txtDobr.Appearance = appearance47;
            this.txtDobr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtDobr.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtDobr.EnterKeyToTab = true;
            this.txtDobr.Location = new System.Drawing.Point(676, 39);
            this.txtDobr.MaxLength = 8;
            this.txtDobr.Name = "txtDobr";
            appearance48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance48.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance48.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance48.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance48.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance48.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtDobr.NullTextAppearance = appearance48;
            this.txtDobr.ReadOnly = true;
            this.txtDobr.Size = new System.Drawing.Size(66, 23);
            this.txtDobr.TabIndex = 4;
            this.txtDobr.Tag = "DOBR";
            this.txtDobr.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtDobr.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel12
            // 
            appearance49.BackColor = System.Drawing.Color.Transparent;
            appearance49.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance49.FontData.Name = "맑은 고딕";
            appearance49.FontData.SizeInPoints = 9F;
            appearance49.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance49.TextHAlignAsString = "Right";
            appearance49.TextVAlignAsString = "Middle";
            this.LxTitleLabel12.Appearance = appearance49;
            this.LxTitleLabel12.Location = new System.Drawing.Point(819, 39);
            this.LxTitleLabel12.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel12.Name = "LxTitleLabel12";
            this.LxTitleLabel12.Size = new System.Drawing.Size(29, 23);
            this.LxTitleLabel12.TabIndex = 0;
            this.LxTitleLabel12.Text = "연령";
            this.LxTitleLabel12.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel12.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtAddrBldgNo
            // 
            appearance50.BackColor = System.Drawing.Color.White;
            appearance50.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance50.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance50.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance50.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance50.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance50.TextHAlignAsString = "Center";
            this.txtAddrBldgNo.Appearance = appearance50;
            this.txtAddrBldgNo.BackColor = System.Drawing.Color.White;
            this.txtAddrBldgNo.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtAddrBldgNo.Location = new System.Drawing.Point(603, 218);
            this.txtAddrBldgNo.Name = "txtAddrBldgNo";
            appearance51.BackColor = System.Drawing.Color.White;
            appearance51.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance51.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance51.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance51.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtAddrBldgNo.NullTextAppearance = appearance51;
            this.txtAddrBldgNo.Size = new System.Drawing.Size(107, 23);
            this.txtAddrBldgNo.TabIndex = 1;
            this.txtAddrBldgNo.TabStop = false;
            this.txtAddrBldgNo.Tag = "ADDR_BLDG_NO";
            this.txtAddrBldgNo.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtAddrBldgNo.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.txtAddrBldgNo.Visible = false;
            // 
            // txtNatnCd
            // 
            appearance52.BackColor = System.Drawing.Color.White;
            appearance52.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance52.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance52.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance52.TextHAlignAsString = "Center";
            this.txtNatnCd.Appearance = appearance52;
            this.txtNatnCd.BackColor = System.Drawing.Color.White;
            this.txtNatnCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtNatnCd.Location = new System.Drawing.Point(776, 218);
            this.txtNatnCd.Name = "txtNatnCd";
            appearance53.BackColor = System.Drawing.Color.White;
            appearance53.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance53.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance53.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance53.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtNatnCd.NullTextAppearance = appearance53;
            this.txtNatnCd.Size = new System.Drawing.Size(107, 23);
            this.txtNatnCd.TabIndex = 1;
            this.txtNatnCd.TabStop = false;
            this.txtNatnCd.Tag = "NATN_CD";
            this.txtNatnCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtNatnCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.txtNatnCd.Visible = false;
            // 
            // txtItdtEmno
            // 
            appearance54.BackColor = System.Drawing.Color.White;
            appearance54.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance54.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance54.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance54.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance54.TextHAlignAsString = "Center";
            this.txtItdtEmno.Appearance = appearance54;
            this.txtItdtEmno.BackColor = System.Drawing.Color.White;
            this.txtItdtEmno.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtItdtEmno.Location = new System.Drawing.Point(776, 245);
            this.txtItdtEmno.Name = "txtItdtEmno";
            appearance55.BackColor = System.Drawing.Color.White;
            appearance55.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance55.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance55.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance55.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtItdtEmno.NullTextAppearance = appearance55;
            this.txtItdtEmno.Size = new System.Drawing.Size(107, 23);
            this.txtItdtEmno.TabIndex = 1;
            this.txtItdtEmno.TabStop = false;
            this.txtItdtEmno.Tag = "ITDT_EMNO";
            this.txtItdtEmno.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtItdtEmno.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.txtItdtEmno.Visible = false;
            // 
            // txtSrrn_SrrnEcpt
            // 
            appearance56.BackColor = System.Drawing.Color.White;
            appearance56.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance56.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance56.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance56.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance56.TextHAlignAsString = "Center";
            this.txtSrrn_SrrnEcpt.Appearance = appearance56;
            this.txtSrrn_SrrnEcpt.BackColor = System.Drawing.Color.White;
            this.txtSrrn_SrrnEcpt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtSrrn_SrrnEcpt.EnterKeyToTab = true;
            this.txtSrrn_SrrnEcpt.Location = new System.Drawing.Point(520, 39);
            this.txtSrrn_SrrnEcpt.MaxLength = 7;
            this.txtSrrn_SrrnEcpt.Name = "txtSrrn_SrrnEcpt";
            appearance57.BackColor = System.Drawing.Color.White;
            appearance57.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance57.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance57.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance57.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtSrrn_SrrnEcpt.NullTextAppearance = appearance57;
            this.txtSrrn_SrrnEcpt.Size = new System.Drawing.Size(66, 23);
            this.txtSrrn_SrrnEcpt.TabIndex = 3;
            this.txtSrrn_SrrnEcpt.Tag = "txtSrrn_SrrnEcpt";
            this.txtSrrn_SrrnEcpt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtSrrn_SrrnEcpt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel13
            // 
            appearance58.BackColor = System.Drawing.Color.Transparent;
            appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance58.FontData.Name = "맑은 고딕";
            appearance58.FontData.SizeInPoints = 9F;
            appearance58.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance58.TextHAlignAsString = "Right";
            appearance58.TextVAlignAsString = "Middle";
            this.LxTitleLabel13.Appearance = appearance58;
            this.LxTitleLabel13.Location = new System.Drawing.Point(886, 39);
            this.LxTitleLabel13.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel13.Name = "LxTitleLabel13";
            this.LxTitleLabel13.Size = new System.Drawing.Size(17, 23);
            this.LxTitleLabel13.TabIndex = 0;
            this.LxTitleLabel13.Text = "세";
            this.LxTitleLabel13.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel13.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtEtcTel1
            // 
            appearance59.BackColor = System.Drawing.Color.White;
            appearance59.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance59.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance59.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance59.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance59.TextHAlignAsString = "Left";
            this.txtEtcTel1.Appearance = appearance59;
            this.txtEtcTel1.BackColor = System.Drawing.Color.White;
            this.txtEtcTel1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtEtcTel1.EnterKeyToTab = true;
            this.txtEtcTel1.Location = new System.Drawing.Point(442, 71);
            this.txtEtcTel1.MaxLength = 15;
            this.txtEtcTel1.Name = "txtEtcTel1";
            appearance60.BackColor = System.Drawing.Color.White;
            appearance60.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance60.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance60.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance60.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtEtcTel1.NullTextAppearance = appearance60;
            this.txtEtcTel1.Size = new System.Drawing.Size(144, 23);
            this.txtEtcTel1.TabIndex = 9;
            this.txtEtcTel1.Tag = "ETC_TEL_1";
            this.txtEtcTel1.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtEtcTel1.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel2
            // 
            appearance61.BackColor = System.Drawing.Color.Transparent;
            appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance61.FontData.Name = "맑은 고딕";
            appearance61.FontData.SizeInPoints = 9F;
            appearance61.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance61.TextHAlignAsString = "Right";
            appearance61.TextVAlignAsString = "Middle";
            this.LxTitleLabel2.Appearance = appearance61;
            this.LxTitleLabel2.Location = new System.Drawing.Point(7, 71);
            this.LxTitleLabel2.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel2.Name = "LxTitleLabel2";
            this.LxTitleLabel2.Size = new System.Drawing.Size(54, 23);
            this.LxTitleLabel2.TabIndex = 0;
            this.LxTitleLabel2.Text = "전화번호";
            this.LxTitleLabel2.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel2.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtFrrn
            // 
            appearance62.BackColor = System.Drawing.Color.White;
            appearance62.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance62.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance62.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance62.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance62.TextHAlignAsString = "Center";
            this.txtFrrn.Appearance = appearance62;
            this.txtFrrn.BackColor = System.Drawing.Color.White;
            this.txtFrrn.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtFrrn.EnterKeyToTab = true;
            this.txtFrrn.Location = new System.Drawing.Point(442, 39);
            this.txtFrrn.MaxLength = 6;
            this.txtFrrn.Name = "txtFrrn";
            appearance63.BackColor = System.Drawing.Color.White;
            appearance63.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance63.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance63.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance63.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFrrn.NullTextAppearance = appearance63;
            this.txtFrrn.Size = new System.Drawing.Size(66, 23);
            this.txtFrrn.TabIndex = 2;
            this.txtFrrn.Tag = "FRRN";
            this.txtFrrn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtFrrn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel3
            // 
            appearance64.BackColor = System.Drawing.Color.Transparent;
            appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance64.FontData.Name = "맑은 고딕";
            appearance64.FontData.SizeInPoints = 9F;
            appearance64.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance64.TextHAlignAsString = "Right";
            appearance64.TextVAlignAsString = "Middle";
            this.LxTitleLabel3.Appearance = appearance64;
            this.LxTitleLabel3.Location = new System.Drawing.Point(10, 103);
            this.LxTitleLabel3.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel3.Name = "LxTitleLabel3";
            this.LxTitleLabel3.Size = new System.Drawing.Size(51, 23);
            this.LxTitleLabel3.TabIndex = 0;
            this.LxTitleLabel3.Text = "주     소";
            this.LxTitleLabel3.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel3.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtNatnCdnm
            // 
            appearance65.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance65.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance65.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance65.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance65.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance65.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance65.TextHAlignAsString = "Center";
            this.txtNatnCdnm.Appearance = appearance65;
            this.txtNatnCdnm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtNatnCdnm.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance66.BackColor = System.Drawing.Color.Transparent;
            appearance66.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance66.BorderColor = System.Drawing.Color.Transparent;
            appearance66.BorderColor2 = System.Drawing.Color.Transparent;
            appearance66.Image = ((object)(resources.GetObject("appearance66.Image")));
            appearance66.ImageHAlign = Infragistics.Win.HAlign.Right;
            appearance66.ImageVAlign = Infragistics.Win.VAlign.Middle;
            editorButton2.Appearance = appearance66;
            editorButton2.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Button;
            editorButton2.Width = 18;
            this.txtNatnCdnm.ButtonsRight.Add(editorButton2);
            this.txtNatnCdnm.Location = new System.Drawing.Point(63, 135);
            this.txtNatnCdnm.Name = "txtNatnCdnm";
            appearance67.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance67.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance67.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance67.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance67.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance67.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtNatnCdnm.NullTextAppearance = appearance67;
            this.txtNatnCdnm.ReadOnly = true;
            this.txtNatnCdnm.Size = new System.Drawing.Size(110, 23);
            this.txtNatnCdnm.TabIndex = 15;
            this.txtNatnCdnm.Tag = "NATN_CDNM";
            this.txtNatnCdnm.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtNatnCdnm.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblNatnCd
            // 
            appearance68.BackColor = System.Drawing.Color.Transparent;
            appearance68.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance68.FontData.Name = "맑은 고딕";
            appearance68.FontData.SizeInPoints = 9F;
            appearance68.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance68.TextHAlignAsString = "Right";
            appearance68.TextVAlignAsString = "Middle";
            this.lblNatnCd.Appearance = appearance68;
            this.lblNatnCd.Location = new System.Drawing.Point(7, 135);
            this.lblNatnCd.Margin = new System.Windows.Forms.Padding(0);
            this.lblNatnCd.Name = "lblNatnCd";
            this.lblNatnCd.Size = new System.Drawing.Size(54, 23);
            this.lblNatnCd.TabIndex = 0;
            this.lblNatnCd.Text = "국가코드";
            this.lblNatnCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblNatnCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtAddrCd
            // 
            appearance69.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance69.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance69.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance69.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance69.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance69.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance69.TextHAlignAsString = "Center";
            this.txtAddrCd.Appearance = appearance69;
            this.txtAddrCd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtAddrCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance70.BackColor = System.Drawing.Color.Transparent;
            appearance70.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance70.BorderColor = System.Drawing.Color.Transparent;
            appearance70.BorderColor2 = System.Drawing.Color.Transparent;
            appearance70.Image = ((object)(resources.GetObject("appearance70.Image")));
            appearance70.ImageHAlign = Infragistics.Win.HAlign.Right;
            appearance70.ImageVAlign = Infragistics.Win.VAlign.Middle;
            editorButton3.Appearance = appearance70;
            editorButton3.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Button;
            editorButton3.Width = 18;
            this.txtAddrCd.ButtonsRight.Add(editorButton3);
            this.txtAddrCd.Location = new System.Drawing.Point(63, 103);
            this.txtAddrCd.Name = "txtAddrCd";
            appearance71.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance71.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance71.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance71.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance71.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance71.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtAddrCd.NullTextAppearance = appearance71;
            this.txtAddrCd.ReadOnly = true;
            this.txtAddrCd.Size = new System.Drawing.Size(110, 23);
            this.txtAddrCd.TabIndex = 12;
            this.txtAddrCd.Tag = "ADDR_CD";
            this.txtAddrCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtAddrCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel5
            // 
            appearance72.BackColor = System.Drawing.Color.Transparent;
            appearance72.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance72.FontData.Name = "맑은 고딕";
            appearance72.FontData.SizeInPoints = 9F;
            appearance72.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance72.TextHAlignAsString = "Right";
            appearance72.TextVAlignAsString = "Middle";
            this.LxTitleLabel5.Appearance = appearance72;
            this.LxTitleLabel5.Location = new System.Drawing.Point(7, 167);
            this.LxTitleLabel5.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel5.Name = "LxTitleLabel5";
            this.LxTitleLabel5.Size = new System.Drawing.Size(54, 23);
            this.LxTitleLabel5.TabIndex = 0;
            this.LxTitleLabel5.Text = "사망일자";
            this.LxTitleLabel5.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel5.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtHousTel
            // 
            appearance73.BackColor = System.Drawing.Color.White;
            appearance73.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance73.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance73.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance73.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance73.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance73.TextHAlignAsString = "Left";
            this.txtHousTel.Appearance = appearance73;
            this.txtHousTel.BackColor = System.Drawing.Color.White;
            this.txtHousTel.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtHousTel.EnterKeyToTab = true;
            this.txtHousTel.Location = new System.Drawing.Point(63, 71);
            this.txtHousTel.MaxLength = 15;
            this.txtHousTel.Name = "txtHousTel";
            appearance74.BackColor = System.Drawing.Color.White;
            appearance74.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance74.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance74.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance74.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance74.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtHousTel.NullTextAppearance = appearance74;
            this.txtHousTel.Size = new System.Drawing.Size(110, 23);
            this.txtHousTel.TabIndex = 7;
            this.txtHousTel.Tag = "HOUS_TEL";
            this.txtHousTel.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtHousTel.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel6
            // 
            appearance75.BackColor = System.Drawing.Color.Transparent;
            appearance75.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance75.FontData.Name = "맑은 고딕";
            appearance75.FontData.SizeInPoints = 9F;
            appearance75.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance75.TextHAlignAsString = "Right";
            appearance75.TextVAlignAsString = "Middle";
            this.LxTitleLabel6.Appearance = appearance75;
            this.LxTitleLabel6.Location = new System.Drawing.Point(7, 199);
            this.LxTitleLabel6.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel6.Name = "LxTitleLabel6";
            this.LxTitleLabel6.Size = new System.Drawing.Size(54, 23);
            this.LxTitleLabel6.TabIndex = 0;
            this.LxTitleLabel6.Text = "특이사항";
            this.LxTitleLabel6.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel6.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtPtPclrMatr
            // 
            appearance76.BackColor = System.Drawing.Color.White;
            appearance76.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance76.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance76.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance76.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance76.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtPtPclrMatr.Appearance = appearance76;
            this.txtPtPclrMatr.BackColor = System.Drawing.Color.White;
            this.txtPtPclrMatr.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtPtPclrMatr.ImeMode = System.Windows.Forms.ImeMode.Hangul;
            this.txtPtPclrMatr.Location = new System.Drawing.Point(63, 199);
            this.txtPtPclrMatr.MaxLength = 3000;
            this.txtPtPclrMatr.Multiline = true;
            this.txtPtPclrMatr.Name = "txtPtPclrMatr";
            appearance77.BackColor = System.Drawing.Color.White;
            appearance77.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance77.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance77.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance77.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance77.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtPtPclrMatr.NullTextAppearance = appearance77;
            this.txtPtPclrMatr.Size = new System.Drawing.Size(840, 111);
            this.txtPtPclrMatr.TabIndex = 22;
            this.txtPtPclrMatr.Tag = "PT_PCLR_MATR";
            this.txtPtPclrMatr.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtPtPclrMatr.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtPID
            // 
            appearance78.BackColor = System.Drawing.Color.White;
            appearance78.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance78.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance78.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance78.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance78.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance78.TextHAlignAsString = "Center";
            this.txtPID.Appearance = appearance78;
            this.txtPID.BackColor = System.Drawing.Color.White;
            this.txtPID.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance79.BackColor = System.Drawing.Color.Transparent;
            appearance79.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance79.BorderColor = System.Drawing.Color.Transparent;
            appearance79.BorderColor2 = System.Drawing.Color.Transparent;
            appearance79.Image = ((object)(resources.GetObject("appearance79.Image")));
            appearance79.ImageHAlign = Infragistics.Win.HAlign.Right;
            appearance79.ImageVAlign = Infragistics.Win.VAlign.Middle;
            editorButton4.Appearance = appearance79;
            editorButton4.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Button;
            editorButton4.Width = 18;
            this.txtPID.ButtonsRight.Add(editorButton4);
            this.txtPID.EnterKeyToTab = true;
            this.txtPID.ImeMode = System.Windows.Forms.ImeMode.Hangul;
            this.txtPID.Location = new System.Drawing.Point(63, 39);
            this.txtPID.MaxLength = 10;
            this.txtPID.Name = "txtPID";
            appearance80.BackColor = System.Drawing.Color.White;
            appearance80.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance80.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance80.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance80.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance80.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtPID.NullTextAppearance = appearance80;
            this.txtPID.Size = new System.Drawing.Size(110, 23);
            this.txtPID.TabIndex = 0;
            this.txtPID.Tag = "PID";
            this.txtPID.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtPID.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // ucPatientInfoModE
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.pnlTop);
            this.Name = "ucPatientInfoModE";
            this.Size = new System.Drawing.Size(909, 355);
            this.Controls.SetChildIndex(this.pnlTop, 0);
            this.Controls.SetChildIndex(this.pnlBase, 0);
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).EndInit();
            this.pnlBase.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pnlTop)).EndInit();
            this.pnlTop.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lxButtonList1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ttpPtInfo)).EndInit();
            this.ttpPtInfo.ResumeLayout(false);
            this.ttpPtInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mskDethDd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDethPlceDvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSmsCnsnYn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkDelYn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboIndvInfoCnsnYn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDongAddr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDetlAddr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEmalAddr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrnrNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtClphTel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPtNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAge)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtItdtEmnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDobr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddrBldgNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNatnCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtItdtEmno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSrrn_SrrnEcpt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEtcTel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrrn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNatnCdnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblNatnCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddrCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHousTel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPtPclrMatr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Framework.Controls.LxPanel pnlTop;
        private Framework.Controls.LxButtonList lxButtonList1;
        private Framework.Controls.LxTitlePanel ttpPtInfo;
        private Framework.Controls.LxTitleLabel LxTitleLabel24;
        private Framework.Controls.LxTitleLabel LxTitleLabel25;
        private Framework.Controls.LxTitleLabel LxTitleLabel4;
        private Framework.Controls.LxTitleLabel LxTitleLabel1;
        private Framework.Controls.LxMaskedEdit mskDethDd;
        private Framework.Controls.LxTitleLabel LxTitleLabel7;
        private Framework.Controls.LxComboBox cboDethPlceDvcd;
        private Framework.Controls.LxTitleLabel LxTitleLabel14;
        private Framework.Controls.LxCheckBox chkSmsCnsnYn;
        private Framework.Controls.LxTitleLabel LxTitleLabel18;
        private Framework.Controls.LxCheckBox chkDelYn;
        private Framework.Controls.LxTitleLabel LxTitleLabel21;
        private Framework.Controls.LxComboBox cboIndvInfoCnsnYn;
        private Framework.Controls.LxTitleLabel LxTitleLabel8;
        private Framework.Controls.LxTextBox txtDongAddr;
        private Framework.Controls.LxTitleLabel LxTitleLabel15;
        private Framework.Controls.LxTextBox txtDetlAddr;
        private Framework.Controls.LxTitleLabel LxTitleLabel19;
        private Framework.Controls.LxTextBox txtEmalAddr;
        private Framework.Controls.LxTitleLabel LxTitleLabel10;
        private Framework.Controls.LxTextBox txtFrnrNm;
        private Framework.Controls.LxTitleLabel LxTitleLabel9;
        private Framework.Controls.LxTextBox txtClphTel;
        private Framework.Controls.LxTitleLabel LxTitleLabel16;
        private Framework.Controls.LxTextBox txtPtNm;
        private Framework.Controls.LxTitleLabel LxTitleLabel11;
        private Framework.Controls.LxTextBox txtAge;
        private Framework.Controls.LxTitleLabel LxTitleLabel17;
        private Framework.Controls.LxTextBox txtSex;
        private Framework.Controls.LxTitleLabel LxTitleLabel22;
        private Framework.Controls.LxTextBox txtItdtEmnm;
        private Framework.Controls.LxTitleLabel LxTitleLabel20;
        private Framework.Controls.LxTextBox txtDobr;
        private Framework.Controls.LxTitleLabel LxTitleLabel12;
        private Framework.Controls.LxTextBox txtAddrBldgNo;
        private Framework.Controls.LxTextBox txtNatnCd;
        private Framework.Controls.LxTextBox txtItdtEmno;
        private Framework.Controls.LxTextBox txtSrrn_SrrnEcpt;
        private Framework.Controls.LxTitleLabel LxTitleLabel13;
        private Framework.Controls.LxTextBox txtEtcTel1;
        private Framework.Controls.LxTitleLabel LxTitleLabel2;
        private Framework.Controls.LxTextBox txtFrrn;
        private Framework.Controls.LxTitleLabel LxTitleLabel3;
        private Framework.Controls.LxTextBox txtNatnCdnm;
        private Framework.Controls.LxTitleLabel lblNatnCd;
        private Framework.Controls.LxTextBox txtAddrCd;
        private Framework.Controls.LxTitleLabel LxTitleLabel5;
        private Framework.Controls.LxTextBox txtHousTel;
        private Framework.Controls.LxTitleLabel LxTitleLabel6;
        private Framework.Controls.LxTextBox txtPtPclrMatr;
        private Framework.Controls.LxTextBox txtPID;


    }
}
