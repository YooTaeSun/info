using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;
using SQL_BI = Lime.SqlPack.BI;
using SQL_NR = Lime.SqlPack.NR;
using SQL_OR = Lime.SqlPack.OR;

namespace Lime.Framework
{
    public class ORBizCommon
    {
        #region 처방 설정
        /// <summary>
        /// 수가코드에 해당하는 수가명을 자동으로 스프레드에 세팅해주는 함수.
        /// 스프레드에서 수가명Column에서 Enter를 쳤을 때 발생하는 이벤트 안에 넣어주면 된다.
        /// 성공시 0, 실패시 1을 반환한다.
        /// </summary>
        /// <param name="spr">사용하는 스프레드 이름</param>
        /// <param name="AplyStrtDdTag">적용시작일자의 컬럼 Tag명</param>
        /// <param name="CodeTag">코드가 있는 컬럼의 Tag명</param>
        /// <param name="MefeNameTag">코드의 명칭이 들어갈 컬럼의 Tag명</param>
        public static bool SetMefeName(LxSpread spr, string aplystrtddtag, string codetag, string mefenametag)
        {
            string Name = DBService.ExecuteScalar(SQL_BI.Sql.SelectMefe(), spr.GetValue(codetag).ToString().ToUpper()
                                                                         , spr.GetValue(aplystrtddtag).ToString()).ToString();

            if (Name != "N")
            {
                spr.SetText(mefenametag, Name);
                spr.SetText(codetag, spr.GetValue(codetag).ToString().ToUpper());
                return true;
            }
            else
            {
                LxMessage.Show("코드명과 적용시작일자에 해당하는 적합한 명칭을 찾을 수 없습니다.", "코드명 검색불가", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                spr.ActiveSheet.SetActiveCell(spr.ActiveSheet.ActiveRowIndex, spr.ActiveSheet.ActiveColumnIndex);
                spr.SetText(codetag, "");
                spr.SetText(mefenametag, "");
                spr.SetActiveCell(spr.ActiveSheet.ActiveRowIndex, codetag);
                return false;
            }
        }
        #endregion

        #region 상병설정
        /// <summary>
        /// 상병을 설정한다.
        /// </summary>
        /// <param name="spr"></param>
        /// <param name="aplystrtddtag"></param>
        /// <param name="codetag"></param>
        /// <param name="mefenametag"></param>
        /// <returns></returns>
        public static bool SetDisName(LxSpread spr, string aplystrtddtag, string codetag, string disnametag)
        {
            string regmsg = string.Empty;
            string Name = DBService.ExecuteScalar(SQL_BI.Sql.SelectBIORDCDT_ILNS_CD(), spr.GetValue(codetag).ToString().ToUpper()
                                                                                     , spr.GetValue(aplystrtddtag).ToString()
                                                                                     , regmsg).ToString();

            if (Name != "N")
            {
                spr.SetText(disnametag, Name);
                spr.SetText(codetag, spr.GetValue(codetag).ToString().ToUpper());
                return true;
            }
            else
            {
                LxMessage.Show("코드명과 적용시작일자에 해당하는 적합한 명칭을 찾을 수 없습니다.", "코드명 검색불가", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                spr.ActiveSheet.SetActiveCell(spr.ActiveSheet.ActiveRowIndex, spr.ActiveSheet.ActiveColumnIndex);
                spr.SetText(codetag, "");
                spr.SetText(disnametag, "");
                spr.SetActiveCell(spr.ActiveSheet.ActiveRowIndex, codetag);
                return false;
            }
        }
        #endregion

        // 키 몸무게 설정( Vital Sign Chart -> 간호초기평가 )
        public static bool GetHeightWeight(string pid, int pt_cmhs_no, ref string height, ref string weight)
        {
            // Vital Sign Chart 먼저 조회한다.
            // 키
            height = DBService.ExecuteScalar(Lime.SqlPack.Function.FN_NR_READ_VSCRIF(), pid
                                                                                   , "HT").ToString();

            weight = DBService.ExecuteScalar(Lime.SqlPack.Function.FN_NR_READ_VSCRIF(), pid
                                                                                   , "B.W").ToString();

            // Vital Sign Chart에서 없다면 간호초기평가에서 확인한다.
            if (string.IsNullOrWhiteSpace(height))
            {
                height = DBService.ExecuteScalar(Lime.SqlPack.Function.FN_NR_READ_NRINEXIF(), pid
                                                                                         , pt_cmhs_no.ToString()
                                                                                         , "HGHT").ToString();
            }

            if (string.IsNullOrWhiteSpace(weight))
            {
                weight = DBService.ExecuteScalar(Lime.SqlPack.Function.FN_NR_READ_NRINEXIF(), pid
                                                                                         , pt_cmhs_no.ToString()
                                                                                         , "BDWT").ToString();
            }

            return true;
        }

        /// <summary>
        /// [처방변경 처리관리 (ORCHPCMA)] Insert
        /// </summary>
        /// <param name="pid">환자등록번호</param>
        /// <param name="prscuniqno">처방고유번호</param>
        /// <param name="chngclmnnm">변경칼럼명</param>
        /// <param name="frtmclmncnts">이전칼럼내용</param>
        /// <param name="chngclmncnts">변경칼럼내용</param>
        /// <param name="etcpcft">기타특이사항</param>
        /// <param name="rgstdt">등록일시</param>
        /// <param name="rgstrid">등록자ID</param>
        /// <returns></returns>
        public static bool InsertORCHPCMA(string pid, string prscuniqno, string chngclmnnm, string frtmclmncnts, string chngclmncnts, string etcpcft, string rgstdt, string rgstrid)
        {
            // Call 하는 쪽에서 try...catch 처리함

            // 해당칼럼내용이 수정되지 않은 경우 리턴
            if (frtmclmncnts.Equals(chngclmncnts))
                return true;

            // 해당칼럼의 수정이력을 저장
            if (!DBService.ExecuteNonQuery(SQL_OR.Sql.InsertORCHPCMA(), pid              // 환자등록번호
                                                                        , prscuniqno       // 처방고유번호
                                                                        , chngclmnnm       // 변경칼럼명
                                                                        , frtmclmncnts     // 이전칼럼내용
                                                                        , chngclmncnts     // 변경칼럼내용
                                                                        , etcpcft          // 기타특이사항
                                                                        , ""               // 기타사용내용첫째
                                                                        , ""               // 기타사용내용둘째
                                                                        , ""               // 기타사용내용셋째
                                                                        , rgstdt           // 등록일시
                                                                        , rgstrid))        // 등록자ID
            {
                LogService.ErrorLog("Error : InsertORCHPCMA 처방변경 처리관리 저장 중 에러발생");
                return false;
            }

            return true;
        }

        /// <summary>
        /// [처방SEQTEMP용 (ORSQTPIF)] Insert (스프레드에서 선택한 행만큼)
        /// </summary>
        /// <param name="dlwtuniqno">처리고유번호</param>
        /// <param name="targetitems">스프레드에서 선택한 행row list</param>
        /// <param name="spread">해당 스프레드</param>
        /// <param name="currentdate">등록,수정일자</param>
        /// <param name="pid">환자등록번호</param>
        /// <param name="ptcmhsno">환자내원번호</param>
        /// <param name="usedvcd">사용구분코드</param>
        /// <returns></returns>
        public static bool InsertORSQTPIF(ref string dlwtuniqno, List<int> targetitems, LxSpread spread, string currentdate, string pid, string ptcmhsno, string usedvcd)
        {
            dlwtuniqno = GetDlwtUniqNo(pid, currentdate);

            // 처리관리를 저장
            int sqno = 0;
            foreach (int row in targetitems)
            {
                sqno++;
                InsertORSQTPIFSub(pid, ptcmhsno, spread.GetValue(row, "MDCR_DD").ToString(), usedvcd, ref dlwtuniqno, sqno.ToString(), spread.GetValue(row, "PRSC_SQNO").ToString(), currentdate);
            }

            return true;
        }

        /// <summary>
        /// [처방SEQTEMP용 (ORSQTPIF)] Insert (데이터 지정)
        /// </summary>
        /// <param name="pid">환자등록번호</param>
        /// <param name="ptcmhsno">환자내원번호</param>
        /// <param name="mdcrdd">진료일자</param>
        /// <param name="usedvcd">사용구분코드</param>
        /// <param name="dlwtuniqno"></param>
        /// <param name="sqno"></param>
        /// <param name="prscsqno"></param>
        /// <param name="currentdate"></param>
        /// <returns></returns>
        public static bool InsertORSQTPIFSub(string pid, string ptcmhsno, string mdcrdd, string usedvcd, ref string dlwtuniqno, string sqno, string prscsqno, string currentdate)
        {
            if (dlwtuniqno.Equals(""))
                dlwtuniqno = GetDlwtUniqNo(pid, currentdate);

            try
            {
                if (!DBService.ExecuteNonQuery(SQL_OR.Sql.InsertORSQTPIF()
                                             , pid                          // PID                (환자등록번호)
                                             , ptcmhsno                     // PT_CMHS_NO         (환자내원번호)
                                             , mdcrdd                       // MDCR_DD            (진료일자)
                                             , usedvcd                      // USE_DVCD           (사용구분코드)
                                             , dlwtuniqno                   // DLWT_UNIQ_NO       (처리고유번호)
                                             , sqno                         // SQNO               (일련번호)
                                             , prscsqno                     // PRSC_SQNO          (처방일련번호)
                                             , "0"                          // TMPR_SQNO          (임시일련번호)
                                             , "N"                          // DLWT_YN            (처리여부)
                                             , ""                           // ETC_USE_CNTS_1     (기타사용내용첫째)
                                             , ""                           // ETC_USE_CNTS_2     (기타사용내용둘째)
                                             , ""                           // ETC_USE_CNTS_3     (기타사용내용셋째)
                                             , ""                           // ETC_USE_CNTS_4     (기타사용내용넷째)
                                             , ""                           // ETC_USE_CNTS_5     (기타사용내용다섯째)
                                             , currentdate                  // RGST_DT,UPDT_DT    (등록일시,수정일시)
                                             , DOPack.UserInfo.USER_CD))    // RGSTR_ID,UPDTR_ID  (등록자ID,수정자ID)
                {
                    throw new Exception();
                    //return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
        }

        /// <summary>
        /// [처방SEQTEMP용 (ORSQTPIF)]의 처리여부(DLWT_YN)을 'Y'로 변경
        /// </summary>
        /// <param name="currentdate"></param>
        /// <returns></returns>
        public static bool UpdateORSQTPIF_DLWT_YN_Y(string pid, string ptcmhsno, string dlwtuniqno, string usedvcd)
        {
            if (!DBService.ExecuteNonQuery(SQL_OR.Sql.UpdateORSQTPIF_DLWT_YN_Y(), pid, ptcmhsno, dlwtuniqno, usedvcd))
                return false;

            return true;
        }

        /// <summary>
        /// [처방SEQTEMP용 (ORSQTPIF)]에서 처리고유번호(DLWT_UNIQ_NO) 취득
        /// 미사용 예정
        /// </summary>
        /// <param name="currentdate"></param>
        /// <returns></returns>
        public static string GetDlwtUniqNo(string currentdate)
        {
            string dlwtuniqno = string.Empty;
            int refdlwtuniqno = 0;
            SqlPack.Procedure.PR_AD_READ_UNIQSQ("ORSQTPIF", currentdate.Substring(0, 4), currentdate.Substring(4, 2), currentdate.Substring(6, 2), "N", "N", ref refdlwtuniqno);
            dlwtuniqno = string.Format("{0}{1:00000}", currentdate.Substring(0, 8), refdlwtuniqno);
            return dlwtuniqno;
        }

        /// <summary>
        /// [처방SEQTEMP용 (ORSQTPIF)]에서 처리고유번호(DLWT_UNIQ_NO) 취득
        /// </summary>
        /// <param name="pid">환자등록번호</param>
        /// <param name="currentdate">등록일시</param>
        /// <returns></returns>
        public static string GetDlwtUniqNo(string pid, string currentdate)
        {
            if (ConfigService.GetConfigValueDirect("OR", "TEMP", "USE_ORSQTPSQ") == "Y")
            {
                int refDlwtUniqNo = 0;
                SQL.Procedure.PR_OR_READ_ORSQTPSQ(pid, currentdate.Substring(0, 4), currentdate.Substring(4, 2), ref refDlwtUniqNo);
                return $"{currentdate.Substring(0, 6)}{refDlwtUniqNo.ToString("0000000")}";
            }
            else
                return GetDlwtUniqNo(currentdate);
        }

        /// <summary>
        /// 마약처방전 출력
        /// </summary>
        /// <param name="dlwtuniqno">처리고유번호</param>
        /// <param name="reprintflag">재출력flag</param>
        public static DataTable PrintPrescribeDrug(string pid, string ptcmhsno, string dlwtuniqno, bool reprintflag = false, string printDC = "")
        {
            DataTable printdt = new DataTable();

            List<string> targetitems = new List<string>();

            DataTable dt = new DataTable();
            DBService.ExecuteDataTable(SQL_OR.Sql.SelectORSQTPIF_ORORDRRT(), ref dt, pid, ptcmhsno, dlwtuniqno);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                // DC 출력시에는, DC된 원처방은 Continue
                if (StringService.IsNotNull(printDC) && !(dt.Rows[i]["DC_PRSC_DVCD"].ToString().Equals("A") || dt.Rows[i]["DC_PRSC_DVCD"].ToString().Equals("D")))
                    continue;

                // 마약이 아니면 Continue
                if (!(dt.Rows[i]["PRSC_LCLS_CD"].ToString().Equals("30") && dt.Rows[i]["PRSC_MCLS_CD"].ToString().Equals("30")) &&
                    !(dt.Rows[i]["PRSC_LCLS_CD"].ToString().Equals("20") && dt.Rows[i]["PRSC_MCLS_CD"].ToString().Equals("30")))
                    continue;

                // PRN , 자가이면 Continue
                if (dt.Rows[i]["PRSC_DVCD"].ToString().Equals("P") || dt.Rows[i]["PRSC_DVCD"].ToString().Equals("S"))
                    continue;

                // 선시행이면 Continue
                if (dt.Rows[i]["PRV_ACTG_YN"].ToString().Equals("Y"))
                    continue;

                // 약 또는 주사가 아니면 Continue
                if (!dt.Rows[i]["PRSC_CLSF_CD"].ToString().Equals("1") && !dt.Rows[i]["PRSC_CLSF_CD"].ToString().Equals("2") &&
                    !dt.Rows[i]["PRSC_CLSF_CD"].ToString().Equals("3") && !dt.Rows[i]["PRSC_CLSF_CD"].ToString().Equals("4"))
                    continue;

                // 원외처방은 마약처방전이 출력 안되게 한다
                if (dt.Rows[i]["REAL_OTPT_ADMS_DVCD"].ToString().Equals("O") && dt.Rows[i]["EXCP_RESN_CD"].ToString().Equals("NO"))
                {
                    if (reprintflag)
                        LxMessage.Show(string.Format("처방코드 : {0}\r\n처방명칭 : {1}\r\n원외처방은 마약처방전이 출력되지 않습니다.\r\n원무 수납 시 출력됩니다.", dt.Rows[i]["PRSC_CD"].ToString(), dt.Rows[i]["PRSC_NM"].ToString()),
                            "오류",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);

                    continue;
                }

                targetitems.Add(dt.Rows[i]["PRSC_UNIQ_NO"].ToString());
            }

            if (targetitems.Count.Equals(0))
                return printdt;

            string inselect = string.Empty;
            foreach (string item in targetitems)
                inselect += inselect.Equals(string.Empty) ? item : ", " + item;

            DBService.ExecuteDataTable(SQL_NR.Sql.SelectORORDRRT_PRSC_UNIQ_NO_IN(), ref printdt, inselect);
            if (printdt.Rows.Count.Equals(0))
                return printdt;

            //clsReissuePrescribeDrug prt = new clsReissuePrescribeDrug();
            //prt.Print(true, printdt, reprintflag);
            return printdt;
        }

        /// <summary>
        /// 향정처방전 출력
        /// </summary>
        /// <param name="dlwtuniqno">처리고유번호</param>
        /// <param name="reprintflag">재출력flag</param>
        public static DataTable PrintPrescribePsyco(string pid, string ptcmhsno, string dlwtuniqno, bool reprintflag = false, string printDC = "")
        {
            DataTable printdt = new DataTable();

            List<string> targetitems = new List<string>();

            DataTable dt = new DataTable();
            DBService.ExecuteDataTable(SQL_OR.Sql.SelectORSQTPIF_ORORDRRT(), ref dt, pid, ptcmhsno, dlwtuniqno);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                // DC 출력시에는, DC된 원처방은 Continue
                if (StringService.IsNotNull(printDC) && !(dt.Rows[i]["DC_PRSC_DVCD"].ToString().Equals("A") || dt.Rows[i]["DC_PRSC_DVCD"].ToString().Equals("D")))
                    continue;

                // 향정주사가 아니면 Continue
                if (!(dt.Rows[i]["PRSC_LCLS_CD"].ToString().Equals("20") && dt.Rows[i]["PRSC_MCLS_CD"].ToString().Equals("40")))
                {
                    // 향정PO 출력 시 조건 처리
                    if (!(ConfigService.GetConfigValueBool("PM", "PM_PRINT_PSYCO_YN", "PM_PRINT_PSYCO_PO_YN") && dt.Rows[i]["PRSC_LCLS_CD"].ToString().Equals("30") && dt.Rows[i]["PRSC_MCLS_CD"].ToString().Equals("40")))
                        continue;
                }

                // PRN , 자가이면 Continue
                if (dt.Rows[i]["PRSC_DVCD"].ToString().Equals("P") || dt.Rows[i]["PRSC_DVCD"].ToString().Equals("S"))
                    continue;

                // 선시행이면 Continue
                if (dt.Rows[i]["PRV_ACTG_YN"].ToString().Equals("Y"))
                    continue;

                // 약 또는 주사가 아니면 Continue
                if (!dt.Rows[i]["PRSC_CLSF_CD"].ToString().Equals("1") && !dt.Rows[i]["PRSC_CLSF_CD"].ToString().Equals("2") &&
                    !dt.Rows[i]["PRSC_CLSF_CD"].ToString().Equals("3") && !dt.Rows[i]["PRSC_CLSF_CD"].ToString().Equals("4"))
                    continue;

                if (dt.Rows[i]["REAL_OTPT_ADMS_DVCD"].ToString().Equals("O") && dt.Rows[i]["EXCP_RESN_CD"].ToString().Equals("NO"))
                {
                    if (reprintflag)
                        LxMessage.Show(string.Format("처방코드 : {0}\r\n처방명칭 : {1}\r\n원외처방은 향정처방전이 출력되지 않습니다.\r\n원무 수납 시 출력됩니다.", dt.Rows[i]["PRSC_CD"].ToString(), dt.Rows[i]["PRSC_NM"].ToString()),
                            "오류",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);

                    continue;
                }

                targetitems.Add(dt.Rows[i]["PRSC_UNIQ_NO"].ToString());
            }

            if (targetitems.Count.Equals(0))
                return printdt;

            string inselect = string.Empty;
            foreach (string item in targetitems)
                inselect += inselect.Equals(string.Empty) ? item : ", " + item;

            DBService.ExecuteDataTable(SQL_NR.Sql.SelectORORDRRT_PRSC_UNIQ_NO_IN(), ref printdt, inselect);
            if (printdt.Rows.Count.Equals(0))
                return printdt;

            //clsReissuePrescribeDrug prt = new clsReissuePrescribeDrug();
            //prt.Print(true, printdt, reprintflag);
            return printdt;
        }

        /// <summary>
        /// 투여방법을 조회한다.
        /// </summary>
        /// <param name="tvw">트리뷰</param>
        /// <param name="prsc_clsf_cd">처방구분코드</param>
        /// <returns></returns>
        public static bool SelectMedicineUsage(LxTreeView tvw, string prsc_clsf_cd)
        {
            DataTable dt = new DataTable();
            string key = string.Empty;
            string name = string.Empty;

            try
            {
                if (!DBService.ExecuteDataTable(SQL_OR.Sql.SelectpopMediUsageTree(), ref dt
                                                                                    , prsc_clsf_cd))
                    LxMessage.Show("투여방법 조회에 실패했습니다. \r\n관리자에게 문의 요망", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                if (dt.Rows.Count <= 0)
                    return false;

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (tvw.GetNodeByKey(dt.Rows[i]["GROUP_NOTH"].ToString()) == null)
                    {
                        key = dt.Rows[i]["GROUP_NOTH"].ToString();
                        name = dt.Rows[i]["GROUP_NOTH"].ToString();
                        tvw.Nodes.Add(key, name).Tag = "1";

                        key = dt.Rows[i]["AOMD_MTHD_CD"].ToString();
                        name = dt.Rows[i]["AOMD_MTHD_CD"].ToString() + "   " + dt.Rows[i]["AOMD_MTHD_NM"].ToString();

                        tvw.GetNodeByKey(dt.Rows[i]["GROUP_NOTH"].ToString()).Nodes.Add(key, name).Tag = "2";
                    }
                    else
                    {
                        key = dt.Rows[i]["AOMD_MTHD_CD"].ToString();
                        name = dt.Rows[i]["AOMD_MTHD_CD"].ToString() + "   " + dt.Rows[i]["AOMD_MTHD_NM"].ToString();

                        tvw.GetNodeByKey(dt.Rows[i]["GROUP_NOTH"].ToString()).Nodes.Add(key, name).Tag = "2";
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
            return true;
        }

        /// <summary>
        /// 설정한 용법이 맞는지 확인한다.
        /// </summary>
        /// <param name="aomd_mthd_cd">용법코드</param>
        /// <param name="prsc_clsf_cd">처방구분코드</param>
        public static bool CheckMedicineUsage(string aomd_mthd_cd, string prsc_clsf_cd, ref string notm_chek_yn, ref string aply_notm, ref string errmsg)
        {
            DataTable dt = new DataTable();

            try
            {
                if (!(prsc_clsf_cd == "1" || prsc_clsf_cd == "2" || prsc_clsf_cd == "3" || prsc_clsf_cd == "4"))
                {
                    errmsg = "약/주사가 아닙니다. 투여방법을 설정할 수 없습니다.";
                    return false;
                }

                // 용법을 확인한다.
                if (DBService.ExecuteDataTable(SQL_OR.Sql.SelectCheckPMMTHDMA(), ref dt
                                                                               , aomd_mthd_cd
                                                                               , prsc_clsf_cd))
                {
                    if (dt.Rows.Count > 0)
                    {
                        if (string.IsNullOrWhiteSpace(dt.Rows[0]["NOTM_CHEK_YN"].ToString()))
                        {
                            errmsg = aomd_mthd_cd + "투여방법은 해당 투여방법이 아닙니다. 확인 해 주세요.";
                            return false;
                        }

                        notm_chek_yn = dt.Rows[0]["NOTM_CHEK_YN"].ToString();
                        aply_notm = dt.Rows[0]["APLY_NOTM"].ToString();

                        return true;
                    }
                    else
                    {
                        errmsg = aomd_mthd_cd + "투여방법은 존재하지 않는 용법입니다.";
                        return false;
                    }
                }
                else
                {
                    errmsg = "투여방법 조회 중 오류가 발생했습니다.";
                    return false;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
        }

        /// <summary>
        /// 횟수에 따른 용법을 불러온다.
        /// </summary>
        /// <returns></returns>
        public static string GetDefaultMedicineUsage(string prsc_cd, string mdcr_dd, int notm)
        {
            DataTable dt = new DataTable();

            try
            {
                // 처방 횟수별 용법을 설정
                if (DBService.ExecuteDataTable(SQL_OR.Sql.SelectPMPRNTMA(), ref dt
                                                                          , prsc_cd
                                                                          , mdcr_dd))
                {
                    if (dt.Rows.Count > 0)
                    {
                        switch (notm)
                        {
                            case 1:
                                return dt.Rows[0]["ONTM_AOMD_MTHD_CD"].ToString();
                            case 2:
                                return dt.Rows[0]["TWTS_AOMD_MTHD_CD"].ToString();
                            case 3:
                                return dt.Rows[0]["THTS_AOMD_MTHD_CD"].ToString();
                            case 4:
                                return dt.Rows[0]["FRTS_AOMD_MTHD_CD"].ToString();
                            case 5:
                                return dt.Rows[0]["FVTS_AOMD_MTHD_CD"].ToString();
                            case 6:
                                return dt.Rows[0]["SXTS_AOMD_MTHD_CD"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return "";
            }

            return "";
        }

        /// <summary>
        /// 정신건강의학과 협진의뢰 대상인지 체크
        /// </summary>
        /// <param name="pid">환자번호</param>
        /// <param name="pt_cmhs_no">내원번호</param>
        /// <param name="msg_dvcd">메세지 구분</param>
        /// <param name="error_msg">메세지</param>
        /// <returns></returns>
        public static bool CheckNpConsultTarget(string pid, string pt_cmhs_no, ref string msg_dvcd, ref string error_msg)
        {
            int cancerdiscount = 0;

            cancerdiscount = DBService.ExecuteInteger(SQL_OR.Sql.SelecCancerDisCount(), pid
                                                                                      , pt_cmhs_no);

            if (cancerdiscount < 0)
            {
                error_msg = "암상병 조회 중 오류가 발생했습니다.";
                return false;
            }

            return true;
        }

        /// <summary>
        /// 주 상병이 DRG상병인지 확인, DRG분류코드를 반환.
        /// </summary>
        /// <param name="pid">환자번호</param>
        /// <param name="pt_cmhs_no">내원번호</param>
        /// <param name="mdcr_dd">처방일자</param>
        /// <param name="drg_clsf_cd">DRG분류기호</param>
        /// <param name="errmsg">에러메세지</param>
        /// <returns></returns>
        public static bool CheckDrgMainDisAndGetDrgClsfCd(string pid, string pt_cmhs_no, string mdcr_dd, ref string drg_clsf_cd, ref string errmsg)
        {
            string ilns_cd = string.Empty;

            ilns_cd = DBService.ExecuteScalar(SQL_OR.Sql.SelectDrgMainDis(), pid
                                                                           , pt_cmhs_no
                                                                           , mdcr_dd).ToString();

            if (string.IsNullOrWhiteSpace(ilns_cd))
            {
                errmsg = "주상병이 DRG상병에 해당하지 않습니다. DRG적용할 수 없습니다.";
                return false;
            }
            else
            {
                drg_clsf_cd = DBService.ExecuteScalar(SQL_OR.Sql.SelectDrgClsfCd(), ilns_cd
                                                                                  , mdcr_dd).ToString();
                return true;
            }
        }

        /// <summary>
        /// 수신자 자격조회의 질병정보를 명칭으로 불러온다.
        /// </summary>
        /// <param name="rrn">주민등록번호</param>
        /// <param name="pt_nm">환자이름</param>
        /// <param name="disregprson_nm">질병정보명</param>
        /// <param name="errmsg">에러메세지</param>
        /// <returns></returns>
        public static bool GetDisregprsonInfoName(string rrn, string pt_nm, ref string disregprson_nm, ref string errmsg)
        {
            string disregprson1 = string.Empty;
            string disregprson2 = string.Empty;
            string disregprson4 = string.Empty;
            string disregprson6 = string.Empty;
            string disregprson9 = string.Empty;
            string todate = DateTime.Now.ToString("yyyyMMddHHmmss");
            string today = DateTimeService.ConvertDateStringToFormatString(todate, "yyyyMMdd");
            string disregprson1_sdate = string.Empty;
            string disregprson2_sdate = string.Empty;
            string disregprson4_sdate = string.Empty;
            string disregprson9_sdate = string.Empty;
            string disregprson1_edate = string.Empty;
            string disregprson2_edate = string.Empty;
            string disregprson4_edate = string.Empty;
            string disregprson9_edate = string.Empty;
            bool mellitus_yn = false;
            DataTable dt = new DataTable();

            try
            {
                if (!(DBService.ExecuteDataTable(SQL_OR.Sql.GetDisregprsonInfo(), ref dt
                                                                               , rrn
                                                                               , pt_nm
                                                                               , DateTimeService.ConvertDateStringToFormatString(todate, "yyyyMMdd-HHmmss"))))
                {
                    errmsg = "환자 정보 조회 중 오류가 발생했습니다.";
                    return false;
                }

                if (dt.Rows.Count > 0)
                {
                    disregprson1 = dt.Rows[0]["DISREGPRSON1"].ToString();
                    disregprson2 = dt.Rows[0]["DISREGPRSON2"].ToString();
                    disregprson4 = dt.Rows[0]["DISREGPRSON4"].ToString();
                    disregprson6 = dt.Rows[0]["DISREGPRSON6"].ToString();
                    disregprson9 = dt.Rows[0]["DISREGPRSON9"].ToString();

                    disregprson1_sdate = StringService.SubString(disregprson1, 4, 8);
                    disregprson2_sdate = StringService.SubString(disregprson2, 19, 8);
                    disregprson4_sdate = StringService.SubString(disregprson4, 19, 8);
                    disregprson9_sdate = StringService.SubString(disregprson9, 19, 8);
                    disregprson1_edate = StringService.SubString(disregprson1, 12, 8);
                    disregprson2_edate = StringService.SubString(disregprson2, 27, 8);
                    disregprson4_edate = StringService.SubString(disregprson4, 27, 8);
                    disregprson9_edate = StringService.SubString(disregprson9, 27, 8);

                    if (disregprson6.Trim().Length > 1)
                        mellitus_yn = true;

                    // 암환자 확인
                    if (DateTimeService.IsDateTime(disregprson4_sdate) && DateTimeService.IsDateTime(disregprson4_edate))
                    {
                        if (disregprson4 != "N" && StringService.SubString(disregprson4, 4) == "V193" && int.Parse(disregprson4_sdate) <= int.Parse(today) && int.Parse(disregprson4_edate) >= int.Parse(today))
                            disregprson_nm = "등록암";
                    }
                    // 산정특례희귀난치 확인
                    else if (DateTimeService.IsDateTime(disregprson2_sdate) && DateTimeService.IsDateTime(disregprson2_edate))
                    {
                        if (disregprson2 != "N" && StringService.SubString(disregprson2, 1) == "V" && int.Parse(disregprson2_sdate) <= int.Parse(today) && int.Parse(disregprson2_edate) >= int.Parse(today))
                        {
                            if (DateTimeService.IsDateTime(disregprson1_sdate) && DateTimeService.IsDateTime(disregprson1_edate))
                            {
                                if (disregprson1 != "N" && StringService.SubString(disregprson1, 1) == "H" && int.Parse(disregprson1_sdate) <= int.Parse(today) && int.Parse(disregprson1_edate) >= int.Parse(today))
                                    disregprson_nm = "산정특례희귀난치";
                                else
                                    disregprson_nm = "산정특례";
                            }
                            else
                                disregprson_nm = "산정특례";
                        }
                    }
                    // 결핵 산정특례 확인
                    else if (DateTimeService.IsDateTime(disregprson9_sdate) && DateTimeService.IsDateTime(disregprson9_edate))
                    {
                        if (disregprson9 != "N" && StringService.SubString(disregprson9, 1) == "V" && int.Parse(disregprson9_sdate) <= int.Parse(today) && int.Parse(disregprson9_edate) >= int.Parse(today))
                        {
                            if (DateTimeService.IsDateTime(disregprson1_sdate) && DateTimeService.IsDateTime(disregprson1_edate))
                            {
                                if (disregprson1 != "N" && StringService.SubString(disregprson1, 1) == "H" && int.Parse(disregprson1_sdate) <= int.Parse(today) && int.Parse(disregprson1_edate) >= int.Parse(today))
                                    disregprson_nm = "결핵산정특례/희귀";
                                else
                                    disregprson_nm = "결핵산정특례";
                            }
                            else
                                disregprson_nm = "결핵산정특례";
                        }
                    }
                    // 희귀난치 확인
                    else if (DateTimeService.IsDateTime(disregprson1_sdate) && DateTimeService.IsDateTime(disregprson1_edate))
                    {
                        if (disregprson1 != "N" && StringService.SubString(disregprson1, 1) == "H" && int.Parse(disregprson1_sdate) <= int.Parse(today) && int.Parse(disregprson1_edate) >= int.Parse(today))
                            disregprson_nm = "희귀난치";
                    }
                    else
                        disregprson_nm = "";

                    if (mellitus_yn)
                    {
                        if (string.IsNullOrWhiteSpace(disregprson_nm))
                            disregprson_nm = "당뇨환자";
                        else
                            disregprson_nm = disregprson_nm + "/당뇨환자";
                    }

                }
                else
                    disregprson_nm = "";

                return true;
            }
            catch (Exception ex)
            {
                errmsg = ex.Message;

                return false;
            }
        }

        /// <summary>
        /// 산정특례 및 희귀난치 상병 체크
        /// </summary>
        /// <param name="pid">환자번호</param>
        /// <param name="mdcr_dd">처방일자</param>
        /// <param name="pt_nm">환자이름</param>
        /// <param name="rrn">주민등록번호</param>
        /// <param name="insn_tycd">보험유형</param>
        /// <param name="todate">현재일자</param>
        /// <param name="disinfo">상병데이터</param>
        /// <param name="errmsg">에러메세지</param>
        /// <returns></returns>
        public static bool CheckCfscOrRrobDis(string pid, string mdcr_dd, string pt_nm, string rrn, string insn_tycd, string todate, DataTable disinfo, ref string errmsg)
        {
            string ilns_cd = string.Empty;
            string cfsc_cd = string.Empty;
            string ilns_cd_sqno = string.Empty;
            string disregprson2 = string.Empty;
            string disregprson9 = string.Empty;
            string fir_insn_tycd = string.Empty;
            string tbrc_kind_dvcd = string.Empty;
            string chek_ilns_cd = string.Empty;
            string title_commt = string.Empty;
            string vald_date = string.Empty;
            string app_ilns_cd = string.Empty;
            string app_ilns_cd_sqno = string.Empty;
            string aply_strt_dd = string.Empty;
            string aply_end_dd = string.Empty;
            DataTable dt = new DataTable();
            int cancer_count = 0;
            int tbrc_count = 0;
            int tbrc07_count = 0;
            int tbrc08_count = 0;
            int tbrc_kind_count = 0;
            int cfsc_cancer_count = 0;
            int chek_ilns_count = 0;
            int count = 0;
            int daynum = 0;

            try
            {
                // 자격조회 정보 조회
                if (!(DBService.ExecuteDataTable(SQL_OR.Sql.GetDisregprsonInfo(), ref dt
                                                                               , rrn
                                                                               , pt_nm
                                                                               , todate)))
                {
                    errmsg = "환자 정보 조회 중 오류가 발생했습니다.";
                    return false;
                }

                if (dt.Rows.Count > 0)
                {
                    disregprson2 = dt.Rows[0]["DISREGPRSON2"].ToString();
                    disregprson9 = dt.Rows[0]["DISREGPRSON9"].ToString();

                    // 등록암 정보 개수
                    cancer_count = DBService.ExecuteInteger(SQL_OR.Sql.SelectCountCancerPAPSDSMA(), pid
                                                                                                  , mdcr_dd);

                    // 결핵정보 개수
                    tbrc_count = DBService.ExecuteInteger(SQL_OR.Sql.SelectCountTbrcPAPSDSMA(), pid
                                                                                              , mdcr_dd);

                    // 중증질환등록 중증구분이 결핵 이고 등록번호가 07인 환자
                    tbrc07_count = DBService.ExecuteInteger(SQL_OR.Sql.SelectCountTbrc07PAPSDSMA(), pid
                                                                                                  , mdcr_dd);

                    // 중증질환등록 중증구분이 결핵 이고 등록번호가 08인 환자
                    tbrc08_count = DBService.ExecuteInteger(SQL_OR.Sql.SelectCountTbrc08PAPSDSMA(), pid
                                                                                                  , mdcr_dd);
                    fir_insn_tycd = StringService.SubString(insn_tycd, 1);

                    if (string.IsNullOrWhiteSpace(tbrc_kind_dvcd))
                        tbrc_kind_dvcd = "00";

                    for (int i = 0; i < disinfo.Rows.Count; i++)
                    {
                        ilns_cd = disinfo.Rows[i]["ILNS_CD"].ToString();
                        cfsc_cd = disinfo.Rows[i]["CFSC_CD"].ToString();
                        ilns_cd_sqno = disinfo.Rows[i]["ILNS_CD_SQNO"].ToString();

                        // 산정특례에 해당하는 상병인지 희귀난치에 해당하는 상병인지 확인한다.
                        if (!(string.IsNullOrWhiteSpace(ilns_cd)))
                        {
                            // 산정특례상병의 결핵종류구분코드의 개수를 조회한다.
                            if (DBService.ExecuteInteger(SQL_OR.Sql.SelectCountTbrcBIDSSCIF(), ilns_cd
                                                                                             , ilns_cd_sqno
                                                                                             , mdcr_dd
                                                                                             , fir_insn_tycd) > 0)
                            {
                                tbrc_kind_count++;
                                if (tbrc_kind_dvcd == "00")
                                {
                                    // 산정특례상병의 결핵종류구분코드를 조회한다.
                                    tbrc_kind_dvcd = DBService.ExecuteScalar(SQL_OR.Sql.SelectTbrcKindDvcdBIDSSCIF(), ilns_cd
                                                                                                                    , ilns_cd_sqno
                                                                                                                    , mdcr_dd
                                                                                                                    , fir_insn_tycd).ToString();
                                }
                            }

                            // 산정특례 코드가 등록암상병일 때
                            if (cfsc_cd == "V193")
                            {
                                cfsc_cancer_count++;

                                switch (StringService.SubString(ilns_cd, 3))
                                {
                                    case "C77":
                                    case "C78":
                                    case "C79":
                                        // 암등록 상병에서 비교제외
                                        break;
                                    default:
                                        if (DBService.ExecuteInteger(SQL_OR.Sql.SelectCountExcepCancerPAPSDSMA(), pid
                                                                                                               , mdcr_dd
                                                                                                               , ilns_cd) <= 0)
                                        {
                                            chek_ilns_count++;
                                            chek_ilns_cd = chek_ilns_cd + ilns_cd + " ";
                                        }
                                        break;
                                }
                            }
                        }
                    }
                }

                // ----------------------------------------------------------------------------------------------------------
                /* 산정특례 상병이 입력되었고 
                   1. 중증질환관리에 존재하지 않으면
                    2. 중증관리에 산정특례 정보만 존재하고 결핵상병이 등록되었다면
                    3. 중증관리에 산정특례 정보가 존재하지 않고 결핵정보는 존재하는데 산정특례 상병이 입력되었고
                       07로 시작되는 결핵번호를 갖고 있는 경우
                        (05로 시작되는 번호를 갖고 있는 경우는 둘 다(산정특례,결핵) 만족하는 경우이다.)
            
                    tbrc_kind_count : 산정특례 상병이 있는가 ?
                    count           : 중증질환등록 중증구분이 기타산정특례 정보가 존재하는가 ?
                    tbrc_count      : 중증질환등록 중증구분이 결핵         정보가 존재하는가 ?
                    tbrc_kind_dvcd  : 산정특례 상병관리에 결핵 상병이 있는가?
                    tbrc07_count    : 중증질환등록 중증구분이 결핵 이고 W등록번호가 07로 시작하는가 ?
                    tbrc08_count    : 중증질환등록 중증구분이 결핵 이고 등록번호가 08로 시작하는가 ?
		
                    2016.07.01 시행 결핵환자 V246종료 ... V000시행
                
                    이해가 되지 않음. 확인하여 업무파악해야함
                */
                if (tbrc_kind_dvcd == "01" && tbrc_kind_dvcd == "02")
                {
                    // V000이 등록되어 있지 않을 때
                    if (tbrc08_count < 1)
                    {
                        count = 1;
                        tbrc_count = 0;
                    }
                    else
                        count = 0;

                    if (tbrc_kind_count >= 1 && ((count <= 0 && tbrc_count <= 0) ||
                                                 (count <= 0 && tbrc_count >= 1 && tbrc_kind_dvcd != "01" && tbrc_kind_dvcd != "02" && (tbrc07_count >= 1 || tbrc08_count >= 1))) ||
                                                 (count >= 1 && (tbrc_kind_dvcd == "01" || tbrc_kind_dvcd == "02") && tbrc_count <= 0))
                    {
                        if (tbrc_kind_dvcd == "01" || tbrc_kind_dvcd == "02")
                        {
                            title_commt = "※결핵 산정특례 신청 대상자※\r\n" +
                                          "(2016.07.01 이후 신규등록 및 기존 환자 재등록 => 본인부담 면제)\r\n" +
                                          "(2016.06.30 이전 등록 => 본인부담 10%)\r\n" +
                                          "문의 : 보험심사팀 (2016.07.01 시행)";
                        }
                        else
                        {
                            title_commt = "※희귀난치성질환 산정특례 신청 대상자※";
                        }

                        LxMessage.Show(title_commt + "\r\n" + "신규등록 기준 확인 후 [산정특례 등록신청서] 작성 해 주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

                // 암상병이 입력되었지만 등록암정보 등록이 되어 있지 않을 때
                if (cfsc_cancer_count >= 1)
                {
                    if (cancer_count <= 0)
                    {
                        LxMessage.Show("암 상병이 입력되었으나 암 환자등록이 되어있지 않습니다.\r\n" +
                                       "암 등록 대상 신청서를 작성하여 주십시오.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        if (chek_ilns_count > 0)
                        {
                            LxMessage.Show("상병 : " + chek_ilns_cd + "\r\n" +
                                           "공단에 등록한 암중증 상병과 일치하지 않습니다.\r\n" +
                                           "암중증 중복등록 대상자 확인 바랍니다.\r\n" +
                                           "* 전이암은 암중증 중복등록에서 제외*", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }

                // 산정특례 재등록 메세지
                if (tbrc_kind_count >= 1 && StringService.SubString(disregprson2, 1) == "V" || StringService.SubString(disregprson2, 1) == "H")
                {
                    vald_date = StringService.SubString(disregprson2, 19, 16);                                                            // 유효기간
                    app_ilns_cd = StringService.SubString(StringService.SubString(disregprson2, disregprson2.Length - 12, 12), 10).Trim();  // 적용상병코드
                    app_ilns_cd_sqno = StringService.SubString(disregprson2, disregprson2.Length - 2, 2);                                        // 적용상병일련번호

                    aply_strt_dd = StringService.SubString(vald_date, 8);
                    aply_end_dd = StringService.SubString(vald_date, vald_date.Length - 8, 8);

                    daynum = Convert.ToInt32(Math.Floor((DateTimeService.ConvertDateTime(aply_end_dd) - DateTimeService.ConvertDateTime(mdcr_dd)).TotalDays));

                    if (tbrc_kind_dvcd == "01" || tbrc_kind_dvcd == "02")
                    {
                        title_commt = "※결핵 산정특례 신청 대상자※";
                        daynum = 100;
                    }
                    else
                        title_commt = "※희귀난치성질환 산정특례 신청 대상자※";

                    if (daynum <= 90)
                    {
                        LxMessage.Show(title_commt + "\r\n" +
                                       "신규등록 및 재등록 기준 확인 후 산정특례 등록신청서를 작성해 주세요.\r\n" +
                                       "(등록상병에 대해 신청 시 재등록입니다.)\r\n" +
                                       "적용기간 : " + DateTimeService.ConvertDateStringToFormatString(aply_strt_dd, "yyyy-MM-dd") + " - " + DateTimeService.ConvertDateStringToFormatString(aply_end_dd, "yyyy-MM-dd") + "\r\n" +
                                       "등록상병(일련번호) : " + app_ilns_cd + "(" + app_ilns_cd_sqno + ")", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

                // 결핵 재등록 메세지
                if (tbrc_kind_count >= 1 && StringService.SubString(disregprson9, 1) == "V" || StringService.SubString(disregprson9, 1) == "H")
                {
                    vald_date = StringService.SubString(disregprson9, 19, 16);                                                            // 유효기간
                    app_ilns_cd = StringService.SubString(StringService.SubString(disregprson9, disregprson9.Length - 12, 12), 10).Trim();  // 적용상병코드
                    app_ilns_cd_sqno = StringService.SubString(disregprson9, disregprson9.Length - 2, 2);                                        // 적용상병일련번호

                    aply_strt_dd = StringService.SubString(vald_date, 8);
                    aply_end_dd = StringService.SubString(vald_date, vald_date.Length - 8, 8);

                    daynum = Convert.ToInt32(Math.Floor((DateTimeService.ConvertDateTime(aply_end_dd) - DateTimeService.ConvertDateTime(mdcr_dd)).TotalDays));

                    if (tbrc_kind_dvcd == "01" || tbrc_kind_dvcd == "02")
                    {
                        title_commt = "※결핵 산정특례 신청 대상자※";
                        daynum = 100;
                    }
                    else
                        title_commt = "※희귀난치성질환 산정특례 신청 대상자※";

                    if (daynum <= 90)
                    {
                        LxMessage.Show(title_commt + "\r\n" +
                                       "신규등록 및 재등록 기준 확인 후 산정특례 등록신청서를 작성해 주세요.\r\n" +
                                       "(등록상병에 대해 신청 시 재등록입니다.)\r\n" +
                                       "적용기간 : " + DateTimeService.ConvertDateStringToFormatString(aply_strt_dd, "yyyy-MM-dd") + " - " + DateTimeService.ConvertDateStringToFormatString(aply_end_dd, "yyyy-MM-dd") + "\r\n" +
                                       "등록상병(일련번호) : " + app_ilns_cd + "(" + app_ilns_cd_sqno + ")", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                errmsg = ex.Message;

                return false;
            }
        }

        /// <summary>
        /// 드래싱팀을 리턴한다.
        /// </summary>
        /// <returns></returns>
        public static bool GetDressingTeam(string user_id)
        {
            DataTable dresuser = new DataTable();

            // 드래싱 사용자를 읽는다.
            dresuser = OverallCodeList.GetDataList("DRES_NURSE_DVCD");

            for (int i = 0; i < dresuser.Rows.Count; i++)
            {
                if (dresuser.Rows[i]["LWRN_OVRL_CD"].ToString() == user_id)
                    return true;
            }

            return false;
        }

        // 응급실 환자가 귀가처리되거나, 입원전환된 경우,
        // 응급실 간호초기평가지 (NRINEFIF)의 퇴실일자(LEAVE_DD)와 퇴실시간(LEAVE_TIME)을 갱신한다.
        public static bool UpdateNRINERIF_LeaveDdTime(string pid, string ptcmhsno, string leaveDd, string leaveTime)
        {
            // try...catch 는 call 하는 쪽에서 건다.

            // 응급의학과가 아닌 경우 리턴.
            DataTable dt = new DataTable();
            string sqltext = SQL_OR.Sql.SelectPAOPATRT_MdcrDeptCd_ERInitAssess(pid, ptcmhsno);
            DBService.ExecuteDataTable(sqltext, ref dt);
            if (dt.Rows.Count.Equals(0) || !dt.Rows[0]["MDCR_DEPT_CD"].ToString().Equals("2400"))
                return true;

            string currentdate = DateTime.Now.ToString("yyyyMMddHHmmss");

            if (dt != null)
                dt.Dispose();
            dt = new DataTable();
            DBService.ExecuteDataTable(SQL.PA.Sql.SelectERRGSRMA(), ref dt, pid, ptcmhsno);
            if (!dt.Rows.Count.Equals(0))
            {
                // 퇴실시간이 존재하지 않을때만 수정.
                if (dt.Rows[0]["EMRM_CHOT_DT"].ToString().Contains("29991231"))
                {
                    // 응급실 대장의 퇴실일시를 업데이트 한다.
                    if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateERRGSRMA_LEAVE(), string.Format($"{leaveDd}{leaveTime}")
                                                                                    , currentdate
                                                                                    , DOPack.UserInfo.USER_CD
                                                                                    , pid
                                                                                    , ptcmhsno))
                        return false;
                }
            }

            // 응급실 간호초기평가지(NEDIS)가 존재하지 않는 경우 리턴.
            if (dt != null)
                dt.Dispose();
            dt = new DataTable();
            DBService.ExecuteDataTable(SQL_NR.Sql.SelectERINEXIF(), ref dt, pid, ptcmhsno);
            if (!dt.Rows.Count.Equals(0))
            {
                // 퇴실시간이 이미 존재하는 경우는 업데이트 하지 않고 리턴.
                if (!dt.Rows[0]["LEAVE_DD"].ToString().Equals("29991231"))
                    return true;

                // 응급실 간호초기평가지의 퇴실일시를 업데이트 한다.
                if (!DBService.ExecuteNonQuery(SQL_NR.Sql.UpdateERINEXIF_LeaveDdTime(), leaveDd,
                                                                                        leaveTime,
                                                                                        currentdate,
                                                                                        DOPack.UserInfo.USER_CD,
                                                                                        pid,
                                                                                        ptcmhsno))
                    return false;

                return true;
            }

            // 응급실 간호초기평가지가 존재하지 않는 경우 리턴.
            if (dt != null)
                dt.Dispose();
            dt = new DataTable();
            DBService.ExecuteDataTable(SQL_OR.Sql.SelectNRINERIF(), ref dt, pid, ptcmhsno);
            if (dt.Rows.Count.Equals(0))
                return true;

            // 퇴실시간이 이미 존재하는 경우는 업데이트 하지 않고 리턴.
            if (!dt.Rows[0]["LEAVE_DD"].ToString().Equals("29991231"))
                return true;

            // 응급실 간호초기평가지의 퇴실일시를 업데이트 한다.
            if (!DBService.ExecuteNonQuery(SQL_OR.Sql.UpdateNRINERIF_LeaveDdTime(), leaveDd,
                                                                                    leaveTime,
                                                                                    currentdate,
                                                                                    DOPack.UserInfo.USER_CD,
                                                                                    pid,
                                                                                    ptcmhsno))
                return false;

            return true;
        }

        /// <summary>
        /// 처방그룹코드에 대한 세부코드를 툴팁으로 보여준다.
        /// </summary>
        /// <param name="spread"></param>
        /// <param name="e"></param>
        /// <param name="row"></param>
        /// <param name="tag"></param>
        /// <param name="mdcr_dd"></param>
        public static void TextTipGroupDetailCode(LxSpread spread, FarPoint.Win.Spread.TextTipFetchEventArgs e, string code_tag, string view_tag, string mdcr_dd)
        {
            DataTable dt = new DataTable();
            string prsc_cd = spread.GetValue(e.Row, code_tag).ToString();
            string mefe_hnm = string.Empty;

            if (string.IsNullOrWhiteSpace(prsc_cd))
                return;

            if (!DBService.ExecuteDataTable(SQL_OR.Sql.SelectMefeCdBIMFGRMA(), ref dt
                                                                             , prsc_cd
                                                                             , mdcr_dd))
                return;

            if (dt.Rows.Count > 0)
            {
                int max_length = 0;

                //코드는 조회한것 중에 가장 긴코드 length를 가지고 있는다.
                foreach (DataRow dr in dt.Rows)
                {
                    if (max_length < dr["MEFE_CD"].ToString().Length)
                        max_length = dr["MEFE_CD"].ToString().Length;
                }

                //max_length에 스페이스 한칸 기준으로 정렬 - 원래는 max_length + 1 이나 각 괄호 2개가 있으므로..
                foreach (DataRow dr in dt.Rows)
                {
                    if (string.IsNullOrEmpty(mefe_hnm))
                        mefe_hnm = ("[" + dr["MEFE_CD"].ToString() + "]").PadRight(max_length + 3) + StringService.AddSpaceLength(StringService.PadRight(dr["MEFE_HNM"].ToString(), 50, true), 50, ' ').Trim();
                    else
                        mefe_hnm += "\r\n" + ("[" + dr["MEFE_CD"].ToString() + "]").PadRight(max_length + 3) + StringService.AddSpaceLength(StringService.PadRight(dr["MEFE_HNM"].ToString(), 50, true), 50, ' ').Trim();
                }

                e.ShowTip = true;
                e.View.TextTipAppearance.Font = new Font("맑은 고딕", 10f, FontStyle.Bold);
                e.View.TextTipAppearance.ForeColor = Color.Black;
                e.TipText = mefe_hnm;
            }
        }

        /// <summary>
        /// 처방정보를 불러온다.
        /// </summary>
        /// <returns></returns>
        public static DataRow GetMefeInfo(string mefe_cd, string mdcr_dd, string wmon_yn, ref string errmsg)
        {
            DataTable dt = new DataTable();
            string mefemsg = string.Empty;

            if (!(DBService.ExecuteDataTable(SQL_OR.Sql.SelectMefeCdE(), ref dt
                                                                       , mefe_cd
                                                                       , mdcr_dd
                                                                       , wmon_yn)))
            {
                errmsg = "처방 조회 중 오류가 발생했습니다.";
                return null;
            }

            if (dt.Rows.Count > 0)
                return dt.Rows[0];
            else
                return null;

        }

        public static void SetOrderColor(string test, LxSpread spr, string pid, string otpt_adms_dvcd, string pt_cmhs_no, bool specialRow = false, int row = -1)
        {
            if (spr.RowCount <= 0)
                return;

            DataTable prsc_aply_cmhs_no = new DataTable();

            // 부입원 정보의 내원번호 조회
            if (otpt_adms_dvcd == "I")
                DBService.ExecuteDataTable(SQL_OR.Sql.SelectSubAdmsDvcdPtCmhsNoListPAIPATRT(), ref prsc_aply_cmhs_no, pid, pt_cmhs_no);

            for (int i = 0; i < spr.ActiveSheet.RowCount; i++)
            {
                if (specialRow && row != i)
                    continue;

                if (spr.GetValue(i, "TITLECODE").ToString() != "3")
                    continue;

                if (string.IsNullOrWhiteSpace(spr.GetValue(i, "PRSC_CD").ToString()))
                    continue;

                Color rowForeColor = Color.Transparent;
                Font rowFont = null;
                Color prscDvcdForeColor = Color.Transparent;

                // PICKUP(입원)
                if (otpt_adms_dvcd == "I")
                {
                    if (spr.GetValue(i, "PRSC_INPT_DVCD").ToString() == "99")
                    {
                        rowFont = new Font("맑은 고딕", 10F, System.Drawing.FontStyle.Bold);
                        rowForeColor = Color.DarkGreen;
                    }
                    else if (spr.GetValue(i, "PCUP_YN").ToString() == "Y")
                    {
                        rowForeColor = Color.FromArgb(0, 0, 0, 183);
                    }
                }
                else
                {
                    if (spr.GetValue(i, "RCPT_YN").ToString() == "Y")
                        rowForeColor = Color.FromArgb(0, 0, 0, 183);
                }

                // 처방구분 색 변경
                switch (spr.GetValue(i, "PRSC_DVCD").ToString())
                {
                    // 응급
                    case "E":
                        prscDvcdForeColor = Color.FromArgb(0, 255, 0, 0);
                        break;

                    // 원외
                    case "W":
                        prscDvcdForeColor = Color.FromArgb(0, 0, 0, 255);
                        break;

                    // PRN
                    case "P":
                        prscDvcdForeColor = Color.FromArgb(0, 0, 80, 0);
                        break;
                }

                // 오더화면표시, 오더링 메세지, 오더화 코드는 초록색으로
                // 2018-11-05 김남훈 먼저 고위험, 고주의 약은 빨간색으로 표시, 아니라면 심사정보를 표시
                if (spr.GetTagToColumnIndex("HGRS_MDPR_DVCD") >= 0 && spr.GetTagToColumnIndex("HGAL_MDPR_DVCD") >= 0)
                {
                    string hgrs_mdpr_dvcd = string.Empty;
                    string hgal_mdpr_dvcd = string.Empty;

                    hgrs_mdpr_dvcd = spr.GetValue(i, "HGRS_MDPR_DVCD").ToString();
                    hgal_mdpr_dvcd = spr.GetValue(i, "HGAL_MDPR_DVCD").ToString();

                    if (!(string.IsNullOrWhiteSpace(hgrs_mdpr_dvcd) && hgrs_mdpr_dvcd != "N") || !(string.IsNullOrWhiteSpace(hgal_mdpr_dvcd) && hgal_mdpr_dvcd != "N"))
                        spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("MSG_VIEW")].BackColor = Color.Red;
                    else
                    {
                        if (spr.GetValue(i, "MSG_DVCD").ToString() == "Y")
                        {
                            spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("MSG_VIEW")].BackColor = Color.Green;
                        }
                    }
                }
                else
                {
                    if (spr.GetValue(i, "MSG_DVCD").ToString() == "Y")
                    {
                        spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("MSG_VIEW")].BackColor = Color.Green;
                    }
                }

                // 검사 접수 및 결과 표시
                if (spr.GetValue(i, "SUPT_DEPT_RCPN_YN").ToString() == "Y")
                {
                    if (spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW") >= 0)
                    {
                        if (spr.GetValue(i, "PHTG_YN").ToString() == "Y")
                            spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW")].BackColor = Color.Yellow;
                        else
                            spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW")].BackColor = Color.Silver;
                    }

                }

                if (spr.GetValue(i, "DLVR_DEPT_CD").ToString() == "PMR" && spr.GetValue(i, "PHTG_YN").ToString() == "Y" && spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW") >= 0)
                    spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW")].BackColor = Color.Silver;

                // 결과 확정여부 표시
                if (spr.GetValue(i, "RSLT_DFNT_YN").ToString() == "Y")
                {
                    if (spr.GetTagToColumnIndex("RSLT_DFNT_YN_VIEW") >= 0)
                        spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("RSLT_DFNT_YN_VIEW")].BackColor = Color.Red;
                }
                else if (spr.GetValue(i, "RSLT_YN").ToString() == "Y")
                {
                    if (spr.GetTagToColumnIndex("RSLT_DFNT_YN_VIEW") >= 0)
                        spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("RSLT_DFNT_YN_VIEW")].BackColor = Color.Green;
                }

                // 부입원 처방 표시
                if (otpt_adms_dvcd == "I")
                {
                    if (prsc_aply_cmhs_no.Rows.Count > 0 && !string.IsNullOrWhiteSpace(spr.GetValue(i, "PRSC_APLY_CMHS_NO").ToString()))
                    {
                        for (int k = 0; k < prsc_aply_cmhs_no.Rows.Count; k++)
                        {
                            if (spr.GetValue(i, "PRSC_APLY_CMHS_NO").ToString() == prsc_aply_cmhs_no.Rows[k]["PT_CMHS_NO"].ToString())
                            {
                                if (spr.GetTagToColumnIndex("SUB_ADMS_VIEW") >= 0)
                                    spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("SUB_ADMS_VIEW")].BackColor = Color.Green;
                            }
                        }
                    }
                }

                if (string.IsNullOrWhiteSpace(spr.GetValue(i, "PRSC_LCLS_CD").ToString()))
                    continue;

                //// 2018-08-16 김남훈
                //// 2018-11-26 김남훈 수탁처방은 {수탁}으로 표시해서 색 표시 삭제
                //// 수탁 처방 표시 (대분류 40, 중분류 19보다 클 때[보라색])
                //if(spr.GetValue(i, "PRSC_LCLS_CD").ToString() == "40")
                //{
                //    if(StringService.IsNumeric(spr.GetValue(i, "PRSC_MCLS_CD").ToString()))
                //    {
                //        if(int.Parse(spr.GetValue(i, "PRSC_MCLS_CD").ToString()) >= 19)
                //            spr.ActiveSheet.Rows[i].ForeColor = Color.Purple;
                //    }
                //}

                // Stop/Hold처방 빨간색으로
                if (spr.GetValue(i, "PRSC_STOP_DVCD").ToString() == "H" || spr.GetValue(i, "PRSC_STOP_DVCD").ToString() == "S")
                    spr.ActiveSheet.Rows[i].ForeColor = Color.FromArgb(0, 255, 0, 0);

                // DC 빨간색으로
                if (spr.GetValue(i, "DC_PRSC_DVCD").ToString() == "D" || (spr.GetValue(i, "PRSC_LCLS_CD").ToString() == "41" && decimal.Parse(spr.GetValue(i, "ONTM_QTY").ToString()) < 0))
                    spr.ActiveSheet.Rows[i].ForeColor = Color.FromArgb(0, 255, 0, 0);

                // 2018-08-16 김남훈 DC 원처방 표시
                if (ConfigService.GetConfigValueString("OR", "ORDER_COLOR_OPTION", "DC_ORIGINAL_ORDER").ToString() == "Y" && spr.GetValue(i, "DC_PRSC_DVCD").ToString() == "F")
                    spr.ActiveSheet.Rows[i].ForeColor = Color.FromArgb(0, 255, 0, 0);

                // 2018-10-02 김남훈 급비구분 표시
                switch (spr.GetValue(i, "PNPY_DVCD").ToString())
                {

                    case "1":   // 급여
                        break;
                    case "2":   // 보험100   #FFFF99
                        // 선별급여 칼럼이 있을때만 100/50, 100/80 표시
                        // 100/50   #BBA8D4
                        // 100/80   #FDA5F9
                        if (spr.GetTagToColumnIndex("I100_USCH_CD") >= 0)
                        {
                            // 01 100분의 50
                            if (spr.GetValue(i, "I100_USCH_CD").ToString() == "01")
                                spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 187, 168, 212);
                            // 02 100분의 80
                            else if (spr.GetValue(i, "I100_USCH_CD").ToString() == "02")
                                spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 253, 165, 249);
                            else
                                spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 255, 255, 153);
                        }
                        else
                            spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 255, 255, 153);
                        break;
                    case "3":   // 의학적비급여
                        spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.Purple;
                        break;
                    case "4":   // 비급여   #6CA1D2
                        spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 108, 161, 210);
                        break;
                    case "5":   // 미산정
                        break;
                }

                // 2018-10-08 김남훈 외래시행여부 표시
                if (otpt_adms_dvcd == "O")
                {
                    string rcpt_yn = string.Empty;
                    string ptaf_clcl_aply_yn = string.Empty;
                    string prv_actg_yn = string.Empty;

                    if (spr.GetValue(i, "TITLECODE").ToString() == "3")
                    {
                        rcpt_yn = spr.GetValue(i, "RCPT_YN").ToString();
                        ptaf_clcl_aply_yn = spr.GetValue(i, "PTAF_CLCL_APLY_YN").ToString();
                        prv_actg_yn = spr.GetValue(i, "PRV_ACTG_YN").ToString();

                        if (rcpt_yn == "Y" || ptaf_clcl_aply_yn == "Y" || prv_actg_yn == "Y")
                            spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PRV_ACTG_YN"].Index].BackColor = Color.FromArgb(255, 255, 0, 0);
                    }
                }

                if (spr.GetValue(i, "TITLECODE").ToString() == "3" &&
                    spr.GetValue(i, "PRV_ACTG_YN").ToString() == "Y" &&
                    new string[] { "20", "30" }.Any(s => s == spr.GetValue(i, "PRSC_LCLS_CD").ToString()) &&
                    !string.IsNullOrWhiteSpace(spr.GetValue(i, "PRSC_UNIQ_NO").ToString()) &&
                    DBService.ExecuteInteger($"select count(*) from pmlgefma where prsc_uniq_no = {spr.GetValue(i, "PRSC_UNIQ_NO").ToString()} and nr_cnfr_yn = 'Y' and del_yn = 'A'") > 0
                    )
                {
                    spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PRV_ACTG_YN"].Index].BackColor = Color.FromArgb(255, 255, 0);
                }

                // 대분류별로 색상 표시
                switch (spr.GetValue(i, "PRSC_LCLS_CD").ToString())
                {
                    case "1A":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 243, 243, 243);
                        break;
                    case "30":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 255, 240, 240);
                        break;
                    case "20":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 242, 255, 255);
                        break;
                    case "50":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 245, 241, 245);
                        break;
                    case "70":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 255, 234, 213);
                        break;
                    case "40":
                    case "41":
                    case "42":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 237, 252, 235);
                        break;
                    case "I0":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 245, 241, 245);
                        break;
                    default:
                        continue;
                }

                if (rowForeColor != Color.Transparent)
                    spr.ActiveSheet.Rows[i].ForeColor = rowForeColor;

                if (rowFont != null)
                    spr.ActiveSheet.Rows[i].Font = rowFont;

                if (prscDvcdForeColor != Color.Transparent)
                    spr.GetCell(i, "PRSC_DVCD").ForeColor = prscDvcdForeColor;

                spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PID"].Index].BackColor = spr.ActiveSheet.Rows[i].BackColor;

            }
        }

        /// <summary>
        /// 처방 오더색을 변환한다.
        /// </summary>
        /// <param name="spr"></param>
        public static void SetOrderColor(LxSpread spr, string pid, string otpt_adms_dvcd, string pt_cmhs_no)
        {
            if (ConfigService.GetConfigValueDirect("OR", "ORDER_COLOR_OPTION", "USE_COMMON").Equals("Y"))
            {
                SetOrderColorCommon(spr, pid, otpt_adms_dvcd, pt_cmhs_no, -1);
                return;
            }

            DataTable prsc_aply_cmhs_no = new DataTable();

            if (spr.ActiveSheet.RowCount > 0 && otpt_adms_dvcd == "I")
            {
                // 부입원 정보의 내원번호 조회
                DBService.ExecuteDataTable(SQL_OR.Sql.SelectSubAdmsDvcdPtCmhsNoListPAIPATRT(), ref prsc_aply_cmhs_no
                                                                                             , pid
                                                                                             , pt_cmhs_no);
            }

            for (int i = 0; i < spr.ActiveSheet.RowCount; i++)
            {
                if (spr.GetValue(i, "TITLECODE").ToString() != "3")
                    continue;

                if (string.IsNullOrWhiteSpace(spr.GetValue(i, "PRSC_CD").ToString()) && spr.GetValue(i, "TITLECODE").ToString() == "3")
                    continue;

                // PICKUP(입원)
                if (otpt_adms_dvcd == "I")
                {
                    if (spr.GetValue(i, "PRSC_INPT_DVCD").ToString() == "99")
                    {
                        spr.ActiveSheet.Rows[i].Font = new Font("맑은 고딕", 10F, System.Drawing.FontStyle.Bold);
                        spr.ActiveSheet.Rows[i].ForeColor = Color.DarkGreen;
                    }
                    else
                    {
                        if (spr.GetValue(i, "PCUP_YN").ToString() == "Y")
                            spr.ActiveSheet.Rows[i].ForeColor = Color.FromArgb(0, 0, 0, 183);
                    }
                }
                else
                {
                    if (spr.GetValue(i, "RCPT_YN").ToString() == "Y")
                        spr.ActiveSheet.Rows[i].ForeColor = Color.FromArgb(0, 0, 0, 183);
                }

                // 처방구분 색 변경
                // 응급
                if (spr.GetValue(i, "PRSC_DVCD").ToString() == "E")
                    spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PRSC_DVCD"].Index].ForeColor = Color.FromArgb(0, 255, 0, 0);
                // 원외
                else if (spr.GetValue(i, "PRSC_DVCD").ToString() == "W")
                    spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PRSC_DVCD"].Index].ForeColor = Color.FromArgb(0, 0, 0, 255);
                // PRN
                else if (spr.GetValue(i, "PRSC_DVCD").ToString() == "P")
                    spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PRSC_DVCD"].Index].ForeColor = Color.FromArgb(0, 0, 80, 0);

                // 오더화면표시, 오더링 메세지, 오더화 코드는 초록색으로
                // 2018-11-05 김남훈 먼저 고위험, 고주의 약은 빨간색으로 표시, 아니라면 심사정보를 표시
                if (spr.GetTagToColumnIndex("HGRS_MDPR_DVCD") >= 0 && spr.GetTagToColumnIndex("HGAL_MDPR_DVCD") >= 0)
                {
                    string hgrs_mdpr_dvcd = string.Empty;
                    string hgal_mdpr_dvcd = string.Empty;

                    hgrs_mdpr_dvcd = spr.GetValue(i, "HGRS_MDPR_DVCD").ToString();
                    hgal_mdpr_dvcd = spr.GetValue(i, "HGAL_MDPR_DVCD").ToString();

                    if (!(string.IsNullOrWhiteSpace(hgrs_mdpr_dvcd) && hgrs_mdpr_dvcd != "N") || !(string.IsNullOrWhiteSpace(hgal_mdpr_dvcd) && hgal_mdpr_dvcd != "N"))
                        spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("MSG_VIEW")].BackColor = Color.Red;
                    else
                    {
                        if (spr.GetValue(i, "MSG_DVCD").ToString() == "Y")
                        {
                            spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("MSG_VIEW")].BackColor = Color.Green;
                        }
                    }
                }
                else
                {
                    if (spr.GetValue(i, "MSG_DVCD").ToString() == "Y")
                    {
                        spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("MSG_VIEW")].BackColor = Color.Green;
                    }
                }

                // 검사 접수 및 결과 표시
                if (spr.GetValue(i, "SUPT_DEPT_RCPN_YN").ToString() == "Y")
                {
                    if (spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW") >= 0)
                    {
                        if (spr.GetValue(i, "PHTG_YN").ToString() == "Y")
                            spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW")].BackColor = Color.Yellow;
                        else
                            spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW")].BackColor = Color.Silver;
                    }

                }

                if (spr.GetValue(i, "DLVR_DEPT_CD").ToString() == "PMR" && spr.GetValue(i, "PHTG_YN").ToString() == "Y" && spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW") >= 0)
                    spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW")].BackColor = Color.Silver;

                // 결과 확정여부 표시
                if (spr.GetValue(i, "RSLT_DFNT_YN").ToString() == "Y")
                {
                    if (spr.GetTagToColumnIndex("RSLT_DFNT_YN_VIEW") >= 0)
                        spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("RSLT_DFNT_YN_VIEW")].BackColor = Color.Red;
                }
                else if (spr.GetValue(i, "RSLT_YN").ToString() == "Y")
                {
                    if (spr.GetTagToColumnIndex("RSLT_DFNT_YN_VIEW") >= 0)
                        spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("RSLT_DFNT_YN_VIEW")].BackColor = Color.Green;
                }

                // 부입원 처방 표시
                if (otpt_adms_dvcd == "I")
                {
                    if (prsc_aply_cmhs_no.Rows.Count > 0 && !string.IsNullOrWhiteSpace(spr.GetValue(i, "PRSC_APLY_CMHS_NO").ToString()))
                    {
                        for (int k = 0; k < prsc_aply_cmhs_no.Rows.Count; k++)
                        {
                            if (spr.GetValue(i, "PRSC_APLY_CMHS_NO").ToString() == prsc_aply_cmhs_no.Rows[k]["PT_CMHS_NO"].ToString())
                            {
                                if (spr.GetTagToColumnIndex("SUB_ADMS_VIEW") >= 0)
                                    spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("SUB_ADMS_VIEW")].BackColor = Color.Green;
                            }
                        }
                    }
                }

                if (string.IsNullOrWhiteSpace(spr.GetValue(i, "PRSC_LCLS_CD").ToString()))
                    continue;

                //// 2018-08-16 김남훈
                //// 2018-11-26 김남훈 수탁처방은 {수탁}으로 표시해서 색 표시 삭제
                //// 수탁 처방 표시 (대분류 40, 중분류 19보다 클 때[보라색])
                //if(spr.GetValue(i, "PRSC_LCLS_CD").ToString() == "40")
                //{
                //    if(StringService.IsNumeric(spr.GetValue(i, "PRSC_MCLS_CD").ToString()))
                //    {
                //        if(int.Parse(spr.GetValue(i, "PRSC_MCLS_CD").ToString()) >= 19)
                //            spr.ActiveSheet.Rows[i].ForeColor = Color.Purple;
                //    }
                //}

                // Stop/Hold처방 빨간색으로
                if (spr.GetValue(i, "PRSC_STOP_DVCD").ToString() == "H" || spr.GetValue(i, "PRSC_STOP_DVCD").ToString() == "S")
                    spr.ActiveSheet.Rows[i].ForeColor = Color.FromArgb(0, 255, 0, 0);

                // DC 빨간색으로
                if (spr.GetValue(i, "DC_PRSC_DVCD").ToString() == "D" || (spr.GetValue(i, "PRSC_LCLS_CD").ToString() == "41" && decimal.Parse(spr.GetValue(i, "ONTM_QTY").ToString()) < 0))
                    spr.ActiveSheet.Rows[i].ForeColor = Color.FromArgb(0, 255, 0, 0);

                // 2018-08-16 김남훈 DC 원처방 표시
                if (ConfigService.GetConfigValueString("OR", "ORDER_COLOR_OPTION", "DC_ORIGINAL_ORDER").ToString() == "Y" && spr.GetValue(i, "DC_PRSC_DVCD").ToString() == "F")
                    spr.ActiveSheet.Rows[i].ForeColor = Color.FromArgb(0, 255, 0, 0);

                // 2018-10-02 김남훈 급비구분 표시
                switch (spr.GetValue(i, "PNPY_DVCD").ToString())
                {

                    case "1":   // 급여
                        break;
                    case "2":   // 보험100   #FFFF99
                        // 선별급여 칼럼이 있을때만 100/50, 100/80 표시
                        // 100/50   #BBA8D4
                        // 100/80   #FDA5F9
                        if (spr.GetTagToColumnIndex("I100_USCH_CD") >= 0)
                        {
                            // 01 100분의 50
                            if (spr.GetValue(i, "I100_USCH_CD").ToString() == "01")
                                spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 187, 168, 212);
                            // 02 100분의 80
                            else if (spr.GetValue(i, "I100_USCH_CD").ToString() == "02")
                                spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 253, 165, 249);
                            else
                                spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 255, 255, 153);
                        }
                        else
                            spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 255, 255, 153);
                        break;
                    case "3":   // 의학적비급여
                        spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.Purple;
                        break;
                    case "4":   // 비급여   #6CA1D2
                        spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 108, 161, 210);
                        break;
                    case "5":   // 미산정
                        break;
                }

                // 2018-10-08 김남훈 외래시행여부 표시
                if (otpt_adms_dvcd == "O")
                {
                    string rcpt_yn = string.Empty;
                    string ptaf_clcl_aply_yn = string.Empty;
                    string prv_actg_yn = string.Empty;

                    if (spr.GetValue(i, "TITLECODE").ToString() == "3")
                    {
                        rcpt_yn = spr.GetValue(i, "RCPT_YN").ToString();
                        ptaf_clcl_aply_yn = spr.GetValue(i, "PTAF_CLCL_APLY_YN").ToString();
                        prv_actg_yn = spr.GetValue(i, "PRV_ACTG_YN").ToString();

                        if (rcpt_yn == "Y" || ptaf_clcl_aply_yn == "Y" || prv_actg_yn == "Y")
                            spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PRV_ACTG_YN"].Index].BackColor = Color.FromArgb(255, 255, 0, 0);
                    }
                }

                if (spr.GetValue(i, "TITLECODE").ToString() == "3" &&
                    spr.GetValue(i, "PRV_ACTG_YN").ToString() == "Y" &&
                    new string[] { "20", "30" }.Any(s => s == spr.GetValue(i, "PRSC_LCLS_CD").ToString()) &&
                    !string.IsNullOrWhiteSpace(spr.GetValue(i, "PRSC_UNIQ_NO").ToString()) &&
                    DBService.ExecuteInteger($"select count(*) from pmlgefma where prsc_uniq_no = {spr.GetValue(i, "PRSC_UNIQ_NO").ToString()} and nr_cnfr_yn = 'Y' and del_yn = 'A'") > 0
                    )
                {
                    spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PRV_ACTG_YN"].Index].BackColor = Color.FromArgb(255, 255, 0);
                }

                // 대분류별로 색상 표시
                switch (spr.GetValue(i, "PRSC_LCLS_CD").ToString())
                {
                    case "1A":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 243, 243, 243);
                        break;
                    case "30":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 255, 240, 240);
                        break;
                    case "20":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 242, 255, 255);
                        break;
                    case "50":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 245, 241, 245);
                        break;
                    case "70":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 255, 234, 213);
                        break;
                    case "40":
                    case "41":
                    case "42":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 237, 252, 235);
                        break;
                    case "I0":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 245, 241, 245);
                        break;
                    default:
                        continue;
                }

                spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PID"].Index].BackColor = spr.ActiveSheet.Rows[i].BackColor;

            }
        }

        /// <summary>
        /// 처방 오더색을 변환한다.(Row단위)
        /// </summary>
        /// <param name="spr"></param>
        public static void SetOrderColor(LxSpread spr, string pid, string otpt_adms_dvcd, string pt_cmhs_no, int row)
        {
            if (ConfigService.GetConfigValueDirect("OR", "ORDER_COLOR_OPTION", "USE_COMMON").Equals("Y"))
            {
                SetOrderColorCommon(spr, pid, otpt_adms_dvcd, pt_cmhs_no, row);
                return;
            }

            DataTable prsc_aply_cmhs_no = new DataTable();

            if (spr.ActiveSheet.RowCount > 0 && otpt_adms_dvcd == "I")
            {
                // 부입원 정보의 내원번호 조회
                DBService.ExecuteDataTable(SQL_OR.Sql.SelectSubAdmsDvcdPtCmhsNoListPAIPATRT(), ref prsc_aply_cmhs_no
                                                                                             , pid
                                                                                             , pt_cmhs_no);
            }

            if (spr.GetValue(row, "TITLECODE").ToString() != "3")
                return;

            if (string.IsNullOrWhiteSpace(spr.GetValue(row, "PRSC_CD").ToString()) && spr.GetValue(row, "TITLECODE").ToString() == "3")
                return;

            // PICKUP(입원)
            if (otpt_adms_dvcd == "I")
            {
                if (spr.GetValue(row, "PRSC_INPT_DVCD").ToString() == "99")
                {
                    spr.ActiveSheet.Rows[row].Font = new Font("맑은 고딕", 10F, System.Drawing.FontStyle.Bold);
                    spr.ActiveSheet.Rows[row].ForeColor = Color.DarkGreen;
                }
                else
                {
                    if (spr.GetValue(row, "PCUP_YN").ToString() == "Y")
                        spr.ActiveSheet.Rows[row].ForeColor = Color.FromArgb(0, 0, 0, 183);
                }
            }
            else
            {
                if (spr.GetValue(row, "RCPT_YN").ToString() == "Y")
                    spr.ActiveSheet.Rows[row].ForeColor = Color.FromArgb(0, 0, 0, 183);
            }

            // 처방구분 색 변경
            // 응급
            if (spr.GetValue(row, "PRSC_DVCD").ToString() == "E")
                spr.ActiveSheet.Cells[row, spr.ActiveSheet.Columns["PRSC_DVCD"].Index].ForeColor = Color.FromArgb(0, 255, 0, 0);
            // 원외
            else if (spr.GetValue(row, "PRSC_DVCD").ToString() == "W")
                spr.ActiveSheet.Cells[row, spr.ActiveSheet.Columns["PRSC_DVCD"].Index].ForeColor = Color.FromArgb(0, 0, 0, 255);
            // PRN
            else if (spr.GetValue(row, "PRSC_DVCD").ToString() == "P")
                spr.ActiveSheet.Cells[row, spr.ActiveSheet.Columns["PRSC_DVCD"].Index].ForeColor = Color.FromArgb(0, 0, 80, 0);

            // 오더화면표시, 오더링 메세지, 오더화 코드는 초록색으로
            // 2018-11-05 김남훈 먼저 고위험, 고주의 약은 빨간색으로 표시, 아니라면 심사정보를 표시
            if (spr.GetTagToColumnIndex("HGRS_MDPR_DVCD") >= 0 && spr.GetTagToColumnIndex("HGAL_MDPR_DVCD") >= 0)
            {
                string hgrs_mdpr_dvcd = string.Empty;
                string hgal_mdpr_dvcd = string.Empty;

                hgrs_mdpr_dvcd = spr.GetValue(row, "HGRS_MDPR_DVCD").ToString();
                hgal_mdpr_dvcd = spr.GetValue(row, "HGAL_MDPR_DVCD").ToString();

                if (!(string.IsNullOrWhiteSpace(hgrs_mdpr_dvcd) && hgrs_mdpr_dvcd != "N") || !(string.IsNullOrWhiteSpace(hgal_mdpr_dvcd) && hgal_mdpr_dvcd != "N"))
                    spr.ActiveSheet.Cells[row, spr.GetTagToColumnIndex("MSG_VIEW")].BackColor = Color.Red;
                else
                {
                    if (spr.GetValue(row, "MSG_DVCD").ToString() == "Y")
                    {
                        spr.ActiveSheet.Cells[row, spr.GetTagToColumnIndex("MSG_VIEW")].BackColor = Color.Green;
                    }
                }
            }
            else
            {
                if (spr.GetValue(row, "MSG_DVCD").ToString() == "Y")
                {
                    spr.ActiveSheet.Cells[row, spr.GetTagToColumnIndex("MSG_VIEW")].BackColor = Color.Green;
                }
            }

            // 검사 접수 및 결과 표시
            if (spr.GetValue(row, "SUPT_DEPT_RCPN_YN").ToString() == "Y")
            {
                if (spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW") >= 0)
                {
                    if (spr.GetValue(row, "PHTG_YN").ToString() == "Y")
                        spr.ActiveSheet.Cells[row, spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW")].BackColor = Color.Yellow;
                    else
                        spr.ActiveSheet.Cells[row, spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW")].BackColor = Color.Silver;
                }

            }

            if (spr.GetValue(row, "DLVR_DEPT_CD").ToString() == "PMR" && spr.GetValue(row, "PHTG_YN").ToString() == "Y" && spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW") >= 0)
                spr.ActiveSheet.Cells[row, spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW")].BackColor = Color.Silver;

            // 결과 확정여부 표시
            if (spr.GetValue(row, "RSLT_DFNT_YN").ToString() == "Y")
            {
                if (spr.GetTagToColumnIndex("RSLT_DFNT_YN_VIEW") >= 0)
                    spr.ActiveSheet.Cells[row, spr.GetTagToColumnIndex("RSLT_DFNT_YN_VIEW")].BackColor = Color.Red;
            }
            else if (spr.GetValue(row, "RSLT_YN").ToString() == "Y")
            {
                if (spr.GetTagToColumnIndex("RSLT_DFNT_YN_VIEW") >= 0)
                    spr.ActiveSheet.Cells[row, spr.GetTagToColumnIndex("RSLT_DFNT_YN_VIEW")].BackColor = Color.Green;
            }

            // 부입원 처방 표시
            if (otpt_adms_dvcd == "I")
            {
                if (prsc_aply_cmhs_no.Rows.Count > 0 && !string.IsNullOrWhiteSpace(spr.GetValue(row, "PRSC_APLY_CMHS_NO").ToString()))
                {
                    for (int k = 0; k < prsc_aply_cmhs_no.Rows.Count; k++)
                    {
                        if (spr.GetValue(row, "PRSC_APLY_CMHS_NO").ToString() == prsc_aply_cmhs_no.Rows[k]["PT_CMHS_NO"].ToString())
                        {
                            if (spr.GetTagToColumnIndex("SUB_ADMS_VIEW") >= 0)
                                spr.ActiveSheet.Cells[row, spr.GetTagToColumnIndex("SUB_ADMS_VIEW")].BackColor = Color.Green;
                        }
                    }
                }
            }

            if (string.IsNullOrWhiteSpace(spr.GetValue(row, "PRSC_LCLS_CD").ToString()))
                return;

            //// 2018-08-16 김남훈
            //// 2018-11-26 김남훈 수탁처방은 {수탁}으로 표시해서 색 표시 삭제
            //// 수탁 처방 표시 (대분류 40, 중분류 19보다 클 때[보라색])
            //if(spr.GetValue(i, "PRSC_LCLS_CD").ToString() == "40")
            //{
            //    if(StringService.IsNumeric(spr.GetValue(i, "PRSC_MCLS_CD").ToString()))
            //    {
            //        if(int.Parse(spr.GetValue(i, "PRSC_MCLS_CD").ToString()) >= 19)
            //            spr.ActiveSheet.Rows[i].ForeColor = Color.Purple;
            //    }
            //}

            // Stop/Hold처방 빨간색으로
            if (spr.GetValue(row, "PRSC_STOP_DVCD").ToString() == "H" || spr.GetValue(row, "PRSC_STOP_DVCD").ToString() == "S")
                spr.ActiveSheet.Rows[row].ForeColor = Color.FromArgb(0, 255, 0, 0);

            // DC 빨간색으로
            if (spr.GetValue(row, "DC_PRSC_DVCD").ToString() == "D" || (spr.GetValue(row, "PRSC_LCLS_CD").ToString() == "41" && decimal.Parse(spr.GetValue(row, "ONTM_QTY").ToString()) < 0))
                spr.ActiveSheet.Rows[row].ForeColor = Color.FromArgb(0, 255, 0, 0);

            // 2018-08-16 김남훈 DC 원처방 표시
            if (ConfigService.GetConfigValueString("OR", "ORDER_COLOR_OPTION", "DC_ORIGINAL_ORDER").ToString() == "Y" && spr.GetValue(row, "DC_PRSC_DVCD").ToString() == "F")
                spr.ActiveSheet.Rows[row].ForeColor = Color.FromArgb(0, 255, 0, 0);

            // 2018-10-02 김남훈 급비구분 표시
            switch (spr.GetValue(row, "PNPY_DVCD").ToString())
            {

                case "1":   // 급여
                    break;
                case "2":   // 보험100   #FFFF99
                    // 선별급여 칼럼이 있을때만 100/50, 100/80 표시
                    // 100/50   #BBA8D4
                    // 100/80   #FDA5F9
                    if (spr.GetTagToColumnIndex("I100_USCH_CD") >= 0)
                    {
                        // 01 100분의 50
                        if (spr.GetValue(row, "I100_USCH_CD").ToString() == "01")
                            spr.ActiveSheet.Cells[row, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 187, 168, 212);
                        // 02 100분의 80
                        else if (spr.GetValue(row, "I100_USCH_CD").ToString() == "02")
                            spr.ActiveSheet.Cells[row, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 253, 165, 249);
                        else
                            spr.ActiveSheet.Cells[row, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 255, 255, 153);
                    }
                    else
                        spr.ActiveSheet.Cells[row, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 255, 255, 153);
                    break;
                case "3":   // 의학적비급여
                    spr.ActiveSheet.Cells[row, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.Purple;
                    break;
                case "4":   // 비급여   #6CA1D2
                    spr.ActiveSheet.Cells[row, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 108, 161, 210);
                    break;
                case "5":   // 미산정
                    break;
            }

            // 2018-10-08 김남훈 외래시행여부 표시
            if (otpt_adms_dvcd == "O")
            {
                string rcpt_yn = string.Empty;
                string ptaf_clcl_aply_yn = string.Empty;
                string prv_actg_yn = string.Empty;

                if (spr.GetValue(row, "TITLECODE").ToString() == "3")
                {
                    rcpt_yn = spr.GetValue(row, "RCPT_YN").ToString();
                    ptaf_clcl_aply_yn = spr.GetValue(row, "PTAF_CLCL_APLY_YN").ToString();
                    prv_actg_yn = spr.GetValue(row, "PRV_ACTG_YN").ToString();

                    if (rcpt_yn == "Y" || ptaf_clcl_aply_yn == "Y" || prv_actg_yn == "Y")
                        spr.ActiveSheet.Cells[row, spr.ActiveSheet.Columns["PRV_ACTG_YN"].Index].BackColor = Color.FromArgb(255, 255, 0, 0);
                }
            }

            if (spr.GetValue(row, "TITLECODE").ToString() == "3" &&
                spr.GetValue(row, "PRV_ACTG_YN").ToString() == "Y" &&
                new string[] { "20", "30" }.Any(s => s == spr.GetValue(row, "PRSC_LCLS_CD").ToString()) &&
                    !string.IsNullOrWhiteSpace(spr.GetValue(row, "PRSC_UNIQ_NO").ToString()) &&
                    DBService.ExecuteInteger($"select count(*) from pmlgefma where prsc_uniq_no = {spr.GetValue(row, "PRSC_UNIQ_NO").ToString()} and nr_cnfr_yn = 'Y' and del_yn = 'A'") > 0
                )
            {
                spr.ActiveSheet.Cells[row, spr.ActiveSheet.Columns["PRV_ACTG_YN"].Index].BackColor = Color.FromArgb(255, 255, 0);
            }

            // 대분류별로 색상 표시
            switch (spr.GetValue(row, "PRSC_LCLS_CD").ToString())
            {
                case "1A":
                    spr.ActiveSheet.Rows[row].BackColor = Color.FromArgb(255, 243, 243, 243);
                    break;
                case "30":
                    spr.ActiveSheet.Rows[row].BackColor = Color.FromArgb(255, 255, 240, 240);
                    break;
                case "20":
                    spr.ActiveSheet.Rows[row].BackColor = Color.FromArgb(255, 242, 255, 255);
                    break;
                case "50":
                    spr.ActiveSheet.Rows[row].BackColor = Color.FromArgb(255, 245, 241, 245);
                    break;
                case "70":
                    spr.ActiveSheet.Rows[row].BackColor = Color.FromArgb(255, 255, 234, 213);
                    break;
                case "40":
                case "41":
                case "42":
                    spr.ActiveSheet.Rows[row].BackColor = Color.FromArgb(255, 237, 252, 235);
                    break;
                case "I0":
                    spr.ActiveSheet.Rows[row].BackColor = Color.FromArgb(255, 245, 241, 245);
                    break;
                default:
                    return;
            }

            spr.ActiveSheet.Cells[row, spr.ActiveSheet.Columns["PID"].Index].BackColor = spr.ActiveSheet.Rows[row].BackColor;

        }

        public static void SetOrderColorCommon(LxSpread spr, string pid, string otpt_adms_dvcd, string pt_cmhs_no, int row)
        {
            DataTable prsc_aply_cmhs_no = new DataTable();

            if (spr.ActiveSheet.RowCount > 0 && otpt_adms_dvcd == "I")
            {
                // 부입원 정보의 내원번호 조회
                DBService.ExecuteDataTable(SQL_OR.Sql.SelectSubAdmsDvcdPtCmhsNoListPAIPATRT(), ref prsc_aply_cmhs_no
                                                                                             , pid
                                                                                             , pt_cmhs_no);
            }

            int strt_row = row > -1 ? row     : 0;
            int end_row  = row > -1 ? row + 1 : spr.ActiveSheet.Rows.Count;

            for (int i = strt_row; i < end_row; i++)
            {
                if (spr.GetValue(i, "TITLECODE").ToString() != "3")
                    continue;

                if (string.IsNullOrWhiteSpace(spr.GetValue(i, "PRSC_CD").ToString()) && spr.GetValue(i, "TITLECODE").ToString() == "3")
                    continue;

                // PICKUP(입원)
                if (otpt_adms_dvcd == "I")
                {
                    if (spr.GetValue(i, "PRSC_INPT_DVCD").ToString() == "99")
                    {
                        spr.ActiveSheet.Rows[i].Font = new Font("맑은 고딕", 10F, FontStyle.Bold);
                        spr.ActiveSheet.Rows[i].ForeColor = Color.DarkGreen;
                    }
                    else
                    {
                        if (spr.GetValue(i, "PCUP_YN").ToString() == "Y")
                            spr.ActiveSheet.Rows[i].ForeColor = Color.FromArgb(0, 0, 0, 183);
                    }
                }
                else
                {
                    if (spr.GetValue(i, "RCPT_YN").ToString() == "Y")
                        spr.ActiveSheet.Rows[i].ForeColor = Color.FromArgb(0, 0, 0, 183);
                }

                // 처방구분 색 변경
                // 응급
                if (spr.GetValue(i, "PRSC_DVCD").ToString() == "E")
                    spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PRSC_DVCD"].Index].ForeColor = Color.FromArgb(0, 255, 0, 0);
                // 원외
                else if (spr.GetValue(i, "PRSC_DVCD").ToString() == "W")
                    spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PRSC_DVCD"].Index].ForeColor = Color.FromArgb(0, 0, 0, 255);
                // PRN
                else if (spr.GetValue(i, "PRSC_DVCD").ToString() == "P")
                    spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PRSC_DVCD"].Index].ForeColor = Color.FromArgb(0, 0, 80, 0);

                // 오더화면표시, 오더링 메세지, 오더화 코드는 초록색으로
                // 2018-11-05 김남훈 먼저 고위험, 고주의 약은 빨간색으로 표시, 아니라면 심사정보를 표시
                if (spr.GetTagToColumnIndex("HGRS_MDPR_DVCD") >= 0 && spr.GetTagToColumnIndex("HGAL_MDPR_DVCD") >= 0)
                {
                    string hgrs_mdpr_dvcd = string.Empty;
                    string hgal_mdpr_dvcd = string.Empty;

                    hgrs_mdpr_dvcd = spr.GetValue(i, "HGRS_MDPR_DVCD").ToString();
                    hgal_mdpr_dvcd = spr.GetValue(i, "HGAL_MDPR_DVCD").ToString();

                    if (!(string.IsNullOrWhiteSpace(hgrs_mdpr_dvcd) && hgrs_mdpr_dvcd != "N") || !(string.IsNullOrWhiteSpace(hgal_mdpr_dvcd) && hgal_mdpr_dvcd != "N"))
                        spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("MSG_VIEW")].BackColor = Color.Red;
                    else
                    {
                        if (spr.GetValue(i, "MSG_DVCD").ToString() == "Y")
                        {
                            spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("MSG_VIEW")].BackColor = Color.Green;
                        }
                    }
                }
                else
                {
                    if (spr.GetValue(i, "MSG_DVCD").ToString() == "Y")
                    {
                        spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("MSG_VIEW")].BackColor = Color.Green;
                    }
                }

                // 검사 접수 및 결과 표시
                if (spr.GetValue(i, "SUPT_DEPT_RCPN_YN").ToString() == "Y")
                {
                    if (spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW") >= 0)
                    {
                        spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW")].BackColor = spr.GetValue(i, "PHTG_YN").ToString() == "Y" ?  Color.Yellow : Color.Silver;
                    }
                }

                if (spr.GetValue(i, "DLVR_DEPT_CD").ToString() == "PMR" && spr.GetValue(i, "PHTG_YN").ToString() == "Y" && spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW") >= 0)
                    spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("SUPT_DEPT_RCPN_YN_VIEW")].BackColor = Color.Silver;

                // 결과 확정여부 표시
                if (spr.GetValue(i, "RSLT_DFNT_YN").ToString() == "Y")
                {
                    if (spr.GetTagToColumnIndex("RSLT_DFNT_YN_VIEW") >= 0)
                        spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("RSLT_DFNT_YN_VIEW")].BackColor = Color.Red;
                }
                else if (spr.GetValue(i, "RSLT_YN").ToString() == "Y")
                {
                    if (spr.GetTagToColumnIndex("RSLT_DFNT_YN_VIEW") >= 0)
                        spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("RSLT_DFNT_YN_VIEW")].BackColor = Color.Green;
                }

                // 부입원 처방 표시
                if (otpt_adms_dvcd == "I")
                {
                    if (prsc_aply_cmhs_no.Rows.Count > 0 && !string.IsNullOrWhiteSpace(spr.GetValue(i, "PRSC_APLY_CMHS_NO").ToString()))
                    {
                        for (int k = 0; k < prsc_aply_cmhs_no.Rows.Count; k++)
                        {
                            if (spr.GetValue(i, "PRSC_APLY_CMHS_NO").ToString() == prsc_aply_cmhs_no.Rows[k]["PT_CMHS_NO"].ToString())
                            {
                                if (spr.GetTagToColumnIndex("SUB_ADMS_VIEW") >= 0)
                                    spr.ActiveSheet.Cells[i, spr.GetTagToColumnIndex("SUB_ADMS_VIEW")].BackColor = Color.Green;
                            }
                        }
                    }
                }

                if (string.IsNullOrWhiteSpace(spr.GetValue(i, "PRSC_LCLS_CD").ToString()))
                    continue;

                //// 2018-08-16 김남훈
                //// 2018-11-26 김남훈 수탁처방은 {수탁}으로 표시해서 색 표시 삭제
                //// 수탁 처방 표시 (대분류 40, 중분류 19보다 클 때[보라색])
                //if(spr.GetValue(i, "PRSC_LCLS_CD").ToString() == "40")
                //{
                //    if(StringService.IsNumeric(spr.GetValue(i, "PRSC_MCLS_CD").ToString()))
                //    {
                //        if(int.Parse(spr.GetValue(i, "PRSC_MCLS_CD").ToString()) >= 19)
                //            spr.ActiveSheet.Rows[i].ForeColor = Color.Purple;
                //    }
                //}

                // Stop/Hold처방 빨간색으로
                if (spr.GetValue(i, "PRSC_STOP_DVCD").ToString() == "H" || spr.GetValue(i, "PRSC_STOP_DVCD").ToString() == "S")
                    spr.ActiveSheet.Rows[i].ForeColor = Color.FromArgb(0, 255, 0, 0);

                // DC 빨간색으로
                if (spr.GetValue(i, "DC_PRSC_DVCD").ToString() == "D" || (spr.GetValue(i, "PRSC_LCLS_CD").ToString() == "41" && decimal.Parse(spr.GetValue(i, "ONTM_QTY").ToString()) < 0))
                    spr.ActiveSheet.Rows[i].ForeColor = Color.FromArgb(0, 255, 0, 0);

                // 2018-08-16 김남훈 DC 원처방 표시
                if (ConfigService.GetConfigValueString("OR", "ORDER_COLOR_OPTION", "DC_ORIGINAL_ORDER").ToString() == "Y" && spr.GetValue(i, "DC_PRSC_DVCD").ToString() == "F")
                    spr.ActiveSheet.Rows[i].ForeColor = Color.FromArgb(0, 255, 0, 0);

                // 2018-10-02 김남훈 급비구분 표시
                switch (spr.GetValue(i, "PNPY_DVCD").ToString())
                {

                    case "1":   // 급여
                        break;
                    case "2":   // 보험100   #FFFF99
                                // 선별급여 칼럼이 있을때만 100/50, 100/80 표시
                                // 100/50   #BBA8D4
                                // 100/80   #FDA5F9
                        if (spr.GetTagToColumnIndex("I100_USCH_CD") >= 0)
                        {
                            // 01 100분의 50
                            if (spr.GetValue(i, "I100_USCH_CD").ToString() == "01")
                                spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 187, 168, 212);
                            // 02 100분의 80
                            else if (spr.GetValue(i, "I100_USCH_CD").ToString() == "02")
                                spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 253, 165, 249);
                            else
                                spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 255, 255, 153);
                        }
                        else
                            spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 255, 255, 153);
                        break;
                    case "3":   // 의학적비급여
                        spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.Purple;
                        break;
                    case "4":   // 비급여   #6CA1D2
                        spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PNPY_DVCD"].Index].BackColor = Color.FromArgb(255, 108, 161, 210);
                        break;
                    case "5":   // 미산정
                        break;
                }

                // 2018-10-08 김남훈 외래시행여부 표시
                if (otpt_adms_dvcd == "O")
                {
                    string rcpt_yn = string.Empty;
                    string ptaf_clcl_aply_yn = string.Empty;
                    string prv_actg_yn = string.Empty;

                    if (spr.GetValue(i, "TITLECODE").ToString() == "3")
                    {
                        rcpt_yn = spr.GetValue(i, "RCPT_YN").ToString();
                        ptaf_clcl_aply_yn = spr.GetValue(i, "PTAF_CLCL_APLY_YN").ToString();
                        prv_actg_yn = spr.GetValue(i, "PRV_ACTG_YN").ToString();

                        if (rcpt_yn == "Y" || ptaf_clcl_aply_yn == "Y" || prv_actg_yn == "Y")
                            spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PRV_ACTG_YN"].Index].BackColor = Color.FromArgb(255, 255, 0, 0);
                    }
                }

                if (spr.GetValue(i, "TITLECODE").ToString() == "3" &&
                    spr.GetValue(i, "PRV_ACTG_YN").ToString() == "Y" &&
                    new string[] { "20", "30" }.Any(s => s == spr.GetValue(i, "PRSC_LCLS_CD").ToString()) &&
                        !string.IsNullOrWhiteSpace(spr.GetValue(i, "PRSC_UNIQ_NO").ToString()) &&
                        DBService.ExecuteInteger($"select count(*) from pmlgefma where prsc_uniq_no = {spr.GetValue(i, "PRSC_UNIQ_NO").ToString()} and nr_cnfr_yn = 'Y' and del_yn = 'A'") > 0
                    )
                {
                    spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PRV_ACTG_YN"].Index].BackColor = Color.FromArgb(255, 255, 0);
                }

                // 대분류별로 색상 표시
                switch (spr.GetValue(i, "PRSC_LCLS_CD").ToString())
                {
                    case "1A":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 243, 243, 243);
                        break;
                    case "30":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 255, 240, 240);
                        break;
                    case "20":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 242, 255, 255);
                        break;
                    case "50":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 245, 241, 245);
                        break;
                    case "70":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 255, 234, 213);
                        break;
                    case "40":
                    case "41":
                    case "42":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 237, 252, 235);
                        break;
                    case "I0":
                        spr.ActiveSheet.Rows[i].BackColor = Color.FromArgb(255, 245, 241, 245);
                        break;
                    default:
                        continue;
                }

                spr.ActiveSheet.Cells[i, spr.ActiveSheet.Columns["PID"].Index].BackColor = spr.ActiveSheet.Rows[i].BackColor;
            }
        }

        /// <summary>
        /// 약국전달 선처치 관련 픽업/수납 완료 이 후 수정처리
        /// </summary>
        /// <param name="lstPrscUniqNo"></param>
        /// <param name="currentValue"></param>
        /// <param name="msg"></param>
        /// <returns>true:update 진행/false:return</returns>
        public static bool SetDlvrPharmPrvActg(Dictionary<int, string> dicTargetPrsc, bool currentValue, ref string msg)
        {
            if (!ConfigService.GetConfigValueBool("OR", "SAVE_OPTION", "SET_PRV_ACTG_YN_PCAF"))
                return false;

            if (dicTargetPrsc.Count <= 0)
                return false;

            try
            {
                string joinPrscUniqNo = string.Join(", ", dicTargetPrsc.Select(x => $"'{x.Value}'"));

                DataTable dt = new DataTable();
                DBService.ExecuteDataTable($"SELECT * FROM ORORDRRT WHERE PRSC_UNIQ_NO IN ( {joinPrscUniqNo} )", ref dt);

                if (dt.Rows.Count <= 0)
                    return false;

                var prscData = dicTargetPrsc.Join(
                    dt.AsEnumerable(),
                    x => x.Value,
                    y => y["PRSC_UNIQ_NO"].ToString(),
                    (xx, yy) => new { Index = xx.Key, PrscUniqNo = xx.Value, PrscCd = yy["PRSC_CD"].ToString(), PrscNm = yy["PRSC_NM"].ToString(), DataRow = yy });

                joinPrscUniqNo = string.Join(", ", prscData.Select(x => $"'{x.PrscUniqNo}'"));

                // #Validation
                // 선처치X -> 선처치O
                if (!currentValue)
                {
                    DataTable dtPMPRRQIF = new DataTable();
                    DBService.ExecuteDataTable($"select prsc_uniq_no, drst_rcpn_yn from pmprrqif where prsc_uniq_no in ( {joinPrscUniqNo} )", ref dtPMPRRQIF);

                    var joinTable = prscData.GroupJoin(
                        dtPMPRRQIF.AsEnumerable(),
                        x => x.PrscUniqNo,
                        y => y["PRSC_UNIQ_NO"].ToString(),
                        (xx, yy) => new { xx.Index, xx.PrscUniqNo, xx.PrscCd, xx.PrscNm, DRST_RCPN_YN = yy.FirstOrDefault()?["DRST_RCPN_YN"].ToString() });
                    var joinNoneData = joinTable.Where(x => string.IsNullOrWhiteSpace(x.DRST_RCPN_YN));
                    var joinCmplData = joinTable.Where(x => x.DRST_RCPN_YN == "Y");

                    if (joinNoneData.Any())
                    {
                        foreach (var item in joinNoneData)
                            prscData = prscData.Where(x => x.Index != item.Index);

                        joinPrscUniqNo = string.Join(", ", prscData.Select(x => $"'{x.PrscUniqNo}'"));
                    }
                    
                    if (joinCmplData.Any())
                    {
                        msg = $"약국 의뢰내역이 접수되어 선처치 여부를 변경 할 수 없는 항목이 존재합니다.\r\n\r\n{string.Join("\r\n", joinCmplData.Select(x => $"[{(x.Index + 1).ToString().PadLeft(2, ' ')}행] {x.PrscCd}({x.PrscNm})"))}";
                        return false;
                    }
                }
                // 선처치O -> 선처치X
                else
                {
                    DataTable dtPMLGEFMA = new DataTable();
                    DBService.ExecuteDataTable($"select prsc_uniq_no from pmlgefma where prsc_uniq_no in ( {joinPrscUniqNo} ) and nr_cnfr_yn = 'Y' and del_yn = 'A'", ref dtPMLGEFMA);

                    var joinLedger = dtPMLGEFMA.AsEnumerable().Join(
                        prscData,
                        x => x["PRSC_UNIQ_NO"].ToString(),
                        y => y.PrscUniqNo,
                        (x, y) => y);

                    if (joinLedger.Any())
                    {
                        msg = $"전자장부 등록되어 선처치 여부를 변경 할 수 없는 항목이 존재합니다.\r\n\r\n{string.Join("\r\n", joinLedger.Select(x => $"[{(x.Index + 1).ToString().PadLeft(2, ' ')}행] {x.PrscCd}({x.PrscNm})"))}";
                        return false;
                    }

                    DataTable dtPMPREFIF = new DataTable();
                    DBService.ExecuteDataTable($"select prsc_uniq_no from pmprefif where prsc_uniq_no in ( {joinPrscUniqNo} ) and etc_use_cnts_1 is not null", ref dtPMPREFIF);

                    var joinEnd = dtPMPREFIF.AsEnumerable().Join(
                        prscData,
                        x => x["PRSC_UNIQ_NO"].ToString(),
                        y => y.PrscUniqNo, (x, y) => y);

                    if (joinEnd.Any())
                    {
                        msg = $"선처치 의약품 마감 되어 선처치 여부를 변경 할 수 없는 항목이 존재합니다.\r\n\r\n{string.Join("\r\n", joinEnd.Select(x => $"[{(x.Index + 1).ToString().PadLeft(2, ' ')}행] {x.PrscCd}({x.PrscNm})"))}";
                        return false;
                    }
                }

                // 선처치X -> 선처치O
                if (!currentValue)
                {
                    if (LxMessage.ShowQuestion(prscData.Count() > 1 ? "선택하신 처방에 선처치를 일괄 적용하시겠습니까?" : "선처치를 적용하시겠습니까?") != DialogResult.Yes)
                        return false;

                    DBService.BeginTransaction();

                    // 1. 약국 의뢰정보 삭제
                    if (!DBService.ExecuteNonQuery($"delete from pmprrqif where prsc_uniq_no in ( {joinPrscUniqNo} )"))
                        throw new Exception($"[{DBService.ErrorCode}] {DBService.ErrorMessage}");

                    // 2. 선처치 처리
                    if (!DBService.ExecuteNonQuery($"update orordrrt set prv_actg_yn = 'Y' where prsc_uniq_no in ( {joinPrscUniqNo} )"))
                        throw new Exception($"[{DBService.ErrorCode}] {DBService.ErrorMessage}");

                    // 3. 선처치 처방 추가
                    foreach (var item in prscData)
                    {
                        if (!DBService.ExecuteNonQuery(SQL.OR.Sql.InsertPMPREFIF()
                            , item.DataRow["PRSC_UNIQ_NO"].ToString()
                            , item.DataRow["PRSC_INPT_DVCD"].ToString()
                            , DateTimeService.ConvertDateStringToFormatString(item.DataRow["OTPT_ADMS_DVCD"].ToString() == "I" ? item.DataRow["PCUP_DT"].ToString() : item.DataRow["RGST_DT"].ToString(), "yyyyMMdd")
                            , DateTimeService.ConvertDateStringToFormatString(item.DataRow["OTPT_ADMS_DVCD"].ToString() == "I" ? item.DataRow["PCUP_DT"].ToString() : item.DataRow["RGST_DT"].ToString(), "HHmmss")
                            , item.DataRow["ACTG_DEPT_CD"].ToString()
                            , item.DataRow["PRSC_DVCD"].ToString()
                            , item.DataRow["PRSC_LCLS_CD"].ToString()
                            , item.DataRow["PRSC_MCLS_CD"].ToString()
                            , item.DataRow["DC_PRSC_DVCD"].ToString()
                            , item.DataRow["PRSC_CLSF_CD"].ToString()))
                            throw new Exception($"[{DBService.ErrorCode}] {DBService.ErrorMessage}");
                    }
                }
                // 선처치O -> 선처치X
                else
                {
                    if (LxMessage.ShowQuestion(prscData.Count() > 1 ? "선택하신 처방에 선처치를 일괄 해제하시겠습니까?" : "선처치를 해제하시겠습니까?") != DialogResult.Yes)
                        return false;

                    DBService.BeginTransaction();

                    // 1. 선처치 삭제
                    if (!DBService.ExecuteNonQuery($"delete from pmprefif where prsc_uniq_no in ( {joinPrscUniqNo} )"))
                        throw new Exception($"[{DBService.ErrorCode}] {DBService.ErrorMessage}");

                    // 2. 선처치 취소 처리
                    if (!DBService.ExecuteNonQuery($"update orordrrt set prv_actg_yn = 'N' where prsc_uniq_no in ( {joinPrscUniqNo} )"))
                        throw new Exception($"[{DBService.ErrorCode}] {DBService.ErrorMessage}");

                    // 3. 처방 임시테이블 등록
                    var cmhsList = prscData.Select(x => new { PID = x.DataRow["PID"].ToString(), PT_CMHS_NO = x.DataRow["PT_CMHS_NO"].ToString(), MDCR_DD = x.DataRow["MDCR_DD"].ToString(), OTPT_ADMS_DVCD = x.DataRow["OTPT_ADMS_DVCD"].ToString() }).Distinct();

                    foreach (var cmhs in cmhsList)
                    {
                        string dlwt_uniq_no = GetDlwtUniqNo(cmhs.PID, cmhs.MDCR_DD);

                        DataTable dtPAIPCHMA = new DataTable();

                        if (cmhs.OTPT_ADMS_DVCD == "I")
                        {
                            if (!DBService.ExecuteDataTable(SQL.OR.Sql.SelectNewPAIPCHMA(), ref dtPAIPCHMA, cmhs.PID, cmhs.PT_CMHS_NO, cmhs.MDCR_DD))
                                throw new Exception($"[{DBService.ErrorCode}] {DBService.ErrorMessage}");
                        }

                        string ward_cd = dtPAIPCHMA.Rows.Count > 0 ? dtPAIPCHMA.Rows[0]["WARD_CD"].ToString() : "";
                        string room_cd = dtPAIPCHMA.Rows.Count > 0 ? dtPAIPCHMA.Rows[0]["ROOM_CD"].ToString() : "";

                        var cmhsPrscList = prscData.Where(x => x.DataRow["PID"].ToString() == cmhs.PID &&
                                                               x.DataRow["PT_CMHS_NO"].ToString() == cmhs.PT_CMHS_NO &&
                                                               x.DataRow["MDCR_DD"].ToString() == cmhs.MDCR_DD);

                        int sqno = 0;
                        foreach (var prsc in cmhsPrscList)
                        {
                            if (!InsertORSQTPIFSub(cmhs.PID, cmhs.PT_CMHS_NO, cmhs.MDCR_DD, "PRE_ACT", ref dlwt_uniq_no, (++sqno).ToString(), prsc.DataRow["PRSC_SQNO"].ToString(), DateTime.Now.ToString("yyyyMMddHHmmss")))
                                throw new Exception("약국 처방 전달 중 오류가 발생하였습니다.");
                        }

                        // 4. 약국 의뢰 등록
                        string error_dvcd = string.Empty;
                        string error_cnts = string.Empty;

                        if (!SQL.Procedure.PR_PM_READ_PMPRRQIF(
                              cmhs.PID
                            , cmhs.PT_CMHS_NO
                            , cmhs.OTPT_ADMS_DVCD
                            , ward_cd
                            , room_cd
                            , "PRE_ACT"
                            , dlwt_uniq_no
                            , DateTime.Now.ToString("yyyyMMddHHmmss")
                            , DOPack.UserInfo.USER_CD
                            , ref error_dvcd
                            , ref error_cnts
                            ))
                            throw new Exception($"약국 처방 전달 중 오류가 발생하였습니다.\r\n[{error_dvcd}] {error_cnts}");

                        if (!UpdateORSQTPIF_DLWT_YN_Y(cmhs.PID, cmhs.PT_CMHS_NO.ToString(), dlwt_uniq_no, "PRE_ACT"))
                            throw new Exception("약국 처방 전달 완료 중 오류가 발생하였습니다.");
                    }
                }

                DBService.CommitTransaction();
                LxMessage.Show(LxMessage.MESSAGETYPE.SaveComplete);

                return true;
            }
            catch (Exception ex)
            {
                DBService.RollbackTransaction();

                LogService.ErrorLog(ex);
                msg = $"선처치 처리 중 오류가 발생하였습니다.\r\n\r\n{ex.Message}";
                return false;
            }
        }

        public static bool GetDefaultPrvActgYN(
            string pid, string pt_cmhs_no, string otpt_adms_dvcd, string mdcr_dd, string prsc_dvcd, string prsc_cd
            , string mdcr_dept_cd, string mdcr_dr_cd
            , string prsc_inpt_dvcd, string excp_resn_cd, string prsc_lcls_cd, string prsc_mcls_cd)
        {
            if (string.IsNullOrWhiteSpace(prsc_cd))
                return false;

            // 자가, PRN, 원외, 응급, 퇴원 선처치 불가
            if (new string[] { "S", "P", "W", "E", "T" }.Any(s => s == prsc_dvcd))
                return false;

            // 퇴원 선처치 불가
            if (prsc_inpt_dvcd == "99")
                return false;

            if (otpt_adms_dvcd == "O" && (string.IsNullOrWhiteSpace(excp_resn_cd) || excp_resn_cd == "NO"))
                return false;

            if ((prsc_lcls_cd == "20" && prsc_mcls_cd == "A4") || (prsc_lcls_cd == "30" && prsc_mcls_cd == "70"))
                return false;

            // > 마약 및 향정 선처치 불가
            if (new string[] { "20", "30" }.Any(s => s == prsc_lcls_cd) &&
                new string[] { "30", "40" }.Any(s => s == prsc_mcls_cd))
                return false;

            // > 진단검사, 병리검사, 방사선은 선수행 불가, 특정코드는 가능
            // 기능검사(A0) 중 심장검사(E0) 선수행 불가능
            if (new string[] { "40","42","50"}.Any(s => s == prsc_lcls_cd) &&
                new string[] { "A0", "E0"}.Any(s => s == prsc_mcls_cd))
            {
                if (DBService.ExecuteInteger(SQL.Function.SelectFN_BI_READ_BISPORDTCNT(), "EXMNRAORD", prsc_cd, mdcr_dd) <= 0)
                    return false;
            }

            // 임상시험 부서의 경우 선처치 미적용
            if (ConfigService.GetConfigValueDirect("OR", "SET_PRV_ACTG", "CHECK_CNPAT_L090", false) && mdcr_dept_cd == "L090")
                return false;

            // 선처치 특정처방 케이스의 경우 무조건 선처치 처리
            if (DBService.ExecuteInteger(SQL.Function.SelectFN_BI_READ_BISPORDTCNT(), "PRV_PRSC", prsc_cd, mdcr_dd) > 0)
                return true;

            if (string.IsNullOrWhiteSpace(excp_resn_cd))
                excp_resn_cd = "NO";

            // > 특정 부서 및 전달부서 강제 선처치 적용
            string dlvr_dept_cd = DBService.ExecuteScalar(SQL.Function.SelectFN_BI_READ_BIMFCDMA(), prsc_cd, mdcr_dd, "DLVR_DEPT_CD").ToString();
            bool use_all_dlvr_prv = ConfigService.GetConfigValueBool("OR", "ALL_DLVR_PRV_ACTG_YN", "USE_YN");
            bool contain_dlvr_prv = ConfigService.GetConfigList("OR", "ALL_DLVR_PRV_ACTG_YN").AsEnumerable().Any(x => x["CONF_CD"].ToString() == dlvr_dept_cd && x["CONF_VAL"].ToString() == "Y");

            if (!use_all_dlvr_prv || contain_dlvr_prv)
            {
                bool use_all_opa_prv      = ConfigService.GetConfigValueBool("OR", "ALL_OPA_PRV_ACTG_YN", "USE_YN") && ConfigService.GetConfigValueBool("OR", "ALL_OPA_PRV_ACTG_YN", mdcr_dept_cd);
                bool use_all_opa_prv_dept = ConfigService.GetConfigValueBool("OR", "ALL_OPA_PRV_ACTG_DEPT_YN", "USE_YN") && ConfigService.GetConfigValueBool("OR", "ALL_OPA_PRV_ACTG_DEPT_YN", DOPack.UserInfo.DEPT_CD);
                bool use_all_ipa_prv_dept = ConfigService.GetConfigValueBool("OR", "ALL_IPA_PRV_ACTG_YN", "USE_YN") && ConfigService.GetConfigValueBool("OR", "ALL_IPA_PRV_ACTG_YN", DOPack.UserInfo.DEPT_CD);

                if (otpt_adms_dvcd == "O")
                {
                    if ((use_all_opa_prv || use_all_opa_prv_dept))
                    {
                        // 예외사유 NO가 아니면서(원내처방), Admission Order가 아닐 경우
                        if (excp_resn_cd != "NO" && prsc_inpt_dvcd != "2")
                            return true;
                    }
                }

                if (otpt_adms_dvcd == "I")
                {
                    if (!(mdcr_dr_cd == DOPack.UserInfo.USER_CD && DOPack.UserInfo.DEPT_CD == "0900") && use_all_ipa_prv_dept)
                    {
                        return true;
                    }
                }

                if (SelectAllTimePrvActg(mdcr_dd))
                    return true;
            }

            return false;
        }

        public static bool SelectAllTimePrvActg(string date)
        {
            //if (string.IsNullOrWhiteSpace(date))
            date = DateTime.Now.ToString("yyyyMMdd");

            // > 특정요일 시간대 강제 선처치 적용
            string day_dvcd = DBService.ExecuteScalar(SQL.Function.SelectFN_BI_READ_DAYDVCD(), date).ToString();

            DataTable dtPrvDays = ConfigService.GetConfigList("OR", "ALL_PRV_ACTG_YN");
            // 1:토요일 / 2:공휴일 / 0:평일
            string dayCode = day_dvcd == "1" ? "SAT" : day_dvcd == "2" ? "HDAY" : "WEEK";
            string fromCode = $"{dayCode}_FROM";
            string toCode = $"{dayCode}_TO";

            var fromFilter = dtPrvDays.AsEnumerable().Where(x =>
            {
                if (!x["CONF_CD"].ToString().Contains(fromCode))
                    return false;

                string fromDateString = x["CONF_VAL"].ToString();

                if (string.IsNullOrWhiteSpace(fromDateString))
                    fromDateString = "0000";

                DateTime fromDate = DateTimeService.ConvertDateTime($"{DateTime.Now.ToString("yyyyMMdd")}{fromDateString}");

                if (fromDate > DateTime.Now)
                    return false;

                return true;
            });

            if (fromFilter.Any())
            {
                var toFilter = dtPrvDays.AsEnumerable().Where(x =>
                {
                    if (!x["CONF_CD"].ToString().Contains(toCode))
                        return false;

                    if (x["CONF_VAL"].ToString() == "0000")
                        return false;

                    if (!fromFilter.Any(y => y["CONF_CD"].ToString().Remove(0, fromCode.Length) == x["CONF_CD"].ToString().Remove(0, toCode.Length)))
                        return false;

                    string toDateString = x["CONF_VAL"].ToString();
                    DateTime toDate = DateTimeService.ConvertDateTime($"{DateTime.Now.ToString("yyyyMMdd")}{toDateString}59");

                    if (toDate < DateTime.Now)
                        return false;

                    return true;
                });

                if (toFilter.Any())
                    return true;
            }

            DateTime prvFrom;
            DateTime prvTo;

            switch (day_dvcd)
            {
                case "1": // 토요일
                    prvFrom = ConfigService.GetConfigValueDateTime("OR", "ALL_PRV_ACTG_YN", "SAT_FROM", DateTime.Today);
                    prvTo = ConfigService.GetConfigValueDateTime("OR", "ALL_PRV_ACTG_YN", "SAT_TO", DateTime.Today);
                    break;

                case "2": // 공휴일
                    prvFrom = ConfigService.GetConfigValueDateTime("OR", "ALL_PRV_ACTG_YN", "HDAY_FROM", DateTime.Today);
                    prvTo = ConfigService.GetConfigValueDateTime("OR", "ALL_PRV_ACTG_YN", "HDAY_TO", DateTime.Today);
                    break;

                default: // 평일
                    prvFrom = ConfigService.GetConfigValueDateTime("OR", "ALL_PRV_ACTG_YN", "WEEK_FROM", DateTime.Today);
                    prvTo = ConfigService.GetConfigValueDateTime("OR", "ALL_PRV_ACTG_YN", "WEEK_TO", DateTime.Today);
                    break;
            }

            if (prvFrom.ToString("HHmm") != "0000" || prvTo.ToString("HHmm") != "0000")
            {
                int.TryParse(prvFrom.ToString("HHmm"), out int from);
                int.TryParse(prvTo.ToString("HHmm"), out int to);
                int.TryParse(DateTime.Now.ToString("HHmm"), out int now);

                if (from <= now && now <= to)
                    return true;
            }

            return false;
        }

        /// <summary>
        /// 수술/마취정보를 저장한다.
        /// </summary>
        /// <param name="work_dvcd"></param>
        /// <param name="octy_dvcd"></param>
        /// <returns></returns>
        public static bool UpdateOpInfo(string otpt_adms_dvcd, string pid, string pt_cmhs_no, string mdcr_dd, string prsc_sqno, string prsc_notm, string work_dvcd,
                                 string rcpt_yn, string op_dvcd, string anst_mthd_dvcd, string anst_inhl_prdt_cd, string anst_time, string prsc_time_dvcd, string prsc_time,
                                 string emrg_adtn_yn, string mdcr_dr_cd, string popup_dvcd, ref string errmsg)
        {
            int rcpn_sqno = 0;
            string error_dvcd = string.Empty;
            string error_cnts = string.Empty;

            // 외래
            if (otpt_adms_dvcd == "O")
            {
                if (rcpt_yn == "Y")
                {
                    rcpn_sqno = DBService.ExecuteInteger(SQL_OR.Sql.SelectRcpnSqnoPAOPATRT(), pid
                                                                                            , pt_cmhs_no);

                    // 처방카운트를 변경한다/
                    if (!(SQL.Procedure.PR_PA_PRC_PAOPATRTCH(pid, pt_cmhs_no, rcpn_sqno.ToString(), "PRSC_NOTM", (int.Parse(prsc_notm) + 1).ToString(), DOPack.UserInfo.USER_CD, ref error_dvcd, ref error_cnts)))
                    {
                        errmsg = error_cnts + "\r\n처방 카운트 변경 중 오류가 발생했습니다.";
                        return false;
                    }
                }
            }

            switch (work_dvcd)
            {
                // 응급가산
                case "EMCFLAG":
                    if (!(DBService.ExecuteNonQuery(SQL_OR.Sql.UpdateMefeEMCFLAG(), pid
                                                                                 , pt_cmhs_no
                                                                                 , mdcr_dd
                                                                                 , prsc_sqno
                                                                                 , emrg_adtn_yn
                                                                                 , prsc_time_dvcd
                                                                                 , prsc_time
                                                                                 , mdcr_dr_cd
                                                                                 , popup_dvcd)))
                    {
                        errmsg = "응급가산 저장 중 오류가 발생했습니다.";
                        return false;
                    }
                    break;
                // 수술구분
                case "OPFLAG":
                    if (!(DBService.ExecuteNonQuery(SQL_OR.Sql.UpdateMefeOPFLAG(), pid
                                                                                , pt_cmhs_no
                                                                                , mdcr_dd
                                                                                , prsc_sqno
                                                                                , emrg_adtn_yn
                                                                                , op_dvcd
                                                                                , prsc_time_dvcd
                                                                                , prsc_time
                                                                                , popup_dvcd)))
                    {
                        errmsg = "수술구분 저장 중 오류가 발생했습니다.";
                        return false;
                    }
                    break;
                // 수술시간
                case "OPTIME":
                    if (!(DBService.ExecuteNonQuery(SQL_OR.Sql.UpdateMefeOPTIME(), pid
                                                                                , pt_cmhs_no
                                                                                , mdcr_dd
                                                                                , prsc_sqno
                                                                                , emrg_adtn_yn
                                                                                , prsc_time_dvcd
                                                                                , prsc_time
                                                                                , popup_dvcd)))
                    {
                        errmsg = "수술시간 저장 중 오류가 발생했습니다.";
                        return false;
                    }
                    break;
                // 마취구분
                case "ANSTFLAG":
                    if (!(DBService.ExecuteNonQuery(SQL_OR.Sql.UpdateMefeANSTFLAG(), pid
                                                                                  , pt_cmhs_no
                                                                                  , mdcr_dd
                                                                                  , prsc_sqno
                                                                                  , anst_mthd_dvcd
                                                                                  , anst_inhl_prdt_cd
                                                                                  , anst_time
                                                                                  , prsc_time_dvcd
                                                                                  , prsc_time
                                                                                  , popup_dvcd)))
                    {
                        errmsg = "마취구분 저장 중 오류가 발생했습니다.";
                        return false;
                    }
                    break;
            }

            return true;
        }

        /// <summary>
        /// 수술환자의 마취시간, 마취약제 코드를 가져온다.
        /// </summary>
        /// <param name="pid">환자번호</param>
        /// <param name="mdcr_dd">조회일자</param>
        /// <param name="errmsg">에러코드</param>
        /// <returns></returns>
        public static DataRow GetPatAnstInfo(string pid, string mdcr_dd, ref string errmsg)
        {
            // DataRow 칼럼
            // ANST_CD 마취코드
            // ANST_NM 마취명
            // ANST_TIME 소요시간
            // ANST_STRT_TIME 시작시간

            string MLAP_UNIQ_NO = string.Empty;
            DataTable dt = new DataTable();
            DataRow dr = null;

            MLAP_UNIQ_NO = DBService.ExecuteScalar(SQL_OR.Sql.SelectUniqOPREFRMA(), pid
                                                                                  , mdcr_dd).ToString();

            if (!(string.IsNullOrWhiteSpace(MLAP_UNIQ_NO)))
            {
                // TODO : 마취기록지 조회
            }

            dt.Columns.Add("ANST_CD", Type.GetType("System.String"));
            dt.Columns.Add("ANST_NM", Type.GetType("System.String"));
            dt.Columns.Add("ANST_TIME", Type.GetType("System.String"));
            dt.Columns.Add("ANST_STRT_TIME", Type.GetType("System.String"));

            dr = dt.NewRow();

            dr["ANST_CD"] = "";
            dr["ANST_NM"] = "";
            dr["ANST_TIME"] = "0000";
            dr["ANST_STRT_TIME"] = "0000";

            return dr;
        }

        /// <summary>
        /// 해당 Row의 데이터를 지정한다.
        /// </summary>
        public static void SetRowMefeData(LxSpread spr, int row)
        {
            if (spr.GetTagToColumnIndex("OLD_PRSC_CD") >= 0)
            {
                spr.SetText(row, "OLD_PRSC_CD", spr.GetValue(row, "PRSC_CD").ToString());
                spr.SetText(row, "OLD_PRSC_NM", spr.GetValue(row, "PRSC_NM").ToString());

                // Free오더가 입력되었으면 선택해준다.
                if (spr.GetValue(row, "PRSC_CD").ToString() == "-")
                    spr.SetText(row, "FREE_PRSC_CD", "Y");
            }
        }


        public static bool SaveFreeTextOrder(string pid, string pt_cmhs_no, string mdcr_dd, string otpt_adms_dvcd, string prsc_inpt_dvcd, string prsc_time, string mdcr_dept_cd, string mdcr_dr_cd, string real_prdc_cd, string actg_dept_cd, string prsc_nm, string rgst_dt, string rgstr_id)
        {
            try
            {
                string sqltext = @"
INSERT INTO ORORDRRT
(PID, PT_CMHS_NO, MDCR_DD, PRSC_SQNO, 
 PRSC_INPT_DVCD, PRSC_SORT_SEQ, OTPT_ADMS_DVCD, PRSC_DVCD, PRSC_TIME, 
 MDCR_DEPT_CD, MDCR_DR_CD, REAL_PRDC_CD, DLVR_DEPT_CD, ACTG_DEPT_CD, 
 VIST_PLCE_CD, WARD_CD, PRSC_LCLS_CD, PRSC_MCLS_CD, PRSC_CD, 
 PRSC_NM, PRSC_INPT_QTY, ONTM_QTY, APLY_ONTM_QTY, TOTL_AOMD_QTY, 
 CC_AOMD_QTY, NOTM, NODY, PNOD_PRSC_UNIQ_NO, PNOD_PRSC_PSND, 
 PNOD_PRSC_INOD, ACTN_ACTG_NOTM, AOMD_ITVL_VALU, AOMD_VLCT_VALU, AOMD_UNIT_VALU, 
 AOMD_MTHD_CD, ORIG_AOMD_MTHD_CD, MDCT_NO, MIX_YN, MOVE_PHTG_YN, 
 PWDR_YN, EXCP_RESN_CD, OUPR_GRNT_NO, PNPY_DVCD, PRV_ACTG_YN, 
 SMCR_APLY_YN, HOPE_DD, PRSC_PCFT, DC_PRSC_DVCD, ORIG_PT_CMHS_NO, 
 ORIG_MDCR_DD, ORIG_PRSC_SQNO, DEL_YN, RCPT_YN, CLCL_HOLD_YN, 
 OP_DVCD, PRSC_TIME_DVCD, EMRG_ADTN_YN, ANST_MTHD_DVCD, ANST_INHL_PRDT_CD,
 ANST_TIME, CNFR_DVCD, CNFR_CD, TRFS_PLCE_CD, PRSC_CLSF_CD,
 DNFR_RGUP_CNTS, DNFR_LFUP_CNTS, DNFR_RGHT_LOW_CNTS, DNFR_LEFT_LOW_CNTS, PRSC_INPS_DVCD,
 MAIN_INGR_CD, SPCM_CD, SPCM_RCPN_YN, SPCM_RCPN_DT, SPCM_RCPS_ID,
 SPCM_RCPN_NO, SPCM_PRNT_YN, PCUP_YN, PCUP_DT, PCUP_TGPS_ID, 
 PCUP_DEPT_CD, PRSC_STOP_DVCD, PTAF_CLCL_APLY_YN, PTAF_CLCL_ACTG_DT, PTAF_CLCL_ACTR_ID, 
 SUPT_DEPT_APNT_YN, SPDP_APNT_TIME, EXAP_MARK_CNTS, SUPT_DEPT_RCPN_YN, SUPT_DEPT_RCPN_DT, 
 SUPT_DEPT_RCPS_ID, SPDP_ACTR_ID, PHTG_YN, PHTG_RGST_DT, PHTG_RGST_ID, 
 RSLT_YN, RSLT_RGST_DT, RSLT_RGSTR_ID, RSLT_DFNT_YN, RSLT_DFNT_DT, 
 RSLT_SPFR_ID, MDED_REFR_YN, DRST_SPCL_APLY_YN, INSL_DODY, MLAP_PRSC_YN, 
 PRSC_APLY_CMHS_NO, PRSC_LAST_DD, DUR_RESN, SPLN_MDTR_DVCD, SPLN_MFMT_BNOT_VOL, 
 PYDS_ITCN_DEPT_CD, PYDS_ITCNR_ID, PYDS_ITCN_DT, PYDS_ITCN_CNFR_YN, PYDS_ITCN_CNFR_DT, 
 ORMD_ANS_YN, ORMD_ANS_CD, ORMD_ANS_NM, ORMD_SITE_APLY_YN, ORMD_SITE_APLY_CD, 
 DC_PRSC_QTY, ORIG_PRSC_DVCD, POPUP_DVCD, ETC_USE_CNTS_1,ETC_USE_CNTS_2,
 ETC_USE_CNTS_3, ETC_USE_CNTS_4, ETC_USE_CNTS_5, DLWT_IP_ADDR, RGST_DT,
 RGSTR_ID, UPDT_DT, UPDTR_ID)
VALUES 
('{0}', {1}, '{2}', {3}, 
 '{4}', {5}, '{6}', '{7}', '{8}', 
 '{9}', '{10}', '{11}', '{12}', '{13}', 
 '{14}', '{15}', '{16}', '{17}', '{18}', 
 '{19}', '{20}', {21}, {22}, {23}, 
 {24}, {25}, {26}, '{27}', {28}, 
 {29}, {30}, '{31}', '{32}', '{33}', 
 '{34}', '{35}', '{36}', '{37}', '{38}', 
 '{39}', '{40}', '{41}', '{42}', '{43}', 
 '{44}', '{45}', '{46}', '{47}', {48}, 
 '{49}', {50}, '{51}', '{52}', '{53}', 
 '{54}', '{55}', '{56}', '{57}', '{58}',
 '{59}', '{60}', '{61}', '{62}', '{63}',
 '{64}', '{65}', '{66}', '{67}', '{68}',
 '{69}', '{70}', '{71}', '{72}', '{73}',
 '{74}', '{75}', '{76}', '{77}', '{78}',
 '{79}', '{80}', '{81}', '{82}', '{83}',
 '{84}', '{85}', '{86}', '{87}', '{88}',
 '{89}', '{90}', '{91}', '{92}', '{93}',
 '{94}', '{95}', '{96}', '{97}', '{98}',
 '{99}', '{100}', '{101}', {102}, '{103}',
 {104},  '{105}', '{106}', '{107}', {108},
 '{109}', '{110}', '{111}', '{112}', '{113}',
 '{114}', '{115}', '{116}', '{117}', '{118}',
 {119}, '{120}', '{121}', '{122}', '{123}',
 '{124}', '{125}', '{126}', '{127}', '{128}',
 '{129}', '{130}', '{131}')
";
                string prsc_sqno = DBService.ExecuteScalar($"select nvl(max(prsc_sqno), 0) + 1 from orordrrt where pid = '{pid}' and pt_cmhs_no = '{pt_cmhs_no}' and mdcr_dd = '{mdcr_dd}'").ToString();
                string prsc_sort_seq = DBService.ExecuteScalar($"select nvl(max(prsc_sort_seq), 0) + 1 from orordrrt where pid = '{pid}' and pt_cmhs_no = '{pt_cmhs_no}' and mdcr_dd = '{mdcr_dd}'").ToString();

                if (!DBService.ExecuteNonQuery(sqltext
                                             , pid, pt_cmhs_no, mdcr_dd, prsc_sqno, prsc_inpt_dvcd
                                             , prsc_sort_seq, otpt_adms_dvcd, otpt_adms_dvcd, prsc_time, mdcr_dept_cd
                                             , mdcr_dr_cd, real_prdc_cd, "ZZZZ", actg_dept_cd, "00"
                                             , "", "1A", "24", "-", prsc_nm
                                             , "1", "1", "1", "1", "1"
                                             , "1", "1", "", "1", "1"
                                             , "0", "", "", "", ""
                                             , "", "", "", "N", "N"
                                             , "NO", "NO", "4", "N", "N"
                                             , mdcr_dd, "", "A", pt_cmhs_no, mdcr_dd
                                             , prsc_sqno, "A", "Y", "N", ""
                                             , "", "", "", "", ""
                                             , "000", "", "", "A", ""
                                             , "", "", "", "D", "*"
                                             , "", "N", "", "", ""
                                             , "N", "N", "", "", ""
                                             , "A", "N", "", "", "N"
                                             , "", "", "N", "", ""
                                             , "", "N", "", "", "N"
                                             , "", "", "N", "", ""
                                             , "N", "N", "NULL", "N", pt_cmhs_no
                                             , "D", "", "", "NULL", ""
                                             , "", "", "", "", "N"
                                             , "", "", "N", "", "0"
                                             , otpt_adms_dvcd, "", "", "0", ""
                                             , "", "", ClientEnvironment.IP, rgst_dt, rgstr_id
                                             , rgst_dt, rgstr_id))
                    throw new Exception($"[{DBService.ErrorCode}] {DBService.ErrorMessage}");

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
        }

        public static bool ExistIncompleteChart(string system_cd, bool is_or_mefe)
        {
            try
            {
                string dlvr_insf = "";
                string dlvr_trgt = "";

                string user_cd = DOPack.UserInfo.USER_CD;
                string octy_dvcd = DOPack.UserInfo.OCTY_DVCD;
                string dept_cd = DOPack.UserInfo.DEPT_CD;
                string dept_clsf_cd = DeptList.GetColumnValue(dept_cd, "DEPT_CLSF_CD").ToString();

                if (is_or_mefe && dept_clsf_cd == "2" && dept_cd != "ER")
                    return false;

                // 작성완료 포함여부 false => insf_cmpl_yn O 값도 제외하도록 처리
                bool wrtnContain = ClientConfig.GetConfigValueBool("popOrInCtInfoE.chkWrtnCmpl.Checked", true);
                string cmplCondition = " <> 'Y' ";

                if (!wrtnContain)
                    cmplCondition = " NOT IN ( 'Y', 'O' ) ";

                // 간호, 수술실 시스템
                if (new string[] { "NR", "OP" }.Any(s => s == system_cd) && !is_or_mefe)
                {
                    if (dept_clsf_cd != "2")
                        return false;

                    if (system_cd == "NR")
                    {
                        dlvr_insf = DOPack.UserInfo.DEPT_CD;
                        dlvr_trgt = "WARD";
                    }
                    else if (system_cd == "OP")
                    {
                        dlvr_insf = dlvr_trgt = "OP";
                    }
                }
                // 처방 등록
                else if (is_or_mefe)
                {
                    if (StringService.SubString(octy_dvcd, 1) == "N")
                    {
                        dlvr_insf = dlvr_trgt = new string[] { "2400", "ER" }.Any(s => s == DOPack.UserInfo.DEPT_CD) ? "ER" : "OUT";
                    }
                    else if (octy_dvcd == "D1")
                    {
                        dlvr_insf = user_cd;
                        dlvr_trgt = "N";
                    }
                }

                if (new string[] { dlvr_insf, dlvr_trgt }.All(s => string.IsNullOrWhiteSpace(s)))
                    return false;

                string sqltext = $@"
SELECT SUM(A.CNT)
  FROM ( SELECT COUNT(*) CNT
           FROM MRINCKMA Z
          WHERE Z.CHEK_YN = 'Y' -- 미비체크
            AND NVL(Z.ETC_USE_CNTS_1, 'N') <> 'Y' -- 점검완료X
            AND Z.DEL_YN = 'A'
            AND Z.DLVR_INSF = '{dlvr_insf}' -- 미비대상
            AND EXISTS (SELECT *
                          FROM BICDINDT X
                         WHERE X.OVRL_CD = 'REC_INC_CD'
                           AND X.LWRN_OVRL_CD = Z.GRP_CD
                           AND NVL(X.LWRN_OVRL_DETL_CD, 'N') IN ( '%', '{dlvr_trgt}' )) -- 미비대상구분
            AND Z.DSCH_ANLY_UNIQ_NO IN ( SELECT A.DSCH_ANLY_UNIQ_NO
                                           FROM PAIPATRT B
                                              , MRDSANMA A
                                          WHERE A.INSF_CHEK_YN            = 'Y'
                                            AND NVL(A.INSF_CMPL_YN, 'N') {cmplCondition}
                                            AND A.PID                     = B.PID
                                            AND A.PT_CMHS_NO              = B.PT_CMHS_NO
                                            AND B.ROW_STAT_DVCD           = 'A' )

      UNION

         SELECT COUNT(*) CNT
           FROM MRINCAMA Z
          WHERE Z.CHEK_YN = 'Y' -- 미비체크
            AND NVL(Z.ETC_USE_CNTS_1, 'N') <> 'Y' -- 점검완료X
            AND Z.DEL_YN = 'A'
            AND Z.DLVR_INSF = '{dlvr_insf}' -- 미비대상
            AND EXISTS (SELECT *
                          FROM BICDINDT X
                         WHERE X.OVRL_CD = 'REC_INC_CD'
                           AND X.LWRN_OVRL_CD = Z.GRP_CD
                           AND NVL(X.LWRN_OVRL_DETL_CD, 'N') IN ( '%', '{dlvr_trgt}' )) -- 미비대상구분
            AND Z.ADMS_INSF_UNIQ_NO IN ( SELECT A.ADMS_INSF_UNIQ_NO
                                           FROM PAIPATRT B
                                              , MRAOIFMA A
                                          WHERE A.INSF_CHEK_YN            = 'Y'
                                            AND NVL(A.INSF_CMPL_YN, 'N') {cmplCondition}
                                            AND A.PID                     = B.PID
                                            AND A.PT_CMHS_NO              = B.PT_CMHS_NO
                                            AND B.ROW_STAT_DVCD           = 'A'

                                         UNION ALL

                                         SELECT A.ADMS_INSF_UNIQ_NO
                                           FROM PAOPATRT B
                                              , MRAOIFMA A
                                          WHERE A.INSF_CHEK_YN = 'Y'
                                            AND NVL(A.INSF_CMPL_YN, 'N') {cmplCondition}
                                            AND A.PID  = B.PID
                                            AND A.PT_CMHS_NO = B.PT_CMHS_NO
                                            AND B.ROW_STAT_DVCD IN ('A', 'I') )
       ) A
";

                return DBService.ExecuteInteger(sqltext) > 0;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
        }
    }
}
