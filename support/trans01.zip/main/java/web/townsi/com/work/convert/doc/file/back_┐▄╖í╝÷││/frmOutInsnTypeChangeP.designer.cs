namespace Lime.PA
{
    partial class frmOutInsnTypeChangeP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOutInsnTypeChangeP));
            this.lxPanel1 = new Lime.Framework.Controls.LxPanel();
            this.txtAge = new Lime.Framework.Controls.LxTextBox();
            this.txtSex = new Lime.Framework.Controls.LxTextBox();
            this.txtSrrn = new Lime.Framework.Controls.LxTextBox();
            this.txtFrrn = new Lime.Framework.Controls.LxTextBox();
            this.txtPtNm = new Lime.Framework.Controls.LxTextBox();
            this.txtPid = new Lime.Framework.Controls.LxTextBox();
            this.LxTitleLabel3 = new Lime.Framework.Controls.LxTitleLabel();
            this.LxTitleLabel2 = new Lime.Framework.Controls.LxTitleLabel();
            this.LxTitleLabel1 = new Lime.Framework.Controls.LxTitleLabel();
            this.btnButtonList = new Lime.Framework.Controls.LxButtonList();
            this.lxPanel5 = new Lime.Framework.Controls.LxPanel();
            this.lblMessage = new Lime.Framework.Controls.LxLabel();
            this.lxPanel2 = new Lime.Framework.Controls.LxPanel();
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).BeginInit();
            this.pnlBase.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel1)).BeginInit();
            this.lxPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtAge)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSrrn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrrn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPtNm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnButtonList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel5)).BeginInit();
            this.lxPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lblMessage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel2)).BeginInit();
            this.lxPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBase
            // 
            this.pnlBase.Controls.Add(this.lxPanel2);
            this.pnlBase.Controls.Add(this.lxPanel1);
            this.pnlBase.Location = new System.Drawing.Point(1, 31);
            this.pnlBase.Size = new System.Drawing.Size(862, 864);
            // 
            // lxPanel1
            // 
            this.lxPanel1.BackColor = System.Drawing.Color.White;
            this.lxPanel1.Controls.Add(this.txtAge);
            this.lxPanel1.Controls.Add(this.txtSex);
            this.lxPanel1.Controls.Add(this.txtSrrn);
            this.lxPanel1.Controls.Add(this.txtFrrn);
            this.lxPanel1.Controls.Add(this.txtPtNm);
            this.lxPanel1.Controls.Add(this.txtPid);
            this.lxPanel1.Controls.Add(this.LxTitleLabel3);
            this.lxPanel1.Controls.Add(this.LxTitleLabel2);
            this.lxPanel1.Controls.Add(this.LxTitleLabel1);
            this.lxPanel1.Controls.Add(this.btnButtonList);
            this.lxPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.lxPanel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxPanel1.Location = new System.Drawing.Point(0, 0);
            this.lxPanel1.Name = "lxPanel1";
            this.lxPanel1.Padding = new System.Windows.Forms.Padding(6);
            this.lxPanel1.Size = new System.Drawing.Size(862, 40);
            this.lxPanel1.TabIndex = 0;
            // 
            // txtAge
            // 
            appearance2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance2.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance2.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance2.TextHAlignAsString = "Center";
            appearance2.TextVAlignAsString = "Middle";
            this.txtAge.Appearance = appearance2;
            this.txtAge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtAge.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtAge.Location = new System.Drawing.Point(527, 8);
            this.txtAge.Name = "txtAge";
            appearance3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance3.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance3.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtAge.NullTextAppearance = appearance3;
            this.txtAge.ReadOnly = true;
            this.txtAge.Size = new System.Drawing.Size(32, 23);
            this.txtAge.TabIndex = 3;
            this.txtAge.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtAge.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtSex
            // 
            appearance4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance4.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance4.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance4.TextHAlignAsString = "Center";
            appearance4.TextVAlignAsString = "Middle";
            this.txtSex.Appearance = appearance4;
            this.txtSex.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtSex.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtSex.Location = new System.Drawing.Point(493, 8);
            this.txtSex.Name = "txtSex";
            appearance5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance5.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance5.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtSex.NullTextAppearance = appearance5;
            this.txtSex.ReadOnly = true;
            this.txtSex.Size = new System.Drawing.Size(32, 23);
            this.txtSex.TabIndex = 3;
            this.txtSex.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtSex.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtSrrn
            // 
            appearance6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance6.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance6.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance6.TextHAlignAsString = "Center";
            appearance6.TextVAlignAsString = "Middle";
            this.txtSrrn.Appearance = appearance6;
            this.txtSrrn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtSrrn.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtSrrn.Location = new System.Drawing.Point(435, 8);
            this.txtSrrn.Name = "txtSrrn";
            appearance7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance7.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance7.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtSrrn.NullTextAppearance = appearance7;
            this.txtSrrn.ReadOnly = true;
            this.txtSrrn.Size = new System.Drawing.Size(56, 23);
            this.txtSrrn.TabIndex = 3;
            this.txtSrrn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtSrrn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtFrrn
            // 
            appearance8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance8.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance8.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance8.TextHAlignAsString = "Center";
            appearance8.TextVAlignAsString = "Middle";
            this.txtFrrn.Appearance = appearance8;
            this.txtFrrn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtFrrn.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtFrrn.Location = new System.Drawing.Point(377, 8);
            this.txtFrrn.Name = "txtFrrn";
            appearance9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance9.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance9.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFrrn.NullTextAppearance = appearance9;
            this.txtFrrn.ReadOnly = true;
            this.txtFrrn.Size = new System.Drawing.Size(56, 23);
            this.txtFrrn.TabIndex = 3;
            this.txtFrrn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtFrrn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtPtNm
            // 
            appearance10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance10.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance10.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance10.TextHAlignAsString = "Center";
            appearance10.TextVAlignAsString = "Middle";
            this.txtPtNm.Appearance = appearance10;
            this.txtPtNm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtPtNm.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtPtNm.Location = new System.Drawing.Point(218, 8);
            this.txtPtNm.Name = "txtPtNm";
            appearance11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance11.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance11.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtPtNm.NullTextAppearance = appearance11;
            this.txtPtNm.ReadOnly = true;
            this.txtPtNm.Size = new System.Drawing.Size(89, 23);
            this.txtPtNm.TabIndex = 3;
            this.txtPtNm.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtPtNm.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtPid
            // 
            appearance12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance12.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance12.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance12.TextHAlignAsString = "Center";
            appearance12.TextVAlignAsString = "Middle";
            this.txtPid.Appearance = appearance12;
            this.txtPid.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtPid.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtPid.Location = new System.Drawing.Point(70, 8);
            this.txtPid.Name = "txtPid";
            appearance13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance13.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance13.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtPid.NullTextAppearance = appearance13;
            this.txtPid.ReadOnly = true;
            this.txtPid.Size = new System.Drawing.Size(78, 23);
            this.txtPid.TabIndex = 2;
            this.txtPid.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtPid.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel3
            // 
            appearance14.BackColor = System.Drawing.Color.Transparent;
            appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance14.FontData.Name = "맑은 고딕";
            appearance14.FontData.SizeInPoints = 9F;
            appearance14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance14.TextHAlignAsString = "Right";
            appearance14.TextVAlignAsString = "Middle";
            this.LxTitleLabel3.Appearance = appearance14;
            this.LxTitleLabel3.Location = new System.Drawing.Point(317, 8);
            this.LxTitleLabel3.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel3.Name = "LxTitleLabel3";
            this.LxTitleLabel3.Size = new System.Drawing.Size(57, 23);
            this.LxTitleLabel3.TabIndex = 1;
            this.LxTitleLabel3.Text = "주민번호";
            this.LxTitleLabel3.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel3.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel2
            // 
            appearance15.BackColor = System.Drawing.Color.Transparent;
            appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance15.FontData.Name = "맑은 고딕";
            appearance15.FontData.SizeInPoints = 9F;
            appearance15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance15.TextHAlignAsString = "Right";
            appearance15.TextVAlignAsString = "Middle";
            this.LxTitleLabel2.Appearance = appearance15;
            this.LxTitleLabel2.Location = new System.Drawing.Point(158, 8);
            this.LxTitleLabel2.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel2.Name = "LxTitleLabel2";
            this.LxTitleLabel2.Size = new System.Drawing.Size(57, 23);
            this.LxTitleLabel2.TabIndex = 1;
            this.LxTitleLabel2.Text = "환자성명";
            this.LxTitleLabel2.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel2.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel1
            // 
            appearance16.BackColor = System.Drawing.Color.Transparent;
            appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance16.FontData.Name = "맑은 고딕";
            appearance16.FontData.SizeInPoints = 9F;
            appearance16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance16.TextHAlignAsString = "Right";
            appearance16.TextVAlignAsString = "Middle";
            this.LxTitleLabel1.Appearance = appearance16;
            this.LxTitleLabel1.Location = new System.Drawing.Point(10, 8);
            this.LxTitleLabel1.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel1.Name = "LxTitleLabel1";
            this.LxTitleLabel1.Size = new System.Drawing.Size(57, 23);
            this.LxTitleLabel1.TabIndex = 1;
            this.LxTitleLabel1.Text = "환자번호";
            this.LxTitleLabel1.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel1.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // btnButtonList
            // 
            this.btnButtonList.BackColor = System.Drawing.Color.White;
            this.btnButtonList.ButtonItems.AddRange(new Lime.Framework.Controls.ButtonItem[] {
            new Lime.Framework.Controls.ButtonItem(Lime.Framework.Controls.ButtonType.Save, "내역변경", "Save", System.Drawing.Color.Gold, System.Drawing.Color.RoyalBlue, true),
            new Lime.Framework.Controls.ButtonItem(Lime.Framework.Controls.ButtonType.Check, "자격조회", "Check", System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50))))), System.Drawing.Color.White, true),
            new Lime.Framework.Controls.ButtonItem(Lime.Framework.Controls.ButtonType.Close, "닫 기", "Close", System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(85)))), ((int)(((byte)(100))))), System.Drawing.Color.White, true)});
            this.btnButtonList.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnButtonList.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.btnButtonList.Location = new System.Drawing.Point(624, 6);
            this.btnButtonList.MaximumSize = new System.Drawing.Size(1000, 28);
            this.btnButtonList.Name = "btnButtonList";
            this.btnButtonList.Padding = new System.Windows.Forms.Padding(3);
            this.btnButtonList.Size = new System.Drawing.Size(232, 28);
            this.btnButtonList.TabIndex = 0;
            // 
            // lxPanel5
            // 
            this.lxPanel5.BackColor = System.Drawing.Color.White;
            this.lxPanel5.Controls.Add(this.lblMessage);
            this.lxPanel5.DisplayBorder = true;
            this.lxPanel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.lxPanel5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxPanel5.Location = new System.Drawing.Point(0, 0);
            this.lxPanel5.Name = "lxPanel5";
            this.lxPanel5.Padding = new System.Windows.Forms.Padding(3);
            this.lxPanel5.Size = new System.Drawing.Size(862, 27);
            this.lxPanel5.TabIndex = 0;
            // 
            // lblMessage
            // 
            appearance1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance1.FontData.Name = "맑은 고딕";
            appearance1.FontData.SizeInPoints = 9F;
            appearance1.ForeColor = System.Drawing.Color.Red;
            appearance1.TextHAlignAsString = "Left";
            appearance1.TextVAlignAsString = "Middle";
            this.lblMessage.Appearance = appearance1;
            this.lblMessage.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.None;
            this.lblMessage.Location = new System.Drawing.Point(3, 3);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(824, 20);
            this.lblMessage.TabIndex = 2;
            this.lblMessage.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblMessage.UseLimeStyle = false;
            this.lblMessage.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lxPanel2
            // 
            this.lxPanel2.BackColor = System.Drawing.Color.White;
            this.lxPanel2.Controls.Add(this.lxPanel5);
            this.lxPanel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lxPanel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxPanel2.Location = new System.Drawing.Point(0, 352);
            this.lxPanel2.Name = "lxPanel2";
            this.lxPanel2.Size = new System.Drawing.Size(862, 512);
            this.lxPanel2.TabIndex = 3;
            // 
            // frmOutInsnTypeChangeP
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Caption = "내역변경";
            this.ClientSize = new System.Drawing.Size(864, 896);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmOutInsnTypeChangeP";
            this.Padding = new System.Windows.Forms.Padding(0);
            this.Text = "내역변경";
            this.Controls.SetChildIndex(this.pnlBase, 0);
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).EndInit();
            this.pnlBase.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel1)).EndInit();
            this.lxPanel1.ResumeLayout(false);
            this.lxPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtAge)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSrrn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrrn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPtNm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnButtonList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel5)).EndInit();
            this.lxPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lblMessage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel2)).EndInit();
            this.lxPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Framework.Controls.LxPanel lxPanel5;
        private ucPatRegistLst ucPatRegistLst1;
        private Framework.Controls.LxPanel lxPanel1;
        private Framework.Controls.LxButtonList btnButtonList;
        private ucOrecTypeChange ucOrecTypeChange1;
        private Framework.Controls.LxLabel lblMessage;
        private Framework.Controls.LxTextBox txtAge;
        private Framework.Controls.LxTextBox txtSex;
        private Framework.Controls.LxTextBox txtSrrn;
        private Framework.Controls.LxTextBox txtFrrn;
        private Framework.Controls.LxTextBox txtPtNm;
        private Framework.Controls.LxTextBox txtPid;
        private Framework.Controls.LxTitleLabel LxTitleLabel3;
        private Framework.Controls.LxTitleLabel LxTitleLabel2;
        private Framework.Controls.LxTitleLabel LxTitleLabel1;
        private Framework.Controls.LxPanel lxPanel2;
        private ucInsuranceNew ucInsuranceNew1;
    }
}