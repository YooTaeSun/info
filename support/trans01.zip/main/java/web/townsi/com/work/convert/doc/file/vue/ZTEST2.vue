
<script setup lang="ts">
import { ref, reactive, onMounted, defineExpose, computed } from "vue";
import { $ref, $computed } from 'vue/macros'
import { CELLTYPE, CELL_HALIGNMENT, CELL_VALIGNMENT } from "@/app/framework/Controls/LxSpread/LxSpreadNS";

/* Life Cycles */
onMounted(() => {
  InitializeComponent();
  OnLoad();
});

const InitializeComponent = () => {
}


    
    
        const MdcrDd = $computed({
          set(value: any) { m_MdcrDd = value; }
        });
    
        const Pid = $computed({
          get() { return m_Pid; }
        });
        const PtCmhsNo = $computed({
          set(value: any) { m_PtCmhsNo = value; }
        });

        const MdcrDd2 = $computed({
          get()  { return m_PtCmhsNo; }, 
          set(value: any)  { m_MdcrDd = value; }
        });

        const PtCmhsNo = $computed({
          get()  { return m_PtCmhsNo; }, 
          set(value: any)  { m_PtCmhsNo = value; }
        });
        
        const InitializeSpread = () => 
        {
            SelectData(m_Pid, m_MdcrDd);
       
        
        const InitializeSpread = () => 
        {
            // if (!String.IsNullOrWhiteSpace(txtCttrUnclAplyAmt.Text.Replace(/,/gi, "")) && txtCttrUnclAplyAmt.Tag != null && !String.IsNullOrWhiteSpace(txtCttrUnclAplyAmt.Tag.ToString()))
            //                           , ucDschBiLLinfo1.txtPtSharAmt.Text.Replace(/,/gi, ""), ucDschBiLLinfo1.txtUschUplmAmt.Text.Replace(/,/gi, ""), insntycd, assttycd
            /*
             * sprSameDayRegList
             */
            sprSameDayRegList.SetSpreadSheet(sprSameDayRegList.ActiveSheet, FarPoint.Win.Spread.Model.SelectionPolicy.Single, FarPoint.Win.Spread.Model.SelectionUnit.Cell, FarPoint.Win.Spread.SelectionStyles.Both, FarPoint.Win.Spread.OperationMode.RowMode, false, false, FarPoint.Win.Spread.ButtonDrawModes.CurrentCell, true, true, FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded, FarPoint.Win.Spread.ScrollBarPolicy.Always, true, false, false, false);

            sprSameDayRegList.SetSpreadSheetColumn(sprSameDayRegList.ActiveSheet, COL.PID, "PID", "!환자등록번호", 70, CELL_HALIGNMENT.Left, CELL_VALIGNMENT.Center, CELLTYPE.TextBoxCellType);
            sprSameDayRegList.SetSpreadSheetColumn(sprSameDayRegList.ActiveSheet, COL.PT_NM, "PT_NM", "!환자명", 70, CELL_HALIGNMENT.Left, CELL_VALIGNMENT.Center, CELLTYPE.TextBoxCellType);
            sprSameDayRegList.SetSpreadSheetColumn(sprSameDayRegList.ActiveSheet, COL.PT_CMHS_NO, "PT_CMHS_NO", "!환자내원번호", 70, CELL_HALIGNMENT.Left, CELL_VALIGNMENT.Center, CELLTYPE.TextBoxCellType);
            sprSameDayRegList.SetSpreadSheetColumn(sprSameDayRegList.ActiveSheet, COL.MDCR_DEPT_CD, "MDCR_DEPT_CD", "!진료부서", 70, CELL_HALIGNMENT.Left, CELL_VALIGNMENT.Center, CELLTYPE.TextBoxCellType);
            sprSameDayRegList.SetSpreadSheetColumn(sprSameDayRegList.ActiveSheet, COL.DEPT_NM, "DEPT_NM", "진료부서", 70, CELL_HALIGNMENT.Left, CELL_VALIGNMENT.Center, CELLTYPE.TextBoxCellType);
            sprSameDayRegList.SetSpreadSheetColumn(sprSameDayRegList.ActiveSheet, COL.MDCR_DR_CD, "MDCR_DR_CD", "!진료의사", 70, CELL_HALIGNMENT.Left, CELL_VALIGNMENT.Center, CELLTYPE.TextBoxCellType);
            sprSameDayRegList.SetSpreadSheetColumn(sprSameDayRegList.ActiveSheet, COL.DR_NM, "DR_NM", "진료의사", 60, CELL_HALIGNMENT.Left, CELL_VALIGNMENT.Center, CELLTYPE.TextBoxCellType);

               
        
        
        
        
         
        
        


        
/* Expose */
defineExpose({ });
</script>

<template>
</template>
