using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack.BI;

namespace Lime.Framework
{
    public class BizCommon
    {
        #region 날짜체크
        /// <summary>
        /// [Spread의 LeaveCell이벤트 안에서 사용] 지정한 컬럼 내 Cell에서 LeaveCell이벤트가 일어날 때, 날짜 형식이 유효하지 않으면 LxMessage를 출력하고 Focus를 이동을 막는다.
        /// </summary>
        /// <param name="spr">적용할 스프레드</param>
        /// <param name="e">LeaveCellEventArgs e</param>
        /// <param name="tagName">적용할 스프레드의 컬럼Tag 명</param>
        public static bool CheckValidDateString(LxSpread spr, int row, int col, string tagname)
        {
            string strDate = spr.GetValue(row, col).ToString();

            if (spr.ActiveSheet.Columns.Get(col).Tag.ToString() == tagname)
            {
                if (!DateTimeService.IsDateTime(strDate))
                {
                    LxMessage.Show("유효하지 않은 날짜형식 입니다. 날짜형식을 확인해주세요.", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;
                }
            }


            if (tagname == "APLY_END_DD")
            {
                if (Convert.ToInt32(spr.GetValue("APLY_END_DD").ToString()) > Convert.ToInt32("29991231"))
                {
                    LxMessage.Show("종료일자는 2999년 12월 31일을 넘을 수 없습니다. 날짜형식을 확인해주세요.", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;
                }
            }

            return true;
        }
        #endregion

        #region CheckAplyDate - 스프레드의 적용시작일자가 종료일자보다 크면 메세지박스를 띄우고, false 를 반환한다.
        /// <summary>
        /// 스프레드의 적용시작일자가 종료일자보다 크면 메세지박스를 띄우고, false 를 반환한다.
        /// </summary>
        /// <param name="spr">검색 대상이 되는 스프레드</param>
        /// <param name="AplyStrtDdTag">적용시작일자 컬럼의 Tag</param>
        /// <param name="AplyEndDdTag">적용종료일자 컬럼의 Tag</param>
        /// <returns></returns>
        public static bool CheckAplyDate(LxSpread spr, string aplystrtddtag, string aplyendddtag)
        {
            string a = spr.Name;
            for (int i = 0; i < spr.ActiveSheet.RowCount; i++)
            {
                if ((spr.GetCRUDFromRow(i) == CRUD_TYPE.Create) || (spr.GetCRUDFromRow(i) == CRUD_TYPE.Update))
                {
                    if (string.IsNullOrWhiteSpace(spr.GetValue(i, aplystrtddtag).ToString()))
                    {
                        LxMessage.Show("시작일자가 비어있습니다. 시작일자를 확인해주세요.", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        SetRowFocus(spr, i, "APLY_STRT_DD");
                        return false;
                    }
                    if (string.IsNullOrWhiteSpace(spr.GetValue(i, aplyendddtag).ToString()))
                    {
                        LxMessage.Show("종료일자가 비어있습니다. 종료일자를 확인해주세요.", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        SetRowFocus(spr, i, "APLY_END_DD");
                        return false;
                    }

                    if (TypeCheckService.IsInt(spr.GetValue(i, aplystrtddtag).ToString()) && TypeCheckService.IsInt(spr.GetValue(i, aplyendddtag).ToString()))
                    {
                        if (Convert.ToInt32(spr.GetValue(i, aplystrtddtag).ToString()) > Convert.ToInt32(spr.GetValue(i, aplyendddtag).ToString()))
                        {
                            LxMessage.Show("적용시작일자는 종료일자보다 클 수 없습니다!!", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            SetRowFocus(spr, i, "APLY_STRT_DD");
                            return false;
                        }
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// 스프레드의 적용시작일자가 종료일자보다 크면 메세지박스를 띄우고, false 를 반환한다.
        /// </summary>
        /// <param name="spr">검색 대상이 되는 스프레드</param>
        /// <param name="row">Row</param>
        /// <param name="AplyStrtDdTag">적용시작일자 컬럼의 Tag</param>
        /// <param name="AplyEndDdTag">적용종료일자 컬럼의 Tag</param>
        /// <returns></returns>
        public static bool CheckAplyDate(LxSpread spr, int row, string aplystrtddtag, string aplyendddtag)
        {
            string a = spr.Name;
            if ((spr.GetCRUDFromRow(row) == CRUD_TYPE.Create) || (spr.GetCRUDFromRow(row) == CRUD_TYPE.Update))
            {
                if (string.IsNullOrWhiteSpace(spr.GetValue(row, aplystrtddtag).ToString()))
                {
                    LxMessage.Show("시작일자가 비어있습니다. 시작일자를 확인해주세요.", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    SetRowFocus(spr, row);
                    return false;
                }
                if (string.IsNullOrWhiteSpace(spr.GetValue(row, aplyendddtag).ToString()))
                {
                    LxMessage.Show("종료일자가 비어있습니다. 종료일자를 확인해주세요.", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    SetRowFocus(spr, row);
                    return false;
                }

                if (TypeCheckService.IsInt(spr.GetValue(row, aplystrtddtag).ToString()) && TypeCheckService.IsInt(spr.GetValue(row, aplyendddtag).ToString()))
                {
                    if (Convert.ToInt32(spr.GetValue(row, aplystrtddtag).ToString()) > Convert.ToInt32(spr.GetValue(row, aplyendddtag).ToString()))
                    {
                        LxMessage.Show("적용시작일자는 종료일자보다 클 수 없습니다!!", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        SetRowFocus(spr, row);
                        return false;
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// 스프레드의 적용시작일자가 종료일자보다 크면 메세지박스를 띄우고, false 를 반환한다.
        /// </summary>
        /// <param name="spr">검색 대상이 되는 스프레드</param>
        /// <param name="row">Row</param>
        /// <param name="col">Column</param>
        /// <param name="AplyStrtDdTag">적용시작일자 컬럼의 Tag</param>
        /// <param name="AplyEndDdTag">적용종료일자 컬럼의 Tag</param>
        /// <returns></returns>
        public static bool CheckAplyDate(LxSpread spr, int row, int col, string aplystrtddtag, string aplyendddtag)
        {
            string a = spr.Name;
            if ((spr.GetCRUDFromRow(row) == CRUD_TYPE.Create) || (spr.GetCRUDFromRow(row) == CRUD_TYPE.Update))
            {
                if (string.IsNullOrWhiteSpace(spr.GetValue(row, aplystrtddtag).ToString()))
                {
                    LxMessage.Show("시작일자가 비어있습니다. 시작일자를 확인해주세요.", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    SetRowFocus(spr, row, col);
                    return false;
                }
                if (string.IsNullOrWhiteSpace(spr.GetValue(row, aplyendddtag).ToString()))
                {
                    LxMessage.Show("종료일자가 비어있습니다. 종료일자를 확인해주세요.", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    SetRowFocus(spr, row, col);
                    return false;
                }

                if (TypeCheckService.IsInt(spr.GetValue(row, aplystrtddtag).ToString()) && TypeCheckService.IsInt(spr.GetValue(row, aplyendddtag).ToString()))
                {
                    if (Convert.ToInt32(spr.GetValue(row, aplystrtddtag).ToString()) > Convert.ToInt32(spr.GetValue(row, aplyendddtag).ToString()))
                    {
                        LxMessage.Show("적용시작일자는 종료일자보다 클 수 없습니다!!", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        SetRowFocus(spr, row, col);
                        return false;
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// 스프레드의 적용시작일자가 종료일자보다 크면 메세지박스를 띄우고, false 를 반환한다.
        /// </summary>
        /// <param name="spr">검색 대상이 되는 스프레드</param>
        /// <param name="row">Row</param>
        /// <param name="col">Column</param>
        /// <param name="AplyStrtDdTag">적용시작일자 컬럼의 Tag</param>
        /// <param name="AplyEndDdTag">적용종료일자 컬럼의 Tag</param>
        /// <returns></returns>
        public static bool CheckAplyDate(LxSpread spr, int row, string col, string aplystrtddtag, string aplyendddtag)
        {
            string a = spr.Name;
            if ((spr.GetCRUDFromRow(row) == CRUD_TYPE.Create) || (spr.GetCRUDFromRow(row) == CRUD_TYPE.Update))
            {
                if (string.IsNullOrWhiteSpace(spr.GetValue(row, aplystrtddtag).ToString()))
                {
                    LxMessage.Show("시작일자가 비어있습니다. 시작일자를 확인해주세요.", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    SetRowFocus(spr, row, col);
                    return false;
                }
                if (string.IsNullOrWhiteSpace(spr.GetValue(row, aplyendddtag).ToString()))
                {
                    LxMessage.Show("종료일자가 비어있습니다. 종료일자를 확인해주세요.", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    SetRowFocus(spr, row, col);
                    return false;
                }

                if (TypeCheckService.IsInt(spr.GetValue(row, aplystrtddtag).ToString()) && TypeCheckService.IsInt(spr.GetValue(row, aplyendddtag).ToString()))
                {
                    if (Convert.ToInt32(spr.GetValue(row, aplystrtddtag).ToString()) > Convert.ToInt32(spr.GetValue(row, aplyendddtag).ToString()))
                    {
                        LxMessage.Show("적용시작일자는 종료일자보다 클 수 없습니다!!", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        SetRowFocus(spr, row, col);
                        return false;
                    }
                }
            }
            return true;
        }
        #endregion

        #region CheckDupDuration - Spread의 PK들 간의 중복기간이 있는지 체크
        /// <summary>
        /// 하나의 코드를 대상으로, 적용기간이 겹치는 코드를 체크하고, 기간이 겹치면 메세지 박스를 띄우고, false를 반환한다.
        /// 스프레드의 CRUD플래그가 Update이면서, 적용시작일자,종료일자 체크대상이 되는 코드가 바뀌지 않았으면 기간의 중복을 체크하지 않는다.
        /// </summary>
        /// <param name="spr">확인할 스프레드</param>
        /// <param name="rowIdx">확인할 스프레드의 RowIndex</param>
        /// <param name="TableName">테이블명</param>
        /// <param name="AplyStrtDdTag">적용시작일자의 Tag</param>
        /// <param name="AplyEndDdTag">적용종료일자의 Tag</param>
        /// <param name="CodeColumnTag">확인 코드의 컬럼Tag</param>
        /// <param name="isDelYN">테이블 상의 DEL_YN 필드의 존재여부</param> 
        /// <param name="isMsgBox">오류 발생 시, 메세지박스 출력여부</param> 
        /// <returns></returns>
        public static bool CheckDupDuration(LxSpread spr, int rowIdx, string TableName, string AplyStrtDdTag, string AplyEndDdTag, string CodeColumnTag, bool isDelYN, bool isMsgBox)
        {
            #region 중복코드 동시저장 불가
            DataTable CreateDt = new DataTable();
            CreateDt.Columns.Add(new DataColumn("CODE", typeof(string)));
            DataTable DeleteDupDt = new DataTable();
            for (int i = 0; i < spr.ActiveSheet.RowCount; i++)
            {
                if (spr.GetCRUDFromRow(i) == CRUD_TYPE.Create)
                {
                    CreateDt.Rows.Add(spr.GetValue(i, CodeColumnTag));
                }
            }
            DeleteDupDt = CreateDt.DefaultView.ToTable(true, "CODE");

            if (CreateDt.Rows.Count != DeleteDupDt.Rows.Count)
            {
                if (isMsgBox)
                    LxMessage.Show("새로 저장하는 코드 값은 한번에 두개이상 중복된 값이 될 수 없습니다.", "중복코드 동시저장 불가", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            #endregion

            //Key가 되는 컬럼의 정보가 변경되었는지 체크하는 변수
            bool isKeyChanged = false;

            if (spr.GetCRUDFromRow(rowIdx) == CRUD_TYPE.Update)
                if ((spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() == spr.GetValue(rowIdx, AplyStrtDdTag).ToString())
               && (spr.GetOldValue(rowIdx, AplyEndDdTag).ToString() == spr.GetValue(rowIdx, AplyEndDdTag).ToString())
               && (spr.GetOldValue(rowIdx, CodeColumnTag).ToString() == spr.GetValue(rowIdx, CodeColumnTag).ToString()))
                    return true;
                else
                    isKeyChanged = true;

            string RevisionSql = " AND DEL_YN = 'A'";
            string CheckAplySql = "";
            if (isDelYN)
            {
                CheckAplySql = SQL.Sql.GetMinAplyStrtDd() + RevisionSql;
                RevisionSql = SQL.Sql.GetDupDuration() + RevisionSql;
            }
            else
            {
                CheckAplySql = SQL.Sql.GetMinAplyStrtDd();
                RevisionSql = SQL.Sql.GetDupDuration();
            }

            //입력하려는 적용 시작일자가 ,기존의 적용시작 일자의 최소 값보다 작으면 Return
            int MinAplyStrtDd = DBService.ExecuteInteger(CheckAplySql, AplyStrtDdTag
                                                                     , TableName
                                                                     , CodeColumnTag
                                                                     , spr.GetValue(rowIdx, CodeColumnTag).ToString());

            if (TypeCheckService.IsInt(spr.GetValue(rowIdx, AplyStrtDdTag).ToString()) && Convert.ToInt32(spr.GetValue(rowIdx, AplyStrtDdTag).ToString()) <= MinAplyStrtDd)
            {
                //자기 자신의 시작일자를 수정하는 경우 제외.
                if ((spr.GetCRUDFromRow(rowIdx) != CRUD_TYPE.Create) && (spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() != MinAplyStrtDd.ToString()))
                {
                    if (isMsgBox)
                        LxMessage.Show("수정 또는 새롭게 저장되는 적용 시작일자는\r\n기존에 같은 코드에 존재하는 적용시작일자보다 같거나 작을 수 없습니다!!", "적용시작일자 재입력필요", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

            }

            DataTable dt = new DataTable();
            if (DBService.ExecuteDataTable(RevisionSql, ref dt, TableName
                                                                             , AplyStrtDdTag
                                                                             , AplyEndDdTag
                                                                             , spr.GetValue(rowIdx, AplyStrtDdTag).ToString()
                                                                             , spr.GetValue(rowIdx, AplyEndDdTag).ToString()
                                                                             , CodeColumnTag
                                                                             , spr.GetValue(rowIdx, CodeColumnTag).ToString()))
            {
                string dupDurationRow = (rowIdx + 1).ToString();
                //겹치는 기간이 없을 때,
                if (dt.Rows.Count == 0)
                {
                    return true;
                }
                //겹치는 기간이 있을 때,
                else
                {
                    //데이터가 하나이면서, Update시 Key컬럼이 변경되었을 때, 즉, 자기 자신의 Key가 되는 컬럼을 변경할 때,
                    if ((dt.Rows.Count == 1) && (isKeyChanged == true))
                        return true;
                    else
                    {
                        if (isMsgBox)
                            LxMessage.Show(dupDurationRow + "번째 줄의 " + spr.GetValue(rowIdx, CodeColumnTag) + "코드와 적용기간이 겹치는 동일한 코드가 존재합니다!!", "기간이 겹치는 코드 존재", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// 두개의 코드를 대상으로, 적용기간이 겹치는 코드를 체크하고, 기간이 겹치면 메세지 박스를 띄우고, false를 반환한다.
        /// 스프레드의 CRUD플래그가 Update이면서, 적용일자시작일자,종료일자 체크대상이 되는 코드가 바뀌지 않았으면 기간의 중복을 체크하지 않는다.
        /// </summary>
        /// <param name="spr">확인할 스프레드</param>
        /// <param name="rowIdx">확인할 스프레드의 RowIndex</param>
        /// <param name="TableName">테이블명</param>
        /// <param name="AplyStrtDdTag">적용시작일자의 Tag</param>
        /// <param name="AplyEndDdTag">적용종료일자의 Tag</param>
        /// <param name="CodeColumnTag1">확인 코드의 첫번째 컬럼Tag</param>
        /// <param name="CodeColumnTag2">확인 코드의 두번째 컬럼Tag</param>
        /// <param name="isDelYN">테이블 상의 DEL_YN 필드의 존재여부</param> 
        /// <param name="isMsgBox">오류 발생 시, 메세지박스 출력여부</param> 
        /// <returns></returns>
        public static bool CheckDupDuration(LxSpread spr, int rowIdx, string TableName, string AplyStrtDdTag, string AplyEndDdTag, string CodeColumnTag1, string CodeColumnTag2, bool isDelYN, bool isMsgBox)
        {
            #region 중복코드 동시저장 불가
            DataTable CreateDt = new DataTable();
            CreateDt.Columns.Add(new DataColumn("CODE", typeof(string)));
            DataTable DeleteDupDt = new DataTable();
            for (int i = 0; i < spr.ActiveSheet.RowCount; i++)
            {
                if (spr.GetCRUDFromRow(i) == CRUD_TYPE.Create)
                {
                    CreateDt.Rows.Add(spr.GetValue(i, CodeColumnTag1).ToString() + spr.GetValue(i, CodeColumnTag2).ToString());
                }
            }
            DeleteDupDt = CreateDt.DefaultView.ToTable(true, "CODE");

            if (CreateDt.Rows.Count != DeleteDupDt.Rows.Count)
            {
                if (isMsgBox)
                    LxMessage.Show("새로 저장하는 코드 값은 한번에 두개이상 중복된 값이 될 수 없습니다.", "중복코드 동시저장 불가", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            #endregion

            //Key가 되는 컬럼의 정보가 변경되었는지 체크하는 변수
            bool isKeyChanged = false;

            if (spr.GetCRUDFromRow(rowIdx) == CRUD_TYPE.Update)
                if ((spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() == spr.GetValue(rowIdx, AplyStrtDdTag).ToString())
                   && (spr.GetOldValue(rowIdx, AplyEndDdTag).ToString() == spr.GetValue(rowIdx, AplyEndDdTag).ToString())
                   && (spr.GetOldValue(rowIdx, CodeColumnTag1).ToString() == spr.GetValue(rowIdx, CodeColumnTag1).ToString())
                    && (spr.GetOldValue(rowIdx, CodeColumnTag2).ToString() == spr.GetValue(rowIdx, CodeColumnTag2).ToString()))
                    return true;
                else
                    isKeyChanged = true;

            string CheckAplySql = "";
            string RevisionSql = " AND DEL_YN = 'A'";
            if (isDelYN)
            {
                CheckAplySql = SQL.Sql.GetMinAplyStrtDd2() + RevisionSql;
                RevisionSql = SQL.Sql.GetDupDuration2() + RevisionSql;
            }
            else
            {
                CheckAplySql = SQL.Sql.GetMinAplyStrtDd2();
                RevisionSql = SQL.Sql.GetDupDuration2();
            }

            //입력하려는 적용 시작일자가 ,기존의 적용시작 일자의 최소 값보다 작으면 Return
            int MinAplyStrtDd = DBService.ExecuteInteger(CheckAplySql, AplyStrtDdTag
                                                                     , TableName
                                                                     , CodeColumnTag1
                                                                     , spr.GetValue(rowIdx, CodeColumnTag1).ToString()
                                                                     , CodeColumnTag2
                                                                     , spr.GetValue(rowIdx, CodeColumnTag2).ToString());

            if (Convert.ToInt32(spr.GetValue(rowIdx, AplyStrtDdTag).ToString()) <= MinAplyStrtDd)
            {
                //자기 자신의 시작일자를 수정하는 경우 제외.
                if ((spr.GetCRUDFromRow(rowIdx) != CRUD_TYPE.Create) && (spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() != MinAplyStrtDd.ToString()))
                {
                    if (isMsgBox)
                        LxMessage.Show("수정 또는 새롭게 저장되는 적용 시작일자는\r\n기존에 같은 코드에 존재하는 적용시작일자보다 같거나 작을 수 없습니다!!", "적용시작일자 재입력필요", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

            }

            DataTable dt = new DataTable();
            if (DBService.ExecuteDataTable(RevisionSql, ref dt, TableName
                                                              , AplyStrtDdTag
                                                              , AplyEndDdTag
                                                              , spr.GetValue(rowIdx, AplyStrtDdTag).ToString()
                                                              , spr.GetValue(rowIdx, AplyEndDdTag).ToString()
                                                              , CodeColumnTag1
                                                              , spr.GetValue(rowIdx, CodeColumnTag1).ToString()
                                                              , CodeColumnTag2
                                                              , spr.GetValue(rowIdx, CodeColumnTag2).ToString()))
            {
                string dupDurationRow = (rowIdx + 1).ToString();
                //겹치는 기간이 없을 때,
                if (dt.Rows.Count == 0)
                {
                    return true;
                }
                //겹치는 기간이 있을 때,
                else
                {//데이터가 하나이면서, Update시 Key컬럼이 변경되었을 때, 즉, 자기 자신의 Key가 되는 컬럼을 변경할 때,
                    if ((dt.Rows.Count == 1) && (isKeyChanged == true))
                        return true;
                    else
                    {
                        if (isMsgBox)
                            LxMessage.Show(dupDurationRow + "번째 줄의" + spr.GetValue(rowIdx, CodeColumnTag1) + ", " + spr.GetValue(rowIdx, CodeColumnTag2) + "코드와 적용기간이 겹치는 동일한 코드가 존재합니다!!", "기간이 겹치는 코드 존재", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// 세개의 코드를 대상으로, 적용기간이 겹치는 코드를 체크하고, 기간이 겹치면 메세지 박스를 띄우고, false를 반환한다.
        /// 스프레드의 CRUD플래그가 Update이면서, 적용일자시작일자,종료일자 체크대상이 되는 코드가 바뀌지 않았으면 기간의 중복을 체크하지 않는다.
        /// </summary>
        /// <param name="spr">확인할 스프레드</param>
        /// <param name="rowIdx">확인할 스프레드의 RowIndex</param>
        /// <param name="TableName">테이블명</param>
        /// <param name="AplyStrtDdTag">적용시작일자의 Tag</param>
        /// <param name="AplyEndDdTag">적용종료일자의 Tag</param>
        /// <param name="CodeColumnTag1">확인 코드의 첫번째 컬럼Tag</param>
        /// <param name="CodeColumnTag2">확인 코드의 두번째 컬럼Tag</param>
        /// <param name="CodeColumnTag3">확인 코드의 세번째 컬럼Tag</param>
        /// <param name="isDelYN">테이블 상의 DEL_YN 필드의 존재여부</param> 
        /// <param name="isMsgBox">오류 발생 시, 메세지박스 출력여부</param> 
        /// <returns></returns>
        public static bool CheckDupDuration(LxSpread spr, int rowIdx, string TableName, string AplyStrtDdTag, string AplyEndDdTag, string CodeColumnTag1, string CodeColumnTag2, string CodeColumnTag3, bool isDelYN, bool isMsgBox)
        {
            #region 중복코드 동시저장 불가
            DataTable CreateDt = new DataTable();
            CreateDt.Columns.Add(new DataColumn("CODE", typeof(string)));
            DataTable DeleteDupDt = new DataTable();
            for (int i = 0; i < spr.ActiveSheet.RowCount; i++)
            {
                if (spr.GetCRUDFromRow(i) == CRUD_TYPE.Create)
                {
                    CreateDt.Rows.Add(spr.GetValue(i, CodeColumnTag1).ToString() + spr.GetValue(i, CodeColumnTag2).ToString() + spr.GetValue(i, CodeColumnTag3).ToString());
                }
            }
            DeleteDupDt = CreateDt.DefaultView.ToTable(true, "CODE");

            if (CreateDt.Rows.Count != DeleteDupDt.Rows.Count)
            {
                if (isMsgBox)
                    LxMessage.Show("새로 저장하는 코드 값은 한번에 두개이상 중복된 값이 될 수 없습니다.", "중복코드 동시저장 불가", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            #endregion

            //Key가 되는 컬럼의 정보가 변경되었는지 체크하는 변수
            bool isKeyChanged = false;

            if (spr.GetCRUDFromRow(rowIdx) == CRUD_TYPE.Update)
                if ((spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() == spr.GetValue(rowIdx, AplyStrtDdTag).ToString())
                   && (spr.GetOldValue(rowIdx, AplyEndDdTag).ToString() == spr.GetValue(rowIdx, AplyEndDdTag).ToString())
                   && (spr.GetOldValue(rowIdx, CodeColumnTag1).ToString() == spr.GetValue(rowIdx, CodeColumnTag1).ToString())
                    && (spr.GetOldValue(rowIdx, CodeColumnTag2).ToString() == spr.GetValue(rowIdx, CodeColumnTag2).ToString())
                    && (spr.GetOldValue(rowIdx, CodeColumnTag3).ToString() == spr.GetValue(rowIdx, CodeColumnTag3).ToString()))
                    return true;
                else
                    isKeyChanged = true;

            string CheckAplySql = "";
            string RevisionSql = " AND DEL_YN = 'A'";
            if (isDelYN)
            {
                CheckAplySql = SQL.Sql.GetMinAplyStrtDd3() + RevisionSql;
                RevisionSql = SQL.Sql.GetDupDuration3() + RevisionSql;
            }
            else
            {
                CheckAplySql = SQL.Sql.GetMinAplyStrtDd3();
                RevisionSql = SQL.Sql.GetDupDuration3();
            }

            //입력하려는 적용 시작일자가 ,기존의 적용시작 일자의 최소 값보다 작으면 Return
            int MinAplyStrtDd = DBService.ExecuteInteger(CheckAplySql, AplyStrtDdTag
                                                                     , TableName
                                                                     , CodeColumnTag1
                                                                     , spr.GetValue(rowIdx, CodeColumnTag1).ToString()
                                                                     , CodeColumnTag2
                                                                     , spr.GetValue(rowIdx, CodeColumnTag2).ToString()
                                                                     , CodeColumnTag3
                                                                     , spr.GetValue(rowIdx, CodeColumnTag3).ToString());

            if (Convert.ToInt32(spr.GetValue(rowIdx, AplyStrtDdTag).ToString()) <= MinAplyStrtDd)
            {
                //자기 자신의 시작일자를 수정하는 경우 제외.
                if ((spr.GetCRUDFromRow(rowIdx) != CRUD_TYPE.Create) && (spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() != MinAplyStrtDd.ToString()))
                {
                    if (isMsgBox)
                        LxMessage.Show("수정 또는 새롭게 저장되는 적용 시작일자는\r\n기존에 같은 코드에 존재하는 적용시작일자보다 같거나 작을 수 없습니다!!", "적용시작일자 재입력필요", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

            }

            DataTable dt = new DataTable();
            if (DBService.ExecuteDataTable(RevisionSql, ref dt, TableName
                                                                             , AplyStrtDdTag
                                                                             , AplyEndDdTag
                                                                             , spr.GetValue(rowIdx, AplyStrtDdTag).ToString()
                                                                             , spr.GetValue(rowIdx, AplyEndDdTag).ToString()
                                                                             , CodeColumnTag1
                                                                             , spr.GetValue(rowIdx, CodeColumnTag1).ToString()
                                                                             , CodeColumnTag2
                                                                             , spr.GetValue(rowIdx, CodeColumnTag2).ToString()
                                                                             , CodeColumnTag3
                                                                             , spr.GetValue(rowIdx, CodeColumnTag3).ToString()))
            {
                string dupDurationRow = (rowIdx + 1).ToString();
                //겹치는 기간이 없을 때,
                if (dt.Rows.Count == 0)
                {
                    return true;
                }
                //겹치는 기간이 있을 때,
                else
                {
                    //데이터가 하나이면서, Update시 Key컬럼이 변경되었을 때, 즉, 자기 자신의 Key가 되는 컬럼을 변경할 때,
                    if ((dt.Rows.Count == 1) && (isKeyChanged == true))
                        return true;
                    else
                    {
                        if (isMsgBox)
                            LxMessage.Show(dupDurationRow + "번째 줄의" + spr.GetValue(rowIdx, CodeColumnTag1) + ", " + spr.GetValue(rowIdx, CodeColumnTag2) + ", " + spr.GetValue(rowIdx, CodeColumnTag3) + "코드와 적용기간이 겹치는 동일한 코드가 존재합니다!!", "기간이 겹치는 코드 존재", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// 네개의 코드를 대상으로, 적용기간이 겹치는 코드를 체크하고, 기간이 겹치면 메세지 박스를 띄우고, false를 반환한다.
        /// 스프레드의 CRUD플래그가 Update이면서, 적용일자시작일자,종료일자 체크대상이 되는 코드가 바뀌지 않았으면 기간의 중복을 체크하지 않는다.
        /// </summary>
        /// <param name="spr">확인할 스프레드</param>
        /// <param name="rowIdx">확인할 스프레드의 RowIndex</param>
        /// <param name="TableName">테이블명</param>
        /// <param name="AplyStrtDdTag">적용시작일자의 Tag</param>
        /// <param name="AplyEndDdTag">적용종료일자의 Tag</param>
        /// <param name="CodeColumnTag1">확인 코드의 첫번째 컬럼Tag</param>
        /// <param name="CodeColumnTag2">확인 코드의 두번째 컬럼Tag</param>
        /// <param name="CodeColumnTag3">확인 코드의 세번째 컬럼Tag</param>
        /// <param name="CodeColumnTag4">확인 코드의 네번째 컬럼Tag</param>
        /// <param name="isDelYN">테이블 상의 DEL_YN 필드의 존재여부</param> 
        /// <param name="isMsgBox">오류 발생 시, 메세지박스 출력여부</param> 
        /// <returns></returns>
        public static bool CheckDupDuration(LxSpread spr, int rowIdx, string TableName, string AplyStrtDdTag, string AplyEndDdTag, string CodeColumnTag1, string CodeColumnTag2, string CodeColumnTag3, string CodeColumnTag4, bool isDelYN, bool isMsgBox)
        {
            #region 중복코드 동시저장 불가
            DataTable CreateDt = new DataTable();
            CreateDt.Columns.Add(new DataColumn("CODE", typeof(string)));
            DataTable DeleteDupDt = new DataTable();
            for (int i = 0; i < spr.ActiveSheet.RowCount; i++)
            {
                if (spr.GetCRUDFromRow(i) == CRUD_TYPE.Create)
                {
                    CreateDt.Rows.Add(spr.GetValue(i, CodeColumnTag1).ToString() + spr.GetValue(i, CodeColumnTag2).ToString() + spr.GetValue(i, CodeColumnTag3).ToString() + spr.GetValue(i, CodeColumnTag4).ToString());
                }
            }
            DeleteDupDt = CreateDt.DefaultView.ToTable(true, "CODE");

            if (CreateDt.Rows.Count != DeleteDupDt.Rows.Count)
            {
                if (isMsgBox)
                    LxMessage.Show("새로 저장하는 코드 값은 한번에 두개이상 중복된 값이 될 수 없습니다.", "중복코드 동시저장 불가", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            #endregion

            //Key가 되는 컬럼의 정보가 변경되었는지 체크하는 변수
            bool isKeyChanged = false;

            if (spr.GetCRUDFromRow(rowIdx) == CRUD_TYPE.Update)
                if ((spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() == spr.GetValue(rowIdx, AplyStrtDdTag).ToString())
                   && (spr.GetOldValue(rowIdx, AplyEndDdTag).ToString() == spr.GetValue(rowIdx, AplyEndDdTag).ToString())
                   && (spr.GetOldValue(rowIdx, CodeColumnTag1).ToString() == spr.GetValue(rowIdx, CodeColumnTag1).ToString())
                    && (spr.GetOldValue(rowIdx, CodeColumnTag2).ToString() == spr.GetValue(rowIdx, CodeColumnTag2).ToString())
                    && (spr.GetOldValue(rowIdx, CodeColumnTag3).ToString() == spr.GetValue(rowIdx, CodeColumnTag3).ToString())
                    && (spr.GetOldValue(rowIdx, CodeColumnTag4).ToString() == spr.GetValue(rowIdx, CodeColumnTag4).ToString()))
                    return true;
                else
                    isKeyChanged = true;

            string CheckAplySql = "";
            string RevisionSql = " AND DEL_YN = 'A'";
            if (isDelYN)
            {
                CheckAplySql = SQL.Sql.GetMinAplyStrtDd4() + RevisionSql;
                RevisionSql = SQL.Sql.GetDupDuration4() + RevisionSql;
            }
            else
            {
                CheckAplySql = SQL.Sql.GetMinAplyStrtDd4();
                RevisionSql = SQL.Sql.GetDupDuration4();
            }

            //입력하려는 적용 시작일자가 ,기존의 적용시작 일자의 최소 값보다 작으면 Return
            int MinAplyStrtDd = DBService.ExecuteInteger(CheckAplySql, AplyStrtDdTag
                                                                     , TableName
                                                                     , CodeColumnTag1
                                                                     , spr.GetValue(rowIdx, CodeColumnTag1).ToString()
                                                                     , CodeColumnTag2
                                                                     , spr.GetValue(rowIdx, CodeColumnTag2).ToString()
                                                                     , CodeColumnTag3
                                                                     , spr.GetValue(rowIdx, CodeColumnTag3).ToString()
                                                                     , CodeColumnTag4
                                                                     , spr.GetValue(rowIdx, CodeColumnTag4).ToString());

            if (Convert.ToInt32(spr.GetValue(rowIdx, AplyStrtDdTag).ToString()) <= MinAplyStrtDd)
            {
                //자기 자신의 시작일자를 수정하는 경우 제외.
                if ((spr.GetCRUDFromRow(rowIdx) != CRUD_TYPE.Create) && (spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() != MinAplyStrtDd.ToString()))
                {
                    if (isMsgBox)
                        LxMessage.Show("수정 또는 새롭게 저장되는 적용 시작일자는\r\n기존에 같은 코드에 존재하는 적용시작일자보다 같거나 작을 수 없습니다!!", "적용시작일자 재입력필요", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

            }

            DataTable dt = new DataTable();
            if (DBService.ExecuteDataTable(RevisionSql, ref dt, TableName
                                                                             , AplyStrtDdTag
                                                                             , AplyEndDdTag
                                                                             , spr.GetValue(rowIdx, AplyStrtDdTag).ToString()
                                                                             , spr.GetValue(rowIdx, AplyEndDdTag).ToString()
                                                                             , CodeColumnTag1
                                                                             , spr.GetValue(rowIdx, CodeColumnTag1).ToString()
                                                                             , CodeColumnTag2
                                                                             , spr.GetValue(rowIdx, CodeColumnTag2).ToString()
                                                                             , CodeColumnTag3
                                                                             , spr.GetValue(rowIdx, CodeColumnTag3).ToString()
                                                                             , CodeColumnTag4
                                                                             , spr.GetValue(rowIdx, CodeColumnTag4).ToString()))
            {
                string dupDurationRow = (rowIdx + 1).ToString();
                //겹치는 기간이 없을 때,
                if (dt.Rows.Count == 0)
                {
                    return true;
                }
                //겹치는 기간이 있을 때,
                else
                {
                    //데이터가 하나이면서, Update시 Key컬럼이 변경되었을 때, 즉, 자기 자신의 Key가 되는 컬럼을 변경할 때,
                    if ((dt.Rows.Count == 1) && (isKeyChanged == true))
                        return true;
                    else
                    {
                        if (isMsgBox)
                            LxMessage.Show(dupDurationRow + "번째 줄의" + spr.GetValue(rowIdx, CodeColumnTag1) + ", " + spr.GetValue(rowIdx, CodeColumnTag2) + ", " + spr.GetValue(rowIdx, CodeColumnTag3) + ", " + spr.GetValue(rowIdx, CodeColumnTag4) + "코드와 적용기간이 겹치는 동일한 코드가 존재합니다!!", "기간이 겹치는 코드 존재", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// 코드를 대상으로, 적용기간이 겹치는 코드를 체크하고, 기간이 겹치면 메세지 박스를 띄우고, false를 반환한다.
        /// 스프레드의 CRUD플래그가 Update이면서, 적용일자시작일자,종료일자 체크대상이 되는 코드가 바뀌지 않았으면 기간의 중복을 체크하지 않는다.
        /// </summary>
        /// <param name="spr">확인할 스프레드</param>
        /// <param name="rowIdx">확인할 스프레드의 RowIndex</param>
        /// <param name="TableName">테이블명</param>
        /// <param name="AplyStrtDdTag">적용시작일자의 Tag</param>
        /// <param name="AplyEndDdTag">적용종료일자의 Tag</param>
        /// <param name="CodeColumnTag1">확인 코드의 첫번째 컬럼Tag</param>
        /// <param name="CodeColumnTag2">확인 코드의 두번째 컬럼Tag</param>
        /// <param name="CodeColumnTag3">확인 코드의 세번째 컬럼Tag</param>
        /// <param name="CodeColumnTag4">확인 코드의 네번째 컬럼Tag</param>
        /// <param name="isDelYN">테이블 상의 DEL_YN 필드의 존재여부</param> 
        /// <param name="isMsgBox">오류 발생 시, 메세지박스 출력여부</param> 
        /// <returns></returns>
        public static bool CheckDupDuration(LxSpread spr, int rowIdx, string TableName, bool isDelYN, bool isMsgBox, string AplyStrtDdTag, string AplyEndDdTag, params string[] CodeColumnTag)
        {
            #region 중복코드 동시저장 불가
            DataTable CreateDt = new DataTable();
            CreateDt.Columns.Add(new DataColumn("CODE", typeof(string)));
            DataTable DeleteDupDt = new DataTable();
            for (int j = 0; j < CodeColumnTag.Length; j++)
            {
                for (int i = 0; i < spr.ActiveSheet.RowCount; i++)
                {
                    if (spr.GetCRUDFromRow(i) == CRUD_TYPE.Create)
                    {
                        CreateDt.Rows.Add(spr.GetValue(i, CodeColumnTag[j]).ToString());
                    }
                }
            }
            DeleteDupDt = CreateDt.DefaultView.ToTable(true, "CODE");

            if (CreateDt.Rows.Count != DeleteDupDt.Rows.Count)
            {
                if (isMsgBox)
                    LxMessage.Show("새로 저장하는 코드 값은 한번에 두개이상 중복된 값이 될 수 없습니다.", "중복코드 동시저장 불가", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            #endregion

            //Key가 되는 컬럼의 정보가 변경되었는지 체크하는 변수
            bool isKeyChanged = false;

            if (spr.GetCRUDFromRow(rowIdx) == CRUD_TYPE.Update)
            {
                for (int j = 0; j < CodeColumnTag.Length; j++)
                {
                    if ((spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() == spr.GetValue(rowIdx, AplyStrtDdTag).ToString())
                       && (spr.GetOldValue(rowIdx, AplyEndDdTag).ToString() == spr.GetValue(rowIdx, AplyEndDdTag).ToString())
                       && (spr.GetOldValue(rowIdx, CodeColumnTag[j]).ToString() == spr.GetValue(rowIdx, CodeColumnTag[j]).ToString()))
                        return true;
                    else
                        isKeyChanged = true;
                }
            }
            string CheckAplySql = "";
            string RevisionSql = " AND DEL_YN = 'A'";
            int count = Convert.ToInt32(CodeColumnTag.Length.ToString());
            if (isDelYN)
            {
                CheckAplySql = SQL.Sql.GetMinAplyStrtDd5(count) + RevisionSql;
                RevisionSql = SQL.Sql.GetDupDuration5(count) + RevisionSql;
            }
            else
            {
                CheckAplySql = SQL.Sql.GetMinAplyStrtDd5(count);
                RevisionSql = SQL.Sql.GetDupDuration5(count);
            }

            //입력하려는 적용 시작일자가 ,기존의 적용시작 일자의 최소 값보다 작으면 Return
            int MinAplyStrtDd = 0;
            for (int j = 0; j < CodeColumnTag.Length; j++)
            {
                MinAplyStrtDd = DBService.ExecuteInteger(CheckAplySql, AplyStrtDdTag
                                                                     , TableName
                                                                     , CodeColumnTag[j]
                                                                     , spr.GetValue(rowIdx, CodeColumnTag[j]).ToString());
            }
            if (Convert.ToInt32(spr.GetValue(rowIdx, AplyStrtDdTag).ToString()) <= MinAplyStrtDd)
            {
                //자기 자신의 시작일자를 수정하는 경우 제외.
                if ((spr.GetCRUDFromRow(rowIdx) != CRUD_TYPE.Create) && (spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() != MinAplyStrtDd.ToString()))
                {
                    if (isMsgBox)
                        LxMessage.Show("수정 또는 새롭게 저장되는 적용 시작일자는\r\n기존에 같은 코드에 존재하는 적용시작일자보다 같거나 작을 수 없습니다!!", "적용시작일자 재입력필요", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

            }

            DataTable dt = new DataTable();
            for (int j = 0; j < CodeColumnTag.Length; j++)
            {
                if (DBService.ExecuteDataTable(RevisionSql, ref dt, TableName, AplyStrtDdTag
                                                                             , AplyEndDdTag
                                                                             , spr.GetValue(rowIdx, AplyStrtDdTag).ToString()
                                                                             , spr.GetValue(rowIdx, AplyEndDdTag).ToString()
                                                                             , CodeColumnTag[j]
                                                                             , spr.GetValue(rowIdx, CodeColumnTag[j]).ToString()))
                {
                    string dupDurationRow = (rowIdx + 1).ToString();
                    //겹치는 기간이 없을 때,
                    if (dt.Rows.Count == 0)
                    {
                        return true;
                    }
                    //겹치는 기간이 있을 때,
                    else
                    {
                        //데이터가 하나이면서, Update시 Key컬럼이 변경되었을 때, 즉, 자기 자신의 Key가 되는 컬럼을 변경할 때,
                        if ((dt.Rows.Count == 1) && (isKeyChanged == true))
                        {
                            return true;
                        }
                        else
                        {
                            if (isMsgBox)
                                LxMessage.Show(dupDurationRow + "번째 줄의 코드와 적용기간이 겹치는 동일한 코드가 존재합니다!!", "기간이 겹치는 코드 존재", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return false;
                        }
                    }
                }
            }
            return false;
        }
        #endregion

        #region 해당하는 Control의 모든 Control 취득
        /// <summary>
        /// 선택한 컨트롤 내의 모든 컨트롤을 취득
        /// </summary>
        /// <param name="containerControl">선택한 컨트롤</param>
        /// <returns>모든 컨트롤</returns>
        public static Control[] GetAllControlsUsingRecursive(Control containerControl)
        {
            List<Control> allControls = new List<Control>();
            try
            {
                foreach (Control control in containerControl.Controls)
                {
                    //자식 컨트롤을 컬렉션에 추가한다
                    allControls.Add(control);

                    //만일 자식 컨트롤이 또 다른 자식 컨트롤을 가지고 있다면
                    if (control.Controls.Count > 0)
                    {
                        //자신을 재귀적으로 호출한다
                        allControls.AddRange(GetAllControlsUsingRecursive(control));
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                MessageBox.Show(ex.StackTrace);
            }
            //모든 컨트롤을 반환한다
            return allControls.ToArray();
        }
        #endregion

        #region 헤더 체크박스
        /// <summary>
        /// 컬럼 헤드의 체크에 따라 모든 행 체크를 변경(ActiveSheet를 대상으로 함)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public static void checkColumnHeader(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            BizCommon.CheckFirstColumnHeaderCheckbox(sender, e);
        }

        /// <summary>
        /// 현재시트의 맨 앞 체크박스 헤더행 클릭시 처리
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public static void CheckFirstColumnHeaderCheckbox(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (!e.ColumnHeader)
                return;

            if (e.RowHeader)
                return;

            LxSpread spread = ((LxSpread)sender);
            int row = e.Row;
            int col = e.Column;

            try
            {
                if (!(spread.ActiveSheet.GetCellType(row, col) is FarPoint.Win.Spread.CellType.CheckBoxCellType))
                    return;

                if (spread.ActiveSheet.ColumnHeader.Cells[0, col].Value == null ||
                    spread.ActiveSheet.ColumnHeader.Cells[0, col].Value.ToString() == "False")
                {
                    for (int i = 0; i < spread.ActiveSheet.RowCount; i++)
                        spread.ActiveSheet.Cells[i, col].Value = true;
                    spread.ActiveSheet.ColumnHeader.Cells[0, col].Value = true;
                }
                else
                {
                    for (int i = 0; i < spread.ActiveSheet.RowCount; i++)
                        spread.ActiveSheet.Cells[i, col].Value = false;
                    spread.ActiveSheet.ColumnHeader.Cells[0, col].Value = false;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        /// <summary>
        /// 현재시트의 맨 앞 체크박스 데이터행 클릭시 처리
        /// </summary>
        /// <param name="sender"></param>
        public static void CheckFirstColumnDataCheckbox(object sender)
        {
            LxSpread spread = ((LxSpread)sender);
            int row = spread.ActiveSheet.ActiveRowIndex;
            int col = spread.ActiveSheet.ActiveColumnIndex;

            if (!(spread.ActiveSheet.GetCellType(row, col) is FarPoint.Win.Spread.CellType.CheckBoxCellType))
                return;

            bool isallchecked = true;
            for (int i = 0; i < spread.ActiveSheet.RowCount; i++)
            {
                if (spread.GetValue(i, col).ToString().Equals("N"))
                {
                    isallchecked = false;
                    break;
                }
            }

            spread.ActiveSheet.ColumnHeader.Cells[0, col].Value = isallchecked;
        }

        #endregion

        #region Method : SetRowFocus

        /// <summary>
        /// 스프레드에 해당 행, 열에 포커스를 설정합니다.
        /// </summary>
        /// <param name="spr">설정할 스프레드</param>
        /// <param name="row">행</param>
        /// <param name="colname">칼럼명</param>
        public static void SetRowFocus(LxSpread spr, int row, string col)
        {
            int colnum = 0;

            for (int i = 0; i < spr.ActiveSheet.ColumnCount; i++)
            {
                if (spr.ActiveSheet.Columns.Get(i).Tag.ToString() == col)
                {
                    colnum = i;
                    break;
                }
            }

            spr.SetActiveRow(row);
            spr.SetActiveCell(row, col);
            spr.ShowRow(0, row, FarPoint.Win.Spread.VerticalPosition.Nearest);
            spr.ShowColumn(0, colnum, FarPoint.Win.Spread.HorizontalPosition.Nearest);
            if (spr.ActiveSheet.OperationMode == FarPoint.Win.Spread.OperationMode.ExtendedSelect)
                spr.ActiveSheet.AddSelection(row, 0, 1, spr.ActiveSheet.ColumnCount);
            spr.Focus();
        }

        /// <summary>
        /// 스프레드에 해당 행, 열에 포커스를 설정합니다.
        /// </summary>
        /// <param name="spr">설정할 스프레드</param>
        /// <param name="row">행</param>
        /// <param name="colname">칼럼명</param>
        public static void SetRowFocus(LxSpread spr, int row, int col)
        {
            spr.SetActiveRow(row);
            spr.SetActiveCell(row, col);
            spr.ShowRow(0, row, FarPoint.Win.Spread.VerticalPosition.Nearest);
            spr.ShowColumn(0, col, FarPoint.Win.Spread.HorizontalPosition.Nearest);
            if (spr.ActiveSheet.OperationMode == FarPoint.Win.Spread.OperationMode.ExtendedSelect)
                spr.ActiveSheet.AddSelection(row, 0, 1, spr.ActiveSheet.ColumnCount);
            spr.Focus();
        }

        /// <summary>
        /// 스프레드에 해당 행, 열에 포커스를 설정합니다.
        /// </summary>
        /// <param name="spr">설정할 스프레드</param>
        /// <param name="row">행</param>
        /// <param name="colname">칼럼명</param>
        public static void SetRowFocus(LxSpread spr, int row)
        {
            spr.SetActiveRow(row);
            spr.ShowRow(0, row, FarPoint.Win.Spread.VerticalPosition.Nearest);
            if (spr.ActiveSheet.OperationMode == FarPoint.Win.Spread.OperationMode.ExtendedSelect)
                spr.ActiveSheet.AddSelection(row, 0, 1, spr.ActiveSheet.ColumnCount);
            spr.Focus();
        }

        #endregion Method : SetRowFocus

        #region CheckModified - 스프레드에 변경된 내용이 없으면 메세지박스를 띄우고, false를 반환하고, 변경된 내용이 있으면 True를 반환한다.
        /// <summary>
        /// 스프레드에 변경된 내용이 없으면 메세지박스를 띄우고, false를 반환하고, 변경된 내용이 있으면 True를 반환한다.
        /// </summary>
        /// <param name="spr">검색 대상이 되는 스프레드</param>
        /// <returns></returns>
        public static bool CheckModified(LxSpread spr)
        {
            //변경된 내용이 없을 때,
            if (!spr.IsModified())
            {
                LxMessage.Show("변경된 내용이 없습니다!!", "변경내역없음", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        #endregion

        /// <summary>
        /// 특정 Column 선택여부 확인
        /// </summary>
        /// <returns></returns>
        public static bool CheckChooseColumn(LxSpread Spread, string Col)
        {
            for (int i = 0; i < Spread.ActiveSheet.RowCount; i++)
            {
                if (Spread.GetValue(i, Col).ToString() == "Y")
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 특정 Column 선택여부 확인과 개수 확인
        /// </summary>
        /// <returns></returns>
        public static bool CheckChooseColumn(LxSpread Spread, string Col, ref int Count)
        {
            Count = 0;

            for (int i = 0; i < Spread.ActiveSheet.RowCount; i++)
            {
                if (Spread.GetValue(i, Col).ToString() == "Y")
                {
                    Count++;
                }
            }

            if (Count > 0)
                return true;
            else
                return false;
        }

        /// <summary>
        /// 특정 Column 선택여부 확인, 개수, 첫번째 Row 확인
        /// </summary>
        /// <returns></returns>
        public static bool CheckChooseColumn(LxSpread Spread, string Col, ref int Count, ref int Row)
        {
            bool Setflag = false;

            Count = 0;
            Row = 0;

            for (int i = 0; i < Spread.ActiveSheet.RowCount; i++)
            {
                if (Spread.GetValue(i, Col).ToString() == "Y")
                {
                    if (!Setflag)
                    {
                        Setflag = true;
                        Row = i;
                    }

                    Count++;
                }
            }

            if (Count > 0)
                return true;
            else
                return false;
        }

        /// <summary>
        /// 입력받은 문자열이 소수이면, 소수점의 가장 마지막 '0'을 제거하고 Return.
        /// <para>입력받은 문자열이 소수가 아니면, 입력받은 문자열 그대로 Return.</para>
        /// <para>Ex. 13 입력 -> 13 Return.</para>
        /// <para>Ex. 13.0000 입력 -> 13 Return.</para>
        /// <para>Ex. 13.520 입력 -> 13.52 Return.</para>
        /// <para>Ex. 13.0520 입력 -> 13.052 Return 등.</para>
        /// </summary>
        /// <param name="strDecimal">변환할 문자열</param>
        /// <returns></returns>
        public static string TrimZeroPoint(string strDecimal)
        {
            strDecimal = strDecimal.Trim();
            if (strDecimal.Contains("."))
            {
                string str = strDecimal;
                string[] spltStr = str.Split('.');
                string decimalPoint = spltStr[1];

                bool isZero = true;
                int decimalLength = 0;
                for (int i = decimalPoint.Length - 1; i >= 0; i--)
                {
                    if (!(decimalPoint[i]).Equals('0'))
                    {
                        isZero = false;
                        decimalLength = i;
                        break;
                    }
                }

                if (!isZero)
                {
                    return spltStr[0] + "." + decimalPoint.Substring(0, decimalLength + 1);
                }
                else
                {
                    return spltStr[0];
                }
            }
            else
                return strDecimal;
        }

        /// <summary>
        /// 병원로고 Image To Byte Array
        /// </summary>
        /// <param name="usercd"></param>
        /// <returns></returns>
        public static byte[] GetHospitalLogoMegaBytes()
        {
            System.IO.MemoryStream ms = new System.IO.MemoryStream();

            try
            {
                DOPack.HospitalInfo.HospitalLogo.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return ms.ToArray();
        }

        /// <summary>
        /// 영수증 Image To Byte Array
        /// </summary>
        /// <param name="usercd"></param>
        /// <returns></returns>
        public static byte[] GetHospitalReceiptImageMegaBytes()
        {
            System.IO.MemoryStream ms = new System.IO.MemoryStream();

            try
            {
                DOSignInfo a = new DOSignInfo("ReceiptImg");
                a.Load();
                a.SignImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return ms.ToArray();
        }

        /// <summary>
        /// 처방전 Image To Byte Array
        /// </summary>
        /// <param name="usercd"></param>
        /// <returns></returns>
        public static byte[] GetHospitalPrescriptionImageMegaBytesTop()
        {
            System.IO.MemoryStream ms = new System.IO.MemoryStream();

            try
            {
                DOSignInfo a = new DOSignInfo("SlipTImg");
                a.Load();
                a.SignImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return ms.ToArray();
        }

        /// <summary>
        /// 처방전 Image To Byte Array
        /// </summary>
        /// <param name="usercd"></param>
        /// <returns></returns>
        public static byte[] GetHospitalPrescriptionImageMegaBytesMiddle()
        {
            System.IO.MemoryStream ms = new System.IO.MemoryStream();

            try
            {
                DOSignInfo a = new DOSignInfo("SlipMImg");
                a.Load();
                a.SignImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return ms.ToArray();
        }

        /// <summary>
        /// 처방전 Image To Byte Array
        /// </summary>
        /// <param name="usercd"></param>
        /// <returns></returns>
        public static byte[] GetHospitalPrescriptionImageMegaBytesBottom()
        {
            System.IO.MemoryStream ms = new System.IO.MemoryStream();

            try
            {
                DOSignInfo a = new DOSignInfo("SlipBImg");
                a.Load();
                a.SignImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return ms.ToArray();
        }

        public static string Get_CD_DVCD(string MEFE_CD)
        {
            try
            {
                object RetVal = null;

                RetVal = DBService.ExecuteScalar(SQL.Sql.Get_CD_DVCD(), MEFE_CD, DateTime.Now.ToString("yyyyMMdd"));
                if (DBService.HasError)
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));

                if (RetVal != null)
                    return RetVal.ToString();
                return string.Empty;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return string.Empty;
            }
        }

        public static void SaveActionLog(string assemblyname, string screenname, string action, string pid)
        {
            try
            {
                if (!DBService.ExecuteNonQuery(
                    Lime.Framework.Controls.Sql.InsertActionLog(assemblyname, screenname, action, pid)
                    ))
                    throw new Exception(string.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        /// <summary>
        /// String의 Height를 구한다.
        /// </summary>
        /// <param name="text"></param>
        /// <param name="font"></param>
        /// <param name="width"></param>
        /// <param name="g"></param>
        /// <returns></returns>
        public static int GetDisplayStringHeight(string text, Font font, Graphics g)
        {
            StringFormat sf = new StringFormat();
            RectangleF rect = new RectangleF(0, 0, 10000, 1000);
            Region[] region = new Region[1];
            CharacterRange[] range = { new CharacterRange(0, text.Length) };

            if (font == null)
                font = new Font(new FontFamily("맑은 고딕"), 9);

            sf.SetMeasurableCharacterRanges(range);
            region = g.MeasureCharacterRanges(text, font, rect, sf);
            rect = region[0].GetBounds(g);

            return (int)(rect.Bottom + 1.0F);
        }

        public static Bitmap GetQRCodeToBitmap(string qrcode, int size)
        {
            try
            {
                QrEncoder encoder = new QrEncoder(ErrorCorrectionLevel.L);
                QrCode qr = encoder.Encode(qrcode);

                int start = 1;
                Renderer renderer = new Renderer(start);

                int calc = 0;

                for (; ; )
                {
                    if (renderer.Measure(qr.Matrix.Width).Width - size > 0)
                    {
                        if ((calc < 0 ? calc * (-1) : calc) < renderer.Measure(qr.Matrix.Width).Width - size)
                            renderer = new Renderer(--start);

                        break;
                    }
                    calc = renderer.Measure(qr.Matrix.Width).Width - size;
                    renderer = new Renderer(++start);
                }

                return new Bitmap(renderer.CreateImageFile(qr.Matrix, System.Drawing.Imaging.ImageFormat.Png));
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return null;
            }
        }

        public static List<string> GetStringCut(string text, int cutByte)
        {
            char[] btChars = text.ToCharArray();
            List<string> list = new List<string>();

            try
            {
                string addtext = "";
                int i = -1;

                foreach (byte b in btChars)
                {
                    i++;
                    if (StringService.ByteCount(addtext + btChars[i]) > cutByte)
                    {
                        list.Add(addtext);
                        addtext = "";
                        addtext += btChars[i];
                    }
                    else
                    {
                        addtext += btChars[i];
                    }
                }

                if (StringService.IsNotNull(addtext))
                    list.Add(addtext);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
            return list;
        }

        public static void SetSpreadColumnUserOption(Type type, LxSpread spread, string sprCode)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("SELECT *");
                sb.AppendLine("  FROM ADUSCOMA");
                sb.AppendLine(" WHERE USER_CD        = '{0}'");
                sb.AppendLine("   AND ASSM_FILE_NAME = '{1}'");
                sb.AppendLine("   AND CLAS_NAME      = '{2}'");
                sb.AppendLine("   AND SPR_CODE       = '{3}'");
                sb.AppendLine("   AND DEL_YN         = 'A'");
                sb.AppendLine(" ORDER BY SORT_SEQ");

                DataTable dt = new DataTable();

                if (!DBService.ExecuteDataTable(sb.ToString(), ref dt
                    , DOPack.UserInfo.USER_CD
                    , type.Assembly.ManifestModule.Name
                    , type.Name
                    , sprCode
                    ))
                    throw new Exception(string.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));

                if (dt.Rows.Count <= 0)
                    return;

                int currentIndex = 0;

                for (int i = 0; i < spread.ActiveSheet.Columns.Count; i++)
                {
                    spread.ActiveSheet.Columns[i].Visible = true;
                }

                foreach (DataRow row in dt.Rows)
                {
                    string columnTag = row["COL_CODE"].ToString();
                    int columnIndex = spread.GetTagToColumnIndex(columnTag);

                    if (columnIndex < 0)
                        continue;

                    if (currentIndex == columnIndex)
                    {
                        currentIndex++;
                        continue;
                    }

                    spread.ActiveSheet.MoveColumn(columnIndex, currentIndex++, false);
                }

                for (int i = 0; i < spread.ActiveSheet.Columns.Count; i++)
                {
                    bool exist = false;

                    if (spread.ActiveSheet.Columns[i].Tag != null)
                        exist = dt.Select(string.Format("COL_CODE = '{0}'", spread.ActiveSheet.Columns[i].Tag)).Length > 0;

                    spread.ActiveSheet.Columns[i].Visible = exist;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        /// <summary>
        /// 병원직인 Image To Byte Array
        /// </summary>
        /// <param name="usercd"></param>
        /// <returns></returns>
        public static byte[] GetHospitalSign()
        {
            System.IO.MemoryStream ms = new System.IO.MemoryStream();

            try
            {
                DOPack.HospitalInfo.HospitalSign.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return ms.ToArray();
        }
        public static void GetComboColumns(Type type, LxSpread spr, LxComboBoxMultiCheck cbo_mul)
        {
            try
            {
                for (int i = 0; i < spr.ActiveSheet.ColumnCount; i++)
                {
                    spr.ActiveSheet.Columns[i].Visible = false;
                }

                DataTable dt = new DataTable();
                string sqltext = string.Format(@"
SELECT NVL(B.DEL_YN, 'D') AS DEL_YN
     , B.COL_CODE
     , B.COL_NAME
  FROM ADCOLMMT A
     , ADCOLMDT B
 WHERE A.ASSM_FILE_NAME = '{0}'
   AND A.CLAS_NAME      = '{1}'
   AND A.SPR_CODE       = '{2}'
   AND A.ASSM_FILE_NAME = B.ASSM_FILE_NAME
   AND A.CLAS_NAME      = B.CLAS_NAME
   AND A.SPR_CODE       = B.SPR_CODE
 ORDER BY A.SORT_SEQ", type.Assembly.ManifestModule.Name
                     , type.Name
                     , spr.Name);

                if (!DBService.ExecuteDataTable(sqltext, ref dt))
                    throw new Exception("사용 컬럼 목록 조회 중 오류가 발생했습니다.");

                if (dt.Rows.Count < 1)
                    throw new Exception("조회된 컬럼 목록이 없습니다.");

                cbo_mul.SetComboItems(dt, "COL_CODE", "COL_NAME", false);

                foreach (Infragistics.Win.UltraWinGrid.UltraGridRow row in cbo_mul.Rows)
                {
                    if (row.Cells["COL_CODE"].Value == null)
                        continue;

                    bool Check = dt.AsEnumerable().Any(r => r["COL_CODE"].ToString() == row.Cells["COL_CODE"].Value.ToString() && r["DEL_YN"].ToString().Equals("A"));
                    row.Cells["SELECTED"].Value = Check;
                }

                SetSpreadVisible(spr, cbo_mul);
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }

        }

        public static void SetComboColumns(Type type, LxSpread spr, LxComboBoxMultiCheck cbo_mul)
        {
            try
            {
                string sqltext = @"
UPDATE ADCOLMDT
   SET DEL_YN         = '{0}'
 WHERE ASSM_FILE_NAME = '{1}'
   AND CLAS_NAME      = '{2}'
   AND SPR_CODE       = '{3}'";

                DBService.BeginTransaction();

                if (!DBService.ExecuteNonQuery(sqltext, "D", type.Assembly.ManifestModule.Name, type.Name, spr.Name))
                    throw new Exception("사용 컬럼 설정 중 오류가 발생했습니다.");

                string item = cbo_mul.GetCheckedItem(true, "COL_CODE");
                if (!string.IsNullOrWhiteSpace(item))
                {
                    sqltext += string.Format($"\r\n   AND COL_CODE      IN ({item})");

                    if (!DBService.ExecuteNonQuery(sqltext, "A", type.Assembly.ManifestModule.Name, type.Name, spr.Name))
                        throw new Exception("사용 컬럼 설정 중 오류가 발생했습니다.");

                }

                DBService.CommitTransaction();

                SetSpreadVisible(spr, cbo_mul);
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                DBService.RollbackTransaction();
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        public static void SetSpreadVisible(LxSpread spr, LxComboBoxMultiCheck cbo_mul)
        {
            try
            {
                if (cbo_mul.Rows.Count < 1)
                    return;

                for(int i = 0; i < spr.ActiveSheet.ColumnCount; i++)
                {
                    spr.ActiveSheet.Columns[i].Visible = false;
                }

                int currentIndex = 0;
                foreach (Infragistics.Win.UltraWinGrid.UltraGridRow row in cbo_mul.Rows)
                {
                    if (row.Cells["COL_CODE"].Value == null)
                        continue;

                    if (spr.GetTagToColumnIndex(row.Cells["COL_CODE"].Value.ToString()) < 0)
                        continue;

                    int rowIndex = spr.GetTagToColumnIndex(row.Cells["COL_CODE"].Value.ToString());
                    spr.ActiveSheet.Columns[rowIndex].Visible = (bool)row.Cells["SELECTED"].Value;

                    if(currentIndex == rowIndex)
                    {
                        currentIndex++;
                        continue;
                    }

                    spr.ActiveSheet.MoveColumn(rowIndex, currentIndex++, false);
                }
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

    }


    #region Report Common

    public static class DataTableService
    {
        public static DataTable ToDataTable<T>(this IList<T> data)
        {
            System.ComponentModel.PropertyDescriptorCollection DescriptCollection = System.ComponentModel.TypeDescriptor.GetProperties(typeof(T));
            object[] values = new object[DescriptCollection.Count];
            using (DataTable Table = new DataTable())
            {
                long ListCount = DescriptCollection.Count;
                for (int Index = 0; Index < ListCount; ++Index)
                {
                    System.ComponentModel.PropertyDescriptor Descript = DescriptCollection[Index];
                    Table.Columns.Add(Descript.Name, Descript.PropertyType);
                }
                foreach (T item in data)
                {
                    long Count = values.Length;
                    for (int Index = 0; Index < Count; ++Index)
                    {
                        values[Index] = DescriptCollection[Index].GetValue(item);
                    }
                    Table.Rows.Add(values);
                }
                return Table;
            }
        }
    }

    #endregion
}