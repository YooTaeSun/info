using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using Lime.Framework;
using Lime.Framework.Controls;

namespace Lime.BusinessControls
{
    public class clsInHospPrescript : IDisposable
    {
        #region IDisposable Support
        private bool disposedValue = false; // 중복 호출을 검색하려면

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: 관리되는 상태(관리되는 개체)를 삭제합니다.
                    if (m_FieldInfo_List != null && m_FieldInfo_List.Count > 0)
                        m_FieldInfo_List.Clear();

                    if (m_ReportPreViewer != null)
                        m_ReportPreViewer.Dispose();
                }

                // TODO: 관리되지 않는 리소스(관리되지 않는 개체)를 해제하고 아래의 종료자를 재정의합니다.
                // TODO: 큰 필드를 null로 설정합니다.

                disposedValue = true;
            }
        }

        // TODO: 위의 Dispose(bool disposing)에 관리되지 않는 리소스를 해제하는 코드가 포함되어 있는 경우에만 종료자를 재정의합니다.
        // ~clsInHospPrescript() {
        //   // 이 코드를 변경하지 마세요. 위의 Dispose(bool disposing)에 정리 코드를 입력하세요.
        //   Dispose(false);
        // }

        // 삭제 가능한 패턴을 올바르게 구현하기 위해 추가된 코드입니다.
        public void Dispose()
        {
            // 이 코드를 변경하지 마세요. 위의 Dispose(bool disposing)에 정리 코드를 입력하세요.
            Dispose(true);
            // TODO: 위의 종료자가 재정의된 경우 다음 코드 줄의 주석 처리를 제거합니다.
            // GC.SuppressFinalize(this);
        }
        #endregion

        private const string m_ReportFileName = "rptInHospPrescript.rdlc";
        private const string m_ReportFieldName = "clsInHospPrescript_FieldInfo";

        private string m_ReportFullPath;

        private clsInHospPrescript_FieldInfo m_FieldInfo = null;
        private List<clsInHospPrescript_FieldInfo> m_FieldInfo_List = new List<clsInHospPrescript_FieldInfo>();
        private LxReportPreView m_ReportPreViewer = new LxReportPreView();

        public bool Print(string mdct_no, string pid, bool reprint)
        {
            try
            {
                // 처방전유효기간 : ConfigService.GetConfigValueString("PA", "OUPR", "USE_PERD", "3")

                // 약품정보
                DataTable dtPMPRRQIF = new DataTable();
                // 자가주사약품정보
                DataTable dtPMPRRQIF_Injc = new DataTable();
                // 환자정보
                DataTable dtPAOPATRT = new DataTable();
                // 상병정보
                DataTable dtORDISRRT = new DataTable();
                // DUR정보
                DataTable dtORDRTRIF = new DataTable();

                //======================================================================
                // 약품 정보 조회
                //======================================================================
                if (!DBService.ExecuteDataTable(GetPMPRRQIF(mdct_no, pid), ref dtPMPRRQIF))
                    throw new Exception(string.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));

                if (dtPMPRRQIF.Rows.Count <= 0)
                {
                    LxMessage.ShowWarning("약품정보가 존재하지 않습니다.");
                    return false;
                }

                dtPMPRRQIF_Injc = dtPMPRRQIF.AsEnumerable().Where(x => x["PRSC_LCLS_CD"].ToString() != "30").AsDataView().ToTable();
                dtPMPRRQIF = dtPMPRRQIF.AsEnumerable().Where(x => x["PRSC_LCLS_CD"].ToString() == "30").AsDataView().ToTable();
                string injcList = string.Join(", ", dtPMPRRQIF_Injc.AsEnumerable().Select(x => string.Format("{0}", x["PRSC_NM"].ToString())).ToList());

                //======================================================================
                // 환자 내원정보 조회
                //======================================================================
                if (!DBService.ExecuteDataTable(GetPAOPATRTPAIPATRT(dtPMPRRQIF.Rows[0]["PID"].ToString()
                                                                  , dtPMPRRQIF.Rows[0]["PT_CMHS_NO"].ToString()
                                                                  , dtPMPRRQIF.Rows[0]["MDCR_DD"].ToString())
                                              , ref dtPAOPATRT
                                              ))
                    throw new Exception(string.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));

                if (dtPAOPATRT.Rows.Count <= 0)
                {
                    LxMessage.ShowWarning("환자정보가 존재하지 않습니다.");
                    return false;
                }

                //======================================================================
                // 상병 정보 조회
                //======================================================================
                if (!DBService.ExecuteDataTable(GetORDISRRT(dtPMPRRQIF.Rows[0]["PID"].ToString()
                                                          , dtPMPRRQIF.Rows[0]["PT_CMHS_NO"].ToString())
                                              , ref dtORDISRRT
                                              ))
                    throw new Exception(string.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));

                if (dtORDISRRT.Rows.Count <= 0)
                {
                    LxMessage.ShowWarning("상병정보가 존재하지 않습니다.");
                    return false;
                }

                if (!DBService.ExecuteDataTable(GetORDRTRIF(dtPMPRRQIF.Rows[0]["PID"].ToString()
                                                          , dtPMPRRQIF.Rows[0]["PT_CMHS_NO"].ToString()
                                                          , dtPMPRRQIF.Rows[0]["MDCR_DD"].ToString())
                                              , ref dtORDRTRIF
                                              ))
                    throw new Exception(string.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));

                // 인슐린 투여중인 환자인지 확인한다.
                string insu_inst_prsc = ConfigService.GetConfigValueString("%", "INSU_INST_PRSC", "INSU_INST_PRSC", "*").ToString();
                string sqltext = string.Format(@"
SELECT COUNT(*)
  FROM ORORDRRT
 WHERE PID          = '{0}'
   AND PT_CMHS_NO   =  {1}
   AND MDCR_DD      = '{2}'
   AND PRSC_CD      = '{3}'
   AND DEL_YN       = 'A'
   AND DC_PRSC_DVCD = 'A'
", dtPMPRRQIF.Rows[0]["PID"].ToString()
 , dtPMPRRQIF.Rows[0]["PT_CMHS_NO"].ToString()
 , dtPMPRRQIF.Rows[0]["MDCR_DD"].ToString()
 , insu_inst_prsc);
                int insulinePrscCount = DBService.ExecuteInteger(sqltext);
                string usinginsuline = insulinePrscCount > 0 ? "인슐린 투여중인 환자입니다." : "";

                this.m_FieldInfo = new clsInHospPrescript_FieldInfo();

                string insntycd = dtPAOPATRT.Rows[0]["INSN_TYCD"].ToString();
                string assttycd = dtPAOPATRT.Rows[0]["ASST_TYCD"].ToString();

                switch (insntycd.Substring(0, 1))
                {
                    case "1":
                        if (assttycd == "99" || assttycd == "D9" || assttycd == "P9")
                        {
                            this.m_FieldInfo.INSN_TYCD_5 = "✓";
                            this.m_FieldInfo.INSN_TYCD_ETC = "일반";
                        }
                        else
                            this.m_FieldInfo.INSN_TYCD_1 = "✓";
                        break;
                    case "2":
                        if (assttycd == "99" || assttycd == "D9" || assttycd == "P9")
                        {
                            this.m_FieldInfo.INSN_TYCD_5 = "✓";
                            this.m_FieldInfo.INSN_TYCD_ETC = "일반";
                        }
                        else
                            this.m_FieldInfo.INSN_TYCD_2 = "✓";

                        break;
                    case "3":
                        if (assttycd == "99")
                        {
                            this.m_FieldInfo.INSN_TYCD_5 = "✓";
                            this.m_FieldInfo.INSN_TYCD_ETC = "일반";
                        }
                        else if (assttycd == "G")
                        {
                            this.m_FieldInfo.INSN_TYCD_5 = "✓";
                            this.m_FieldInfo.INSN_TYCD_ETC = "공상";
                        }
                        else
                            this.m_FieldInfo.INSN_TYCD_3 = "✓";
                        break;
                    case "4":
                        this.m_FieldInfo.INSN_TYCD_4 = "✓";
                        break;
                    case "5":
                        this.m_FieldInfo.INSN_TYCD_5 = "✓";
                        this.m_FieldInfo.INSN_TYCD_ETC = "일반";
                        break;
                }

                this.m_FieldInfo.REPRINT = reprint ? "재발행" : "";

                this.m_FieldInfo.HPTL_RGNO_CD = DOPack.HospitalInfo.HPTL_RGNO_CD;
                this.m_FieldInfo.HSPT_NM = DOPack.HospitalInfo.HSPT_NM;
                this.m_FieldInfo.TEL = DOPack.HospitalInfo.TEL;
                this.m_FieldInfo.FAX_NO = DOPack.HospitalInfo.FAX_NO;

                this.m_FieldInfo.MDCT_NO = dtPMPRRQIF.Rows[0]["MDCT_NO"].ToString();
                this.m_FieldInfo.PID = dtPMPRRQIF.Rows[0]["PID"].ToString();
                this.m_FieldInfo.PT_NM = dtPMPRRQIF.Rows[0]["PT_NM"].ToString();
                this.m_FieldInfo.RRNO = dtPMPRRQIF.Rows[0]["RRNO"].ToString();

                for (int k = 0; k < dtORDISRRT.Rows.Count; k++)
                {
                    if (k.Equals(0))
                    {
                        string ilnscd1 = dtORDISRRT.Rows[k]["ILNS_CD"].ToString().PadRight(6);

                        this.m_FieldInfo.ILNS_CD_11 = ilnscd1.Substring(0, 1);
                        this.m_FieldInfo.ILNS_CD_12 = ilnscd1.Substring(1, 1);
                        this.m_FieldInfo.ILNS_CD_13 = ilnscd1.Substring(2, 1);
                        this.m_FieldInfo.ILNS_CD_14 = ilnscd1.Substring(3, 1);
                        this.m_FieldInfo.ILNS_CD_15 = ilnscd1.Substring(4, 1);
                    }
                    else
                    {
                        string ilnscd2 = dtORDISRRT.Rows[k]["ILNS_CD"].ToString().PadRight(6);

                        this.m_FieldInfo.ILNS_CD_21 = ilnscd2.Substring(0, 1);
                        this.m_FieldInfo.ILNS_CD_22 = ilnscd2.Substring(1, 1);
                        this.m_FieldInfo.ILNS_CD_23 = ilnscd2.Substring(2, 1);
                        this.m_FieldInfo.ILNS_CD_24 = ilnscd2.Substring(3, 1);
                        this.m_FieldInfo.ILNS_CD_25 = ilnscd2.Substring(4, 1);

                        // 2개까지만 보여준다.
                        break;
                    }
                }

                this.m_FieldInfo.DR_NM = dtPAOPATRT.Rows[0]["MDCR_DR_NM"].ToString();
                this.m_FieldInfo.LCTY = "의사";
                this.m_FieldInfo.LCNO = dtPAOPATRT.Rows[0]["LCNO"].ToString();

                using (MemoryStream ms = new MemoryStream())
                {
                    using (DOSignInfo sign = new DOSignInfo(dtPAOPATRT.Rows[0]["MDCR_DR_CD"].ToString()))
                    {
                        sign.SignImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        this.m_FieldInfo.DR_SIGN = ms.ToArray();
                        sign.Clear();
                    }
                }

                DataTable tempORDRTRIF = new DataTable();
                string durCheckMedicine = "";
                string durCheckInject = "";
                for (int i = 0; i < dtPMPRRQIF.Rows.Count; i++)
                {
                    tempORDRTRIF.Clear();
                    dtORDRTRIF.DefaultView.RowFilter = "";
                    dtORDRTRIF.DefaultView.RowFilter = string.Format("PRSC_SQNO = {0}", dtPMPRRQIF.Rows[i]["PRSC_SQNO"].ToString());
                    tempORDRTRIF = dtORDRTRIF.DefaultView.ToTable();
                    if (tempORDRTRIF.Rows.Count.Equals(0))
                        continue;

                    string prscNm = dtPMPRRQIF.Rows[i]["PRSC_NM"].ToString();

                    for (int j = 0; j < tempORDRTRIF.Rows.Count; j++)
                    {
                        //DUR사유 점검종류코드의 명을 가져온다.
                        string chckkind = OverallCodeList.GetName("DUR_CHEK_CD", tempORDRTRIF.Rows[j]["CHCK_KIND_CD"].ToString());

                        if (dtPMPRRQIF.Rows[i]["PRSC_LCLS_CD"].ToString().Equals("30"))
                        {
                            // 약
                            if (StringService.IsNull(durCheckMedicine))
                                durCheckMedicine = string.Format("DUR 점검내역({0}) : 처방명({1}) 사유 [{2}] {3}", "약", prscNm, chckkind, tempORDRTRIF.Rows[j]["RESN_CNTS"].ToString());
                            else
                                durCheckMedicine += string.Format(" / 처방명({0}) 사유 [{1}] {2}", prscNm, chckkind, tempORDRTRIF.Rows[j]["RESN_CNTS"].ToString());
                        }
                        else
                        {
                            // 주사
                            if (StringService.IsNull(durCheckInject))
                                durCheckInject = string.Format("DUR 점검내역({0}) : 처방명({1}) 사유 [{2}] {3}", "주사", prscNm, chckkind, tempORDRTRIF.Rows[j]["RESN_CNTS"].ToString());
                            else
                                durCheckInject += string.Format(" / 처방명({0}) 사유 [{1}] {2}", prscNm, chckkind, tempORDRTRIF.Rows[j]["RESN_CNTS"].ToString());
                        }
                    }
                }

                if (!string.IsNullOrWhiteSpace(injcList))
                    this.m_FieldInfo.DUR_CHEK = string.Format("처방명({0}) ", injcList);

                this.m_FieldInfo.DUR_CHEK += string.Format("{0}{1}{2}", durCheckMedicine, StringService.IsNotNull(durCheckMedicine) && StringService.IsNotNull(durCheckInject) ? "\r\n" : "", durCheckInject);
                this.m_FieldInfo.DUR_CHEK += string.Format("{0}{1}", StringService.IsNotNull(m_FieldInfo.DUR_CHEK) && StringService.IsNotNull(usinginsuline) ? "\r\n" : "", usinginsuline);

                for (int i = 0; i < dtPMPRRQIF.Rows.Count; i++)
                {
                    if (!i.Equals(0))
                        this.m_FieldInfo = new clsInHospPrescript_FieldInfo();

                    string edicd = StringService.IsNvl(dtPMPRRQIF.Rows[i]["EDI_CD"].ToString(), dtPMPRRQIF.Rows[i]["PRSC_CD"].ToString());
                    string aomdmthdcd = StringService.IsNvl(dtPMPRRQIF.Rows[i]["AOMD_MTHD_CD"].ToString(), "");
                    string aomdMthdNm = dtPMPRRQIF.Rows[i]["AOMD_MTHD_NM"].ToString();
                    string pnpyDvcd = dtPMPRRQIF.Rows[i]["PNPY_DVCD"].ToString();
                    string prscNm = dtPMPRRQIF.Rows[i]["PRSC_NM"].ToString();
                    string prscPcft = dtPMPRRQIF.Rows[i]["PRSC_PCFT"].ToString().Trim();
                    bool isPwdrYn = dtPMPRRQIF.Rows[i]["PWDR_YN"].ToString().Equals("Y") ? true : false;

                    if (pnpyDvcd.Equals("5"))
                        continue;

                    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                    // 급비구분 / 처방코드+명 / 1회 투약량 / 1일 투여횟수 / 총 투약일수 /용법
                    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                    this.m_FieldInfo.PNPY = string.Format("[{0}]", OverallCodeList.GetName("PAY_NOPY_DVCD", pnpyDvcd));
                    this.m_FieldInfo.PRSC = string.Format("{0} {1}", edicd, prscNm);
                    this.m_FieldInfo.QTY = string.Format("{0:N4}", Convert.ToDouble(dtPMPRRQIF.Rows[i]["ONTM_QTY"].ToString()));
                    this.m_FieldInfo.NOTM = string.Format("{0:#,##0}", Convert.ToDouble(dtPMPRRQIF.Rows[i]["NOTM"].ToString()));
                    this.m_FieldInfo.NODY = string.Format("{0:#,##0}", Convert.ToDouble(dtPMPRRQIF.Rows[i]["NODY"].ToString()));
                    this.m_FieldInfo.MTHD = aomdmthdcd.Equals("P") ? StringService.IsNvl(prscPcft, aomdMthdNm) : aomdMthdNm;

                    this.m_FieldInfo_List.Add(m_FieldInfo);

                    //사용기간
                    this.m_FieldInfo.USE_PERD = ConfigService.GetConfigValueString("PA", "OUPR", "USE_PERD");

                    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                    // Powder의 경우, 한줄 더 넣어준다.
                    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                    string newRowString = "";

                    if (aomdmthdcd.Equals("P") && isPwdrYn)
                    {
                        newRowString = "[※주의] (Powder)";
                    }
                    else
                    {
                        if (StringService.IsNull(prscPcft))
                        {
                            if (isPwdrYn)
                            {
                                newRowString = "[※주의] (Powder)";
                            }
                        }
                        else
                        {
                            if (isPwdrYn)
                            {
                                newRowString = "[※주의] (Powder) " + prscPcft;
                            }
                            else
                            {
                                newRowString = "[※주의] " + prscPcft;
                            }
                        }
                    }

                    if (StringService.IsNotNull(newRowString))
                    {
                        this.m_FieldInfo = new clsInHospPrescript_FieldInfo();
                        this.m_FieldInfo.PRSC = newRowString;
                        this.m_FieldInfo_List.Add(m_FieldInfo);
                    }
                }

                this.SetReportInfo();

                this.PrintCall();

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.ShowWarning(ex.Message + Environment.NewLine + ex.StackTrace);
                return false;
            }
            finally
            {
                this.Dispose();
            }
        }

        /// <summary>
        /// 인쇄
        /// </summary>
        private void PrintCall()
        {
            this.m_ReportPreViewer.Print();
        }

        /// <summary>
        /// 출력물 세팅
        /// </summary>
        private void SetReportInfo()
        {
            List<ReportPrintDocument.PageSource> PageList = new List<ReportPrintDocument.PageSource>();
            ReportPrintDocument.PageSource Page = new ReportPrintDocument.PageSource();

            m_ReportFullPath = @"\" + m_ReportFileName;
            Page.ReportName = ClientEnvironment.StartupPath + @"\Report\" + m_ReportFullPath;
            Page.DataSource = new string[] { m_ReportFieldName };
            Page.Table = new DataTable[] { DataTableService.ToDataTable(m_FieldInfo_List) };

            PageList.Add(Page);

            this.m_ReportPreViewer.ReportInfo(PageList);
        }

        private string GetORDRTRIF(string pid, string ptcmhsno, string mdcrdd)
        {
            return string.Format(@"
SELECT RESN_CNTS
     , CHCK_KIND_CD
     , PRSC_SQNO
     , PRSC_NM
  FROM ORDRTRIF
 WHERE PID        = '{0}'
   AND PT_CMHS_NO =  {1} 
   AND MDCR_DD    = '{2}'
   AND OTPT_ADMS_DVCD = 'O'
", pid, ptcmhsno, mdcrdd);
        }

        private string GetPMPRRQIF(string mdctno, string pid)
        {
            return string.Format(@"
SELECT A.PID
     , A.PT_CMHS_NO
     , A.MDCR_DR_CD
     , A.PRSC_CD
     , A.MDCR_DD
     , B.EDI_CD
     , CASE NVL(A.MIX_YN, '0') WHEN '0' THEN A.PRSC_NM ELSE '{{MIX'||A.MIX_YN||'}}'||A.PRSC_NM END PRSC_NM
     , A.ONTM_QTY
     , DECODE(A.PRSC_DVCD, 'P', '1', '0') AS PRN_YN
     , A.NOTM
     , A.NODY
     , A.AOMD_MTHD_CD
     , A.PNPY_DVCD
     , A.APLY_ONTM_QTY
     , (SELECT AOMD_MTHD_NM 
          FROM PMMTHDMA
         WHERE AOMD_MTHD_CD = A.AOMD_MTHD_CD 
           AND DEL_YN = 'A'
           AND APLY_SQNO = (SELECT MAX(APLY_SQNO)
                              FROM PMMTHDMA
                             WHERE AOMD_MTHD_CD = A.AOMD_MTHD_CD
                               AND DEL_YN = 'A')) AOMD_MTHD_NM
     , A.PRSC_PCFT
     , A.PRSC_SQNO
     , A.PWDR_YN
     , A.PRSC_LCLS_CD
     , A.PRSC_MCLS_CD
     , A.MDCT_NO
     , C.PT_NM
     , C.FRRN || '-' || C.SRRN RRNO
  FROM PMPRRQIF A
     , PMMFCDMA B
     , PAPATHIN C
 WHERE A.PID = C.PID
   AND A.PRSC_CD = B.MDPR_CD
   AND A.MDCR_DD >= B.APLY_STRT_DD
   AND A.MDCR_DD <= B.APLY_END_DD
   AND A.MDCT_NO = '{0}'
   AND A.PID     = '{1}'
   AND NVL(A.PRV_ACTG_YN, 'N') = 'N' 
   AND (A.PRSC_LCLS_CD = '30' --약만 출력
     OR EXISTS (SELECT 1
                  FROM BISPORMT SOM, BISPORDT SOD
                 WHERE SOM.CHEK_DVCD = SOD.CHEK_DVCD
                   AND SOM.APLY_SQNO = SOD.APLY_SQNO
                   AND SOM.CHEK_DVCD = 'IREC_EXCP'
                   AND SOD.PRSC_CD = A.PRSC_CD
                   AND A.MDCR_DD BETWEEN SOM.APLY_STRT_DD AND SOM.APLY_END_DD
                   AND A.MDCR_DD BETWEEN SOD.APLY_STRT_DD AND SOD.APLY_END_DD
                   AND SOM.DEL_YN = 'A'
                   AND SOD.DEL_YN = 'A'))
   --AND DECODE(B.MDPR_DVCD, '30', B.MDPR_DVCD, DECODE(B.MDPR_DVCD, '40', B.MDPR_DVCD, '%')) LIKE '%'
   --AND A.PWDR_YN LIKE '%'
   --AND (A.OTPT_ADMS_DVCD  = 'I' OR (A.OTPT_ADMS_DVCD = 'O' AND (B.PICE_PRNT_YN = 'Y' OR DECODE(A.PRSC_CLSF_CD, '4', 'J', 'P') = 'P') OR '' = 'R'))
   AND A.PRSC_UNIQ_NO = (SELECT PRSC_UNIQ_NO 
                           FROM ORORDRRT
                          WHERE DC_PRSC_DVCD = 'A'
                            AND PID          = A.PID
                            AND PRSC_UNIQ_NO = A.PRSC_UNIQ_NO)
   AND EXISTS (SELECT *
                 FROM PAOPATRT Z
                WHERE Z.PID = A.PID
                  AND Z.PT_CMHS_NO = A.PT_CMHS_NO
                  AND ROWNUM = 1)
", mdctno, pid);
        }

        private string GetPAOPATRTPAIPATRT(string pid, string ptcmhsno, string mdcrdd)
        {
            return string.Format(@"
    SELECT A.INSN_TYCD
         , A.ASST_TYCD
         , A.MDCR_DR_CD
         , A.MDCR_DD
         , A.ASCT_RGNO_CD
         , A.CFSC_RGNO_CD     --산정특례기호
         , A.VTRN_PT_YN
         , A.PID
         , A.OTPT_ADMS_DVCD
         , A.PAY_QLFC_DVCD
         , A.TBRC_DVCD        --결핵구분코드
         , A.USCH_APLY_CD     --본인부담코드
         , (SELECT FN_BI_READ_USERNM(A.MDCR_DR_CD) FROM DUAL) AS MDCR_DR_NM
         , (SELECT FN_BI_READ_BICDINDT('OCTY_DVCD', (SELECT OCTY_DVCD FROM BIUSERMT WHERE USER_CD = A.MDCR_DR_CD), MDCR_DD, 'LWRN_OVRL_CDNM') FROM DUAL) AS OCTY_DVNM
         , (SELECT LCNO FROM BIUSERMT WHERE USER_CD = A.MDCR_DR_CD) AS LCNO
         , (SELECT INSN_CLAM_DEPT_CD FROM BIDEPTMA WHERE DEPT_CD = MDCR_DEPT_CD AND APLY_STRT_DD <= A.MDCR_DD AND APLY_END_DD >= A.MDCR_DD ) AS INSN_CLAM_DEPT_CD
         , (SELECT FN_PA_READ_PATIENTADDR(A.PID) FROM DUAL) AS ADDRESS
         , NVL((SELECT MIN(MDCR_DD) FROM PAOPATRT WHERE PID = '{0}' AND MDCR_DD > A.MDCR_DD AND ROW_STAT_DVCD = 'A'), '') AS APNT_DD
      FROM
(   SELECT INSN_TYCD
         , ASST_TYCD
         , MDCR_DR_CD
         , MDCR_DD
         , ASCT_RGNO_CD
         , CFSC_RGNO_CD
         , VTRN_PT_YN
         , MDCR_DEPT_CD
         , PID
         , 'O' AS OTPT_ADMS_DVCD
         , PAY_QLFC_DVCD
         , TBRC_DVCD
         , USCH_APLY_CD
      FROM PAOPATRT
     WHERE PID = '{0}'
       AND PT_CMHS_NO = {1}
       AND ROW_STAT_DVCD IN ('A', 'I')
     UNION
    SELECT B.INSN_TYCD
         , B.ASST_TYCD
         , A.MDCR_DR_CD
         , '{2}' AS MDCR_DD
         , A.ASCT_RGNO_CD
         , B.CFSC_RGNO AS CFSC_RGNO_CD
         , A.VTRN_PT_YN
         , A.MDCR_DEPT_CD
         , A.PID
         , 'I' AS OTPT_ADMS_DVCD
         , B.PAY_QLFC_DVCD
         , B.TBRC_DVCD
         , B.USCH_YN_CD AS USCH_APLY_CD
      FROM PAIPATRT A
         , PAIPCHMA B
     WHERE A.PID = B.PID
       AND A.PT_CMHS_NO = B.PT_CMHS_NO
       AND B.APLY_STRT_DD <= '{2}'
       AND B.APLY_END_DD  >= '{2}'
       AND A.PID = '{0}'
       AND A.PT_CMHS_NO = {1}
       AND A.ROW_STAT_DVCD = 'A' 
) A
", pid, ptcmhsno, mdcrdd);
        }

        private string GetORDISRRT(string pid, string ptcmhsno)
        {
            return string.Format(@"
SELECT *
  FROM ORDISRRT
 WHERE PID = '{0}'
   AND PT_CMHS_NO = {1}
   AND DEL_YN = 'A'
 ORDER BY ILNS_DVCD, ILNS_CD
", pid, ptcmhsno);
        }

    }

    public class clsInHospPrescript_FieldInfo
    {
        //======================================================================
        // 보험정보
        //======================================================================
        private string m_INSN_TYCD_1 = string.Empty; public string INSN_TYCD_1 { get { return this.m_INSN_TYCD_1; } set { this.m_INSN_TYCD_1 = value; } }
        private string m_INSN_TYCD_2 = string.Empty; public string INSN_TYCD_2 { get { return this.m_INSN_TYCD_2; } set { this.m_INSN_TYCD_2 = value; } }
        private string m_INSN_TYCD_3 = string.Empty; public string INSN_TYCD_3 { get { return this.m_INSN_TYCD_3; } set { this.m_INSN_TYCD_3 = value; } }
        private string m_INSN_TYCD_4 = string.Empty; public string INSN_TYCD_4 { get { return this.m_INSN_TYCD_4; } set { this.m_INSN_TYCD_4 = value; } }
        private string m_INSN_TYCD_5 = string.Empty; public string INSN_TYCD_5 { get { return this.m_INSN_TYCD_5; } set { this.m_INSN_TYCD_5 = value; } }
        private string m_INSN_TYCD_ETC = string.Empty; public string INSN_TYCD_ETC { get { return this.m_INSN_TYCD_ETC; } set { this.m_INSN_TYCD_ETC = value; } }

        //======================================================================
        // 병원정보
        //======================================================================
        private string m_HPTL_RGNO_CD = string.Empty; public string HPTL_RGNO_CD { get { return this.m_HPTL_RGNO_CD; } set { this.m_HPTL_RGNO_CD = value; } }
        private string m_HSPT_NM = string.Empty; public string HSPT_NM { get { return this.m_HSPT_NM; } set { this.m_HSPT_NM = value; } }
        private string m_TEL = string.Empty; public string TEL { get { return this.m_TEL; } set { this.m_TEL = value; } }
        private string m_FAX_NO = string.Empty; public string FAX_NO { get { return this.m_FAX_NO; } set { this.m_FAX_NO = value; } }

        //======================================================================
        // 환자정보
        //======================================================================
        private string m_MDCT_NO = string.Empty; public string MDCT_NO { get { return this.m_MDCT_NO; } set { this.m_MDCT_NO = value; } }
        private string m_PID = string.Empty; public string PID { get { return this.m_PID; } set { this.m_PID = value; } }
        private string m_PT_NM = string.Empty; public string PT_NM { get { return this.m_PT_NM; } set { this.m_PT_NM = value; } }
        private string m_RRNO = string.Empty; public string RRNO { get { return this.m_RRNO; } set { this.m_RRNO = value; } }

        //======================================================================
        // 상병정보
        //======================================================================
        private string m_ILNS_CD_11 = string.Empty; public string ILNS_CD_11 { get { return this.m_ILNS_CD_11; } set { this.m_ILNS_CD_11 = value; } }
        private string m_ILNS_CD_12 = string.Empty; public string ILNS_CD_12 { get { return this.m_ILNS_CD_12; } set { this.m_ILNS_CD_12 = value; } }
        private string m_ILNS_CD_13 = string.Empty; public string ILNS_CD_13 { get { return this.m_ILNS_CD_13; } set { this.m_ILNS_CD_13 = value; } }
        private string m_ILNS_CD_14 = string.Empty; public string ILNS_CD_14 { get { return this.m_ILNS_CD_14; } set { this.m_ILNS_CD_14 = value; } }
        private string m_ILNS_CD_15 = string.Empty; public string ILNS_CD_15 { get { return this.m_ILNS_CD_15; } set { this.m_ILNS_CD_15 = value; } }
        private string m_ILNS_CD_21 = string.Empty; public string ILNS_CD_21 { get { return this.m_ILNS_CD_21; } set { this.m_ILNS_CD_21 = value; } }
        private string m_ILNS_CD_22 = string.Empty; public string ILNS_CD_22 { get { return this.m_ILNS_CD_22; } set { this.m_ILNS_CD_22 = value; } }
        private string m_ILNS_CD_23 = string.Empty; public string ILNS_CD_23 { get { return this.m_ILNS_CD_23; } set { this.m_ILNS_CD_23 = value; } }
        private string m_ILNS_CD_24 = string.Empty; public string ILNS_CD_24 { get { return this.m_ILNS_CD_24; } set { this.m_ILNS_CD_24 = value; } }
        private string m_ILNS_CD_25 = string.Empty; public string ILNS_CD_25 { get { return this.m_ILNS_CD_25; } set { this.m_ILNS_CD_25 = value; } }

        //======================================================================
        // 의사정보
        //======================================================================
        private string m_DR_NM = string.Empty; public string DR_NM { get { return this.m_DR_NM; } set { this.m_DR_NM = value; } }
        private string m_LCTY = string.Empty; public string LCTY { get { return this.m_LCTY; } set { this.m_LCTY = value; } }
        private string m_LCNO = string.Empty; public string LCNO { get { return this.m_LCNO; } set { this.m_LCNO = value; } }
        private byte[] m_DR_SIGN = null; public byte[] DR_SIGN { get { return this.m_DR_SIGN; } set { this.m_DR_SIGN = value; } }

        //======================================================================
        // 약품정보
        //======================================================================
        private string m_PNPY = string.Empty; public string PNPY { get { return this.m_PNPY; } set { this.m_PNPY = value; } }
        private string m_PRSC = string.Empty; public string PRSC { get { return this.m_PRSC; } set { this.m_PRSC = value; } }
        private string m_QTY = string.Empty; public string QTY { get { return this.m_QTY; } set { this.m_QTY = value; } }
        private string m_NOTM = string.Empty; public string NOTM { get { return this.m_NOTM; } set { this.m_NOTM = value; } }
        private string m_NODY = string.Empty; public string NODY { get { return this.m_NODY; } set { this.m_NODY = value; } }
        private string m_MTHD = string.Empty; public string MTHD { get { return this.m_MTHD; } set { this.m_MTHD = value; } }

        private string m_DUR_CHEK = string.Empty; public string DUR_CHEK { get { return this.m_DUR_CHEK; } set { this.m_DUR_CHEK = value; } }
        private string m_REPRINT = string.Empty; public string REPRINT { get { return this.m_REPRINT; } set { this.m_REPRINT = value; } }
        private string m_USE_PERD = string.Empty; public string USE_PERD { get { return this.m_USE_PERD; } set { this.m_USE_PERD = value; } }
    }
}