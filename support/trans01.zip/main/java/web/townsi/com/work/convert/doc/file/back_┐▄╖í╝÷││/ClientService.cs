using System;
using System.Management;

namespace Lime.Framework
{
    /// <summary>
    /// SystemService에 대한 요약 설명입니다.
    /// </summary>
    public class ClientService
    {
        private static string m_StartupPath = "";
        private static string m_OSVersion = "";

        private static int m_ProcessNumber = 0;

        public ClientService()
        {
        }

        public static string StartupPath
        {
            get
            {
                if (string.IsNullOrWhiteSpace(m_StartupPath))
                {
                    System.Diagnostics.Process p = System.Diagnostics.Process.GetCurrentProcess();
                    return System.IO.Path.GetDirectoryName(p.MainModule.FileName);
                }
                else
                    return m_StartupPath;
            }
            set
            {
                m_StartupPath = value;
            }
        }

        /// <summary>
        /// HDD의 Volume serial number 조회
        /// </summary>
        /// <param name="drive"></param>
        /// <returns></returns>
        public static string GetHDDSerialNumber()
        {
            return GetHDDSerialNumber("C:");
        }

        public static string GetHDDSerialNumber(string drivename)
        {
            string serialnumber = string.Empty;

            ManagementObjectSearcher searcher = new ManagementObjectSearcher(new ObjectQuery("SELECT VolumeSerialNumber FROM Win32_LogicalDisk WHERE Name='" + drivename + "'"));

            try
            {
                foreach (ManagementObject mobj in searcher.Get())
                {
                    serialnumber = mobj["VolumeSerialNumber"].ToString();
                    break;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return serialnumber;
        }

        /// <summary>
        /// Get System IP
        /// </summary>
        public static string IP
        {
            get
            {
                return NetworkService.IP;
            }
        }

        /// <summary>
        /// Get MacAddress
        /// </summary>
        /// <returns></returns>
        public static string GetMacAddress()
        {
            return NetworkService.GetMacAddress();
        }

        public static bool NetworkEnable
        {
            get
            {
                return NetworkService.CheckNetworkAvailable();
            }
        }

        public static string ComputerName
        {
            get
            {
                return System.Windows.Forms.SystemInformation.ComputerName.Trim();
            }
        }

        public static string UserName
        {
            get
            {
                return System.Windows.Forms.SystemInformation.UserName.Trim();
            }
        }

        public static string ProgramVersion
        {
            get
            {
                //return System.Diagnostics.Process.GetCurrentProcess().MainModule.FileVersionInfo.ProductVersion;
                return System.Windows.Forms.Application.ProductVersion;
            }
        }

        public static string ProgramName
        {
            get
            {
                return System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
                //return FileService.GetExecuteFileName();
            }
        }

        public static string OSVersion
        {
            get
            {
                if (StringService.IsNotNull(m_OSVersion))
                    return m_OSVersion;

                m_OSVersion = GetOsVersion();

                return m_OSVersion;
            }
        }

        private static ManagementObject GetManagementObject(string className)
        {
            ManagementClass wmi = new ManagementClass(className);

            foreach (ManagementBaseObject o in wmi.GetInstances())
            {
                ManagementObject mo = (ManagementObject)o;
                if (mo != null) return mo;
            }

            return null;
        }

        public static string GetOsVersion()
        {
            try
            {
                ManagementObject mo = GetManagementObject("Win32_OperatingSystem");

                if (null != mo)
                    return string.Format("{0}({1})", mo["Caption"].ToString(), mo["Version"].ToString());
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return "Unknown O/S Version";
        }

        public static bool Is64Bit
        {
            get
            {
                return Environment.Is64BitOperatingSystem;
            }
        }

        public static int ProcessNumber
        {
            get
            {
                return m_ProcessNumber;
            }
            set
            {
                m_ProcessNumber = value;
            }
        }

        public static bool FristRunClient
        {
            get
            {
                return (ProcessNumber == 1); 
            }
        }
    }
}
