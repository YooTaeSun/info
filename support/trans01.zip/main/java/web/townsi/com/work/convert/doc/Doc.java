package web.townsi.com.work.convert.doc;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import web.townsi.com.utils.Util;

public class Doc {

	private String docType = "";
	private String classNm = "";
	private String onlyFileNm = "";
	
	public static String[] DATE_TYPE = {"decimal", "int", "double", "float", "long", "bool", "string", "DataTable"};
	public static String[] SCOPE_TYPE = {"private", "public"};
	public static String[] NEW_TYPE = {
			"clsOutBillBreakdown", "StringCollection", "clsOutBillTemp", 
			"clsCardCashPermitInfo", "clsTraiLimitInfo", "clsOutReceiptBreakDown",
			"clsSevereDiseaseInfo", "clsOutRegistrationInfo", "clsORCommon", 
			"frmChangePnpyDvcdP", "clsInHospPrescript", "clsNhisM2",
			"DOHospitalInfo", "DOUserInfo", "DOPatientInfo", "DOMenuInfo",
			"frmOutReceiptWatingP", "clsUncollectedDpstInfo", "ucMedicalReceipt", "clsPatientRemark", "clsCommon", "clsPatientRemark",
			"clsPatientSelected", "clsPAReceiptInfo"
	};
	
	

	public Doc(String docType, String classNm) {
		this.docType = docType;
		this.classNm = classNm;
		methodList.add("public void ");
		methodList.add("public bool ");
		methodList.add("public int ");
		methodList.add("public string ");

		methodList.add("private void ");
		methodList.add("private bool ");
		methodList.add("private int ");
		methodList.add("private string ");
		methodList.add("protected override void ");
		methodList.add("protected override bool ");
		methodList.add("void ");

		methodList.add("public static ");
		methodList.add("private static ");
//		methodList.add("private ");
		
		methodList.add("public DataTable ");
		methodList.add("private DataTable ");
		
		methodList.add("private clsNhisM2 ");
		methodList.add("public clsNhisM2 ");
	}

	public static String TAB_SIZE = "    ";
	public static String IMPORT_START_STR = "// import start";
	public static String rLine = "\r\n";
	public static String strOfLine = "<rEaDlInE>";

	List<String> methodList = new ArrayList<String>();

	public String convert(String docType, String str, String onlyFileNm) {

		String[] str_araay = str.split("\\r\\n");
		List<String> list = Arrays.asList(str_araay);

		StringBuilder sb = new StringBuilder(16 ^ 5);
		String line = "";
		String lineBefore = "";
		String lineNext = "";

		String noBlankLine = "";
		String noBlankLineBefore = "";
		String noBlankLineNext = "";

		String trimLine = "";
		String regex = "";
		String lineChg = "";
		String _docType = this.docType;
		this.onlyFileNm = onlyFileNm;

		for (int i = 0; i < list.size(); i++) {
			line = list.get(i);
			
			if (line.contains("DataTable")) {
				System.out.println("");
			}
			
			if (i != 0) {
				lineBefore = list.get(i - 1);
				noBlankLineBefore = Util.removeBlank(lineBefore);
			}
			if (i != (list.size() - 1)) {
				lineNext = list.get(i + 1);
				noBlankLineNext = Util.removeBlank(lineNext);
			}

			line = line.replaceAll("\\t", TAB_SIZE);
			noBlankLine = Util.removeBlank(line);
			trimLine = line.trim();

			// private string 멤버변수
			int commIdx = noBlankLine.indexOf("//");
			String commNoBlankLine = noBlankLine;
			if (commIdx > -1) {
				commNoBlankLine = noBlankLine.substring(0, commIdx);
			}
			
			// 전체
			line = convertLIneAll(line, lineBefore, lineNext, noBlankLine, commNoBlankLine, noBlankLineBefore, noBlankLineNext, trimLine);
			
			// ================= continue start ==============================
			if (line.contains("delegate")) {
				sb.append(line + "\r\n");
				continue;
			}
			if (line.contains(" interface")) {
				sb.append(line + "\r\n");
				continue;
			}
			if (line.contains("DispId")) {
				sb.append(line + "\r\n");
				continue;
			}
			// 처음에 나오는 char, 데이타 타입
			if (line.startsWith("using ") || line.contains(" using ")) {

				if (noBlankLine.contains(Util.removeBlank("using System"))
						|| noBlankLine.contains(Util.removeBlank("using Lime"))
						|| noBlankLine.contains(Util.removeBlank("using PdfSharp"))
						|| noBlankLine.contains(Util.removeBlank("using FarPoint"))
						|| noBlankLine.contains(Util.removeBlank("using SQL"))) {
					continue;
				} else {
					line = line.replaceAll(" using ", " // using ");
					sb.append(line + "\r\n");
					continue;
				}

			} else if (commNoBlankLine.contains("DBService.BeginTransaction()")) {
				line = line.replaceAll("DBService.BeginTransaction", "// DBService.BeginTransaction ");
				sb.append(line + "\r\n");
				continue;
			} else if (commNoBlankLine.contains("[ToolboxItem")) {
				line = line.replaceAll("\\[ToolboxItem", "  // [ToolboxItem");
				sb.append(line + "\r\n");
				continue;
			} else if (line.contains(" DBService.CommitTransaction()")) {
				line = line.replaceAll("DBService.CommitTransaction", "// DBService.CommitTransaction ");
				sb.append(line + "\r\n");
				continue;
			} else if (line.contains(" Infragistics.Win.Appearance")) {
				line = line.replaceAll("Infragistics.Win.Appearance", "// Infragistics.Win.Appearance ");
				sb.append(line + "\r\n");
				continue;
			} else if (commNoBlankLine.contains(Util.removeBlank("if(DBService.IsTransaction"))) {
				regex = "if[\\s]*[(][\\s]*DBService.IsTransaction";
				String startBlank = Util.makeStartBlank(line);
				line = line.replaceAll(regex, "// if(DBService.IsTransaction");
				sb.append(line + "\r\n");
				continue;
			} else if (trimLine.startsWith("namespace ")) {
				if (docType.equals("VUE")) {
					sb.append("<script setup lang=\"ts\">" + "\r\n");
				}
				sb.append(IMPORT_START_STR + "\r\n");
				continue;
				
				
			} else if (trimLine.contains(" class ")) {
				String[] array = line.split("\\s");
				
				regex = "";
				for (int j = 0; j < array.length; j++) {
					String s = array[j].trim();
					if (!array[j].trim().isEmpty()) {
						regex += s + "[\\s]*";
						if (s.equals("class")) {
							break;
						}
					}
				}
				
				if (docType.equals("TS")) {
					String startBlank = Util.makeStartBlank(line);
					if (line.contains(this.classNm)) {
						line = startBlank + "export class " + this.classNm;
						sb.append(line + "\r\n");
						continue;
					} else {
						try {
							
							line = line.replaceFirst(regex, "");
							if (line.contains(":")) {
								String s01= line.substring(0, line.indexOf(":")).trim();
								String s02= " /*" + line.substring(line.indexOf(":") + 1).trim() + "*/";
								line = startBlank + "export class " + s01 + s02;
							} else {
								line = startBlank + "export class " + line.trim();
							}
						} catch (Exception e) {
							// TODO: handle exception
						}
					}
					
				} else if (docType.equals("VUE")) {
					if (line.contains(this.classNm)) {
						continue;
					}
				}
			} else if (trimLine.startsWith("#")) {
				line = line.replaceFirst("#", "// #");
				sb.append(line + "\r\n");
				continue;

				// --------------------- catch start -----------------------------
			} else if (trimLine.startsWith("catch")) {
				line = Util.chgMethodParam(line);
				sb.append(line + "\r\n");
				continue;
				// --------------------- catch end -----------------------------

			} 
			
			// ================= continue end ==============================
			boolean isCheck = false;
			for (int j = 0; j < Doc.NEW_TYPE.length; j++) {
				String type = Doc.NEW_TYPE[j];
				if (trimLine.startsWith(type) && trimLine.contains("new ")) {
					isCheck = true;
				}
			}
			
			if ((!trimLine.contains("class ")
					&& commNoBlankLine.endsWith(";")
					) &&
					(trimLine.contains("private")
					|| trimLine.contains("public")
					|| trimLine.contains("static")
					|| trimLine.contains("const"))
					) {
				// 멤버변수
				line = convertMemberVari(line, lineBefore, lineNext, noBlankLine, commNoBlankLine, noBlankLineBefore, noBlankLineNext, trimLine);
				
			} else if(isCheck) {
				
					line = convertMemberVari(line, lineBefore, lineNext, noBlankLine, commNoBlankLine, noBlankLineBefore, noBlankLineNext, trimLine);
					
			} else if(!trimLine.startsWith("int.TryParse ") 
					&& !trimLine.startsWith("//")
					
					&& (
					trimLine.startsWith("DialogResult ")
					|| trimLine.startsWith("string ")
					|| trimLine.startsWith("int ")
					|| trimLine.startsWith("long ")
					|| trimLine.startsWith("double ")
					|| trimLine.startsWith("float ")
					|| trimLine.startsWith("DataTable ")
					|| trimLine.startsWith("bool ")
					|| trimLine.startsWith("DateTime ")
					|| trimLine.startsWith("object ")
					|| trimLine.startsWith("DOPatientInfo ")
					|| trimLine.startsWith("ScreenParameters ")
					|| trimLine.startsWith("DataRow ")
					|| trimLine.startsWith("for ")
					|| trimLine.startsWith("for(")
					|| trimLine.startsWith("foreach ")
					|| trimLine.startsWith("foreach(")
					|| trimLine.startsWith("DataTable ")
					|| trimLine.startsWith("DialogResult ")
					|| trimLine.startsWith("decimal ")
					|| trimLine.startsWith("string[] ")
					|| trimLine.startsWith("clsNhisM1 ")
							)
					) {
				// 지역변수				
				line = convertLocalVari(line, lineBefore, lineNext, noBlankLine, commNoBlankLine, noBlankLineBefore, noBlankLineNext, trimLine);
			}
			
			if(true) {
				// --------------------- method start -----------------------------
				boolean isMethodUpdate = false;
				
				for (String method : methodList) {
					if (noBlankLine.contains(Util.removeBlank(method)) 
							&& !commNoBlankLine.endsWith(";")
							&& commNoBlankLine.contains("(")
							&& commNoBlankLine.contains(")")
							) {
						
						String[] regexArray = method.split("\\s");
						List<String> regexList = new ArrayList<String>();
						regexList.addAll(Arrays.asList(regexArray));
						if (method.contains("static")) {
							String a1 = line.substring(line.indexOf("static") + "static ".length()).trim();
							String a2 = "";
							try {
								a2 = a1.substring(0, a1.indexOf(" "));
								regexList.add(a2);
							} catch (Exception e) {
								System.out.println("e >> " + e);
							}
							
							lineChg = line.replaceFirst(Util.findNextStr(regexList, "static") + " ", "");
						} else {
							String regexStr = "";
							String regex2 = "";
							
							for (int j = 0; j < regexList.size(); j++) {
								regexStr = regexList.get(j);
								
								if (!regexStr.trim().isEmpty()) {
									// VUE 일때 private, public, static 예약어 남긴다.
									if(docType.equals("TS")) {
										if (regexStr.equals("private") || regexStr.equals("public") || regexStr.equals("static")) {
											continue;
										}										
									}
									
									regex2 += regexStr + "[\\s]*";
								}
							}
							lineChg = line.replaceAll(regex2, "");
							regex = "";
						}
						
						// 변경되어 있다면
						if (!line.equals(lineChg)) {
							isMethodUpdate = true;
							
							line = Util.chgMethodParam(lineChg);
							
							if (_docType.equals("VUE")) {
								line = Util.makeVueConstFormat(line);
							}
							sb.append(line + "\r\n");
							break;
						}
					}
				}
				// --------------------- method end -----------------------------
				if (isMethodUpdate == false) {
					
					// ----------------------- 생성자 메세드 start -------------------------
					
					String classNm = this.classNm;
					if (!classNm.isEmpty() && (noBlankLine.contains(Util.removeBlank("public " + classNm + "("))
							|| noBlankLine.contains(Util.removeBlank("private " + classNm + "(")))) {
						
						if (docType.equals("TS")) {
							line = line.replaceAll("public[\\s*]" + classNm, "constructor");
							line = line.replaceAll("private[\\s*]" + classNm, "constructor");
							line = Util.chgMethodParam(line);
//							line = Util.makeVueConstFormat(line);
						} else {
							line = line.replaceAll("public[\\s*]" + classNm, "constructor");
							line = line.replaceAll("private[\\s*]" + classNm, "constructor");
							line = Util.chgMethodParam(line);
							System.out.println();
							
							
						}
					}
					// ----------------------- 생성자 메세드 end -------------------------
					sb.append(line + "\r\n");
				}
			}

		}

		return sb.toString();
	}

	private String convertLIneAll(String line, String lineBefore, String lineNext,
			String noBlankLine, String commNoBlankLine, String noBlankLineBefore, String noBlankLineNext, String trimLine) {
		
		if (line.indexOf("base.OnLoad(e)") > -1) {
			line = line.replaceAll("base.OnLoad\\(e\\)", " // base.OnLoad(e)");
		} else if (line.contains("OnLoad(EventArgs e)")) {
			line = line.replaceAll("OnLoad\\(EventArgs e\\)", " OnLoad()");
		}
		
		if (line.contains(".Replace(\",\", \"\")")) {
			line = line.replace(".Replace(\",\", \"\")", ".Replace(/,/gi, \"\")");
		}
		
		if (noBlankLine.indexOf("int.TryParse(") > -1) {
			line = line.replaceAll("int.TryParse\\(", "Int.TryParse(");
		}
		
		if (line.contains("btnButtonList.Initialize()")) {
			line = line.replace("btnButtonList.Initialize()", "btnButtonList.InitializeButtons()");
		}
		if (noBlankLine.indexOf("int.Parse(") > -1) {
			line = line.replaceAll("int.Parse\\(", "Int.Parse(");
		}
		if (noBlankLine.indexOf("DBService.RollbackTransaction") > -1) {
			line = line.replaceAll("DBService.RollbackTransaction", "// DBService.RollbackTransaction");
		}
		if (line.indexOf("string.Empty") > -1) {
			line = line.replaceAll("string.Empty", "String.Empty");
		}
		if (line.indexOf("string.Join") > -1) {
			line = line.replaceAll("string.Join", "String.Join");
		}
		if (line.indexOf("string.IsNullOrWhiteSpace") > -1) {
			line = line.replaceAll("string.IsNullOrWhiteSpace", "String.IsNullOrWhiteSpace");
		}
		if (line.indexOf("string.IsNullOrEmpty") > -1) {
			line = line.replaceAll("string.IsNullOrEmpty", "String.IsNullOrEmpty");
		}
		if (line.indexOf("string.Format") > -1) {
			line = line.replaceAll("string.Format", "String.Format");
		}
		if (line.contains(" out ")) {
			line = line.replaceAll(" out ", " /*out*/ ");
		}
		if (line.contains("SqlPack.Function.")) {
			line = line.replaceAll("SqlPack.Function.", "Function.");
		}
		if (line.contains("String.Format(\"{0:#,###}\"")) {
			line = line.replace("String.Format(\"{0:#,###}\"", "String.Format(\"{0:#,#0#}\"");
		}
		if (line.contains("string.Format(\"{0:#,###}\"")) {
			line = line.replace("string.Format(\"{0:#,###}\"", "String.Format(\"{0:#,#0#}\"");
		}
		if (line.contains("SQL.Function.")) {
			line = line.replaceAll("SQL.Function.", "Function.");
		}
		if (line.contains("SQL.Procedure.")) {
			line = line.replaceAll("SQL.Procedure.", "Procedure.");
		}
		if (line.contains("SqlPack.Procedure.")) {
			line = line.replaceAll("SqlPack.Procedure.", "Procedure.");
		}
		if (line.contains("(out ")) {
			line = line.replace("(out ", "(");
		}
		if (line.contains(" ref ")) {
			line = line.replaceAll(" ref ", " /*ref*/ ");
		}
		if (line.contains(" var ")) {
			line = line.replaceAll(" var ", " let ");
		}
		if (line.contains("(ref ")) {
			line = line.replace("(ref ", "(");
		}
		if (line.contains("Lime.BusinessControls.clsCommon.")) {
			line = line.replace("Lime.BusinessControls.clsCommon.", "clsCommon.");
		}
		if (line.contains("LxMessage.")) {
			if (docType.equals("TS")) {
				String classNm = this.classNm;
				if (!classNm.isEmpty()) {
					line = line.replace("LxMessage.", "await "+ classNm +".LxMessage.");	
				}else {
					line = line.replace("LxMessage.", "await LxMessage.");
				}	
			} else {
				line = line.replace("LxMessage.", "await LxMessage.");
			}
		}
		if (line.contains("OverallCodeList.GetDataList") &&  !line.contains("await OverallCodeList.GetDataList")) {
			line = line.replace("OverallCodeList.GetDataList", "await OverallCodeList.GetDataList");
		}
		if (line.contains("OverallCodeList.GetDataList") &&  !line.contains("await OverallCodeList.GetDataList")) {
			line = line.replace("OverallCodeList.GetDataList", "await OverallCodeList.GetDataList");
		}
		if (line.contains("ConfigService.GetConfigValueString") &&  !line.contains("await ConfigService.GetConfigValueString")) {
			line = line.replace("ConfigService.GetConfigValueString", "await ConfigService.GetConfigValueString");
		}
		if (line.contains("ConfigService.GetConfigValueBool") &&  !line.contains("await ConfigService.GetConfigValueBool")) {
			line = line.replace("ConfigService.GetConfigValueBool", "await ConfigService.GetConfigValueBool");
		}
		if (line.contains("clsPACommon.HasPatientMemo(") &&  !line.contains("await clsPACommon.HasPatientMemo(")) {
			line = line.replace("clsPACommon.HasPatientMemo(", "await clsPACommon.HasPatientMemo(");
		}
		if (line.contains("clsPACommon.ReturnPrscIssuedCnt(") &&  !line.contains("await clsPACommon.ReturnPrscIssuedCnt(")) {
			line = line.replace("clsPACommon.ReturnPrscIssuedCnt(", "await clsPACommon.ReturnPrscIssuedCnt(");
		}
		if (line.contains("clsPACommon.ShowMessage_UnclAmt(") &&  !line.contains("await clsPACommon.ShowMessage_UnclAmt(")) {
			line = line.replace("clsPACommon.ShowMessage_UnclAmt(", "await clsPACommon.ShowMessage_UnclAmt(");
		}
		if (line.contains("OutProfitTp.GetPaOpraTpForSave(") &&  !line.contains("await OutProfitTp.GetPaOpraTpForSave(")) {
			line = line.replace("OutProfitTp.GetPaOpraTpForSave(", "await OutProfitTp.GetPaOpraTpForSave(");
		}
		if (line.contains("OutProfitTp.GetPaOpraTpForBill(") &&  !line.contains("await OutProfitTp.GetPaOpraTpForBill(")) {
			line = line.replace("OutProfitTp.GetPaOpraTpForBill(", "await OutProfitTp.GetPaOpraTpForBill(");
		}
		if (line.contains("clsPACommon.GetDtCbo") &&  !line.contains("await clsPACommon.GetDtCbo")) {
			line = line.replace("clsPACommon.GetDtCbo", "await clsPACommon.GetDtCbo");
		}
		if (line.contains("clsPACommon.CheckCreditPermit") &&  !line.contains("await clsPACommon.CheckCreditPermit")) {
			line = line.replace("clsPACommon.CheckCreditPermit", "await clsPACommon.CheckCreditPermit");
		}
		
		if (line.contains("ClinicList.GetDataList") &&  !line.contains("await ClinicList.GetDataList")) {
			line = line.replace("ClinicList.GetDataList", "await ClinicList.GetDataList");
		}
		if (line.contains("UserList.GetDataList") &&  !line.contains("await UserList.GetDataList")) {
			line = line.replace("UserList.GetDataList", "await UserList.GetDataList");
		}
		if (line.contains("ConfigService.GetConfigValueDirect")) {
			line = line.replace("ConfigService.GetConfigValueDirect", "await ConfigService.GetConfigValueDirect");
		}			
		if (commNoBlankLine.contains("DBService.")) {
			if (line.contains("DBService.ExecuteDataTable")) {
				line = line.replace("DBService.ExecuteDataTable", "await DBService.ExecuteDataTable");
			}
			if (line.contains("DBService.ExecuteScalar")) {
				line = line.replace("DBService.ExecuteScalar", "await DBService.ExecuteScalar");
			}
			if (line.contains("DBService.ExecuteInteger")) {
				line = line.replace("DBService.ExecuteInteger", "await DBService.ExecuteInteger");
			}
			if (line.contains("DBService.ExecuteNonQuery")) {
				line = line.replace("DBService.ExecuteNonQuery", "await DBService.ExecuteNonQuery");
			}
		}
		
		if (trimLine.contains("Lime.BusinessControls.clsPACommon.")) {
			line = line.replace("Lime.BusinessControls.clsPACommon.", "clsPACommon.");
		}
		if (trimLine.contains("FarPoint.Win.Spread.VerticalPosition")) {
			line = line.replace("FarPoint.Win.Spread.VerticalPosition", "VerticalPosition");
		}
		if (trimLine.contains("FarPoint.Win.Spread.HorizontalPosition")) {
			line = line.replace("FarPoint.Win.Spread.HorizontalPosition", "HorizontalPosition");
		}
		if (trimLine.contains("FarPoint.Win.Spread.CellHorizontalAlignment")) {
			line = line.replace("FarPoint.Win.Spread.CellHorizontalAlignment", "CellHorizontalAlignment");
		}
		if (trimLine.contains("System.Drawing.FontStyle.")) {
			line = line.replace("System.Drawing.FontStyle.", "FontStyle.");
		}
		
		if (docType.equals("VUE")) {
			if (trimLine.contains("LxSpread.")) {
				line = line.replace("LxSpread.", "");
			}
			if (line.contains(" this.")) {
				line = line.replace(" this.", " ");
			}
			if (line.contains("(this.")) {
				line = line.replace("this.", "");
			}
			
			if (trimLine.contains("(int)COL")) {
				line = line.replace("(int)COL", "COL");
			}
		}
		if (commNoBlankLine.contains(Util.removeBlank("new Exception"))) {
			line = line.replaceAll("new[\\s]+Exception", "new Error");
			line = line.replace("(ex.Message)", "(ex.message)"); 
		}
		
//			private enum COL
		if (commNoBlankLine.contains(Util.removeBlank("private enum "))) {
			line = line.replaceFirst("private ", "");
		}
		if (commNoBlankLine.contains(Util.removeBlank("public enum "))) {
			line = line.replaceFirst("public ", "");
		}
		return line;
	}

	private String convertLocalVari(String line, String lineBefore, String lineNext,
			String noBlankLine, String commNoBlankLine, String noBlankLineBefore, String noBlankLineNext, String trimLine) {
		String regex = "";
		// 지역변수				
		// DialogResult dr = "" ====> let dr:DialogResult = ""
		if (trimLine.contains("DialogResult ")) {
			line = Util.chgLocalVari(line, "DialogResult ");
		}
		// string aaa = "" ====> let aaa:string = ""
		if (trimLine.contains("string ") && !trimLine.contains("(string")) {
			line = Util.chgLocalVari(line, "string ");
		}
		// int aaa = "" ====> let aaa:number = ""
		if (trimLine.contains("int ") && !trimLine.contains("(int")) {
			line = Util.chgLocalVari(line, "int ");
		}
		if (trimLine.contains("decimal ") && !trimLine.contains("(decimal")) {
			line = Util.chgLocalVari(line, "decimal ");
		}
		// long aaa = "" ====> let aaa:number = ""
		if (trimLine.contains("long ") && !trimLine.contains("(long")) {
			line = Util.chgLocalVari(line, "long ");
		}
		if (trimLine.contains("double ") && !trimLine.contains("(double")) {
			line = Util.chgLocalVari(line, "double ");
		}
		if (trimLine.contains("float ") && !trimLine.contains("(float")) {
			line = Util.chgLocalVari(line, "float ");
		}
		// DataTable aaa = "" ====> let aaa:DataTable = ""
		if (trimLine.contains("DataTable ") && !trimLine.contains("(DataTable")) {
			line = Util.chgLocalVari(line, "DataTable ");
		}
		// bool aaa = "" ====> let aaa:boolean = ""
		if (trimLine.contains("bool ") && !trimLine.contains("(bool")) {
			line = Util.chgLocalVari(line, "bool ");
		}
		// DateTime aaa = "" ====> let aaa:DateTime = ""
		if (trimLine.contains("DateTime ") && !trimLine.contains("(DateTime")) {
			line = Util.chgLocalVari(line, "DateTime ");
		}
		// object aaa = "" ====> let aaa:Object = ""
		if (trimLine.contains("object ") && !trimLine.contains("(object")) {
			line = Util.chgLocalVari(line, "object ");
		}
		if (trimLine.contains("DOPatientInfo ") && !trimLine.contains("(DOPatientInfo")) {
			line = Util.chgLocalVari(line, "DOPatientInfo ");
		}
		if (trimLine.contains("ScreenParameters ") && !trimLine.contains("(ScreenParameters")) {
			line = Util.chgLocalVari(line, "ScreenParameters ");
		}
		// DataRow row = ====> let row =
		if (trimLine.contains("DataRow ")) {
			line = Util.chgLocalVari(line, "DataRow ");
			regex = ":DataRow[\\s]*[=]";
			line = line.replaceAll(regex, " =");
		}
		// string[] progress_texts 		
		if (trimLine.contains("string[] ")) {
//			line = Util.chgLocalVari(line, "string[] ");
//			regex = ":string[][\\s]*[=]";
			String startBlank = Util.makeStartBlank(line);
			String lineChg = line.replace("string[] ", "").trim();
			if (!line.equals(lineChg)) {
				line = startBlank + "let " + lineChg;
			}
		}
		if (trimLine.contains("clsNhisM1 ") && !trimLine.contains("(clsNhisM1")) {
			line = Util.chgLocalVari(line, "clsNhisM1 ");
		}
		
		// for 문			
		if (commNoBlankLine.startsWith("foreach(DataRow")
				&& trimLine.contains("DataRow ")
				&& trimLine.contains(" in ")
				&& (
						commNoBlankLine.endsWith(")") ||
						commNoBlankLine.endsWith(")}")
						)) {
			line = line.replaceFirst("foreach", "for")
			.replaceFirst("DataRow", "const")
			.replaceFirst(" in ", " of ");
			
		} else if (commNoBlankLine.startsWith("for") && commNoBlankLine.endsWith(")")) {
			if (trimLine.contains("int ")) {
				line = Util.chgLocalVari(line, "int ");
			}
		} else if (trimLine.contains("DataTable ") && !trimLine.contains("(DataTable") && commNoBlankLine.endsWith(");")) {
			line = Util.chgLocalVari(line, "DataTable ");
		} else if (trimLine.contains("DialogResult ") && !trimLine.contains("(DialogResult") && commNoBlankLine.endsWith(");")) {
			line = Util.chgLocalVari(line, "DialogResult ");
		}
		return line;
	}

	private String convertMemberVari(String line, String lineBefore, String lineNext,
			String noBlankLine, String commNoBlankLine, String noBlankLineBefore, String noBlankLineNext, String trimLine) {
		boolean isNumberType = false;
		

		
		String nType = ""; 
		for (int sdx = 0; sdx < SCOPE_TYPE.length; sdx++) {
			String scope = SCOPE_TYPE[sdx];
			
			for (int ndx = 0; ndx < DATE_TYPE.length; ndx++) {
				nType = DATE_TYPE[ndx];
				
				if (noBlankLine.contains(Util.removeBlank(scope + " "+nType +" "))) {
					
					line = Util.chgMemberVari(this.docType, line, (scope + " "+nType));
					
					isNumberType = true;
					break;
				}
				if (noBlankLine.contains(Util.removeBlank(scope + " static "+nType +" "))) {
					line = Util.chgMemberVari(this.docType, line.replace("static ", ""), (scope + " "+nType));
					isNumberType = true;
					break;
				}
				if (noBlankLine.contains(Util.removeBlank(scope + " const "+nType +" "))) {
					line = Util.chgMemberVari(this.docType, line.replace("const ", ""), (scope + " "+nType));
					isNumberType = true;
					break;
				}
			}
			
			if (!isNumberType) {
				for (int edx = 0; edx < NEW_TYPE.length; edx++) {
					nType = NEW_TYPE[edx];
					if (noBlankLine.contains(Util.removeBlank(nType+" "))) {
						line = Util.chgMemberVari(this.docType, line, (nType));
						break;
					}
					if (noBlankLine.contains(Util.removeBlank(scope + "static "+nType +""))) {
						line = Util.chgMemberVari(this.docType, line.replace("static ", ""), (scope + " " + nType));
						break;
					}
					if (noBlankLine.contains(Util.removeBlank(scope + "const "+nType+" "))) {
						line = Util.chgMemberVari(this.docType, line.replace("const ", ""), (scope + " " + nType));
						break;
					}						
				}
			}
		}
		
		if (noBlankLine.contains(Util.removeBlank("private clsUnCollectedOcrrInfo "))) {
			line = Util.chgMemberVari(this.docType, line, "private clsUnCollectedOcrrInfo ".trim());
		}
		
		if (noBlankLine.contains(Util.removeBlank("private static LxMessage "))) {
			line = Util.chgMemberVari(this.docType, line.replace("static ", ""), "private LxMessage ".trim());
		}
		return line;
	}

}