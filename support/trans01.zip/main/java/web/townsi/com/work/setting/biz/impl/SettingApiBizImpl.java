package web.townsi.com.work.setting.biz.impl;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;
import web.townsi.com.utils.ListUtil;
import web.townsi.com.work.mapper.SettingMapper;
import web.townsi.com.work.setting.biz.SettingApiBiz;
import web.townsi.com.work.setting.biz.SettingBiz;

/**
* SettingServiceImpl
* @author 유태선
* @since 2020.08.31
* @version 1.0
* @see
* </pre>
*/
@SuppressWarnings({"rawtypes","unchecked","unused"})
@Service
public class SettingApiBizImpl implements SettingApiBiz {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private SettingBiz settingBiz;

	@Autowired
	private SettingMapper settingMapper;

	public static String READ_LINE = "\n";
	public static String TAB = "\t";
	public static String SLASH = File.separator;// lastIndexOf("/")


	public static String rTxt  = "#{txt}";

	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();


	public List<HashMap> selectTableList(HashMap params){

		List<HashMap>  list = null;
		String dbName = StringUtils.defaultString((String)params.get("dbName"));
		list = settingMapper.selectTableList(params);
		return list;
	}

	public HashMap makeApi(HashMap params) throws Exception {

		HashMap dataMap = new HashMap();

		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String upperTableName = StringUtils.defaultString((String) params.get("upperTableName"));
		String lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		String camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		String tableSchema = StringUtils.defaultString((String) params.get("tableSchema"));
		String camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String modelComment = StringUtils.defaultString((String) params.get("modelComment"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String group1 = StringUtils.defaultString((String) params.get("group1"));
		String author = StringUtils.defaultString((String) params.get("author"));
		String today = StringUtils.defaultString((String) params.get("today"));
		String current = StringUtils.defaultString((String) params.get("current"));
		String desc = StringUtils.defaultString((String) params.get("desc"));
		String path1 = StringUtils.defaultString((String) params.get("path1"));
		String path2 = StringUtils.defaultString((String) params.get("path2"));
		String path3 = StringUtils.defaultString("/" + (String) params.get("path3"), "/com/" + group);
		String menu = StringUtils.defaultString((String) params.get("menu"));
		String programId = StringUtils.defaultString((String) params.get("programId"));
		String sort = StringUtils.defaultString((String) params.get("sort"));
		String taskName = StringUtils.defaultString((String) params.get("taskName"));
		String taskNameFirstUpperName = StringUtils.defaultString((String) params.get("taskNameFirstUpperName"));

		List<HashMap> list = settingBiz.selectTableInfo(params,
				  StringUtils.defaultString((String)params.get("dbName"))
				, StringUtils.defaultString((String)params.get("tableSchema"))
			    , StringUtils.defaultString((String)params.get("tableName"))
				);

		List<HashMap> pkList = list.stream().
				filter(map ->  {
					String pk = StringUtils.defaultString((String) map.get("pk"));
					String columnName = StringUtils.defaultString((String)map.get("column_name"));
					//PK이고 컬럼 이름 _ID 존재
					if(pk.equals("pk")){
						return true;
					}else {
						return false;
					}
				})
				.collect(Collectors.toList());

		HashMap replaceMap = new HashMap();

		if(!ListUtil.isEmpty(pkList)){
			//id 존재
			String pkJoinStr = "\""+ pkList.stream().map(o->o.get("column_name").toString()).collect(Collectors.joining("\",\"")) + "\"";
			String sortStr = "sort="+ pkList.stream().map(o->o.get("column_name").toString()).collect(Collectors.joining(",ASC&sort=")) + ",ASC";
			replaceMap.put("#pkJoinStr#",pkJoinStr);
			replaceMap.put("#sortStr#", sortStr);
		}else {
			replaceMap.put("#pkJoinStr#","");
			replaceMap.put("#sortStr#","");
		}

		replaceMap.put("#mainPath#","");

		//AppStartingEvent.java --> copyArray
		String rfullPath = "";
		rfullPath = SITE_WEB_ROOT + "/copy/SampleApi3.java";
		String wfullPath = "";
		wfullPath = SITE_WEB_ROOT + "/new/" + tableSchema + "/" + tableName+"/"+taskNameFirstUpperName+"Controller.java";



		replaceMap.put("#group#",group);
		replaceMap.put("#group1#",group1);
		replaceMap.put("#today#",today);
		replaceMap.put("#current#",current);
		replaceMap.put("#author#",author);
		replaceMap.put("#menu#",menu);
		replaceMap.put("#programId#",programId);
		replaceMap.put("#camelTableFirstUpperName#",camelTableFirstUpperName);
		replaceMap.put("#camelTableName#",camelTableName);
		replaceMap.put("#lowerTableName#",camelTableFirstUpperName.toLowerCase());
		replaceMap.put("#desc#",desc);
		replaceMap.put("#path1#",path1);
		replaceMap.put("#path2#",path2);
		replaceMap.put("#path3#",path3);
		replaceMap.put("#taskName#",taskName);
		replaceMap.put("#taskNameFirstUpperName#",taskNameFirstUpperName);

		String str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);
		dataMap.put("str", str);
		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}
}