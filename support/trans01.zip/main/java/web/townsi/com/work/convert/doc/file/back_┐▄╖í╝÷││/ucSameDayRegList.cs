//********************************************************************
// Class 명 : ucSameDayRegList
// 역    할 : 동일날 외래접수내역 User Control
// 작 성 자 : PGH
// 작 성 일 : 2017-09-19
//********************************************************************
// 수정내역 : 
//********************************************************************

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    [ToolboxItem(true)]
    public partial class ucSameDayRegList : BaseUserControl
    {
        #region Define : Event
        public delegate void PatientSelectedEventHandler(object sender, SelectDataEventArgs e);
        public event PatientSelectedEventHandler PatientSelected;
        #endregion

        #region Define : Member
        public int m_RegCount = 0;
        private string m_Pid = String.Empty;
        private string m_MdcrDd = String.Empty;
        private string m_Dvcd = String.Empty;
        #endregion Define : Member

        #region Define : Member Property
        public string Dvcd { set { m_Dvcd = value; } }
        public string Pid { set { m_Pid = value; } }
        public string MdcrDd { set { m_MdcrDd = value; } }
        #endregion 

        #region Enum : Private Enum
        private enum COL
        {
            PID,
            PT_NM,
            PT_CMHS_NO,
            MDCR_DEPT_CD,
            DEPT_NM,
            MDCR_DR_CD,
            DR_NM,
            INSN_TYCD,
            INSN_TYNM,
            ASST_TYCD,
            ASST_TYNM,
            FRVS_RVST_DVCD,
            MCCH_CMPT_DVCD,
            MDCR_DD,
            MDCR_TIME,
            APNT_TIME,
            FRRN,
            SRRN,
            SRRN_ECPT,
            SEX_DVCD,
            AGE,
            WAIT_STAT,
            PRSC_NOTM,
            RCPT_NOTM,
            ORD_NOTM,
            REC_NOTM
        }
        private enum COL_POP
        {
            PID,
            PT_NM,
            PT_CMHS_NO,
            MDCR_DEPT_CD,
            FRRN,
            SRRN,
            SRRN_ECPT,
            SEX_DVCD,
            AGE,
            DEPT_NM,
            MDCR_DR_CD,
            DR_NM,
            INSN_TYCD,
            INSN_TYNM,
            ASST_TYCD,
            ASST_TYNM,
            FRVS_RVST_DVCD,
            MCCH_CMPT_DVCD,
            MDCR_DD,
            MDCR_TIME,
            APNT_TIME,
            WAIT_STAT,
            PRSC_NOTM,
            RCPT_NOTM,
            ORD_NOTM,
            REC_NOTM
        }
        #endregion

        #region Construction
        public ucSameDayRegList()
        {
            InitializeComponent();
        }
        #endregion

        #region Screen Load
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode) return;


            if (StringService.IsNotNull(this.m_Dvcd))
            {
                this.lxTitlePanel1.TitleText = "2개과 이상 접수내역";
                InitializeSpreadPop();
            }
            else
            {
                this.lxTitlePanel1.TitleText = "타과 접수내역";
                InitializeSpread();
            }

            InitializeEvent();
            InitializeSpreadCombo();

            this.SelectData(this.m_Pid, this.m_MdcrDd);
        }
        #endregion

        #region Method : Initialize Method
        private void InitializeEvent()
        {
            sprSameDayRegList.KeyDown += sprSameDayRegList_KeyDown;
            sprSameDayRegList.CellClick += sprSameDayRegList_CellClick;
        }

        private void InitializeSpreadCombo()
        {
            sprSameDayRegList.SetComboItems("INSN_TYCD", OverallCodeList.GetDataList("INSN_TYCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            sprSameDayRegList.SetComboItems("ASST_TYCD", OverallCodeList.GetDataList("INSN_TYCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            sprSameDayRegList.SetComboItems("FRVS_RVST_DVCD", OverallCodeList.GetDataList("FRVS_RVST_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            sprSameDayRegList.SetComboItems("MCCH_CMPT_DVCD", OverallCodeList.GetDataList("MCCH_CMPT_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
        }
        private void InitializeSpread()
        {
            /*
             * sprSameDayRegList
             */
            this.sprSameDayRegList.SetSpreadSheet(this.sprSameDayRegList.ActiveSheet, FarPoint.Win.Spread.Model.SelectionPolicy.Single, FarPoint.Win.Spread.Model.SelectionUnit.Cell, FarPoint.Win.Spread.SelectionStyles.Both, FarPoint.Win.Spread.OperationMode.RowMode, false, false, FarPoint.Win.Spread.ButtonDrawModes.CurrentCell, true, true, FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded, FarPoint.Win.Spread.ScrollBarPolicy.Always, true, false, false, false);

            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.PID, "PID", "!환자등록번호", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.PT_NM, "PT_NM", "!환자명", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.PT_CMHS_NO, "PT_CMHS_NO", "!환자내원번호", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.MDCR_DEPT_CD, "MDCR_DEPT_CD", "!진료부서", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.DEPT_NM, "DEPT_NM", "진료부서", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.MDCR_DR_CD, "MDCR_DR_CD", "!진료의사", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.DR_NM, "DR_NM", "진료의사", 60, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.INSN_TYCD, "INSN_TYCD", "!보험유형", 60, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.INSN_TYNM, "INSN_TYNM", "보험유형", 60, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.ASST_TYCD, "ASST_TYCD", "!보조유형", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.ASST_TYNM, "ASST_TYNM", "보조유형", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.FRVS_RVST_DVCD, "FRVS_RVST_DVCD", "초재진", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.ComboBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.MCCH_CMPT_DVCD, "MCCH_CMPT_DVCD", "산정구분", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.ComboBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.MDCR_DD, "MDCR_DD", "진료일자", 80, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.MaskCellTypeYMD);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.MDCR_TIME, "MDCR_TIME", "진료시간", 60, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.MaskCellTypeHM);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.APNT_TIME, "APNT_TIME", "!예약시간", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.FRRN, "FRRN", "!주민등록앞번호", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.SRRN, "SRRN", "!주민등록뒷번호", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.SRRN_ECPT, "SRRN_ECPT", "!주민뒷번호암호화", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.SEX_DVCD, "SEX_DVCD", "성별", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.AGE, "AGE", "연령", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.WAIT_STAT, "WAIT_STAT", "수납상태", 60, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.PRSC_NOTM, "PRSC_NOTM", "처방횟수", 70, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.RCPT_NOTM, "RCPT_NOTM", "수납횟수", 70, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.ORD_NOTM, "ORD_NOTM", "!처방횟수", 70, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL.REC_NOTM, "REC_NOTM", "!수납처방횟수", 70, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);

            //this.sprSameDayRegList.AutoFitColumnName = "PT_NM";
            //this.sprSameDayRegList.AutoFitColumnType = LxSpread.AUTO_FIT_COLUMN_TYPE.AllColumn;

            this.sprSameDayRegList.AutoFirstAppendRow = false;
            this.sprSameDayRegList.AutoLastAppendRow = false;
            this.sprSameDayRegList.ActiveSheet.ColumnCount = (int)COL.REC_NOTM + 1;
            this.sprSameDayRegList.ActiveSheet.RowCount = 0;
            this.sprSameDayRegList.ActiveSheet.ColumnHeader.Rows[0].Height = 22;
            this.sprSameDayRegList.ActiveSheet.RowHeader.Visible = false;

            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.PID).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.PT_NM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.PT_CMHS_NO).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.DEPT_NM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.DR_NM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.INSN_TYNM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.ASST_TYNM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.FRVS_RVST_DVCD).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.MCCH_CMPT_DVCD).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.MDCR_DD).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.MDCR_TIME).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.APNT_TIME).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.FRRN).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.SRRN).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.SRRN_ECPT).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.SEX_DVCD).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.AGE).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.WAIT_STAT).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.PRSC_NOTM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.RCPT_NOTM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.ORD_NOTM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.REC_NOTM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.DEPT_NM).CellPadding.Left = 0;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.DR_NM).CellPadding.Left = 0;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL.INSN_TYNM).CellPadding.Left = 0;

        }

        private void InitializeSpreadPop()
        {
            /*
             * sprSameDayRegList
             */
            this.sprSameDayRegList.SetSpreadSheet(this.sprSameDayRegList.ActiveSheet, FarPoint.Win.Spread.Model.SelectionPolicy.Single, FarPoint.Win.Spread.Model.SelectionUnit.Cell, FarPoint.Win.Spread.SelectionStyles.Both, FarPoint.Win.Spread.OperationMode.RowMode, false, false, FarPoint.Win.Spread.ButtonDrawModes.CurrentCell, true, true, FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded, FarPoint.Win.Spread.ScrollBarPolicy.Always, true, false, false, false);

            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.PID, "PID", "환자등록번호", 80, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.PT_NM, "PT_NM", "환자성명", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.FRRN, "FRRN", "주민앞번호", 70, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.SRRN, "SRRN", "주민뒷번호", 70, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.SRRN_ECPT, "SRRN_ECPT", "!주민뒷번호암호화", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.SEX_DVCD, "SEX_DVCD", "성별", 34, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.AGE, "AGE", "연령", 34, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.PT_CMHS_NO, "PT_CMHS_NO", "!환자내원번호", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.MDCR_DEPT_CD, "MDCR_DEPT_CD", "!진료부서", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.DEPT_NM, "DEPT_NM", "진료부서", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.MDCR_DR_CD, "MDCR_DR_CD", "!진료의사", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.DR_NM, "DR_NM", "진료의사", 60, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.INSN_TYCD, "INSN_TYCD", "!보험유형", 60, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.INSN_TYNM, "INSN_TYNM", "보험유형", 60, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.ASST_TYCD, "ASST_TYCD", "!보조유형", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.ASST_TYNM, "ASST_TYNM", "보조유형", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.FRVS_RVST_DVCD, "FRVS_RVST_DVCD", "초재진", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.ComboBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.MCCH_CMPT_DVCD, "MCCH_CMPT_DVCD", "산정구분", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.ComboBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.MDCR_DD, "MDCR_DD", "진료일자", 80, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.MaskCellTypeYMD);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.MDCR_TIME, "MDCR_TIME", "진료시간", 60, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.MaskCellTypeHM);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.APNT_TIME, "APNT_TIME", "!예약시간", 70, LxSpread.CELL_HALIGNMENT.Left, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.WAIT_STAT, "WAIT_STAT", "수납상태", 60, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.PRSC_NOTM, "PRSC_NOTM", "!처방횟수", 70, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.RCPT_NOTM, "RCPT_NOTM", "!수납횟수", 70, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.ORD_NOTM, "ORD_NOTM", "!처방횟수", 70, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);
            this.sprSameDayRegList.SetSpreadSheetColumn(this.sprSameDayRegList.ActiveSheet, (int)COL_POP.REC_NOTM, "REC_NOTM", "!수납처방횟수", 70, LxSpread.CELL_HALIGNMENT.Center, LxSpread.CELL_VALIGNMENT.Center, LxSpread.CELLTYPE.TextBoxCellType);

            this.sprSameDayRegList.AutoFitColumnName = "PT_NM";
            this.sprSameDayRegList.AutoFitColumnType = LxSpread.AUTO_FIT_COLUMN_TYPE.AllColumn;

            this.sprSameDayRegList.AutoFirstAppendRow = false;
            this.sprSameDayRegList.AutoLastAppendRow = false;
            this.sprSameDayRegList.ActiveSheet.ColumnCount = (int)COL.REC_NOTM + 1;
            this.sprSameDayRegList.ActiveSheet.RowCount = 0;
            this.sprSameDayRegList.ActiveSheet.ColumnHeader.Rows[0].Height = 22;
            this.sprSameDayRegList.ActiveSheet.RowHeader.Visible = false;

            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.PID).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.PT_NM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.PT_CMHS_NO).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.DEPT_NM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.DR_NM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.INSN_TYNM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.ASST_TYNM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.FRVS_RVST_DVCD).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.MCCH_CMPT_DVCD).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.MDCR_DD).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.MDCR_TIME).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.APNT_TIME).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.FRRN).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.SRRN).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.SRRN_ECPT).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.SEX_DVCD).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.AGE).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.WAIT_STAT).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.PRSC_NOTM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.RCPT_NOTM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.ORD_NOTM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.REC_NOTM).Locked = true;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.DEPT_NM).CellPadding.Left = 0;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.DR_NM).CellPadding.Left = 0;
            this.sprSameDayRegList.ActiveSheet.Columns.Get((int)COL_POP.INSN_TYNM).CellPadding.Left = 0;

        }
        #endregion

        #region Method : Public Method
        public void Clear()
        {
            sprSameDayRegList.Clear();
        }
        #region Method : Select Method
        /// <summary>
        /// 동일날 접수건수가 2건 이상인 경우 보여준다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="mdcrdd"></param>
        public void SelectData(string pid, string mdcrdd)
        {
            DataTable dt = new DataTable();
            sprSameDayRegList.Clear();
            if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectSameDayRegList(), ref dt, pid
                                                                                   , mdcrdd))
            {
                m_RegCount = dt.Rows.Count;
                if (m_RegCount > 1)
                {
                    sprSameDayRegList.FillDataTag(dt);
                }
                SetSpreadColor();
            }
        }
        /// <summary>
        /// 타과접수내역을 보여준다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="mdcrdd"></param>
        /// <param name="mdcrdeptcd"></param>
        public void SelectData(string pid, string mdcrdd, string mdcrdeptcd)
        {
            DataTable dt = new DataTable();
            sprSameDayRegList.Clear();
            if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectOtherDeptRegList(), ref dt, pid
                                                                                      , mdcrdd
                                                                                      , mdcrdeptcd))
            {
                m_RegCount = dt.Rows.Count;
                if (m_RegCount >= 1)
                {
                    sprSameDayRegList.FillDataTag(dt);
                }
                SetSpreadColor();
            }
        }
        #endregion Method : Select Method

        #endregion Method : Public Method

        #region Method : Private Method
        private void SetSpreadColor()
        {

            int ordnotm = 0;
            int recnotm = 0;
            int rcptnotm = 0;

            for (int i = 0; i < sprSameDayRegList.ActiveSheet.RowCount; i++)
            {
                int.TryParse(sprSameDayRegList.GetValue(i, "ORD_NOTM").ToString(), out ordnotm);
                int.TryParse(sprSameDayRegList.GetValue(i, "REC_NOTM").ToString(), out recnotm);
                int.TryParse(sprSameDayRegList.GetValue(i, "RCPT_NOTM").ToString(), out rcptnotm);

                if (ordnotm > recnotm)
                {
                    sprSameDayRegList.SetText(i, "WAIT_STAT", "수납대기");
                    sprSameDayRegList.Sheets[0].Cells[i, 0, i, sprSameDayRegList.Sheets[0].ColumnCount - 1].ForeColor = Color.Red;
                }
                else if (ordnotm == recnotm && rcptnotm >= 1)
                {
                    sprSameDayRegList.SetText(i, "WAIT_STAT", "수납완료");
                    sprSameDayRegList.Sheets[0].Cells[i, 0, i, sprSameDayRegList.Sheets[0].ColumnCount - 1].ForeColor = Color.Blue;
                }
                else
                {
                    sprSameDayRegList.SetText(i, "WAIT_STAT", "미진료");
                }


            }
        }
        #endregion
        #region Event : Event Process

        private void sprSameDayRegList_CellDoubleClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader) return;
            if (e.RowHeader) return;

            if (e.Row >= 0)
            {
                OnPatientSelected(sprSameDayRegList.GetText(e.Row, "PID"), int.Parse(sprSameDayRegList.GetText(e.Row, "PT_CMHS_NO")));
            }

        }

        private void sprSameDayRegList_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                int currow = sprSameDayRegList.ActiveSheet.ActiveRowIndex;

                if (currow < 0) return;

                OnPatientSelected(sprSameDayRegList.GetText(currow, "PID"), int.Parse(sprSameDayRegList.GetText(currow, "PT_CMHS_NO")));
            }
        }

        void sprSameDayRegList_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader || e.RowHeader)
                return;

            ((LxSpread)sender).MultiCellSelectRowBackColor(e.Row);
        }

        #endregion

        #region Event : Raise Event

        public void OnPatientSelected(string pid, int ptcmhsno)
        {
            SelectDataEventArgs args = new SelectDataEventArgs(pid, ptcmhsno);
            if (this.PatientSelected != null)
            {
                this.PatientSelected(this, args);
            }
        }
        #endregion Event : Raise Event

        #region Event : EventArgs
        public class SelectDataEventArgs : EventArgs
        {
            private string m_Pid = String.Empty;
            private int m_PtCmhsNo = 0;


            public string Pid
            {
                get { return m_Pid; }
                set { m_Pid = value; }
            }
            public int PtCmhsNo
            {
                get { return m_PtCmhsNo; }
                set { m_PtCmhsNo = value; }
            }

            public SelectDataEventArgs(string pid, int ptcmhsno)
            {
                this.m_Pid = pid;
                this.m_PtCmhsNo = ptcmhsno;
            }
        }
        #endregion Event : EventArgs

    }
}
