package web.townsi.com.work.setting.biz;

import java.util.HashMap;

public interface SettingQueryBiz {
	public abstract HashMap<String, Object> makeQuery(HashMap paramHashMap) throws Exception;
	public abstract HashMap<String, Object> makeMutation(HashMap paramHashMap) throws Exception;
	public abstract HashMap<String, Object> makeService(HashMap paramHashMap) throws Exception;
}