//********************************************************************************
// Class 명 : ucPatientInfoModE
// 역    할 : 환자기본정보관리 UserControl
// 작 성 자 : 유준선
// 작 성 일 : 2017-10-02
//********************************************************************************
// 수정내역 :  
//********************************************************************************
using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.BusinessControls
{
    [ToolboxItem(true)]
    public partial class ucPatientInfoModE : BaseUCF
    {
        #region [ Define : Member ]
        private bool m_isRevision = false; //수정중이던 정보였는지 여부를 나타내는 Flag. 
        public string m_partFlag = ""; //원무, 간호, 기타 중 어느 화면에서 이 화면을 Call하는지 구분한다.
        public string m_pid = ""; //외부로부터 받는 변수, pid가 null이 아니면 창을 띄우면서 자동검색한다.
        #endregion [ Define : Member ]

        #region [ Construction ]
        public ucPatientInfoModE()
        {
            InitializeComponent();
        }
        #endregion [ Construction ]

        #region [ Screen Load ]
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (!this.DesignMode)
                this.Initialize();
        }
        #endregion [ Screen Load ]

        #region [ Method : Initialize Method ]
        private void Initialize()
        {
            this.InitializeControl();
            this.InitializeButtonList();
            this.InitializeEvent();
        }

        private void InitializeControl()
        {
            //TO DO
            //사망장소 콤보박스에 Binding 해야 함.

            this.ActiveControl = txtPID;
            txtPID.Focus();

            SetReadOnly();

            if (!m_pid.Equals(""))
            {
                txtPID.Text = m_pid;
                if (!ViewPtInfo())
                    return;
            }
        }

        private void InitializeButtonList()
        {
            this.lxButtonList1.ButtonItems.Clear();
            this.lxButtonList1.ButtonItems.Add(ButtonType.Save, "수 정");
            this.lxButtonList1.ButtonItems.Add(ButtonType.Close, "종 료");
            this.lxButtonList1.InitializeButtons();
        }

        private void InitializeEvent()
        {
            this.lxButtonList1.ButtonClick += this.OnLxButtonList_ButtonClick;
            txtPID.EditorButtonClick += txt_EditorButtonClick;
            txtAddrCd.EditorButtonClick += txt_EditorButtonClick;
            txtNatnCdnm.EditorButtonClick += txt_EditorButtonClick;
            txtItdtEmnm.EditorButtonClick += txt_EditorButtonClick;
            txtFrrn.KeyPress += toNumber_KeyPress;
            txtSrrn_SrrnEcpt.KeyPress += toNumber_KeyPress;
            txtPID.KeyDown += txt_KeyDown;
            txtAddrCd.KeyDown += txt_KeyDown;
            txtNatnCdnm.KeyDown += txt_KeyDown;
            txtItdtEmnm.KeyDown += txt_KeyDown;
            mskDethDd.KeyPress += toNumber_KeyPress;
            txtSrrn_SrrnEcpt.Leave += txt_Leave;
        }
        #endregion [ Method : Initialize Method ]

        #region [ Method : Private Method ]
        /// <summary>
        /// 소개직원번호 팝업
        /// </summary>
        private void ViewUserCd()
        {
            popSearchUser pop = new popSearchUser();

            if (pop.ShowDialog() == DialogResult.OK)
            {
                txtItdtEmno.Text = pop.USER_CD;
                txtItdtEmnm.Text = pop.USER_NM;
            }
            pop.Dispose();
        }

        private void CloseScreen()
        {
            if (m_isRevision)
            {
                DialogResult dr = LxMessage.Show("변경중이던 내역이 있습니다.\r\n계속 진행하시겠습니까?", "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dr != DialogResult.Yes)
                    return;
                else
                    this.ParentForm.Close();
            }
            else
                this.ParentForm.Close();
        }

        private bool Validation()
        {
            try
            {
                #region [ 환자번호 Null 체크, 주민등록번호 유효성 체크 ]
                if (string.IsNullOrEmpty(txtPID.Text))
                {
                    txtPID.Focus();
                    LxMessage.Show("환자번호가 입력되지 않았습니다.\r\n환자번호를 확인해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;
                }

                if (!CheckAndSetByRegNum())
                    return false;
                #endregion [ 환자번호 Null 체크, 주민등록번호 유효성 체크 ]

                #region [ 한글 입력 가능 부분의 MaxLength 체크 ]
                if (StringService.ByteCount(txtHousTel.Text) > 15)
                {
                    txtHousTel.Focus();
                    LxMessage.Show("전화번호 글자수는 15Byte 이상일 수 없습니다.\r\n전화번호를 확인해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;
                }

                if (StringService.ByteCount(txtClphTel.Text) > 15)
                {
                    txtClphTel.Focus();
                    LxMessage.Show("휴대전화번호는 글자수는 15Byte 이상일 수 없습니다.\r\n휴대전화번호를 확인해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;
                }

                if (StringService.ByteCount(txtEtcTel1.Text) > 15)
                {
                    txtEtcTel1.Focus();
                    LxMessage.Show("기타전화번호는 글자수는 15Byte 이상일 수 없습니다.\r\n기타전화번호를 확인해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;
                }

                if (StringService.ByteCount(txtDetlAddr.Text) > 200)
                {
                    txtDetlAddr.Focus();
                    LxMessage.Show("상세주소는 글자수는 200Byte 이상일 수 없습니다.\r\n상세주소를 확인해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;
                }

                if (StringService.ByteCount(txtFrnrNm.Text) > 50)
                {
                    txtFrnrNm.Focus();
                    LxMessage.Show("외국인성명 글자수는 50Byte 이상일 수 없습니다.\r\n외국인성명을 확인해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;
                }

                if (StringService.ByteCount(txtEmalAddr.Text) > 50)
                {
                    txtEmalAddr.Focus();
                    LxMessage.Show("이메일주소 글자수는 50Byte 이상일 수 없습니다.\r\n이메일주소를 확인해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;
                }

                if (StringService.ByteCount(txtPtPclrMatr.Text) > 3000)
                {
                    txtPtPclrMatr.Focus();
                    LxMessage.Show("특이사항 글자수는 3000Byte 이상일 수 없습니다.\r\n특이사항을 확인해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;
                }
                #endregion [ 한글 입력 가능 부분의 MaxLength 체크 ]

                #region 도로명주소로 반드시 입력하는지 체크

                if (string.IsNullOrEmpty(txtAddrBldgNo.Text))
                {
                    if (string.IsNullOrEmpty(txtDongAddr.Text))
                    {
                        LxMessage.Show("주소가 누락되었습니다.\r\n주소를 입력하세요.", "주소확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return false;
                    }
                    else
                    {
                        LxMessage.Show("지역별 통계를 위하여 지번주소는\r\n반드시 도로명주소로 변경해야 합니다.", "재입력", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return false;
                    }
                }

                #endregion

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
        }

        private void SaveData()
        {
            try
            {
                if (!Validation())
                    return;

                if (DBService.ExecuteNonQuery(SQL.PA.Sql.RevisionPAPATHIN(), txtPtNm.Text
                                                                          , txtFrrn.Text.Trim()
                                                                          , txtSrrn_SrrnEcpt.Text.Substring(0, 1) + "******"
                                                                          , EncryptionService.Encoding(txtSrrn_SrrnEcpt.Text.Trim())
                                                                          , txtDobr.Text
                                                                          , txtSex.Text
                                                                          , txtAddrCd.Text
                                                                          , txtDetlAddr.Text
                                                                          , txtHousTel.Text.Trim()
                                                                          , txtAddrBldgNo.Text
                                                                          , txtClphTel.Text.Trim()
                                                                          , txtEtcTel1.Text.Trim()
                                                                          , txtEmalAddr.Text.Trim()
                                                                          , txtNatnCd.Text
                                                                          , cboIndvInfoCnsnYn.Value == null ? "" : cboIndvInfoCnsnYn.Value.ToString()
                                                                          , chkSmsCnsnYn.Checked ? "Y" : "N"
                                                                          , txtItdtEmno.Text
                                                                          , txtPtPclrMatr.Text
                                                                          , chkDelYn.Checked ? "D" : "A"
                                                                          , mskDethDd.Text.Replace("-", "")
                                                                          , cboDethPlceDvcd.Value == null ? "" : cboDethPlceDvcd.Value.ToString()
                                                                          , txtFrnrNm.Text.Trim()
                                                                          , DateTime.Now.ToString("yyyyMMddHHmmss")
                                                                          , DOPack.UserInfo.USER_CD
                                                                          , m_pid))
                {
                    ViewPtInfo();
                    LxMessage.Show("수정되었습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information, 3);
                }
                else
                {
                    LxMessage.Show("환자정보 수정 중 오류가 발생했습니다", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

        }

        private void Clear()
        {
            try
            {
                #region [ 모든 컨트롤을 초기화한다. ]
                foreach (Control ctl in ttpPtInfo.Controls)
                {
                    if (ctl is LxTextBox)
                        ctl.Text = string.Empty;
                    else if (ctl is LxComboBox)
                        ctl.Text = string.Empty;
                    else if (ctl is LxMaskedEdit)
                        ctl.Text = DateTime.Now.ToString("yyyyMMdd");
                    else if (ctl is LxCheckBox)
                    {
                        LxCheckBox chk = (LxCheckBox)ctl;
                        chk.Checked = false;
                    }
                }
                #endregion [ 모든 컨트롤을 초기화한다. ]
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
        }

        /// <summary>
        /// 팝업을 Call하는 화면에서 보낸 Flag에 따라, Readonly를 설정한다.
        /// </summary>
        private void SetReadOnly()
        {
            #region [ 팝업을 Call하는 화면에서 보낸 Flag에 따라, Readonly를 설정한다. ]
            if (m_partFlag.Equals("P"))//원무
            {
                //txtPtNm.ReadOnly = false;
                txtFrrn.ReadOnly = false;
                txtSrrn_SrrnEcpt.ReadOnly = false;
                txtHousTel.ReadOnly = false;
                txtClphTel.ReadOnly = false;
                txtEtcTel1.ReadOnly = false;
                cboIndvInfoCnsnYn.ReadOnly = false;
                chkSmsCnsnYn.Enabled = true;
                //주소코드는 KeyDown Enter나 EditButton에서 설정
                txtDetlAddr.ReadOnly = false;
                //국가코드는 KeyDown Enter나 EditButton에서 설정
                txtFrnrNm.ReadOnly = false;
                txtEmalAddr.ReadOnly = false;
                //소개직원번호는 KeyDown Enter나 EditButton에서 설정
                mskDethDd.ReadOnly = false;
                cboDethPlceDvcd.ReadOnly = false;
                chkDelYn.Enabled = true;
                txtPtPclrMatr.ReadOnly = false;

            }
            else if (m_partFlag.Equals("N"))//간호
            {
                //txtPtNm.ReadOnly = true;
                txtFrrn.ReadOnly = true;
                txtSrrn_SrrnEcpt.ReadOnly = true;
                txtHousTel.ReadOnly = false;
                txtClphTel.ReadOnly = false;
                txtEtcTel1.ReadOnly = false;
                cboIndvInfoCnsnYn.ReadOnly = true;
                chkSmsCnsnYn.Enabled = false;
                //주소코드는 KeyDown Enter나 EditButton에서 설정
                txtDetlAddr.ReadOnly = false;
                //국가코드는 KeyDown Enter나 EditButton에서 설정
                txtFrnrNm.ReadOnly = true;
                txtEmalAddr.ReadOnly = true;
                //소개직원번호는 KeyDown Enter나 EditButton에서 설정
                mskDethDd.ReadOnly = true;
                cboDethPlceDvcd.ReadOnly = true;
                chkDelYn.Enabled = false;
                txtPtPclrMatr.ReadOnly = false;
            }
            else //기타
            {
                txtPtNm.ReadOnly = true;
                txtFrrn.ReadOnly = true;
                txtSrrn_SrrnEcpt.ReadOnly = true;
                txtHousTel.ReadOnly = true;
                txtClphTel.ReadOnly = true;
                txtEtcTel1.ReadOnly = true;
                cboIndvInfoCnsnYn.ReadOnly = true;
                chkSmsCnsnYn.Enabled = false;
                //주소코드는 KeyDown Enter나 EditButton에서 설정
                txtDetlAddr.ReadOnly = true;
                //국가코드는 KeyDown Enter나 EditButton에서 설정
                txtFrnrNm.ReadOnly = true;
                txtEmalAddr.ReadOnly = true;
                //소개직원번호는 KeyDown Enter나 EditButton에서 설정
                mskDethDd.ReadOnly = true;
                cboDethPlceDvcd.ReadOnly = true;
                chkDelYn.Enabled = false;
                txtPtPclrMatr.ReadOnly = true;
            }
            #endregion [ 팝업을 Call하는 화면에서 보낸 Flag에 따라, Readonly를 설정한다. ]
        }

        /// <summary>
        /// PID에 해당하는 환자정보 세팅.
        /// </summary>
        /// <param name="PtNo"></param>
        private void InuptPatientInfo(string PtNo)
        {
            try
            {
                #region [ 국가코드 명칭, 소개직원번호 명칭, SMS동의 CheckBox, 삭제여부 CheckBox , ROWID 세팅 ]
                DataTable dt = new DataTable();
                if (DBService.ExecuteDataTable(SQL.PA.Sql.GetPapathin(), ref dt, PtNo))
                {
                    if (dt.Rows.Count > 0)
                    {
                        txtNatnCdnm.Text = dt.Rows[0]["NATN_CDNM"].ToString();
                        txtItdtEmnm.Text = dt.Rows[0]["ITDT_EMNM"].ToString();

                        if (dt.Rows[0]["SMS_CNSN_YN"].ToString().Equals("Y"))
                            chkSmsCnsnYn.Checked = true;
                        else
                            chkSmsCnsnYn.Checked = false;

                        if (dt.Rows[0]["DEL_YN"].ToString().Equals("Y"))
                            chkDelYn.Checked = true;
                        else
                            chkDelYn.Checked = false;
                    }
                    else
                    {
                        txtNatnCdnm.Text = string.Empty;
                        txtItdtEmnm.Text = string.Empty;
                        chkSmsCnsnYn.Checked = false;
                        chkDelYn.Checked = false;
                    }
                }
                #endregion [ 국가코드 명칭, 소개직원번호 명칭, SMS동의 CheckBox, 삭제여부 CheckBox 세팅 ]

                m_pid = PtNo;

                DOPack.PatientInfo.Clear();
                DOPack.PatientInfo.Load(PtNo);
                txtPID.Text = m_pid;
                txtPtNm.Text = DOPack.PatientInfo.PT_NM;
                txtFrrn.Text = DOPack.PatientInfo.FRRN;

                if (m_partFlag.Equals("P") || m_partFlag.Equals("N"))
                    txtSrrn_SrrnEcpt.Text = DOPack.PatientInfo.SRRN_ECPT;
                else
                    txtSrrn_SrrnEcpt.Text = DOPack.PatientInfo.SRRN;

                txtDobr.Text = DOPack.PatientInfo.DOBR;
                txtSex.Text = DOPack.PatientInfo.SEX_DVCD;
                txtAge.Text = DOPack.PatientInfo.AGE.ToString();
                txtHousTel.Text = DOPack.PatientInfo.HOUS_TEL;
                txtClphTel.Text = DOPack.PatientInfo.CLPH_TEL;
                txtEtcTel1.Text = DOPack.PatientInfo.ETC_TEL_1;
                cboIndvInfoCnsnYn.Value = DOPack.PatientInfo.INDV_INFO_CNSN_YN == null ? "" : DOPack.PatientInfo.INDV_INFO_CNSN_YN;
                txtAddrCd.Text = DOPack.PatientInfo.ADDR_CD;
                txtDongAddr.Text = DOPack.PatientInfo.ADDRESS_DONG;
                txtDetlAddr.Text = DOPack.PatientInfo.DETL_ADDR;
                txtAddrBldgNo.Text = DOPack.PatientInfo.ADDR_BLDG_NO;
                txtNatnCd.Text = DOPack.PatientInfo.NATN_CD; //숨겨놓은 컨트롤
                txtFrnrNm.Text = DOPack.PatientInfo.FRNR_NM;
                txtEmalAddr.Text = DOPack.PatientInfo.EMAL_ADDR;
                txtItdtEmno.Text = DOPack.PatientInfo.ITDT_EMNO; //숨겨놓은 컨트롤
                mskDethDd.Text = DOPack.PatientInfo.DETH_DD;
                cboDethPlceDvcd.Value = DOPack.PatientInfo.DETH_PLCE_DVCD == null ? "" : DOPack.PatientInfo.DETH_PLCE_DVCD;
                txtPtPclrMatr.Text = DOPack.PatientInfo.PT_PCLR_MATR;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
        }

        /// <summary>
        /// 환자검색
        /// </summary>
        /// <returns></returns>
        private bool ViewPtInfo()
        {
            try
            {
                txtPID.Text = txtPID.Text.Trim();
                string PtNo = txtPID.Text;

                //입력 값이 숫자일 경우
                if (int.TryParse(PtNo, out int numChk))
                {
                    //신환번호 생성규칙
                    string PidRule = ConfigService.GetConfigValueString("BI", "NEWPID", "RULE");
                    //환자 등록번호 최대자릿수
                    int PidLength = int.Parse(ConfigService.GetConfigValueString("BI", "NEWPID", "SIZE"));
                    //순번으로 환자번호 생성 시,
                    if (PidRule.Equals("1"))
                    {
                        txtPID.Text = txtPID.Text.PadLeft(PidLength, '0');
                        InuptPatientInfo(txtPID.Text);

                        if (string.IsNullOrEmpty(txtPtNm.Text))
                        {
                            LxMessage.Show("이름에 해당하는 환자 정보가 존재하지 않습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            return false;
                        }
                        else
                            return true;
                    }
                    //년도 + 순번으로 환자번호 생성 시,
                    else if (PidRule.Equals("2"))
                    {
                        //TO DO 추후코딩
                        return true; ;
                    }
                }
                else//입력 값이 문자일 경우
                {
                    DataTable dt = new DataTable();
                    if (DBService.ExecuteDataTable(SQL.PA.Sql.GetPAPATHIN(), ref dt, txtPID.Text.Trim()))
                    {
                        if (dt.Rows.Count == 0)
                        {
                            LxMessage.Show("이름에 해당하는 환자 정보가 존재하지 않습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            return false;
                        }
                        else if (dt.Rows.Count == 1)
                        {
                            txtPID.Text = dt.Rows[0]["PID"].ToString();
                            InuptPatientInfo(txtPID.Text);

                            return true;
                        }
                        else
                        {
                            popSearchPatient pop = new popSearchPatient("PT_NM", txtPID.Text.Trim());
                            pop.StartPosition = FormStartPosition.CenterScreen;
                            if (pop.ShowDialog() == DialogResult.OK)
                            {
                                if (pop.Pid != "")
                                {
                                    InuptPatientInfo(pop.Pid);
                                    pop.Dispose();
                                    return true;
                                }
                                else
                                {
                                    pop.Dispose();
                                    return false;
                                }
                            }
                            pop.Dispose();
                        }
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
        }

        /// <summary>
        /// 주민등록번호 유효성체크, 
        /// <para>주민등록번호에 의한 생년월일/성별/연령 세팅</para>
        /// </summary>
        private bool CheckAndSetByRegNum()
        {
            try
            {
                DataTable dt = new DataTable();
                string isValidRegNum = DBService.ExecuteScalar(SqlPack.Function.FN_PA_PRC_CHECKPATRRNO(), txtFrrn.Text.Trim(), txtSrrn_SrrnEcpt.Text.Trim()).ToString();
                if (!isValidRegNum.Equals("0"))
                {
                    //주민번호 뒷자리가 NULL이 아니고, 외국인이 아닐 때 주민번호 체크.
                    if (!string.IsNullOrWhiteSpace(txtSrrn_SrrnEcpt.Text.Trim()) && !"5678".Contains(txtSrrn_SrrnEcpt.Text.Substring(0, 1)))
                    {
                        txtFrrn.Focus();
                        LxMessage.Show("주민등록번호가 유효하지 않습니다.\r\n주민등록번호를 확인해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        return false;
                    }

                    //외국인이면 여기로 넘어와서 세팅.

                    #region [ 이 주민등록번호와 겹치는 환자정보가 존재하는지 확인 ]
                    dt.Clear();
                    dt.Columns.Clear();
                    if (DBService.ExecuteDataTable(SQL.PA.Sql.CheckRegNumDup(), ref dt, txtFrrn.Text.Trim()
                                                                              , EncryptionService.Encoding(txtSrrn_SrrnEcpt.Text.Trim())
                                                                              , m_pid))
                    {
                        if (dt.Rows.Count > 0)
                        {
                            string regNumDupList = "";
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                regNumDupList += dt.Rows[i][0].ToString() + "/" + dt.Rows[i][1].ToString() + "\r\n";
                            }

                            txtFrrn.Focus();
                            LxMessage.Show("해당 주민등록번호로 등록된 환자가\r\n이미 존재합니다.\r\n환자목록:\r\n" + regNumDupList, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            return false;
                        }
                    }
                    else
                    {
                        LxMessage.Show("주민등록번호 중복 체크 중 에러가 발생했습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        return false;
                    }
                    #endregion [ 이 주민등록번호와 겹치는 환자정보가 존재하는지 확인 ]

                    #region [ 주민등록번호에 따른 생년월일, 성별, 연령 세팅 ]
                    //생년월일
                    txtDobr.Text = DBService.ExecuteScalar(SqlPack.Function.FN_PA_PRC_DATEOFBIRTH(), txtFrrn.Text.Trim(), txtSrrn_SrrnEcpt.Text.Trim()).ToString();
                    //성별
                    txtSex.Text = DBService.ExecuteScalar(SqlPack.Function.FN_PA_READ_SEXDVCD(), txtSrrn_SrrnEcpt.Text.Trim()).ToString();
                    //연령
                    txtAge.Text = DBService.ExecuteScalar(SqlPack.Function.FN_PA_READ_AGE(), txtFrrn.Text.Trim(), txtSrrn_SrrnEcpt.Text.Trim()).ToString();
                    #endregion [ 주민등록번호에 따른 생년월일, 성별, 연령 세팅 ]
                }
                else //유효한 주민등록번호 일 때, 
                {
                    #region [ 이 주민등록번호와 겹치는 환자정보가 존재하는지 확인 ]
                    dt.Clear();
                    dt.Columns.Clear();
                    if (DBService.ExecuteDataTable(SQL.PA.Sql.CheckRegNumDup(), ref dt, txtFrrn.Text.Trim()
                                                                              , EncryptionService.Encoding(txtSrrn_SrrnEcpt.Text.Trim())
                                                                              , m_pid))
                    {
                        if (dt.Rows.Count > 0)
                        {
                            string regNumDupList = "";
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                regNumDupList += dt.Rows[i][0].ToString() + "/" + dt.Rows[i][1].ToString() + "\r\n";
                            }

                            txtFrrn.Focus();
                            LxMessage.Show("해당 주민등록번호로 등록된 환자가\r\n이미 존재합니다.\r\n환자목록:\r\n" + regNumDupList, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            return false;
                        }
                    }
                    else
                    {
                        LxMessage.Show("주민등록번호 중복 체크 중 에러가 발생했습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        return false;
                    }
                    #endregion [ 이 주민등록번호와 겹치는 환자정보가 존재하는지 확인 ]

                    #region [ 주민등록번호에 따른 생년월일, 성별, 연령 세팅 ]
                    //생년월일
                    txtDobr.Text = DBService.ExecuteScalar(SqlPack.Function.FN_PA_PRC_DATEOFBIRTH(), txtFrrn.Text.Trim(), txtSrrn_SrrnEcpt.Text.Trim()).ToString();
                    //성별
                    txtSex.Text = DBService.ExecuteScalar(SqlPack.Function.FN_PA_READ_SEXDVCD(), txtSrrn_SrrnEcpt.Text.Trim()).ToString();
                    //연령
                    txtAge.Text = DBService.ExecuteScalar(SqlPack.Function.FN_PA_READ_AGE(), txtFrrn.Text.Trim(), txtSrrn_SrrnEcpt.Text.Trim()).ToString();
                    #endregion [ 주민등록번호에 따른 생년월일, 성별, 연령 세팅 ]
                }

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;
            }
        }

        /// <summary>
        /// 주소 조회 팝업
        /// </summary>
        private void ViewAddrCode()
        {
            popSearchAddress pop = new popSearchAddress();

            if (pop.ShowDialog() == DialogResult.OK)
            {
                txtAddrBldgNo.Text = pop.BLDG_MNGM_NO;
                txtDongAddr.Text = pop.ROAD_NM_ADDR;
                txtAddrCd.Text = pop.FNDT_DSTT_NO;

                txtDongAddr.Focus();
            }
            pop.Dispose();
        }

        /// <summary>
        /// 국가코드 조회 팝업
        /// </summary>
        private void ViewNatnCd()
        {
            popOverallCode pop = new popOverallCode("NATN_cD");

            if (DialogResult.OK == pop.ShowDialog(this))
            {
                txtNatnCd.Text = pop.SelectedCode;
                txtNatnCdnm.Text = pop.SelectedName;
            }
            pop.Dispose();
        }
        #endregion [ Method : Private Method ]

        #region [ Event : Event Process ]

        private void OnLxButtonList_ButtonClick(object sender, ButtonClickEventArgs e)
        {
            try
            {
                switch (e.ButtonType)
                {
                    case ButtonType.Save:
                        //원무, 간호에서 열었을 때 수정버튼 동작
                        if (m_partFlag.Equals("P") || m_partFlag.Equals("N"))
                            SaveData();
                        break;
                    case ButtonType.Close:
                        CloseScreen();
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
        }

        //숫자, 벡스페이스만 사용
        private void toNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar)) && e.KeyChar != 8) //8:백스페이스
            {
                e.Handled = true;
            }
        }

        private void txt_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    #region [ 환자번호에서 작동 ]
                    if (sender == txtPID)
                    {
                        if (!ViewPtInfo())
                            return;
                    }
                    #endregion [ 환자번호에서 작동 ]

                    #region [ 주소크드에서 작동 ]
                    if (sender == txtAddrCd)
                    {
                        //원무 or 간호 화면에서 열었을 때에만 동작.
                        if (m_partFlag.Equals("P") || m_partFlag.Equals("N"))
                        {
                            ViewAddrCode();
                        }
                    }
                    #endregion [ 주소크드에서 작동 ]

                    #region [ 국가코드에서 작동 ]
                    if (sender == txtNatnCdnm)
                    {
                        //원무 화면에서 열었을 때에만 동작.
                        if (m_partFlag.Equals("P"))
                        {
                            ViewNatnCd();
                        }
                    }
                    #endregion [ 국가코드에서 작동 ]

                    #region [ 소개직원번호에서 작동 ]
                    if (sender == txtItdtEmnm)
                    {
                        //원무 화면에서 열었을 때에만 동작.
                        if (m_partFlag.Equals("P"))
                        {
                            ViewUserCd();
                        }
                    }
                    #endregion [ 소개직원번호에서 작동 ]
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
        }

        private void txt_EditorButtonClick(object sender, Infragistics.Win.UltraWinEditors.EditorButtonEventArgs e)
        {
            try
            {
                #region [ 환자번호에서 작동 ]
                if (sender == txtPID)
                {
                    if (!ViewPtInfo())
                        return;
                }
                #endregion [ 환자번호에서 작동 ]

                #region [ 주소코드에서 작동 ]
                if (sender == txtAddrCd)
                {
                    //원무 or 간호 화면에서 열었을 때에만 동작.
                    if (m_partFlag.Equals("P") || m_partFlag.Equals("N"))
                    {
                        ViewAddrCode();
                    }
                }
                #endregion [ 주소코드에서 작동 ]

                #region [ 국가코드에서 작동 ]
                if (sender == txtNatnCdnm)
                {
                    //원무 화면에서 열었을 때에만 동작.
                    if (m_partFlag.Equals("P"))
                    {
                        ViewNatnCd();
                    }
                }
                #endregion [ 국가코드에서 작동 ]

                #region [ 소개직원번호에서 작동 ]
                if (sender == txtItdtEmnm)
                {
                    //원무 화면에서 열었을 때에만 동작.
                    if (m_partFlag.Equals("P"))
                    {
                        ViewUserCd();
                    }
                }
                #endregion [ 소개직원번호에서 작동 ]
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
        }

        private void txt_Leave(object sender, EventArgs e)
        {
            try
            {
                #region [ 주민등록번호 뒷자리를 떠날 때, ]
                if (sender == txtSrrn_SrrnEcpt)
                {
                    if (m_partFlag.Equals("P"))
                    {
                        if (!CheckAndSetByRegNum())
                            return;
                    }
                }
                #endregion [ 주민등록번호 뒷자리를 떠날 때, ]

                #region [ 사망일자 유효성 체크 ]
                if (sender == mskDethDd)
                {
                    if (!DateTimeService.IsDateTime(mskDethDd.Text))
                    {
                        mskDethDd.Focus();
                        LxMessage.Show("유효한 일자 형식이 아닙니다.\r\n사망일자를 확인해주세요.");
                        return;
                    }
                }
                #endregion [ 사망일자 유효성 체크 ]
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("[ 에러발생 ]\r\n" + ex.ToString(), "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
        }

        #endregion [ Event : Event Process ]
    }
}
