//********************************************************************
// Class 명 : ucOlocInf
// 역    할 : 방문할 곳을 보여주는 User Control
// 작 성 자 : PGH
// 작 성 일 : 2017-09-22
//********************************************************************
using System;
using System.Data;
using System.Windows.Forms;

namespace Lime.PA
{
    public partial class ucOlocInf : UserControl
    {
        public ucOlocInf()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            sprVisitPlace.ActiveSheet.ColumnHeader.Rows[0].Height = 23;
            sprVisitPlace.AutoFitColumnSize = false;
            sprVisitPlace.AutoFirstAppendRow = false;
            sprVisitPlace.AutoLastAppendRow = false;
            sprVisitPlace.ActiveSheet.ColumnHeader.Columns[0].Width = 220;
        }

        public void Clear()
        {
            sprVisitPlace.Clear();
        }

        public void DisplayVisitPlace(DataTable dt)
        {
            Clear();

            if (dt.Rows.Count > 0)
            {
                sprVisitPlace.FillDataTag(dt);
            }
        }
    }

}
