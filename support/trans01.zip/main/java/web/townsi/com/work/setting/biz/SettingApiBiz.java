package web.townsi.com.work.setting.biz;

import java.util.HashMap;
import java.util.List;

public interface SettingApiBiz {
	public abstract HashMap<String, Object> makeApi(HashMap paramHashMap) throws Exception;
}