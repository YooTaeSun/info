//********************************************************************
// Class 명 : ucfOutReceiptE
// 역    할 : 외래수납 Main 
// 작 성 자 : PGH
// 작 성 일 : 2017-09-19
//********************************************************************
using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Lime.BusinessControls;
using Lime.Framework;
using Lime.Framework.BusinessService;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public partial class ucfOutReceiptE : BaseUCF_TP, IMessageFilter
    {
        #region Define : Member
        clsOutBillBreakdown m_OutBillBd = new clsOutBillBreakdown();
        clsOutProfitBreakDown m_OutProfitBd = new clsOutProfitBreakDown();
        clsOutProfitTemp m_OutProfitTp = new clsOutProfitTemp();
        clsOutReceiptBreakDown m_OutReceiptBd = new clsOutReceiptBreakDown();
        private bool m_VisibleWating = false; // 대기창 보이기
        private bool m_SaveYn = true;  // 수납비활성여부 

        private DataTable m_DtProfit = new DataTable();
        private DataTable m_DtProfitSum = new DataTable();
        private int m_STATVAL1 = 0;

        private Lime.BusinessControls.clsPAReceiptInfo m_ReceiptPrint = new Lime.BusinessControls.clsPAReceiptInfo();

        private Lime.BusinessControls.PrescriptionType m_PrintType = Lime.BusinessControls.PrescriptionType.None;
        //SEO-자격조회private clsQualificationInfo m_QulificationInfo = new clsQualificationInfo();

        // 2018-04-26 권재호 외래대기자 수정
        private bool m_UseFilter = true;
        public const int WM_MOUSEMOVE = 0x0200;

        #endregion Define : Member

        #region Define : Member Property
        public clsOutReceiptBreakDown OutReceiptBd
        {
            get { return m_OutReceiptBd; }
            set { m_OutReceiptBd = value; }
        }

        public clsOutProfitBreakDown OutProfitBd
        {
            get { return m_OutProfitBd; }
            set { m_OutProfitBd = value; }
        }

        public clsOutProfitTemp OutProfitTp
        {
            get { return m_OutProfitTp; }
            set { m_OutProfitTp = value; }
        }

        public clsOutBillBreakdown OutBillBd
        {
            get { return m_OutBillBd; }
            set { m_OutBillBd = value; }
        }

        #endregion Define : Member Property

        #region Construction
        public ucfOutReceiptE()
        {
            InitializeComponent();
        }
        #endregion

        #region Screen Load

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode) 
                return;

            Initialize();
            InitializeEvent();
            InitializeButtonList();

            this.SetButtonColor();

            // 2018-04-26 권재호 외래대기자 수정
            tabWating.SelectedTab = null;
            tabWating.ActiveTab = null;
        }
        #endregion Screen Load

        #region Method : Initialize Method

        private void Initialize()
        {
            // 2018-04-26 권재호 외래대기자 수정
            Application.AddMessageFilter(this);

            dteMdcrDd.DateTime = DateTimeService.ConvertDateTime(DateTimeService.NowDateNoneSeperatorString());
            chkFrvsRvst.Checked = true;
            ucOrecRegInf11.m_FrvsRvstDvcd = "Y";
            ucOrecRegInf11.m_Mdcr_Dd = DateTimeService.NowDateNoneSeperatorString();
        }

        private void InitializeEvent()
        {
            if (DOPack.UserInfo.USER_CD != "LIME")
                btnNotCard.Visible = false;

            // 의료급여 미승인
            btnNonPermit.Click += btnNonPermit_Click;
            btnNeedRereciept.Click += BtnNeedRereciept_Click;

            this.Loaded += ucfOutReceiptE_Loaded;
            this.ScreenClosing += ucfOutReceiptE_ScreenClosing;

            ucOrecRegInf11.PatientSelected += ucOrecRegInf11_PatientSelected;
            ucSameDayRegList1.PatientSelected += ucSameDayRegList1_PatientSelected;
            ucOutRecWatingList1.PatientSelected += ucOutRecWatingList1_PatientSelected;
            ucOutReceiptBD1.PrscRetrieved += ucOutReceiptBD1_PrscRetrieved;
            dteMdcrDd.Leave += dteMdcrDd_Leave;
            dteMdcrDd.AfterCloseUp += dteMdcrDd_AfterCloseUp;
            //ucOutReceiptBD1.OnProfitSelect += ucOutReceiptBD1_OnProfitSelect;
            ucOrecRegInf11.OnPatientClear += ucOrecRegInf11_OnPatientClear;
            ucOutReceiptBD1.OnNotSave += ucOutReceiptBD1_OnNotSave;
            ucOutReceiptBD1.OnPatRegSelected += ucOutReceiptBD1_OnPatRegSelected;
            ucObillInf11.OnTotlMdcrAmt += ucObillInf11_OnTotlMdcrAmt;
            btnButtonList.ButtonClick += btnButtonList_ButtonClick;
            ucOrecRegInf11.OnCreditCheck += ucOrecRegInf11_OnCreditCheck;

            // 2018-04-26 권재호 외래대기자 수정
            tabWating.SelectedTabChanged += tabWating_SelectedTabChanged;
            ucOrecRegInf11.SystemLocked += ucOrecRegInf11_SystemLocked;

            btnSearchMefeUnpr.Click += btnSearchMefeUnpr_Click;
            this.ScreenClosed += ucfOutReceiptE_ScreenClosed;
            this.btnNotCard.Click += btnNotCard_Click;

            // 2020-10-13 정재원 원내처방전 재발행 추가
            btnPrintPrescription.Visible = ConfigService.GetConfigValueBool("PA", "IN_PRESCRIPTION", "IN_PRESCRIPTION");
            if (btnPrintPrescription.Visible)
                btnPrintPrescription.Click += (s, e) => PrintInHospPrescription();
        }

        void ucfOutReceiptE_ScreenClosed(object sender, EventArgs e)
        {
            this.ucOutRecWatingList1.SaveDeptIni();
        }

        private void btnSearchMefeUnpr_Click(object sender, EventArgs e)
        {
            try
            {
                if (ucOrecRegInf11.OutRegInfo != null && StringService.IsNotNull(ucOrecRegInf11.OutRegInfo.PID))
                {
                    using (popSearchMefeUnpr popup = new popSearchMefeUnpr(ucOrecRegInf11.OutRegInfo.SEX_DVCD, ucOrecRegInf11.OutRegInfo.AGE.ToString()))
                        popup.ShowDialog(this);
                }
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        private void ucOrecRegInf11_SystemLocked(bool locked)
        {
            this.btnButtonList.SetButtonEnable(ButtonType.Save, !locked); // "수 납(F2)"
            ucObillInf11.Enabled = !locked;

            this.btnButtonList.SetButtonEnable(ButtonType.Custom1, !locked); // "내역변경(F4)"
            this.btnButtonList.SetButtonEnable(ButtonType.Custom6, !locked); // "접수변경재계산(F12)"
            this.btnButtonList.SetButtonEnable(ButtonType.Custom5, !locked); // "처방변경(F11)"
            this.btnButtonList.SetButtonEnable(ButtonType.Custom18, !locked); // "미정산처리"

            this.ucObillInf11.SystemLocked = locked; // 카드(F9) / 현금(F6) / 통장(F7) / 승인취소
        }

        private void InitializeButtonList()
        {
            // 2018-07-24 SEO 순서 수정
            this.btnButtonList.ButtonItems.Clear();
            this.btnButtonList.ButtonItems.Add(ButtonType.Edit, "환자인적정보수정");
            this.btnButtonList.ButtonItems.Add(ButtonType.Clear, "초기화(F5)", "Clear");
            this.btnButtonList.ButtonItems.Add(ButtonType.Custom7, "대기자(F3)", "");
            this.btnButtonList.ButtonItems.Add(ButtonType.Save, "수 납(F2)", "Save");
            this.btnButtonList.ButtonItems.Add(ButtonType.Custom1, "내역변경(F4)", "");
            this.btnButtonList.ButtonItems.Add(ButtonType.Custom6, "접수변경재계산(F12)", "");
            this.btnButtonList.ButtonItems.Add(ButtonType.Custom5, "처방변경(F11)", "");
            this.btnButtonList.ButtonItems.Add(ButtonType.Custom8, "임시영수증발행", "");
            this.btnButtonList.ButtonItems.Add(ButtonType.Custom2, "영수증발행", "");
            this.btnButtonList.ButtonItems.Add(ButtonType.Custom3, "원외처방전", "");
            this.btnButtonList.ButtonItems.Add(ButtonType.Custom4, "자격조회(F8)", "");
            this.btnButtonList.ButtonItems.Add(ButtonType.Custom10, "EMR 열기", "");
            this.btnButtonList.ButtonItems.Add(ButtonType.Custom19, "특이사항", "");
            this.btnButtonList.ButtonItems.Add(ButtonType.Custom18, "미정산처리", "");
            this.btnButtonList.ButtonItems.Add(ButtonType.Process, "제증명추가", "");
            this.btnButtonList.ButtonItems.Add(ButtonType.Close, "닫 기", "Close");
            this.btnButtonList.InitializeButtons();

            this.btnButtonList.Dock = DockStyle.Right;
        }

        #endregion Method : Initialize Method

        #region Method : Private Method

        private void Clear(bool waitClear = true)
        {
            ucOutReceiptBD1.Clear();
            ucOrecRegInf11.Clear();
            ucObillInf11.Clear();
            ucOappInf1.Clear();
            ucOremInf1.Clear();
            ucOremInf2.Clear();
            ucOlocInf1.Clear();
            ucSameDayRegList1.Clear();
            ucOdisInf1.Clear();
            ucSpecialInf1.Clear();
            ucOrderHisV1.Clear();
            dteMdcrDd.DateTime = DateTime.Today;

            if (waitClear)
                ucOutRecWatingList1.Clear();

            m_SaveYn = true;
            // 수납버튼 비활성화
            EnableSaveReceipt(true);
            // 내역변경버튼 비활성화
            btnButtonList.SetButtonEnable(ButtonType.Custom1, true);
            // 처방변경
            btnButtonList.SetButtonEnable(ButtonType.Custom5, true);
            // 접수정보변경재계산
            btnButtonList.SetButtonEnable(ButtonType.Custom6, false);
        }

        /// <summary>
        /// 영수증 정보를 저장한다.
        /// </summary>
        private void SaveBillInfo()
        {
            this.ucObillInf11.LeaveFocus();

            if (!m_SaveYn)
            {
                LxMessage.Show("접수정보가 변경되었습니다. \r\n 접수정보변경재계산 작업을 수행하세요.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string clrs_resn_cnts = string.Empty; // 청구생성 됐을 경우에 정산사유
            string pacl_resn_dvcd = "RO"; // 외래청구간 사유 구분코드

            string msg = string.Empty;
            string rcptsaveyn = "Y";
            int rcptsqno = 0;                 // 수납일련번호
            int newrcptsqno = 0;   // 영수증 신규수납일련번호
            string billno = "0000000000";      // 영수증 번호

            string pid = ucOrecRegInf11.txtPid.Text.Trim();

            if (StringService.IsNull(pid))
            {
                LxMessage.Show("환자번호가 없습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (!ucOrecRegInf11.txtPid.Text.Trim().Equals(ucOrecRegInf11.OutRegInfo.PID))
            {
                string message = string.Format("수납하려는 환자가 {0}({1}) 입니까?\r\n(이 메시지는 화면 조회시의 환자번호와 환자정보에 표시된 환자번호가 다를 때 보여집니다.)", ucOrecRegInf11.txtPtNm.Text, ucOrecRegInf11.OutRegInfo.PID);

                if (!LxMessage.ShowQuestion(message).Equals(DialogResult.Yes))
                    return;
            }

            pid = ucOrecRegInf11.OutRegInfo.PID;
            string pt_cmhs_no = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString();
            string rcpn_sqno = ucOrecRegInf11.OutRegInfo.RCPN_SQNO.ToString();
            ucOrecRegInf11.txtPid.Text = pid;

            // OCS오픈일자를 확인한다.
            if (!clsPACommon.CheckOcsOpenDate(ucOrecRegInf11.OutRegInfo.MDCR_DD))
            {
                return;
            }

            // 환자의 행상태구분코드를 체크하여 수납진행여부를 파악한다.
            if (ucOrecRegInf11.CheckRowStatDvcdOfPatient(ref msg) > 1)
            {
                LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // 진료부서가 응급의학과이고, 응급실주진료부서가 선택되지 않은 경우, 수납 불가.
            if (ucOrecRegInf11.OutRegInfo.MDCR_DEPT_CD.Equals("2400") && ucOrecRegInf11.OutRegInfo.EMRM_MMCD_CD.Equals("2400"))
            {
                LxMessage.ShowInformation("진료과가 응급의학과인 경우, 응급실주과가 선택되어야 합니다.\r\n[환자정보]에서 [응급실주과]를 선택해 주세요.");
                return;
            }

            // 의료급여인 환자는 주상병을 체크하자. (저장완료인지 체크하자.)
            if (ucOrecRegInf11.OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("2") && !ucOrecRegInf11.OutRegInfo.ASST_TYCD.Equals("99") && !ucOrecRegInf11.OutRegInfo.PT_MDCR_STAT_DVCD.Equals("5"))
            {
                // 저장완료 되지 않았어도 주상병이 있으면 패스.
                string ilns_cd = DBService.ExecuteScalar($@"SELECT ILNS_CD 
                                                              FROM ORDISRRT 
                                                             WHERE PID        = '{pid}'  
                                                               AND PT_CMHS_NO = {pt_cmhs_no} 
                                                               AND ILNS_DVCD  = '1' 
                                                               AND DEL_YN     = 'A' 
                                                               AND ROWNUM     = 1 ").ToString();
                if (string.IsNullOrWhiteSpace(ilns_cd))
                {
                    if (!LxMessage.ShowQuestion("의료급여환자는 진료확인번호 승인을 위해,\r\n주상병이 반드시 입력되어야 합니다.\r\n진료과에서 아직 주상병을 입력하지 않았습니다.\r\n그래도 수납하시겠습니까?\r\n\r\n(그대로 진행할 경우 전산실에 연락하여\r\n재승인 바랍니다.)").Equals(DialogResult.Yes))
                        return;
                }
            }

            //옵션에 진료완료가 아니면 수납못하게 막을것인지 체크 'Y'인경우 수납안되게 한다.
            //if (SystemConfig.GetConfigValueString("RECEIPT", "PT_MDCR_STAT_DVCD", "N") == "Y")
            //{
            //    if (!ucOrecRegInf11.OutRegInfo.PT_MDCR_STAT_DVCD.Equals("5"))
            //    {
            //        LxMessage.ShowInformation("진료완료 상태가 아닌 환자는 수납하실 수 없습니다.");
            //        return;
            //    }
            //}                

            // 처방갯수확인
            if (ucOrecRegInf11.OutRegInfo.PRSC_COUNT != DBService.ExecuteInteger(SQL.PA.Sql.SelectPrscCountToCompare(), ucOrecRegInf11.OutRegInfo.PID
                                                                                                  , ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString()
                                                                                                  , ucOrecRegInf11.OutRegInfo.MDCR_DD))
            {
                LxMessage.Show("처방이 변경되었습니다. 수납처리후 재수납 처리해주시기 바랍니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                rcptsaveyn = "N";
            }
            // 영수증갯수확인
            if (ucOrecRegInf11.OutRegInfo.BILL_COUNT != DBService.ExecuteInteger(SQL.PA.Sql.SelectBillCountToCompare(), ucOrecRegInf11.OutRegInfo.PID
                                                                                                , ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString()))
            {
                LxMessage.Show("이미 수납처리한 영수증정보가 존재합니다. 진료비 계산을 다시 해주시기 바랍니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // 처방 변경이 있는 경우 수납 처리 불가'
            int prscrtn = ucOutReceiptBD1.CheckOrderChange(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO, ucOrecRegInf11.OutRegInfo.MDCR_DD, ref msg);

            if (prscrtn < 1)
            {
                if (LxMessage.Show(msg + "\r\n 이미 카드 또는 현금 승인 되었다면 수납처리 후 다시 수납처리를 하고 \r\n" +
                                   "  그렇지 않으면 처방을 다시 조회한 후 수납 처리하세요. \r\n OK : 수납처리후 재수납, Cancel : 수납취소",
                                     "확인", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.Cancel)
                    return;

                if (prscrtn == -21 || prscrtn == -22)
                    rcptsaveyn = "N";
            }

            if (ucOrecRegInf11.OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("2") && !ucOrecRegInf11.OutRegInfo.ASST_TYCD.Equals("99") && ucOrecRegInf11.m_NhicYn.Equals("NO"))
            {
                LxMessage.Show("의료급여환자는 건강생활유지비/산전지원비잔액 조회가 반드시 필요합니다. \r\n 반드시 잔액조회후 수납 처리가 가능합니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            //의료급여 2종 임신부 및 조산아 본인부담코드 확인
            if (ucOrecRegInf11.OutRegInfo.INSN_TYCD.Equals("22"))
            {
                if (ucOrecRegInf11.OutRegInfo.ASST_TYCD.Equals("J0") && !ucOrecRegInf11.OutRegInfo.USCH_APLY_CD.Equals("B010"))
                {
                    LxMessage.ShowInformation("의료급여 2종 임신부 입니다.\r\n본인코드를 B010 로 변경해주세요.");
                    return;
                }
                else if (ucOrecRegInf11.OutRegInfo.ASST_TYCD.Equals("K0") && !ucOrecRegInf11.OutRegInfo.USCH_APLY_CD.Equals("B011"))
                {
                    LxMessage.ShowInformation("의료급여 2종 조산아 및 저체중 출산아 입니다.\r\n본인코드를 B011 로 변경해주세요.");
                    return;
                }
            }

            //TODO : 약국 SCREEN

            //TODO : 금액표시기

            // 카드수납이 있는 경우 승인정보을 확인한다.
            if (ucObillInf11.CheckCardCashPermitAmt(ref msg) < 1)
            {
                LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ucObillInf11.PopUpCardCashPermit("P", "O", "A", ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), ucOrecRegInf11.OutRegInfo.MDCR_DD); //승인프로그램실행
                return;
            }

            // 카드 진행 금액에 금액이 있는 경우
            if (DBService.ExecuteScalar("SELECT CONF_VAL FROM ADCONFDT WHERE CONF_TYPE = 'TEST_SJH' AND CONF_CD = 'TEST_SJH_3'").ToString().Equals("Y"))
            {
                if (!ucObillInf11.txtCardRcptAmt.Text.Equals("0") && !string.IsNullOrWhiteSpace(ucObillInf11.txtCardRcptAmt.Text))
                {
                    int.TryParse(ucObillInf11.txtCardRcptAmt.Text, out int card_rcpt_amt);
                    if (!card_rcpt_amt.Equals(0))
                    {
                        LxMessage.ShowError($"카드 승인이 되지 않은 금액 [{ucObillInf11.txtCardRcptAmt.Text}]원이 있습니다.\r\n카드 금액을 확인해 주세요.");
                        return;
                    }
                }
            }

            //TODO : 업무LOCK 확인, 다른사용자가 사용하고 있으면 수납불가
            // 2020-11-27 SJH 굳이...?
            /*
            if (IsLockedSystem(pid, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString()))
            {
                //Lock 걸린상태
                SystemLockInfo lockinfo = new SystemLockInfo();
                lockinfo = this.SystemLockService.SelectSystemLock(pid, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString());
                if (!lockinfo.LOCK_USER_CD.Equals(DOPack.UserInfo.USER_CD))
                {
                    msg = "LOCK 시스템명 : [" + lockinfo.SYSTEM_CD + "] " + lockinfo.SYSTEM_NM + Environment.NewLine +
                         "LOCK 사용자명 : [" + lockinfo.LOCK_USER_CD + "]" + lockinfo.LOCK_USER_NM + Environment.NewLine +
                         "LOCK 부서명   : [" + lockinfo.LOCK_DEPT_CD + "]" + lockinfo.LOCK_DEPT_NM + Environment.NewLine +
                         "LOCK IP       : " + lockinfo.LOCK_IP + Environment.NewLine +
                         "LOCK 일시     : " + lockinfo.LOCK_DT;
                    LxMessage.Show(msg, "LOCK 확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // return;
                }
            }
            */
            //미수금액확인 미수코드, 미수사유 입력
            //환불금액확인 환불사유입력
            //할인감액금액확인 할인감액사유입력
            if (ucObillInf11.CheckReasonIsOrNot(ref msg) < 1)
            {
                LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 이전 수납고유번호를 가지고 있자.
            string prevRcptOcrrUniqNo = string.Empty;
            if (!clsPACommon.SelectPrevRcptOcrrUniqNo(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), "", "O", ref prevRcptOcrrUniqNo, ref msg))
            {
                LxMessage.ShowError(msg);
                return;
            }

            // 청구 생성 되었는지 확인한다.
            bool trms_cmpl_yn = false;
            if (!clsPACommon.CheckCLAM_CRTN_YN(pid, pt_cmhs_no, rcpn_sqno, true, true, ref msg, ref trms_cmpl_yn))
                return;

            if (LxMessage.Show("수납 하시겠습니까?", "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                return;

            string cash_rcpt_amt = ucObillInf11.txtCashRcptAmt.Text.Replace(",", "");
            if (!string.IsNullOrWhiteSpace(cash_rcpt_amt))
            {
                // 현금에 마이너스 금액이 있는 경우 한 번 더 물어보자.
                int.TryParse(cash_rcpt_amt, out int cash_amt);
                if (cash_amt < 0)
                {
                    if (!LxMessage.Show("마이너스 금액으로 수납하려 합니다.\r\n환불하는 금액이 맞습니까?", "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Error).Equals(DialogResult.Yes))
                        return;
                }
            }

            if (trms_cmpl_yn)
            {
                popClRsResn pop = new popClRsResn();
                pop.ShowDialog(this);
                clrs_resn_cnts = pop.RESN_CNTS;
                pop.Dispose();
                pop = null;
            }

            try
            {
                DBService.BeginTransaction();

                // 응급실주과가 변경되었으면
                if (ucOrecRegInf11.EMRM_MMCD_CD_bk != ucOrecRegInf11.OutRegInfo.EMRM_MMCD_CD)
                {
                    clsPACommon.UpdatePAOPATRT_EMRM_MMCD_CD(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), ucOrecRegInf11.OutRegInfo.MDCR_DD, ucOrecRegInf11.OutRegInfo.EMRM_MMCD_CD);
                }

                //의료급여 정신과 환자 예외코드가 "13"이 아닌경우 외래접수의 예외사유코드를 "13"으로 변경한다.
                if (ucOrecRegInf11.UpdateExcpResnCdOfPaOpaRt(ref msg) < 1)
                {
                    throw new Exception("[UpdateExcpResnCdOfPaOpaRt] " + msg);
                }

                // 원외처방전 교부번호 발생
                if (rcptsaveyn.Equals("Y"))
                {
                    if (ucOutReceiptBD1.CreateOuprGrntNo(ucOrecRegInf11.OutRegInfo.MDCR_DD, ref msg) < 1)
                    {
                        throw new Exception("[CreateOuprGrntNo] " + msg);
                    }
                }
                //TODO : 지원부서 수납 순번 생성, 외래처방에 수납 순서 설정

                //외래접수정보에 수납 횟수를 UPDATE
                if (ucOrecRegInf11.UpdateRcptNotmOfPaOpaRt(ref msg) < 1)
                {
                    throw new Exception("[UpdateRcptNotmOfPaOpaRt] " + msg);
                }

                string errordvcd = string.Empty;
                string errorcnts = string.Empty;

                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                // 2019-08-06 SJH 추가
                // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
                if (ucOrecRegInf11.Compare_ASST_TYCD != ucOrecRegInf11.OutRegInfo.ASST_TYCD)
                {
                    if (!SqlPack.Procedure.PR_PA_PRC_PAOPATRTCH(pid, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), ucOrecRegInf11.OutRegInfo.RCPN_SQNO.ToString(), "ASST_TYCD", ucOrecRegInf11.OutRegInfo.ASST_TYCD, DOPack.UserInfo.USER_CD, ref errordvcd, ref errorcnts))
                        throw new Exception(string.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));

                    if (StringService.IsNotNull(errordvcd))
                        throw new Exception("오류 내용[PR_PA_PRC_PAOPATRTCH] : [" + errordvcd + "]" + errorcnts);
                }

                if (ucOrecRegInf11.Compare_CFSC_RGNO_CD != ucOrecRegInf11.OutRegInfo.CFSC_RGNO_CD)
                {
                    if (!SqlPack.Procedure.PR_PA_PRC_PAOPATRTCH(pid, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), ucOrecRegInf11.OutRegInfo.RCPN_SQNO.ToString(), "CFSC_RGNO_CD", ucOrecRegInf11.OutRegInfo.CFSC_RGNO_CD, DOPack.UserInfo.USER_CD, ref errordvcd, ref errorcnts))
                        throw new Exception(string.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));

                    if (StringService.IsNotNull(errordvcd))
                        throw new Exception("오류 내용[PR_PA_PRC_PAOPATRTCH] : [" + errordvcd + "]" + errorcnts);
                }

                //옵션에 따른 진료완료정보를 UPDATE
                if (ConfigService.GetConfigValueString("PA", "RECEIPT", "MDCR_END_UPD", "N") == "Y")
                {
                    if (!SqlPack.Procedure.PR_PA_PRC_PAOPATRTCH(pid, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), ucOrecRegInf11.OutRegInfo.RCPN_SQNO.ToString(), "PT_MDCR_STAT_DVCD", "5", DOPack.UserInfo.USER_CD, ref errordvcd, ref errorcnts))
                    {
                        throw new Exception(string.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));
                    }

                    if (StringService.IsNotNull(errordvcd))
                    {
                        throw new Exception("오류 내용[PR_PA_PRC_PAOPATRTCH] : [" + errordvcd + "]" + errorcnts);
                    }
                }

                string dlwtuniqno = String.Empty;
                string currentdate = DateTimeService.NowDateTimeNoneSeperatorString();

                //약국처방의뢰 정보에 DATA를 INSERT
                if (!ucOutReceiptBD1.InsertORSQTPIF(pid, currentdate, ref dlwtuniqno, ref msg))
                {
                    throw new Exception("[InsertORSQTPIF] " + msg);
                }

                // 전자서명
                if (!EMBizCommon.SetESignOrderPickUp(ucOrecRegInf11.OutRegInfo.PID, dlwtuniqno, ref msg))
                    throw new Exception(string.Format("[EMBizCommon.SetESignOrderPickUp]\r\n전자서명 중 에러가 발생했습니다.{0}", msg));

                if (!SqlPack.Procedure.PR_PM_READ_PMPRRQIF(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), "O", "", "", "OUTREC", dlwtuniqno, currentdate, DOPack.UserInfo.USER_CD, ref errordvcd, ref errorcnts))
                {
                    msg = "약국처방의뢰 생성중 오류를 발생했습니다.\r\n [PR_PM_READ_PMPRRQIF] 오류메시지 : " + DBService.ErrorMessage;
                    throw new Exception(msg);
                }

                if (StringService.IsNotNull(errordvcd))
                {
                    msg = "약국처방의뢰 생성중 오류를 발생했습니다.\r\n [PR_PM_READ_PMPRRQIF] 오류메시지 : [" + errordvcd + "]" + errorcnts;
                    throw new Exception(msg);
                }

                if (!ORBizCommon.UpdateORSQTPIF_DLWT_YN_Y(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), dlwtuniqno, "OUTREC"))
                {
                    msg = "약국처방의뢰 생성중 오류를 발생했습니다.\r\n [UpdateORSQTPIF_DLWT_YN_Y] 오류메시지 : " + DBService.ErrorMessage;
                    throw new Exception(msg);
                }

                // 처방등록의 수납여부 및 원외처방교부번호를 UPDATE
                if (ucOutReceiptBD1.UpdateRcptYnOfOrOrdrRt(ref msg) < 1)
                {
                    throw new Exception("[UpdateRcptYnOfOrOrdrRt] " + msg);
                }

                // 수납일련번호를 가져온다.
                rcptsqno = m_OutBillBd.SelectMaxRcptSqno(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO, out msg);

                if (rcptsqno < 0)
                {
                    throw new Exception("[SelectMaxRcptSqno] " + msg);
                }

                // 영수증번호를 생성한다.
                if (!clsPACommon.GetBillNo(DateTimeService.NowDateNoneSeperatorString(), ref billno, ref msg))
                {
                    throw new Exception("[GetBillNo] " + msg);
                }

                // 수납발생고유번호를 생성한다.
                string rcptocrruniqno = String.Empty;

                if (!clsPACommon.GetRcptOcrrUniqNo(currentdate, ref rcptocrruniqno, ref msg))
                {
                    throw new Exception("[GetRcptOcrrUniqNo] " + msg);
                }

                // 재수납의 경우
                if (rcptsqno >= 1)
                {
                    newrcptsqno = rcptsqno + 1;

                    /* 기존 발생 수익집계내역의 마이너스 금액을 생성 한다*/
                    OutProfitBd.PID = ucOrecRegInf11.OutRegInfo.PID;
                    OutProfitBd.PT_CMHS_NO = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                    OutProfitBd.RCPT_SQNO = rcptsqno;                                                   //최종 영수증 수납일련번호
                    OutProfitBd.NEW_RCPT_RQNO = newrcptsqno;                                            //신규 영수증 수납일련번호
                    OutProfitBd.BILL_NO = billno;                                                       // 신규 영수증번호
                    OutProfitBd.RGST_DT = currentdate;
                    OutProfitBd.RGSTR_ID = DOPack.UserInfo.USER_CD;
                    OutProfitBd.STATVAL1 = -1;                                                          // 금액을 마이너스 처리함.
                    OutProfitBd.AFRS_STAT_DVCD = "5";                                                   // 업무구분코드   : "5" 
                    OutProfitBd.ROW_STAT_DVCD = "A";                                                    // 행상태구분코드 : 기존
                    OutProfitBd.NEW_ROW_STAT_DVCD = "D";                                                // 행상태구분코드 : 취소

                    if (!OutProfitBd.SavePaOpraBd(ref msg))
                    {
                        throw new Exception("[SavePaOpraBd] 수익코드집계내역 확인[D] :  " + msg);
                    }

                    OutBillBd.PID = ucOrecRegInf11.OutRegInfo.PID;
                    OutBillBd.PT_CMHS_NO = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                    OutBillBd.RCPT_SQNO = rcptsqno;                                                     // 최종 영수증 수납일련번호
                    OutBillBd.NEW_RCPT_RQNO = newrcptsqno;                                              // 신규 영수증 수납일련번호
                    OutBillBd.BILL_NO = billno;                                                         // 신규 영수증번호
                    OutBillBd.RCPT_OCRR_UNIQ_NO = rcptocrruniqno;                                       // 수납발생고유번호
                    OutBillBd.RGST_DT = currentdate;
                    OutBillBd.RGSTR_ID = DOPack.UserInfo.USER_CD;
                    OutBillBd.STATVAL1 = -1;                                                            // 금액을 마이너스 처리함.
                    OutBillBd.STATVAL2 = -1;                                                            // 금액을 마이너스 처리함.
                    OutBillBd.STATVAL3 = -1;                                                            // 금액을 마이너스 처리함.
                    OutBillBd.AFRS_STAT_DVCD = "5";                                                     // 업무구분코드   : "5"
                    OutBillBd.ROW_STAT_DVCD = "A";                                                      // 행상태구분코드 : 기존
                    OutBillBd.NEW_ROW_STAT_DVCD = "D";                                                  // 행상태구분코드 : 취소

                    if (!OutBillBd.SavePaObilBd(ref msg))
                    {
                        throw new Exception("[SavePaObilBd] 외래영수내역 확인[D] :  " + msg);
                    }

                    OutReceiptBd.PID = ucOrecRegInf11.OutRegInfo.PID;
                    OutReceiptBd.PT_CMHS_NO = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                    OutReceiptBd.RCPT_SQNO = rcptsqno;                                                  //최종 영수증 수납일련번호
                    OutReceiptBd.NEW_RCPT_RQNO = newrcptsqno;                                           //신규 영수증 수납일련번호
                    OutReceiptBd.MDCR_DD = ucOrecRegInf11.OutRegInfo.MDCR_DD;                           // 내원일자
                    OutReceiptBd.RGST_DT = currentdate;
                    OutReceiptBd.RGSTR_ID = DOPack.UserInfo.USER_CD;
                    m_OutReceiptBd.STATVAL1 = -1;                                                       // 금액을 마이너스 처리함.
                    OutReceiptBd.AFRS_STAT_DVCD = "5";                                                  // 업무구분코드   : "5" 
                    OutReceiptBd.ROW_STAT_DVCD = "A";                                                   // 행상태구분코드 : 기존
                    OutReceiptBd.NEW_ROW_STAT_DVCD = "D";                                               // 행상태구분코드 : 취소

                    if (!OutReceiptBd.SavePaOrecBd(ref msg, "D"))
                    {
                        throw new Exception("[SavePaOrecBd] 외래수납처방내역 확인[D] :  " + msg);
                    }

                    //ucOrecRegInf11.OutRegInfo에 대한 정보는 현재기준임 -> OutBillBd로 변경 : 마지막 수납된 정보로 하는게 맞음(2019.07.25 PMK)
                    //if (ucOrecRegInf11.OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("2") && !ucOrecRegInf11.OutRegInfo.ASST_TYCD.Equals("99") && !ucOrecRegInf11.OutRegInfo.ASST_TYCD.Equals("91"))
                    if (OutBillBd.INSN_TYCD.Substring(0, 1).Equals("2") && !OutBillBd.ASST_TYCD.Equals("99") && !OutBillBd.ASST_TYCD.Equals("91"))
                    {

                        int cnt = DBService.ExecuteInteger(SQL.PA.Sql.SelectCountPANHM4MA_Check(), pid
                                                                                                 , ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString());

                        if (cnt >= 1)
                        {
                            // 의료급여 승인취소처리를 한다.
                            if (!clsPACommon.PermitAndCancelMedicalAid(pid, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO, newrcptsqno, rcptocrruniqno, rcptsqno, "O", ucOrecRegInf11.OutRegInfo.DY_WARD_YN, ucOrecRegInf11.OutRegInfo.INSN_TYCD, ucOrecRegInf11.OutRegInfo.MDCR_DD, "A", "D", ref msg))
                            {
                                throw new Exception("[PermitAndCancelMedicalAid] 의료급여 승인취소처리 확인[D] :  " + msg);
                            }
                            LxMessage.Show("승인취소 되었습니다 \r\n 취소 응답을 받기 위해서 지연시간을 설정했습니다. 2초후 사라집니다.", "승인취소", MessageBoxButtons.OK, MessageBoxIcon.Information, 2);
                        }
                    }

                    //회계연동관련
                    clsPACommon.SaveAccountingPacapema(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString());

                    OutReceiptBd.PID = ucOrecRegInf11.OutRegInfo.PID;
                    OutReceiptBd.PT_CMHS_NO = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                    OutReceiptBd.ROW_STAT_DVCD = "A";                                                         // 행상태구분코드 : 기존
                    OutReceiptBd.NEW_ROW_STAT_DVCD = "C";                                                     // 행상태구분코드 : 취소

                    if (!OutReceiptBd.UpdateRowStatDvcdOfPaOrecBd(ref msg))
                    {
                        throw new Exception("[UpdateRowStatDvcdOfPaOrecBd] 수납계산처방내역 확인[C] :  " + msg);
                    }

                    OutProfitBd.PID = ucOrecRegInf11.OutRegInfo.PID;
                    OutProfitBd.PT_CMHS_NO = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                    OutProfitBd.ROW_STAT_DVCD = "A";                                                          // 행상태구분코드 : 기존
                    OutProfitBd.NEW_ROW_STAT_DVCD = "C";                                                      // 행상태구분코드 : 취소

                    if (!OutProfitBd.UpdateRowStatDvcdOfPaOpraBd(ref msg))
                    {
                        throw new Exception("[UpdateRowStatDvcdOfPaOpraBd] 수익코드집계내역 확인[C] :  " + msg);
                    }

                    OutBillBd.PID = ucOrecRegInf11.OutRegInfo.PID;
                    OutBillBd.PT_CMHS_NO = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                    OutBillBd.AFRS_STAT_DVCD = "3";                                                           // 업무구분코드   : "3" 외래접수취소
                    OutBillBd.ROW_STAT_DVCD = "A";                                                            // 행상태구분코드 : 기존
                    OutBillBd.NEW_ROW_STAT_DVCD = "C";                                                        // 행상태구분코드 : 취소

                    if (!OutBillBd.UpdateRowStatDvcdOfPaObilBd(ref msg))
                    {
                        throw new Exception("[UpdateRowStatDvcdOfPaObilBd] 외래영수내역 확인[C] :  " + msg);
                    }

                    // ++++++++++++++++++++++++++++++++++++++++
                    // 협력업체 지원금액을 저장한다. (SJH 2019-03-20) C/D를 만들자.
                    // ++++++++++++++++++++++++++++++++++++++++
                    if (!clsPACommon.SavePACOBSMA_Make_C_D(OutBillBd.PID, OutBillBd.PT_CMHS_NO.ToString(), prevRcptOcrrUniqNo, currentdate, ref msg))
                    {
                        throw new Exception("[SavePACOBSMA_Make_C_D] 기존 협력업체 지원금액 취소 저장 : " + msg);
                    }

                    // 2019-06-20 SJH 일단 막아놓자.
                    /*
                    //혈액감액정보의 수납여부 변경
                    if (!clsPACommon.SavePABREDMA_Make_C_D(OutBillBd.PID, OutBillBd.PT_CMHS_NO.ToString(), prevRcptOcrrUniqNo, currentdate, ref msg))
                    {
                        throw new Exception("[SaveRcptYnOfPaBredMa] 혈액감액정보 :  " + msg);
                    }
                     * */
                }

                newrcptsqno++;

                if (m_STATVAL1 == 1)
                {
                    foreach (DataRow row in m_DtProfit.Rows)
                    {
                        if (!DBService.ExecuteNonQuery(SQL.PA.BaseSql.Insert.PAOPRABD(), ucOrecRegInf11.OutRegInfo.PID
                                                                                       , ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString()
                                                                                       , newrcptsqno.ToString()
                                                                                       , row["PRFT_CD"].ToString()
                                                                                       , ucOrecRegInf11.OutRegInfo.MDCR_DD
                                                                                       , billno
                                                                                       , ucOrecRegInf11.OutRegInfo.INSN_TYCD
                                                                                       , ucOrecRegInf11.OutRegInfo.ASST_TYCD
                                                                                       , ucOrecRegInf11.OutRegInfo.ASCT_RGNO_CD
                                                                                       , ucOrecRegInf11.OutRegInfo.MDCR_DEPT_CD
                                                                                       , ucOrecRegInf11.OutRegInfo.MDCR_DR_CD
                                                                                       , (int.Parse(row["PAY_MATL_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (int.Parse(row["PAY_ACTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (int.Parse(row["PAY_BYKN_ADTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (int.Parse(row["INSN_100_MATL_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (int.Parse(row["INSN_100_ACTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (int.Parse(row["I100_HSBK_ADTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (int.Parse(row["SCNG_PAY_MATL_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (int.Parse(row["SCNG_PAY_ACTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (int.Parse(row["SCPY_BYKN_ADTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (int.Parse(row["CLAM_NOPY_MATL_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (int.Parse(row["CLAM_NOPY_ACTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (int.Parse(row["CCPY_HSBK_ADTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (int.Parse(row["NOPY_MATL_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (int.Parse(row["NOPY_ACTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (int.Parse(row["NOPY_BYKN_ADTN_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (int.Parse(row["SMCR_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (int.Parse(row["MDCN_UPLM_DIAM"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (double.Parse(row["PAY_ACTN_USCH_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (double.Parse(row["PAY_ACTN_CLAM_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (double.Parse(row["PAY_MATL_USCH_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (double.Parse(row["PAY_MATL_CLAM_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (double.Parse(row["SCPY_MATL_USCH_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (double.Parse(row["SCPY_MATL_CLAM_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (double.Parse(row["SCPY_ACTN_USCH_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , (double.Parse(row["SCPY_ACTN_CLAM_AMT"].ToString()) * m_STATVAL1).ToString()
                                                                                       , ""
                                                                                       , ""
                                                                                       , "5"
                                                                                       , "A"
                                                                                       , ClientService.IP
                                                                                       , currentdate
                                                                                       , DOPack.UserInfo.USER_CD
                                                                                       , (int.Parse(row["GVRN_CLAM_AMT"].ToString()) * m_STATVAL1).ToString()))
                            throw new Exception("외래수익코드집계내역 저장 중 에러가 발생했습니다.");
                    }
                }
                else
                {
                    //수익코드별집계내역 저장
                    OutProfitTp.PID = ucOrecRegInf11.OutRegInfo.PID;
                    OutProfitTp.PT_CMHS_NO = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                    OutProfitTp.RCPT_SQNO = rcptsqno;                                                       //최종 영수증 수납일련번호
                    OutProfitTp.NEW_RCPT_RQNO = newrcptsqno;                                                //신규 영수증 수납일련번호
                    OutProfitTp.BILL_NO = billno;                                                           // 신규 영수증번호
                    OutProfitTp.RGST_DT = currentdate;
                    OutProfitTp.RGSTR_ID = DOPack.UserInfo.USER_CD;
                    OutProfitTp.AFRS_STAT_DVCD = "5";                                                       // 업무구분코드   : "5" 
                    OutProfitTp.ROW_STAT_DVCD = "A";                                                        // 행상태구분코드 : 기존
                    OutProfitTp.NEW_ROW_STAT_DVCD = "A";                                                    // 행상태구분코드 : 취소
                    OutProfitTp.MDCR_DD = ucOrecRegInf11.OutRegInfo.MDCR_DD;
                    OutProfitTp.MDCR_DEPT_CD = ucOrecRegInf11.OutRegInfo.MDCR_DEPT_CD;
                    OutProfitTp.MDCR_DR_CD = ucOrecRegInf11.OutRegInfo.MDCR_DR_CD;
                    OutProfitTp.INSN_TYCD = ucOrecRegInf11.OutRegInfo.INSN_TYCD;
                    OutProfitTp.ASST_TYCD = ucOrecRegInf11.OutRegInfo.ASST_TYCD;
                    OutProfitTp.ASCT_RGNO_CD = ucOrecRegInf11.OutRegInfo.ASCT_RGNO_CD;

                    if (!OutProfitTp.SavePaOpraBd(OutProfitTp.DtProfit, ref msg))
                    {
                        throw new Exception("[SavePaOpraBd] 수익코드집계내역 확인[A] :  " + msg);
                    }
                }

                //영수내역 저장

                // 영수정보생성한다.
                // 미수정보생성한다.
                // 의료급여승인한다.
                ucObillInf11.BillBd.RCPT_SQNO = newrcptsqno;
                ucObillInf11.BillBd.BILL_NO = billno;
                ucObillInf11.BillBd.RCPT_OCRR_UNIQ_NO = rcptocrruniqno;
                ucObillInf11.BillBd.MDCR_DEPT_CD = ucOrecRegInf11.OutRegInfo.MDCR_DEPT_CD;
                ucObillInf11.BillBd.MDCR_DR_CD = ucOrecRegInf11.OutRegInfo.MDCR_DR_CD;
                ucObillInf11.BillBd.INSN_TYCD = ucOrecRegInf11.OutRegInfo.INSN_TYCD;
                ucObillInf11.BillBd.ASST_TYCD = ucOrecRegInf11.OutRegInfo.ASST_TYCD;
                ucObillInf11.BillBd.ASCT_RGNO_CD = ucOrecRegInf11.OutRegInfo.ASCT_RGNO_CD;
                ucObillInf11.BillBd.RGST_DT = currentdate;

                if (ucObillInf11.SavePaObilBd(ucOrecRegInf11.OutRegInfo.CFSC_RGNO_CD, ref msg) < 1)
                {
                    throw new Exception("[SavePaObilBd] 영수증내역 확인[A]" + msg);
                }

                //TODO: 수납처방 History 저장 로직 구현 여부확인?

                ucOutReceiptBD1.OutRecBD.PID = ucOrecRegInf11.OutRegInfo.PID;
                ucOutReceiptBD1.OutRecBD.PT_CMHS_NO = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                ucOutReceiptBD1.OutRecBD.RCPT_SQNO = rcptsqno;                                                    //최종 영수증 수납일련번호
                ucOutReceiptBD1.OutRecBD.NEW_RCPT_RQNO = newrcptsqno;                                             //신규 영수증 수납일련번호
                ucOutReceiptBD1.OutRecBD.MDCR_DD = ucOrecRegInf11.OutRegInfo.MDCR_DD;                             // 내원일자
                ucOutReceiptBD1.OutRecBD.RGST_DT = currentdate;
                ucOutReceiptBD1.OutRecBD.RGSTR_ID = DOPack.UserInfo.USER_CD;
                ucOutReceiptBD1.OutRecBD.AFRS_STAT_DVCD = "5";                                                    // 업무구분코드   : "5" 
                ucOutReceiptBD1.OutRecBD.ROW_STAT_DVCD = "A";                                                     // 행상태구분코드 : 기존
                ucOutReceiptBD1.OutRecBD.NEW_ROW_STAT_DVCD = "A";                                                 // 행상태구분코드 : 취소

                // 수납처방을 저장한다.
                if (!ucOutReceiptBD1.InsertPaOrecBd(ref msg))
                {
                    throw new Exception("[InsertPaOrecBd] 수납처방[A] :  " + msg);
                }

                // 이 로직은 무조건 paorecbd가 insert된 이후에 call되어야 한다.
                if (ucOrecRegInf11.OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("2") && !ucOrecRegInf11.OutRegInfo.ASST_TYCD.Equals("99") && !ucOrecRegInf11.OutRegInfo.ASST_TYCD.Equals("91"))
                {
                    // 의료급여 승인처리를 한다.
                    if (!clsPACommon.PermitAndCancelMedicalAid(pid, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO, newrcptsqno, rcptocrruniqno, rcptsqno, "O", ucOrecRegInf11.OutRegInfo.DY_WARD_YN, ucOrecRegInf11.OutRegInfo.INSN_TYCD, ucOrecRegInf11.OutRegInfo.MDCR_DD, "A", "A", ref msg))
                    {
                        throw new Exception("[PermitAndCancelMedicalAid] 의료급여 승인처리 :  " + msg);
                    }
                }

                //혈액감액정보의 수납여부 변경
                if (!ucObillInf11.SaveRcptYnOfPaBredMa(ref msg))
                {
                    throw new Exception("[SaveRcptYnOfPaBredMa] 혈액감액정보 :  " + msg);
                }

                //TODO : 상병저장 처방에서 입력한 상병 그대로 사용

                //자보한도액에 조합부담액 발생시킨다.
                if (!ucObillInf11.SavePaTlimMa(ref msg))
                {
                    throw new Exception("[SavePaTlimMa] 자보한도액 : " + msg);
                }

                //환자기본정보의 특이사항저장
                if (!ucOremInf1.SavePaPathInRemark(ref msg))
                {
                    throw new Exception("[SavePaPathInRemark] 환자기본정보의 특이사항저장 : " + msg);
                }

                //환자접수 특이사항저장
                if (!ucOremInf2.SaveRegistrationRemark(ref msg))
                {
                    throw new Exception("[SaveRegistrationRemark] 환자접수 특이사항저장 : " + msg);
                }

                //카드현금승인내역의 영수정보를 변경한다.
                if (!ucObillInf11.SavePaCapeMa(ref msg))
                {
                    throw new Exception("[SavePaCapeMa] 카드현금승인정보 변경 : " + msg);
                }

                // ++++++++++++++++++++++++++++++++++++++++
                // 협력업체 지원금액을 저장한다. (SJH 2019-03-20)
                // ++++++++++++++++++++++++++++++++++++++++
                if (!ucObillInf11.SavePACOBSMA(ref msg))
                {
                    throw new Exception("[SavePACOBSMA] 협력업체 지원금액 저장 : " + msg);
                }

                // 정신과 의료급여 정액정률표시
                ucOrecRegInf11.UpdateFxamFxrtDvcdOfPaOpatRt(ucObillInf11.BillBd.FXAM_MCCS);

                //TODO : 환불정보변경
                //TODO : 진료비오류수납유무

                // 자동초재진변경을 체크한다.
                if (ucOrecRegInf11.FrvsRvstDvcdSave)
                {
                    string frvsrvstdvcd = ucOrecRegInf11.OutRegInfo.FRVS_RVST_DVCD;

                    // if (!ucOrecRegInf11.OutRegInfo.CheckFrvsRvstDvcd(ref msg))
                    if (!SqlPack.Procedure.PR_PA_PRC_PAOPATRTCH(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), ucOrecRegInf11.OutRegInfo.RCPN_SQNO.ToString(),
                                                               "FRVS_RVST_DVCD", ucOrecRegInf11.OutRegInfo.FRVS_RVST_DVCD, DOPack.UserInfo.USER_CD, ref errordvcd, ref errorcnts))
                    {
                        throw new Exception("[PR_PA_PRC_PAOPATRTCH] 초진재진확인 : " + msg);
                    }

                    if (StringService.IsNotNull(errordvcd))
                    {
                        throw new Exception("[PR_PA_PRC_PAOPATRTCH] errordvcd : [" + errordvcd + "] " + errorcnts);
                    }
                }
                //외래접수의 보조유형코드, 산정특례코드 변경한다.
                if (!ucOrecRegInf11.OutRegInfo.UpdateAsstTycdOfPaOpatRt(ref msg))
                {
                    throw new Exception("[UpdateAsstTycdOfPaOpatRt]  : " + msg);
                }

                //TODO : 카드/현금 강제영수여부 변경


                //TODO : 의료급여 최종 자격조회정보 저장

                // 조함기호변경
                if ((ucOrecRegInf11.OutRegInfo.INSN_TYCD.Substring(0, 1) == "1" || ucOrecRegInf11.OutRegInfo.INSN_TYCD.Substring(0, 1) == "2") &&
                   !ucOrecRegInf11.OutRegInfo.ASST_TYCD.Equals("99") && !ucOrecRegInf11.OutRegInfo.ASST_TYCD.Equals("D9"))
                {
                    if (!ucOrecRegInf11.OutRegInfo.UpdateAsctRgnoCdOfPaOpatRt(ref msg))
                    {
                        throw new Exception("[UpdateAsctRgnoCdOfPaOpatRt]  : " + msg);
                    }
                }

                if (Lime.PA.clsPACommon.CheckNonCmpy(ucOrecRegInf11.OutRegInfo.PID, false))
                {
                    UpdatePAOUNRMA_DEL_DVSN();

                    if (!DBService.ExecuteNonQuery(SQL.PA.Sql.DeletePAORECBD()
                                                 , ucOrecRegInf11.OutRegInfo.PID
                                                 , ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString()
                                                 , "-1"))
                        throw new Exception("미정산 내역을 삭제하는 중 에러가 발생했습니다.");
                }

                // TODO : 부가세대상여부
                // TODO : 수납완료후 상병수정 안되게
                // TODO : 노인틀니대상자로 접수했지만 대상이 아닌경우 비대상으로 변경
                // TODO : 보훈국비7급 대상자중 본인일부부담금 대상자
                // TODO : 마약원외처방이 존재시 
                // TODO : 자보일부본인부담율
                // TODO : 계약회사 미수정보
                // TODO : 응급실 KTAS 등급 저장
                // TODO : V252상병저장

                // TODO : 작업 업무 삭제

                if (!this.UnLockSystem(pid, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), "PA"))
                {
                    msg = "작업 업무 삭제중 오류가 발생하였습니다.";
                    throw new Exception("[UnLockSystem]  : " + msg);
                }

                if (trms_cmpl_yn)
                {
                    if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertPACLRSMA()
                        , ucOrecRegInf11.OutRegInfo.PID
                        , ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString()
                        , ucOrecRegInf11.OutRegInfo.RCPN_SQNO.ToString()

                        , ucOrecRegInf11.OutRegInfo.MDCR_DD
                        , ucOrecRegInf11.OutRegInfo.INSN_TYCD
                        , ucOrecRegInf11.OutRegInfo.ASST_TYCD
                        , ucOrecRegInf11.OutRegInfo.INSN_TYCD
                        , ucOrecRegInf11.OutRegInfo.ASST_TYCD
                        , ucOrecRegInf11.OutRegInfo.MDCR_DEPT_CD
                        , ucOrecRegInf11.OutRegInfo.MDCR_DR_CD
                        , ucOrecRegInf11.OutRegInfo.MDCR_DEPT_CD
                        , ucOrecRegInf11.OutRegInfo.MDCR_DR_CD
                        , "N"
                        , ""
                        , ""
                        , clrs_resn_cnts
                        , pacl_resn_dvcd
                        , ""
                        , ""
                        , ""
                        , ""))
                        throw new Exception("InsertPACLRSMA [" + DBService.ErrorCode + "] " + DBService.ErrorMessage);
                }

                // 재수납 대상 환자여부를 Y로 Update한다.
                clsPACommon.UpdatePAORCHMA(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), currentdate);

                DBService.CommitTransaction();

                ucObillInf11.DisposeViewer();
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                if (DBService.IsTransaction)
                    DBService.RollbackTransaction();

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
                return;
            }
            // TODO : 상병변경여부확인

            // +++++++++++++++++++++++++++++++++++++++++++++++++++++
            // 영수증 출력
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++
            PrintMedicalBill();

            // +++++++++++++++++++++++++++++++++++++++++++++++++++++
            // 원외 처방전 출력
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++
            // 원외처방전 교부번호가 중복 발행되었는지 확인
            if (ucOutReceiptBD1.CheckIsSameOuprGrntNo(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.MDCR_DD, ref msg) > 0)
            {
                LxMessage.ShowInformation(msg, "확인");
            }
            // 원외처방전 교부번호가 없는 처방이 있는지 확인
            if (ucOutReceiptBD1.CheckIsNoOuprGrntNo(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO, ref msg) > 0)
            {
                LxMessage.ShowInformation(msg, "확인");
            }

            if (ucOutReceiptBD1.m_OuprYn.Equals("Y") && rcptsaveyn.Equals("N") && ucOutReceiptBD1.m_OuprGrntNo.Equals("NO"))
            {
                LxMessage.ShowInformation("원외처방전이 출력되지 않은 경우 재수납 해 주세요.");
            }

            // 원외처방전 출력
            if (ucOutReceiptBD1.m_OuprYn.Equals("Y") && StringService.IsNotNull(ucOutReceiptBD1.m_OuprGrntNo) && !ucOutReceiptBD1.m_OuprGrntNo.Equals("NO") && ucOutReceiptBD1.m_OuprGrntNo.Length > 8)
            {
                PrintPrescription();
                ucOutReceiptBD1.m_OuprGrntNo = "NO";
                ucOutReceiptBD1.m_OuprYn = "N";
            }

            // +++++++++++++++++++++++++++++++++++++++++++++++++++++
            // 원내 처방전 출력
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++
            PrintInHospPrescription();

            // TODO : 의료급여환자 공단과의 처리시간 관련하여 Delay 
            // TODO : 검사예약처방 존재 확인한다.

            // 당일 내원일 이전에 미수납된 처방이 있는지 확인한다.
            DataTable dt = new DataTable();

            if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectNoRcptPrsc(), ref dt, ucOrecRegInf11.OutRegInfo.PID
                                                                               , ucOrecRegInf11.OutRegInfo.MDCR_DD))
            {
                string message = string.Empty;

                if (dt.Rows.Count.Equals(1))
                {
                    message = string.Format("{0} 일자에 미수납된 자료가 있습니다.\r\n이동하시겠습니까?", DateTimeService.ConvertDateStringToFormatString(dt.Rows[0]["MDCR_DD"].ToString()));
                    if (LxMessage.ShowQuestion(message).Equals(DialogResult.Yes))
                    {
                        this.DisplayPateintInfo("NONREC", ucOrecRegInf11.OutRegInfo.PID, int.Parse(dt.Rows[0]["PT_CMHS_NO"].ToString()), dt.Rows[0]["MDCR_DD"].ToString());
                        return;
                    }
                }
                else if (dt.Rows.Count > 1)
                {
                    foreach (DataRow row in dt.Rows)
                        message += string.Format("{0}{1}", string.IsNullOrWhiteSpace(message) ? string.Empty : ", ", DateTimeService.ConvertDateStringToFormatString(row["MDCR_DD"].ToString()));

                    LxMessage.ShowInformation(string.Format("아래 일자에 미수납된 자료가 있습니다. 확인해 주세요.\r\n\r\n{0}", message));
                }
            }

            // 타과접수 내역이 존재 확인
            string otherMdcr = string.Empty;
            SelectTodayOtherRegInfo(pid, ucOrecRegInf11.OutRegInfo.MDCR_DD, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), ref otherMdcr);

            if (!otherMdcr.Equals(string.Empty)) // if(ucSameDayRegList1.m_RegCount > 1)
            {
                otherMdcr = string.Format("수납완료\r\n\r\n타과접수 내역이 존재합니다. 확인해 주세요.{0}", otherMdcr);

                LxMessage.ShowInformation(otherMdcr);
                ucSameDayRegList1.SelectData(pid, dteMdcrDd.DateTimeValue.ToString("yyyyMMdd"), ucOrecRegInf11.OutRegInfo.MDCR_DEPT_CD);
            }
            else
            {
                LxMessage.ShowInformation("수납완료", 2);
            }

            // 초기화
            Clear();

            // 2018-07-24 SEO 수납 완료 후 초기화되는 기능 삭제 + 수납 후 수납화면에 이전환자 번호 설정
            if (StringService.IsNotNull(pid))
            {
                ucOrecRegInf11.txtPid.Text = pid;
                PostCallService.PostFocus(ucOrecRegInf11.txtPid);
            }

            // 2018-10-15 SEO 의료급여 미승인 환자가 있으면 팝업으로 보여준다.
            /*
            clsPACommon.CheckMedicalCarePatientNonePermitNo(this);
             * */
            //clsPACommon.CheckNoneCard(this); 

            // 재수납 대상
            if (clsPACommon.CheckNeedReReceipt())
                btnNeedRereciept.PerformClick();

            this.SetButtonColor();

            // LOAD시 수납대기창 자동열기
            if (ConfigService.GetConfigValueString("PA", "RECEIPT2", "WATING", "N").ToString().Equals("N")) return;

            PopUpReceiptWating();

        }

        private void SelectTodayOtherRegInfo(string pid, string mdcrdd, string ptcmhsno, ref string otherMdcr)
        {
            DataTable tempDt = new DataTable();
            string sqltext = string.Format(@"
    SELECT T.*
         , FN_BI_READ_BIDEPTMA(T.MDCR_DEPT_CD, T.MDCR_DD, 'DEPT_HNM') DEPT_NM
         , FN_BI_READ_USERNM(T.MDCR_DR_CD) MDCR_DR_NM
      FROM PAOPATRT T
     WHERE T.PID                = '{0}'
       AND T.MDCR_DD            = '{1}'
       AND T.PT_CMHS_NO        <> '{2}'
       AND T.PT_MDCR_STAT_DVCD <> '9'
       AND T.ROW_STAT_DVCD      = 'A'
       AND T.PRSC_NOTM          > T.RCPT_NOTM ", pid, mdcrdd, ptcmhsno);

            DBService.ExecuteDataTable(sqltext, ref tempDt);

            otherMdcr = string.Empty;
            for (int i = 0; i < tempDt.Rows.Count; i++)
                otherMdcr += string.Format("\r\n    - {0}  ( {1} )", tempDt.Rows[i]["DEPT_NM"].ToString(), tempDt.Rows[i]["MDCR_DR_NM"].ToString());
        }

        /// <summary>
        /// 내역변경 프로그램을 호출한다.
        /// </summary>
        private void PopupInsnTypeChange(bool checkSaveYn)
        {
            if (checkSaveYn && !m_SaveYn)
            {
                LxMessage.Show("접수정보가 변경되었습니다. \r\n 접수정보변경재계산 작업을 수행하세요.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (StringService.IsNull(ucOrecRegInf11.OutRegInfo.PID))
                return;

            // LOCK 해제
            if (StringService.IsNotNull(ucOrecRegInf11.OutRegInfo.PID))
            {
                this.UnLockSystem(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString());
            }

            // TODO : 카드 승인 확인
            string msg = String.Empty;

            if (!clsPACommon.CheckCreditPermit("O", ucObillInf11.BillTp.PID, ucObillInf11.BillTp.PT_CMHS_NO.ToString()))
            {
                msg = "신용카드/현금 승인된 자료가 존재합니다.\r\n" +
                      "수납 또는 승인취소를 진행하지 않으면,\r\n마감시 금액이 맞지 않습니다.\r\n\r\n" +
                      "내역변경 하시겠습니까?";

                if (LxMessage.Show(msg, "내역변경여부", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
                    return;
            }

            using (frmOutInsnTypeChangeP popup = new frmOutInsnTypeChangeP(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO, false))
            {
                popup.BaseMDI = this.BaseMDI;
                if (!popup.ShowDialog(this).Equals(DialogResult.OK))
                    return;

                Clear();

                // 강제적용인 경우
                ucOrecRegInf11.chkReBurn.Checked = popup.ReBurn.Equals("Y");
                ucOrecRegInf11.lblForceChange.Visible = popup.ReBurn.Equals("Y");

                DisplayPateintInfo("TYPECHNG", popup.Pid, popup.PtCmhsNo, popup.MdcrDd);
            }
        }

        /// 처방변경 프로그램을 호출한다.
        /// </summary>
        private void PopupPnpyDvcdChange()
        {
            if (!m_SaveYn)
            {
                LxMessage.Show("접수정보가 변경되었습니다. \r\n 접수정보변경재계산 작업을 수행하세요.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (StringService.IsNull(ucOrecRegInf11.OutRegInfo.PID))
            {
                LxMessage.Show("환자 수납정보를 먼저 조회해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            string msg = String.Empty;

            if (!clsPACommon.CheckCreditPermit("O", ucObillInf11.BillTp.PID, ucObillInf11.BillTp.PT_CMHS_NO.ToString()))
            {
                msg = "신용카드/현금 승인된 자료가 존재합니다.\r\n" +
                      "수납 또는 승인취소를 진행하지 않으면,\r\n마감시 금액이 맞지 않습니다.\r\n\r\n" +
                      "처방변경 하시겠습니까?";

                if (LxMessage.Show(msg, "처방변경여부", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
                    return;
            }

            frmChangePnpyDvcdP popPnpyChange = new frmChangePnpyDvcdP(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO);
            popPnpyChange.BaseMDI = this.BaseMDI;
            popPnpyChange.ShowDialog(this);

            if (popPnpyChange.DialogResult == DialogResult.OK)
            {
                Clear();
                DisplayPateintInfo("WAIT", popPnpyChange.Pid, popPnpyChange.PtCmhsNo, popPnpyChange.MdcrDD);
            }
            popPnpyChange.Dispose();
        }

        private void PrintPrescription()
        {
            m_PrintType = Lime.BusinessControls.PrescriptionType.None;
            if (chkForPharmacy.Checked) m_PrintType |= Lime.BusinessControls.PrescriptionType.PH;
            if (chkForPatient.Checked) m_PrintType |= Lime.BusinessControls.PrescriptionType.PT;

            using (Lime.BusinessControls.clsPrescriptionSlip a = new Lime.BusinessControls.clsPrescriptionSlip())
                a.PrintNew(ucOrecRegInf11.OutRegInfo.PID
                         , ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString()
                         , ucOutReceiptBD1.m_OuprGrntNo
                         , "O"
                         , m_PrintType
                         , chkIlnsCd.Checked
                         , false
                         , chkForWhitePrint.Checked
                         , true);
        }

        /// <summary>
        /// 진료비영수증출력
        /// </summary>
        private void PrintMedicalBill()
        {
            m_ReceiptPrint.PrintReceiptOut(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), "A", false, false, false, string.Empty, string.Empty, false, true);
        }

        /// <summary>
        /// 원내 처방전 출력
        /// </summary>
        private void PrintInHospPrescription()
        {
            if (!ConfigService.GetConfigValueBool("PA", "IN_PRESCRIPTION", "IN_PRESCRIPTION", false))
                return;

            string pid = ucOrecRegInf11.OutRegInfo.PID;
            string tempSQL = string.Format(@"
SELECT MAX(MDCT_NO) AS MDCT_NO
  FROM PMPRRQIF
 WHERE PID           = '{0}'
   AND PT_CMHS_NO    =  {1}
   AND MDCR_DD       = '{2}'
   AND ROW_STAT_DVCD = 'A'
   AND ((PRSC_LCLS_CD = '30') OR (PRSC_LCLS_CD = '20' AND PRSC_MCLS_CD = '70')) ", pid
                                                                                 , ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString()
                                                                                 , ucOrecRegInf11.OutRegInfo.MDCR_DD);

            string mdct_no = DBService.ExecuteScalar(tempSQL).ToString();
            if (!mdct_no.Equals(string.Empty) && mdct_no.Length.Equals(13))
            {
                clsInHospPrescript a = new clsInHospPrescript();
                a.Print(mdct_no, pid, false);
                a.Dispose();
            }
        }

        /// <summary>
        /// 선택한 환자의 접수 정보 및 계산정보를 조회한다.
        /// </summary>
        /// <param name="flag"></param>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="mdcrdd"></param>
        private void DisplayPateintInfo(string flag, string pid, int ptcmhsno, string mdcrdd)
        {
            string msg = String.Empty;

            // LOCK 해제
            if (StringService.IsNotNull(ucOrecRegInf11.OutRegInfo.PID))
            {
                this.UnLockSystem(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString());
            }

            if (!ucOrecRegInf11.OutRegInfo.Load("PT_CMHS_NO", pid, ptcmhsno, mdcrdd)) return;

            if (ucOrecRegInf11.OutRegInfo.ETC_USE_CNTS_5 != null && ucOrecRegInf11.OutRegInfo.ETC_USE_CNTS_5 == "강제변경:재수상")
                ucOrecRegInf11.chkReBurn.Checked = true;
            else
                ucOrecRegInf11.chkReBurn.Checked = false;

            if (!clsPACommon.CheckNotAply_CttrUnclAplyAmt(pid, ptcmhsno.ToString(), mdcrdd, mdcrdd))
            {
                // TODO : SJH 2019-05-07 일단 코멘트아웃해놓자.
                //LxMessage.ShowInformation("협력지원금 temp데이터 수정 중 에러가 발생했습니다.\r\n관리자에게 연락 바랍니다.");
                //return;
            }

            if (ucOrecRegInf11.CheckPatientRegistInfo(ref msg) < 0)
            {
                DBService.RollbackTransaction();

                if (StringService.IsNotNull(msg))
                {
                    LxMessage.Show(msg, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                return;
            }
            else
            {
                if (StringService.IsNotNull(msg))
                {
                    LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }

            ucOrecRegInf11.SetPatientRegInfo();

            // 타과 접수 내역이 있으면 보여준다.
            ucSameDayRegList1.SelectData(pid, mdcrdd, ucOrecRegInf11.OutRegInfo.MDCR_DEPT_CD);
        }

        /// <summary>
        /// 접수정보변경후 재계산..
        /// </summary>
        private void ReCalculateRegChange()
        {
            string msg = String.Empty;

            //승인/승인취소된 상태에서 재계산 버튼을 누르면 바로 적용될 수 있게 처리해준다.
            if (!clsPACommon.CheckCreditPermit("O", ucObillInf11.BillTp.PID, ucObillInf11.BillTp.PT_CMHS_NO.ToString()))
            {
                ucObillInf11.BillNoApply();
            }

            ucOrecRegInf11.m_ChangeFlag = "F";
            m_SaveYn = true;

            // 수납버튼 비활성화
            EnableSaveReceipt(true);
            // 내역변경버튼 비활성화
            btnButtonList.SetButtonEnable(ButtonType.Custom1, true);
            // 처방변경
            btnButtonList.SetButtonEnable(ButtonType.Custom5, true);
            // 접수정보변경재계산
            btnButtonList.SetButtonEnable(ButtonType.Custom6, false);

            // LOCK 해제
            if (StringService.IsNotNull(ucOrecRegInf11.OutRegInfo.PID))
            {
                this.UnLockSystem(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString());
            }

            if (ucOrecRegInf11.CheckPatientRegistInfo(ref msg) < 0)
            {
                DBService.RollbackTransaction();
                if (StringService.IsNotNull(msg))
                {
                    LxMessage.Show(msg, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                return;
            }
            else
            {
                if (StringService.IsNotNull(msg))
                {
                    LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        /// <summary>
        /// 자격조회
        /// </summary>
        private void ShowNhisMessage()
        {
            DOPack.PatientInfo.Load(ucOrecRegInf11.OutRegInfo.PID);
            clsNhisM1 m1 = new clsNhisM1();
            if (!m1.SendM1(dteMdcrDd.DateTimeValue.ToString("yyyyMMdd"), false, ucOrecRegInf11.OutRegInfo.PT_NM, ucOrecRegInf11.OutRegInfo.RRNO))
            {
                LxMessage.ShowError("자격조회 중 에러가 발생했습니다.\r\n다시 조회해 주세요.");
                return;
            }

            m1.OnGetMessage2 += m1_OnGetMessage2;
        }

        private void m1_OnGetMessage2(clsNhisM2 m2)
        {
            Lime.BusinessControls.popMessage2Response pop = new Lime.BusinessControls.popMessage2Response();
            pop.SetM2Data(m2);
            pop.StartPosition = FormStartPosition.CenterParent;
            pop.ShowDialog();
            pop.Dispose();
        }

        /// <summary>
        /// 영수증재발행 화면 Call
        /// </summary>
        private void RePrintBill()
        {
            string pid = String.Empty;
            string ptcmhsno = String.Empty;
            string mdcrdd = String.Empty;

            ScreenParameters param = new ScreenParameters();

            if (!ucOutReceiptBD1.GetPid(ref pid, ref ptcmhsno, ref mdcrdd))
            {
                pid = ucOrecRegInf11.OutRegInfo.PID;
                ptcmhsno = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString();
                mdcrdd = ucOrecRegInf11.OutRegInfo.MDCR_DD;
            }

            if (StringService.IsNull(pid)) return;

            param.Add("PID", pid);
            param.Add("PT_CMHS_NO", ptcmhsno);
            param.Add("MDCR_DD", mdcrdd);
            this.CallScreen("Lime.PA.dll", "Lime.PA.ucfOutBillRePrintR", "외래영수증 재발행", param);
        }

        /// <summary>
        /// 임시 영수증 발행 화면 Call
        /// </summary>
        private void TempPrintBill()
        {
            m_ReceiptPrint.PrintReceiptOut(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), "A", false, true, false, string.Empty, string.Empty, false, true);
        }

        /// <summary>
        /// 처방전재발행 화면 Call
        /// </summary>
        private void RePrintOutPriscription()
        {
            ScreenParameters param = new ScreenParameters();
            if (StringService.IsNull(ucOrecRegInf11.OutRegInfo.PID)) return;

            param.Add("PID", ucOrecRegInf11.OutRegInfo.PID);

            this.CallScreen("Lime.PA.dll", "Lime.PA.ucfOutPrescriptionSlipR", "원외처방전 재발행", param);
        }

        /// <summary>
        /// 대기자 PopUp
        /// </summary>
        private void PopUpReceiptWating()
        {
            try
            {
                string msg = String.Empty;

                if (!clsPACommon.CheckCreditPermit("O", ucObillInf11.BillTp.PID, ucObillInf11.BillTp.PT_CMHS_NO.ToString()))
                {
                    msg = "신용카드/현금 승인된 자료가 존재합니다.\r\n" +
                          "수납 또는 승인취소를 진행하지 않으면,\r\n마감시 금액이 맞지 않습니다.\r\n\r\n" +
                          "환자를 조회하시겠습니까?";

                    if (LxMessage.Show(msg, "환자조회여부", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
                        return;

                    ucObillInf11.BillNoApply();
                }

                this.Clear();

                ucOrecRegInf11.m_Mdcr_Dd = dteMdcrDd.DateTimeValue.ToString("yyyyMMdd");
                frmOutReceiptWatingP popwating = new frmOutReceiptWatingP(dteMdcrDd.DateTimeValue.ToString("yyyyMMdd"));
                popwating.BaseMDI = this.BaseMDI;
                popwating.ShowDialog(this);
                if (popwating.DialogResult.Equals(DialogResult.OK))
                {
                    dteMdcrDd.DateTime = DateTimeService.ConvertDateTime(popwating.MdcrDd);
                    ucOrecRegInf11.m_Mdcr_Dd = popwating.MdcrDd;

                    DisplayPateintInfo("WAIT", popwating.Pid, popwating.PtCmhsNo, popwating.MdcrDd);

                    //YJS, 특이사항 유무에 따라 팝업띄우기.
                    if (Lime.PA.clsPACommon.HasPatientMemo(ucOrecRegInf11.txtPid.Text))
                    {
                        Lime.BusinessControls.popPatientMemo pop = new Lime.BusinessControls.popPatientMemo(popwating.Pid);
                        pop.ShowDialog(this); 
                        pop.Dispose();
                    }
                }
                popwating.Dispose();
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        /// <summary>
        /// YJS 추가
        /// <para>환자 특이사항 등록 팝업 띄우기.</para>
        /// </summary>
        private void ViewMemo()
        {
            if (string.IsNullOrWhiteSpace(ucOrecRegInf11.txtPid.Text))
            {
                LxMessage.ShowError("환자가 선택되지 않아 [특이사항]을 오픈할 수 없습니다.");
                return;
            }

            Lime.BusinessControls.popPatientMemo pop = new Lime.BusinessControls.popPatientMemo(ucOrecRegInf11.txtPid.Text);
            pop.ShowDialog(this);
            pop.Dispose();
        }

        private void CallEmr()
        {
            try
            {
                string pid = String.Empty;
                string ptcmhsno = String.Empty;
                pid = ucOrecRegInf11.OutRegInfo.PID;
                ptcmhsno = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString();

                if (StringService.IsNull(pid)) return;

                //string sheetcode = DBService.ExecuteScalar(SqlPack.Function.SelectFN_BI_READ_BICDINDT(), "EM_SHEET_DVCD", "INIT_BURN", DateTime.Now.ToString("yyyyMMdd"), "LWRN_OVRL_CDNM").ToString();

                SystemService.OpenEMR(pid, "O", ptcmhsno);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        private void SetButtonColor()
        {
            // 의료급여 미승인
            clsPACommon.SetButtonColor(btnNonPermit, "0");
            if (clsPACommon.HasNonPermit())
                clsPACommon.SetButtonColor(btnNonPermit, "1");

            // 재수납 대상
            clsPACommon.SetButtonColor(btnNeedRereciept, "0");
            if (clsPACommon.CheckNeedReReceipt())
                clsPACommon.SetButtonColor(btnNeedRereciept, "1");
        }

        /// <summary>
        /// 선택한 환자의 정보를 보여준다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="mdcrdd"></param>
        private void ShowPatientInfoForReceipt(string pid, int ptcmhsno, string mdcrdd)
        {
            try
            {
                string msg = String.Empty;

                this.SetButtonColor();

                // LOCK 해제
                this.UnLockSystem(ucObillInf11.BillTp.PID, ucObillInf11.BillTp.PT_CMHS_NO.ToString());

                if (!clsPACommon.CheckCreditPermit("O", ucObillInf11.BillTp.PID, ucObillInf11.BillTp.PT_CMHS_NO.ToString()))
                {
                    msg = "신용카드/현금 승인된 자료가 존재합니다.\r\n" +
                          "수납 또는 승인취소를 진행하지 않으면,\r\n마감시 금액이 맞지 않습니다.\r\n\r\n" +
                          "환자를 조회하시겠습니까?";

                    if (LxMessage.Show(msg, "환자조회여부", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
                        return;

                    ucObillInf11.BillNoApply();
                }

                this.Clear(false);
                ucOrecRegInf11.m_Mdcr_Dd = dteMdcrDd.DateTimeValue.ToString("yyyyMMdd");
                dteMdcrDd.DateTime = DateTimeService.ConvertDateTime(mdcrdd);
                ucOrecRegInf11.m_Mdcr_Dd = mdcrdd;

                DisplayPateintInfo("WAIT", pid, ptcmhsno, mdcrdd);
                ShowWatingWindow();
                Lime.PA.clsPACommon.CheckNonCmpy(ucOrecRegInf11.OutRegInfo.PID, true);

                //YJS, 특이사항 유무에 따라 팝업띄우기.
                if (Lime.PA.clsPACommon.HasPatientMemo(ucOrecRegInf11.txtPid.Text))
                {
                    Lime.BusinessControls.popPatientMemo pop = new Lime.BusinessControls.popPatientMemo(pid);
                    pop.ShowDialog(this);
                    pop.Dispose();
                }

                if (chkAutoEmr.Checked)
                    CallEmr();
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            GC.Collect();
        }

        private void ShowWatingWindow()
        {

            if (tabWating.Tabs[0].Selected)
            {

                if (!m_VisibleWating)
                {
                    if (StringService.IsNotNull(ucOrecRegInf11.txtPid.Text))
                    {
                        ucOutRecWatingList1.SetCurrentRow(ucOrecRegInf11.txtPid.Text);
                    }
                    pnlWating.Width = 800;
                    pnlWating.Height = pnlBase.Height;
                    pnlWating.BringToFront();
                    m_VisibleWating = true;
                    ucOutRecWatingList1.SetDate(dteMdcrDd.DateTimeValue.ToString("yyyyMMdd"));
                }
                else
                {
                    if (!ucOutRecWatingList1.AutoVisible) return;

                    pnlWating.Width = 28;
                    pnlWating.Height = pnlBase.Height;
                    pnlWating.BringToFront();
                    m_VisibleWating = false;

                    // 2018-04-26 권재호 외래대기자 수정
                    tabWating.SelectedTab = null;
                    tabWating.ActiveTab = null;
                }
            }
        }

        /// <summary>
        /// 미정산처리
        /// </summary>
        private void NonCmpySave()
        {
            try
            {
                string msg = String.Empty;
                string iovmsg = String.Empty;
                string pid = ucOrecRegInf11.OutRegInfo.PID;
                string ptcmhsno = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString();
                string rcpnsqno = ucOrecRegInf11.OutRegInfo.RCPN_SQNO.ToString();
                string mdcrdd = ucOrecRegInf11.OutRegInfo.MDCR_DD;
                string mdcrdeptcd = ucOrecRegInf11.OutRegInfo.MDCR_DEPT_CD;
                string mdcrdrcd = ucOrecRegInf11.OutRegInfo.MDCR_DR_CD;
                string insntycd = ucOrecRegInf11.OutRegInfo.INSN_TYCD;
                string assttycd = ucOrecRegInf11.OutRegInfo.ASST_TYCD;
                int unclamt = 0;                    // 미수금액
                int rcptsqno = 0;
                int newrcptsqno = 0;
                int rcptamt = 0;
                int cashamt = 0;
                int cardamt = 0;
                int bnacamt = 0;
                string noncmpysqno = string.Empty;  //미정산일련번호                
                string pclrmatr = String.Empty;     // 특이사항 미정산처리 사융                
                string ouprgrntno = "NO";

                if (StringService.IsNull(pid))
                {
                    LxMessage.Show("환자를 선택하세요.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // OCS오픈일자를 확인한다.
                if (!clsPACommon.CheckOcsOpenDate(ucOrecRegInf11.OutRegInfo.MDCR_DD))
                    return;

                /*
                if (DBService.ExecuteScalar(SqlPack.Function.SelectFN_CL_PRC_CHKCLAMCRTN()
                                          , pid, ptcmhsno, iovmsg).ToString() == "Y")
                {

                    LxMessage.Show("해당 환자는 청구심사 중이거나 이미 청구가 완료되어 수정이 불가합니다.\r\n" +
                                   "보험 심사과에 문의하세요.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                 * */

                //환자 자보구분 확인
                string revw_rqst_yn = DBService.ExecuteScalar(SQL.PA.Sql.SelectPAOPATRT_REVW_RQST_YN()
                                                            , pid, ptcmhsno).ToString();

                if (DBService.HasError)
                    throw new Exception(string.Format("오류내용 : [{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));

                if (revw_rqst_yn == "Y")
                {
                    LxMessage.Show("해당 환자 진료정보는 자동차보험 지급심사요청건으로 등록된 자료입니다.\r\n" +
                                   "보험 심사과에 문의하세요.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                string currentdate = DateTimeService.NowDateTimeNoneSeperatorString();

                frmMemo frm = new frmMemo();

                if (frm.ShowDialog() == DialogResult.OK)
                    pclrmatr = frm.Memo;    // 미정산 처리 사유

                frm.Dispose();

                if (string.IsNullOrEmpty(pclrmatr.Trim()))
                {
                    LxMessage.Show("미정산 처리 사유를 입력하지 않았습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                //Transaction 밖에서 체크하고 들어간다.
                if (ucOutReceiptBD1.m_InMedYn.Equals("Y"))
                {
                    DialogResult dr = LxMessage.Show("미수납 원내약 처방이 존재합니다.\r\n미정산 처리 하시겠습니까?", "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (dr.Equals(DialogResult.No)) return;
                }

                //미정산 발생 횟수
                int noncmpycnt = DBService.ExecuteInteger(SQL.PA.Sql.SelectCountOfPAOUNRMA(), pid, ptcmhsno);

                if (DBService.HasError)
                    throw new Exception(string.Format("오류내용 : [{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));

                int.TryParse(ucObillInf11.txtUnclAmt.Text.Replace(",", ""), out unclamt); // 미수금액
                int.TryParse(ucObillInf11.txtCashRcptAmt.Text.Replace(",", ""), out cashamt);
                int.TryParse(ucObillInf11.txtCardRcptAmt.Text.Replace(",", ""), out cardamt);
                int.TryParse(ucObillInf11.txtBnacRcptAmt.Text.Replace(",", ""), out bnacamt);

                // 청구 생성 되었는지 확인한다.
                bool trms_cmpl_yn = false;
                if (!clsPACommon.CheckCLAM_CRTN_YN(pid, ptcmhsno, rcpnsqno, true, true, ref msg, ref trms_cmpl_yn))
                    return;

                string clrs_resn_cnts = string.Empty;
                string pacl_resn_dvcd = "RO"; // 외래청구간 사유 구분코드
                if (trms_cmpl_yn)
                {
                    popClRsResn pop = new popClRsResn();
                    pop.ShowDialog(this);
                    clrs_resn_cnts = pop.RESN_CNTS;
                    pop.Dispose();
                    pop = null;
                }

                DBService.BeginTransaction();

                // EDI전송된 경우는 사유를 남겨놓자.
                if (trms_cmpl_yn)
                {
                    if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertPACLRSMA()
                        , ucOrecRegInf11.OutRegInfo.PID
                        , ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString()
                        , ucOrecRegInf11.OutRegInfo.RCPN_SQNO.ToString()

                        , ucOrecRegInf11.OutRegInfo.MDCR_DD
                        , ucOrecRegInf11.OutRegInfo.INSN_TYCD
                        , ucOrecRegInf11.OutRegInfo.ASST_TYCD
                        , ucOrecRegInf11.OutRegInfo.INSN_TYCD
                        , ucOrecRegInf11.OutRegInfo.ASST_TYCD
                        , ucOrecRegInf11.OutRegInfo.MDCR_DEPT_CD
                        , ucOrecRegInf11.OutRegInfo.MDCR_DR_CD
                        , ucOrecRegInf11.OutRegInfo.MDCR_DEPT_CD
                        , ucOrecRegInf11.OutRegInfo.MDCR_DR_CD
                        , "N"
                        , ""
                        , ""
                        , clrs_resn_cnts
                        , pacl_resn_dvcd // 외래청구간 사유 구분코드
                        , ""
                        , ""
                        , ""
                        , ""))
                        throw new Exception("InsertPACLRSMA [" + DBService.ErrorCode + "] " + DBService.ErrorMessage);
                }

                //미수납 약제 전달,의뢰정보생성
                if (ucOutReceiptBD1.m_InMedYn.Equals("Y"))
                {
                    string dlwtuniqno = String.Empty;
                    string errordvcd = String.Empty;
                    string errorcnts = String.Empty;

                    //약국처방의뢰 정보에 DATA를 INSERT
                    if (!ucOutReceiptBD1.InsertORSQTPIF(ucOrecRegInf11.OutRegInfo.PID, currentdate, ref dlwtuniqno, ref msg))
                        throw new Exception("[InsertORSQTPIF] " + msg);

                    if (!SqlPack.Procedure.PR_PM_READ_PMPRRQIF(pid, ptcmhsno, "O", "", "", "OUTREC", dlwtuniqno, currentdate, DOPack.UserInfo.USER_CD, ref errordvcd, ref errorcnts))
                    {
                        msg = "약국처방의뢰 생성중 오류를 발생했습니다.\r\n [PR_PM_READ_PMPRRQIF] 오류메시지 : " + DBService.ErrorMessage;
                        throw new Exception(msg);
                    }

                    if (StringService.IsNotNull(errordvcd))
                    {
                        msg = "약국처방의뢰 생성중 오류를 발생했습니다.\r\n [PR_PM_READ_PMPRRQIF] 오류메시지 : [" + errordvcd + "]" + errorcnts;
                        throw new Exception(msg);
                    }

                    if (!ORBizCommon.UpdateORSQTPIF_DLWT_YN_Y(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), dlwtuniqno, "OUTREC"))
                    {
                        msg = "약국처방의뢰 생성중 오류를 발생했습니다.\r\n [UpdateORSQTPIF_DLWT_YN_Y] 오류메시지 : " + DBService.ErrorMessage;
                        throw new Exception(msg);
                    }
                }

                //미수납 원외처방이 존재하면 교부번호 생성한다.                
                if (ucOutReceiptBD1.CreateOuprGrntNo(ucOrecRegInf11.OutRegInfo.MDCR_DD, ref msg) < 1)
                    throw new Exception("[CreateOuprGrntNo] " + msg);

                //외래접수정보에 수납 횟수를 UPDATE
                if (ucOrecRegInf11.UpdateRcptNotmOfPaOpaRt(ref msg) < 1)
                    throw new Exception("[UpdateRcptNotmOfPaOpaRt] " + msg);

                // 2019-01-18 처방변경된 경우, 원외처방교부번호 Update 하지 않기 위한 플래그가 추가됨 (printPrescription)
                // [미정산처리]의 경우에는 false를 Default로 한다.
                // 처방등록의 수납여부 및 원외처방교부번호를 UPDATE
                if (ucOutReceiptBD1.UpdateRcptYnOfOrOrdrRt(ref msg) < 1)
                    throw new Exception("[UpdateRcptYnOfOrOrdrRt] " + msg);

                // 수납일련번호를 가져온다. (PAOBILBD에 있는 RCPT_SQNO의 MAX값을 가져온다.)
                rcptsqno = m_OutBillBd.SelectMaxRcptSqno(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO, out msg);

                if (rcptsqno < 0)
                    throw new Exception("[SelectMaxRcptSqno] " + msg);

                bool reReceipt = false;
                if (rcptsqno > 0)
                {
                    //미정산처리는 C,D,A가 증가하면 안된다. - DELETE & INSERT 방식으로 처리
                    //외래수익코드별집계내역(PAOPARABD), 외래영수내역(PAOBILBD) 순번이 틀어지기 때문에
                    //newrcptsqno = rcptsqno + 1;

                    //OutReceiptBd.PID                = ucOrecRegInf11.OutRegInfo.PID;
                    //OutReceiptBd.PT_CMHS_NO         = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                    //OutReceiptBd.RCPT_SQNO          = rcptsqno;                                       //최종 영수증 수납일련번호
                    //OutReceiptBd.NEW_RCPT_RQNO      = newrcptsqno;                                    //신규 영수증 수납일련번호
                    //OutReceiptBd.MDCR_DD            = ucOrecRegInf11.OutRegInfo.MDCR_DD;              // 내원일자
                    //OutReceiptBd.RGST_DT            = currentdate;
                    //OutReceiptBd.RGSTR_ID           = DOPack.UserInfo.USER_CD;
                    //m_OutReceiptBd.STATVAL1         = -1;                                             // 금액을 마이너스 처리함.
                    //OutReceiptBd.AFRS_STAT_DVCD     = "5";                                            // 업무구분코드   : "5" 
                    //OutReceiptBd.ROW_STAT_DVCD      = "A";                                            // 행상태구분코드 : 기존
                    //OutReceiptBd.NEW_ROW_STAT_DVCD  = "D";                                            // 행상태구분코드 : 취소

                    //if (!OutReceiptBd.SavePaOrecBd(ref msg, "D"))
                    //{
                    //    throw new Exception("[SavePaOrecBd] 외래수납처방내역 확인[D] :  " + msg);
                    //}

                    //OutReceiptBd.PID                = ucOrecRegInf11.OutRegInfo.PID;
                    //OutReceiptBd.PT_CMHS_NO         = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                    //OutReceiptBd.ROW_STAT_DVCD      = "A";                                                     // 행상태구분코드 : 기존
                    //OutReceiptBd.NEW_ROW_STAT_DVCD  = "C";                                                     // 행상태구분코드 : 취소

                    //if (!OutReceiptBd.UpdateRowStatDvcdOfPaOrecBd(ref msg))
                    //{
                    //    throw new Exception("[UpdateRowStatDvcdOfPaOrecBd] 수납계산처방내역 확인[C] :  " + msg);
                    //}

                    if (!DBService.ExecuteNonQuery(SQL.PA.Sql.DeletePAORECBD()
                                                 , ucOrecRegInf11.OutRegInfo.PID
                                                 , ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString()
                                                 , rcptsqno.ToString()))
                        throw new Exception("[DeletePAORECBD] 수납처방[A] :  " + DBService.ErrorMessage + "[" + DBService.ErrorCode + "]");

                    reReceipt = true;
                }

                //newrcptsqno++;

                ucOutReceiptBD1.OutRecBD.PID = ucOrecRegInf11.OutRegInfo.PID;
                ucOutReceiptBD1.OutRecBD.PT_CMHS_NO = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                ucOutReceiptBD1.OutRecBD.RCPT_SQNO = reReceipt ? rcptsqno : -1;                                            //최종 영수증 수납일련번호
                ucOutReceiptBD1.OutRecBD.NEW_RCPT_RQNO = reReceipt ? rcptsqno : -1;                                            //최종 영수증 수납일련번호 - 미정산일때는 Delete & Insert이므로.. 신규번호가 최종 영수증 수납일련번호이다
                ucOutReceiptBD1.OutRecBD.MDCR_DD = ucOrecRegInf11.OutRegInfo.MDCR_DD;                   // 내원일자
                ucOutReceiptBD1.OutRecBD.RGST_DT = currentdate;
                ucOutReceiptBD1.OutRecBD.RGSTR_ID = DOPack.UserInfo.USER_CD;
                //m_OutReceiptBd.STATVAL1                   = -1;                                                  // 금액을 마이너스 처리함.
                ucOutReceiptBD1.OutRecBD.AFRS_STAT_DVCD = "5";                                                 // 업무구분코드   : "5" 
                ucOutReceiptBD1.OutRecBD.ROW_STAT_DVCD = "A";                                                 // 행상태구분코드 : 기존
                ucOutReceiptBD1.OutRecBD.NEW_ROW_STAT_DVCD = "A";                                                 // 행상태구분코드 : 취소

                // 수납처방을 저장한다.
                if (!ucOutReceiptBD1.InsertPaOrecBd(ref msg))
                    throw new Exception("[InsertPaOrecBd] 수납처방[A] :  " + msg);

                rcptamt = cashamt + cardamt + bnacamt + unclamt;

                if (noncmpycnt <= 0)
                {
                    noncmpysqno = DBService.ExecuteScalar(SQL.PA.Sql.SelectPAOUNRMA_MAX_NON_CMPY_SQNO()
                                                        , pid, ptcmhsno).ToString();

                    if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertPAOUNRMA(), pid
                                                                                , ptcmhsno
                                                                                , noncmpysqno.ToString()
                                                                                , mdcrdd
                                                                                , mdcrdeptcd
                                                                                , mdcrdrcd
                                                                                , insntycd
                                                                                , assttycd
                                                                                , rcptamt.ToString()
                                                                                , pclrmatr
                                                                                , "0"
                                                                                , "N"
                                                                                , ""
                                                                                , ""
                                                                                , "A"
                                                                                , ClientService.IP
                                                                                , currentdate
                                                                                , DOPack.UserInfo.USER_CD
                                                                                , currentdate
                                                                                , DOPack.UserInfo.USER_CD
                                                                                ))
                    {
                        throw new Exception(string.Format("[InsertPAOUNRMA]오류내용 : [{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));
                    }
                }
                else if (noncmpycnt == 1)
                {
                    if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePAOUNRMA(), pid
                                                                                , ptcmhsno
                                                                                , "N"
                                                                                , DOPack.UserInfo.USER_CD
                                                                                , currentdate
                                                                                , pclrmatr
                                                                                , rcptamt.ToString()
                                                                                , currentdate
                                                                                , DOPack.UserInfo.USER_CD
                                                                                ))
                    {
                        throw new Exception(string.Format("[UpdatePAOUNRMA]오류내용 : [{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));
                    }
                }

                // 재수납 대상 환자여부를 Y로 Update한다.
                clsPACommon.UpdatePAORCHMA(pid, ptcmhsno, currentdate);

                DBService.CommitTransaction();

                LxMessage.ShowInformation("미정산 처리되었습니다.", 2);

                this.Clear();
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                if (DBService.IsTransaction)
                    DBService.RollbackTransaction();

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }

        }

        /// <summary>
        /// 미정산내역을 처리한다.
        /// </summary>
        private void UpdatePAOUNRMA_DEL_DVSN()
        {
            try
            {
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePAOUNRMA_DEL_DVSN()
                                             , ucOrecRegInf11.OutRegInfo.PID
                                             , ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString()
                                             , "D"))
                    throw new Exception("SelectPAUNCOMA_CNT - " + DBService.ErrorMessage + "[" + DBService.ErrorCode + "]");
            }
            catch (Exception ex)
            {
                LxMessage.Show(ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 환자인적정보수정
        private void ShowPopupPatientInfo()
        {
            string pid = ucOrecRegInf11.txtPid.Text;

            // 환자번호가 없으면 리턴.
            if (StringService.IsNull(pid))
                return;

            // 환자번호가 숫자형이 아니면 리턴.
            if (!StringService.IsNumeric(pid))
            {
                this.ActiveControl = ucOrecRegInf11.txtPid;
                LxMessage.Show("환자번호가 숫자형식이 아닙니다.\r\n환자번호를 확인해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            //등록되지 않은 환자번호면 리턴.
            ucOrecRegInf11.txtPid.Text = pid.PadLeft(9, '0');
            PatientInfo.Load(ucOrecRegInf11.txtPid.Text);
            if (string.IsNullOrWhiteSpace(PatientInfo.PT_NM))
            {
                this.ActiveControl = ucOrecRegInf11.txtPid;
                LxMessage.Show("등록되지 않은 환자번호입니다.\r\n환자번호를 확인해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            // 팝업 open
            popPatientInfoMod popmod = new popPatientInfoMod("P", pid);
            popmod.BaseMDI = this.BaseMDI;
            popmod.ShowDialog(this);
            popmod.Dispose();
        }

        // 초기화(F5)
        private void ClearForm()
        {
            string msg = String.Empty;

            if (!clsPACommon.CheckCreditPermit("O", ucObillInf11.BillTp.PID, ucObillInf11.BillTp.PT_CMHS_NO.ToString()))
            {
                msg = "신용카드/현금 승인된 자료가 존재합니다.\r\n" +
                      "수납 또는 승인취소를 진행하지 않으면,\r\n마감시 금액이 맞지 않습니다.\r\n\r\n" +
                      "초기화 하시겠습니까?";

                if (LxMessage.Show(msg, "초기화여부", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
                    return;
            }

            Clear();
        }

        // 대기자(F3)
        private void ShowPatientList()
        {
            // 대기자를 팝업으로 보여줄 경우.
            if (ConfigService.GetConfigValueString("PA", "RECEIPT", "POPUP", "N").ToString().Equals("Y"))
            {
                PopUpReceiptWating();   // 대기자 POPUP
                return;
            }

            // 대기자를 왼쪽 리스트에서 보여줄 경우.
            if (tabWating.Tabs.Count > 0)
            {
                if (m_VisibleWating)
                {
                    m_UseFilter = true;

                    pnlWating.Width = 28;
                    pnlWating.Height = pnlBase.Height;
                    pnlWating.BringToFront();
                    m_VisibleWating = false;

                    tabWating.SelectedTab = null;
                    tabWating.ActiveTab = null;
                }
                else
                {
                    m_UseFilter = false;
                    tabWating.Tabs[0].Selected = true;
                    tabWating.Tabs[0].Active = true;

                    // 2018-07-24 SEO 버튼 클릭 이벤트에는 있었으나, cmdKey이벤트에는 없었으므로 주석처리함
                    //ucOutRecWatingList1.SetDate(dteMdcrDd.DateTimeValue.ToString("yyyyMMdd"));
                }
            }
        }

        // 현금영수증, 카드 승인 팝업
        private void ShowCardCashPermitPopup(string cash_card_dvcd)
        {
            // 환자가 선택되지 않았으면 리턴.
            if (StringService.IsNull(ucOrecRegInf11.OutRegInfo.PID))
                return;

            ucObillInf11.PopUpCardCashPermit("P", "O", cash_card_dvcd, ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), ucOrecRegInf11.OutRegInfo.MDCR_DD);
            ucObillInf11.Focus();
        }

        private void EnableSaveReceipt(bool enable)
        {
            btnButtonList.SetButtonEnable(ButtonType.Save, enable);
            ucObillInf11.Enabled = enable;
        }

        private void ChangeUnComaBilbd()
        {
            try
            {
                string billno = string.Empty;
                string rcptocrruniqno = string.Empty;
                string msg = string.Empty;
                DataTable dt = new DataTable();
                int rcptsqno = 0;
                int newrcptsqno = 0;
                string currentdate = DateTime.Now.ToString("yyyyMMddHHmmss");
                int cash_rcpt_amt = 0;
                int bnac_rcpt_amt = 0;
                int card_rcpt_amt = 0;
                int uncl_amt = 0;

                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAUNCDMA_PT_CMHS_NO()
                                              , ref dt
                                              , ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), "O"))
                    throw new Exception("SQL.PA.Sql.SelectPAUNCDMA_PT_CMHS_NO\r\n" + DBService.ErrorMessage + "[" + DBService.ErrorCode + "]");

                if (dt.Rows.Count.Equals(0))
                    return;

                clsUncollectedDpstInfo uncldpstinfo = new clsUncollectedDpstInfo();
                clsCardCashPermitInfo permitInfo = new clsCardCashPermitInfo();
                int uncldpstsqnoold = 0;

                DBService.BeginTransaction();

                foreach (DataRow dr in dt.Rows)
                {
                    rcptsqno = 0;
                    newrcptsqno = 0;

                    // 영수증번호를 생성한다.
                    if (!clsPACommon.GetBillNo(DateTimeService.NowDateNoneSeperatorString(), ref billno, ref msg))
                    {
                        throw new Exception("[GetBillNo] " + msg);
                    }

                    // 수납발생고유번호를 생성한다.
                    if (!clsPACommon.GetRcptOcrrUniqNo(DateTimeService.NowDateTimeNoneSeperatorString(), ref rcptocrruniqno, ref msg))
                        throw new Exception("[GetRcptOcrrUniqNo] " + msg);

                    uncldpstinfo.Clear();

                    uncldpstsqnoold = int.Parse(dr["UNCL_DPST_SQNO"].ToString());

                    uncldpstinfo.BILL_NO = billno;
                    uncldpstinfo.RCPT_OCRR_UNIQ_NO = rcptocrruniqno;
                    uncldpstinfo.PID = dr["PID"].ToString();
                    uncldpstinfo.UNCL_OCRR_SQNO = int.Parse(dr["UNCL_OCRR_SQNO"].ToString());
                    uncldpstinfo.UNCL_DPST_DD = dr["UNCL_DPST_DD"].ToString();
                    uncldpstinfo.UNCL_OCRR_DVCD = dr["UNCL_OCRR_DVCD"].ToString();
                    uncldpstinfo.OTPT_ADMS_DVCD = dr["OTPT_ADMS_DVCD"].ToString();
                    uncldpstinfo.PT_CMHS_NO = int.Parse(dr["PT_CMHS_NO"].ToString());
                    uncldpstinfo.MDCR_DEPT_CD = dr["MDCR_DEPT_CD"].ToString();
                    uncldpstinfo.MDCR_DR_CD = dr["MDCR_DR_CD"].ToString();
                    uncldpstinfo.INSN_TYCD = dr["INSN_TYCD"].ToString();
                    uncldpstinfo.ASST_TYCD = dr["ASST_TYCD"].ToString();
                    uncldpstinfo.CARD_AMT = int.Parse(dr["CARD_AMT"].ToString()) * (-1);
                    uncldpstinfo.CASH_DPST_AMT = int.Parse(dr["CASH_DPST_AMT"].ToString()) * (-1);
                    uncldpstinfo.BNAC_DPST_AMT = int.Parse(dr["BNAC_DPST_AMT"].ToString()) * (-1);

                    uncldpstinfo.CUT_AMT = int.Parse(dr["CUT_AMT"].ToString()) * (-1);
                    uncldpstinfo.AJAM = int.Parse(dr["AJAM"].ToString()) * (-1);
                    uncldpstinfo.PCLR_MATR = dr["PCLR_MATR"].ToString();
                    uncldpstinfo.PTAF_CLSN_YN = "N";
                    uncldpstinfo.CNCL_YN = "Y";  // 체크 필요!!
                    uncldpstinfo.BILL_NO = billno;
                    uncldpstinfo.RCPT_DD = currentdate.Substring(0, 8);
                    uncldpstinfo.RCPT_TIME = currentdate.Substring(8, 4);
                    uncldpstinfo.RGST_DT = uncldpstinfo.UPDT_DT = currentdate;
                    uncldpstinfo.RGSTR_ID = uncldpstinfo.UPDTR_ID = DOPack.UserInfo.USER_CD;

                    // 마이너스(취소) 입금정보를 생성한다.
                    if (!uncldpstinfo.SavePAUNCDMA(ref msg))
                        throw new Exception(msg);

                    if (uncldpstsqnoold.Equals(0))
                        throw new Exception("원미수입금정보의 미수입금일련번호에 오류가 있습니다.");

                    uncldpstinfo.UNCL_DPST_SQNO_OLD = uncldpstsqnoold;

                    // 원미수입금정보의 취소여부를 "Y" 로 변경한다.
                    if (!uncldpstinfo.SaveUpdPAUNCDMA(ref msg))
                    {
                        throw new Exception(msg);
                    }

                    uncldpstinfo.IDFLAG = "D";

                    // 미수발생정보의 미수잔액을 변경한다.
                    if (!uncldpstinfo.SavePAUNCOMA(ref msg))
                        throw new Exception(msg);

                    // 카드테이블 취소
                    if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateCnclYnOfPACAPEMA_RCPT_OCRR_UNIQ_NO()
                                                , uncldpstinfo.PID, dr["RCPT_OCRR_UNIQ_NO"].ToString()))
                        throw new Exception("SQL.PA.Sql.UpdateCnclYnOfPACAPEMA_RCPT_OCRR_UNIQ_NO\r\n" + DBService.ErrorMessage + "[" + DBService.ErrorCode + "]");

                    // 카드 취소내역 Insert
                    if (!DBService.ExecuteNonQuery(SQL.PA.Sql.Insert_PACAPEMA_RCPT_OCRR_UNIQ_NO()
                                                 , uncldpstinfo.PID, dr["RCPT_OCRR_UNIQ_NO"].ToString(), rcptocrruniqno, uncldpstinfo.UNCL_DPST_SQNO.ToString(), billno
                                                 , currentdate, DOPack.UserInfo.USER_CD))
                        throw new Exception("SQL.PA.Sql.Insert_PACAPEMA_RCPT_OCRR_UNIQ_NO\r\n" + DBService.ErrorMessage + "[" + DBService.ErrorCode + "]");

                    // 2020-09-09 SJH 원래 아랫단에서 했는데 이쪽으로 옮김 여기가 맞는 듯.
                    if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertAccountingPacapema_uncoma()
                                                 , ucOrecRegInf11.OutRegInfo.PID, dr["RCPT_OCRR_UNIQ_NO"].ToString(), ucOrecRegInf11.OutRegInfo.MDCR_DD, currentdate, DOPack.UserInfo.USER_CD))
                        throw new Exception("미수입금금액을 외래로 변환하는 도중 에러가 발생했습니다.");

                    uncl_amt = int.Parse(dr["UNCL_AMT"].ToString());    //이건 미수발생테이블에서 가지고 옴 -> 더하지 않는다.

                    cash_rcpt_amt += int.Parse(dr["CASH_DPST_AMT"].ToString());
                    bnac_rcpt_amt += int.Parse(dr["BNAC_DPST_AMT"].ToString());
                    card_rcpt_amt += int.Parse(dr["CARD_AMT"].ToString());
                }

                uncl_amt -= cash_rcpt_amt + bnac_rcpt_amt + card_rcpt_amt;

                // 수납일련번호를 가져온다.
                rcptsqno = m_OutBillBd.SelectMaxRcptSqno(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO, out msg);

                if (rcptsqno < 0)
                {
                    throw new Exception("[SelectMaxRcptSqno] " + msg);
                }

                // 영수증번호를 생성한다.
                if (!clsPACommon.GetBillNo(DateTimeService.NowDateNoneSeperatorString(), ref billno, ref msg))
                {
                    throw new Exception("[GetBillNo] " + msg);
                }

                // 수납발생고유번호를 생성한다.
                if (!clsPACommon.GetRcptOcrrUniqNo(currentdate, ref rcptocrruniqno, ref msg))
                {
                    throw new Exception("[GetRcptOcrrUniqNo] " + msg);
                }

                if (rcptsqno >= 1)
                {
                    newrcptsqno = rcptsqno + 1;

                    /* 기존 발생 수익집계내역의 마이너스 금액을 생성 한다*/
                    OutProfitBd.PID = ucOrecRegInf11.OutRegInfo.PID;
                    OutProfitBd.PT_CMHS_NO = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                    OutProfitBd.RCPT_SQNO = rcptsqno;                                                   //최종 영수증 수납일련번호
                    OutProfitBd.NEW_RCPT_RQNO = newrcptsqno;                                            //신규 영수증 수납일련번호
                    OutProfitBd.BILL_NO = billno;                                                       // 신규 영수증번호
                    OutProfitBd.RGST_DT = currentdate;
                    OutProfitBd.RGSTR_ID = DOPack.UserInfo.USER_CD;
                    OutProfitBd.STATVAL1 = -1;                                                          // 금액을 마이너스 처리함.
                    OutProfitBd.AFRS_STAT_DVCD = "5";                                                   // 업무구분코드   : "5" 
                    OutProfitBd.ROW_STAT_DVCD = "A";                                                    // 행상태구분코드 : 기존
                    OutProfitBd.NEW_ROW_STAT_DVCD = "D";                                                // 행상태구분코드 : 취소

                    if (!OutProfitBd.SavePaOpraBd(ref msg))
                    {
                        throw new Exception("[SavePaOpraBd] 수익코드집계내역 확인[D] :  " + msg);
                    }

                    OutBillBd.PID = ucOrecRegInf11.OutRegInfo.PID;
                    OutBillBd.PT_CMHS_NO = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                    OutBillBd.RCPT_SQNO = rcptsqno;                                                     // 최종 영수증 수납일련번호
                    OutBillBd.NEW_RCPT_RQNO = newrcptsqno;                                              // 신규 영수증 수납일련번호
                    OutBillBd.BILL_NO = billno;                                                         // 신규 영수증번호
                    OutBillBd.RCPT_OCRR_UNIQ_NO = rcptocrruniqno;                                       // 수납발생고유번호
                    OutBillBd.RGST_DT = currentdate;
                    OutBillBd.RGSTR_ID = DOPack.UserInfo.USER_CD;
                    OutBillBd.STATVAL1 = -1;                                                            // 금액을 마이너스 처리함.
                    OutBillBd.STATVAL2 = -1;                                                            // 금액을 마이너스 처리함.
                    OutBillBd.STATVAL3 = -1;                                                            // 금액을 마이너스 처리함.
                    OutBillBd.AFRS_STAT_DVCD = "5";                                                     // 업무구분코드   : "5"
                    OutBillBd.ROW_STAT_DVCD = "A";                                                      // 행상태구분코드 : 기존
                    OutBillBd.NEW_ROW_STAT_DVCD = "D";                                                  // 행상태구분코드 : 취소

                    if (!OutBillBd.SavePaObilBd(ref msg))
                    {
                        throw new Exception("[SavePaObilBd] 외래영수내역 확인[D] :  " + msg);
                    }

                    OutReceiptBd.PID = ucOrecRegInf11.OutRegInfo.PID;
                    OutReceiptBd.PT_CMHS_NO = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                    OutReceiptBd.RCPT_SQNO = rcptsqno;                                                  //최종 영수증 수납일련번호
                    OutReceiptBd.NEW_RCPT_RQNO = newrcptsqno;                                           //신규 영수증 수납일련번호
                    OutReceiptBd.MDCR_DD = ucOrecRegInf11.OutRegInfo.MDCR_DD;                           // 내원일자
                    OutReceiptBd.RGST_DT = currentdate;
                    OutReceiptBd.RGSTR_ID = DOPack.UserInfo.USER_CD;
                    m_OutReceiptBd.STATVAL1 = -1;                                                       // 금액을 마이너스 처리함.
                    OutReceiptBd.AFRS_STAT_DVCD = "5";                                                  // 업무구분코드   : "5" 
                    OutReceiptBd.ROW_STAT_DVCD = "A";                                                   // 행상태구분코드 : 기존
                    OutReceiptBd.NEW_ROW_STAT_DVCD = "D";                                               // 행상태구분코드 : 취소

                    if (!OutReceiptBd.SavePaOrecBd(ref msg, "D"))
                    {
                        throw new Exception("[SavePaOrecBd] 외래수납처방내역 확인[D] :  " + msg);
                    }

                    //회계연동관련
                    clsPACommon.SaveAccountingPacapema_Uncama(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), OutBillBd.MDCR_DD);

                    OutReceiptBd.PID = ucOrecRegInf11.OutRegInfo.PID;
                    OutReceiptBd.PT_CMHS_NO = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                    OutReceiptBd.ROW_STAT_DVCD = "A";                                                         // 행상태구분코드 : 기존
                    OutReceiptBd.NEW_ROW_STAT_DVCD = "C";                                                     // 행상태구분코드 : 취소

                    if (!OutReceiptBd.UpdateRowStatDvcdOfPaOrecBd(ref msg))
                    {
                        throw new Exception("[UpdateRowStatDvcdOfPaOrecBd] 수납계산처방내역 확인[C] :  " + msg);
                    }

                    OutProfitBd.PID = ucOrecRegInf11.OutRegInfo.PID;
                    OutProfitBd.PT_CMHS_NO = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                    OutProfitBd.ROW_STAT_DVCD = "A";                                                          // 행상태구분코드 : 기존
                    OutProfitBd.NEW_ROW_STAT_DVCD = "C";                                                      // 행상태구분코드 : 취소

                    if (!OutProfitBd.UpdateRowStatDvcdOfPaOpraBd(ref msg))
                    {
                        throw new Exception("[UpdateRowStatDvcdOfPaOpraBd] 수익코드집계내역 확인[C] :  " + msg);
                    }

                    OutBillBd.PID = ucOrecRegInf11.OutRegInfo.PID;
                    OutBillBd.PT_CMHS_NO = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                    OutBillBd.AFRS_STAT_DVCD = "3";                                                           // 업무구분코드   : "3" 외래접수취소
                    OutBillBd.ROW_STAT_DVCD = "A";                                                            // 행상태구분코드 : 기존
                    OutBillBd.NEW_ROW_STAT_DVCD = "C";                                                        // 행상태구분코드 : 취소

                    if (!OutBillBd.UpdateRowStatDvcdOfPaObilBd(ref msg))
                    {
                        throw new Exception("[UpdateRowStatDvcdOfPaObilBd] 외래영수내역 확인[C] :  " + msg);
                    }
                }

                newrcptsqno++;

                /* 기존 발생 수익집계내역의 마이너스 금액을 생성 한다*/
                OutProfitBd.PID = ucOrecRegInf11.OutRegInfo.PID;
                OutProfitBd.PT_CMHS_NO = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                OutProfitBd.RCPT_SQNO = rcptsqno;                                                   //최종 영수증 수납일련번호
                OutProfitBd.NEW_RCPT_RQNO = newrcptsqno;                                            //신규 영수증 수납일련번호
                OutProfitBd.BILL_NO = billno;                                                       // 신규 영수증번호
                OutProfitBd.RGST_DT = currentdate;
                OutProfitBd.RGSTR_ID = DOPack.UserInfo.USER_CD;
                OutProfitBd.STATVAL1 = 1;                                                           // 금액을 마이너스 처리함.
                OutProfitBd.AFRS_STAT_DVCD = "5";                                                   // 업무구분코드   : "5" 
                OutProfitBd.ROW_STAT_DVCD = "C";                                                    // 행상태구분코드 : 기존
                OutProfitBd.NEW_ROW_STAT_DVCD = "A";                                                // 행상태구분코드 : 취소

                if (!OutProfitBd.SavePaOpraBd_Uncl(ref msg))
                {
                    throw new Exception("[SavePaOpraBd] 수익코드집계내역 확인[A] :  " + msg);
                }

                ucObillInf11.BillBd.RCPT_SQNO = newrcptsqno;
                ucObillInf11.BillBd.BILL_NO = billno;
                ucObillInf11.BillBd.RCPT_OCRR_UNIQ_NO = rcptocrruniqno;
                ucObillInf11.BillBd.MDCR_DEPT_CD = ucOrecRegInf11.OutRegInfo.MDCR_DEPT_CD;
                ucObillInf11.BillBd.MDCR_DR_CD = ucOrecRegInf11.OutRegInfo.MDCR_DR_CD;
                ucObillInf11.BillBd.INSN_TYCD = ucOrecRegInf11.OutRegInfo.INSN_TYCD;
                ucObillInf11.BillBd.ASST_TYCD = ucOrecRegInf11.OutRegInfo.ASST_TYCD;
                ucObillInf11.BillBd.ASCT_RGNO_CD = ucOrecRegInf11.OutRegInfo.ASCT_RGNO_CD;
                ucObillInf11.BillBd.RGST_DT = currentdate;

                if (!ucObillInf11.SavePaObilBd_Uncl(ucOrecRegInf11.OutRegInfo.PID
                                                 , ucOrecRegInf11.OutRegInfo.PT_CMHS_NO
                                                 , ucOrecRegInf11.OutRegInfo.CFSC_RGNO_CD
                                                 , cash_rcpt_amt, bnac_rcpt_amt, card_rcpt_amt, uncl_amt
                                                 , ref msg))
                {
                    throw new Exception("[SavePaObilBd] 영수증내역 확인[A]" + msg);
                }

                OutReceiptBd.PID = ucOrecRegInf11.OutRegInfo.PID;
                OutReceiptBd.PT_CMHS_NO = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                OutReceiptBd.RCPT_SQNO = rcptsqno;                                                  //최종 영수증 수납일련번호
                OutReceiptBd.NEW_RCPT_RQNO = newrcptsqno;                                           //신규 영수증 수납일련번호
                OutReceiptBd.MDCR_DD = ucOrecRegInf11.OutRegInfo.MDCR_DD;                           // 내원일자
                OutReceiptBd.RGST_DT = currentdate;
                OutReceiptBd.RGSTR_ID = DOPack.UserInfo.USER_CD;
                m_OutReceiptBd.STATVAL1 = 1;                                                       // 금액을 마이너스 처리함.
                OutReceiptBd.AFRS_STAT_DVCD = "5";                                                  // 업무구분코드   : "5" 
                OutReceiptBd.ROW_STAT_DVCD = "C";                                                   // 행상태구분코드 : 기존
                OutReceiptBd.NEW_ROW_STAT_DVCD = "A";                                               // 행상태구분코드 : 취소

                if (!OutReceiptBd.SavePaOrecBd_Uncl(ref msg, "A"))
                {
                    throw new Exception("[SavePaOrecBd] 외래수납처방내역 확인[A] :  " + msg);
                }

                // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                // 의료급여환자의 경우 승인 내역의 수납일련번호와 수납고유번호를 update한다.
                // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                if (ucOrecRegInf11.OutRegInfo.INSN_TYCD.Length > 0 && ucOrecRegInf11.OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("2"))
                {
                    string pid = ucOrecRegInf11.OutRegInfo.PID;
                    string pt_cmhs_no = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString();

                    // M3
                    if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePANHM3MA_RcptSqno(true , pid, pt_cmhs_no, rcptsqno.ToString(), newrcptsqno.ToString(), rcptocrruniqno)))
                        throw new Exception("의료급여 진료확인번호를 저장하는 중 에러가 발생했습니다.(M3)");

                    // M4
                    if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePANHM3MA_RcptSqno(false, pid, pt_cmhs_no, rcptsqno.ToString(), newrcptsqno.ToString(), rcptocrruniqno)))
                        throw new Exception("의료급여 진료확인번호를 저장하는 중 에러가 발생했습니다.(M4)");
                }

                //카드현금승인내역의 영수정보를 변경한다.
                if (!ucObillInf11.SavePaCapeMa(ref msg))
                {
                    throw new Exception("[SavePaCapeMa] 카드현금승인정보 변경 : " + msg);
                }

                LogService.ErrorLog($"[미수금=>외래수납 전환] PID:{OutReceiptBd.PID}|PT_CMHS_NO:{OutReceiptBd.PT_CMHS_NO}|RCPT_SQNO:{rcptsqno}");

                DBService.CommitTransaction();
                LxMessage.Show("미수입금금액이 외래수납금으로 전환되었습니다.", "전환완료", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                if (DBService.IsTransaction)
                    DBService.RollbackTransaction();

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        #endregion Method

        #region Event : Event Process

        /// <summary>
        /// 단축키사용
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="keyData"></param>
        /// <returns></returns>
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            Keys key = keyData & ~(Keys.Shift | Keys.Control);

            switch (key)
            {
                case Keys.F2:                           // 수납                    
                    if (btnButtonList.IsButtonEnable(ButtonType.Save))
                    {
                        // 2019-08-23 SJH 단축키 사용시에 Control Leave이벤트를 안 타서 일단 이렇게 해 놓자...
                        if (!clsPACheckCommon.CheckSpclDcntAmt(ucObillInf11.txtSpclDcntAmt))
                            return false;

                        SaveBillInfo();
                    }
                    break;

                case Keys.F3:                           // 대기자
                    ShowPatientList();
                    break;

                case Keys.F4:                           // 내역변경
                    if (btnButtonList.IsButtonEnable(ButtonType.Custom1))
                        PopupInsnTypeChange(true);
                    break;

                case Keys.F5:                           // 초기화                    
                    ClearForm();
                    break;

                case Keys.F6:                           // 현금영수증 승인 Screen Open
                    if (!this.ucObillInf11.SystemLocked && btnButtonList.IsButtonEnable(ButtonType.Save))
                        ShowCardCashPermitPopup("02");
                    break;
                /*
            case Keys.F7:                           // 환자 외/입 정보조회(내원내역조회) PopUp


                if (string.IsNullOrWhiteSpace(ucOrecRegInf11.txtPid.Text))
                {
                    ucOrecRegInf11.txtPid.Focus();
                    LxMessage.Show("환자번호가 비어있습니다.\r\n외래/입원 정보를 조회할 환자번호를 먼저 입력해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    break;
                }
                
                using (Lime.BusinessControls.ucfOtptAdmsInfoV popup = new BusinessControls.ucfOtptAdmsInfoV(ucOrecRegInf11.txtPid.Text.Trim()))
                    popup.ShowDialog(this);
                break;
                */
                // 통장입금
                case Keys.F7:
                    if (!this.ucObillInf11.SystemLocked && btnButtonList.IsButtonEnable(ButtonType.Save))
                        ShowCardCashPermitPopup("03");
                    break;

                case Keys.F8:                           // 자격조회 PopUp
                    //SEO-자격조회ShowQualificationInfo();
                    ShowNhisMessage();
                    break;

                case Keys.F9:                           // 신용카드 승인 Screen Open
                    if (!this.ucObillInf11.SystemLocked && btnButtonList.IsButtonEnable(ButtonType.Save))
                        ShowCardCashPermitPopup("01");
                    break;

                case Keys.F10:
                    /* 2018-07-24 SEO 코멘트
                     * F10 키는 MDI에서 메뉴 활성화시 사용되는 듯 함
                     * F10 키를 눌러도 이 이벤트(ProcessCmdKey)에 타지 않음 */
                    break;

                case Keys.F11:                          // 처방변경
                    if (btnButtonList.IsButtonEnable(ButtonType.Custom5))
                        PopupPnpyDvcdChange();
                    break;

                case Keys.F12:                          // 접수정보변경재계산
                    if (btnButtonList.IsButtonEnable(ButtonType.Custom6))
                        ReCalculateRegChange();
                    break;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        void ucOrecRegInf11_PatientSelected(object sender, ucOrecRegInf1.SelectDataEventArgs e)
        {
            string msg = String.Empty;
            switch (e.Condition)
            {
                case "PID":

                    ucOrecRegInf11.OutRegInfo.Load(e.Condition, e.Pid, 0, dteMdcrDd.DateTimeValue.ToString("yyyyMMdd"));

                    if (ucOrecRegInf11.CheckPatientRegistInfo(ref msg) < 0)
                    {
                        DBService.RollbackTransaction();
                        if (StringService.IsNotNull(msg))
                        {
                            LxMessage.Show(msg, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        return;
                    }
                    else
                    {
                        if (StringService.IsNotNull(msg))
                        {
                            LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    ucOrecRegInf11.SetPatientRegInfo();

                    break;
                case "PT_CMHS_NO":
                    ucSameDayRegList1.SelectData(e.Pid, dteMdcrDd.DateTimeValue.ToString("yyyyMMdd"), ucOrecRegInf11.OutRegInfo.MDCR_DEPT_CD);
                    break;
                case "PRSC":    //처방
                    ucOutReceiptBD1.SelectORORDRRT(e.Pid, e.PtCmhsNo);
                    ucOrderHisV1.SelectData(e.Pid, e.PtCmhsNo.ToString());
                    break;
                case "APP":     //예약내역
                    ucOappInf1.SelectData(e.Pid, e.MdcrDd);
                    break;
                case "REG":     //접수내역
                    ucOutReceiptBD1.SelectPAOPATRT(e.Pid);
                    break;
                case "RECPRSC": //수납처방내역
                    ucOutReceiptBD1.m_InsnTycd = ucOrecRegInf11.OutRegInfo.INSN_TYCD;
                    ucOutReceiptBD1.m_AsstTycd = ucOrecRegInf11.OutRegInfo.ASST_TYCD;
                    ucOutReceiptBD1.m_UschAplyCd = ucOrecRegInf11.OutRegInfo.USCH_APLY_CD;
                    ucOutReceiptBD1.SelectPAORECTP(e.Pid, e.PtCmhsNo);
                    ucOutReceiptBD1.SelectPAORECBD(e.Pid, e.PtCmhsNo);
                    break;
                case "PROFIT": //수익별집계내역
                    ucOutReceiptBD1.SelectPAOPRATP(e.Pid, e.PtCmhsNo);

                    if (ConfigService.GetConfigValueDirect("%", "TEST_SJH", "TEST_SJH_21", false))
                    {
                        m_STATVAL1 = 1;
                        m_DtProfit.Reset();
                        DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOPRATP(), ref m_DtProfit, e.Pid, e.PtCmhsNo.ToString());

                        m_DtProfitSum.Reset();
                        DBService.ExecuteDataTable(SQL.PA.Sql.SelectProfiSumForBill(), ref m_DtProfitSum, e.Pid, e.PtCmhsNo.ToString());
                    }
                    else
                    {
                        m_STATVAL1 = 0;
                        OutProfitTp.GetPaOpraTpForSave(e.Pid, e.PtCmhsNo);
                        OutProfitTp.GetPaOpraTpForBill(e.Pid, e.PtCmhsNo);
                    }
                    break;
                case "BILLHIS": // 영수증 History
                    ucOutReceiptBD1.SelectPAOBILBD(e.Pid);
                    SaveActionLog("외래수납", e.Pid);
                    break;
                case "BILL":   //영수정보
                    ucObillInf11.DisplayBillInfo(e.Pid, e.PtCmhsNo, ucOrecRegInf11.OutRegInfo);
                    break;
                case "REMARK":   // 특이사항
                    ucOremInf1.Clear();
                    ucOremInf2.Clear();
                    ucOremInf2.Remark.PID = e.Pid;
                    ucOremInf2.Remark.PT_CMHS_NO = e.PtCmhsNo;
                    ucOremInf2.SetPatientRegRemark();
                    ucOremInf1.PatientInfo.PID = e.Pid;
                    ucOremInf1.SetPatientInfoRemark();
                    break;
                case "ILLNESS":
                    // TODO : 처방내역에서 급여처방이 있는지 확인
                    // TODO : 영수정보에서 청구금액이 있는지 확인
                    ucOdisInf1.m_AsstTycd = ucOrecRegInf11.OutRegInfo.ASST_TYCD;
                    ucOdisInf1.SetPatientIllness(e.Pid, e.PtCmhsNo, ucOutReceiptBD1.m_PayYn, ucObillInf11.BillTp.PAY_CLAM_AMT);
                    // 중증등록내역을 조회한다.
                    ucSpecialInf1.SelectData(e.Pid, e.MdcrDd);
                    break;
                case "SAVEYN":
                    if (!e.Pid.Equals("RECALC"))
                    {
                        LxMessage.Show("미수입금, 청구완료, 급여비급여구분 오류시 수납내역만 확인 가능합니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    m_SaveYn = false;
                    // 버튼리스트
                    // 수납버튼 비활성화
                    EnableSaveReceipt(false);
                    // 내역변경버튼 비활성화
                    btnButtonList.SetButtonEnable(ButtonType.Custom1, false);
                    // 처방변경
                    btnButtonList.SetButtonEnable(ButtonType.Custom5, false);
                    // 접수정보변경재계산
                    btnButtonList.SetButtonEnable(ButtonType.Custom6, true);
                    break;
                case "INSNCHANGE":      // 내역변경
                    PopupInsnTypeChange(false);
                    break;
                case "CHANGEUNCOMABILBD":   // 미수금 외래수납금으로 변경
                    ChangeUnComaBilbd();
                    break;
                case "END":   // 미수금 외래수납금으로 변경

                    if (chkAutoEmr.Checked)
                        CallEmr();

                    // 낮병동 환자인 경우를 체크하자.
                    if (ucOrecRegInf11.OutRegInfo.DY_WARD_YN.Equals("Y"))
                        Lime.BusinessControls.clsCommon.CheckDyWardYnTime_PAOPATRT(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), false);

                    // 보조유형이 V로 시작하는 경우 PAPSDSMA 에 데이터가 존재하는지 확인하자.
                    if (ucOrecRegInf11.OutRegInfo.INSN_TYCD.Length > 0 && (ucOrecRegInf11.OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("1") || ucOrecRegInf11.OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("2")) &&
                        ucOrecRegInf11.OutRegInfo.ASST_TYCD.Length > 0 && ucOrecRegInf11.OutRegInfo.ASST_TYCD.Contains("V") && !ucOrecRegInf11.OutRegInfo.CFSC_RGNO_CD.Contains("V"))
                        LxMessage.ShowError("접수정보에 산정특례기호가 등록되지 않았습니다.\r\n산정특례 기호를 입력해 주세요.\r\n(내역변경에서 수정가능합니다.)");

                    // 2021-08-17 SJH 건강진단결과서 대상자인지 확인하자.
                    CheckMedicalExamResult();

                    // 2021-12-15 SJH 코로나 외래 진료건인 경우 A311 코드가 자동발생되는데, 이 때 [AH313, AH314] 코드가 중복산정 불가하므로, 이를 확인한다.
                    CheckCvdOpt();

                    // 2019-09-18 SJH 자격조회가 켜져 있는지 확인하자.
                    if (ucOrecRegInf11.OutRegInfo.INSN_TYCD.Length > 0 && ucOrecRegInf11.OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("2") &&
                        ucOrecRegInf11.OutRegInfo.ASST_TYCD.Length > 1 && !ucOrecRegInf11.OutRegInfo.ASST_TYCD.Contains("99") && !ucOrecRegInf11.OutRegInfo.ASST_TYCD.Contains("91") &&
                        ConfigService.GetConfigValueInt("NH", "NHIS_TERM", "LOG") >= 60000)
                    {
                        int minute = ConfigService.GetConfigValueInt("NH", "NHIS_TERM", "LOG", 60000) / 60000;
                        minute = minute * -1;

                        DateTime now = DateTime.Now;
                        string fromdt = now.AddMinutes(minute).AddMinutes(-1).ToString("yyyyMMddHHmmss");
                        string todt = now.ToString("yyyyMMddHHmmss");

                        int logCount = DBService.ExecuteInteger(string.Format(@"
    SELECT COUNT(1)
      FROM PANHLGMA
     WHERE RGST_DT BETWEEN '{0}' AND '{1}' 
       AND LOG_DVCD IN ('S', 'L') ", fromdt, todt));

                        if (logCount <= 0)
                            LxMessage.ShowError("자격조회 프로그램이 실행되고 있지 않습니다.\r\n의료급여 환자의 진료확인번호를 승인받기 위해 자격조회가 실행되어 있어야 합니다.");

                        string logMessage = string.Format("logCount:{0} / fromDt:{1} / toDt:{2}", logCount.ToString(), DateTimeService.ConvertDateTime(fromdt).ToString("yyyy-MM-dd HH:mm:ss"), DateTimeService.ConvertDateTime(todt).ToString("yyyy-MM-dd HH:mm:ss"));
                        DBService.ExecuteNonQuery(string.Format(@" INSERT INTO PANHLGMA (RGST_DT, LOG_DVCD, LOG_MESSAGE) VALUES ('{0}', '{1}', '{2}') ", DateTime.Now.ToString("yyyyMMddHHmmss"), "T", logMessage));
                    }

                    break;
            }

            ucObillInf11.BillNoApply();

            // 영수증 미리보기
            if (e.Condition == "SHOW_PREVIEW_RECEIPT")
            {
                this.ShowPreivewReceipt();
            }

        }

        private void CheckCvdOpt()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(ucOrecRegInf11.OutRegInfo.PID))
                    return;

                // 코로나19 외래 진료 환자인지 확인한다.
                var temp = DBService.ExecuteScalar(SQL.Function.FN_PA_READ_PATRTEIF(), ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), "ETC_USE_CNTS_21").ToString();
                if (!temp.Equals("CVD_OPT"))
                    return;

                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAORECTP_CvdOpt(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString()), ref dt))
                    throw new Exception("코로나 외래 진료 내역의 처방을 조회하는 중 오류가 발생했습니다.");

                if (dt.Rows.Count.Equals(0))
                    return;

                string message = "코로나 외래 진료로 접수한 내역 중,\r\n아래 처방은 중복 산정할 수 없으니 확인해 주세요.\r\n\r\n";
                message += string.Join("\r\n", dt.AsEnumerable().Select(r => $"  - {StringService.SubStringByte(r["MEFE_CD"].ToString(), 0, 42)}"));
                LxMessage.ShowInformation(message);
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        private void CheckMedicalExamResult()
        {
            if (string.IsNullOrWhiteSpace(ucOrecRegInf11.OutRegInfo.PID))
                return;

            if (!ucOrecRegInf11.OutRegInfo.CMHS_DVCD.Equals("R"))
                return;

            // 특정처방체크에 존재하는지 확인한다.
            var temp = DBService.ExecuteInteger(SQL.PA.Sql.SelectBISPORMT_MedicalExamResult(ucOrecRegInf11.OutRegInfo.MDCR_DD, "BIL_HCR1"));
            if (temp.Equals(0))
                return;

            string message = "건강진단결과서 대상자입니다.";

            //  paorectp에 대상수가가 아닌 수가가 존재하는지 확인한다.
            DataTable dt = new DataTable();
            if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectBISPORDT_MedicalExamResult(ucOrecRegInf11.OutRegInfo.PID, ucOrecRegInf11.OutRegInfo.PT_CMHS_NO.ToString(), ucOrecRegInf11.OutRegInfo.MDCR_DD, "BIL_HCR1"), ref dt))
            {
                if (dt.Rows.Count > 0)
                {
                    var mefe_cdnm = string.Join("\r\n", dt.AsEnumerable().Select(r => $"  - {StringService.SubStringByteBasic(r["MEFE_CDNM"].ToString(), 0, 40)}").ToList());

                    message += $"\r\n\r\n아래 처방은 대상 수가가 아닌 처방입니다.\r\n처방을 미산정처리하거나, 수가 확인 후 수납해 주세요.\r\n\r\n{mefe_cdnm}";
                }
            }

            LxMessage.ShowInformation(message);
        }

        private void ShowPreivewReceipt()
        {
            // 2019-11-11 SJH 영수증 미리보기
            // 얘는 반드시 맨 마지막에 Call 되어야 함 메시지가 얘를 덮어버리는 경우가 있어서... 
            string tempTabletReceiptAuto = ConfigService.GetConfigValueString("PA", "TABLET_RECEIPT", "AUTO"); //DBService.ExecuteScalar("SELECT CONF_VAL FROM ADCONFDT WHERE SYSTEM_CD = 'PA' AND CONF_TYPE = 'TABLET_RECEIPT' AND CONF_CD = 'AUTO' ");
            if (!tempTabletReceiptAuto.Equals("Y"))
                return;

            ucObillInf11.TempTabletBill();
        }

        void ucSameDayRegList1_PatientSelected(object sender, ucSameDayRegList.SelectDataEventArgs e)
        {
            string msg = String.Empty;

            if (!clsPACommon.CheckCreditPermit("O", ucObillInf11.BillTp.PID, ucObillInf11.BillTp.PT_CMHS_NO.ToString()))
            {
                msg = "신용카드/현금 승인된 자료가 존재합니다.\r\n" +
                      "수납 또는 승인취소를 진행하지 않으면,\r\n마감시 금액이 맞지 않습니다.\r\n\r\n" +
                      "환자를 조회하시겠습니까?";

                if (LxMessage.Show(msg, "환자조회여부", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
                    return;

                ucObillInf11.BillNoApply();
            }

            this.Clear();

            DisplayPateintInfo("SAME", e.Pid, e.PtCmhsNo, dteMdcrDd.DateTimeValue.ToString("yyyyMMdd"));
        }

        void ucOutReceiptBD1_PrscRetrieved(object sender, ucOutReceiptBD.PrscEventArgs e)
        {
            ucOlocInf1.DisplayVisitPlace(e.Dt);
            ucOrecRegInf11.m_QtyZeroYn = e.QtyZeroYn;
            ucOrecRegInf11.m_TbrcSuptTrgtYn = e.TbrcSuptTrgtYn;
            ucOrecRegInf11.m_HpvSameIlnsYn = e.HpvSameIlnsYn;
            ucOrecRegInf11.m_HpvOthrIlnsYn = e.HpvOthrIlnsYn;
            ucOrecRegInf11.m_AllDcPrscDvcd = e.AllDcPrscDvcd;
        }

        /// <summary>
        /// 저장버튼비활성화여부, DRG수가여부
        /// </summary>
        /// <param name="NotSaveYn"></param>
        private void ucOutReceiptBD1_OnNotSave(string CheckDvcd, string NotSaveYn)
        {
            switch (CheckDvcd)
            {
                case "DRGMEFEYN":       // DRG수가여부
                    ucOrecRegInf11.m_DrgMefeYn = NotSaveYn;
                    break;
            }
        }

        /// <summary>
        /// 총진료금액 전달 .. DRG확인
        /// </summary>
        /// <param name="totlmdcramt"></param>
        private void ucObillInf11_OnTotlMdcrAmt(int totlmdcramt)
        {
            ucOrecRegInf11.m_TotlMdcrAmt = totlmdcramt;
        }

        private bool ucOrecRegInf11_OnCreditCheck(string dvcd)
        {
            string msg = String.Empty;

            if (!clsPACommon.CheckCreditPermit("O", ucObillInf11.BillTp.PID, ucObillInf11.BillTp.PT_CMHS_NO.ToString()))
            {
                msg = "신용카드/현금 승인된 자료가 존재합니다.\r\n" +
                      "수납 또는 승인취소를 진행하지 않으면,\r\n마감시 금액이 맞지 않습니다.\r\n\r\n" +
                      "환자를 조회하시겠습니까?";

                if (LxMessage.Show(msg, "환자조회여부", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
                {
                    if (dvcd.Equals("Y"))
                    {
                        ucOrecRegInf11.txtPid.Text = ucObillInf11.BillTp.PID;
                    }

                    return false;
                }

                ucObillInf11.BillNoApply();
            }

            return true;
        }

        private void btnButtonList_ButtonClick(object sender, ButtonClickEventArgs e)
        {
            switch (e.ButtonType)
            {
                case ButtonType.Save:           // 수납(F2)
                    SaveBillInfo();
                    break;

                case ButtonType.Custom7:        // 대기자(F3)
                    ShowPatientList();
                    break;

                case ButtonType.Custom1:        // 내역변경(F4)
                    PopupInsnTypeChange(true);
                    break;

                case ButtonType.Clear:          // 초기화(F5)
                    ClearForm();
                    break;

                case ButtonType.Custom19:       // 특이사항(F7)
                    ViewMemo();
                    break;

                case ButtonType.Custom4:        // 자격조회(F8)
                    //SEO-자격조회ShowQualificationInfo();
                    ShowNhisMessage();
                    break;

                case ButtonType.Custom5:        // 처방변경(F11)
                    PopupPnpyDvcdChange();
                    break;

                case ButtonType.Custom6:        // 접수변경재계산(F12)
                    ReCalculateRegChange();
                    break;

                case ButtonType.Edit:           // 환자인적정보수정
                    ShowPopupPatientInfo();
                    break;

                case ButtonType.Custom8:        // 임시영수증재발행
                    TempPrintBill();
                    break;

                case ButtonType.Custom2:        // 영수증발행
                    RePrintBill();
                    break;

                case ButtonType.Custom3:        // 원외처방전
                    RePrintOutPriscription();
                    break;

                case ButtonType.Custom10:       // EMR 열기
                    CallEmr();
                    break;

                case ButtonType.Custom18:       // 미정산처리
                    NonCmpySave();
                    break;

                case ButtonType.Close:          // 닫기
                    Close();
                    break;
                case ButtonType.Process:        // 제증명추가
                    ShowInputPrsc();
                    break;
            }
        }

        private void ShowInputPrsc()
        {
            try
            {
                string pid = ucOrecRegInf11.OutRegInfo.PID;
                int ptCmhsNo = ucOrecRegInf11.OutRegInfo.PT_CMHS_NO;
                string mdcrDd = ucOrecRegInf11.OutRegInfo.MDCR_DD;

                if (string.IsNullOrWhiteSpace(pid) || ptCmhsNo < 1 || string.IsNullOrWhiteSpace(mdcrDd))
                    return;

                using (popDschRecEntryOrder pop = new popDschRecEntryOrder(pid, ptCmhsNo.ToString(), mdcrDd, "O"))
                {
                    pop.ShowDialog(this);

                    // 저장을 한번이라도 한 경우인지 확인한다.
                    if (!pop.IsSaved)
                        return;

                    // 진료완료가 아닌 경우
                    if (int.Parse(ucOrecRegInf11.OutRegInfo.PT_MDCR_STAT_DVCD) < 5 && clsPACommon.ReturnPrscIssuedCnt(pid, ptCmhsNo, "N", "ALL") >= 1)
                    {
                        // 진료완료로 변경할지 물어본다.
                        if (LxMessage.ShowQuestion("진료완료되지 않은 내역입니다.\r\n진료완료로 변경하시겠습니까?").Equals(DialogResult.Yes))
                        {
                            string errordvcd = string.Empty;
                            string errorcnts = string.Empty;

                            if (!SqlPack.Procedure.PR_PA_PRC_PAOPATRTCH(pid, ptCmhsNo.ToString(), ucOrecRegInf11.OutRegInfo.RCPN_SQNO.ToString(), "PT_MDCR_STAT_DVCD", "5", DOPack.UserInfo.USER_CD, ref errordvcd, ref errorcnts))
                                throw new Exception(string.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));

                            if (!string.IsNullOrWhiteSpace(errordvcd))
                                throw new Exception("오류 내용[PR_PA_PRC_PAOPATRTCH] : [" + errordvcd + "]" + errorcnts);
                        }
                    }

                    Clear();
                    DisplayPateintInfo("WAIT", pid, ptCmhsNo, mdcrDd);
                }
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError("처방적용 중 에러가 발생했습니다.\r\n" + ex.Message + error);
            }
        }

        /// <summary>
        /// 진료일자가 변경되면 접수정보와 수납대기자의 진료일자를 변경한다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void dteMdcrDd_ValueChanged(object sender, EventArgs e)
        {
            ucOrecRegInf11.m_Mdcr_Dd = DateTimeService.ConvertDateTimeToFormatString(dteMdcrDd.DateTime, "yyyyMMdd");
        }

        private void dteMdcrDd_Leave(object sender, EventArgs e)
        {
            ucOrecRegInf11.m_Mdcr_Dd = dteMdcrDd.DateTimeValue.ToString("yyyyMMdd");
            if (ucOutRecWatingList1.Visible == true)
                ucOutRecWatingList1.SetDate(dteMdcrDd.DateTimeValue.ToString("yyyyMMdd"));
        }

        private void dteMdcrDd_AfterCloseUp(object sender, EventArgs e)
        {
            ucOrecRegInf11.m_Mdcr_Dd = dteMdcrDd.DateTimeValue.ToString("yyyyMMdd");
            if (ucOutRecWatingList1.Visible == true)
                ucOutRecWatingList1.SetDate(dteMdcrDd.DateTimeValue.ToString("yyyyMMdd"));
        }

        /// <summary>
        /// 접수정보에서 환자 선택 오류시 초기화한다.
        /// </summary>
        private void ucOrecRegInf11_OnPatientClear()
        {
            this.Clear();
        }

        private void ucfOutReceiptE_Loaded(object sender, EventArgs e)
        {

            // LOAD시 수납대기창 자동열기
            if (ConfigService.GetConfigValueString("PA", "RECEIPT", "WATING", "N").ToString().Equals("N")) return;

            if (ConfigService.GetConfigValueString("PA", "RECEIPT", "POPUP", "N").ToString().Equals("Y"))
                PopUpReceiptWating();   // 대기자 POPUP
            else
            {

                ucOutRecWatingList1.Clear();
                ShowWatingWindow();     // 대기자 FORM에서 열기
            }
        }

        private void ucfOutReceiptE_ScreenClosing(object sender, CancelEventArgs e)
        {
            string msg = String.Empty;

            if (!clsPACommon.CheckCreditPermit("O", ucObillInf11.BillTp.PID, ucObillInf11.BillTp.PT_CMHS_NO.ToString()))
            {
                msg = "신용카드/현금 승인된 자료가 존재합니다.\r\n" +
                      "수납 또는 승인취소를 진행하지 않으면,\r\n마감시 금액이 맞지 않습니다.\r\n\r\n" +
                      "종료하시겠습니까?";

                if (LxMessage.Show(msg, "종료여부", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
                    e.Cancel = true;
            }

            this.SystemLockService.UnLockUser();
        }

        void ucOutRecWatingList1_PatientSelected(object sender, ucOutRecWatingList.clsPatientSelected patientinfo)
        {
            this.SelectData(patientinfo.pid, int.Parse(patientinfo.pt_cmhs_no), patientinfo.mdcr_dd);
        }

        private void SelectData(string pid, int pt_cmhs_no, string mdcr_dd)
        {
            ShowPatientInfoForReceipt(pid, pt_cmhs_no, mdcr_dd);

            ShowPreivewReceipt();
        }

        private void ucOutReceiptBD1_OnPatRegSelected(string pid, string ptcmhsno, string mdcrdd)
        {
            try
            {
                string msg = String.Empty;

                // LOCK 해제
                this.UnLockSystem(ucObillInf11.BillTp.PID, ucObillInf11.BillTp.PT_CMHS_NO.ToString());

                if (!clsPACommon.CheckCreditPermit("O", ucObillInf11.BillTp.PID, ucObillInf11.BillTp.PT_CMHS_NO.ToString()))
                {
                    msg = "신용카드/현금 승인된 자료가 존재합니다.\r\n" +
                          "수납 또는 승인취소를 진행하지 않으면,\r\n마감시 금액이 맞지 않습니다.\r\n\r\n" +
                          "환자를 조회하시겠습니까?";

                    if (LxMessage.Show(msg, "환자조회여부", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
                        return;

                    ucObillInf11.BillNoApply();
                }

                this.Clear();

                DisplayPateintInfo("WAIT", pid, int.Parse(ptcmhsno), mdcrdd);
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        void btnNonPermit_Click(object sender, EventArgs e)
        {
            // 2018-10-15 SEO 의료급여 미승인 환자가 있으면 팝업으로 보여준다.
            clsPACommon.CheckMedicalCarePatientNonePermitNo(this);

            this.SetButtonColor();
        }

        private void BtnNeedRereciept_Click(object sender, EventArgs e)
        {
            // 2020-02-25 SJH 재수납 대상 환자가 있으면 팝업으로 보여준다.
            popNeedReReceipt popup = new popNeedReReceipt();

            try
            {
                popup.ShowDialog(this);
                if (popup.DialogResult != DialogResult.OK)
                    return;

                string pid = popup.PID;
                string pt_cmhs_no = popup.PT_CMHS_NO;

                if (string.IsNullOrWhiteSpace(pid) || string.IsNullOrWhiteSpace(pt_cmhs_no))
                    return;

                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOPATRT_PtNm_MdcrDd(pid, pt_cmhs_no), ref dt) || dt.Rows.Count.Equals(0))
                    throw new Exception(string.Format("선택한 환자의 내원정보를 조회하는 중 에러가 발생했습니다.{0}", dt.Rows.Count.Equals(0) ? "\r\n(환자 내원정보가 존재하지 않습니다.)" : string.Empty));

                if (!LxMessage.ShowQuestion($"{dt.Rows[0]["PT_NM"].ToString()}({pid}) 환자의 수납내역으로 이동합니다.").Equals(DialogResult.Yes))
                    return;

                // 선택한 환자로 수납내역 조회
                this.SelectData(pid, int.Parse(pt_cmhs_no), dt.Rows[0]["MDCR_DD"].ToString());
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
            finally
            {
                if (popup != null)
                    popup.Dispose();

                this.SetButtonColor();
            }
        }

        void btnNotCard_Click(object sender, EventArgs e)
        {
            clsPACommon.CheckNoneCard(this);
        }

        #endregion Event : Event Process

        // 2018-04-26 권재호 외래대기자 수정
        private void tabWating_SelectedTabChanged(object sender, Infragistics.Win.UltraWinTabControl.SelectedTabChangedEventArgs e)
        {
            ShowWatingWindow();
        }

        // 2018-04-26 권재호 외래대기자 수정
        public bool PreFilterMessage(ref System.Windows.Forms.Message m)
        {
            bool rtn = false;

            try
            {
                switch (m.Msg)
                {
                    case WM_MOUSEMOVE:
                        //환자리스트가 보여지고 있을때만 체크
                        if (m_VisibleWating && ucOutRecWatingList1.AutoVisible)
                        {
                            Point pointscreen = System.Windows.Forms.Control.MousePosition;
                            Point pointorigin = PointToScreen(new Point(0, 0));

                            if (m_UseFilter)
                            {
                                //마우스가 환자리스트 영역을 벗어나면 환자리스트를 닫는다.
                                if (pnlWating.Left - 100 > pointscreen.X - pointorigin.X ||
                                    pnlWating.Top - 100 > pointscreen.Y - pointorigin.Y ||
                                    pnlWating.Left + pnlWating.Width + 160 < pointscreen.X - pointorigin.X ||
                                    pnlWating.Top + pnlWating.Height + 100 < pointscreen.Y - pointorigin.Y)
                                {
                                    pnlWating.Width = 28;
                                    pnlWating.Height = pnlBase.Height;
                                    pnlWating.BringToFront();
                                    m_VisibleWating = false;

                                    tabWating.SelectedTab = null;
                                    tabWating.ActiveTab = null;
                                }
                            }
                            else
                            {
                                if (pnlWating.Left <= pointscreen.X - pointorigin.X &&
                                    pnlWating.Top <= pointscreen.Y - pointorigin.Y &&
                                    pnlWating.Left + pnlWating.Width >= pointscreen.X - pointorigin.X &&
                                    pnlWating.Top + pnlWating.Height >= pointscreen.Y - pointorigin.Y)
                                {
                                    m_UseFilter = true;
                                }
                            }
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return rtn;
        }
    }
}