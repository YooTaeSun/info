package web.townsi.com.work.convert.doc;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import web.townsi.com.utils.FileUtil;
import web.townsi.com.utils.Util;

public class ChgLangId {

//	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();
	final static String SITE_WEB_ROOT = "D:\\project_java/workspace/tran01";
	
	
	public static JSONObject JSON_OBJECT = new JSONObject();
	public static String strOfLine = "<rEaDlInE>";
	
	public static List<HashMap> process() throws Exception {

		makeLangMap();
		List<HashMap> resultList = convertLang();
		return resultList;
	}


	private static void makeLangMap() throws FileNotFoundException, IOException, ParseException {
		
		String langRootPath = SITE_WEB_ROOT + "/test/result";
		
		String path = "";
		Reader reader = null;
		JSONParser parser = null;
		path = langRootPath + "/all.json";
		parser = new JSONParser();
		reader = new FileReader(path);
		JSON_OBJECT = (JSONObject) parser.parse(reader);
		System.out.println("path all.json >>" + path);
	}

	private static List<HashMap> convertLang() throws FileNotFoundException {
		
		List<HashMap> resultList = new ArrayList<HashMap>();
		File folder;
		File[] listOfFiles;
		String content;
		String root = SITE_WEB_ROOT + "/lang/from";
		String result = SITE_WEB_ROOT + "/lang/to/";

		folder = new File(root);
		listOfFiles = folder.listFiles();
		content = "";

		for (File file : listOfFiles) {
			if (file.isFile()) {
				String fileNm = file.getName();
				String rfullPath = file.getPath();
				String wfullPath = "";
				wfullPath = result + fileNm;
				String readContent = FileUtil.readFile(rfullPath);
				
				content =  processDetail(readContent, wfullPath);
				
				HashMap dataMap = new HashMap();
				dataMap.put("fileNm", fileNm);
				dataMap.put("fullPath", wfullPath);
				dataMap.put("str", content);
				resultList.add(dataMap);
				System.out.println("wfullPath >> " + wfullPath);
			}
		}
		return resultList;
	}
	
	private static String processDetail(String content, String wfullPath) throws FileNotFoundException {
		
		content = ChgLangId.convertAllLine(JSON_OBJECT, content);
		File dic = new File(wfullPath.substring(0, wfullPath.lastIndexOf("/")));
		String dirPath = dic.getPath();
		if (dic.exists()) {
			System.out.println(dirPath + " 디렉토리 있음");
		} else {
			dic.mkdirs();
			System.out.println(dirPath + " 디렉토리 생성");
		}
		
		String reusltStr = FileUtil.writeFile(wfullPath, content);
		return reusltStr;
	}
	
	public static String convertAllLine(JSONObject jsonObject, String content) {
//		getUseLang(jsonObject, content);
		
		content = content.replaceAll("\r\n", strOfLine);
		String reContent =  chgGetSetObj2(jsonObject, content);
		content = reContent.replaceAll(strOfLine, "\r\n");
//		System.out.println(content);
		return content;
	}
	
	public static String chgGetSetObj2(JSONObject jsonObject, String content) {
		
		JSONObject val = null;
		String idNew = "";
		String key = "";
		String ko = "";
		String en = "";
	    for (Object keyObj : jsonObject.keySet()) {
	    	key = (String)keyObj;
	    	val = (JSONObject) jsonObject.get(key);
	    	idNew = (String) val.get("id_new");
	    	ko = (String) val.get("한글");
	    	en = (String) val.get("영어");
	        try {
	        	content = Util.replaceOld(content, idNew, key);	        	
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("e jsonObject key 이상 >> " + e);
			}
	    }
		return content;
	}



	
	public static String getUseLang(JSONObject jsonObject, String content) {
		JSONObject val = null;
		String idNew = "";
		String key = "";
		String ko = "";
		String en = "";
		String[] str_araay = content.split("\\r\\n");
		List<String> list = Arrays.asList(str_araay);
		
		
		String line = "";
		for (int i = 0; i < list.size(); i++) {
			line = list.get(i);
			
		    for (Object keyObj : jsonObject.keySet()) {
		    	key = (String)keyObj;
		    	val = (JSONObject) jsonObject.get(key);
		    	idNew = (String) val.get("id_new");
		    	ko = (String) val.get("한글");
		    	en = (String) val.get("영어");
		        try {
		        	content = Util.replaceOld(content, idNew, key);
				} catch (Exception e) {
					// TODO: handle exception
					System.out.println("e jsonObject key 이상 >> " + e);
				}
		    }
			
		}
		

		return content;
	}	
	
	
	public static void main(String[] args) throws Exception {
		
		System.out.println("=================	make_lang_file start 	======================");
		ChgLangId.process();
		System.out.println("=================	make_lang_file end 	======================");		
	}
}
