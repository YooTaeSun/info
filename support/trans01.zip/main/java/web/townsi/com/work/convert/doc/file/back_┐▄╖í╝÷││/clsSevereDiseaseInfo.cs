//********************************************************************************
// Class 명 : clsSevereDiseaseInfo
// 역    할 : 중증질환관리
// 작 성 자 : PGH
// 작 성 일 : 2017-09-07
//********************************************************************************
// 수정내역 : 2017-11-06 [Region] Save Input Data 의 StringService.SubStringByte 부분 시작 인덱스를 1만큼 모두 뺐음.
//********************************************************************************
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lime.Framework;
using Lime.Framework.BusinessService;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;


namespace Lime.PA
{
    public class clsSevereDiseaseInfo
    {
        #region Define Variable Member
        private string m_PID = string.Empty;    //환자등록번호                     VARCHAR2(10)
        private string m_SEVR_DVCD = string.Empty;    //중증구분코드              VARCHAR2(2)
        private string m_APLY_DD = string.Empty;    //적용일자                  VARCHAR2(8)
        private string m_VALD_DD = string.Empty;    //유효일자                  VARCHAR2(8)
        private string m_VCODE_CD = string.Empty;    //특정기호코드              VARCHAR2(10)
        private string m_SEVR_NO = string.Empty;    //중증번호                  VARCHAR2(15)
        private string m_ILNS_CD = string.Empty;    //상병코드                  VARCHAR2(10)
        private int m_ILNS_SQNO = 0;               //상병일련번호              NUMBER(3, 0)
        private string m_OP_DD = string.Empty;    //수술일자                  VARCHAR2(8)
        private string m_DNTR_RCPR_INSTNO = string.Empty;    //틀니요양기관기호          VARCHAR2(10)
        private string m_DNTR_APLY_DD = string.Empty;    //틀니적용일자              VARCHAR2(8)
        private string m_DNTR_END_DD = string.Empty;    //틀니종료일자              VARCHAR2(8)
        private string m_RRNS_APLY_DD = string.Empty;    //희귀적용일자              VARCHAR2(8)
        private string m_INSN_TYCD = string.Empty;    //보험유형코드              VARCHAR2(10)
        private string m_ILNS_CD_1 = string.Empty;    //상병코드첫째              VARCHAR2(10)
        private string m_ILNS_CD_2 = string.Empty;    //상병코드둘째              VARCHAR2(10)
        private string m_ILNS_CD_3 = string.Empty;    //상병코드셋째              VARCHAR2(10)
        private string m_ILNS_CD_4 = string.Empty;    //상병코드넷째              VARCHAR2(10)
        private string m_ILNS_CD_5 = string.Empty;    //상병코드다섯째            VARCHAR2(10)
        private string m_ETC_USE_CNTS_1 = string.Empty;    //기타사용내용첫째          VARCHAR2(10)
        private string m_ETC_USE_CNTS_2 = string.Empty;    //기타사용내용둘째          VARCHAR2(10)
        private string m_ETC_USE_CNTS_3 = string.Empty;    //기타사용내용셋째          VARCHAR2(10)
        private string m_RGST_DT = string.Empty;    //등록일시                  VARCHAR2(14)
        private string m_RGSTR_ID = string.Empty;    //등록자ID                  VARCHAR2(10)
        private string m_UPDT_DT = string.Empty;    //수정일시                  VARCHAR2(14)
        private string m_UPDTR_ID = string.Empty;    //수정자ID                  VARCHAR2(10)
        private string m_OLD_SEVR_DVCD = string.Empty;
        private string m_OLD_APLY_DD = string.Empty;
        private string m_OLD_PID = string.Empty;

        private string m_ilnsCd = string.Empty;
        private string m_opDd = string.Empty;
        #endregion

        #region Define Member Property
        public string PID { get { return m_PID; } set { m_PID = value; } }
        public string SEVR_DVCD { get { return m_SEVR_DVCD; } set { m_SEVR_DVCD = value; } }
        public string APLY_DD { get { return m_APLY_DD; } set { m_APLY_DD = value; } }
        public string VALD_DD { get { return m_VALD_DD; } set { m_VALD_DD = value; } }
        public string VCODE_CD { get { return m_VCODE_CD; } set { m_VCODE_CD = value; } }
        public string SEVR_NO { get { return m_SEVR_NO; } set { m_SEVR_NO = value; } }
        public string ILNS_CD { get { return m_ILNS_CD; } set { m_ILNS_CD = value; } }
        public int ILNS_SQNO { get { return m_ILNS_SQNO; } set { m_ILNS_SQNO = value; } }
        public string OP_DD { get { return m_OP_DD; } set { m_OP_DD = value; } }
        public string DNTR_RCPR_INSTNO { get { return m_DNTR_RCPR_INSTNO; } set { m_DNTR_RCPR_INSTNO = value; } }
        public string DNTR_APLY_DD { get { return m_DNTR_APLY_DD; } set { m_DNTR_APLY_DD = value; } }
        public string DNTR_END_DD { get { return m_DNTR_END_DD; } set { m_DNTR_END_DD = value; } }
        public string RRNS_APLY_DD { get { return m_RRNS_APLY_DD; } set { m_RRNS_APLY_DD = value; } }
        public string INSN_TYCD { get { return m_INSN_TYCD; } set { m_INSN_TYCD = value; } }
        public string ILNS_CD_1 { get { return m_ILNS_CD_1; } set { m_ILNS_CD_1 = value; } }
        public string ILNS_CD_2 { get { return m_ILNS_CD_2; } set { m_ILNS_CD_2 = value; } }
        public string ILNS_CD_3 { get { return m_ILNS_CD_3; } set { m_ILNS_CD_3 = value; } }
        public string ILNS_CD_4 { get { return m_ILNS_CD_4; } set { m_ILNS_CD_4 = value; } }
        public string ILNS_CD_5 { get { return m_ILNS_CD_5; } set { m_ILNS_CD_5 = value; } }
        public string ETC_USE_CNTS_1 { get { return m_ETC_USE_CNTS_1; } set { m_ETC_USE_CNTS_1 = value; } }
        public string ETC_USE_CNTS_2 { get { return m_ETC_USE_CNTS_2; } set { m_ETC_USE_CNTS_2 = value; } }
        public string ETC_USE_CNTS_3 { get { return m_ETC_USE_CNTS_3; } set { m_ETC_USE_CNTS_3 = value; } }
        public string RGST_DT { get { return m_RGST_DT; } set { m_RGST_DT = value; } }
        public string RGSTR_ID { get { return m_RGSTR_ID; } set { m_RGSTR_ID = value; } }
        public string UPDT_DT { get { return m_UPDT_DT; } set { m_UPDT_DT = value; } }
        public string UPDTR_ID { get { return m_UPDTR_ID; } set { m_UPDTR_ID = value; } }
        public string OLD_SEVR_DVCD { get { return m_OLD_SEVR_DVCD; } set { m_OLD_SEVR_DVCD = value; } }
        public string OLD_APLY_DD { get { return m_OLD_APLY_DD; } set { m_OLD_APLY_DD = value; } }
        public string OLD_PID { get { return m_OLD_PID; } set { m_OLD_PID = value; } }

        #endregion

        #region Construction

        public clsSevereDiseaseInfo()
        {
            this.Clear(true);
        }

        #endregion

        #region Method : Clear

        public void Clear(bool isClearPID)
        {
            if (isClearPID)
                m_PID = string.Empty;

            m_SEVR_DVCD = string.Empty;
            m_APLY_DD = string.Empty;
            m_VALD_DD = string.Empty;
            m_VCODE_CD = string.Empty;
            m_SEVR_NO = string.Empty;
            m_ILNS_CD = string.Empty;
            m_ILNS_SQNO = 0;
            m_OP_DD = string.Empty;
            m_DNTR_RCPR_INSTNO = string.Empty;
            m_DNTR_APLY_DD = string.Empty;
            m_DNTR_END_DD = string.Empty;
            m_RRNS_APLY_DD = string.Empty;
            m_INSN_TYCD = string.Empty;
            m_ILNS_CD_1 = string.Empty;
            m_ILNS_CD_2 = string.Empty;
            m_ILNS_CD_3 = string.Empty;
            m_ILNS_CD_4 = string.Empty;
            m_ILNS_CD_5 = string.Empty;
            m_ETC_USE_CNTS_1 = string.Empty;
            m_ETC_USE_CNTS_2 = string.Empty;
            m_ETC_USE_CNTS_3 = string.Empty;
            m_RGST_DT = string.Empty;
            m_RGSTR_ID = string.Empty;
            m_UPDT_DT = string.Empty;
            m_UPDTR_ID = string.Empty;
        }

        #endregion

        #region Method : Public Method

        public bool SaveSevereDiseaseInfo(clsNhisM2 m2, ref string outmsg)
        {
            try
            {
                DBService.BeginTransaction();

                //TO-DO : 암중증정보13,14,15,16 등 만들어야함. (w_acc01q_nhicm2 적용버튼)

                // [ 암중증정보 등록 ]
                if (StringService.IsNotNull(m2.disRegPrson4) && m2.disRegPrson4.Length > 2)
                {
                    if (this.SaveDisRegPrson4(m2.disRegPrson4, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }

                // [ 산정특례(희귀)정보 등록 ]

                if (StringService.IsNotNull(m2.disRegPrson2) && m2.disRegPrson2.Length > 2)
                {
                    if (this.SaveDisRegPrson2(m2.disRegPrson1, m2.disRegPrson2, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }

                // [ 산정특례(화상)정보 등록 ]

                if (StringService.IsNotNull(m2.disRegPrson5) && m2.disRegPrson5.Length > 2)
                {
                    if (this.SaveDisRegPrson5(m2.disRegPrson5, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }

                // [ 당뇨병환자 등록 ]

                if (StringService.IsNotNull(m2.disRegPrson6) && m2.disRegPrson6.Length > 2)
                {
                    if (this.SaveDisRegPrson6(m2.disRegPrson6, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }

                // [ 동일성분의약품제한자 등록 ]

                if (StringService.IsNotNull(m2.disRegPrson7) && m2.disRegPrson7.Length > 2)
                {
                    if (this.SaveDisRegPrson7(m2.disRegPrson7, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }

                // [ 노인틀니대상자(상악) 등록 ]

                if (StringService.IsNotNull(m2.dentTop) && m2.dentTop.Length > 2)
                {
                    if (this.SaveDent("8", m2.dentTop, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }

                // [ 노인틀니대상자(하악) 등록 ]

                if (StringService.IsNotNull(m2.dentBottom) && m2.dentBottom.Length > 2)
                {
                    if (this.SaveDent("9", m2.dentBottom, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }

                // [ 임플란트1 등록 ]

                if (StringService.IsNotNull(m2.dentImpl1) && m2.dentImpl1.Length > 2)
                {
                    if (this.SaveDentImpl("A", m2.dentImpl1, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }

                // [ 임플란트2 등록 ]

                if (StringService.IsNotNull(m2.dentImpl2) && m2.dentImpl2.Length > 2)
                {
                    if (this.SaveDentImpl("B", m2.dentImpl2, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }

                // [ 산정특례(결핵)정보 등록 ]

                if (StringService.IsNotNull(m2.disRegPrson9) && m2.disRegPrson9.Length > 2)
                {
                    if (this.SaveDisRegPrson9(m2.disRegPrson9, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }

                // [ 요양기관별 산정특례(결핵)정보 등록 ]

                if (StringService.IsNotNull(m2.disRegPrson12) && m2.disRegPrson12.Length > 2)
                {
                    if (this.SaveDisRegPrson12(m2.disRegPrson12, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }

                // [ 조산아 및 저체중출생아 등록 ]

                if (StringService.IsNotNull(m2.preInfant) && m2.preInfant.Length > 2)
                {
                    if (this.SavePreInFant(m2.preInfant, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }


                // [ 산정특례(중증치매대상자)정보 등록 ]

                if (StringService.IsNotNull(m2.disRegPrson14) && m2.disRegPrson14.Length > 2)
                {
                    if (this.SaveDisRegPrson14(m2.disRegPrson14, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }


                if (StringService.IsNotNull(m2.disRegPrson10) && m2.disRegPrson10.Length > 2)
                {
                    if (this.SaveDisRegPrson10(m2.disRegPrson10, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }

                if (StringService.IsNotNull(m2.disRegPrson11) && m2.disRegPrson11.Length > 2)
                {
                    if (this.SaveDisRegPrson11(m2.disRegPrson11, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }

                if (StringService.IsNotNull(m2.disRegPrson18) && m2.disRegPrson18.Length > 2)
                {
                    if (this.SaveDisRegPrson18(m2.disRegPrson18, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }

                if (StringService.IsNotNull(m2.disRegPrson19) && m2.disRegPrson19.Length > 2)
                {
                    if (this.SaveDisRegPrson19(m2.disRegPrson19, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }

                if (StringService.IsNotNull(m2.disRegPrson20) && m2.disRegPrson20.Length > 2)
                {
                    if (this.SaveDisRegPrson20(m2.disRegPrson20, out outmsg) < 0)
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    else
                        this.Clear(false);
                }

                DBService.CommitTransaction();
            }
            catch (Exception ex)
            {
                if (DBService.IsTransaction)
                    DBService.RollbackTransaction();

                outmsg = "중증정보[산정특례정보] 저장 중 오류를 발생했습니다.\r\n " +
                         "Method :  [clsSevereDiseaseInfo -> SaveSevereDiseaseInfo] \r\n " +
                         "오류 메시지 : " + ex.Message;
                return false;
            }

            return true;
        }

        public bool InsertPaPsdsMa()
        {
            try
            {
                DBService.ReplaceSingleQuotationMark = false;

                string countQuery = DBService.ExecuteScalar("SELECT COUNT(*) FROM PAPSDSMA WHERE PID = '{0}' AND SEVR_DVCD = '{1}' AND APLY_DD = '{2}'", this.PID
                                                                                                                                                       , this.SEVR_DVCD
                                                                                                                                                       , this.APLY_DD
                                                                                                                                                       ).ToString();
                //DB에 없는 자료만 INSERT.
                if (countQuery.Equals("0"))
                {
                    if (string.IsNullOrWhiteSpace(this.PID))
                        return false;

                    if (!DBService.ExecuteNonQuery(SQL.PA.BaseSql.Insert.PAPSDSMA(), this.PID
                                                                                   , this.SEVR_DVCD
                                                                                   , this.APLY_DD
                                                                                   , this.VALD_DD
                                                                                   , this.VCODE_CD
                                                                                   , this.SEVR_NO
                                                                                   , this.ILNS_CD
                                                                                   , this.ILNS_SQNO.ToString()
                                                                                   , this.OP_DD
                                                                                   , this.DNTR_RCPR_INSTNO
                                                                                   , this.DNTR_APLY_DD
                                                                                   , this.DNTR_END_DD
                                                                                   , this.RRNS_APLY_DD
                                                                                   , this.INSN_TYCD
                                                                                   , this.ILNS_CD_1
                                                                                   , this.ILNS_CD_2
                                                                                   , this.ILNS_CD_3
                                                                                   , this.ILNS_CD_4
                                                                                   , this.ILNS_CD_5
                                                                                   , this.ETC_USE_CNTS_1
                                                                                   , this.ETC_USE_CNTS_2
                                                                                   , this.ETC_USE_CNTS_3
                                                                                   , this.RGST_DT
                                                                                   , this.RGSTR_ID
                                                                                   , this.UPDT_DT
                                                                                   , this.UPDTR_ID))
                    {
                        return false;
                    }
                    return true;
                }
                else
                    return true;
            }
            finally
            {
                DBService.ReplaceSingleQuotationMark = true;
            }
        }

        public bool UpdatePaPsdsMa()
        {
            if (!DBService.ExecuteNonQuery(SQL.PA.BaseSql.Update.PAPSDSMA(), this.OLD_PID
                                                                         , this.OLD_SEVR_DVCD
                                                                         , this.OLD_APLY_DD
                                                                         , this.SEVR_DVCD
                                                                         , this.APLY_DD
                                                                         , this.VALD_DD
                                                                         , this.VCODE_CD
                                                                         , this.SEVR_NO
                                                                         , this.ILNS_CD
                                                                         , this.ILNS_SQNO.ToString()
                                                                         , this.OP_DD
                                                                         , this.DNTR_RCPR_INSTNO
                                                                         , this.DNTR_APLY_DD
                                                                         , this.DNTR_END_DD
                                                                         , this.RRNS_APLY_DD
                                                                         , this.INSN_TYCD
                                                                         , this.ILNS_CD_1
                                                                         , this.ILNS_CD_2
                                                                         , this.ILNS_CD_3
                                                                         , this.ILNS_CD_4
                                                                         , this.ILNS_CD_5
                                                                         , this.ETC_USE_CNTS_1
                                                                         , this.ETC_USE_CNTS_2
                                                                         , this.ETC_USE_CNTS_3
                                                                         , this.UPDT_DT
                                                                         , this.UPDTR_ID))
            {
                return false;
            }
            return true;

        }

        #endregion Method : Public Method

        #region Method : Private Method

        private int SelectPAPSDSMA()
        {
            try
            {
                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAPSDSMA(m_PID, m_SEVR_DVCD, m_APLY_DD), ref dt))
                    throw new Exception("중증정보 조회 중 에러가 발생했습니다.");

                if (dt.Rows.Count.Equals(0))
                { 
                    LogService.DebugLog(String.Format("Patient not found.({0})", m_PID));
                    return 0;
                }

                DataRow row = dt.Rows[0];

                /*수정 - PMK(2018.05.08)
                    *OLD에 관련된 정보가 세팅이 안되어 Update가 일단 되지 않았음 - 추가
                    *자격조회한 내용으로 Update가 되기 위해서는 서버에서 가져온 정보로 변수가 세팅되어야 하는데 이미 저장되어 있는걸로 계속 세팅되어 update가 되지 않았음
                */
                //기존에 가지고 있던정보
                m_OLD_PID = row["PID"].ToString();
                m_OLD_SEVR_DVCD = row["SEVR_DVCD"].ToString();
                m_OLD_APLY_DD = row["APLY_DD"].ToString();

                //신규
                m_PID = row["PID"].ToString();
                m_SEVR_DVCD = row["SEVR_DVCD"].ToString();
                m_APLY_DD = row["APLY_DD"].ToString();
                m_VALD_DD = m_VALD_DD;         //row["VALD_DD"].ToString();
                m_VCODE_CD = m_VCODE_CD;        //row["VCODE_CD"].ToString();
                m_SEVR_NO = m_SEVR_NO;         //row["SEVR_NO"].ToString();
                m_ILNS_CD = row["ILNS_CD"].ToString();

                // 조산아는 상병 가져오지 않으므로 상병일련번호를 0으로 세팅한다.
                m_ILNS_SQNO = StringService.IsNull(row["ILNS_SQNO"].ToString()) ? 0 : int.Parse(row["ILNS_SQNO"].ToString());
                m_OP_DD = row["OP_DD"].ToString();
                m_DNTR_RCPR_INSTNO = row["DNTR_RCPR_INSTNO"].ToString();
                m_DNTR_APLY_DD = row["DNTR_APLY_DD"].ToString();
                m_DNTR_END_DD = row["DNTR_END_DD"].ToString();
                m_RRNS_APLY_DD = row["RRNS_APLY_DD"].ToString();
                m_INSN_TYCD = row["INSN_TYCD"].ToString();
                m_ILNS_CD_1 = row["ILNS_CD_1"].ToString();
                m_ILNS_CD_2 = row["ILNS_CD_2"].ToString();
                m_ILNS_CD_3 = row["ILNS_CD_3"].ToString();
                m_ILNS_CD_4 = row["ILNS_CD_4"].ToString();
                m_ILNS_CD_5 = row["ILNS_CD_5"].ToString();
                m_ETC_USE_CNTS_1 = row["ETC_USE_CNTS_1"].ToString();
                m_ETC_USE_CNTS_2 = row["ETC_USE_CNTS_2"].ToString();
                m_ETC_USE_CNTS_3 = row["ETC_USE_CNTS_3"].ToString();
                m_RGST_DT = row["RGST_DT"].ToString();
                m_RGSTR_ID = row["RGSTR_ID"].ToString();
                m_UPDT_DT = row["UPDT_DT"].ToString();
                m_UPDTR_ID = row["UPDTR_ID"].ToString();

                return dt.Rows.Count;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return -1;
            }
        }

        private void TrimData()
        {
            PID = PID.Trim();
            SEVR_DVCD = SEVR_DVCD.Trim();
            APLY_DD = APLY_DD.Trim();
            VALD_DD = VALD_DD.Trim();
            VCODE_CD = VCODE_CD.Trim();
            SEVR_NO = SEVR_NO.Trim();
            ILNS_CD = ILNS_CD.Trim();

            // 조산아는 상병 가져오지 않으므로 상병일련번호를 0으로 세팅한다.
            ILNS_SQNO = SEVR_DVCD.Equals("P") ? 0 : int.Parse(ILNS_SQNO.ToString().Trim());
            OP_DD = OP_DD.Trim();
            DNTR_RCPR_INSTNO = DNTR_RCPR_INSTNO.Trim();
            DNTR_APLY_DD = DNTR_APLY_DD.Trim();
            DNTR_END_DD = DNTR_END_DD.Trim();
            RRNS_APLY_DD = RRNS_APLY_DD.Trim();
            INSN_TYCD = INSN_TYCD.Trim();
            ILNS_CD_1 = ILNS_CD_1.Trim();
            ILNS_CD_2 = ILNS_CD_2.Trim();
            ILNS_CD_3 = ILNS_CD_3.Trim();
            ILNS_CD_4 = ILNS_CD_4.Trim();
            ILNS_CD_5 = ILNS_CD_5.Trim();
            ETC_USE_CNTS_1 = ETC_USE_CNTS_1.Trim();
            ETC_USE_CNTS_2 = ETC_USE_CNTS_2.Trim();
            ETC_USE_CNTS_3 = ETC_USE_CNTS_3.Trim();
            RGST_DT = RGST_DT.Trim();
            RGSTR_ID = RGSTR_ID.Trim();
            UPDT_DT = UPDT_DT.Trim();
            UPDTR_ID = UPDTR_ID.Trim();
            OLD_SEVR_DVCD = OLD_SEVR_DVCD.Trim();
            OLD_APLY_DD = OLD_APLY_DD.Trim();
            OLD_PID = OLD_PID.Trim();
        }

        /// <summary>
        /// 산정특례(암)등록대상자
        /// </summary>
        /// <param name="disregprson4">특정기호(4)+등록번호(15)+등록일(8)+종료일(8)+상병기호(10)+상병일련번호(2)+등록구분(1)</param>
        /// <param name="outmsg"></param>
        /// <returns></returns>
        private int SaveDisRegPrson4(string disregprson4, out string outmsg)
        {
            int result = 0;
            string msg = string.Empty;
            m_VCODE_CD = StringService.SubStringByte(disregprson4, 0, 4);      // 특정기호코드
            m_SEVR_NO = StringService.SubStringByte(disregprson4, 4, 15);      // 중증등록번호
            m_APLY_DD = StringService.SubStringByte(disregprson4, 19, 8);      // 적용일자
            m_VALD_DD = StringService.SubStringByte(disregprson4, 27, 8);      // 종료일자

            switch (m_VCODE_CD)
            {
                case "V191":
                    m_SEVR_DVCD = "3";
                    break;
                case "V192":
                    m_SEVR_DVCD = "2";
                    break;
                case "V193":
                    m_SEVR_DVCD = "1";
                    break;
            }

            m_UPDT_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_UPDTR_ID = DOPack.UserInfo.USER_CD;
            m_RGST_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_RGSTR_ID = DOPack.UserInfo.USER_CD;

            TrimData();
            result = SavePaPsdsMa();

            if (result < 0)
            {
                outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                return result;
            }

            outmsg = msg;
            return result;
        }

        /// <summary>
        /// 산정특례(희귀)등록대상자
        /// </summary>
        /// <param name="disregprson1">희귀난치대상자 : 특정기호(4)+승인일(8)+종료일(8)</param>
        /// <param name="disregprson2">산정특례(희귀)등록대상자 : 특정기호(4)+등록번호(15)+등록일(8)+종료일(8)+상병코드(10)+ 상병일련번호(2)</param>
        /// <param name="outmsg"></param>
        /// <returns></returns>
        private int SaveDisRegPrson2(string disregprson1, string disregprson2, out string outmsg)
        {
            int result = 0;
            string msg = String.Empty;
            if (StringService.SubStringByte(disregprson1, 0, 1) == "H")
            {
                m_VCODE_CD = StringService.SubStringByte(disregprson1, 0, 4);       // 특정기호코드
                m_RRNS_APLY_DD = StringService.SubStringByte(disregprson1, 4, 8);       // 희귀적용일자
            }
            else
            {
                m_VCODE_CD = StringService.SubStringByte(disregprson2, 0, 4);       // 특정기호코드
                m_RRNS_APLY_DD = String.Empty;                                      // 희귀적용일자
            }

            m_SEVR_NO = StringService.SubStringByte(disregprson2, 4, 15);                // 중증등록번호
            m_APLY_DD = StringService.SubStringByte(disregprson2, 19, 8);                // 적용일자
            m_VALD_DD = StringService.SubStringByte(disregprson2, 27, 8);                // 종료일자
            m_ilnsCd = StringService.SubStringByte(disregprson2, 35, 10);                // 상병코드
            int.TryParse(StringService.SubStringByte(disregprson2, 45, 2), out m_ILNS_SQNO);                // 상병일련번호

            m_SEVR_DVCD = "4";                                                       // 중증구분코드

            m_UPDT_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_UPDTR_ID = DOPack.UserInfo.USER_CD;
            m_RGST_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_RGSTR_ID = DOPack.UserInfo.USER_CD;

            TrimData();
            result = SavePaPsdsMa();

            if (result < 0)
            {
                outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                return result;
            }

            // 결핵
            if (StringService.SubStringByte(m_SEVR_NO, 0, 2) == "07")
            {
                m_SEVR_DVCD = "C";

                result = SavePaPsdsMa();

                if (result < 0)
                {
                    outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                    return result;
                }
            }
            outmsg = msg;
            return result;
        }

        /// <summary>
        /// 산정특례(화상)등록대상자
        /// </summary>
        /// <param name="disregprson5">특정기호(4)+등록번호(15)+등록일(8)+종료일(8)</param>
        /// <param name="outmsg"></param>
        /// <returns></returns>
        private int SaveDisRegPrson5(string disregprson5, out string outmsg)
        {
            int result = 0;
            string msg = string.Empty;

            m_VCODE_CD = StringService.SubStringByte(disregprson5, 0, 4);      // 특정기호코드
            m_SEVR_NO = StringService.SubStringByte(disregprson5, 4, 15);      // 중증등록번호
            m_APLY_DD = StringService.SubStringByte(disregprson5, 19, 8);      // 적용일자
            m_VALD_DD = StringService.SubStringByte(disregprson5, 27, 8);      // 종료일자
            m_SEVR_DVCD = "5";                                                 // 중증구분코드
            m_UPDT_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_UPDTR_ID = DOPack.UserInfo.USER_CD;
            m_RGST_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_RGSTR_ID = DOPack.UserInfo.USER_CD;

            TrimData();

            result = SavePaPsdsMa();

            if (result < 0)
            {
                outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                return result;
            }

            outmsg = msg;
            return result;
        }

        /// <summary>
        /// 당뇨병 요양비 대상자 등록일
        /// </summary>
        /// <param name="disregprson6">등록일(8)</param>
        /// <param name="outmsg"></param>
        /// <returns></returns>
        private int SaveDisRegPrson6(string disregprson6, out string outmsg)
        {
            int result = 0;
            string msg = string.Empty;
            //m_VCODE_CD = StringService.SubString(disregprson6, 0, 4);     // 특정기호코드
            //m_SEVR_NO = StringService.SubString(disregprson6, 4, 15);     // 중증등록번호
            m_APLY_DD = StringService.SubStringByte(disregprson6, 0, 8);        // 적용일자
            m_VALD_DD = "29991231";                                         // 종료일자

            m_SEVR_DVCD = "6";                                             // 중증구분코드

            m_UPDT_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_UPDTR_ID = DOPack.UserInfo.USER_CD;
            m_RGST_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_RGSTR_ID = DOPack.UserInfo.USER_CD;

            TrimData();
            result = SavePaPsdsMa();

            if (result < 0)
            {
                outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                return result;
            }

            outmsg = msg;
            return result;
        }

        /// <summary>
        /// 동일성분 의약품 제한자
        /// </summary>
        /// <param name="disregprson7">등록일(8)+종료일(8)</param>
        /// <param name="outmsg"></param>
        /// <returns></returns>
        private int SaveDisRegPrson7(string disregprson7, out string outmsg)
        {
            int result = 0;
            string msg = string.Empty;
            //m_VCODE_CD = StringService.SubString(disregprson6, 0, 4);     // 특정기호코드
            //m_SEVR_NO = StringService.SubString(disregprson6, 4, 15);     // 중증등록번호
            m_APLY_DD = StringService.SubStringByte(disregprson7, 0, 8);        // 적용일자
            m_VALD_DD = StringService.SubStringByte(disregprson7, 8, 8);        // 종료일자

            m_SEVR_DVCD = "7";                                             // 중증구분코드

            m_UPDT_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_UPDTR_ID = DOPack.UserInfo.USER_CD;
            m_RGST_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_RGSTR_ID = DOPack.UserInfo.USER_CD;

            TrimData();
            result = SavePaPsdsMa();

            if (result < 0)
            {
                outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                return result;
            }

            outmsg = msg;
            return result;
        }

        /// <summary>
        /// 노인틀니대상자( 상악 : "8", 하악 = "9" )
        /// </summary>
        /// <param name="sevrdvcd"></param>
        /// <param name="dent">등록번호(15) + 등록요양기관기호(8) + 틀니장착일(8) + 무상사후기간 종료일(8) + 시작일(8) + 종료일(8)</param>
        /// <param name="outmsg"></param>
        /// <returns></returns>
        private int SaveDent(string sevrdvcd, string dent, out string outmsg)
        {
            int result = 0;
            string msg = string.Empty;
            //m_VCODE_CD = StringService.SubString(dend, 0, 4);     // 특정기호코드
            m_SEVR_NO = StringService.SubStringByte(dent, 0, 15);                                  // 등록번호
            m_DNTR_RCPR_INSTNO = StringService.SubStringByte(dent, 15, 8);                                  // 등록요양기관기호
            m_DNTR_APLY_DD = StringService.SubStringByte(dent, 23, 8);                                  // 틀니장착일
            m_DNTR_END_DD = StringService.SubStringByte(dent, 31, 8);                                  // 무상사후기간 종료일
            m_APLY_DD = StringService.SubStringByte(dent, 39, 8);                                           // 적용일자
            m_VALD_DD = StringService.IsNvl(StringService.SubStringByte(dent, 39, 8), "29991231");          // 종료일자
            m_ILNS_CD = "K081";

            m_SEVR_DVCD = sevrdvcd;                                             // 중증구분코드

            m_UPDT_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_UPDTR_ID = DOPack.UserInfo.USER_CD;
            m_RGST_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_RGSTR_ID = DOPack.UserInfo.USER_CD;

            TrimData();
            result = SavePaPsdsMa();

            if (result < 0)
            {
                outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                return result;
            }

            outmsg = msg;
            return result;
        }

        /// <summary>
        /// 임플란트 대상자정보( 대상자 1 : "A", 대상자 2 : "B")
        /// </summary>
        /// <param name="sevrdvcd"></param>
        /// <param name="dentimpl">등록번호(18)+등록요양기관기호(8)+최종단계시술일(8)+사후점검종료일(8)+시작유효일(8)+상실유효일(8)</param>
        /// <param name="outmsg"></param>
        /// <returns></returns>
        private int SaveDentImpl(string sevrdvcd, string dentimpl, out string outmsg)
        {
            int result = 0;
            string msg = string.Empty;
            //m_VCODE_CD = StringService.SubString(dend, 0, 4);     // 특정기호코드
            m_SEVR_NO = StringService.SubStringByte(dentimpl, 0, 18);                                  // 등록번호
            m_DNTR_RCPR_INSTNO = StringService.SubStringByte(dentimpl, 18, 8);                                  // 등록요양기관기호
            m_DNTR_APLY_DD = StringService.SubStringByte(dentimpl, 26, 8);                                  // 종단계시술일
            m_DNTR_END_DD = StringService.SubStringByte(dentimpl, 34, 8);                                  // 사후점검종료일
            m_APLY_DD = StringService.SubStringByte(dentimpl, 42, 8);                                           // 시작유효일
            m_VALD_DD = StringService.IsNvl(StringService.SubStringByte(dentimpl, 50, 8), "29991231");          // 상실유효일
            m_ILNS_CD = "*";

            m_SEVR_DVCD = sevrdvcd;                                             // 중증구분코드

            m_UPDT_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_UPDTR_ID = DOPack.UserInfo.USER_CD;
            m_RGST_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_RGSTR_ID = DOPack.UserInfo.USER_CD;

            TrimData();
            result = SavePaPsdsMa();

            if (result < 0)
            {
                outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                return result;
            }

            outmsg = msg;
            return result;
        }

        /// <summary>
        /// 산정특례(결핵)등록대상자
        /// </summary>
        /// <param name="disregprson9">특정기호(4)+등록번호(15)+등록일(8)+종료일(8)</param>
        /// <param name="outmsg"></param>
        /// <returns></returns>
        private int SaveDisRegPrson9(string disregprson9, out string outmsg)
        {
            int result = 0;
            string msg = string.Empty;
            m_VCODE_CD = StringService.SubStringByte(disregprson9, 0, 4);      // 특정기호코드
            m_SEVR_NO = StringService.SubStringByte(disregprson9, 4, 15);      // 중증등록번호
            m_APLY_DD = StringService.SubStringByte(disregprson9, 19, 8);      // 적용일자
            m_VALD_DD = StringService.SubStringByte(disregprson9, 27, 8);      // 종료일자

            m_SEVR_DVCD = "C";

            m_UPDT_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_UPDTR_ID = DOPack.UserInfo.USER_CD;
            m_RGST_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_RGSTR_ID = DOPack.UserInfo.USER_CD;

            TrimData();
            result = SavePaPsdsMa();

            if (result < 0)
            {
                outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                return result;
            }

            outmsg = msg;
            return result;
        }

        /// <summary>
        /// 요양기관별 산정특례(결핵)등록대상자
        /// </summary>
        /// <param name="disregprson12">특정기호(4)+산정특례등록번호(10)+치료시작일자(8)+치료종료일자(8)+의사면허번호(10)+의사성명(40)+종료요양기관기호(8)</param>
        /// <param name="outmsg"></param>
        /// <returns></returns>
        private int SaveDisRegPrson12(string disregprson12, out string outmsg)
        {
            int result = 0;
            string msg = string.Empty;
            m_VCODE_CD = StringService.SubStringByte(disregprson12, 0, 4);              // 특정기호코드
            m_SEVR_NO = StringService.SubStringByte(disregprson12, 4, 10);              // 중증등록번호
            m_APLY_DD = StringService.SubStringByte(disregprson12, 14, 8);              // 적용일자
            m_VALD_DD = StringService.SubStringByte(disregprson12, 22, 8);              // 종료일자
            m_ETC_USE_CNTS_1 = StringService.SubStringByte(disregprson12, 30, 10);      // 의사면허번호
            m_ETC_USE_CNTS_2 = StringService.SubStringByte(disregprson12, 40, 40);      // 의사성명
            m_ETC_USE_CNTS_3 = StringService.SubStringByte(disregprson12, 80, 8);      // 종료요양기관기호

            m_SEVR_DVCD = "C";

            m_UPDT_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_UPDTR_ID = DOPack.UserInfo.USER_CD;
            m_RGST_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_RGSTR_ID = DOPack.UserInfo.USER_CD;

            TrimData();
            result = SavePaPsdsMa();

            if (result < 0)
            {
                outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                return result;
            }

            outmsg = msg;
            return result;
        }

        /// <summary>
        /// 조산아 및 저체중출생아 등록대상자
        /// </summary>
        /// <param name="preinfant">등록번호(10)+시작유효일자(8)+종료유효일자(8)</param>
        /// <param name="outmsg"></param>
        /// <returns></returns>
        private int SavePreInFant(string preinfant, out string outmsg)
        {
            int result = 0;
            string msg = string.Empty;
            m_SEVR_NO = StringService.SubStringByte(preinfant, 0, 10);              // 특정기호코드
            m_APLY_DD = StringService.SubStringByte(preinfant, 10, 8);              // 적용일자
            m_VALD_DD = StringService.SubStringByte(preinfant, 18, 8);              // 종료일자

            m_SEVR_DVCD = "P";

            m_UPDT_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_UPDTR_ID = DOPack.UserInfo.USER_CD;
            m_RGST_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_RGSTR_ID = DOPack.UserInfo.USER_CD;

            TrimData();
            result = SavePaPsdsMa();

            if (result < 0)
            {
                outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                return result;
            }

            outmsg = msg;
            return result;
        }

        /// 산정특례(중증치매)등록대상자
        /// </summary>
        /// <param name="disregprson14">특정기호(4)+상병코드(10)+상병일련번호(2)+등록번호(15)+시작(유효)일(8)+상실(유효)일(8)+차수시작일(8)+차수종료일(8)+연장전사전승인일수(3)+연장후사전승인일수(3)</param>
        /// <param name="outmsg"></param>
        /// <returns></returns>
        private int SaveDisRegPrson14(string disregprson14, out string outmsg)
        {
            int result = 0;
            string msg = string.Empty;
            m_VCODE_CD = StringService.SubStringByte(disregprson14, 0, 4);        // 특정기호
            m_ILNS_CD = StringService.SubStringByte(disregprson14, 4, 10);       // 상병코드
            int.TryParse(StringService.SubStringByte(disregprson14, 14, 2), out m_ILNS_SQNO);  // 상병일련번호
            m_SEVR_NO = StringService.SubStringByte(disregprson14, 16, 15);      // 등록번호
            m_APLY_DD = StringService.SubStringByte(disregprson14, 31, 8);       // 시작(유효일)
            m_VALD_DD = StringService.SubStringByte(disregprson14, 39, 8);       // 상실(유효일)
            m_DNTR_APLY_DD = StringService.SubStringByte(disregprson14, 47, 8);       // 차수시작일
            m_DNTR_END_DD = StringService.SubStringByte(disregprson14, 55, 8);       // 차수종료일
            m_ETC_USE_CNTS_1 = StringService.SubStringByte(disregprson14, 61, 3);       // 연장전사전승인일수
            m_ETC_USE_CNTS_2 = StringService.SubStringByte(disregprson14, 64, 3);       // 연장후사전승인일수

            m_SEVR_DVCD = "D";

            m_UPDT_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_UPDTR_ID = DOPack.UserInfo.USER_CD;
            m_RGST_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_RGSTR_ID = DOPack.UserInfo.USER_CD;

            TrimData();
            result = SavePaPsdsMa();

            if (result < 0)
            {
                outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                return result;
            }

            outmsg = msg;
            return result;
        }
        
        private int SaveDisRegPrson10(string disregprson10, out string outmsg)
        {
            int result = 0;
            string msg = String.Empty;
            m_VCODE_CD = StringService.SubStringByte(disregprson10, 0, 4);       // 특정기호코드
            m_SEVR_NO = StringService.SubStringByte(disregprson10, 4, 15);                // 중증등록번호
            m_APLY_DD = StringService.SubStringByte(disregprson10, 19, 8);                // 적용일자
            m_VALD_DD = StringService.SubStringByte(disregprson10, 27, 8);                // 종료일자
            m_ilnsCd = StringService.SubStringByte(disregprson10, 35, 10);                // 상병코드
            int.TryParse(StringService.SubStringByte(disregprson10, 45, 3), out m_ILNS_SQNO);                // 상병일련번호

            m_SEVR_DVCD = "R";                                                       // 중증구분코드

            m_UPDT_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_UPDTR_ID = DOPack.UserInfo.USER_CD;
            m_RGST_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_RGSTR_ID = DOPack.UserInfo.USER_CD;

            TrimData();
            result = SavePaPsdsMa();

            if (result < 0)
            {
                outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                return result;
            }

            // 결핵
            if (StringService.SubStringByte(m_SEVR_NO, 0, 2) == "07")
            {
                m_SEVR_DVCD = "C";

                result = SavePaPsdsMa();

                if (result < 0)
                {
                    outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                    return result;
                }
            }
            outmsg = msg;
            return result;
        }

        private int SaveDisRegPrson11(string disregprson11, out string outmsg)
        {
            int result = 0;
            string msg = String.Empty;
            m_VCODE_CD = StringService.SubStringByte(disregprson11, 0, 4);       // 특정기호코드
            m_SEVR_NO = StringService.SubStringByte(disregprson11, 4, 15);                // 중증등록번호
            m_APLY_DD = StringService.SubStringByte(disregprson11, 19, 8);                // 적용일자
            m_VALD_DD = StringService.SubStringByte(disregprson11, 27, 8);                // 종료일자
            m_ilnsCd = StringService.SubStringByte(disregprson11, 35, 10);                // 상병코드
            int.TryParse(StringService.SubStringByte(disregprson11, 45, 2), out m_ILNS_SQNO);                // 상병일련번호

            m_SEVR_DVCD = "R";                                                       // 중증구분코드

            m_UPDT_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_UPDTR_ID = DOPack.UserInfo.USER_CD;
            m_RGST_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_RGSTR_ID = DOPack.UserInfo.USER_CD;

            TrimData();
            result = SavePaPsdsMa();

            if (result < 0)
            {
                outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                return result;
            }

            // 결핵
            if (StringService.SubStringByte(m_SEVR_NO, 0, 2) == "07")
            {
                m_SEVR_DVCD = "C";

                result = SavePaPsdsMa();

                if (result < 0)
                {
                    outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                    return result;
                }
            }
            outmsg = msg;
            return result;
        }

        private int SaveDisRegPrson18(string disregprson18, out string outmsg)
        {
            int result = 0;
            string msg = String.Empty;
            m_VCODE_CD = StringService.SubStringByte(disregprson18, 0, 4);       // 특정기호코드
            m_SEVR_NO = StringService.SubStringByte(disregprson18, 4, 15);                // 중증등록번호
            m_APLY_DD = StringService.SubStringByte(disregprson18, 19, 8);                // 적용일자
            m_VALD_DD = StringService.SubStringByte(disregprson18, 27, 8);                // 종료일자
            m_ilnsCd = StringService.SubStringByte(disregprson18, 35, 10);                // 상병코드
            int.TryParse(StringService.SubStringByte(disregprson18, 45, 2), out m_ILNS_SQNO);                // 상병일련번호

            m_SEVR_DVCD = "S";                                                       // 중증구분코드

            m_UPDT_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_UPDTR_ID = DOPack.UserInfo.USER_CD;
            m_RGST_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_RGSTR_ID = DOPack.UserInfo.USER_CD;

            TrimData();
            result = SavePaPsdsMa();

            if (result < 0)
            {
                outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                return result;
            }

            // 결핵
            if (StringService.SubStringByte(m_SEVR_NO, 0, 2) == "07")
            {
                m_SEVR_DVCD = "C";

                result = SavePaPsdsMa();

                if (result < 0)
                {
                    outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                    return result;
                }
            }
            outmsg = msg;
            return result;
        }

        private int SaveDisRegPrson19(string disregprson19, out string outmsg)
        {
            int result = 0;
            string msg = String.Empty;
            m_VCODE_CD = StringService.SubStringByte(disregprson19, 0, 4);       // 특정기호코드
            m_SEVR_NO = StringService.SubStringByte(disregprson19, 4, 15);                // 중증등록번호
            m_APLY_DD = StringService.SubStringByte(disregprson19, 19, 8);                // 적용일자
            m_VALD_DD = StringService.SubStringByte(disregprson19, 27, 8);                // 종료일자
            m_ilnsCd = StringService.SubStringByte(disregprson19, 35, 10);                // 상병코드
            int.TryParse(StringService.SubStringByte(disregprson19, 45, 3), out m_ILNS_SQNO);                // 상병일련번호

            //m_SEVR_DVCD = "4";                                                       // 중증구분코드

            m_UPDT_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_UPDTR_ID = DOPack.UserInfo.USER_CD;
            m_RGST_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_RGSTR_ID = DOPack.UserInfo.USER_CD;

            TrimData();
            result = SavePaPsdsMa();

            if (result < 0)
            {
                outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                return result;
            }

            // 결핵
            if (StringService.SubStringByte(m_SEVR_NO, 0, 2) == "07")
            {
                m_SEVR_DVCD = "C";

                result = SavePaPsdsMa();

                if (result < 0)
                {
                    outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                    return result;
                }
            }
            outmsg = msg;
            return result;
        }

        private int SaveDisRegPrson20(string disregprson20, out string outmsg)
        {
            int result = 0;
            string msg = String.Empty;
            m_VCODE_CD = StringService.SubStringByte(disregprson20, 0, 4);       // 특정기호코드
            m_SEVR_NO = StringService.SubStringByte(disregprson20, 4, 15);                // 중증등록번호
            m_APLY_DD = StringService.SubStringByte(disregprson20, 19, 8);                // 적용일자
            m_VALD_DD = StringService.SubStringByte(disregprson20, 27, 8);                // 종료일자
            m_ilnsCd = StringService.SubStringByte(disregprson20, 35, 10);                // 상병코드
            m_ILNS_CD = StringService.SubStringByte(disregprson20, 35, 10);                // 상병코드
            int.TryParse(StringService.SubStringByte(disregprson20, 45, 2), out m_ILNS_SQNO);                // 상병일련번호

            m_SEVR_DVCD = "E";                                                       // 중증구분코드

            m_RGST_DT = m_UPDT_DT = DateTime.Now.ToString("yyyyMMddHHmmss");
            m_RGSTR_ID = m_UPDTR_ID = DOPack.UserInfo.USER_CD;

            TrimData();
            result = SavePaPsdsMa();

            if (result < 0)
            {
                outmsg = "오류가 발생하였습니다. 로그파일을 확인하세요!!";
                return result;
            }

            outmsg = msg;
            return result;
        }

        /// <summary>
        /// Save PAPSDAMA[중증질환관리] 
        /// </summary>
        /// <returns></returns>
        /// <summary>
        private int SavePaPsdsMa()
        {
            int result = this.SelectPAPSDSMA();

            if (result < 0)
            {
                return result;
            }
            else if (result > 0)
            {
                //상병이 등록되어 있으면 변경하지 않는다.
                if (m_ilnsCd.Trim().Length > 1 && m_ILNS_CD.Trim().Length <= 1)
                {
                    m_ILNS_CD = m_ilnsCd.Trim();
                }

                this.UpdatePaPsdsMa();
                m_ilnsCd = string.Empty;
            }
            else
            {
                // 이거 값 받아서 리턴하면 안됨 ㅠㅠ
                this.InsertPaPsdsMa();
            }

            return result;
        }

        #endregion Method : Private Method
    }
}
