package web.townsi.com.work.convert.doc;

import java.awt.Container;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import web.townsi.com.utils.FileUtil;
import web.townsi.com.utils.Util;

public class Design {

	private String docType = "";
	private String classNm = "";
	private String onlyFileNm = "";
	public static StringBuilder contentSb = null;
	
	public static Set<String> TYPE_SET = new LinkedHashSet<String>();
	public static Map<String, String> VARI_MAP = new LinkedHashMap<String, String>();
	public static String[] DATE_TYPE = {
			"LxSpread"
			,"LxLabel"
			,"LxPanel"
			,"UltraTab"
			,"SheetView"
			,"LxTitlePanel"
			,"LxTitleLabel"
			,"LxGroupBox"
			
			
			,"LxMaskedEdit"
			,"LxTextBox"
			
			
			
			,"LxComboBox"
			,"LxOverallCombo" 
			,"LxDoctorListCombo"
			,"LxDoctorListCombo"
			,"LxLoginUserDeptCombo"
			,"LxClinicCombo"
			,"LxDeptCombo"
			,"LxOverallCombo"
			,"LxRoomCombo"
			,"LxSlipCombo"
			,"LxUserListCombo"
			,"LxWardCombo"
			,"LxComboBoxMultiCheck"
			
			,"LxCheckBox"
			,"LxRadioButton"
			
			,"LxLoginUserDeptListBox"
			,"LxCheckBoxRadioGroup" //추가
			
			,"LxButtonList"
			,"LxButton"
			,"ToolTip"
			,"LxSplitter"
			,"LxDateTimeEditor"
			,"LxDateTimePicker"
			,"LxButtonList"
			
			,"LxTabControl"
			
			,"UltraTabPageControl"
			,"LxTabStripControl"
			
			};
	
	public static String[] SCOPE_TYPE = {"private", "public"};
	public static String[] NEW_TYPE = {
			"System.Windows.Forms.DockStyle.Fill"
	};

	public Design(String docType, String classNm) {
		this.docType = docType;
		this.classNm = classNm;
	}

	public static String TAB_SIZE = "    ";
	public static String IMPORT_START_STR = "// import start";
	public static String rLine = "\r\n";
	public static String strOfLine = "<rEaDlInE>";

	public String setResultMap(String docType, String str, String onlyFileNm) {

		String[] str_araay = str.split("\\r\\n");
		List<String> list = Arrays.asList(str_araay);

		StringBuilder sb = new StringBuilder(16 ^ 5);
		String line = "";
		String lineBefore = "";
		String lineNext = "";

		String noBlankLine = "";
		String noBlankLineBefore = "";
		String noBlankLineNext = "";

		String trimLine = "";
		String regex = "";
		String lineChg = "";
		String _docType = this.docType;
		this.onlyFileNm = onlyFileNm;
		TYPE_SET.clear();
		VARI_MAP.clear();
		
		for (int i = 0; i < list.size(); i++) {
			line = list.get(i);
			
			if (i != 0) {
				lineBefore = list.get(i - 1);
				noBlankLineBefore = Util.removeBlank(lineBefore);
			}
			if (i != (list.size() - 1)) {
				lineNext = list.get(i + 1);
				noBlankLineNext = Util.removeBlank(lineNext);
			}

			noBlankLine = Util.removeBlank(line);
			trimLine = line.trim();

			// private string 멤버변수
			int commIdx = noBlankLine.indexOf("//");
			String commNoBlankLine = noBlankLine;
			if (commIdx > -1) {
				commNoBlankLine = noBlankLine.substring(0, commIdx);
			}
			
			if (!line.isEmpty()) {
				
				
				if (trimLine.startsWith("#")) {
					continue;
				}
				
				// 전체 여긴 InitializeComponent 후에 나온 줄 
				line = convertMemberVari(line, lineBefore, lineNext, noBlankLine, commNoBlankLine, noBlankLineBefore, noBlankLineNext, trimLine);
				
				// ================= continue start ==============================
//				System.out.println("123 : " + line);
			}
			// ================= continue start ==============================
			sb.append(line + "\r\n");
		}
		return sb.toString();
	}

	private String convertMemberVari(String line, String lineBefore, String lineNext,
			String noBlankLine, String commNoBlankLine, String noBlankLineBefore, String noBlankLineNext, String trimLine) {
		
		boolean isNumberType = false;
		String nType = "";
		noBlankLine = Util.removeBlank(line);
		
		for (int sdx = 0; sdx < SCOPE_TYPE.length; sdx++) {
			String scope = SCOPE_TYPE[sdx];
			
			for (int ndx = 0; ndx < DATE_TYPE.length; ndx++) {
				nType = DATE_TYPE[ndx];
				
				if (noBlankLine.contains(Util.removeBlank(scope + " "+nType +" "))) {
					line = Util.chgMemberVari(this.docType, line, (scope + " "+nType));
					addTypeSet(nType, line);
					line = chgConst(line);
					isNumberType = true;
					break;
				}
				if (noBlankLine.contains(Util.removeBlank(scope + " static "+nType +" "))) {
					line = Util.chgMemberVari(this.docType, line.replace("static ", ""), (scope + " "+nType));
					addTypeSet(nType, line);
					line = chgConst(line);
					isNumberType = true;
					break;
				}
				if (noBlankLine.contains(Util.removeBlank(scope + " const "+nType +" "))) {
					line = Util.chgMemberVari(this.docType, line.replace("const ", ""), (scope + " "+nType));
					addTypeSet(nType, line);
					line = chgConst(line);
					isNumberType = true;
					break;
				}
			}
		}
		return line;
	}

	private void addTypeSet(String nType, String line) {
		
		if (!TYPE_SET.contains(nType)) {
			TYPE_SET.add(nType);	
		}
		
		if (line.contains(":")) {
			String[] array =  line.trim().replace(";", "").split(":");
			VARI_MAP.put(array[0].trim(), nType.trim());
		}
		
	}

	private String chgConst(String line) {
		if(line.contains(":")) {
			String startBlank = Util.makeStartBlank(line);
			int idx = line.lastIndexOf(":");
			String sLine = line.substring(0, idx).trim();
			String eLine = line.substring(idx + 1, line.length()).trim();
			eLine = eLine.replace(";", "");
			
			if (eLine.equals("SheetView")) {
				line = startBlank + "const "+ sLine +" = new SheetView(); //"+ eLine;
			} else {
				line = startBlank + "const "+ sLine +" = $ref(null); //"+ eLine;	
			}
		}
		return line;
	}

	public static HashMap<String, Object> convertGetDesing(String rfullPath, String onlyFileNm, String result, String fileNm, String ext) throws FileNotFoundException {
		
		HashMap<String, Object> resultMap = new LinkedHashMap<String, Object>(); 
		
		int idx = rfullPath.lastIndexOf(File.separator);
		String readDContent = "";
		String wDfullPath = "";
		if (idx > -1) {
			idx = idx + 1;
			rfullPath = rfullPath.substring(0, idx) + onlyFileNm + ".designer.cs";
			File designerF = new File(rfullPath);
			if (designerF.exists()) {
				readDContent = FileUtil.readFile(rfullPath);
				wDfullPath = result + fileNm.replace(ext, "designer.vue");
				resultMap = Design.getInitCompStr("TS", readDContent, onlyFileNm);
			}							
		}
		
		StringBuilder tagSb = new StringBuilder();
		List<String> formCompList = null;
		Map<String, String> variMap = null;
		String initCompStr = "";
		String tagStr = "";
		String designVeri = "";
		
		if (resultMap != null)  {
			if (resultMap.get("TYPE_SET") != null) {
				Set<String> TYPE_SET  = (Set<String>) resultMap.get("TYPE_SET");
				formCompList = new ArrayList<String>(TYPE_SET);
			}
			
			if (resultMap.get("VARI_MAP") != null) {
				variMap = (Map<String, String>) resultMap.get("VARI_MAP");
				tagSb = new StringBuilder();
				if (variMap != null) {
					
					for (String variNm : variMap.keySet()) {
						String type = variMap.get(variNm);
						if (type.equals("LxSpread")) {
							tagSb.append("<LxSpread ref=\""+variNm+"\"></LxSpread>" + "\r\n");
						} else if (type.equals("LxTextBox")) {
							tagSb.append("<LxTextBox ref=\""+variNm+"\"></LxTextBox>" + "\r\n");
						} else if (type.equals("LxTitleLabel")) {
							tagSb.append("<LxTitleLabel ref=\""+variNm+"\"></LxTitleLabel>" + "\r\n");
						} else if (type.equals("LxComboBox")) {
							tagSb.append("<LxComboBox ref=\""+variNm+"\" :style=\"`width: 100%`\"></LxComboBox>" + "\r\n");
						} else if (type.equals("LxOverallCombo")) {
							tagSb.append("<LxOverallCombo ref=\""+variNm+"\" :style=\"`width: 100%`\" selectClass=\"select_default\"></LxOverallCombo>" + "\r\n");
						} else if (type.equals("LxLabel")) {
							tagSb.append("<LxLabel ref=\""+variNm+"\"></LxLabel>" + "\r\n");
						} else if (type.equals("LxDoctorListCombo")) {
							tagSb.append("<LxDoctorListCombo ref=\""+variNm+"\" :style=\"`width: 100%`\"></LxDoctorListCombo>" + "\r\n");
						} else if (type.equals("LxMaskedEdit")) {
							tagSb.append("<LxMaskedEdit ref=\""+variNm+"\" selectClass=\"\" inputValue=\"\"></LxMaskedEdit>" + "\r\n");
						} else if (type.equals("LxTitlePanel")) {
							tagSb.append("<LxTitlePanel ref=\""+variNm+"\"></LxTitlePanel>" + "\r\n");
						} else if (type.equals("LxPanel")) {
							tagSb.append("<LxPanel ref=\""+variNm+"\"></LxPanel>" + "\r\n");
						} else if (type.equals("LxClinicCombo")) {
							tagSb.append("<LxClinicCombo ref=\""+variNm+"\"></LxClinicCombo>" + "\r\n");
						} else if (type.equals("LxDeptCombo")) {
							tagSb.append("<LxDeptCombo ref=\""+variNm+"\"></LxDeptCombo>" + "\r\n");
						} else if (type.equals("LxDoctorListCombo")) {
							tagSb.append("<LxDoctorListCombo ref=\""+variNm+"\"></LxDoctorListCombo>" + "\r\n");
						} else if (type.equals("LxLoginUserDeptCombo")) {
							tagSb.append("<LxLoginUserDeptCombo ref=\""+variNm+"\"></LxLoginUserDeptCombo>" + "\r\n");
						} else if (type.equals("LxLoginUserDeptListBox")) {
							tagSb.append("<LxLoginUserDeptListBox ref=\""+variNm+"\"></LxLoginUserDeptListBox>" + "\r\n");
						} else if (type.equals("LxOverallCombo")) {
			                 tagSb.append("<LxOverallCombo ref=\""+variNm+"\" :style=\"`width: 100%`\" selectClass=\"select_default\"></LxOverallCombo>" + "\r\n");
						} else if (type.equals("LxRoomCombo")) {
							tagSb.append("<LxRoomCombo ref=\""+variNm+"\"></LxRoomCombo>" + "\r\n");
						} else if (type.equals("LxSlipCombo")) {
							tagSb.append("<LxSlipCombo ref=\""+variNm+"\"></LxSlipCombo>" + "\r\n");
						} else if (type.equals("LxUserListCombo")) {
							tagSb.append("<LxUserListCombo ref=\""+variNm+"\"></LxUserListCombo>" + "\r\n");
						} else if (type.equals("LxWardCombo")) {
							tagSb.append("<LxWardCombo ref=\""+variNm+"\"></LxWardCombo>" + "\r\n");
						} else if (type.equals("LxCheckBox")) {
							tagSb.append("<LxCheckBox ref=\""+variNm+"\" componentText=\"\"></LxCheckBox>" + "\r\n");
						} else if (type.equals("LxCheckBoxRadioGroup")) {
							tagSb.append("<LxCheckBoxRadioGroup ref=\""+variNm+"\" componentText=\"\"></LxCheckBoxRadioGroup>" + "\r\n");
						} else if (type.equals("LxButton")) {
			                  tagSb.append("<LxButton ref=\""+variNm+"\" label=\""+variNm+"\" class=\"btn btn-org border-org btn_md\"></LxButton>" + "\r\n");
						} else if (type.equals("ToolTip")) {							
							
						} else if (type.equals("LxSplitter")) {
			                  // tagSb.append("<LxSplitter ref=\""+variNm+"\" ></LxSplitter>" + "\r\n");
						} else if (type.equals("LxDateTimeEditor")) {
//			                  tagSb.append("<LxDateTimeEditor ref=\""+variNm+"\"></LxDateTimeEditor>" + "\r\n");
							tagSb.append("/*LxDateTimeEditor LxDateTimePicker로 대체*/ " + "\r\n");
			                tagSb.append("<LxDateTimePicker ref=\""+variNm+"\" :style=\"'width: 130px'></LxDateTimePicker>" + "\r\n");
			                  
						} else if (type.equals("LxDateTimePicker")) {
							tagSb.append("<LxDateTimePicker ref=\""+variNm+"\" :style=\"'width: 130px'></LxDateTimePicker>" + "\r\n");
						} else if (type.equals("LxButtonList")) {
							tagSb.append("<LxButtonList ref=\""+variNm+"\"></LxButtonList>" + "\r\n");
							
						} else if (type.equals("LxComboBoxMultiCheck")) {
							tagSb.append("<LxComboBoxMultiCheck ref=\""+variNm+"\" style=\"width: 145px\"></LxComboBoxMultiCheck>" + "\r\n");
						} else if (type.equals("LxTabControl")) {
							tagSb.append("<LxTabControl ref=\""+variNm+"\"></LxTabControl>" + "\r\n");
						} else if (type.equals("LxRadioButton")) {
							tagSb.append("<LxRadioButton ref=\""+variNm+"\"></LxRadioButton>" + "\r\n");
						} else if (type.equals("LxButtonList")) {
							tagSb.append("<LxButtonList ref=\""+variNm+"\"></LxButtonList>" + "\r\n");
						} else {
							System.out.println("");
						}
					}
				}
				tagStr = tagSb.toString();
				resultMap.put("tagStr", tagStr);
			}
			
			if (resultMap.get("INITIALIZE_COMPONENT") != null) {
				initCompStr = (String) resultMap.get("INITIALIZE_COMPONENT");
				
			}
			if (resultMap.get("content") != null) {
				designVeri = (String) resultMap.get("content");	
			}
		}		
		
		return resultMap;
	}
	
	public static HashMap<String, Object> getInitCompStr(String docType, String content, String onlyFileNm) {
		content = content.replaceAll("\t", "    ");
		
		String classNm = DocAllLine.getClassNm(content, onlyFileNm);
		
		contentSb = new StringBuilder(1024 * 10);
		content = content.replaceAll("\r\n", strOfLine);		
		
		Pattern pattern = Pattern.compile("InitializeComponent()");
		Matcher matcher = pattern.matcher(content);
		HashMap<String, Object> resultMap = new LinkedHashMap<String, Object>();
		
		int sIdx = -1;
		String chgStr = "";
		String all = "";
		Design.TYPE_SET.clear();
		Design.VARI_MAP.clear();
		
		if (matcher.find()) {
			String targetWord = matcher.group(0);
			String spaceVal = matcher.group(1).trim();
			String target = targetWord.replace("{", "").replace("<rEaDlInE>", "").trim();
			
//			System.out.println(" targetWord >> " + targetWord);
//			System.out.println(" spaceVal >> " + spaceVal);
			
			int idx1 = content.indexOf(targetWord);
			all = content.substring(idx1);
			all = Util.findBracketPairStr(all);
			String allLine = all.replaceAll(strOfLine, "\r\n");
			sIdx = content.indexOf(all) + all.length();
			String sliceStr = content.substring(0, sIdx);
			contentSb.append(sliceStr);
			
			// 다음 InitializeComponent 다음
			String publicStr = content.substring(sIdx, content.length());
			publicStr = publicStr.replace("}", "");
			publicStr = publicStr.replaceAll(strOfLine, "\r\n");
			
			publicStr = converPublicStr(publicStr, Design.VARI_MAP);
			publicStr = convertAllAndType(publicStr);
			
			Design design = new Design("TS", classNm);
			// 여기서 result
			publicStr = design.setResultMap("TS", publicStr, onlyFileNm);
			
			
			// INITIALIZE_COMPONENT 문자열 conver
			allLine = convertAllAndType(allLine);
			allLine = convertInitComp(allLine, Design.VARI_MAP);
			System.out.println("allLine >> " + allLine);
			
			resultMap.put("INITIALIZE_COMPONENT", allLine);
			resultMap.put("TYPE_SET", Design.TYPE_SET);
			resultMap.put("VARI_MAP", Design.VARI_MAP);
			resultMap.put("content", publicStr);
		}
		return resultMap;
	}
	
	public static String convertAllAndType(String content) {
		
		//DocImport.java			importSb.append("import { System } from \"@/app/utils/System\";" + "\r\n");
		if (content.contains("new Lime.Framework.Controls.LxSpread")) {
			Design.TYPE_SET.add("LxSpread");
		} 
		if (content.contains("System.Windows.Forms.DockStyle.Fill")) {
			Design.TYPE_SET.add("System");
		} 
		if (content.contains(".CellType")) {
			Design.TYPE_SET.add("CellType");
		}
		if (content.contains(".DockStyle")) {
			Design.TYPE_SET.add("DockStyle");
		}
		if (content.contains("CellHorizontalAlignment.")) {
			Design.TYPE_SET.add("CellHorizontalAlignment");
		}
		if (content.contains("CellVerticalAlignment.")) {
			Design.TYPE_SET.add("CellVerticalAlignment");
		}
		if (content.contains("COMBO_ADD_ITEM_TYPE.")) {
			Design.TYPE_SET.add("COMBO_ADD_ITEM_TYPE");
		}
		if (content.contains("FarPoint.Win.Spread.SheetView")) {
			Design.TYPE_SET.add("SheetView");
		}
		
		content = content.replace("this.", "");
		content = content.replace("FarPoint.Win.Spread.", "");
		content = content.replace("Lime.Framework.", "");		
		content = content.replace("Framework.Controls.", "");
		content = content.replace("System.Windows.Forms.", "");
		content = content.replace("System.Windows.Forms.", "");
		content = content.replace("Infragistics.Win.UltraWinTabControl.UltraTabPageControl", "UltraTabPageControl");
		content = content.replace("Infragistics.Win.UltraWinTabControl.UltraTab", "UltraTab");
		
		
		
		content = content.replace("CellType.TextCellType ", "const ");
		content = content.replace("CellType.MaskCellType ", "const ");
		content = content.replace("CellType.NumberCellType ", "const ");
		content = content.replace("CellType.ComboBoxCellType ", "const ");
		content = content.replace("CellType.CheckBoxCellType ", "const ");
		content = content.replace("CellType.GeneralCellType ", "const ");
		return content; 
	}
	
	public static String converPublicStr(String content, Map<String, String> veriMap) {
		String[] str_araay = content.split("\\r\\n");
		List<String> list = Arrays.asList(str_araay);
		String line = "";
		String key = "";
		String val = "";
		String lineBefore = "";
		String lineNext = "";

		String noBlankLine = "";
		String noBlankLineBefore = "";
		String noBlankLineNext = "";

		String trimLine = "";
		String regex = "";
		String lineChg = "";		
		
		StringBuilder sb = new StringBuilder(16 ^ 5);
		boolean isContinue = false;
		for (int i = 0; i < list.size(); i++) {
			line = list.get(i);
			if (line.trim().isEmpty()) {
				continue;
			}
			
			if (i != 0) {
				lineBefore = list.get(i - 1);
				noBlankLineBefore = Util.removeBlank(lineBefore);
			}
			if (i != (list.size() - 1)) {
				lineNext = list.get(i + 1);
				noBlankLineNext = Util.removeBlank(lineNext);
			}

			noBlankLine = Util.removeBlank(line);
			trimLine = line.trim();

			// private string 멤버변수
			int commIdx = noBlankLine.indexOf("//");
			String commNoBlankLine = noBlankLine;
			if (commIdx > -1) {
				commNoBlankLine = noBlankLine.substring(0, commIdx);
			}
			
			
			// 모두 제거 
			if (line.contains("Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage")
					|| line.contains("Framework.Controls.LxTabControl") 
					) {
				continue;
			} else {
				sb.append(line + "\r\n");	
			}
			
		}
		return sb.toString();
	}
	
	public static String convertInitComp(String content, Map<String, String> veriMap) {
		
		String[] str_araay = content.split("\\r\\n");
		List<String> list = Arrays.asList(str_araay);
		String line = "";
		String key = "";
		String val = "";
		String lineBefore = "";
		String lineNext = "";

		String noBlankLine = "";
		String noBlankLineBefore = "";
		String noBlankLineNext = "";

		String trimLine = "";
		String regex = "";
		String lineChg = "";		
		
		StringBuilder sb = new StringBuilder(16 ^ 5);
		boolean isContinue = false;
		for (int i = 0; i < list.size(); i++) {
			line = list.get(i);
			if (line.trim().isEmpty()) {
				continue;
			}
			
			if (i != 0) {
				lineBefore = list.get(i - 1);
				noBlankLineBefore = Util.removeBlank(lineBefore);
			}
			if (i != (list.size() - 1)) {
				lineNext = list.get(i + 1);
				noBlankLineNext = Util.removeBlank(lineNext);
			}

			noBlankLine = Util.removeBlank(line);
			trimLine = line.trim();

			// private string 멤버변수
			int commIdx = noBlankLine.indexOf("//");
			String commNoBlankLine = noBlankLine;
			if (commIdx > -1) {
				commNoBlankLine = noBlankLine.substring(0, commIdx);
			}
			
			// 모두 제거 
			if (line.contains("VisualStyles.")
					|| line.contains("Controls.Add(")
					
					|| line.contains("Infragistics.Win.Appearance") 
					|| line.contains("Infragistics.Win.DefaultableBoolean")
					|| line.contains("Infragistics.Win.AlphaBlendMode")
					|| line.contains("Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage")
					|| line.contains("new System.Drawing.Point")
					|| line.contains("new System.Drawing.Size")
					
					|| line.contains("SuspendLayout(") 
					|| line.contains("ResumeLayout(") 
					|| line.contains("System.ComponentModel.") 
					|| line.contains("enhancedScrollBarRenderer") 
					|| line.contains("AllowUserZoom") 
					|| line.contains("AutoFirstAppendRow")  
					|| line.contains("AutoLastAppendRow") 
					|| line.contains("BackColor") 
					|| line.contains("BorderStyle") 
					|| line.contains("ButtonStyle") 
					|| line.contains("ButtonDrawMode") 
					|| line.contains("ColumnSplitBoxPolicy") 
					|| line.contains("FocusRenderer") 
					|| line.contains("HorizontalScrollBar.") 
					|| line.contains("HorizontalScrollBarPolicy.") 
					|| line.contains("ScrollTipPolicy.") 
					|| line.contains("SelectionBlockOptions.") 
					|| line.contains("AllowEditorReservedLocations") 
					|| line.contains("EditModePermanent") 
					|| line.contains("EditModeReplace") 
					|| line.contains("HorizontalScrollBarPolicy") 
					|| line.contains("RowSplitBoxPolicy") 
					|| line.contains("ScrollBarTrackPolicy")
					|| line.contains(".ReferenceStyle")
					|| line.contains(".ColumnCount")
					|| line.contains(".RowCount")
					|| line.contains(".ColumnHeader.Cells.")
					|| line.contains(".AccessibleDescription")
					|| line.contains(".VerticalScrollBarPolicy")
					|| line.contains(".VerticalScrollBar")
					|| line.contains(".RowHeader.Columns.Default.Resizable")					
					|| line.contains("System.Windows.Forms.AutoScaleMode")					
					|| line.contains(".Cells.Get(")					
					|| line.contains("Lime.Framework.Controls.")					
					|| line.contains("System.Windows.Forms.ToolTip")					
					|| line.contains("appearance")
					|| line.contains("Model.SelectionPolicy.")					
					|| line.contains("Model.SelectionUnit.")
					|| line.contains("FarPoint.Win.ButtonAlign")
					|| line.contains("CellType.EnhancedRowHeaderRenderer")
					|| line.contains("FarPoint.Win.LineBorder")
					|| line.contains(".SheetCornerStyle")
					|| line.contains(".ShowRowSelector")
					|| line.contains(".ShowRowSelector")
					|| line.contains("CellType.GeneralCellType")
					|| line.contains(".RowHeader.")
					|| line.contains(".ColumnHeader.")
					|| line.contains(".UseMultiCellCopyPaste")
					|| line.contains(".UseRowMode")
					|| line.contains(".AutoFitColumnType")
					|| line.contains(".Rows.Default.")
					|| line.contains("SelectionStyles.SelectionColors")
					|| line.contains(".Protect")
					|| line.contains(".DefaultStyle")
					|| line.contains("OperationMode.")
					|| line.contains("TextTipPolicy.")
					
					|| line.contains("PerformLayout()")
					|| line.contains("ImeMode")
					
					|| line.contains(".ActiveBackgroundColor")
					|| line.contains(".NormalBackgroundColor")
					|| line.contains(".NormalGridLineColor")
					|| line.contains(".SelectedActiveBackgroundColor")
					|| line.contains(".SelectedBackgroundColor")
					|| line.contains(".SelectedGridLineColor")
					|| line.contains(".TextRotationAngle")					
					|| line.contains(".ForeColor")					
					|| line.contains(".BackgroundImage")					
					|| line.contains(".CellPadding")					
					|| line.contains(".NoteIndicatorColor")					
					|| line.contains(".DropDownButtonDisplayStyle")					
					|| line.contains(".DropDownStyle")					
					|| line.contains(".DropDownButtonDisplayStyle")					
					|| line.contains(".AutoSize")					
					|| line.contains(".NonAutoSizeHeight")					
					
					
					|| line.contains("new System.Drawing.Font")
					|| line.contains("new Padding")
					|| line.contains("new SheetView")	
					|| line.contains("new Controls.LxSpread")					
					|| line.contains("new Controls.LxLabel")
					|| line.contains("new Controls.LxPanel")
					|| line.contains("new Controls.LxTextBox")
					|| line.contains("new Controls.LxTitleLabel")
					|| line.contains("new Controls.LxComboBox")
					|| line.contains("new Controls.LxButton")
					|| line.contains("new Controls.LxCheckBox")
					|| line.contains("new UltraTabPageControl")
					|| line.contains("new Controls.LxDateTimeEditor")
					|| line.contains("new Controls.LxTabStripControl")
					|| line.contains("new Controls.LxDoctorListCombo")
					|| line.contains("new Controls.LxDoctorListCombo")
					|| line.contains("new Controls.LxOverallCombo")
					|| line.contains("new Controls.LxMaskedEdit")
					|| line.contains("new ToolTip")
					
					|| line.contains("new Controls.LxTitlePanel")
					|| line.contains("new Lime.Framework.Controls.LxSpread()")
					|| line.contains("new FarPoint.Win.Spread.EnhancedFocusIndicatorRenderer")
					|| line.contains("new FarPoint.Win.Spread.FpScrollBarButtonCollection")
					
					|| trimLine.startsWith("AutoScaleMode")
					|| trimLine.startsWith("Name")
					|| trimLine.startsWith("Size")
					|| trimLine.startsWith("enhancedRowHeaderRenderer")
					|| trimLine.startsWith("AutoScaleDimensions")
					) {
				
				continue;
			} else {
				// ------------------------------------
				isContinue = false;
				// 하는 것만 포함
				for (Map.Entry<String, String> entry : veriMap.entrySet()) {
					key = entry.getKey();
					val = entry.getValue();
					// 포함 줄
					if(line.contains(key)) {
						
						if (val.equals("LxPanel") 
								|| val.equals("LxLabel")
								|| val.equals("LxTitleLabel")
								) {
							String lTrimStr =  Util.lTrim(line);
							if (!lTrimStr.startsWith("//")) {
								String startBlank = Util.makeStartBlank(line);
								line = startBlank + "// "+ lTrimStr;
							}
							
						}
						
						line = convertDetail(line, noBlankLine);
						sb.append(line + "\r\n");
						isContinue = true;
						break;
					} 
				}
				if(isContinue) {
					continue;
				} else {
					//있는것은 포함
					if (line.contains("CellType.")
							|| line.contains(".Location.")
							|| line.contains(".Sheets.AddRange(")
							|| line.contains("new System.Drawing.Size")
							|| line.contains(".TabIndex")
							) {
						line = convertDetail(line, noBlankLine);
						sb.append(line + "\r\n");
						continue;
					} else {
						continue;
					}
				}
			}
//			sb.append(line + "\r\n");
		}
		return sb.toString();
	}	
	
	private static String convertDetail(String line, String noBlankLine) {
		
		if(line.contains(".RowHeader.Visible")) {
			line = Util.addComment(line);
		} else if(line.contains(".Controls.Add(")) {
			line = Util.addComment(line);
		} else if(line.contains(".ForeColor")) {
			line = Util.addComment(line);
		} else if(line.contains("Columns.Get(") && line.contains(".Width") &&  line.trim().endsWith("F;")) {
			line = line.replace("F;", ";");
		} else if(line.contains(".Anchor")) {
			line = Util.addComment(line);
		} else if(line.trim().endsWith("F;")) {
			line = line.replace("F;", ";");
		} else if(line.trim().endsWith("D;")) {
			line = line.replace("D;", ";");
		} 
		
		if (line.contains("AddRange")) {
			if (line.contains("new SheetView[]")) {
				String startBlank = Util.makeStartBlank(line);
				if (noBlankLine.trim().endsWith(");")) {
					line = startBlank + line.trim();
				} else {
					line = startBlank + line.trim();
				}
				line = line.replace("new SheetView[]", "");
				line = line.replace("AddRange( ", "AddRange(");
			}
		}				
		
		
		return line;
	}	
	

	

}