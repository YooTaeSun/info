using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lime.BusinessControls;
using Lime.Framework;
using Lime.Framework.Controls;

namespace Lime.PA
{
    public class clsPACheckCommon
    {
        public bool Check_CFSC_RGNO_V4_Adms(string insnTycd, string asstTycd, string cfscRgno, ref string msg)
        {
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            // 건강보험 + 유형보조V4인 경우, 
            // 산정특례기호에 F018/V247/V248/V249/V250 이외의 기호가 적혀있는 경우 메시지를 띄운다.
            // 2020-12-29 SJH V305/V306 추가 (2021-01-01 ~)
            // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

            if (!insnTycd.Equals("11"))
                return true;

            if (!asstTycd.Equals("V4"))
                return true;

            if (!cfscRgno.Equals("F018") && !cfscRgno.Equals("V247") && !cfscRgno.Equals("V248") && !cfscRgno.Equals("V249") && !cfscRgno.Equals("V250") &&
                !cfscRgno.Equals("V305") && !cfscRgno.Equals("V306"))
            {
                msg = "건강보험 + 중증화상(V4)인 경우,\r\n산정특례기호에 아래 중 하나가 선택되어야 합니다.\r\n\r\n  F018/V247/V248/V249/V250/V305/V306";

                return false;
            }

            return true;
        }

        public bool Check_CFSC_RGNO_V4_AdmsAll(string pid, string ptcmhsno, ref string msg)
        {
            DataTable dt = new DataTable();

            string sqltext = string.Format(@"
    SELECT *
      FROM PAIPCHMA
     WHERE PID               = '{0}'
       AND PT_CMHS_NO        =  {1}
       AND NVL(DRG_YN, 'N') <> 'Y'
       AND INSN_TYCD         = '11'
       AND ASST_TYCD         = 'V4'
       AND NVL(CFSC_RGNO, 'NO') NOT IN ('F018', 'V247', 'V248', 'V249', 'V250', 'V305', 'V306') ", pid, ptcmhsno);

            DBService.ExecuteDataTable(sqltext, ref dt);

            if (dt.Rows.Count.Equals(0))
                return true;

            string msgFormat = "입원정보변경({0}~{1}) 기간에 산정특례기호가 잘 못 입력되었습니다. 건강보험 + 중증화상(V4)인 경우, 산정특례기호에 F018/V247/V248/V249/V250/V305/V306 중에 하나를 선택해야 합니다. (현재 입력된 산정특례기호 : {2})";
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                msg += string.Format("{0}{1}", msg.Equals(string.Empty) ? "" : "\r\n"
                                             , string.Format(msgFormat, DateTimeService.ConvertDateTime(dt.Rows[i]["APLY_STRT_DD"].ToString()).ToString("yyyy-MM-dd"), DateTimeService.ConvertDateTime(dt.Rows[i]["APLY_END_DD"].ToString()).ToString("yyyy-MM-dd"), dt.Rows[i]["CFSC_RGNO"].ToString()));
            }

            return false;
        }

        public static bool CheckSpclDcntAmt(LxTextBox spcl_dcnt_amt)
        {
            double spcldcntamt = 0;
            double.TryParse(spcl_dcnt_amt.Text.Replace(",", ""), out spcldcntamt);

            if (spcldcntamt - (Math.Truncate(spcldcntamt / 10) * 10) != 0)
            {
                LxMessage.ShowError("할인금액은 1원단위가 아닌 10원 단위로 입력해 주세요!!!");
                return false;
            }

            return true;
        }

    }
}
