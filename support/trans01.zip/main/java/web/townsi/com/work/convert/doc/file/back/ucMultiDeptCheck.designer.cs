namespace Lime.BusinessControls
{
    partial class ucMultiDeptCheck
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            this.cboMultiDeptCheck = new Lime.Framework.Controls.LxComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.cboMultiDeptCheck)).BeginInit();
            this.SuspendLayout();
            // 
            // cboMultiDeptCheck
            // 
            appearance1.BackColor = System.Drawing.Color.White;
            appearance1.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance1.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboMultiDeptCheck.Appearance = appearance1;
            this.cboMultiDeptCheck.BackColor = System.Drawing.Color.White;
            this.cboMultiDeptCheck.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance2.BackColor = System.Drawing.Color.Transparent;
            appearance2.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance2.BorderColor = System.Drawing.Color.Transparent;
            appearance2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance2.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboMultiDeptCheck.ButtonAppearance = appearance2;
            this.cboMultiDeptCheck.CheckedListSettings.CheckBoxStyle = Infragistics.Win.CheckStyle.CheckBox;
            this.cboMultiDeptCheck.CheckedListSettings.EditorValueSource = Infragistics.Win.EditorWithComboValueSource.CheckedItems;
            this.cboMultiDeptCheck.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cboMultiDeptCheck.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboMultiDeptCheck.Location = new System.Drawing.Point(0, 0);
            this.cboMultiDeptCheck.Name = "cboMultiDeptCheck";
            appearance3.BackColor = System.Drawing.Color.White;
            appearance3.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance3.ForeColor = System.Drawing.Color.DarkGray;
            appearance3.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboMultiDeptCheck.NullTextAppearance = appearance3;
            this.cboMultiDeptCheck.SelectedValue = "";
            this.cboMultiDeptCheck.Size = new System.Drawing.Size(232, 18);
            this.cboMultiDeptCheck.TabIndex = 0;
            this.cboMultiDeptCheck.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboMultiDeptCheck.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboMultiDeptCheck.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // ucMultiDeptCheck
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cboMultiDeptCheck);
            this.Name = "ucMultiDeptCheck";
            this.Size = new System.Drawing.Size(232, 19);
            ((System.ComponentModel.ISupportInitialize)(this.cboMultiDeptCheck)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Framework.Controls.LxComboBox cboMultiDeptCheck;
    }
}
