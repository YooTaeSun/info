package web.townsi.com.work.convert.doc;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;

public class DocExcute {

	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();
//	final static String SITE_WEB_ROOT = "D:\\project_java/workspace/zTest/src/web/townsi/com/work/convert/doc/file";
	
	public static List<HashMap> process(String docType) throws Exception {

		List<HashMap> list = new ArrayList<HashMap>();
		
		
		String root = SITE_WEB_ROOT + "/copy";
		String result = SITE_WEB_ROOT;
		
		if (docType.equals("VUE")) {
			result = result + "/vue/"; 
		} else if (docType.equals("TS")) {
			result = result + "/ts/"; 
		}  

		File folder = new File(root);
		File[] listOfFiles = folder.listFiles();
		String content = "";
		String onlyFileNm = "";
		String wfullPath = "";
		String readContent = "";
		HashMap<String, Object> resultMap = null;

		for (File file : listOfFiles) {
			if (file.isFile()) {
				String fileNm = file.getName();
				String rfullPath = file.getPath();
				String ext = FilenameUtils.getExtension(fileNm);
				onlyFileNm  = fileNm.replace(ext, "");
				onlyFileNm = onlyFileNm.replace(".", "");
				List<String> formCompList = null;
				Map<String, String> variMap = null;
				String initCompStr = "";
				String designVeri = "";
				String tagStr = "";
				
				
				if (ext.equals("cs") && !fileNm.endsWith(".designer.cs")) {
					wfullPath = "";
					if (docType.equals("VUE")) {
						resultMap = Design.convertGetDesing(rfullPath, onlyFileNm, result, fileNm, ext);
						
						if (resultMap != null)  {
							
							if (resultMap.get("TYPE_SET") != null) {
								Set<String> TYPE_SET  = (Set<String>) resultMap.get("TYPE_SET");
								formCompList = new ArrayList<String>(TYPE_SET);
							}
							
							if (resultMap.get("INITIALIZE_COMPONENT") != null) {
								initCompStr = (String) resultMap.get("INITIALIZE_COMPONENT");	
							}
							if (resultMap.get("content") != null) {
								designVeri = (String) resultMap.get("content");	
							}
							if (resultMap.get("tagStr") != null) {
								tagStr = (String) resultMap.get("tagStr");;	
							}
							if (resultMap.get("VARI_MAP") != null) {
								variMap = (Map<String, String>) resultMap.get("VARI_MAP");;	
							}
						}
						
						wfullPath = result + fileNm.replace(ext, "vue");	
					} else if (docType.equals("TS")) {
						wfullPath = result + fileNm.replace(ext, "ts");
					}
					
					readContent = FileUtil.readFile(rfullPath);
					
					HashMap<String, String> resultMapContent =  processDetail(docType, readContent, wfullPath, onlyFileNm, formCompList, initCompStr, designVeri, tagStr, variMap);
					for( String strKey : resultMapContent.keySet() ){
						String strValue = resultMapContent.get(strKey);
//						System.out.println( strKey +":"+ strValue );
						
						if (strKey.equals("POP")) {
							HashMap dataMap = new HashMap();
							dataMap.put("csFileNm", fileNm);
							dataMap.put("csFullPath", file.getPath());
							dataMap.put("csStr", readContent);
							wfullPath = SITE_WEB_ROOT + "/pop/"+ onlyFileNm + ".vue";
							dataMap.put("fullPath", wfullPath);
							dataMap.put("str", strValue);
							dataMap.put("kind", "POP");
							list.add(dataMap);
						} else {
							HashMap dataMap = new HashMap();
							dataMap.put("csFileNm", fileNm);
							dataMap.put("csFullPath", file.getPath());
							dataMap.put("csStr", readContent);
							dataMap.put("fullPath", wfullPath);
							dataMap.put("str", strValue);
							dataMap.put("kind", "VUE");
							list.add(dataMap);
						}
					}
				}
			}
		}
		return list;
	}	
	
	
	private static HashMap<String, String> processDetail(
			String docType, String readContent, String wfullPath, String onlyFileNm, List<String> formCompList, 
			String initCompStr, String designVeri, String tagStr, Map<String, String> variMap
		) throws FileNotFoundException {
		
		HashMap<String, String> resultMap = new LinkedHashMap<String, String>();
		
		readContent = readContent.replaceAll("\t", "    ");
		String contentVue = "";
		String content = "";
		String content1 = "";
		String content2 = "";
		String popContent = "";
		String classNm = DocAllLine.getClassNm(readContent, onlyFileNm);
		
		Doc doc = new Doc(docType, classNm);
		content = doc.convert(docType, readContent, onlyFileNm);
		content = DocAllLine.convertAllLine(docType, content);
		content = DocAllLine.removeLargeBracket(content, docType);
		
		if (docType.equals("VUE")) {
			
			content1 = DocImport.addImport(content, docType, formCompList, initCompStr, designVeri, tagStr, variMap);
			resultMap.put("VUE", writeFile(wfullPath, content1));
			
			content2 = DocImport.addImport(content, "POP", formCompList, initCompStr, designVeri, tagStr, variMap);
//			wfullPath = result + fileNm.replace(ext, "ts");
			wfullPath = SITE_WEB_ROOT + "/pop/"+ onlyFileNm + ".vue";
			resultMap.put("POP", writeFile(wfullPath, content2));
			
		} else if (docType.equals("TS")) {
			content = DocImport.addImport(content, docType, formCompList, initCompStr, designVeri, tagStr, variMap);
			String reusltStr = writeFile(wfullPath, content);
			resultMap.put("TS", reusltStr);
		}
		
		return resultMap;
	}


	private static String writeFile(String wfullPath, String content) {
		File dic = new File(wfullPath.substring(0, wfullPath.lastIndexOf("/")));
		String dirPath = dic.getPath();
		if (dic.exists()) {
//			System.out.println(dirPath + " 디렉토리 있음");
		} else {
			dic.mkdirs();
//			System.out.println(dirPath + " 디렉토리 생성");
		}
		
		
		String reusltStr = FileUtil.writeFile(wfullPath, content);
		return reusltStr;
	}
	
	public static void main(String[] args) {
		try {
			List<HashMap> listTs = DocExcute.process("TS");
			List<HashMap> vueTs = DocExcute.process("VUE");
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}