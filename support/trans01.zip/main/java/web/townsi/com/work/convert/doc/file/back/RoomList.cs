using System;
using System.Data;

using SQL = Lime.Framework.DataListService.Sql;

namespace Lime.Framework
{
    /// <summary>
    /// Room List Class
    /// </summary>
    public class RoomList
    {
        #region Define : Member

        private static DataTable m_dtList = new DataTable();
        private static bool m_Initialized = false;

        #endregion

        #region Property : Member Property

        public static DataTable ListTable
        {
            get
            {
                if (!m_Initialized)
                    SelectList();

                return m_dtList.Copy();
            }

            set
            {
                m_dtList = value;
            }
        }

        #endregion

        #region Method : Initialize Method

        public static void Clear()
        {
            m_dtList = new DataTable();

            m_Initialized = false;
        }

        #endregion

        #region Method : Get/Set Data Method

        /// <summary>
        /// 병실명 조회
        /// </summary>
        /// <param name="code"></param>
        /// <param name="nametype"></param>
        /// <returns>string</returns>
        public static string GetName(string code)
        {
            if (!m_Initialized)
                SelectList();

            foreach (DataRow row in m_dtList.Select("ROOM_CD = '" + code + "'"))
            {
                return row["ROOM_NM"].ToString().Trim();
            }

            return "";
        }

        /// <summary>
        /// 병실코드 조회
        /// </summary>
        /// <param name="name"></param>
        /// <returns>string</returns>
        public static string GetCode(string name)
        {
            if (!m_Initialized)
                SelectList();

            foreach (DataRow row in m_dtList.Select("ROOM_NM  = '" + name + "'"))
            {
                return row["ROOM_CD"].ToString().Trim();
            }

            return "";
        }

        /// <summary>
        /// 병동코드 조회
        /// </summary>
        /// <param name="roomcode"></param>
        /// <returns>string</returns>
        public static string GetWardCocd(string roomcode)
        {
            if (!m_Initialized)
                SelectList();

            foreach (DataRow row in m_dtList.Select("ROOM_CD = '" + roomcode + "'"))
            {
                return row["WARD_CD"].ToString().Trim();
            }

            return "";
        }

        /// <summary>
        /// 병동명 조회
        /// </summary>
        /// <param name="roomcode"></param>
        /// <returns>string</returns>
        public static string GetWardName(string roomcode)
        {
            if (!m_Initialized)
                SelectList();

            foreach (DataRow row in m_dtList.Select("ROOM_CD = '" + roomcode + "'"))
            {
                return row["WARD_NM"].ToString().Trim();
            }

            return "";
        }

        /// <summary>
        /// 병동 정보중 지정한 컬럼의 정보 조회
        /// </summary>
        /// <param name="code"></param>
        /// <param name="columnname"></param>
        /// <returns>object</returns>
        public static object GetColumnValue(string roomcode, string columnname)
        {
            if (!m_Initialized)
                SelectList();

            foreach (DataRow row in m_dtList.Select("ROOM_CD = '" + roomcode + "'"))
            {
                return row[columnname];
            }

            return "";
        }

        #endregion

        #region Method : Get Data List

        /// <summary>
        /// 병실 목록 조회
        /// </summary>
        /// <param name="additemtype"></param>
        /// <returns>string</returns>
        public static DataTable GetDataList(COMBO_ADD_ITEM_TYPE additemtype = COMBO_ADD_ITEM_TYPE.None)
        {
            if (!m_Initialized)
                SelectList();

            DataTable dt = m_dtList.Copy();

            if (!additemtype.Equals(COMBO_ADD_ITEM_TYPE.None))
                dt = AddComboItem(dt, additemtype);

            return dt;
        }

        /// <summary>
        /// 병동별 병실 목록 조회
        /// </summary>
        /// <param name="wardcode"></param>
        /// <param name="additemtype"></param>
        /// <returns>string</returns>
        public static DataTable GetDataList(string wardcode, COMBO_ADD_ITEM_TYPE additemtype = COMBO_ADD_ITEM_TYPE.None)
        {
            if (!m_Initialized)
                SelectList();

            DataTable dt = new DataTable();

            try
            {
                if (m_dtList.Rows.Count > 0)
                {
                    if (StringService.IsNull(wardcode) || wardcode.Equals(DataType.COMBO_ADD_ITEM_TYPE_CODE_ALL))
                    {
                        dt = m_dtList.Copy();
                    }
                    else
                    {
                        dt = m_dtList.Clone();

                        //해당 병동의 병실 리스트를 만든다.
                        foreach (DataRow row in m_dtList.Select("WARD_CD = '" + wardcode + "'"))
                        {
                            dt.ImportRow(row);
                        }
                    }

                    if (!additemtype.Equals(COMBO_ADD_ITEM_TYPE.None))
                        dt = AddComboItem(dt, additemtype);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return dt;
        }

        private static DataTable AddComboItem(DataTable dt, COMBO_ADD_ITEM_TYPE additemtype = COMBO_ADD_ITEM_TYPE.None)
        {
            try
            {
                //전체/없음 추가.
                if (!additemtype.Equals(COMBO_ADD_ITEM_TYPE.None))
                {
                    DataRow newrow = dt.NewRow();
                    newrow["WARD_CD"] = (additemtype.Equals(COMBO_ADD_ITEM_TYPE.AddAll) ? DataType.COMBO_ADD_ITEM_TYPE_CODE_ALL : DataType.COMBO_ADD_ITEM_TYPE_CODE_NONE);
                    newrow["ROOM_CD"] = (additemtype.Equals(COMBO_ADD_ITEM_TYPE.AddAll) ? DataType.COMBO_ADD_ITEM_TYPE_CODE_ALL : DataType.COMBO_ADD_ITEM_TYPE_CODE_NONE);
                    newrow["ROOM_NM"] = (additemtype.Equals(COMBO_ADD_ITEM_TYPE.AddAll) ? DataType.COMBO_ADD_ITEM_TYPE_STRING_ALL : DataType.COMBO_ADD_ITEM_TYPE_STRING_NONE);
                    dt.Rows.InsertAt(newrow, 0);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return dt;
        }

        #endregion

        #region Method : Load Data Method

        /// <summary>
        /// Load list
        /// </summary>
        /// <returns></returns>
        public static DataTable LoadList()
        {
            SelectList();

            return m_dtList;
        }

        /// <summary>
        /// Select list
        /// </summary>
        private static void SelectList()
        {
            if (ClientEnvironment.DesignMode)
                return;

            try
            {
                m_dtList = new DataTable();

                DBService.ExecuteDataTable(SQL.SelectBIROOMMA(), ref m_dtList);

                m_Initialized = true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        #endregion
    }
}
