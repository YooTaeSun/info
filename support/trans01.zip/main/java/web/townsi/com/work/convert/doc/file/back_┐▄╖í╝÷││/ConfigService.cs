using System;
using System.Data;
using System.Drawing;
using SQL = Lime.Framework.Config.Sql;

namespace Lime.Framework
{
    /// <summary>
    /// Config Service
    /// </summary>
    public class ConfigService : IDisposable
    {
        #region Define : Member

        //Config Master
        private static System.Data.DataTable m_ConfigList = new DataTable();

        //초기화 여부
        private static bool m_Initialized = false;

        #endregion

        #region Property : Member Property

        public static DataTable ConfigList
        {
            get
            {
                if (!m_Initialized)
                    SelectList();

                return m_ConfigList;
            }
            set
            {
                m_ConfigList = value;
            }
        }

        public static bool IsLoaded
        {
            get
            {
                return m_Initialized;
            }
        }

        #endregion

        #region Dispose

        // Flag: Has Dispose already been called?
        private bool disposed = false;


        // Public implementation of Dispose pattern callable by consumers.
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // Protected implementation of Dispose pattern.
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Free any other managed objects here.
                if (m_ConfigList != null)
                    m_ConfigList.Dispose();
            }

            // Free any unmanaged objects here.

            disposed = true;
        }

        ~ConfigService()
        {
            Dispose(false);
        }

        #endregion


        #region Method : Initialize 

        /// <summary>
        /// 기초코드마스터 초기화
        /// </summary>
        public static void Clear()
        {
            m_ConfigList.Clear();

            m_Initialized = false;
        }

        #endregion

        #region Method : Get Value Method

        public static string GetConfigValueString(string systemcd, string configtype, string configcode, string defaultvalue = "")
        {
            string cvalue = GetConfigValue(systemcd, configtype, configcode);
            string rvalue = defaultvalue;

            if (StringService.IsNotNull(cvalue))
                rvalue = cvalue;

            return rvalue;
        }

        public static bool GetConfigValueBool(string systemcd, string configtype, string configcode, bool defaultvalue = false)
        {
            string cvalue = GetConfigValue(systemcd, configtype, configcode);
            bool rvalue = defaultvalue;

            try
            {
                if (StringService.IsNotNull(cvalue))
                {
                    if (!bool.TryParse(cvalue, out rvalue))
                    {
                        switch (cvalue.ToUpper())
                        {
                            case "TRUE":
                            case "T":
                            case "YES":
                            case "Y":
                            case "1":
                                rvalue = true;
                                break;
                            case "FALSE":
                            case "F":
                            case "NO":
                            case "N":
                            case "0":
                            case "-1":
                                rvalue = false;
                                break;

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return rvalue;
        }

        public static byte GetConfigValueByte(string systemcd, string configtype, string configcode, byte defaultvalue = 0)
        {
            string cvalue = GetConfigValue(systemcd, configtype, configcode);
            byte rvalue = defaultvalue;

            try
            {
                if (StringService.IsNotNull(cvalue))
                    byte.TryParse(cvalue, out rvalue);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return rvalue;
        }

        public static short GetConfigValueShort(string systemcd, string configtype, string configcode, short defaultvalue = 0)
        {
            string cvalue = GetConfigValue(systemcd, configtype, configcode);
            short rvalue = defaultvalue;

            try
            {
                if (StringService.IsNotNull(cvalue))
                    short.TryParse(cvalue, out rvalue);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return rvalue;
        }

        public static int GetConfigValueInt(string systemcd, string configtype, string configcode, int defaultvalue = 0)
        {
            string cvalue = GetConfigValue(systemcd, configtype, configcode);
            int rvalue = defaultvalue;

            try
            {
                if (StringService.IsNotNull(cvalue))
                    int.TryParse(cvalue, out rvalue);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return rvalue;
        }

        public static long GetConfigValueLong(string systemcd, string configtype, string configcode, long defaultvalue = 0L)
        {
            string cvalue = GetConfigValue(systemcd, configtype, configcode);
            long rvalue = defaultvalue;

            try
            {
                if (StringService.IsNotNull(cvalue))
                    long.TryParse(cvalue, out rvalue);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return rvalue;
        }

        public static decimal GetConfigValueDecimal(string systemcd, string configtype, string configcode, decimal defaultvalue = 0m)
        {
            string cvalue = GetConfigValue(systemcd, configtype, configcode);
            decimal rvalue = defaultvalue;

            try
            {
                if (StringService.IsNotNull(cvalue))
                    decimal.TryParse(cvalue, out rvalue);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return rvalue;
        }

        public static float GetConfigValueFloat(string systemcd, string configtype, string configcode, float defaultvalue = 0F)
        {
            string cvalue = GetConfigValue(systemcd, configtype, configcode);
            float rvalue = defaultvalue;

            try
            {
                if (StringService.IsNotNull(cvalue))
                    float.TryParse(cvalue, out rvalue);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return rvalue;
        }

        public static double GetConfigValueDouble(string systemcd, string configtype, string configcode, double defaultvalue = 0D)
        {
            string cvalue = GetConfigValue(systemcd, configtype, configcode);
            double rvalue = defaultvalue;

            try
            {
                if (StringService.IsNotNull(cvalue))
                    double.TryParse(cvalue, out rvalue);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return rvalue;
        }

        public static DateTime GetConfigValueDateTime(string systemcd, string configtype, string configcode, DateTime defaultdatetime)
        {
            string cvalue = GetConfigValue(systemcd, configtype, configcode);
            DateTime rvalue = defaultdatetime;

            try
            {
                if (StringService.IsNotNull(cvalue))
                    rvalue = DateTimeService.ConvertDateTime(cvalue);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return rvalue;
        }

        public static Color GetConfigValueColor(string systemcd, string configtype, string configcode, Color defaultcolor)
        {
            string cvalue = GetConfigValue(systemcd, configtype, configcode);
            Color rvalue = defaultcolor;

            try
            {
                if (StringService.IsNotNull(cvalue))
                    return DataTypeConverter.ConvertColor(cvalue, defaultcolor);

            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return rvalue;
        }

        public static object GetConfigValueEnum(string systemcd, string configtype, string configcode, Type enumtype, object defaultvalue)
        {
            string cvalue = GetConfigValue(systemcd, configtype, configcode);
            object rvalue = defaultvalue;

            try
            {
                if (StringService.IsNotNull(cvalue))
                    rvalue = Enum.Parse(enumtype, cvalue, true);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return rvalue;
        }

        /// <summary>
        /// Get Config Value
        /// </summary>
        /// <param name="configtype"></param>
        /// <param name="configcode"></param>
        /// <returns>string</returns>
        private static string GetConfigValue(string systemcd, string configtype, string configcode)
        {
            if (!DBService.Connected)
                return "";

            if (!m_Initialized)
                SelectList();

            try
            {
                //환경설정 값을 검색하여 리턴한다.
                foreach (DataRow row in m_ConfigList.Select(string.Format("SYSTEM_CD = '{0}' AND CONF_TYPE = '{1}' AND CONF_CD = '{2}'", systemcd.ToUpper(), configtype.ToUpper(), configcode.ToUpper())))
                {
                    //암호화 되어 있는 경우 디코딩하여 리턴한다.
                    if (row["ECPT_YN"].ToString().Equals("Y"))
                        return EncryptionService.Decoding(row["CONF_VAL"].ToString().Trim());
                    else
                        return row["CONF_VAL"].ToString().Trim();
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return "";
        }

        #endregion

        #region Method : Get Data List

        /// <summary>
        /// Select Config Value List
        /// </summary>
        /// <param name="systemcd"></param>
        /// <returns></returns>
        public static DataTable GetConfigList(string systemcd)
        {
            DataTable dt = m_ConfigList.Clone();

            if (ClientEnvironment.DesignMode)
                return dt;

            if (!m_Initialized)
                SelectList();

            try
            {
                foreach (DataRow row in m_ConfigList.Select(string.Format("SYSTEM_CD = '%' OR SYSTEM_CD = '{0}'", systemcd)))
                {
                    dt.ImportRow(row);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return dt;
        }

        /// <summary>
        /// Select Config Value List
        /// </summary>
        /// <param name="systemcd"></param>
        /// <param name="configtype"></param>
        /// <returns></returns>
        public static DataTable GetConfigList(string systemcd, string configtype)
        {
            DataTable dt = m_ConfigList.Clone();

            if (ClientEnvironment.DesignMode)
                return dt;

            if (!m_Initialized)
                SelectList();

            try
            {
                foreach (DataRow row in m_ConfigList.Select(string.Format("SYSTEM_CD = '{0}' AND CONF_TYPE = '{1}'", systemcd, configtype)))
                {
                    dt.ImportRow(row);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return dt;
        }

        #endregion

        #region Method : Select Config Master

        public static void Load()
        {
            SelectList();
        }

        /// <summary>
        /// Select Config Master
        /// </summary>
        public static void SelectList()
        {
            try
            {
                m_ConfigList = new DataTable();

                //Select
                DBService.QueryWritable = false;
                if (DBService.ExecuteDataTable(SQL.SelectConfigList(), ref m_ConfigList))
                {
                    m_Initialized = true;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                m_Initialized = false;
            }
        }

        public static string GetConfigValueDirect(string system_cd, string conf_type, string conf_cd, string default_value = "", string aply_dd = "")
        {
            aply_dd = string.IsNullOrWhiteSpace(aply_dd) ? DateTime.Today.ToString("yyyyMMdd") : aply_dd;

            string value = DBService.ExecuteScalar($"select fn_ad_read_adconfdt('{system_cd}', '{conf_type}', '{conf_cd}', '{aply_dd}') from dual").ToString();

            if (string.IsNullOrEmpty(value) || value == "*")
                value = default_value;

            return value;
        }

        public static T GetConfigValueDirect<T>(string system_cd, string conf_type, string conf_cd, T defaultValue = default, string aply_dd = "") where T : struct
        {
            T value = defaultValue;

            try
            {
                string dbValue = GetConfigValueDirect(system_cd, conf_type, conf_cd, "", aply_dd);

                if (!string.IsNullOrWhiteSpace(dbValue))
                {
                    //(T)Convert.ChangeType(dbValue, typeof(T));
                    if (typeof(T) == typeof(string))
                    {
                        value = (T)(object)dbValue;
                    }
                    else if (typeof(T) == typeof(bool))
                    {
                        switch (dbValue.ToUpper())
                        {
                            case "TRUE":
                            case "T":
                            case "YES":
                            case "Y":
                            case "1":
                                value = (T)(object)true;
                                break;

                            case "FALSE":
                            case "F":
                            case "NO":
                            case "N":
                            case "0":
                            case "-1":
                                value = (T)(object)false;
                                break;
                        }
                    }
                    else if (typeof(T) == typeof(byte))
                    {
                        if (byte.TryParse(dbValue, out byte byteValue))
                            value = (T)(object)byteValue;
                    }
                    else if (typeof(T) == typeof(short))
                    {
                        if (short.TryParse(dbValue, out short shortValue))
                            value = (T)(object)shortValue;
                    }
                    else if (typeof(T) == typeof(int))
                    {
                        if (int.TryParse(dbValue, out int intValue))
                            value = (T)(object)intValue;
                    }
                    else if (typeof(T) == typeof(long))
                    {
                        if (long.TryParse(dbValue, out long longValue))
                            value = (T)(object)longValue;
                    }
                    else if (typeof(T) == typeof(decimal))
                    {
                        if (decimal.TryParse(dbValue, out decimal decimalValue))
                            value = (T)(object)decimalValue;
                    }
                    else if (typeof(T) == typeof(float))
                    {
                        if (float.TryParse(dbValue, out float floatValue))
                            value = (T)(object)floatValue;
                    }
                    else if (typeof(T) == typeof(double))
                    {
                        if (double.TryParse(dbValue, out double doubleValue))
                            value = (T)(object)doubleValue;
                    }
                    else if (typeof(T) == typeof(DateTime))
                    {
                        if (DateTimeService.IsDateTime(dbValue))
                            value = (T)(object)DateTimeService.ConvertDateTime(dbValue);
                    }
                    else if (typeof(T) == typeof(Color))
                    {
                        value = (T)(object)DataTypeConverter.ConvertColor(dbValue);
                    }
                    else if (typeof(T)?.BaseType == typeof(Enum))
                    {
                        if (Enum.TryParse(dbValue, out T enumValue))
                            value = enumValue;
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return value;
        }

        public static DataTable GetConfigListDirect(string system_cd, string conf_type = "")
        {
            DataTable dt = new DataTable();

            try
            {
                if (!DBService.ExecuteDataTable(SQL.SelectConfigList(system_cd, conf_type), ref dt))
                    throw new Exception($"[{DBService.ErrorCode}] {DBService.ErrorMessage}");
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return dt;
        }

        #endregion

        #region Save Config Master

        ///// <summary>
        ///// Save Config Master
        ///// </summary>
        ///// <param name="configtype"></param>
        ///// <param name="configkey"></param>
        ///// <param name="configvalue"></param>
        ///// <param name="userid"></param>
        ///// <returns></returns>
        //public static bool SaveConfigMaster(string configtype, string configtype, string configcode, string configvalue, string userid)
        //{
        //    return SaveConfigMaster(configtype, configkey, configvalue, true, userid);
        //}

        ///// <summary>
        ///// Save Config Master
        ///// </summary>
        ///// <param name="configtype"></param>
        ///// <param name="configkey"></param>
        ///// <param name="configvalue"></param>
        ///// <param name="enable"></param>
        ///// <param name="userid"></param>
        ///// <returns></returns>
        //public static bool SaveConfigMaster(string configtype, string configtype, string configcode, string configvalue, bool enable, string userid)
        //{
        //    DataTable baseconfigtable = new DataTable();

        //    try
        //    {
        //        if (DBService.ExecuteDataTable(SQL.Framework.Config.SelectConfig(), ref baseconfigtable, configtype, configkey))
        //        {
        //            if (baseconfigtable.Rows.Count > 0 && !DBService.HasError)
        //            {
        //                if (DBService.ExecuteNonQuery(SQL.Framework.Config.UpdateConfig()
        //                    , configtype
        //                    , configkey
        //                    , baseconfigtable.Rows[0]["STARTDATE"].ToString()
        //                    , configvalue
        //                    , (enable ? "NULL" : "SYSDATE")
        //                    , userid))
        //                {
        //                    return true;
        //                }
        //            }
        //            else
        //            {
        //                if (DBService.ExecuteNonQuery(SQL.Framework.Config.InsertConfig()
        //                    , configtype
        //                    , configkey
        //                    , configvalue
        //                    , baseconfigtable.Rows[0]["STARTDATE"].ToString()
        //                    , (enable ? "NULL" : "SYSDATE")
        //                    , userid))
        //                {
        //                    return true;
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        LogService.ErrorLog(ex);
        //    }

        //    return false;
        //}

        #endregion
    }
}
