//********************************************************************************
// Class 명 : ucfPrftCdInfo
// 역    할 : 수익코드관리 화면
// 작 성 자 : 유진호
// 작 성 일 : 2017-07-20
//********************************************************************************
// 수정내역 : 2017-08-02 : 유진호 :
//           2018-03-15 : 이기승
// 2021-11-29 SJH
//********************************************************************************
using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.BI
{
    public partial class ucfPrftCdInfo : BaseUCF_TP
    {
        #region Define : Member

        private enum COL
        {
            PRFT_CD,             // 수익코드
            PRFT_CDNM,           // 수익코드명
            DCNT_AGRG_CLSF_CD,   // 할인코드
            PRFT_AGRG_CD_1,      // 수익집계코드1
            PRFT_AGRG_CD_2,      // 수익집계코드2
            PRFT_AGRG_CD_3,      // 수익집계코드3
            BILL_LCTN,           // 영수증위치
        }

        #endregion Define : Member

        #region Construction

        public ucfPrftCdInfo()
        {
            InitializeComponent();
        }

        #endregion Construction

        #region Screen Load

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode)
                return;

            Initialize();

            SelectData();
        }

        #endregion Screen Load

        #region Method : Initialize Method

        private void Initialize()
        {
            try
            {
                cboSearch.SelectedValue = "%";

                btnList.ButtonItems.Clear();
                btnList.ButtonItems.Add(ButtonType.Select, "조 회");
                btnList.ButtonItems.Add(ButtonType.Append, "추 가");
                btnList.ButtonItems.Add(ButtonType.Save, "저 장");
                btnList.ButtonItems.Add(ButtonType.Delete, "삭 제");
                btnList.ButtonItems.Add(ButtonType.Close, "닫 기");
                btnList.InitializeButtons();

                txtSearch.NullText = "수익코드 또는 수익코드명으로 검색";
                txtSearch.NullTextAppearance.ForeColor = System.Drawing.Color.Silver;
                txtSearch.Text = string.Empty;

                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.BI.Sql.SelectBIDCCDMA_CDNM(), ref dt))
                    throw new Exception("할인코드를 조회하는 중 에러가 발생했습니다.");

                sprMaster.SetComboItems((int)COL.DCNT_AGRG_CLSF_CD, dt, COMBO_ADD_ITEM_TYPE.None);

                cboSearch.ValueChanged += (s, e) => txtSearch.Focus();
                txtSearch.KeyDown += (s, e) =>
                {
                    if (e.KeyCode == Keys.Enter)
                        SelectData();
                };
                btnList.ButtonClick += BtnList_ButtonClick;
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        #endregion Method : Initialize Method

        #region Method : Private Method

        private void SelectData(string prft_cd = "")
        {
            try
            {
                sprMaster.ActiveSheet.Rows.Count = 0;

                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.BI.Sql.SelectBIPRCDMA(cboSearch.SelectedValue, txtSearch.Text.ToUpper()), ref dt))
                    throw new Exception("수익코드를 조회하는 중 에러가 발생했습니다.");

                sprMaster.FillDataTag(dt);

                if (!string.IsNullOrWhiteSpace(prft_cd))
                {
                    var temp = dt.AsEnumerable().Where(r => r["PRFT_CD"].ToString().Equals(prft_cd));
                    if (temp.Any())
                    {
                        int i = temp.Select(r => r.Table.Rows.IndexOf(r)).FirstOrDefault();
                        sprMaster.SetActiveCell(i, (int)COL.PRFT_CD, FarPoint.Win.Spread.VerticalPosition.Nearest, FarPoint.Win.Spread.HorizontalPosition.Nearest);
                    }
                }
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        private void AppendData()
        {
            sprMaster.AppendRow();
        }

        private bool Validation()
        {
            for (int i = 0; i < sprMaster.ActiveSheet.Rows.Count ; i++)
            {
                if (!new CRUD_TYPE[] { CRUD_TYPE.Create, CRUD_TYPE.Update }.Any(r => r.Equals(sprMaster.GetCRUDFromRow(i))))
                    continue;

                if (string.IsNullOrWhiteSpace(sprMaster.GetValue(i, (int)COL.PRFT_CD).ToString()))
                {
                    LxMessage.ShowError("수익코드를 입력해 주세요.");
                    sprMaster.SetActiveCell(i, (int)COL.PRFT_CD, FarPoint.Win.Spread.VerticalPosition.Nearest, FarPoint.Win.Spread.HorizontalPosition.Nearest);
                    return false;
                }

                if (string.IsNullOrWhiteSpace(sprMaster.GetValue(i, (int)COL.PRFT_CDNM).ToString()))
                {
                    LxMessage.ShowError("수익코드명을 입력해 주세요.");
                    sprMaster.SetActiveCell(i, (int)COL.PRFT_CDNM, FarPoint.Win.Spread.VerticalPosition.Nearest, FarPoint.Win.Spread.HorizontalPosition.Nearest);
                    return false;
                }
            }

            return true;
        }

        private void SaveData()
        {
            try
            {
                if (!sprMaster.IsModified())
                    return;

                if (!Validation())
                    return;

                int a = sprMaster.ActiveSheet.ActiveRowIndex;
                string prft_cd = sprMaster.GetValue(a, "PRFT_CD").ToString();

                DBService.BeginTransaction();

                for (int i = 0; i < sprMaster.ActiveSheet.Rows.Count; i++)
                {
                    string dcnt_agrg_clsf_cd = sprMaster.GetValue(i, "DCNT_AGRG_CLSF_CD").ToString();
                    dcnt_agrg_clsf_cd = dcnt_agrg_clsf_cd.Equals("NO") ? string.Empty : dcnt_agrg_clsf_cd;

                    if (sprMaster.GetCRUDFromRow(i) == CRUD_TYPE.Create)
                    {
                        if (!DBService.ExecuteNonQuery(SQL.BI.Sql.InsertBiprcdma(), sprMaster.GetValue(i, "PRFT_CD").ToString()
                                                                                          , sprMaster.GetValue(i, "PRFT_CDNM").ToString()
                                                                                          , dcnt_agrg_clsf_cd
                                                                                          , sprMaster.GetValue(i, "PRFT_AGRG_CD_1").ToString()
                                                                                          , sprMaster.GetValue(i, "PRFT_AGRG_CD_2").ToString()
                                                                                          , sprMaster.GetValue(i, "PRFT_AGRG_CD_3").ToString()
                                                                                          , sprMaster.GetValue(i, "BILL_LCTN").ToString()
                                                                                          , ""
                                                                                          , ""
                                                                                          , ""
                                                                                          , DOPack.UserInfo.USER_CD))
                            throw new Exception("수익코드를 저장하는 중 에러가 발생했습니다.");

                    }
                    else if (sprMaster.GetCRUDFromRow(i) == CRUD_TYPE.Update)
                    {
                        if (!DBService.ExecuteNonQuery(SQL.BI.Sql.UpdateBiprcdma(), sprMaster.GetValue(i, "PRFT_CD").ToString()
                                                                                  , sprMaster.GetValue(i, "PRFT_CDNM").ToString()
                                                                                  , dcnt_agrg_clsf_cd
                                                                                  , sprMaster.GetValue(i, "PRFT_AGRG_CD_1").ToString()
                                                                                  , sprMaster.GetValue(i, "PRFT_AGRG_CD_2").ToString()
                                                                                  , sprMaster.GetValue(i, "PRFT_AGRG_CD_3").ToString()
                                                                                  , sprMaster.GetValue(i, "BILL_LCTN").ToString()
                                                                                  , DOPack.UserInfo.USER_CD
                                                                                  , sprMaster.GetOldValue(i, "PRFT_CD").ToString()))
                            throw new Exception("수익코드를 저장하는 중 에러가 발생했습니다.");
                    }
                }

                DBService.CommitTransaction();

                LxMessage.ShowInformation("저장 되었습니다.", 3);

                SelectData(prft_cd);
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                if (DBService.IsTransaction)
                    DBService.RollbackTransaction();

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        private void DeleteData()
        {
            try
            {
                int i = sprMaster.ActiveSheet.ActiveRowIndex;
                if (i < 0)
                    return;

                if (sprMaster.GetCRUDFromRow() == CRUD_TYPE.Create)
                {
                    sprMaster.RemoveRow(i);
                    return;
                }

                if (!LxMessage.ShowQuestion("삭제 하시겠습니까?").Equals(DialogResult.Yes))
                    return;

                if (!DBService.ExecuteNonQuery(SQL.BI.Sql.DeleteBiprcdma(), sprMaster.GetOldValue("PRFT_CD").ToString()))
                    throw new Exception("수익코드를 삭제하는 중 에러가 발생했습니다.");

                SelectData();
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        #endregion Method : Private Method

        #region Event : Event Process

        private void BtnList_ButtonClick(object sender, ButtonClickEventArgs e)
        {
            switch (e.ButtonType)
            {
                case ButtonType.Select:
                    SelectData();
                    break;

                case ButtonType.Append:
                    AppendData();
                    break;

                case ButtonType.Save:
                    SaveData();
                    break;

                case ButtonType.Delete:
                    DeleteData();
                    break;

                case ButtonType.Close:
                    this.Close();
                    break;
            }
        }

        #endregion Event : Event Process
    }
}