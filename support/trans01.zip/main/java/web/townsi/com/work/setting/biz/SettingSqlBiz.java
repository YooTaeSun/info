package web.townsi.com.work.setting.biz;

import java.util.HashMap;
import java.util.List;

public interface SettingSqlBiz {
	public abstract HashMap<String, Object> makeSql(HashMap paramHashMap) throws Exception;
	public abstract HashMap<String, Object> makeDslServiceImpl(HashMap paramHashMap) throws Exception;
}