//********************************************************************************
// Class 명 : DOPatientInfo
// 역    할 : 환자의 정보를 조회하는 Data Object
// 작 성 자 : LDJ
// 작 성 일 : 2017-08-21
//********************************************************************************
// 주    의 : 개발자가 환자정보를 직접 세팅하는 경우 정보 세팅이 완료되었을 때 
//            OnPatientChanged()를 호출하여 환자정보가 변경 되었음을 다른 화면에 
//            알려주어야 한다.
//********************************************************************************
// 수정내역 :
//********************************************************************************
using System;
using System.ComponentModel;
using System.Data;
using SQL = Lime.Framework.DataObject.Sql;

namespace Lime.Framework
{
    /// <summary>
    /// 환자정보
    /// </summary>
    public class DOPatientInfo : ICloneable, IDisposable
    {
        #region Define : Event

        public delegate void PatientChangedEventHandler();
        public event PatientChangedEventHandler PatientChanged;

        #endregion 

        #region Define : Member

        private string m_PID = string.Empty;  //환자등록번호               VARCHAR2(10)  
        private string m_PT_NM = string.Empty;  //환자성명                   VARCHAR2(50)  
        private string m_NICK_NM = string.Empty;  //환자성명2
        private string m_FRRN = string.Empty;  //주민등록앞번호             VARCHAR2(6)   
        private string m_SRRN = string.Empty;  //주민등록뒷번호             VARCHAR2(7)   (1****** 형태의 주민번호 뒷자리)
        private string m_SRRN_ECPT = string.Empty;  //주민등록뒷번호암호화       VARCHAR2(70)  
        private string m_DOBR = string.Empty;  //생년월일                   VARCHAR2(8)   
        private string m_SEX_DVCD = string.Empty;  //성별구분코드               VARCHAR2(1)   
        private int m_AGE = 0;             //나이
        private int m_AGE_YEAR = 0;             //년수
        private int m_AGE_MONTH = 0;             //개월수
        private int m_AGE_WEEK = 0;             //주수
        private int m_AGE_DAY = 0;             //일수
        private string m_FRST_CMHS_DD = string.Empty;  //최초내원일자               VARCHAR2(8)   
        private string m_ADDR_BLDG_NO = string.Empty;  //주소건물번호               VARCHAR2(30)  
        private string m_ADDR_CD = string.Empty;  //주소코드(우편번호)         VARCHAR2(6)   
        private int m_ADDR_SQNO = 0;             //주소일련번호               NUMBER(10)    
        private string m_DETL_ADDR = string.Empty;  //상세주소                   VARCHAR2(200) 
        private string m_ADDRESS_DONG = string.Empty;  //주소(동까지)               VARCHAR2(30)  
        private string m_ADDRESS = string.Empty;  //주소  
        private string m_HOUS_TEL = string.Empty;  //주택전화번호               VARCHAR2(15)
        private string m_CLPH_TEL = string.Empty;  //휴대폰전화번호             VARCHAR2(15)
        private string m_ETC_TEL_1 = string.Empty;  //기타전화번호첫째           VARCHAR2(15)
        private string m_ETC_TEL_2 = string.Empty;  //기타전화번호둘째           VARCHAR2(15)
        private string m_ETC_TEL_3 = string.Empty;  //기타전화번호셋째           VARCHAR2(15)
        private string m_EMAL_ADDR = string.Empty;  //이메일주소                 VARCHAR2(50)
        private string m_PT_DETL_DVCD_1 = string.Empty;  //환자상세구분코드첫째       VARCHAR2(10)
        private string m_PT_DETL_DVCD_2 = string.Empty;  //환자상세구분코드둘째       VARCHAR2(10)
        private string m_PT_DETL_DVCD_3 = string.Empty;  //환자상세구분코드셋째       VARCHAR2(10)
        private string m_PT_DETL_DVCD_4 = string.Empty;  //환자상세구분코드넷째       VARCHAR2(10)
        private string m_PT_DETL_DVCD_5 = string.Empty;  //환자상세구분코드다섯째     VARCHAR2(10)
        private string m_PT_DETL_DVCD_6 = string.Empty;  //환자상세구분코드여섯째     VARCHAR2(10)
        private string m_VTRN_PT_YN = string.Empty;  //보훈환자여부               VARCHAR2(2) 
        private string m_MOMR_AGE_DVCD = string.Empty;  //유공자연령구분코드         VARCHAR2(2) 
        private string m_INDP_MOMR_YN = string.Empty;  //독립유공자여부             VARCHAR2(2) 
        private string m_NATN_CD = string.Empty;  //국가코드                   VARCHAR2(10)
        private string m_INDV_INFO_CNSN_YN = string.Empty;  //개인정보동의여부           VARCHAR2(2) 
        private string m_SMS_CNSN_YN = string.Empty;  //SMS동의여부                VARCHAR2(2) 
        private string m_PTRGRCD_ISSU_YN = string.Empty;  //진찰권발행여부             VARCHAR2(2) 
        private string m_CLUR_DSTG_DVCD = string.Empty;  //장루요루장애대상구분코드   VARCHAR2(2) 
        private string m_UNDN_DVCD = string.Empty;  //신원미상구분코드           VARCHAR2(2) 
        private string m_ITDT_EMNO = string.Empty;  //소개직원번호               VARCHAR2(10)
        private string m_FCLT_APLY_YN = string.Empty;  //시설적용여부               VARCHAR2(2) 
        private string m_FCLT_APLY_DVCD = string.Empty;  //시설적용구분코드           VARCHAR2(10)
        private string m_PT_PCLR_MATR = string.Empty;  //환자특이사항               VARCHAR2(3000)
        private string m_DEL_YN = string.Empty;  //삭제여부                   VARCHAR2(1)
        private string m_DETH_DD = string.Empty;  //사망일자                   VARCHAR2(8)
        private string m_DETH_PLCE_DVCD = string.Empty;  //사망장소구분코드           VARCHAR2(10)
        private string m_FRNR_NM = string.Empty;  //외국인성명                 VARCHAR2(50)
        private string m_PRIVACY = string.Empty;  //개인정보보호 대상자        VARCHAR2(1)
        private string m_INFO_CONSENT = string.Empty;  //개인정보활용동의여부       VARCHAR2(1)

        private string m_ChartIOType = string.Empty;  //차트의 I/O/D/C Type

        /// <summary>
        /// 접수 정보
        /// </summary>
        private DOPatientReceiptInfo m_ReceiptInfo = new DOPatientReceiptInfo();

        #endregion

        #region Property : Member Property

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string PID { get { return m_PID; } set { m_PID = value; } }    //환자등록번호
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string PT_NM { get { return m_PT_NM; } set { m_PT_NM = value; } }    //환자성명                
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string NICK_NM { get { return m_NICK_NM; } set { m_NICK_NM = value; } }    //환자성명2
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string RRN   //주민등록번호(000000-0******)
        {
            get
            {
                return ResidentNumberService.CombineRRNO(m_FRRN, m_SRRN);
            }
            set
            {
                if (StringService.IsNotNull(value) && StringService.IsNumeric(value.Replace("-", "")) && (value.Length == 13 || value.Length == 14))
                    ResidentNumberService.SplitRRNO(value, ref m_FRRN, ref m_SRRN);
            }
        }
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string RRN_ECPT  //복화화된 주민등록번호(000000-0000000)
        {
            get
            {
                return ResidentNumberService.CombineRRNO(m_FRRN, SRRN_ECPT);
            }
            set
            {
                string srrn = "";

                if (StringService.IsNotNull(value) && StringService.IsNumeric(value.Replace("-", "")) && (value.Length == 13 || value.Length == 14))
                {
                    ResidentNumberService.SplitRRNO(value, ref m_FRRN, ref srrn);

                    SRRN_ECPT = srrn;   //인코딩
                }
            }
        }
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string FRRN { get { return m_FRRN; } set { m_FRRN = value; } }    //주민등록앞번호          
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string SRRN { get { return m_SRRN; } set { m_SRRN = value; } }    //주민등록뒷번호(1****** 형태의 주민번호 뒷자리)
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string SRRN_ECPT //복호된 주민등록뒷번호
        {
            get
            {
                return EncryptionService.Decoding(m_SRRN_ECPT);
            }
            set
            {
                if (StringService.IsNotNull(value) && StringService.IsNumeric(value) && value.Length == 7)
                    m_SRRN_ECPT = EncryptionService.Encoding(value);
            }
        }
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string SRRN_SECURITY //암호화된 주민등록뒷번호
        {
            get
            {
                return m_SRRN_ECPT;
            }
            set
            {
                m_SRRN_ECPT = value;
            }
        }
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string DOBR { get { return m_DOBR; } set { m_DOBR = value; } }    //생년월일                
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string SEX_DVCD { get { return m_SEX_DVCD; } set { m_SEX_DVCD = value; } }    //성별구분코드            
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int AGE { get { return m_AGE; } set { m_AGE = value; } }    //나이
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int AGE_YEAR { get { return m_AGE_YEAR; } set { m_AGE_YEAR = value; } }    //년수
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int AGE_MONTH { get { return m_AGE_MONTH; } set { m_AGE_MONTH = value; } }    //개월수
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int AGE_WEEK { get { return m_AGE_WEEK; } set { m_AGE_WEEK = value; } }    //주수
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int AGE_DAY { get { return m_AGE_DAY; } set { m_AGE_DAY = value; } }    //일수
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string FRST_CMHS_DD { get { return m_FRST_CMHS_DD; } set { m_FRST_CMHS_DD = value; } }    //최초내원일자            
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ADDR_BLDG_NO { get { return m_ADDR_BLDG_NO; } set { m_ADDR_BLDG_NO = value; } }    //주소건물번호            
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ADDR_CD { get { return m_ADDR_CD; } set { m_ADDR_CD = value; } }    //주소코드(우편번호)(우편번호)
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int ADDR_SQNO { get { return m_ADDR_SQNO; } set { m_ADDR_SQNO = value; } }    //주소일련번호            
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string DETL_ADDR { get { return m_DETL_ADDR; } set { m_DETL_ADDR = value; } }    //상세주소                
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ADDRESS_DONG { get { return m_ADDRESS_DONG; } set { m_ADDRESS_DONG = value; } }    //주소(동까지)
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ADDRESS { get { return m_ADDRESS; } set { m_ADDRESS = value; } }    //주소  
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string HOUS_TEL { get { return m_HOUS_TEL; } set { m_HOUS_TEL = value; } }    //주택전화번호            
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string CLPH_TEL { get { return m_CLPH_TEL; } set { m_CLPH_TEL = value; } }    //휴대폰전화번호          
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ETC_TEL_1 { get { return m_ETC_TEL_1; } set { m_ETC_TEL_1 = value; } }    //기타전화번호첫째        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ETC_TEL_2 { get { return m_ETC_TEL_2; } set { m_ETC_TEL_2 = value; } }    //기타전화번호둘째        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ETC_TEL_3 { get { return m_ETC_TEL_3; } set { m_ETC_TEL_3 = value; } }    //기타전화번호셋째        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string EMAL_ADDR { get { return m_EMAL_ADDR; } set { m_EMAL_ADDR = value; } }    //이메일주소              
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string PT_DETL_DVCD_1 { get { return m_PT_DETL_DVCD_1; } set { m_PT_DETL_DVCD_1 = value; } }    //환자상세구분코드첫째    
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string PT_DETL_DVCD_2 { get { return m_PT_DETL_DVCD_2; } set { m_PT_DETL_DVCD_2 = value; } }    //환자상세구분코드둘째    
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string PT_DETL_DVCD_3 { get { return m_PT_DETL_DVCD_3; } set { m_PT_DETL_DVCD_3 = value; } }    //환자상세구분코드셋째    
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string PT_DETL_DVCD_4 { get { return m_PT_DETL_DVCD_4; } set { m_PT_DETL_DVCD_4 = value; } }    //환자상세구분코드넷째    
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string PT_DETL_DVCD_5 { get { return m_PT_DETL_DVCD_5; } set { m_PT_DETL_DVCD_5 = value; } }    //환자상세구분코드다섯째  
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string PT_DETL_DVCD_6 { get { return m_PT_DETL_DVCD_6; } set { m_PT_DETL_DVCD_6 = value; } }    //환자상세구분코드여섯째  
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string VTRN_PT_YN { get { return m_VTRN_PT_YN; } set { m_VTRN_PT_YN = value; } }    //보훈환자여부            
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string MOMR_AGE_DVCD { get { return m_MOMR_AGE_DVCD; } set { m_MOMR_AGE_DVCD = value; } }    //유공자연령구분코드      
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string INDP_MOMR_YN { get { return m_INDP_MOMR_YN; } set { m_INDP_MOMR_YN = value; } }    //독립유공자여부          
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string NATN_CD { get { return m_NATN_CD; } set { m_NATN_CD = value; } }    //국가코드                
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string INDV_INFO_CNSN_YN { get { return m_INDV_INFO_CNSN_YN; } set { m_INDV_INFO_CNSN_YN = value; } }    //개인정보동의여부        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string SMS_CNSN_YN { get { return m_SMS_CNSN_YN; } set { m_SMS_CNSN_YN = value; } }    //SMS동의여부             
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string PTRGRCD_ISSU_YN { get { return m_PTRGRCD_ISSU_YN; } set { m_PTRGRCD_ISSU_YN = value; } }    //진찰권발행여부          
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string CLUR_DSTG_DVCD { get { return m_CLUR_DSTG_DVCD; } set { m_CLUR_DSTG_DVCD = value; } }    //장루요루장애대상구분코드
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string UNDN_DVCD { get { return m_UNDN_DVCD; } set { m_UNDN_DVCD = value; } }    //신원미상구분코드        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ITDT_EMNO { get { return m_ITDT_EMNO; } set { m_ITDT_EMNO = value; } }    //소개직원번호            
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string FCLT_APLY_YN { get { return m_FCLT_APLY_YN; } set { m_FCLT_APLY_YN = value; } }    //시설적용여부            
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string FCLT_APLY_DVCD { get { return m_FCLT_APLY_DVCD; } set { m_FCLT_APLY_DVCD = value; } }    //시설적용구분코드        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string PT_PCLR_MATR { get { return m_PT_PCLR_MATR; } set { m_PT_PCLR_MATR = value; } }    //환자특이사항            
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string DEL_YN { get { return m_DEL_YN; } set { m_DEL_YN = value; } }    //삭제여부                
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string DETH_DD { get { return m_DETH_DD; } set { m_DETH_DD = value; } }    //사망일자                
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string DETH_PLCE_DVCD { get { return m_DETH_PLCE_DVCD; } set { m_DETH_PLCE_DVCD = value; } }    //사망장소구분코드        
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string FRNR_NM { get { return m_FRNR_NM; } set { m_FRNR_NM = value; } }    //외국인성명              
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string PRIVACY { get { return m_PRIVACY; } set { m_PRIVACY = value; } }    //개인정보보호 대상자             
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string INFO_CONSENT { get { return m_INFO_CONSENT; } set { m_INFO_CONSENT = value; } }    //개인정보활용동의여부


        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string PatientID { get { return PID; } set { PID = value; } }             //환자등록번호
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string PatientName { get { return PT_NM; } set { PT_NM = value; } }             //환자성명
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string NickName { get { return NICK_NM; } set { NICK_NM = value; } }             //환자성명2
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ResidentNo { get { return RRN; } set { RRN = value; } }             //주민등록번호

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ResidentNoEnc { get { return RRN_ECPT; } set { RRN_ECPT = value; } }             //복화화된 주민등록번호 
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ResidentNoEncrypt { get { return RRN_ECPT; } set { RRN_ECPT = value; } }             //복화화된 주민등록번호 
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ResidentNoFirst { get { return FRRN; } set { FRRN = value; } }             //주민등록앞번호          
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ResidentNoSecond { get { return SRRN; } set { SRRN = value; } }             //주민등록뒷번호(1****** 형태의 주민번호 뒷자리)          
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ResidentNoSecondEncrypt { get { return SRRN_ECPT; } set { SRRN_ECPT = value; } }             //주민등록뒷번호암호화    
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string BirthDay { get { return DOBR; } set { DOBR = value; } }             //생년월일                
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Sex { get { return SEX_DVCD; } set { SEX_DVCD = value; } }             //성별구분코드            
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Age { get { return AGE.ToString(); } set { AGE = int.Parse(value); } }  //나이
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string AgeYear { get { return AGE_YEAR.ToString(); } set { AGE_YEAR = int.Parse(value); } }  //년수
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string AgeMonth { get { return AGE_MONTH.ToString(); } set { AGE_MONTH = int.Parse(value); } }  //개월수
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string AgeWeek { get { return AGE_WEEK.ToString(); } set { AGE_WEEK = int.Parse(value); } }  //주수
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string AgeDay { get { return AGE_DAY.ToString(); } set { AGE_DAY = int.Parse(value); } }  //일수
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string BuildingNo { get { return ADDR_BLDG_NO; } set { ADDR_BLDG_NO = value; } }             //주소건물번호            
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string PostNo { get { return ADDR_CD; } set { ADDR_CD = value; } }             //주소코드(우편번호)(우편번호)
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int AddressSeq { get { return ADDR_SQNO; } set { ADDR_SQNO = value; } }             //주소일련번호            
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string AddressDetail { get { return DETL_ADDR; } set { DETL_ADDR = value; } }             //상세주소                
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string AddressDong { get { return ADDRESS_DONG; } set { ADDRESS_DONG = value; } }             //주소(동까지)
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Address { get { return ADDRESS; } set { ADDRESS = value; } }             //주소  
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Phone { get { return HOUS_TEL; } set { HOUS_TEL = value; } }             //주택전화번호            
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Mobile { get { return CLPH_TEL; } set { CLPH_TEL = value; } }             //휴대폰전화번호          
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string FirstReceiptDate { get { return FRST_CMHS_DD; } set { FRST_CMHS_DD = value; } }             //최초내원일자            
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Privacy { get { return PRIVACY; } set { PRIVACY = value; } }             //개인정보보호 대상자             
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string InfoConsent { get { return INFO_CONSENT; } set { INFO_CONSENT = value; } }             //개인정보활용동의여부

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLoaded
        {
            get
            {
                return StringService.IsNotNull(m_PID, PT_NM, IOSeq);
            }
        }

        #endregion

        #region Patient Receipt Info Property

        /// <summary>
        /// 접수 정보
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DOPatientReceiptInfo ReceiptInfo
        {
            get
            {
                return m_ReceiptInfo;
            }
            set
            {
                m_ReceiptInfo = value;
            }
        }

        /// <summary>
        /// 외래/입원 Chart 구분코드
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ChartIOType
        {
            get
            {
                return m_ChartIOType;
            }
            set
            {
                this.m_ChartIOType = value;
            }
        }

        /// <summary>
        /// 외래/입원 구분코드
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string IOType
        {
            get
            {
                return this.ReceiptInfo.IOType;
            }
            set
            {
                this.ReceiptInfo.IOType = value;
            }
        }
        /// <summary>
        /// 접수 키 
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Key
        {
            get
            {
                return this.ReceiptInfo.Key;
            }
            set
            {
                this.ReceiptInfo.Key = value;
            }
        }
        /// <summary>
        /// 내원번호
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string IOSeq
        {
            get
            {
                return this.ReceiptInfo.IOSeq;
            }
            set
            {
                this.ReceiptInfo.IOSeq = value;
            }
        }
        /// <summary>
        /// 진료일/접수일
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string IODate
        {
            get
            {
                return this.ReceiptInfo.IODate;
            }
            set
            {
                this.ReceiptInfo.IODate = value;
            }
        }
        /// <summary>
        /// 진료일/접수일
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DateTime IODateTime
        {
            get
            {
                return DateTimeService.ConvertDateTime(string.Format("{0} {1}", this.ReceiptInfo.IODate, this.ReceiptInfo.IOTime));
            }
            set
            {
                this.ReceiptInfo.IODate = value.ToString(DateTimeFormat.DATE_FORMAT);
                this.ReceiptInfo.IOTime = value.ToString(DateTimeFormat.TIME_FORMAT);
            }
        }
        /// <summary>
        /// 진료일/접수일
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string IODateTimeString
        {
            get
            {
                return string.Format("{0} {1}", this.ReceiptInfo.IODate, this.ReceiptInfo.IOTime);
            }
            set
            {
                DateTime dt = DateTimeService.ConvertDateTime(value);

                this.ReceiptInfo.IODate = dt.ToString(DateTimeFormat.DATE_FORMAT);
                this.ReceiptInfo.IOTime = dt.ToString(DateTimeFormat.TIME_FORMAT);
            }
        }
        /// <summary>
        /// 진료일/접수일
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string IODateTimeNoneSeparator
        {
            get
            {
                return string.Format("{0}{1}", this.ReceiptInfo.IODate.Replace("-", ""), this.ReceiptInfo.IOTime.Replace(":", ""));
            }
            set
            {
                DateTime dt = DateTimeService.ConvertDateTime(value);

                this.ReceiptInfo.IODate = dt.ToString(DateTimeFormat.DATE_FORMAT);
                this.ReceiptInfo.IOTime = dt.ToString(DateTimeFormat.TIME_FORMAT);
            }
        }
        /// <summary>
        /// 진료일/접수일
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string IODateNoneSeparator
        {
            get
            {
                return this.ReceiptInfo.IODate.Replace("-", "");
            }
        }
        /// <summary>
        /// 진료시간/접수시간
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string IOTime
        {
            get
            {
                return this.ReceiptInfo.IOTime;
            }
            set
            {
                this.ReceiptInfo.IOTime = value;
            }
        }
        /// <summary>
        /// 진료시간/접수시간
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string IOTimeNoneSeparator
        {
            get
            {
                return this.ReceiptInfo.IOTime.Replace(":", "");
            }
        }
        /// <summary>
        /// 진료일/접수일
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DateTime DisDateTime
        {
            get
            {
                return DateTimeService.ConvertDateTime(this.ReceiptInfo.DisDate);
            }
            set
            {
                this.ReceiptInfo.DisDate = value.ToString(DateTimeFormat.DATE_FORMAT);
            }
        }
        /// <summary>
        /// 퇴원일
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string DisDate
        {
            get
            {
                return this.ReceiptInfo.DisDate;
            }
            set
            {
                this.ReceiptInfo.DisDate = value;
            }
        }
        /// <summary>
        /// 퇴원일
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string DisDateNoneSeparator
        {
            get
            {
                return this.ReceiptInfo.DisDate.Replace("-", "");
            }
        }
        /// <summary>
        /// 입원기간
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Period
        {
            get
            {
                return this.ReceiptInfo.Period;
            }
            set
            {
                this.ReceiptInfo.Period = value;
            }
        }
        /// <summary>
        /// 진료과코드
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string DeptCode
        {
            get
            {
                return this.ReceiptInfo.DeptCode;
            }
            set
            {
                this.ReceiptInfo.DeptCode = value;
            }
        }
        /// <summary>
        /// 진료과명
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string DeptName
        {
            get
            {
                return this.ReceiptInfo.DeptName;
            }
            set
            {
                this.ReceiptInfo.DeptName = value;
            }
        }
        /// <summary>
        /// 의사코드
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string DoctorID
        {
            get
            {
                return this.ReceiptInfo.DoctorID;
            }
            set
            {
                this.ReceiptInfo.DoctorID = value;
            }
        }
        /// <summary>
        /// 의사명
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string DoctorName
        {
            get
            {
                return this.ReceiptInfo.DoctorName;
            }
            set
            {
                this.ReceiptInfo.DoctorName = value;
            }
        }
        /// <summary>
        /// 병동코드
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string WardCode
        {
            get
            {
                return this.ReceiptInfo.WardCode;
            }
            set
            {
                this.ReceiptInfo.WardCode = value;
            }
        }
        /// <summary>
        /// 병동명
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string WardName
        {
            get
            {
                return this.ReceiptInfo.WardName;
            }
            set
            {
                this.ReceiptInfo.WardName = value;
            }
        }
        /// <summary>
        /// 병실코드
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string RoomCode
        {
            get
            {
                return this.ReceiptInfo.RoomCode;
            }
            set
            {
                this.ReceiptInfo.RoomCode = value;
            }
        }
        /// <summary>
        /// 병실명
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string RoomName
        {
            get
            {
                return this.ReceiptInfo.RoomName;
            }
            set
            {
                this.ReceiptInfo.RoomName = value;
            }
        }
        /// <summary>
        /// 초진/재진 구분
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ReceiptType
        {
            get
            {
                return this.ReceiptInfo.ReceiptType;
            }
            set
            {
                this.ReceiptInfo.ReceiptType = value;
            }
        }
        /// <summary>
        /// 초진/재진 구분 명칭
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ReceiptTypeName
        {
            get
            {
                return this.ReceiptInfo.ReceiptTypeName;
            }
            set
            {
                this.ReceiptInfo.ReceiptTypeName = value;
            }
        }
        /// <summary>
        /// 초진일자
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string FirstVisitDate
        {
            get
            {
                return this.ReceiptInfo.FirstVisitDate;
            }
            set
            {
                this.ReceiptInfo.FirstVisitDate = value;
            }
        }
        /// <summary>
        /// 선택진료(특진) 여부
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string SpecialTreat
        {
            get
            {
                return this.ReceiptInfo.SpecialTreat;
            }
            set
            {
                this.ReceiptInfo.SpecialTreat = value;
            }
        }
        /// <summary>
        /// 선택진료(특진) 여부 명칭
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string SpecialTreatName
        {
            get
            {
                return this.ReceiptInfo.SpecialTreatName;
            }
            set
            {
                this.ReceiptInfo.SpecialTreatName = value;
            }
        }
        /// <summary>
        /// 보험유형
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string InsuranceKind
        {
            get
            {
                return this.ReceiptInfo.InsuranceKind;
            }
            set
            {
                this.ReceiptInfo.InsuranceKind = value;
            }
        }
        /// <summary>
        /// 보험유형명
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string InsuranceKindName
        {
            get
            {
                return this.ReceiptInfo.InsuranceKindName;
            }
            set
            {
                this.ReceiptInfo.InsuranceKindName = value;
            }
        }
        /// <summary>
        /// 보험증번호
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string InsuranceNo
        {
            get
            {
                return this.ReceiptInfo.InsuranceNo;
            }
            set
            {
                this.ReceiptInfo.InsuranceNo = value;
            }
        }
        /// <summary>
        /// 기관기호
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ContractCode
        {
            get
            {
                return this.ReceiptInfo.ContractCode;
            }
            set
            {
                this.ReceiptInfo.ContractCode = value;
            }
        }
        /// <summary>
        /// 보호자명
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ProtectorName
        {
            get
            {
                return this.ReceiptInfo.ProtectorName;
            }
            set
            {
                this.ReceiptInfo.ProtectorName = value;
            }
        }
        /// <summary>
        /// 보호자와의 관계 코드
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Relation
        {
            get
            {
                return this.ReceiptInfo.Relation;
            }
            set
            {
                this.ReceiptInfo.Relation = value;
            }
        }
        /// <summary>
        /// 보호자와의 관계 명
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string RelationName
        {
            get
            {
                return this.ReceiptInfo.RelationName;
            }
            set
            {
                this.ReceiptInfo.RelationName = value;
            }
        }
        /// <summary>
        /// 접수메모
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ReceiptRemark
        {
            get
            {
                return this.ReceiptInfo.ReceiptRemark;
            }
            set
            {
                this.ReceiptInfo.ReceiptRemark = value;
            }
        }

        #endregion

        #region Construction

        public DOPatientInfo()
        {
            this.Clear();
        }

        public DOPatientInfo(string pid)
        {
            this.Clear();

            m_PID = pid;

            this.Load();
        }

        #endregion 

        #region Dispose

        // Flag: Has Dispose already been called?
        private bool disposed = false;

        // Public implementation of Dispose pattern callable by consumers.
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // Protected implementation of Dispose pattern.
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Free any other managed objects here.
                this.Clear();

                if (m_ReceiptInfo != null) m_ReceiptInfo.Dispose();
            }

            // Free any unmanaged objects here.

            disposed = true;
        }

        ~DOPatientInfo()
        {
            Dispose(false);
        }

        #endregion

        #region Method : General Public Method

        /// <summary>
        /// 초기화
        /// </summary>
        public void Clear()
        {

            m_PID = string.Empty;
            m_PT_NM = string.Empty;
            m_FRRN = string.Empty;
            m_SRRN = string.Empty;
            m_SRRN_ECPT = string.Empty;
            m_DOBR = string.Empty;
            m_SEX_DVCD = string.Empty;
            m_AGE = 0;
            m_AGE_YEAR = 0;
            m_AGE_MONTH = 0;
            m_AGE_WEEK = 0;
            m_AGE_DAY = 0;
            m_FRST_CMHS_DD = string.Empty;
            m_ADDR_CD = string.Empty;
            m_ADDR_SQNO = 0;
            m_DETL_ADDR = string.Empty;
            m_ADDRESS_DONG = string.Empty;
            m_ADDRESS = string.Empty;
            m_HOUS_TEL = string.Empty;
            m_ADDR_BLDG_NO = string.Empty;
            m_CLPH_TEL = string.Empty;
            m_ETC_TEL_1 = string.Empty;
            m_ETC_TEL_2 = string.Empty;
            m_ETC_TEL_3 = string.Empty;
            m_EMAL_ADDR = string.Empty;
            m_PT_DETL_DVCD_1 = string.Empty;
            m_PT_DETL_DVCD_2 = string.Empty;
            m_PT_DETL_DVCD_3 = string.Empty;
            m_PT_DETL_DVCD_4 = string.Empty;
            m_PT_DETL_DVCD_5 = string.Empty;
            m_PT_DETL_DVCD_6 = string.Empty;
            m_VTRN_PT_YN = string.Empty;
            m_MOMR_AGE_DVCD = string.Empty;
            m_INDP_MOMR_YN = string.Empty;
            m_NATN_CD = string.Empty;
            m_INDV_INFO_CNSN_YN = string.Empty;
            m_SMS_CNSN_YN = string.Empty;
            m_PTRGRCD_ISSU_YN = string.Empty;
            m_CLUR_DSTG_DVCD = string.Empty;
            m_UNDN_DVCD = string.Empty;
            m_ITDT_EMNO = string.Empty;
            m_FCLT_APLY_YN = string.Empty;
            m_FCLT_APLY_DVCD = string.Empty;
            m_PT_PCLR_MATR = string.Empty;
            m_DEL_YN = string.Empty;
            m_DETH_DD = string.Empty;
            m_DETH_PLCE_DVCD = string.Empty;
            m_FRNR_NM = string.Empty;
            m_PRIVACY = string.Empty;
            m_INFO_CONSENT = string.Empty;

            ReceiptInfo.Clear();

            //Patient 정보 변경 Event를 발생시킨다
            OnPatientChanged();
        }

        public object Clone()
        {
            DOPatientInfo pi = new DOPatientInfo();

            pi.PID = m_PID;
            pi.PT_NM = m_PT_NM;
            pi.FRRN = m_FRRN;
            pi.SRRN = m_SRRN;
            pi.SRRN_ECPT = m_SRRN_ECPT;
            pi.DOBR = m_DOBR;
            pi.SEX_DVCD = m_SEX_DVCD;
            pi.AGE = m_AGE;
            pi.AGE_YEAR = m_AGE_YEAR;
            pi.AGE_MONTH = m_AGE_MONTH;
            pi.AGE_WEEK = m_AGE_WEEK;
            pi.AGE_DAY = m_AGE_DAY;
            pi.FRST_CMHS_DD = m_FRST_CMHS_DD;
            pi.ADDR_BLDG_NO = m_ADDR_BLDG_NO;
            pi.ADDR_CD = m_ADDR_CD;
            pi.ADDR_SQNO = m_ADDR_SQNO;
            pi.DETL_ADDR = m_DETL_ADDR;
            pi.ADDRESS_DONG = m_ADDRESS_DONG;
            pi.ADDRESS = m_ADDRESS;
            pi.HOUS_TEL = m_HOUS_TEL;
            pi.CLPH_TEL = m_CLPH_TEL;
            pi.ETC_TEL_1 = m_ETC_TEL_1;
            pi.ETC_TEL_2 = m_ETC_TEL_2;
            pi.ETC_TEL_3 = m_ETC_TEL_3;
            pi.EMAL_ADDR = m_EMAL_ADDR;
            pi.PT_DETL_DVCD_1 = m_PT_DETL_DVCD_1;
            pi.PT_DETL_DVCD_2 = m_PT_DETL_DVCD_2;
            pi.PT_DETL_DVCD_3 = m_PT_DETL_DVCD_3;
            pi.PT_DETL_DVCD_4 = m_PT_DETL_DVCD_4;
            pi.PT_DETL_DVCD_5 = m_PT_DETL_DVCD_5;
            pi.PT_DETL_DVCD_6 = m_PT_DETL_DVCD_6;
            pi.VTRN_PT_YN = m_VTRN_PT_YN;
            pi.MOMR_AGE_DVCD = m_MOMR_AGE_DVCD;
            pi.INDP_MOMR_YN = m_INDP_MOMR_YN;
            pi.NATN_CD = m_NATN_CD;
            pi.INDV_INFO_CNSN_YN = m_INDV_INFO_CNSN_YN;
            pi.SMS_CNSN_YN = m_SMS_CNSN_YN;
            pi.PTRGRCD_ISSU_YN = m_PTRGRCD_ISSU_YN;
            pi.CLUR_DSTG_DVCD = m_CLUR_DSTG_DVCD;
            pi.UNDN_DVCD = m_UNDN_DVCD;
            pi.ITDT_EMNO = m_ITDT_EMNO;
            pi.FCLT_APLY_YN = m_FCLT_APLY_YN;
            pi.FCLT_APLY_DVCD = m_FCLT_APLY_DVCD;
            pi.PT_PCLR_MATR = m_PT_PCLR_MATR;
            pi.DEL_YN = m_DEL_YN;
            pi.DETH_DD = m_DETH_DD;
            pi.DETH_PLCE_DVCD = m_DETH_PLCE_DVCD;
            pi.FRNR_NM = m_FRNR_NM;
            pi.PRIVACY = m_PRIVACY;
            pi.INFO_CONSENT = m_INFO_CONSENT;

            return pi;
        }

        #endregion

        #region Method : Get Value

        public string GetValue(string code, out bool isTextBox)
        {
            isTextBox = true;

            return GetValue(code);
        }

        public string GetValue(string code)
        {
            string result = "";

            switch (code.ToUpper().Trim())
            {
                #region 환자 기본 정보
                case "ID":
                case "PID":
                case "PATIENTID":
                    result = PID;
                    break;
                case "NAME":
                case "PNAME":
                case "PATIENTNAME":
                case "PT_NM":
                    result = PT_NM;
                    break;
                case "NAME2":
                case "NICKNAME":
                    result = FRNR_NM;
                    break;
                case "RRN":
                    result = RRN;
                    break;
                case "RRN_ECPT":
                    result = RRN_ECPT;
                    break;
                case "FRRN":
                    result = FRRN;
                    break;
                case "SRRN":
                    result = SRRN;
                    break;
                case "SRRN_ECPT":
                    result = SRRN_ECPT;
                    break;
                case "SEX":
                case "SEX_DVCD":
                    result = SEX_DVCD;
                    break;
                case "DOBR":
                case "BIRTH":
                case "BIRTHDAY":
                    result = DOBR;
                    break;
                case "AGE":
                    result = AGE.ToString();
                    break;
                case "AGE_YEAR":
                    result = AGE_YEAR.ToString();
                    break;
                case "AGE_MONTH":
                    result = AGE_MONTH.ToString();
                    break;
                case "AGE_WEEK":
                    result = AGE_WEEK.ToString();
                    break;
                case "AGE_DAY":
                    result = AGE_DAY.ToString();
                    break;
                case "POST":
                case "POSTNO":
                case "ZIPCODE":
                case "ADDR_CD":
                    result = ADDR_CD;
                    break;
                case "ADDR_SQNO":
                    result = ADDR_SQNO.ToString();
                    break;
                case "DETL_ADDR":
                    result = DETL_ADDR;
                    break;
                case "ADDR_BLDG_NO":
                case "BUILDING_NO":
                    result = ADDR_BLDG_NO;
                    break;
                case "ADDRESS":
                case "ADDRNAME":
                    result = ADDRESS;
                    break;
                case "TEL":
                case "PHONE":
                case "TELEPHONE":
                case "HOUS_TEL":
                    result = HOUS_TEL;
                    break;
                case "MOBILE":
                case "HANDPHONE":
                case "CLPH_TEL":
                    result = CLPH_TEL;
                    break;
                case "ETC1":
                case "ETC_TEL_1":
                    result = ETC_TEL_1;
                    break;
                case "ETC2":
                case "ETC_TEL_2":
                    result = ETC_TEL_2;
                    break;
                case "ETC3":
                case "ETC_TEL_3":
                    result = ETC_TEL_3;
                    break;
                case "EMAL":
                case "EMAL_ADDR":
                case "EMAIL":
                    result = EMAL_ADDR;
                    break;

                case "PT_DETL_DVCD_1":
                    result = PT_DETL_DVCD_1;
                    break;
                case "PT_DETL_DVCD_2":
                    result = PT_DETL_DVCD_2;
                    break;
                case "PT_DETL_DVCD_3":
                    result = PT_DETL_DVCD_3;
                    break;
                case "PT_DETL_DVCD_4":
                    result = PT_DETL_DVCD_4;
                    break;
                case "PT_DETL_DVCD_5":
                    result = PT_DETL_DVCD_5;
                    break;
                case "PT_DETL_DVCD_6":
                    result = PT_DETL_DVCD_6;
                    break;
                case "VTRN_PT_YN":
                    result = VTRN_PT_YN;
                    break;
                case "MOMR_AGE_DVCD":
                    result = MOMR_AGE_DVCD;
                    break;
                case "INDP_MOMR_YN":
                    result = INDP_MOMR_YN;
                    break;
                case "NATN_CD":
                    result = NATN_CD;
                    break;
                case "INDV_INFO_CNSN_YN":
                    result = INDV_INFO_CNSN_YN;
                    break;
                case "SMS_CNSN_YN":
                    result = SMS_CNSN_YN;
                    break;
                case "CLUR_DSTG_DVCD":
                    result = CLUR_DSTG_DVCD;
                    break;
                case "UNDN_DVCD":
                    result = UNDN_DVCD;
                    break;
                case "ITDT_EMNO":
                    result = ITDT_EMNO;
                    break;
                case "FCLT_APLY_YN":
                    result = FCLT_APLY_YN;
                    break;
                case "FCLT_APLY_DVCD":
                    result = FCLT_APLY_DVCD;
                    break;
                case "PT_PCLR_MATR":
                    result = PT_PCLR_MATR;
                    break;
                case "DEL_YN":
                    result = DEL_YN;
                    break;
                case "DETH_DD":
                    result = DETH_DD;
                    break;
                case "DETH_PLCE_DVCD":
                    result = DETH_PLCE_DVCD;
                    break;
                case "FRNR_NM":
                    result = FRNR_NM;
                    break;
                case "PRIVACY":
                    result = Privacy;
                    break;
                case "INFOCONSENT":
                    result = InfoConsent;
                    break;

                #endregion

                #region 접수 정보
                case "IOTYPE":
                    result = IOType;
                    break;
                case "SEQ":
                case "IOSEQ":
                case "KEY":
                case "RECEIPTKEY":
                case "RECEIPTNO":
                    result = IOSeq;
                    break;
                case "IODATE":
                case "INDATE":
                case "RECEIPTDATE":
                    result = IODate;
                    break;
                case "IOTIME":
                case "INTIME":
                case "RECEIPTTIME":
                    result = IOTime;
                    break;
                case "OUTDATE":
                case "DISDATE":
                    result = DisDate;
                    break;
                case "PERIOD":
                    result = Period;
                    break;
                case "DEPT":
                case "DEPTCODE":
                    result = DeptCode;
                    break;
                case "DEPTNAME":
                    result = DeptName;
                    break;
                case "DOCTOR":
                case "DOCTORID":
                    result = DoctorID;
                    break;
                case "DOCTORNAME":
                    result = DoctorName;
                    break;
                case "WARDCODE":
                    result = WardCode;
                    break;
                case "WARD":
                case "WARDNAME":
                    result = WardName;
                    break;
                case "ROOMCODE":
                    result = RoomCode;
                    break;
                case "ROOM":
                case "ROOMNAME":
                    result = RoomName;
                    break;
                case "RECEIPTTYPE":
                    result = ReceiptType;
                    break;
                case "RECEIPTTYPENAME":
                    result = ReceiptTypeName;
                    break;
                case "FIRSTVISITDATE":
                    result = FirstVisitDate;
                    break;
                case "SPECIALTREAT":
                    result = SpecialTreat;
                    break;
                case "SPECIALTREATNAME":
                    result = SpecialTreatName;
                    break;
                case "INSURANCEKIND":
                    result = InsuranceKind;
                    break;
                case "INSURANCEKINDNAME":
                    result = InsuranceKindName;
                    break;
                case "INSURANCENO":
                    result = InsuranceNo;
                    break;
                case "CONTRACT":
                case "CONTRACTCODE":
                    result = ContractCode;
                    break;
                case "PROTECTOR":
                case "PROTECTORNAME":
                    result = ProtectorName;
                    break;
                case "RELATION":
                case "RELATIONCODE":
                    result = Relation;
                    break;
                case "RELATIONNAME":
                    result = RelationName;
                    break;
                case "REMARK2":
                case "RECEIPTREMARK":
                    result = ReceiptRemark;
                    break;
                    #endregion

            }

            return result;
        }

        #endregion

        #region Method : Load Patient Info

        /// <summary>
        /// Load Patient info
        /// </summary>
        /// <returns></returns>
        public bool Load()
        {
            return GetPatientInfo(m_PID);
        }

        /// <summary>
        /// Load Patient info
        /// </summary>
        /// <param name="pid"></param>
        /// <returns></returns>
        public bool Load(string pid)
        {
            return GetPatientInfo(pid);
        }

        /// <summary>
        /// Select Patient Info
        /// </summary>
        /// <param name="pid"></param>
        /// <returns></returns>
        private bool GetPatientInfo(string pid)
        {
            try
            {
                this.Clear();

                DataTable dtpatientinfo = new DataTable();

                try
                {
                    DBService.ExecuteDataTable(SQL.SelectPatientInfo(), ref dtpatientinfo, pid);
                }
                catch (Exception ex)
                {
                    LogService.ErrorLog(ex);
                }

                if (dtpatientinfo.Rows.Count > 0)
                {
                    DataRow row = dtpatientinfo.Rows[0];

                    m_PID = row["PID"].ToString();
                    m_PT_NM = row["PT_NM"].ToString();
                    m_FRRN = row["FRRN"].ToString();
                    m_SRRN = row["SRRN"].ToString();
                    m_SRRN_ECPT = row["SRRN_ECPT"].ToString();
                    m_DOBR = row["DOBR"].ToString();
                    m_SEX_DVCD = row["SEX_DVCD"].ToString();
                    m_AGE = int.Parse(row["AGE"].ToString());
                    m_AGE_YEAR = int.Parse(row["AGE_YEAR"].ToString());
                    m_AGE_MONTH = int.Parse(row["AGE_MONTH"].ToString());
                    m_AGE_WEEK = int.Parse(row["AGE_WEEK"].ToString());
                    m_AGE_DAY = int.Parse(row["AGE_DAY"].ToString());
                    m_FRST_CMHS_DD = row["FRST_CMHS_DD"].ToString();
                    m_ADDR_BLDG_NO = row["ADDR_BLDG_NO"].ToString();
                    m_ADDR_CD = row["ADDR_CD"].ToString();
                    m_ADDR_SQNO = int.Parse(row["ADDR_SQNO"].ToString());
                    m_DETL_ADDR = row["DETL_ADDR"].ToString();
                    m_ADDRESS_DONG = row["ADDRESS_DONG"].ToString();
                    m_ADDRESS = row["ADDRESS"].ToString();
                    m_HOUS_TEL = row["HOUS_TEL"].ToString();
                    m_CLPH_TEL = row["CLPH_TEL"].ToString();
                    m_ETC_TEL_1 = row["ETC_TEL_1"].ToString();
                    m_ETC_TEL_2 = row["ETC_TEL_2"].ToString();
                    m_ETC_TEL_3 = row["ETC_TEL_3"].ToString();
                    m_EMAL_ADDR = row["EMAL_ADDR"].ToString();
                    m_PT_DETL_DVCD_1 = row["PT_DETL_DVCD_1"].ToString();
                    m_PT_DETL_DVCD_2 = row["PT_DETL_DVCD_2"].ToString();
                    m_PT_DETL_DVCD_3 = row["PT_DETL_DVCD_3"].ToString();
                    m_PT_DETL_DVCD_4 = row["PT_DETL_DVCD_4"].ToString();
                    m_PT_DETL_DVCD_5 = row["PT_DETL_DVCD_5"].ToString();
                    m_PT_DETL_DVCD_6 = row["PT_DETL_DVCD_6"].ToString();
                    m_VTRN_PT_YN = row["VTRN_PT_YN"].ToString();
                    m_MOMR_AGE_DVCD = row["MOMR_AGE_DVCD"].ToString();
                    m_INDP_MOMR_YN = row["INDP_MOMR_YN"].ToString();
                    m_NATN_CD = row["NATN_CD"].ToString();
                    m_INDV_INFO_CNSN_YN = row["INDV_INFO_CNSN_YN"].ToString();
                    m_SMS_CNSN_YN = row["SMS_CNSN_YN"].ToString();
                    m_PTRGRCD_ISSU_YN = row["PTRGRCD_ISSU_YN"].ToString();
                    m_CLUR_DSTG_DVCD = row["CLUR_DSTG_DVCD"].ToString();
                    m_UNDN_DVCD = row["UNDN_DVCD"].ToString();
                    m_ITDT_EMNO = row["ITDT_EMNO"].ToString();
                    m_FCLT_APLY_YN = row["FCLT_APLY_YN"].ToString();
                    m_FCLT_APLY_DVCD = row["FCLT_APLY_DVCD"].ToString();
                    m_PT_PCLR_MATR = row["PT_PCLR_MATR"].ToString();
                    m_DEL_YN = row["DEL_YN"].ToString();
                    m_DETH_DD = row["DETH_DD"].ToString();
                    m_DETH_PLCE_DVCD = row["DETH_PLCE_DVCD"].ToString();
                    m_FRNR_NM = row["FRNR_NM"].ToString();


                    //DBService.MappingService의 PatientInfo에 Patient정보 세팅
                    SetMappingServicePatientInfo();

                    //Patient 정보 변경 Event를 발생시킨다
                    OnPatientChanged();
                    return true;
                }
                else
                {
                    LogService.DebugLog(string.Format("Patient not found.({0})", pid));
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return false;
        }

        /// <summary>                     
        /// DBService.MappingService의 PatientInfo에 Patient정보 세팅
        /// DBService에서 DOPack.PatientInfo를 사용하지 않고 따로 PatientInfo를 두는 이유는 DOPack에서 DBService를 참조하므로 DBService에서 DOPack을 참조하면 순환참조가 되므로.
        /// </summary>                    
        private void SetMappingServicePatientInfo()
        {
            MappingService.PatientInfo.SetPatientInfo(m_PID);
        }

        #endregion

        #region Method : Raise Event

        /// <summary>
        /// Patient가 변경되었을 때 Event를 발생시킨다
        /// </summary>
        public void OnPatientChanged()
        {
            if (this.PatientChanged != null)
            {
                SetMappingServicePatientInfo();

                this.PatientChanged();
            }
        }

        #endregion

    }
}
