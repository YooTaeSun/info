using System;

namespace Lime.Framework
{
    /// <summary>
    /// DataTypeCheck에 대한 요약 설명입니다.
    /// </summary>
    public class TypeCheckService
    {
        /// <summary>
        /// 데이타가 DateTime형인지를 검사합니다.
        /// </summary>
        /// <param name="data"></param>
        /// <returns> DateTime형이면 true, 아니면 false </returns>
        public static bool IsDateTime(object data)
        {
            DateTime value = DateTime.Now;

            if (DateTime.TryParse(data.ToString(), out value))
                return true;
            else
                return false;
        }
        public static bool IsDateTime(object data, DateTime value)
        {
            if (DateTime.TryParse(data.ToString(), out value))
                return true;
            else
                return false;
        }

        //Date형 Text인지 여부(YYYYMMDD,YYYY/MM/DD, YYYY-MM-DD)
        public static bool IsDate(string data)
        {
            if (DateTimeService.IsDateTime(data))
                return true;
            else
                return false;
        }
        public static bool IsDate(string data, ref DateTime value)
        {
            if (IsDate(data))
            {
                value = DateTimeService.ConvertDateTime(data.ToString());
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
		/// 데이타가 Time형인지를 검사합니다.
		/// </summary>
		/// <param name="data"></param>
		/// <returns> Time형이면 true, 아니면 false </returns>
		public static bool IsTime(object data)
        {

            //Number형 Check
            //ex> 1212를 넘길때 TimeSpan에서는 1212를 Day로 인식함
            //IsTime Method는 Day를 포함하지 않는 Time만 관리함
            if (IsInt(data))
                if (TimeSpan.TryParse(data.ToString(), out TimeSpan value))
                    return true;
                else
                    return false;
            else
                return false;
        }
        public static bool IsTime(object data, ref TimeSpan value)
        {
            //Number형 Check
            //ex> 1212를 넘길때 TimeSpan에서는 1212를 Day로 인식함
            //IsTime Method는 Day를 포함하지 않는 Time만 관리함
            if (IsInt(data))
                if (TimeSpan.TryParse(data.ToString(), out value))
                    return true;
                else
                    return false;
            else
                return false;
        }

        /// <summary>
		/// 데이타가 Int형인지를 검사합니다.
		/// </summary>
		/// <param name="data"></param>
		/// <returns> Int형이면 true, 아니면 false </returns>
		public static bool IsInt(object data)
        {

            if (int.TryParse(data.ToString(), out int value))
                return true;
            else
                return false;
        }
        public static bool IsInt(object data, ref int value)
        {
            if (int.TryParse(data.ToString(), out value))
                return true;
            else
                return false;
        }

        /// <summary>
		/// 데이타가 long형인지를 검사합니다.
		/// </summary>
		/// <param name="data"></param>
		/// <returns> long형이면 true, 아니면 false </returns>
		public static bool IsLong(object data)
        {

            if (long.TryParse(data.ToString(), out long value))
                return true;
            else
                return false;
        }
        public static bool IsLong(object data, ref long value)
        {
            if (long.TryParse(data.ToString(), out value))
                return true;
            else
                return false;
        }

        /// <summary>
        /// 데이타가 UInt형인지를 검사합니다.
        /// </summary>
        /// <param name="data"></param>
        /// <returns> UInt형이면 true, 아니면 false </returns>
        public static bool IsUInt(object data)
        {

            if (uint.TryParse(data.ToString(), out uint value))
                return true;
            else
                return false;
        }
        public static bool IsUInt(object data, ref uint value)
        {
            if (uint.TryParse(data.ToString(), out value))
                return true;
            else
                return false;
        }

        /// <summary>
		/// 데이타가 Decimal형인지를 검사합니다.
		/// </summary>
		/// <param name="data"></param>
		/// <returns> Decimal형이면 true, 아니면 false </returns>
		public static bool IsDecimal(object data)
        {

            if (decimal.TryParse(data.ToString(), out decimal value))
                return true;
            else
                return false;
        }
        public static bool IsDecimal(object data, ref decimal value)
        {
            if (decimal.TryParse(data.ToString(), out value))
                return true;
            else
                return false;
        }

        /// <summary>
		/// 데이타가 double형인지를 검사합니다.
		/// </summary>
		/// <param name="data"></param>
		/// <returns> double형이면 true, 아니면 false </returns>
		public static bool IsDouble(object data)
        {

            if (double.TryParse(data.ToString(), out double value))
                return true;
            else
                return false;
        }
        public static bool IsDouble(object data, ref double value)
        {
            if (double.TryParse(data.ToString(), out value))
                return true;
            else
                return false;
        }

        /// <summary>
		/// 데이타가 single형인지를 검사합니다.
		/// </summary>
		/// <param name="data"></param>
		/// <returns> single형이면 true, 아니면 false </returns>
		public static bool IsSingle(object data)
        {

            if (float.TryParse(data.ToString(), out float value))
                return true;
            else
                return false;
        }
        public static bool IsSingle(object data, ref float value)
        {
            if (float.TryParse(data.ToString(), out value))
                return true;
            else
                return false;
        }

        /// <summary>
		/// 데이타가 float형인지를 검사합니다.
		/// </summary>
		/// <param name="data"></param>
		/// <returns> float형이면 true, 아니면 false </returns>
		public static bool IsFloat(object data)
        {

            if (float.TryParse(data.ToString(), out float value))
                return true;
            else
                return false;
        }
        public static bool IsFloat(object data, ref float value)
        {
            if (float.TryParse(data.ToString(), out value))
                return true;
            else
                return false;
        }

        /// <summary>
		/// 데이타가 bool형인지를 검사합니다.
		/// </summary>
		/// <param name="data"></param>
		/// <returns> bool형이면 true, 아니면 false </returns>
		public static bool IsBoolean(object data)
        {

            if (bool.TryParse(data.ToString(), out bool value))
                return true;
            else
                return false;
        }
        public static bool IsBoolean(object data, bool value)
        {
            if (bool.TryParse(data.ToString(), out value))
                return true;
            else
                return false;
        }

        /// <summary>
		/// 데이타가 byte형인지를 검사합니다.
		/// </summary>
		/// <param name="data"></param>
		/// <returns> byte형이면 true, 아니면 false </returns>
		public static bool IsByte(object data)
        {

            if (byte.TryParse(data.ToString(), out byte value))
                return true;
            else
                return false;
        }
        public static bool IsByte(object data, byte value)
        {
            if (byte.TryParse(data.ToString(), out value))
                return true;
            else
                return false;
        }

        /// <summary>
		/// 데이타가 SByte형인지를 검사합니다.
		/// </summary>
		/// <param name="data"></param>
		/// <returns> SByte형이면 true, 아니면 false </returns>
		public static bool IsSByte(object data)
        {

            if (sbyte.TryParse(data.ToString(), out sbyte value))
                return true;
            else
                return false;
        }
        public static bool IsSByte(object data, sbyte value)
        {
            if (sbyte.TryParse(data.ToString(), out value))
                return true;
            else
                return false;
        }

        /// <summary>
		/// 데이타가 char형인지를 검사합니다.
		/// </summary>
		/// <param name="data"></param>
		/// <returns> char형이면 true, 아니면 false </returns>
		public static bool IsChar(object data)
        {
            char value = (char)0;

            if (char.TryParse(data.ToString(), out value))
                return true;
            else
                return false;
        }
        public static bool IsChar(object data, char value)
        {
            if (char.TryParse(data.ToString(), out value))
                return true;
            else
                return false;
        }

        /// <summary>
		/// 데이타가 null인지 여부를 검사합니다.
		/// </summary>
		/// <param name="data"></param>
		/// <returns></returns>
		public static bool IsNull(object data)
        {
            if (data == null) return true;
            if (data is DBNull) return true;
            if (data.ToString().TrimEnd() == string.Empty) return true;

            return false;
        }

        /// <summary>
        /// sourceData가 NULL이면 targetData를 Return, Null이 아니면 sourceData Return합니다.
        /// </summary>
        /// <param name="sourceData"> Null을 판단하는 Source Data </param>
        /// <param name="targetData"> SourceData가 Null일때 대체할 Target data </param>
        /// <returns></returns>
        public static object NVL(object sourceData, object targetData)
        {
            if (IsNull(sourceData))
                return targetData;

            return sourceData;
        }
    }
}
