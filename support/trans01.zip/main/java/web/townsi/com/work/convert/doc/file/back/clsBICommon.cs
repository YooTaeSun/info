using System;
using System.Data;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.BI
{
    public class clsBICommon
    {
        #region CheckModified - 스프레드에 변경된 내용이 없으면 메세지박스를 띄우고, false를 반환하고, 변경된 내용이 있으면 True를 반환한다.
        /// <summary>
        /// 스프레드에 변경된 내용이 없으면 메세지박스를 띄우고, false를 반환하고, 변경된 내용이 있으면 True를 반환한다.
        /// </summary>
        /// <param name="spr">검색 대상이 되는 스프레드</param>
        /// <returns></returns>
        public static bool CheckModified(LxSpread spr)
        {
            //변경된 내용이 없을 때,
            if (!spr.IsModified())
            {
                LxMessage.Show("변경된 내용이 없습니다!!", "변경내역없음", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        #endregion

        #region CheckAplyDate - 스프레드의 적용시작일자가 종료일자보다 크면 메세지박스를 띄우고, false 를 반환한다.
        /// <summary>
        /// 스프레드의 적용시작일자가 종료일자보다 크면 메세지박스를 띄우고, false 를 반환한다.
        /// </summary>
        /// <param name="spr">검색 대상이 되는 스프레드</param>
        /// <param name="AplyStrtDdTag">적용시작일자 컬럼의 Tag</param>
        /// <param name="AplyEndDdTag">적용종료일자 컬럼의 Tag</param>
        /// <returns></returns>
        public static bool CheckAplyDate(LxSpread spr, string AplyStrtDdTag, string AplyEndDdTag)
        {
            string a = spr.Name;
            for (int i = 0; i < spr.ActiveSheet.RowCount; i++)
            {
                if ((spr.GetCRUDFromRow(i) == CRUD_TYPE.Create) || (spr.GetCRUDFromRow(i) == CRUD_TYPE.Update))
                {
                    if (StringService.IsNull(spr.GetValue(i, AplyStrtDdTag).ToString()))
                    {
                        LxMessage.Show("시작일자가 비어있습니다. 시작일자를 확인해주세요.", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                    if (StringService.IsNull(spr.GetValue(i, AplyEndDdTag).ToString()))
                    {
                        LxMessage.Show("종료일자가 비어있습니다. 종료일자를 확인해주세요.", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }

                    if (TypeCheckService.IsInt(spr.GetValue(i, AplyStrtDdTag).ToString()) && TypeCheckService.IsInt(spr.GetValue(i, AplyEndDdTag).ToString()))
                    {
                        if (Convert.ToInt32(spr.GetValue(i, AplyStrtDdTag).ToString()) > Convert.ToInt32(spr.GetValue(i, AplyEndDdTag).ToString()))
                        {
                            LxMessage.Show("적용시작일자는 종료일자보다 클 수 없습니다!!", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return false;
                        }
                    }
                }
            }
            return true;
        }
        #endregion

        #region CheckNull - 스프레드의 Null체크
        /// <summary>
        /// NotNull 컬럼에 Null값이 들어가면, 메세지박스를 띄우고, false를 반환한다.
        /// </summary>
        /// <param name="NotNullColumnNames">NotNull인 컬럼명 목록</param>
        /// <returns></returns>
        public static bool CheckNull(string NotNullColumnNames)
        {
            if (DBService.DBError.NullError)
            {
                LxMessage.Show("[" + NotNullColumnNames + "]에 값이 입력되지 않았습니다." + "[" + NotNullColumnNames + "]에 값을 입력하여 주십시오 !", "필수 입력란에 공백존재", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        /// <summary>
        /// NotNull 컬럼에 Null값이 들어가면, 메세지박스를 띄우고, Focus를 원하는 곳에 주고, false를 반환한다.
        /// </summary>
        /// <param name="spr">적용할 스프레드</param>
        /// <param name="focusCellTag">Focus를 줄 컬럼의 테그명</param>
        /// <param name="NotNullColumnNames">NotNull컬럼명 목록</param>
        /// <param name="rowIdx">Focus를 줄 Row</param>
        /// <returns></returns>
        public static bool CheckNull(LxSpread spr, int rowIdx, string focusCellTag, string NotNullColumnNames)
        {
            if (DBService.DBError.NullError)
            {
                spr.SetActiveRow(rowIdx);
                spr.SetActiveCell(rowIdx, focusCellTag);
                spr.ShowRow(0, rowIdx, FarPoint.Win.Spread.VerticalPosition.Nearest);

                LxMessage.Show("[" + NotNullColumnNames + "]에 값이 입력되지 않았습니다." + "[" + NotNullColumnNames + "]에 값을 입력하여 주십시오 !", "필수 입력란에 공백존재", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }
        #endregion

        #region CheckDup - 스프레드의 PK 체크
        /// <summary>
        /// PK 컬럼이 중복되면 메세지박스를 띄우고, false를 반환한다.
        /// </summary>
        /// <param name="PKColumnNames">PK컬럼명</param>
        /// <returns></returns>
        public static bool CheckDup(string PKColumnNames)
        {
            if (DBService.DBError.DupError)
            {
                LxMessage.Show("[" + PKColumnNames + "]은(는) 중복된 값이 입력될 수 없습니다!!", "중복값 존재", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        /// <summary>
        /// PK 컬럼이 중복되면 메세지박스를 띄우고, 원하는 Cell에 Focus를 주고, false를 반환한다.
        /// </summary>
        /// <param name="spr">적용할 스프레드</param>
        /// <param name="rowIdx">적용할 RowIndex</param>
        /// <param name="focusCellTag">Focus를 줄 컬럼의 Tag명</param>
        /// <param name="PKColumnNames">PK컬럼의 이름목록</param>
        /// <returns></returns>
        public static bool CheckDup(LxSpread spr, int rowIdx, string focusCellTag, string PKColumnNames)
        {
            if (DBService.DBError.DupError)
            {
                spr.SetActiveRow(rowIdx);
                spr.SetActiveCell(rowIdx, focusCellTag);
                spr.ShowRow(0, rowIdx, FarPoint.Win.Spread.VerticalPosition.Nearest);

                LxMessage.Show("[" + PKColumnNames + "]은(는) 중복된 값이 입력될 수 없습니다!!", "중복값 존재", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }
        #endregion

        #region CheckDupDuration - Spread의 PK들 간의 중복기간이 있는지 체크
        /// <summary>
        /// 하나의 코드를 대상으로, 적용기간이 겹치는 코드를 체크하고, 기간이 겹치면 메세지 박스를 띄우고, false를 반환한다.
        /// 스프레드의 CRUD플래그가 Update이면서, 적용일자시작일자,종료일자 체크대상이 되는 코드가 바뀌지 않았으면 기간의 중복을 체크하지 않는다.
        /// </summary>
        /// <param name="spr">확인할 스프레드</param>
        /// <param name="rowIdx">확인할 스프레드의 RowIndex</param>
        /// <param name="TableName">테이블명</param>
        /// <param name="AplyStrtDdTag">적용시작일자의 Tag</param>
        /// <param name="AplyEndDdTag">적용종료일자의 Tag</param>
        /// <param name="CodeColumnTag">확인 코드의 컬럼Tag</param>
        /// <param name="isDelYN">테이블 상의 DEL_YN 필드의 존재여부</param> 
        /// <param name="isMsgBox">오류 발생 시, 메세지박스 출력여부</param> 
        /// <returns></returns>
        public static bool CheckDupDuration(LxSpread spr, int rowIdx, string TableName, string AplyStrtDdTag, string AplyEndDdTag, string CodeColumnTag, bool isDelYN, bool isMsgBox)
        {
            #region 중복코드 동시저장 불가
            DataTable CreateDt = new DataTable();
            CreateDt.Columns.Add(new DataColumn("CODE", typeof(string)));
            DataTable DeleteDupDt = new DataTable();
            for (int i = 0; i < spr.ActiveSheet.RowCount; i++)
            {
                if (spr.GetCRUDFromRow(i) == CRUD_TYPE.Create)
                {
                    CreateDt.Rows.Add(spr.GetValue(i, CodeColumnTag));
                }
            }
            DeleteDupDt = CreateDt.DefaultView.ToTable(true, "CODE");

            if (CreateDt.Rows.Count != DeleteDupDt.Rows.Count)
            {
                if (isMsgBox)
                    LxMessage.Show("새로 저장하는 코드 값은 한번에 두개이상 중복된 값이 될 수 없습니다.", "중복코드 동시저장 불가", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            #endregion

            //Key가 되는 컬럼의 정보가 변경되었는지 체크하는 변수
            bool isKeyChanged = false;

            if (spr.GetCRUDFromRow(rowIdx) == CRUD_TYPE.Update)
                if ((spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() == spr.GetValue(rowIdx, AplyStrtDdTag).ToString())
               && (spr.GetOldValue(rowIdx, AplyEndDdTag).ToString() == spr.GetValue(rowIdx, AplyEndDdTag).ToString())
               && (spr.GetOldValue(rowIdx, CodeColumnTag).ToString() == spr.GetValue(rowIdx, CodeColumnTag).ToString()))
                    return true;
                else
                    isKeyChanged = true;

            string RevisionSql = " AND DEL_YN = 'A'";
            string CheckAplySql = "";
            if (isDelYN)
            {
                CheckAplySql = SQL.BI.Sql.GetMinAplyStrtDd() + RevisionSql;
                RevisionSql = SQL.BI.Sql.GetDupDuration() + RevisionSql;
            }
            else
            {
                CheckAplySql = SQL.BI.Sql.GetMinAplyStrtDd();
                RevisionSql = SQL.BI.Sql.GetDupDuration();
            }

            //입력하려는 적용 시작일자가 ,기존의 적용시작 일자의 최소 값보다 작으면 Return
            int MinAplyStrtDd = DBService.ExecuteInteger(CheckAplySql, AplyStrtDdTag
                                                                     , TableName
                                                                     , CodeColumnTag
                                                                     , spr.GetValue(rowIdx, CodeColumnTag).ToString());

            if (TypeCheckService.IsInt(spr.GetValue(rowIdx, AplyStrtDdTag).ToString()) && Convert.ToInt32(spr.GetValue(rowIdx, AplyStrtDdTag).ToString()) <= MinAplyStrtDd)
            {
                //자기 자신의 시작일자를 수정하는 경우 제외.
                if ((spr.GetCRUDFromRow(rowIdx) != CRUD_TYPE.Create) && (spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() != MinAplyStrtDd.ToString()))
                {
                    if (isMsgBox)
                        LxMessage.Show("수정 또는 새롭게 저장되는 적용 시작일자는\r\n기존에 같은 코드에 존재하는 적용시작일자보다 같거나 작을 수 없습니다!!", "적용시작일자 재입력필요", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

            }

            DataTable dt = new DataTable();
            if (DBService.ExecuteDataTable(RevisionSql, ref dt, TableName
                                                                             , AplyStrtDdTag
                                                                             , AplyEndDdTag
                                                                             , spr.GetValue(rowIdx, AplyStrtDdTag).ToString()
                                                                             , spr.GetValue(rowIdx, AplyEndDdTag).ToString()
                                                                             , CodeColumnTag
                                                                             , spr.GetValue(rowIdx, CodeColumnTag).ToString()))
            {
                string dupDurationRow = (rowIdx + 1).ToString();
                //겹치는 기간이 없을 때,
                if (dt.Rows.Count == 0)
                {
                    return true;
                }
                //겹치는 기간이 있을 때,
                else
                {
                    //데이터가 하나이면서, Update시 Key컬럼이 변경되었을 때, 즉, 자기 자신의 Key가 되는 컬럼을 변경할 때,
                    if ((dt.Rows.Count == 1) && (isKeyChanged == true))
                        return true;
                    else
                    {
                        if (isMsgBox)
                            LxMessage.Show(dupDurationRow + "번째 줄의 " + spr.GetValue(rowIdx, CodeColumnTag) + "코드와 적용기간이 겹치는 동일한 코드가 존재합니다!!", "기간이 겹치는 코드 존재", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// 두개의 코드를 대상으로, 적용기간이 겹치는 코드를 체크하고, 기간이 겹치면 메세지 박스를 띄우고, false를 반환한다.
        /// 스프레드의 CRUD플래그가 Update이면서, 적용일자시작일자,종료일자 체크대상이 되는 코드가 바뀌지 않았으면 기간의 중복을 체크하지 않는다.
        /// </summary>
        /// <param name="spr">확인할 스프레드</param>
        /// <param name="rowIdx">확인할 스프레드의 RowIndex</param>
        /// <param name="TableName">테이블명</param>
        /// <param name="AplyStrtDdTag">적용시작일자의 Tag</param>
        /// <param name="AplyEndDdTag">적용종료일자의 Tag</param>
        /// <param name="CodeColumnTag1">확인 코드의 첫번째 컬럼Tag</param>
        /// <param name="CodeColumnTag2">확인 코드의 두번째 컬럼Tag</param>
        /// <param name="isDelYN">테이블 상의 DEL_YN 필드의 존재여부</param> 
        /// <param name="isMsgBox">오류 발생 시, 메세지박스 출력여부</param> 
        /// <returns></returns>
        public static bool CheckDupDuration(LxSpread spr, int rowIdx, string TableName, string AplyStrtDdTag, string AplyEndDdTag, string CodeColumnTag1, string CodeColumnTag2, bool isDelYN, bool isMsgBox)
        {
            #region 중복코드 동시저장 불가
            DataTable CreateDt = new DataTable();
            CreateDt.Columns.Add(new DataColumn("CODE", typeof(string)));
            DataTable DeleteDupDt = new DataTable();
            for (int i = 0; i < spr.ActiveSheet.RowCount; i++)
            {
                if (spr.GetCRUDFromRow(i) == CRUD_TYPE.Create)
                {
                    CreateDt.Rows.Add(spr.GetValue(i, CodeColumnTag1).ToString() + spr.GetValue(i, CodeColumnTag2).ToString());
                }
            }
            DeleteDupDt = CreateDt.DefaultView.ToTable(true, "CODE");

            if (CreateDt.Rows.Count != DeleteDupDt.Rows.Count)
            {
                if (isMsgBox)
                    LxMessage.Show("새로 저장하는 코드 값은 한번에 두개이상 중복된 값이 될 수 없습니다.", "중복코드 동시저장 불가", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            #endregion

            //Key가 되는 컬럼의 정보가 변경되었는지 체크하는 변수
            bool isKeyChanged = false;

            if (spr.GetCRUDFromRow(rowIdx) == CRUD_TYPE.Update)
                if ((spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() == spr.GetValue(rowIdx, AplyStrtDdTag).ToString())
                   && (spr.GetOldValue(rowIdx, AplyEndDdTag).ToString() == spr.GetValue(rowIdx, AplyEndDdTag).ToString())
                   && (spr.GetOldValue(rowIdx, CodeColumnTag1).ToString() == spr.GetValue(rowIdx, CodeColumnTag1).ToString())
                    && (spr.GetOldValue(rowIdx, CodeColumnTag2).ToString() == spr.GetValue(rowIdx, CodeColumnTag2).ToString()))
                    return true;
                else
                    isKeyChanged = true;

            string CheckAplySql = "";
            string RevisionSql = " AND DEL_YN = 'A'";
            if (isDelYN)
            {
                CheckAplySql = SQL.BI.Sql.GetMinAplyStrtDd2() + RevisionSql;
                RevisionSql = SQL.BI.Sql.GetDupDuration2() + RevisionSql;
            }
            else
            {
                CheckAplySql = SQL.BI.Sql.GetMinAplyStrtDd2();
                RevisionSql = SQL.BI.Sql.GetDupDuration2();
            }

            //입력하려는 적용 시작일자가 ,기존의 적용시작 일자의 최소 값보다 작으면 Return
            int MinAplyStrtDd = DBService.ExecuteInteger(CheckAplySql, AplyStrtDdTag
                                                                     , TableName
                                                                     , CodeColumnTag1
                                                                     , spr.GetValue(rowIdx, CodeColumnTag1).ToString()
                                                                     , CodeColumnTag2
                                                                     , spr.GetValue(rowIdx, CodeColumnTag2).ToString());

            if (Convert.ToInt32(spr.GetValue(rowIdx, AplyStrtDdTag).ToString()) <= MinAplyStrtDd)
            {
                //자기 자신의 시작일자를 수정하는 경우 제외.
                if ((spr.GetCRUDFromRow(rowIdx) != CRUD_TYPE.Create) && (spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() != MinAplyStrtDd.ToString()))
                {
                    if (isMsgBox)
                        LxMessage.Show("수정 또는 새롭게 저장되는 적용 시작일자는\r\n기존에 같은 코드에 존재하는 적용시작일자보다 같거나 작을 수 없습니다!!", "적용시작일자 재입력필요", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

            }

            DataTable dt = new DataTable();
            if (DBService.ExecuteDataTable(RevisionSql, ref dt, TableName
                                                              , AplyStrtDdTag
                                                              , AplyEndDdTag
                                                              , spr.GetValue(rowIdx, AplyStrtDdTag).ToString()
                                                              , spr.GetValue(rowIdx, AplyEndDdTag).ToString()
                                                              , CodeColumnTag1
                                                              , spr.GetValue(rowIdx, CodeColumnTag1).ToString()
                                                              , CodeColumnTag2
                                                              , spr.GetValue(rowIdx, CodeColumnTag2).ToString()))
            {
                string dupDurationRow = (rowIdx + 1).ToString();
                //겹치는 기간이 없을 때,
                if (dt.Rows.Count == 0)
                {
                    return true;
                }
                //겹치는 기간이 있을 때,
                else
                {//데이터가 하나이면서, Update시 Key컬럼이 변경되었을 때, 즉, 자기 자신의 Key가 되는 컬럼을 변경할 때,
                    if ((dt.Rows.Count == 1) && (isKeyChanged == true))
                        return true;
                    else
                    {
                        if (isMsgBox)
                            LxMessage.Show(dupDurationRow + "번째 줄의" + spr.GetValue(rowIdx, CodeColumnTag1) + ", " + spr.GetValue(rowIdx, CodeColumnTag2) + "코드와 적용기간이 겹치는 동일한 코드가 존재합니다!!", "기간이 겹치는 코드 존재", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// 세개의 코드를 대상으로, 적용기간이 겹치는 코드를 체크하고, 기간이 겹치면 메세지 박스를 띄우고, false를 반환한다.
        /// 스프레드의 CRUD플래그가 Update이면서, 적용일자시작일자,종료일자 체크대상이 되는 코드가 바뀌지 않았으면 기간의 중복을 체크하지 않는다.
        /// </summary>
        /// <param name="spr">확인할 스프레드</param>
        /// <param name="rowIdx">확인할 스프레드의 RowIndex</param>
        /// <param name="TableName">테이블명</param>
        /// <param name="AplyStrtDdTag">적용시작일자의 Tag</param>
        /// <param name="AplyEndDdTag">적용종료일자의 Tag</param>
        /// <param name="CodeColumnTag1">확인 코드의 첫번째 컬럼Tag</param>
        /// <param name="CodeColumnTag2">확인 코드의 두번째 컬럼Tag</param>
        /// <param name="CodeColumnTag3">확인 코드의 세번째 컬럼Tag</param>
        /// <param name="isDelYN">테이블 상의 DEL_YN 필드의 존재여부</param> 
        /// <param name="isMsgBox">오류 발생 시, 메세지박스 출력여부</param> 
        /// <returns></returns>
        public static bool CheckDupDuration(LxSpread spr, int rowIdx, string TableName, string AplyStrtDdTag, string AplyEndDdTag, string CodeColumnTag1, string CodeColumnTag2, string CodeColumnTag3, bool isDelYN, bool isMsgBox)
        {
            #region 중복코드 동시저장 불가
            DataTable CreateDt = new DataTable();
            CreateDt.Columns.Add(new DataColumn("CODE", typeof(string)));
            DataTable DeleteDupDt = new DataTable();
            for (int i = 0; i < spr.ActiveSheet.RowCount; i++)
            {
                if (spr.GetCRUDFromRow(i) == CRUD_TYPE.Create)
                {
                    CreateDt.Rows.Add(spr.GetValue(i, CodeColumnTag1).ToString() + spr.GetValue(i, CodeColumnTag2).ToString() + spr.GetValue(i, CodeColumnTag3).ToString());
                }
            }
            DeleteDupDt = CreateDt.DefaultView.ToTable(true, "CODE");

            if (CreateDt.Rows.Count != DeleteDupDt.Rows.Count)
            {
                if (isMsgBox)
                    LxMessage.Show("새로 저장하는 코드 값은 한번에 두개이상 중복된 값이 될 수 없습니다.", "중복코드 동시저장 불가", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            #endregion

            //Key가 되는 컬럼의 정보가 변경되었는지 체크하는 변수
            bool isKeyChanged = false;

            if (spr.GetCRUDFromRow(rowIdx) == CRUD_TYPE.Update)
                if ((spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() == spr.GetValue(rowIdx, AplyStrtDdTag).ToString())
                   && (spr.GetOldValue(rowIdx, AplyEndDdTag).ToString() == spr.GetValue(rowIdx, AplyEndDdTag).ToString())
                   && (spr.GetOldValue(rowIdx, CodeColumnTag1).ToString() == spr.GetValue(rowIdx, CodeColumnTag1).ToString())
                    && (spr.GetOldValue(rowIdx, CodeColumnTag2).ToString() == spr.GetValue(rowIdx, CodeColumnTag2).ToString())
                    && (spr.GetOldValue(rowIdx, CodeColumnTag3).ToString() == spr.GetValue(rowIdx, CodeColumnTag3).ToString()))
                    return true;
                else
                    isKeyChanged = true;

            string CheckAplySql = "";
            string RevisionSql = " AND DEL_YN = 'A'";
            if (isDelYN)
            {
                CheckAplySql = SQL.BI.Sql.GetMinAplyStrtDd3() + RevisionSql;
                RevisionSql = SQL.BI.Sql.GetDupDuration3() + RevisionSql;
            }
            else
            {
                CheckAplySql = SQL.BI.Sql.GetMinAplyStrtDd3();
                RevisionSql = SQL.BI.Sql.GetDupDuration3();
            }

            //입력하려는 적용 시작일자가 ,기존의 적용시작 일자의 최소 값보다 작으면 Return
            int MinAplyStrtDd = DBService.ExecuteInteger(CheckAplySql, AplyStrtDdTag
                                                                     , TableName
                                                                     , CodeColumnTag1
                                                                     , spr.GetValue(rowIdx, CodeColumnTag1).ToString()
                                                                     , CodeColumnTag2
                                                                     , spr.GetValue(rowIdx, CodeColumnTag2).ToString()
                                                                     , CodeColumnTag3
                                                                     , spr.GetValue(rowIdx, CodeColumnTag3).ToString());

            if (Convert.ToInt32(spr.GetValue(rowIdx, AplyStrtDdTag).ToString()) <= MinAplyStrtDd)
            {
                //자기 자신의 시작일자를 수정하는 경우 제외.
                if ((spr.GetCRUDFromRow(rowIdx) != CRUD_TYPE.Create) && (spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() != MinAplyStrtDd.ToString()))
                {
                    if (isMsgBox)
                        LxMessage.Show("수정 또는 새롭게 저장되는 적용 시작일자는\r\n기존에 같은 코드에 존재하는 적용시작일자보다 같거나 작을 수 없습니다!!", "적용시작일자 재입력필요", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

            }

            DataTable dt = new DataTable();
            if (DBService.ExecuteDataTable(RevisionSql, ref dt, TableName
                                                                             , AplyStrtDdTag
                                                                             , AplyEndDdTag
                                                                             , spr.GetValue(rowIdx, AplyStrtDdTag).ToString()
                                                                             , spr.GetValue(rowIdx, AplyEndDdTag).ToString()
                                                                             , CodeColumnTag1
                                                                             , spr.GetValue(rowIdx, CodeColumnTag1).ToString()
                                                                             , CodeColumnTag2
                                                                             , spr.GetValue(rowIdx, CodeColumnTag2).ToString()
                                                                             , CodeColumnTag3
                                                                             , spr.GetValue(rowIdx, CodeColumnTag3).ToString()))
            {
                string dupDurationRow = (rowIdx + 1).ToString();
                //겹치는 기간이 없을 때,
                if (dt.Rows.Count == 0)
                {
                    return true;
                }
                //겹치는 기간이 있을 때,
                else
                {
                    //데이터가 하나이면서, Update시 Key컬럼이 변경되었을 때, 즉, 자기 자신의 Key가 되는 컬럼을 변경할 때,
                    if ((dt.Rows.Count == 1) && (isKeyChanged == true))
                        return true;
                    else
                    {
                        if (isMsgBox)
                            LxMessage.Show(dupDurationRow + "번째 줄의" + spr.GetValue(rowIdx, CodeColumnTag1) + ", " + spr.GetValue(rowIdx, CodeColumnTag2) + ", " + spr.GetValue(rowIdx, CodeColumnTag3) + "코드와 적용기간이 겹치는 동일한 코드가 존재합니다!!", "기간이 겹치는 코드 존재", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// 네개의 코드를 대상으로, 적용기간이 겹치는 코드를 체크하고, 기간이 겹치면 메세지 박스를 띄우고, false를 반환한다.
        /// 스프레드의 CRUD플래그가 Update이면서, 적용일자시작일자,종료일자 체크대상이 되는 코드가 바뀌지 않았으면 기간의 중복을 체크하지 않는다.
        /// </summary>
        /// <param name="spr">확인할 스프레드</param>
        /// <param name="rowIdx">확인할 스프레드의 RowIndex</param>
        /// <param name="TableName">테이블명</param>
        /// <param name="AplyStrtDdTag">적용시작일자의 Tag</param>
        /// <param name="AplyEndDdTag">적용종료일자의 Tag</param>
        /// <param name="CodeColumnTag1">확인 코드의 첫번째 컬럼Tag</param>
        /// <param name="CodeColumnTag2">확인 코드의 두번째 컬럼Tag</param>
        /// <param name="CodeColumnTag3">확인 코드의 세번째 컬럼Tag</param>
        /// <param name="CodeColumnTag4">확인 코드의 네번째 컬럼Tag</param>
        /// <param name="isDelYN">테이블 상의 DEL_YN 필드의 존재여부</param> 
        /// <param name="isMsgBox">오류 발생 시, 메세지박스 출력여부</param> 
        /// <returns></returns>
        public static bool CheckDupDuration(LxSpread spr, int rowIdx, string TableName, string AplyStrtDdTag, string AplyEndDdTag, string CodeColumnTag1, string CodeColumnTag2, string CodeColumnTag3, string CodeColumnTag4, bool isDelYN, bool isMsgBox)
        {
            #region 중복코드 동시저장 불가
            DataTable CreateDt = new DataTable();
            CreateDt.Columns.Add(new DataColumn("CODE", typeof(string)));
            DataTable DeleteDupDt = new DataTable();
            for (int i = 0; i < spr.ActiveSheet.RowCount; i++)
            {
                if (spr.GetCRUDFromRow(i) == CRUD_TYPE.Create)
                {
                    CreateDt.Rows.Add(spr.GetValue(i, CodeColumnTag1).ToString() + spr.GetValue(i, CodeColumnTag2).ToString() + spr.GetValue(i, CodeColumnTag3).ToString() + spr.GetValue(i, CodeColumnTag4).ToString());
                }
            }
            DeleteDupDt = CreateDt.DefaultView.ToTable(true, "CODE");

            if (CreateDt.Rows.Count != DeleteDupDt.Rows.Count)
            {
                if (isMsgBox)
                    LxMessage.Show("새로 저장하는 코드 값은 한번에 두개이상 중복된 값이 될 수 없습니다.", "중복코드 동시저장 불가", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            #endregion

            //Key가 되는 컬럼의 정보가 변경되었는지 체크하는 변수
            bool isKeyChanged = false;

            if (spr.GetCRUDFromRow(rowIdx) == CRUD_TYPE.Update)
                if ((spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() == spr.GetValue(rowIdx, AplyStrtDdTag).ToString())
                   && (spr.GetOldValue(rowIdx, AplyEndDdTag).ToString() == spr.GetValue(rowIdx, AplyEndDdTag).ToString())
                   && (spr.GetOldValue(rowIdx, CodeColumnTag1).ToString() == spr.GetValue(rowIdx, CodeColumnTag1).ToString())
                    && (spr.GetOldValue(rowIdx, CodeColumnTag2).ToString() == spr.GetValue(rowIdx, CodeColumnTag2).ToString())
                    && (spr.GetOldValue(rowIdx, CodeColumnTag3).ToString() == spr.GetValue(rowIdx, CodeColumnTag3).ToString())
                    && (spr.GetOldValue(rowIdx, CodeColumnTag4).ToString() == spr.GetValue(rowIdx, CodeColumnTag4).ToString()))
                    return true;
                else
                    isKeyChanged = true;

            string CheckAplySql = "";
            string RevisionSql = " AND DEL_YN = 'A'";
            if (isDelYN)
            {
                CheckAplySql = SQL.BI.Sql.GetMinAplyStrtDd3() + RevisionSql;
                RevisionSql = SQL.BI.Sql.GetDupDuration4() + RevisionSql;
            }
            else
            {
                CheckAplySql = SQL.BI.Sql.GetMinAplyStrtDd3();
                RevisionSql = SQL.BI.Sql.GetDupDuration4();
            }

            //입력하려는 적용 시작일자가 ,기존의 적용시작 일자의 최소 값보다 작으면 Return
            int MinAplyStrtDd = DBService.ExecuteInteger(CheckAplySql, AplyStrtDdTag
                                                                     , TableName
                                                                     , CodeColumnTag1
                                                                     , spr.GetValue(rowIdx, CodeColumnTag1).ToString()
                                                                     , CodeColumnTag2
                                                                     , spr.GetValue(rowIdx, CodeColumnTag2).ToString()
                                                                     , CodeColumnTag3
                                                                     , spr.GetValue(rowIdx, CodeColumnTag3).ToString()
                                                                     , CodeColumnTag4
                                                                     , spr.GetValue(rowIdx, CodeColumnTag4).ToString());

            if (Convert.ToInt32(spr.GetValue(rowIdx, AplyStrtDdTag).ToString()) <= MinAplyStrtDd)
            {
                //자기 자신의 시작일자를 수정하는 경우 제외.
                if ((spr.GetCRUDFromRow(rowIdx) != CRUD_TYPE.Create) && (spr.GetOldValue(rowIdx, AplyStrtDdTag).ToString() != MinAplyStrtDd.ToString()))
                {
                    if (isMsgBox)
                        LxMessage.Show("수정 또는 새롭게 저장되는 적용 시작일자는\r\n기존에 같은 코드에 존재하는 적용시작일자보다 같거나 작을 수 없습니다!!", "적용시작일자 재입력필요", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

            }

            DataTable dt = new DataTable();
            if (DBService.ExecuteDataTable(RevisionSql, ref dt, TableName
                                                                             , AplyStrtDdTag
                                                                             , AplyEndDdTag
                                                                             , spr.GetValue(rowIdx, AplyStrtDdTag).ToString()
                                                                             , spr.GetValue(rowIdx, AplyEndDdTag).ToString()
                                                                             , CodeColumnTag1
                                                                             , spr.GetValue(rowIdx, CodeColumnTag1).ToString()
                                                                             , CodeColumnTag2
                                                                             , spr.GetValue(rowIdx, CodeColumnTag2).ToString()
                                                                             , CodeColumnTag3
                                                                             , spr.GetValue(rowIdx, CodeColumnTag3).ToString()
                                                                             , CodeColumnTag4
                                                                             , spr.GetValue(rowIdx, CodeColumnTag4).ToString()))
            {
                string dupDurationRow = (rowIdx + 1).ToString();
                //겹치는 기간이 없을 때,
                if (dt.Rows.Count == 0)
                {
                    return true;
                }
                //겹치는 기간이 있을 때,
                else
                {
                    //데이터가 하나이면서, Update시 Key컬럼이 변경되었을 때, 즉, 자기 자신의 Key가 되는 컬럼을 변경할 때,
                    if ((dt.Rows.Count == 1) && (isKeyChanged == true))
                        return true;
                    else
                    {
                        if (isMsgBox)
                            LxMessage.Show(dupDurationRow + "번째 줄의" + spr.GetValue(rowIdx, CodeColumnTag1) + ", " + spr.GetValue(rowIdx, CodeColumnTag2) + ", " + spr.GetValue(rowIdx, CodeColumnTag3) + ", " + spr.GetValue(rowIdx, CodeColumnTag4) + "코드와 적용기간이 겹치는 동일한 코드가 존재합니다!!", "기간이 겹치는 코드 존재", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                }
            }
            return false;
        }
        #endregion

        #region AppendLine - Spread에 라인을 추가하고, Focus를 추가된 로우의 가장 처음으로 이동시킨다.
        /// <summary>
        /// 라인을 추가하고, Focus를 추가된 로우의 가장 처음으로 이동시킨다.
        /// 라인을 추가할 스프레드에 적용시작일 컬럼이 없으면 2,3 번째 파라미터에 "" 을 넣는다.
        /// </summary>
        /// <param name="spr">라인을 추가할 스프레드</param>
        /// <param name="AplyStrtDdTag">적용시작일자의 컬럼 Tag명</param>
        /// <param name="AplyEndDdTag">적용종료일자의 컬럼 Tag명</param>
        /// <param name="isAplyDd">적용시작일자나 종료일자 컬럼이 있으면 True, 없으면 False</param>
        public static void AppendLine(LxSpread spr, string AplyStrtDdTag, string AplyEndDdTag, bool isAplyDd)
        {
            int addrow = spr.ActiveSheet.ActiveRowIndex;
            spr.AppendRow();
            if (isAplyDd)
            {
                spr.SetText(addrow + 1, AplyStrtDdTag, DateTime.Now.ToString("yyyyMMdd"));
                spr.SetText(addrow + 1, AplyEndDdTag, "29991231");
            }

        }
        #endregion

        #region SetMefeName - Spread의 수가코드에 해당하는 수가명을 자동으로 스프레드에 세팅해주는 함수.
        /// <summary>
        /// 수가코드에 해당하는 수가명을 자동으로 스프레드에 세팅해주는 함수.
        /// 스프레드에서 수가명Column에서 Enter를 쳤을 때 발생하는 이벤트 안에 넣어주면 된다.
        /// 성공시 0, 실패시 1을 반환한다.
        /// </summary>
        /// <param name="spr">사용하는 스프레드 이름</param>
        /// <param name="AplyStrtDdTag">적용시작일자의 컬럼 Tag명</param>
        /// <param name="CodeTag">코드가 있는 컬럼의 Tag명</param>
        /// <param name="MefeNameTag">코드의 명칭이 들어갈 컬럼의 Tag명</param>
        public static int SetMefeName(LxSpread spr, string AplyStrtDdTag, string CodeTag, string MefeNameTag, LxSpread.ChangeExpandEventArgs e)
        {
            if (spr.GetValue(CodeTag).ToString() != "")
            {
                string Name = DBService.ExecuteScalar(SQL.BI.Sql.SelectMefe(), spr.GetValue(CodeTag).ToString().ToUpper()
                                                                             , spr.GetValue(AplyStrtDdTag).ToString()).ToString();

                if (Name != "N")
                {
                    spr.SetText(MefeNameTag, Name);
                    spr.SetText(CodeTag, spr.GetValue(CodeTag).ToString().ToUpper());
                    return 0;
                }
                else
                {
                    LxMessage.Show("코드명과 적용시작일자에 적합한 명칭을 찾을 수 없습니다!!", "코드명 검색불가", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    spr.ActiveSheet.SetActiveCell(spr.ActiveSheet.ActiveRowIndex, spr.ActiveSheet.ActiveColumnIndex);
                    spr.SetText(CodeTag, "");
                    spr.SetText(MefeNameTag, "");
                    e.HoldFocus = true;
                    return 1;
                }
            }

            return 0;
        }
        #endregion

        #region SetSprBICDINDT - 종합코드관리서브로부터 기준일자 관계없이 LWRN_OVRL_CD, LWRN_OVRL_CDNM컬럼으로 스프레드에 콤보박스로 바인딩한다.
        /// <summary>
        /// 종합코드관리서브로부터 기준일자 관계없이 LWRN_OVRL_CD, LWRN_OVRL_CDNM컬럼으로 스프레드에 콤보박스로 바인딩한다.
        /// </summary>
        /// <param name="spr">적용할 스프레드</param>
        /// <param name="OVRL_CD">종합코드관리서브의 조회 조건</param>
        /// <param name="ColumnTag">바인딩할 스프레드의 콤보박스 컬럼 테그</param>
        public static void SetSprBICDINDT(LxSpread spr, string OVRL_CD, string ColumnTag)
        {
            DataTable dt = new DataTable();
            if (DBService.ExecuteDataTable(SQL.BI.Sql.GetBICDINDT2(), ref dt, OVRL_CD))
            {
                if (dt.Rows.Count > 0)
                {
                    spr.SetComboItems(ColumnTag, dt);
                }
            }
        }
        #endregion

        #region ClearSpr - 선택한 범위내의 스프레드의 데이터 초기화
        /// <summary>
        /// 선택한 범위내의 스프레드의 데이터 초기화
        /// </summary>
        /// <param name="spr">적용할 스프레드</param>
        /// <param name="strtRowIdx">시작 로우인덱스</param>
        /// <param name="endRowIdx">종료 로우인덱스</param>
        /// <param name="strtColumnIdx">시작 컬럼인덱스</param>
        /// <param name="endColumnIdx">종료 컬럼인덱스</param>
        public static void ClearSpr(LxSpread spr, int strtRowIdx, int endRowIdx, int strtColumnIdx, int endColumnIdx)
        {
            for (int i = strtRowIdx; i <= endRowIdx; i++)
            {
                for (int k = strtColumnIdx; k <= endColumnIdx; k++)
                {
                    spr.ActiveSheet.Cells[i, k].Value = "";
                    spr.ActiveSheet.Cells[i, k].Text = "";
                }
            }
        }
        #endregion

        #region SetDateTimeToMask - 스프레드에서 원하는 컬럼의 Type을 MaskCellType으로 바꾸고 Format을 0000-00-00으로 지정한다.
        /// <summary>
        /// 스프레드에서 원하는 컬럼의 Type을 MaskCellType으로 바꾸고 Format을 ####-##-##으로 지정한다.
        /// </summary>
        /// <param name="spr">적용할 스프레드</param>
        /// <param name="tagName">적용할 컬럼의 Tag명</param>
        public static void SetDateTimeToMask(LxSpread spr, string tagName)
        {
            FarPoint.Win.Spread.CellType.MaskCellType mskType = new FarPoint.Win.Spread.CellType.MaskCellType();
            mskType.Mask = "####-##-##";
            mskType.MaskChar = '_';

            for (int i = 0; i < spr.ActiveSheet.ColumnCount; i++)
            {
                if ((spr.ActiveSheet.Columns.Get(i).Tag.ToString() == tagName))
                {
                    spr.ActiveSheet.Columns.Get(i).CellType = mskType;
                }
            }
        }
        #endregion

        #region CheckValidDateString - [Spread의 LeaveCell이벤트 안에서 사용] 지정한 컬럼 내 Cell에서 LeaveCell이벤트가 일어날 때, 날짜 형식이 유효하지 않으면 LxMessage를 출력하고 Focus를 이동을 막는다.
        /// <summary>
        /// [Spread의 LeaveCell이벤트 안에서 사용] 지정한 컬럼 내 Cell에서 LeaveCell이벤트가 일어날 때, 날짜 형식이 유효하지 않으면 LxMessage를 출력하고 Focus를 이동을 막는다.
        /// </summary>
        /// <param name="spr">적용할 스프레드</param>
        /// <param name="e">LeaveCellEventArgs e</param>
        /// <param name="tagName">적용할 스프레드의 컬럼Tag 명</param>
        public static void CheckValidDateString(LxSpread spr, FarPoint.Win.Spread.LeaveCellEventArgs e, string tagName)
        {
            string strDate = spr.ActiveSheet.Cells[e.Row, e.Column].Text;

            if (spr.ActiveSheet.Columns.Get(e.Column).Tag.ToString() == tagName)
            {
                if (!DateTimeService.IsDateTime(strDate))
                {
                    LxMessage.Show("유효하지 않은 날짜형식 입니다!!날짜형식을 확인해주세요!!", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    e.Cancel = true;
                    return;
                }
            }

            if (tagName == "APLY_END_DD")
            {
                if (Convert.ToInt32(spr.GetValue("APLY_END_DD").ToString()) > Convert.ToInt32("29991231"))
                {
                    LxMessage.Show("종료일자는 2999년12월31일을 넘을 수 없습니다!!날짜형식을 확인해주세요!!", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    e.Cancel = true;
                    return;
                }
            }
        }
        #endregion

        #region CheckValidDateString - [Spread의 ChangeExpandEventArgs이벤트 안에서 사용] 지정한 컬럼 내 Cell에서 ChangeExpandEventArgs이벤트가 일어날 때, 날짜 형식이 유효하지 않으면 LxMessage를 출력하고 Focus를 이동을 막는다.
        /// <summary>
        /// [Spread의 ChangeExpandEventArgs이벤트 안에서 사용] 지정한 컬럼 내 Cell에서 ChangeExpandEventArgs이벤트가 일어날 때, 날짜 형식이 유효하지 않으면 LxMessage를 출력하고 Focus를 이동을 막는다.
        /// </summary>
        /// <param name="spr"></param>
        /// <param name="e"></param>
        /// <param name="tagName"></param>
        public static void CheckValidDateString(LxSpread spr, LxSpread.ChangeExpandEventArgs e, string tagName)
        {
            string strDate = spr.ActiveSheet.Cells[e.Row, e.Column].Text;

            if (spr.ActiveSheet.Columns.Get(e.Column).Tag.ToString() == tagName)
            {
                if (!DateTimeService.IsDateTime(strDate))
                {
                    LxMessage.Show("유효하지 않은 날짜형식 입니다!!날짜형식을 확인해주세요!!", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    e.HoldFocus = true;
                    return;
                }
            }

            if (tagName == "APLY_END_DD")
            {
                if (Convert.ToInt32(spr.GetValue("APLY_END_DD").ToString()) > 29991231)
                {
                    LxMessage.Show("종료일자는 2999년12월31일을 넘을 수 없습니다!!날짜형식을 확인해주세요!!", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    e.HoldFocus = true;
                    return;
                }
            }
        }
        #endregion

        /// <summary>
        /// 저장 시, 날짜 체크 후 유효하지 않은 날짜이면 해당 Cell로 Focus를 준다.
        /// </summary>
        /// <param name="spr">적용할 스프레드</param>
        /// <param name="strtTag">시작일자 ColumnTag</param>
        /// <param name="endTag">종료일자 ColumnTag</param>
        /// <returns></returns>
        public static bool CheckValidDate(LxSpread spr, string strtTag, string endTag)
        {
            for (int i = 0; i < spr.ActiveSheet.RowCount; i++)
            {
                if ((spr.GetCRUDFromRow(i) == CRUD_TYPE.Create) || (spr.GetCRUDFromRow(i) == CRUD_TYPE.Update))
                {
                    if (!DateTimeService.IsDateTime(spr.GetValue(i, strtTag).ToString()))
                    {
                        LxMessage.Show("유효하지 않은 날짜형식 입니다!!날짜형식을 확인해주세요!!", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        spr.SetActiveCell(i, strtTag);
                        return false;
                    }

                    if (!DateTimeService.IsDateTime(spr.GetValue(i, endTag).ToString()))
                    {
                        LxMessage.Show("유효하지 않은 날짜형식 입니다!!날짜형식을 확인해주세요!!", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        spr.SetActiveCell(i, endTag);
                        return false;
                    }

                    if (TypeCheckService.IsInt(spr.GetValue(i, endTag).ToString()) && Convert.ToInt32(spr.GetValue(i, endTag).ToString()) > 29991231)
                    {
                        LxMessage.Show("종료일자는 2999년12월31일을 넘을 수 없습니다!!날짜형식을 확인해주세요!!", "확인!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        spr.SetActiveCell(i, endTag);
                        return false;
                    }
                }
            }
            return true;
        }

    }
}
