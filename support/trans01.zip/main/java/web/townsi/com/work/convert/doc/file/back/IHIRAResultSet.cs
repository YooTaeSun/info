#region 어셈블리 Interop.HiraDur, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// C:\Lime\Lib\DUR\Interop.HiraDur.dll
#endregion

using System.Runtime.InteropServices;

namespace HiraDur
{
    [Guid("E0E148AB-B5DE-466D-BA3A-01E958A32FC9")]
    [InterfaceType(2)]
    [TypeLibType(4224)]
    public interface IHIRAResultSet
    {
        [DispId(1)]
        void RewindResult();
        [DispId(2)]
        bool NextResult();
        [DispId(3)]
        void ClearResult();
        [DispId(4)]
        int AddReport(int nIndex, string prscReasonCD, string prscReason);
        [DispId(5)]
        int RemoveReport(int nIndex);
        [DispId(6)]
        int ClearReport();

        [DispId(7)]
        int Index { get; }
        [DispId(8)]
        int Totalcnt { get; }
        [DispId(9)]
        int Checkcnt { get; }
        [DispId(10)]
        int Reportcnt { get; }
        [DispId(11)]
        int ErrorCode { get; }
        [DispId(12)]
        int Medicnt { get; }
        [DispId(13)]
        string AgeLimit { get; }
        [DispId(14)]
        string SafeType { get; }
        [DispId(15)]
        double MaxDoseQuantity { get; }
        [DispId(16)]
        int MaxDoseTerm { get; }
        [DispId(17)]
        string HighQuantityMedcCD { get; }
        [DispId(18)]
        string Message { get; }
        [ComAliasName("HiraDur.PrscType")]
        [DispId(19)]
        PrscType PrscTypeA { get; }
        [ComAliasName("HiraDur.PrscType")]
        [DispId(20)]
        PrscType PrscTypeB { get; }
        [DispId(21)]
        string MedcCDA { get; }
        [DispId(22)]
        string MedcCDB { get; }
        [DispId(23)]
        string GnlNMCDA { get; }
        [DispId(24)]
        string GnlNMCDB { get; }
        [DispId(25)]
        float DDMqtyFreqA { get; }
        [DispId(26)]
        float DDMqtyFreqB { get; }
        [DispId(27)]
        float DDExecFreqA { get; }
        [DispId(28)]
        float DDExecFreqB { get; }
        [DispId(29)]
        int MdcnExecFreqA { get; }
        [DispId(30)]
        int MdcnExecFreqB { get; }
        [DispId(31)]
        int Level { get; }
        [DispId(32)]
        string Notice { get; }
        [DispId(33)]
        string ExeDate { get; set; }
        [DispId(34)]
        int Type { get; }
        [DispId(35)]
        string reasonCd { get; }
        [DispId(36)]
        string Reason { get; }
        [DispId(37)]
        string MedcNMA { get; }
        [DispId(38)]
        string MedcNMB { get; }
        [DispId(39)]
        string PrscEndMsg { get; }
        [DispId(40)]
        string RMK { get; }
        [DispId(41)]
        float DDTotalMqtyB { get; }
        [DispId(42)]
        string GnlNMA { get; }
        [DispId(43)]
        string GnlNMB { get; }
        [DispId(44)]
        int UseTogether { get; }
        [DispId(45)]
        int AgeLimitVal { get; }
        [DispId(46)]
        int AgeLimitUnit { get; }
        [DispId(47)]
        string PregnantExamType { get; }
        [DispId(48)]
        string PregnantContradGrade { get; }
        [DispId(49)]
        string MedcInfType { get; }
        [DispId(50)]
        int Informationcnt { get; }
        [DispId(51)]
        int Warningcnt { get; }
        [DispId(52)]
        int Forbiddencnt { get; }
        [DispId(53)]
        int Resultcnt { get; }
        [DispId(54)]
        int Selectcnt { get; }
        [DispId(55)]
        int PregnantLevelChangeWarning { get; }
        [DispId(56)]
        int PregnantLevelChangeInformation { get; }
        [DispId(57)]
        string ExamTypeCD { get; }
        [DispId(58)]
        string DpPrscMake { get; }
        [DispId(59)]
        string DpPrscYYMMDD { get; }
        [DispId(60)]
        string DpPrscHMMSS { get; }
        [DispId(61)]
        string DpPrscAdminCode { get; }
        [DispId(62)]
        string DpPrscGrantNo { get; }
        [DispId(63)]
        string DpPrscAdminName { get; }
        [DispId(64)]
        string DpPrscTel { get; }
        [DispId(65)]
        string DpPrscFax { get; }
        [DispId(66)]
        string DpPrscName { get; }
        [DispId(67)]
        string DpPrscLic { get; }
        [DispId(68)]
        string DpMakeYYMMDD { get; }
        [DispId(69)]
        string DpMakeHMMSS { get; }
        [DispId(70)]
        string DpMakeAdminCode { get; }
        [DispId(71)]
        string DpMakeAdminName { get; }
        [DispId(72)]
        string DpMakeTel { get; }
        [DispId(73)]
        string DpMakeName { get; }
        [DispId(74)]
        string DpMakeLic { get; }
        [DispId(75)]
        int MedicineSerialNo { get; }
        [DispId(76)]
        string MrgNo { get; }
        [DispId(77)]
        string PrscMgmtNo { get; }
    }
}