//********************************************************************
// Class 명 : ucOrecRegInf1
// 역    할 : 환자정보 User Control
// 작 성 자 : PGH
// 작 성 일 : 2017-09-19
//********************************************************************
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Lime.BusinessControls;
using Lime.Framework;
using Lime.Framework.BusinessService;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public partial class ucOrecRegInf1 : BaseUserControl
    {
        

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode) return;

            Initialize();
            InitializeCombo();
            InitializeEvent();

        }

        #region Method : Public Method

        public void Clear()
        {
            // 초기화시 LOCK을 해제한다.
            this.UnLockSystem(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString());

            m_FrvsRvstDvcd = String.Empty;
            m_QtyZeroYn = String.Empty;
            m_TbrcSuptTrgtYn = String.Empty;
            m_HpvSameIlnsYn = String.Empty;
            m_HpvOthrIlnsYn = String.Empty;
            m_AllDcPrscDvcd = String.Empty;
            m_NhicYn = "NO";
            m_TotlMdcrAmt = 0;
            m_DrgMefeYn = String.Empty;
            EnableSave = true;
            m_ChangeFlag = "N";
            m_NhisErrorYn = "N";
            m_ReadOnly = "N";
            OutRegInfo.Clear();
            this.ClearControlData();
            chkReBurn.Checked = false;      //lblForceChange게 안정화되면 없앨거임            
            lblForceChange.Visible = false;
            m_EMRM_MMCD_CD_bk = string.Empty;
            lblPregnant.Visible = false;             // 임부
            lblDisasterSupt.Visible = false;         // 재난지원(코로나19)
            lblPtMdcrStatDvcd9.Visible = false;      // 과취소
            lblIncsDr.Visible = false;               // 산재 지정의

            m_Compare_ASST_TYCD = string.Empty;
            m_Compare_CFSC_RGNO_CD = string.Empty;

        }
        
        #region Method : Private Method
        private void ClearControlData()
        {
            //this.FindChildControls(this.Controls);
            ClearControl(this.Controls);
        }
        
        
		private void ClearControl(Control.ControlCollection controls)
        {
            foreach (Control ctl in controls)
            {
                if (ctl.HasChildren)
                {
                    this.ClearChildControl(ctl);
                    this.ClearControl(ctl.Controls);
                }
                else
                {
                    this.ClearChildControl(ctl);
                }

            }

            txtTbrcDvcd.Text = string.Empty;
            lblMDCAREHSPTHSPTZYN.Visible = false;
        }
        
        private void ClearChildControl(Control controls)
        {
            if (controls is LxTextBox)
            {
                ((LxTextBox)controls).Text = String.Empty;
            }
            else if (controls is LxComboBox)
            {
                LxComboBox cboBox = controls as LxComboBox;

                cboBox.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
                cboBox.Clear();
            }
            else if (controls is LxMaskedEdit)
            {
                ((LxMaskedEdit)controls).Text = String.Empty;
            }
            else if (controls is LxDateTimeEditor)
            {
                ((LxDateTimeEditor)controls).DateTime = DateTimeService.ConvertDateTime(m_Mdcr_Dd);
            }
            else if (controls is LxTitleLabel)
            {
                LxTitleLabel lblLabel = controls as LxTitleLabel;

                string lbl = lblLabel.Text;

                if (lblLabel.Tag == "C")
                {
                    lblLabel.Appearance.ForeColor = Color.Blue;
                    lblLabel.Appearance.FontData.Bold = Infragistics.Win.DefaultableBoolean.True;
                }
            }
        }        
        

    }
}
