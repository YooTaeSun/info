namespace Lime.PA
{
    partial class ucObillInf1
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinEditors.EditorButton editorButton1 = new Infragistics.Win.UltraWinEditors.EditorButton();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance23 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance24 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinEditors.EditorButton editorButton2 = new Infragistics.Win.UltraWinEditors.EditorButton();
            Infragistics.Win.Appearance appearance25 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance26 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance27 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance28 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance29 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance30 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance31 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance32 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance33 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance34 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance35 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance36 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance37 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance38 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance39 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance40 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance41 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance42 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinEditors.EditorButton editorButton3 = new Infragistics.Win.UltraWinEditors.EditorButton();
            Infragistics.Win.Appearance appearance43 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance44 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance45 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinEditors.EditorButton editorButton4 = new Infragistics.Win.UltraWinEditors.EditorButton();
            Infragistics.Win.Appearance appearance46 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance47 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance48 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance49 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance50 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance51 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance52 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance53 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance54 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance55 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance56 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance57 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinEditors.EditorButton editorButton5 = new Infragistics.Win.UltraWinEditors.EditorButton();
            Infragistics.Win.Appearance appearance58 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance59 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance60 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance61 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance62 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance63 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance64 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance65 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance66 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance67 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance68 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance69 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance70 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance71 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance72 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance73 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance74 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance75 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance76 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance77 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance78 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance79 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance80 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance81 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance82 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance83 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance84 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance85 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance86 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance87 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance88 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance89 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance90 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance91 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance92 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance93 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance94 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance95 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance96 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance97 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance98 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance99 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance100 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance101 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance102 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance103 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance104 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance105 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance106 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance107 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance108 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance109 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance110 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance111 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance112 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance113 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance114 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance115 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance116 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance117 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance118 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance119 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance120 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance121 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance122 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance123 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance124 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance125 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance126 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance127 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance128 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance129 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance130 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance131 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance132 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance133 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance134 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance135 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance136 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance137 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance138 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance139 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance140 = new Infragistics.Win.Appearance();
            Infragistics.Win.ValueListItem valueListItem1 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.ValueListItem valueListItem2 = new Infragistics.Win.ValueListItem();
            Infragistics.Win.Appearance appearance141 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance142 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinEditors.EditorButton editorButton6 = new Infragistics.Win.UltraWinEditors.EditorButton();
            Infragistics.Win.Appearance appearance143 = new Infragistics.Win.Appearance();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucObillInf1));
            Infragistics.Win.Appearance appearance144 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance145 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinEditors.EditorButton editorButton7 = new Infragistics.Win.UltraWinEditors.EditorButton();
            Infragistics.Win.Appearance appearance146 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance147 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance148 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance149 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance150 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance151 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance152 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance153 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance154 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance155 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance156 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance157 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance158 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            this.lxTitlePanel1 = new Lime.Framework.Controls.LxTitlePanel();
            this.btnTabletReceipt = new Lime.Framework.Controls.LxButton();
            this.btnBillNoApply = new Lime.Framework.Controls.LxButton();
            this.btnPermitCancel = new Lime.Framework.Controls.LxButton();
            this.lblCashRcpt = new Lime.Framework.Controls.LxLabel();
            this.lxPanel1 = new Lime.Framework.Controls.LxPanel();
            this.txtFocus = new Lime.Framework.Controls.LxTextBox();
            this.txtCttrUnclAplyAmt = new Lime.Framework.Controls.LxTextBox();
            this.cboUnclCd = new Lime.Framework.Controls.LxComboBox();
            this.txtFrtmBnacAmt = new Lime.Framework.Controls.LxTextBox();
            this.txtBnacRcptAmt = new Lime.Framework.Controls.LxTextBox();
            this.txtFrtmCashRcptAmt = new Lime.Framework.Controls.LxTextBox();
            this.txtFrtmBnacAmt_C = new Lime.Framework.Controls.LxTextBox();
            this.txtFrtmCardRcptAmt_C = new Lime.Framework.Controls.LxTextBox();
            this.txtFrtmCashRcptAmt_C = new Lime.Framework.Controls.LxTextBox();
            this.txtBnacRcptAmt_ing = new Lime.Framework.Controls.LxTextBox();
            this.lxTitleLabel4 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtCardRcptAmt_ing = new Lime.Framework.Controls.LxTextBox();
            this.txtCashRcptAmt_ing = new Lime.Framework.Controls.LxTextBox();
            this.txtCardRcptAmt = new Lime.Framework.Controls.LxTextBox();
            this.txtCashRcptAmt = new Lime.Framework.Controls.LxTextBox();
            this.lxTextBox1 = new Lime.Framework.Controls.LxTextBox();
            this.cboSpclDcntDvcd = new Lime.Framework.Controls.LxComboBox();
            this.chkCashPrmtYn = new Lime.Framework.Controls.LxCheckBox();
            this.lblTbrcCtctSuptAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.lblVcntClamAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.lblTotlMdcrAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtBlodRdiaAmt = new Lime.Framework.Controls.LxTextBox();
            this.lblPayTamt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtTotalPtSharAmt = new Lime.Framework.Controls.LxTextBox();
            this.txtPtSharAmt = new Lime.Framework.Controls.LxTextBox();
            this.txtFrtmRcptTotlAmt = new Lime.Framework.Controls.LxTextBox();
            this.lblInsn100Tamt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtDcntRdiaAmt = new Lime.Framework.Controls.LxTextBox();
            this.lblScngPayTamt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtFrtmDcntRdiaAmt = new Lime.Framework.Controls.LxTextBox();
            this.lblClamNopyTamt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtScngPayClamAmt = new Lime.Framework.Controls.LxTextBox();
            this.lblNopyTamt = new Lime.Framework.Controls.LxTitleLabel();
            this.lblAdedValuTaxTamt = new Lime.Framework.Controls.LxTitleLabel();
            this.LxTitleLabel1 = new Lime.Framework.Controls.LxTitleLabel();
            this.lblFrtmRcptTotlAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.lblBlodRdiaAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.lblDcntRdiaCd = new Lime.Framework.Controls.LxTitleLabel();
            this.lblSpclDcntAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtFrtmCardRcptAmt = new Lime.Framework.Controls.LxTextBox();
            this.lblSpclDcntDvcd = new Lime.Framework.Controls.LxTitleLabel();
            this.lblDcntRdiaEmno = new Lime.Framework.Controls.LxTitleLabel();
            this.txtEmrgSuptAmt = new Lime.Framework.Controls.LxTextBox();
            this.lblRcvdAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtUnclAmt = new Lime.Framework.Controls.LxTextBox();
            this.lblFrtmCashRcptAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtVcntClamAmt = new Lime.Framework.Controls.LxTextBox();
            this.lblCardRcptAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtTbrcCtctSuptAmt = new Lime.Framework.Controls.LxTextBox();
            this.lblFrtmCardRcptAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtHllfMncsClamAmt = new Lime.Framework.Controls.LxTextBox();
            this.lblBnacRcptAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtSuptAmt = new Lime.Framework.Controls.LxTextBox();
            this.lblUnclCd = new Lime.Framework.Controls.LxTitleLabel();
            this.txtHmptPayTamt = new Lime.Framework.Controls.LxTextBox();
            this.txtPayClamAmt = new Lime.Framework.Controls.LxTextBox();
            this.txtDsblFundAmt = new Lime.Framework.Controls.LxTextBox();
            this.lblUnclAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtPayUschAmt = new Lime.Framework.Controls.LxTextBox();
            this.lblSmcrAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtSmcrAmt = new Lime.Framework.Controls.LxTextBox();
            this.lblPayUschAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtAdedValuTaxTamt = new Lime.Framework.Controls.LxTextBox();
            this.lxTitleLabel3 = new Lime.Framework.Controls.LxTitleLabel();
            this.lxTitleLabel2 = new Lime.Framework.Controls.LxTitleLabel();
            this.lblAsctSharAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtNopyTamt = new Lime.Framework.Controls.LxTextBox();
            this.lblSuptAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtClamNopyTamt = new Lime.Framework.Controls.LxTextBox();
            this.lblHllfMncsClamAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtScngPayUschAmt = new Lime.Framework.Controls.LxTextBox();
            this.txtInsn100Tamt = new Lime.Framework.Controls.LxTextBox();
            this.txtPayTamt = new Lime.Framework.Controls.LxTextBox();
            this.lblCttrUnclAplyAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.lblEmrgSuptAmt = new Lime.Framework.Controls.LxTitleLabel();
            this.txtTotlMdcrAmt = new Lime.Framework.Controls.LxTextBox();
            this.cboBldnYn = new Lime.Framework.Controls.LxComboBox();
            this.txtDcntRdiaEmnm = new Lime.Framework.Controls.LxTextBox();
            this.txtDcntRdiaEmno = new Lime.Framework.Controls.LxTextBox();
            this.cboDcntRdiaCd = new Lime.Framework.Controls.LxComboBox();
            this.txtRfndResn = new Lime.Framework.Controls.LxTextBox();
            this.txtUnclResn = new Lime.Framework.Controls.LxTextBox();
            this.txtDcntResn = new Lime.Framework.Controls.LxTextBox();
            this.txtSpclDcntAmt = new Lime.Framework.Controls.LxTextBox();
            this.lxTitleLabel5 = new Lime.Framework.Controls.LxTitleLabel();
            this.txtGvrnClamAmt = new Lime.Framework.Controls.LxTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).BeginInit();
            this.pnlBase.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitlePanel1)).BeginInit();
            this.lxTitlePanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnTabletReceipt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnBillNoApply)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnPermitCancel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCashRcpt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel1)).BeginInit();
            this.lxPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtFocus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCttrUnclAplyAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboUnclCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrtmBnacAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBnacRcptAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrtmCashRcptAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrtmBnacAmt_C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrtmCardRcptAmt_C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrtmCashRcptAmt_C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBnacRcptAmt_ing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitleLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCardRcptAmt_ing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCashRcptAmt_ing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCardRcptAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCashRcptAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTextBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboSpclDcntDvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCashPrmtYn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTbrcCtctSuptAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblVcntClamAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTotlMdcrAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBlodRdiaAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPayTamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalPtSharAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPtSharAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrtmRcptTotlAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblInsn100Tamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDcntRdiaAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblScngPayTamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrtmDcntRdiaAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblClamNopyTamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtScngPayClamAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblNopyTamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblAdedValuTaxTamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblFrtmRcptTotlAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBlodRdiaAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblDcntRdiaCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSpclDcntAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrtmCardRcptAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSpclDcntDvcd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblDcntRdiaEmno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEmrgSuptAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblRcvdAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUnclAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblFrtmCashRcptAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVcntClamAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCardRcptAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTbrcCtctSuptAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblFrtmCardRcptAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHllfMncsClamAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBnacRcptAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuptAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblUnclCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHmptPayTamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayClamAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDsblFundAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblUnclAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayUschAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSmcrAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSmcrAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPayUschAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAdedValuTaxTamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitleLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitleLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblAsctSharAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNopyTamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSuptAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtClamNopyTamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblHllfMncsClamAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtScngPayUschAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInsn100Tamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTamt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCttrUnclAplyAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblEmrgSuptAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotlMdcrAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboBldnYn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDcntRdiaEmnm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDcntRdiaEmno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDcntRdiaCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRfndResn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUnclResn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDcntResn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSpclDcntAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitleLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGvrnClamAmt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBase
            // 
            this.pnlBase.Controls.Add(this.lxTitlePanel1);
            this.pnlBase.Size = new System.Drawing.Size(508, 523);
            // 
            // lxTitlePanel1
            // 
            this.lxTitlePanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.lxTitlePanel1.BottomBarVisible = false;
            this.lxTitlePanel1.BottomText = "";
            this.lxTitlePanel1.Controls.Add(this.btnTabletReceipt);
            this.lxTitlePanel1.Controls.Add(this.btnBillNoApply);
            this.lxTitlePanel1.Controls.Add(this.btnPermitCancel);
            this.lxTitlePanel1.Controls.Add(this.lblCashRcpt);
            this.lxTitlePanel1.Controls.Add(this.lxPanel1);
            this.lxTitlePanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lxTitlePanel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxTitlePanel1.Location = new System.Drawing.Point(0, 0);
            this.lxTitlePanel1.Name = "lxTitlePanel1";
            this.lxTitlePanel1.Padding = new System.Windows.Forms.Padding(3);
            this.lxTitlePanel1.Size = new System.Drawing.Size(508, 523);
            this.lxTitlePanel1.TabIndex = 6;
            this.lxTitlePanel1.TitleText = "영수정보";
            // 
            // btnTabletReceipt
            // 
            appearance1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance1.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance1.FontData.BoldAsString = "False";
            appearance1.FontData.Name = "맑은 고딕";
            appearance1.FontData.SizeInPoints = 9F;
            appearance1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(90)))), ((int)(((byte)(20)))));
            appearance1.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance1.TextHAlignAsString = "Center";
            appearance1.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance1.TextVAlignAsString = "Middle";
            this.btnTabletReceipt.Appearance = appearance1;
            this.btnTabletReceipt.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat;
            appearance2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance2.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance2.FontData.BoldAsString = "True";
            appearance2.FontData.Name = "맑은 고딕";
            appearance2.FontData.SizeInPoints = 9F;
            appearance2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance2.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance2.TextHAlignAsString = "Center";
            appearance2.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance2.TextVAlignAsString = "Middle";
            this.btnTabletReceipt.HotTrackAppearance = appearance2;
            this.btnTabletReceipt.Location = new System.Drawing.Point(225, 7);
            this.btnTabletReceipt.Name = "btnTabletReceipt";
            appearance3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance3.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance3.FontData.BoldAsString = "True";
            appearance3.FontData.Name = "맑은 고딕";
            appearance3.FontData.SizeInPoints = 8F;
            appearance3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance3.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance3.TextHAlignAsString = "Center";
            appearance3.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance3.TextVAlignAsString = "Middle";
            this.btnTabletReceipt.PressedAppearance = appearance3;
            this.btnTabletReceipt.Size = new System.Drawing.Size(80, 23);
            this.btnTabletReceipt.TabIndex = 16;
            this.btnTabletReceipt.Text = "영수증보기";
            this.btnTabletReceipt.UseFlatMode = Infragistics.Win.DefaultableBoolean.False;
            this.btnTabletReceipt.UseHotTracking = Infragistics.Win.DefaultableBoolean.True;
            this.btnTabletReceipt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.btnTabletReceipt.WrapText = false;
            // 
            // btnBillNoApply
            // 
            appearance4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance4.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance4.FontData.BoldAsString = "False";
            appearance4.FontData.Name = "맑은 고딕";
            appearance4.FontData.SizeInPoints = 9F;
            appearance4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(90)))), ((int)(((byte)(20)))));
            appearance4.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance4.TextHAlignAsString = "Center";
            appearance4.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance4.TextVAlignAsString = "Middle";
            this.btnBillNoApply.Appearance = appearance4;
            this.btnBillNoApply.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat;
            appearance5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance5.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance5.FontData.BoldAsString = "True";
            appearance5.FontData.Name = "맑은 고딕";
            appearance5.FontData.SizeInPoints = 9F;
            appearance5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance5.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance5.TextHAlignAsString = "Center";
            appearance5.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance5.TextVAlignAsString = "Middle";
            this.btnBillNoApply.HotTrackAppearance = appearance5;
            this.btnBillNoApply.Location = new System.Drawing.Point(306, 7);
            this.btnBillNoApply.Name = "btnBillNoApply";
            appearance6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance6.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance6.FontData.BoldAsString = "True";
            appearance6.FontData.Name = "맑은 고딕";
            appearance6.FontData.SizeInPoints = 8F;
            appearance6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance6.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance6.TextHAlignAsString = "Center";
            appearance6.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance6.TextVAlignAsString = "Middle";
            this.btnBillNoApply.PressedAppearance = appearance6;
            this.btnBillNoApply.Size = new System.Drawing.Size(80, 23);
            this.btnBillNoApply.TabIndex = 15;
            this.btnBillNoApply.Text = "승인내역적용";
            this.btnBillNoApply.UseFlatMode = Infragistics.Win.DefaultableBoolean.False;
            this.btnBillNoApply.UseHotTracking = Infragistics.Win.DefaultableBoolean.True;
            this.btnBillNoApply.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.btnBillNoApply.WrapText = false;
            // 
            // btnPermitCancel
            // 
            appearance7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance7.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance7.FontData.BoldAsString = "False";
            appearance7.FontData.Name = "맑은 고딕";
            appearance7.FontData.SizeInPoints = 9F;
            appearance7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(90)))), ((int)(((byte)(20)))));
            appearance7.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance7.TextHAlignAsString = "Center";
            appearance7.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance7.TextVAlignAsString = "Middle";
            this.btnPermitCancel.Appearance = appearance7;
            this.btnPermitCancel.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Flat;
            appearance8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance8.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance8.FontData.BoldAsString = "True";
            appearance8.FontData.Name = "맑은 고딕";
            appearance8.FontData.SizeInPoints = 9F;
            appearance8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance8.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance8.TextHAlignAsString = "Center";
            appearance8.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance8.TextVAlignAsString = "Middle";
            this.btnPermitCancel.HotTrackAppearance = appearance8;
            this.btnPermitCancel.Location = new System.Drawing.Point(387, 7);
            this.btnPermitCancel.Name = "btnPermitCancel";
            appearance9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance9.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            appearance9.FontData.BoldAsString = "True";
            appearance9.FontData.Name = "맑은 고딕";
            appearance9.FontData.SizeInPoints = 8F;
            appearance9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(50)))));
            appearance9.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance9.TextHAlignAsString = "Center";
            appearance9.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance9.TextVAlignAsString = "Middle";
            this.btnPermitCancel.PressedAppearance = appearance9;
            this.btnPermitCancel.Size = new System.Drawing.Size(111, 23);
            this.btnPermitCancel.TabIndex = 14;
            this.btnPermitCancel.Text = "카드/현금 승인취소";
            this.btnPermitCancel.UseFlatMode = Infragistics.Win.DefaultableBoolean.False;
            this.btnPermitCancel.UseHotTracking = Infragistics.Win.DefaultableBoolean.True;
            this.btnPermitCancel.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.btnPermitCancel.WrapText = false;
            this.btnPermitCancel.Click += new System.EventHandler(this.btnPermitCancel_Click);
            // 
            // lblCashRcpt
            // 
            appearance10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance10.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance10.FontData.Name = "맑은 고딕";
            appearance10.FontData.SizeInPoints = 8F;
            appearance10.ForeColor = System.Drawing.Color.Red;
            appearance10.TextHAlignAsString = "Center";
            appearance10.TextVAlignAsString = "Middle";
            this.lblCashRcpt.Appearance = appearance10;
            this.lblCashRcpt.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.None;
            this.lblCashRcpt.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblCashRcpt.Location = new System.Drawing.Point(108, 4);
            this.lblCashRcpt.Name = "lblCashRcpt";
            this.lblCashRcpt.Size = new System.Drawing.Size(83, 29);
            this.lblCashRcpt.TabIndex = 10;
            this.lblCashRcpt.Text = "현금영수증\r\n의무발행 대상";
            this.lblCashRcpt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblCashRcpt.UseLimeStyle = false;
            this.lblCashRcpt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.lblCashRcpt.Visible = false;
            // 
            // lxPanel1
            // 
            this.lxPanel1.BackColor = System.Drawing.Color.White;
            this.lxPanel1.Controls.Add(this.lxTitleLabel5);
            this.lxPanel1.Controls.Add(this.txtGvrnClamAmt);
            this.lxPanel1.Controls.Add(this.txtFocus);
            this.lxPanel1.Controls.Add(this.txtCttrUnclAplyAmt);
            this.lxPanel1.Controls.Add(this.cboUnclCd);
            this.lxPanel1.Controls.Add(this.txtFrtmBnacAmt);
            this.lxPanel1.Controls.Add(this.txtBnacRcptAmt);
            this.lxPanel1.Controls.Add(this.txtFrtmCashRcptAmt);
            this.lxPanel1.Controls.Add(this.txtFrtmBnacAmt_C);
            this.lxPanel1.Controls.Add(this.txtFrtmCardRcptAmt_C);
            this.lxPanel1.Controls.Add(this.txtFrtmCashRcptAmt_C);
            this.lxPanel1.Controls.Add(this.txtBnacRcptAmt_ing);
            this.lxPanel1.Controls.Add(this.lxTitleLabel4);
            this.lxPanel1.Controls.Add(this.txtCardRcptAmt_ing);
            this.lxPanel1.Controls.Add(this.txtCashRcptAmt_ing);
            this.lxPanel1.Controls.Add(this.txtCardRcptAmt);
            this.lxPanel1.Controls.Add(this.txtCashRcptAmt);
            this.lxPanel1.Controls.Add(this.lxTextBox1);
            this.lxPanel1.Controls.Add(this.cboSpclDcntDvcd);
            this.lxPanel1.Controls.Add(this.chkCashPrmtYn);
            this.lxPanel1.Controls.Add(this.lblTbrcCtctSuptAmt);
            this.lxPanel1.Controls.Add(this.lblVcntClamAmt);
            this.lxPanel1.Controls.Add(this.lblTotlMdcrAmt);
            this.lxPanel1.Controls.Add(this.txtBlodRdiaAmt);
            this.lxPanel1.Controls.Add(this.lblPayTamt);
            this.lxPanel1.Controls.Add(this.txtTotalPtSharAmt);
            this.lxPanel1.Controls.Add(this.txtPtSharAmt);
            this.lxPanel1.Controls.Add(this.txtFrtmRcptTotlAmt);
            this.lxPanel1.Controls.Add(this.lblInsn100Tamt);
            this.lxPanel1.Controls.Add(this.txtDcntRdiaAmt);
            this.lxPanel1.Controls.Add(this.lblScngPayTamt);
            this.lxPanel1.Controls.Add(this.txtFrtmDcntRdiaAmt);
            this.lxPanel1.Controls.Add(this.lblClamNopyTamt);
            this.lxPanel1.Controls.Add(this.txtScngPayClamAmt);
            this.lxPanel1.Controls.Add(this.lblNopyTamt);
            this.lxPanel1.Controls.Add(this.lblAdedValuTaxTamt);
            this.lxPanel1.Controls.Add(this.LxTitleLabel1);
            this.lxPanel1.Controls.Add(this.lblFrtmRcptTotlAmt);
            this.lxPanel1.Controls.Add(this.lblBlodRdiaAmt);
            this.lxPanel1.Controls.Add(this.lblDcntRdiaCd);
            this.lxPanel1.Controls.Add(this.lblSpclDcntAmt);
            this.lxPanel1.Controls.Add(this.txtFrtmCardRcptAmt);
            this.lxPanel1.Controls.Add(this.lblSpclDcntDvcd);
            this.lxPanel1.Controls.Add(this.lblDcntRdiaEmno);
            this.lxPanel1.Controls.Add(this.txtEmrgSuptAmt);
            this.lxPanel1.Controls.Add(this.lblRcvdAmt);
            this.lxPanel1.Controls.Add(this.txtUnclAmt);
            this.lxPanel1.Controls.Add(this.lblFrtmCashRcptAmt);
            this.lxPanel1.Controls.Add(this.txtVcntClamAmt);
            this.lxPanel1.Controls.Add(this.lblCardRcptAmt);
            this.lxPanel1.Controls.Add(this.txtTbrcCtctSuptAmt);
            this.lxPanel1.Controls.Add(this.lblFrtmCardRcptAmt);
            this.lxPanel1.Controls.Add(this.txtHllfMncsClamAmt);
            this.lxPanel1.Controls.Add(this.lblBnacRcptAmt);
            this.lxPanel1.Controls.Add(this.txtSuptAmt);
            this.lxPanel1.Controls.Add(this.lblUnclCd);
            this.lxPanel1.Controls.Add(this.txtHmptPayTamt);
            this.lxPanel1.Controls.Add(this.txtPayClamAmt);
            this.lxPanel1.Controls.Add(this.txtDsblFundAmt);
            this.lxPanel1.Controls.Add(this.lblUnclAmt);
            this.lxPanel1.Controls.Add(this.txtPayUschAmt);
            this.lxPanel1.Controls.Add(this.lblSmcrAmt);
            this.lxPanel1.Controls.Add(this.txtSmcrAmt);
            this.lxPanel1.Controls.Add(this.lblPayUschAmt);
            this.lxPanel1.Controls.Add(this.txtAdedValuTaxTamt);
            this.lxPanel1.Controls.Add(this.lxTitleLabel3);
            this.lxPanel1.Controls.Add(this.lxTitleLabel2);
            this.lxPanel1.Controls.Add(this.lblAsctSharAmt);
            this.lxPanel1.Controls.Add(this.txtNopyTamt);
            this.lxPanel1.Controls.Add(this.lblSuptAmt);
            this.lxPanel1.Controls.Add(this.txtClamNopyTamt);
            this.lxPanel1.Controls.Add(this.lblHllfMncsClamAmt);
            this.lxPanel1.Controls.Add(this.txtScngPayUschAmt);
            this.lxPanel1.Controls.Add(this.txtInsn100Tamt);
            this.lxPanel1.Controls.Add(this.txtPayTamt);
            this.lxPanel1.Controls.Add(this.lblCttrUnclAplyAmt);
            this.lxPanel1.Controls.Add(this.lblEmrgSuptAmt);
            this.lxPanel1.Controls.Add(this.txtTotlMdcrAmt);
            this.lxPanel1.Controls.Add(this.cboBldnYn);
            this.lxPanel1.Controls.Add(this.txtDcntRdiaEmnm);
            this.lxPanel1.Controls.Add(this.txtDcntRdiaEmno);
            this.lxPanel1.Controls.Add(this.cboDcntRdiaCd);
            this.lxPanel1.Controls.Add(this.txtRfndResn);
            this.lxPanel1.Controls.Add(this.txtUnclResn);
            this.lxPanel1.Controls.Add(this.txtDcntResn);
            this.lxPanel1.Controls.Add(this.txtSpclDcntAmt);
            this.lxPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lxPanel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxPanel1.Location = new System.Drawing.Point(3, 35);
            this.lxPanel1.Name = "lxPanel1";
            this.lxPanel1.Size = new System.Drawing.Size(502, 485);
            this.lxPanel1.TabIndex = 9;
            // 
            // txtFocus
            // 
            appearance14.BackColor = System.Drawing.Color.White;
            appearance14.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance14.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFocus.Appearance = appearance14;
            this.txtFocus.BackColor = System.Drawing.Color.White;
            this.txtFocus.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtFocus.Location = new System.Drawing.Point(129, 466);
            this.txtFocus.Name = "txtFocus";
            appearance15.BackColor = System.Drawing.Color.White;
            appearance15.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance15.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFocus.NullTextAppearance = appearance15;
            this.txtFocus.Size = new System.Drawing.Size(124, 23);
            this.txtFocus.TabIndex = 49;
            this.txtFocus.Text = "Focus Leave용...ㅎ";
            this.txtFocus.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtFocus.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtCttrUnclAplyAmt
            // 
            appearance16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance16.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance16.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance16.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance16.TextHAlignAsString = "Right";
            appearance16.TextVAlignAsString = "Middle";
            this.txtCttrUnclAplyAmt.Appearance = appearance16;
            this.txtCttrUnclAplyAmt.AutoSize = false;
            this.txtCttrUnclAplyAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtCttrUnclAplyAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance17.BackColor = System.Drawing.Color.Transparent;
            appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance17.BorderColor = System.Drawing.Color.Transparent;
            appearance17.BorderColor2 = System.Drawing.Color.Transparent;
            appearance17.Image = global::Lime.PA.Properties.Resources.Button_Icon1;
            appearance17.ImageHAlign = Infragistics.Win.HAlign.Right;
            appearance17.ImageVAlign = Infragistics.Win.VAlign.Middle;
            editorButton1.Appearance = appearance17;
            editorButton1.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Button;
            editorButton1.Width = 18;
            this.txtCttrUnclAplyAmt.ButtonsRight.Add(editorButton1);
            this.txtCttrUnclAplyAmt.EnterKeyToTab = true;
            this.txtCttrUnclAplyAmt.Location = new System.Drawing.Point(95, 432);
            this.txtCttrUnclAplyAmt.Name = "txtCttrUnclAplyAmt";
            appearance18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance18.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance18.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance18.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance18.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtCttrUnclAplyAmt.NullTextAppearance = appearance18;
            this.txtCttrUnclAplyAmt.ReadOnly = true;
            this.txtCttrUnclAplyAmt.Size = new System.Drawing.Size(136, 23);
            this.txtCttrUnclAplyAmt.TabIndex = 48;
            this.txtCttrUnclAplyAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtCttrUnclAplyAmt.UseLimeStyle = false;
            this.txtCttrUnclAplyAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboUnclCd
            // 
            appearance19.BackColor = System.Drawing.Color.White;
            appearance19.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance19.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboUnclCd.Appearance = appearance19;
            this.cboUnclCd.BackColor = System.Drawing.Color.White;
            this.cboUnclCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance20.BackColor = System.Drawing.Color.Transparent;
            appearance20.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance20.BorderColor = System.Drawing.Color.Transparent;
            appearance20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance20.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboUnclCd.ButtonAppearance = appearance20;
            this.cboUnclCd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboUnclCd.Location = new System.Drawing.Point(305, 408);
            this.cboUnclCd.Name = "cboUnclCd";
            appearance21.BackColor = System.Drawing.Color.White;
            appearance21.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance21.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance21.ForeColor = System.Drawing.Color.DarkGray;
            appearance21.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboUnclCd.NullTextAppearance = appearance21;
            this.cboUnclCd.SelectedValue = "";
            this.cboUnclCd.Size = new System.Drawing.Size(190, 21);
            this.cboUnclCd.TabIndex = 47;
            this.cboUnclCd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboUnclCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboUnclCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtFrtmBnacAmt
            // 
            appearance22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance22.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance22.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance22.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance22.TextHAlignAsString = "Right";
            appearance22.TextVAlignAsString = "Middle";
            this.txtFrtmBnacAmt.Appearance = appearance22;
            this.txtFrtmBnacAmt.AutoSize = false;
            this.txtFrtmBnacAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtFrtmBnacAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtFrtmBnacAmt.EnterKeyToTab = true;
            this.txtFrtmBnacAmt.Location = new System.Drawing.Point(386, 332);
            this.txtFrtmBnacAmt.Name = "txtFrtmBnacAmt";
            appearance23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance23.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance23.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance23.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFrtmBnacAmt.NullTextAppearance = appearance23;
            this.txtFrtmBnacAmt.ReadOnly = true;
            this.txtFrtmBnacAmt.Size = new System.Drawing.Size(109, 23);
            this.txtFrtmBnacAmt.TabIndex = 42;
            this.txtFrtmBnacAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtFrtmBnacAmt.UseLimeStyle = false;
            this.txtFrtmBnacAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtBnacRcptAmt
            // 
            appearance24.BackColor = System.Drawing.Color.White;
            appearance24.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance24.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance24.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance24.TextHAlignAsString = "Right";
            appearance24.TextVAlignAsString = "Middle";
            this.txtBnacRcptAmt.Appearance = appearance24;
            this.txtBnacRcptAmt.AutoSize = false;
            this.txtBnacRcptAmt.BackColor = System.Drawing.Color.White;
            this.txtBnacRcptAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance25.BackColor = System.Drawing.Color.Transparent;
            appearance25.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance25.BorderColor = System.Drawing.Color.Transparent;
            appearance25.BorderColor2 = System.Drawing.Color.Transparent;
            appearance25.Image = global::Lime.PA.Properties.Resources.Button_Icon1;
            appearance25.ImageHAlign = Infragistics.Win.HAlign.Right;
            appearance25.ImageVAlign = Infragistics.Win.VAlign.Middle;
            editorButton2.Appearance = appearance25;
            editorButton2.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Button;
            editorButton2.Width = 18;
            this.txtBnacRcptAmt.ButtonsRight.Add(editorButton2);
            this.txtBnacRcptAmt.EnterKeyToTab = true;
            this.txtBnacRcptAmt.Location = new System.Drawing.Point(386, 307);
            this.txtBnacRcptAmt.Name = "txtBnacRcptAmt";
            appearance26.BackColor = System.Drawing.Color.White;
            appearance26.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance26.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance26.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance26.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtBnacRcptAmt.NullTextAppearance = appearance26;
            this.txtBnacRcptAmt.Size = new System.Drawing.Size(109, 23);
            this.txtBnacRcptAmt.TabIndex = 40;
            this.txtBnacRcptAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtBnacRcptAmt.UseLimeStyle = false;
            this.txtBnacRcptAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtFrtmCashRcptAmt
            // 
            appearance27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance27.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance27.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance27.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance27.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance27.TextHAlignAsString = "Right";
            appearance27.TextVAlignAsString = "Middle";
            this.txtFrtmCashRcptAmt.Appearance = appearance27;
            this.txtFrtmCashRcptAmt.AutoSize = false;
            this.txtFrtmCashRcptAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtFrtmCashRcptAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtFrtmCashRcptAmt.EnterKeyToTab = true;
            this.txtFrtmCashRcptAmt.Location = new System.Drawing.Point(386, 232);
            this.txtFrtmCashRcptAmt.Name = "txtFrtmCashRcptAmt";
            appearance28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance28.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance28.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance28.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFrtmCashRcptAmt.NullTextAppearance = appearance28;
            this.txtFrtmCashRcptAmt.ReadOnly = true;
            this.txtFrtmCashRcptAmt.Size = new System.Drawing.Size(109, 23);
            this.txtFrtmCashRcptAmt.TabIndex = 34;
            this.txtFrtmCashRcptAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtFrtmCashRcptAmt.UseLimeStyle = false;
            this.txtFrtmCashRcptAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtFrtmBnacAmt_C
            // 
            appearance29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance29.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance29.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance29.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance29.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance29.TextHAlignAsString = "Right";
            this.txtFrtmBnacAmt_C.Appearance = appearance29;
            this.txtFrtmBnacAmt_C.AutoSize = false;
            this.txtFrtmBnacAmt_C.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtFrtmBnacAmt_C.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtFrtmBnacAmt_C.Location = new System.Drawing.Point(305, 332);
            this.txtFrtmBnacAmt_C.Name = "txtFrtmBnacAmt_C";
            appearance30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance30.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance30.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance30.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance30.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFrtmBnacAmt_C.NullTextAppearance = appearance30;
            this.txtFrtmBnacAmt_C.ReadOnly = true;
            this.txtFrtmBnacAmt_C.Size = new System.Drawing.Size(79, 23);
            this.txtFrtmBnacAmt_C.TabIndex = 41;
            this.txtFrtmBnacAmt_C.TabStop = false;
            this.txtFrtmBnacAmt_C.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtFrtmBnacAmt_C.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtFrtmCardRcptAmt_C
            // 
            appearance31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance31.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance31.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance31.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance31.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance31.TextHAlignAsString = "Right";
            this.txtFrtmCardRcptAmt_C.Appearance = appearance31;
            this.txtFrtmCardRcptAmt_C.AutoSize = false;
            this.txtFrtmCardRcptAmt_C.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtFrtmCardRcptAmt_C.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtFrtmCardRcptAmt_C.Location = new System.Drawing.Point(305, 282);
            this.txtFrtmCardRcptAmt_C.Name = "txtFrtmCardRcptAmt_C";
            appearance32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance32.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance32.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance32.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance32.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFrtmCardRcptAmt_C.NullTextAppearance = appearance32;
            this.txtFrtmCardRcptAmt_C.ReadOnly = true;
            this.txtFrtmCardRcptAmt_C.Size = new System.Drawing.Size(79, 23);
            this.txtFrtmCardRcptAmt_C.TabIndex = 37;
            this.txtFrtmCardRcptAmt_C.TabStop = false;
            this.txtFrtmCardRcptAmt_C.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtFrtmCardRcptAmt_C.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtFrtmCashRcptAmt_C
            // 
            appearance33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance33.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance33.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance33.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance33.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance33.TextHAlignAsString = "Right";
            this.txtFrtmCashRcptAmt_C.Appearance = appearance33;
            this.txtFrtmCashRcptAmt_C.AutoSize = false;
            this.txtFrtmCashRcptAmt_C.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtFrtmCashRcptAmt_C.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtFrtmCashRcptAmt_C.Location = new System.Drawing.Point(305, 232);
            this.txtFrtmCashRcptAmt_C.Name = "txtFrtmCashRcptAmt_C";
            appearance34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance34.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance34.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance34.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance34.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFrtmCashRcptAmt_C.NullTextAppearance = appearance34;
            this.txtFrtmCashRcptAmt_C.ReadOnly = true;
            this.txtFrtmCashRcptAmt_C.Size = new System.Drawing.Size(79, 23);
            this.txtFrtmCashRcptAmt_C.TabIndex = 33;
            this.txtFrtmCashRcptAmt_C.TabStop = false;
            this.txtFrtmCashRcptAmt_C.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtFrtmCashRcptAmt_C.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtBnacRcptAmt_ing
            // 
            appearance35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance35.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance35.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance35.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance35.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance35.TextHAlignAsString = "Right";
            this.txtBnacRcptAmt_ing.Appearance = appearance35;
            this.txtBnacRcptAmt_ing.AutoSize = false;
            this.txtBnacRcptAmt_ing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtBnacRcptAmt_ing.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtBnacRcptAmt_ing.Location = new System.Drawing.Point(305, 307);
            this.txtBnacRcptAmt_ing.Name = "txtBnacRcptAmt_ing";
            appearance36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance36.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance36.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance36.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance36.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtBnacRcptAmt_ing.NullTextAppearance = appearance36;
            this.txtBnacRcptAmt_ing.ReadOnly = true;
            this.txtBnacRcptAmt_ing.Size = new System.Drawing.Size(79, 23);
            this.txtBnacRcptAmt_ing.TabIndex = 39;
            this.txtBnacRcptAmt_ing.TabStop = false;
            this.txtBnacRcptAmt_ing.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtBnacRcptAmt_ing.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lxTitleLabel4
            // 
            appearance37.BackColor = System.Drawing.Color.Transparent;
            appearance37.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance37.FontData.Name = "맑은 고딕";
            appearance37.FontData.SizeInPoints = 9F;
            appearance37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance37.TextHAlignAsString = "Right";
            appearance37.TextVAlignAsString = "Middle";
            this.lxTitleLabel4.Appearance = appearance37;
            this.lxTitleLabel4.Location = new System.Drawing.Point(248, 332);
            this.lxTitleLabel4.Margin = new System.Windows.Forms.Padding(0);
            this.lxTitleLabel4.Name = "lxTitleLabel4";
            this.lxTitleLabel4.Size = new System.Drawing.Size(54, 23);
            this.lxTitleLabel4.TabIndex = 43;
            this.lxTitleLabel4.Text = "기통장액";
            this.lxTitleLabel4.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lxTitleLabel4.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtCardRcptAmt_ing
            // 
            appearance38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance38.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance38.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance38.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance38.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance38.TextHAlignAsString = "Right";
            this.txtCardRcptAmt_ing.Appearance = appearance38;
            this.txtCardRcptAmt_ing.AutoSize = false;
            this.txtCardRcptAmt_ing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtCardRcptAmt_ing.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtCardRcptAmt_ing.Location = new System.Drawing.Point(305, 257);
            this.txtCardRcptAmt_ing.Name = "txtCardRcptAmt_ing";
            appearance39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance39.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance39.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance39.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance39.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtCardRcptAmt_ing.NullTextAppearance = appearance39;
            this.txtCardRcptAmt_ing.ReadOnly = true;
            this.txtCardRcptAmt_ing.Size = new System.Drawing.Size(79, 23);
            this.txtCardRcptAmt_ing.TabIndex = 35;
            this.txtCardRcptAmt_ing.TabStop = false;
            this.txtCardRcptAmt_ing.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtCardRcptAmt_ing.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtCashRcptAmt_ing
            // 
            appearance40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance40.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance40.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance40.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance40.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance40.TextHAlignAsString = "Right";
            this.txtCashRcptAmt_ing.Appearance = appearance40;
            this.txtCashRcptAmt_ing.AutoSize = false;
            this.txtCashRcptAmt_ing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtCashRcptAmt_ing.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtCashRcptAmt_ing.Location = new System.Drawing.Point(305, 207);
            this.txtCashRcptAmt_ing.Name = "txtCashRcptAmt_ing";
            appearance41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance41.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance41.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance41.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance41.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtCashRcptAmt_ing.NullTextAppearance = appearance41;
            this.txtCashRcptAmt_ing.ReadOnly = true;
            this.txtCashRcptAmt_ing.Size = new System.Drawing.Size(79, 23);
            this.txtCashRcptAmt_ing.TabIndex = 31;
            this.txtCashRcptAmt_ing.TabStop = false;
            this.txtCashRcptAmt_ing.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtCashRcptAmt_ing.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtCardRcptAmt
            // 
            appearance42.BackColor = System.Drawing.Color.White;
            appearance42.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance42.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance42.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance42.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance42.TextHAlignAsString = "Right";
            appearance42.TextVAlignAsString = "Middle";
            this.txtCardRcptAmt.Appearance = appearance42;
            this.txtCardRcptAmt.AutoSize = false;
            this.txtCardRcptAmt.BackColor = System.Drawing.Color.White;
            this.txtCardRcptAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance43.BackColor = System.Drawing.Color.Transparent;
            appearance43.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance43.BorderColor = System.Drawing.Color.Transparent;
            appearance43.BorderColor2 = System.Drawing.Color.Transparent;
            appearance43.Image = global::Lime.PA.Properties.Resources.Button_Icon1;
            appearance43.ImageHAlign = Infragistics.Win.HAlign.Right;
            appearance43.ImageVAlign = Infragistics.Win.VAlign.Middle;
            editorButton3.Appearance = appearance43;
            editorButton3.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Button;
            editorButton3.Width = 18;
            this.txtCardRcptAmt.ButtonsRight.Add(editorButton3);
            this.txtCardRcptAmt.EnterKeyToTab = true;
            this.txtCardRcptAmt.Location = new System.Drawing.Point(386, 257);
            this.txtCardRcptAmt.Name = "txtCardRcptAmt";
            appearance44.BackColor = System.Drawing.Color.White;
            appearance44.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance44.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance44.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance44.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance44.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtCardRcptAmt.NullTextAppearance = appearance44;
            this.txtCardRcptAmt.Size = new System.Drawing.Size(109, 23);
            this.txtCardRcptAmt.TabIndex = 36;
            this.txtCardRcptAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtCardRcptAmt.UseLimeStyle = false;
            this.txtCardRcptAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtCashRcptAmt
            // 
            appearance45.BackColor = System.Drawing.Color.White;
            appearance45.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance45.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance45.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance45.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance45.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance45.TextHAlignAsString = "Right";
            appearance45.TextVAlignAsString = "Middle";
            this.txtCashRcptAmt.Appearance = appearance45;
            this.txtCashRcptAmt.AutoSize = false;
            this.txtCashRcptAmt.BackColor = System.Drawing.Color.White;
            this.txtCashRcptAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance46.BackColor = System.Drawing.Color.Transparent;
            appearance46.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance46.BorderColor = System.Drawing.Color.Transparent;
            appearance46.BorderColor2 = System.Drawing.Color.Transparent;
            appearance46.Image = global::Lime.PA.Properties.Resources.Button_Icon1;
            appearance46.ImageHAlign = Infragistics.Win.HAlign.Right;
            appearance46.ImageVAlign = Infragistics.Win.VAlign.Middle;
            editorButton4.Appearance = appearance46;
            editorButton4.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Button;
            editorButton4.Width = 18;
            this.txtCashRcptAmt.ButtonsRight.Add(editorButton4);
            this.txtCashRcptAmt.EnterKeyToTab = true;
            this.txtCashRcptAmt.Location = new System.Drawing.Point(386, 207);
            this.txtCashRcptAmt.Name = "txtCashRcptAmt";
            appearance47.BackColor = System.Drawing.Color.White;
            appearance47.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance47.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance47.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance47.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtCashRcptAmt.NullTextAppearance = appearance47;
            this.txtCashRcptAmt.Size = new System.Drawing.Size(109, 23);
            this.txtCashRcptAmt.TabIndex = 32;
            this.txtCashRcptAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtCashRcptAmt.UseLimeStyle = false;
            this.txtCashRcptAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lxTextBox1
            // 
            appearance48.BackColor = System.Drawing.Color.White;
            appearance48.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance48.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance48.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance48.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance48.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxTextBox1.Appearance = appearance48;
            this.lxTextBox1.BackColor = System.Drawing.Color.White;
            this.lxTextBox1.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.lxTextBox1.Location = new System.Drawing.Point(184, 463);
            this.lxTextBox1.Name = "lxTextBox1";
            appearance49.BackColor = System.Drawing.Color.White;
            appearance49.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance49.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance49.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance49.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance49.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxTextBox1.NullTextAppearance = appearance49;
            this.lxTextBox1.Size = new System.Drawing.Size(110, 23);
            this.lxTextBox1.TabIndex = 13;
            this.lxTextBox1.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lxTextBox1.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.lxTextBox1.Visible = false;
            // 
            // cboSpclDcntDvcd
            // 
            appearance50.BackColor = System.Drawing.Color.White;
            appearance50.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance50.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance50.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance50.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance50.ForeColorDisabled = System.Drawing.Color.DarkGray;
            appearance50.TextHAlignAsString = "Left";
            this.cboSpclDcntDvcd.Appearance = appearance50;
            this.cboSpclDcntDvcd.AutoSize = false;
            this.cboSpclDcntDvcd.BackColor = System.Drawing.Color.White;
            this.cboSpclDcntDvcd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance51.BackColor = System.Drawing.Color.Transparent;
            appearance51.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance51.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance51.BorderColor = System.Drawing.Color.Transparent;
            appearance51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance51.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboSpclDcntDvcd.ButtonAppearance = appearance51;
            this.cboSpclDcntDvcd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboSpclDcntDvcd.EnterKeyToTab = true;
            this.cboSpclDcntDvcd.Location = new System.Drawing.Point(305, 182);
            this.cboSpclDcntDvcd.Name = "cboSpclDcntDvcd";
            appearance52.BackColor = System.Drawing.Color.White;
            appearance52.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance52.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance52.ForeColor = System.Drawing.Color.DarkGray;
            appearance52.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboSpclDcntDvcd.NullTextAppearance = appearance52;
            this.cboSpclDcntDvcd.SelectedValue = "";
            this.cboSpclDcntDvcd.Size = new System.Drawing.Size(79, 23);
            this.cboSpclDcntDvcd.TabIndex = 29;
            this.cboSpclDcntDvcd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboSpclDcntDvcd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboSpclDcntDvcd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.cboSpclDcntDvcd.ValueChangedMoveNextFocus = true;
            // 
            // chkCashPrmtYn
            // 
            appearance53.BackColor = System.Drawing.Color.Transparent;
            appearance53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.chkCashPrmtYn.Appearance = appearance53;
            this.chkCashPrmtYn.BackColor = System.Drawing.Color.Transparent;
            this.chkCashPrmtYn.BackColorInternal = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.chkCashPrmtYn.Enabled = false;
            this.chkCashPrmtYn.Location = new System.Drawing.Point(443, 481);
            this.chkCashPrmtYn.Name = "chkCashPrmtYn";
            this.chkCashPrmtYn.Size = new System.Drawing.Size(15, 16);
            this.chkCashPrmtYn.TabIndex = 8;
            this.chkCashPrmtYn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.chkCashPrmtYn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.chkCashPrmtYn.Visible = false;
            // 
            // lblTbrcCtctSuptAmt
            // 
            appearance54.BackColor = System.Drawing.Color.Transparent;
            appearance54.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance54.FontData.Name = "맑은 고딕";
            appearance54.FontData.SizeInPoints = 9F;
            appearance54.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance54.TextHAlignAsString = "Right";
            appearance54.TextVAlignAsString = "Middle";
            this.lblTbrcCtctSuptAmt.Appearance = appearance54;
            this.lblTbrcCtctSuptAmt.Location = new System.Drawing.Point(13, 357);
            this.lblTbrcCtctSuptAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblTbrcCtctSuptAmt.Name = "lblTbrcCtctSuptAmt";
            this.lblTbrcCtctSuptAmt.Size = new System.Drawing.Size(79, 23);
            this.lblTbrcCtctSuptAmt.TabIndex = 0;
            this.lblTbrcCtctSuptAmt.Text = "결핵접촉지원";
            this.lblTbrcCtctSuptAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblTbrcCtctSuptAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblVcntClamAmt
            // 
            appearance55.BackColor = System.Drawing.Color.Transparent;
            appearance55.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance55.FontData.Name = "맑은 고딕";
            appearance55.FontData.SizeInPoints = 9F;
            appearance55.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance55.TextHAlignAsString = "Right";
            appearance55.TextVAlignAsString = "Middle";
            this.lblVcntClamAmt.Appearance = appearance55;
            this.lblVcntClamAmt.Location = new System.Drawing.Point(13, 382);
            this.lblVcntClamAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblVcntClamAmt.Name = "lblVcntClamAmt";
            this.lblVcntClamAmt.Size = new System.Drawing.Size(79, 23);
            this.lblVcntClamAmt.TabIndex = 0;
            this.lblVcntClamAmt.Text = "예방접종청구";
            this.lblVcntClamAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblVcntClamAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblTotlMdcrAmt
            // 
            appearance56.BackColor = System.Drawing.Color.Transparent;
            appearance56.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance56.FontData.Name = "맑은 고딕";
            appearance56.FontData.SizeInPoints = 9F;
            appearance56.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance56.TextHAlignAsString = "Right";
            appearance56.TextVAlignAsString = "Middle";
            this.lblTotlMdcrAmt.Appearance = appearance56;
            this.lblTotlMdcrAmt.Location = new System.Drawing.Point(38, 7);
            this.lblTotlMdcrAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblTotlMdcrAmt.Name = "lblTotlMdcrAmt";
            this.lblTotlMdcrAmt.Size = new System.Drawing.Size(54, 23);
            this.lblTotlMdcrAmt.TabIndex = 0;
            this.lblTotlMdcrAmt.Text = "총진료비";
            this.lblTotlMdcrAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblTotlMdcrAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtBlodRdiaAmt
            // 
            appearance57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance57.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance57.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance57.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance57.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance57.TextHAlignAsString = "Right";
            this.txtBlodRdiaAmt.Appearance = appearance57;
            this.txtBlodRdiaAmt.AutoSize = false;
            this.txtBlodRdiaAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtBlodRdiaAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance58.BackColor = System.Drawing.Color.Transparent;
            appearance58.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance58.BorderColor = System.Drawing.Color.Transparent;
            appearance58.BorderColor2 = System.Drawing.Color.Transparent;
            appearance58.Image = global::Lime.PA.Properties.Resources.Button_Icon1;
            appearance58.ImageHAlign = Infragistics.Win.HAlign.Left;
            appearance58.ImageVAlign = Infragistics.Win.VAlign.Middle;
            editorButton5.Appearance = appearance58;
            editorButton5.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Button;
            editorButton5.Width = 18;
            this.txtBlodRdiaAmt.ButtonsLeft.Add(editorButton5);
            this.txtBlodRdiaAmt.Location = new System.Drawing.Point(355, 57);
            this.txtBlodRdiaAmt.Name = "txtBlodRdiaAmt";
            appearance59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance59.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance59.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance59.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance59.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance59.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtBlodRdiaAmt.NullTextAppearance = appearance59;
            this.txtBlodRdiaAmt.ReadOnly = true;
            this.txtBlodRdiaAmt.Size = new System.Drawing.Size(140, 23);
            this.txtBlodRdiaAmt.TabIndex = 23;
            this.txtBlodRdiaAmt.TabStop = false;
            this.txtBlodRdiaAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtBlodRdiaAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblPayTamt
            // 
            appearance60.BackColor = System.Drawing.Color.Transparent;
            appearance60.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance60.FontData.Name = "맑은 고딕";
            appearance60.FontData.SizeInPoints = 9F;
            appearance60.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance60.TextHAlignAsString = "Right";
            appearance60.TextVAlignAsString = "Middle";
            this.lblPayTamt.Appearance = appearance60;
            this.lblPayTamt.Location = new System.Drawing.Point(38, 32);
            this.lblPayTamt.Margin = new System.Windows.Forms.Padding(0);
            this.lblPayTamt.Name = "lblPayTamt";
            this.lblPayTamt.Size = new System.Drawing.Size(54, 23);
            this.lblPayTamt.TabIndex = 0;
            this.lblPayTamt.Text = "급여총액";
            this.lblPayTamt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblPayTamt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtTotalPtSharAmt
            // 
            appearance61.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance61.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance61.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance61.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance61.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance61.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance61.TextHAlignAsString = "Right";
            this.txtTotalPtSharAmt.Appearance = appearance61;
            this.txtTotalPtSharAmt.AutoSize = false;
            this.txtTotalPtSharAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtTotalPtSharAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtTotalPtSharAmt.Location = new System.Drawing.Point(42, 463);
            this.txtTotalPtSharAmt.Name = "txtTotalPtSharAmt";
            appearance62.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance62.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance62.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance62.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance62.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance62.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtTotalPtSharAmt.NullTextAppearance = appearance62;
            this.txtTotalPtSharAmt.ReadOnly = true;
            this.txtTotalPtSharAmt.Size = new System.Drawing.Size(136, 23);
            this.txtTotalPtSharAmt.TabIndex = 5;
            this.txtTotalPtSharAmt.TabStop = false;
            this.txtTotalPtSharAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtTotalPtSharAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.txtTotalPtSharAmt.Visible = false;
            // 
            // txtPtSharAmt
            // 
            appearance63.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance63.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance63.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance63.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance63.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance63.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance63.TextHAlignAsString = "Right";
            this.txtPtSharAmt.Appearance = appearance63;
            this.txtPtSharAmt.AutoSize = false;
            this.txtPtSharAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtPtSharAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtPtSharAmt.Location = new System.Drawing.Point(305, 7);
            this.txtPtSharAmt.Name = "txtPtSharAmt";
            appearance64.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance64.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance64.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance64.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance64.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance64.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtPtSharAmt.NullTextAppearance = appearance64;
            this.txtPtSharAmt.ReadOnly = true;
            this.txtPtSharAmt.Size = new System.Drawing.Size(190, 23);
            this.txtPtSharAmt.TabIndex = 20;
            this.txtPtSharAmt.TabStop = false;
            this.txtPtSharAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtPtSharAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtFrtmRcptTotlAmt
            // 
            appearance65.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance65.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance65.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance65.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance65.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance65.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance65.TextHAlignAsString = "Right";
            this.txtFrtmRcptTotlAmt.Appearance = appearance65;
            this.txtFrtmRcptTotlAmt.AutoSize = false;
            this.txtFrtmRcptTotlAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtFrtmRcptTotlAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtFrtmRcptTotlAmt.Location = new System.Drawing.Point(305, 32);
            this.txtFrtmRcptTotlAmt.Name = "txtFrtmRcptTotlAmt";
            appearance66.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance66.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance66.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance66.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance66.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance66.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFrtmRcptTotlAmt.NullTextAppearance = appearance66;
            this.txtFrtmRcptTotlAmt.ReadOnly = true;
            this.txtFrtmRcptTotlAmt.Size = new System.Drawing.Size(190, 23);
            this.txtFrtmRcptTotlAmt.TabIndex = 21;
            this.txtFrtmRcptTotlAmt.TabStop = false;
            this.txtFrtmRcptTotlAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtFrtmRcptTotlAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblInsn100Tamt
            // 
            appearance67.BackColor = System.Drawing.Color.Transparent;
            appearance67.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance67.FontData.Name = "맑은 고딕";
            appearance67.FontData.SizeInPoints = 9F;
            appearance67.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance67.TextHAlignAsString = "Right";
            appearance67.TextVAlignAsString = "Middle";
            this.lblInsn100Tamt.Appearance = appearance67;
            this.lblInsn100Tamt.Location = new System.Drawing.Point(42, 57);
            this.lblInsn100Tamt.Margin = new System.Windows.Forms.Padding(0);
            this.lblInsn100Tamt.Name = "lblInsn100Tamt";
            this.lblInsn100Tamt.Size = new System.Drawing.Size(50, 23);
            this.lblInsn100Tamt.TabIndex = 0;
            this.lblInsn100Tamt.Text = "보험100";
            this.lblInsn100Tamt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblInsn100Tamt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtDcntRdiaAmt
            // 
            appearance68.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance68.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance68.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance68.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance68.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance68.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance68.TextHAlignAsString = "Right";
            this.txtDcntRdiaAmt.Appearance = appearance68;
            this.txtDcntRdiaAmt.AutoSize = false;
            this.txtDcntRdiaAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtDcntRdiaAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtDcntRdiaAmt.Enabled = false;
            this.txtDcntRdiaAmt.Location = new System.Drawing.Point(386, 107);
            this.txtDcntRdiaAmt.MaxLength = 12;
            this.txtDcntRdiaAmt.Name = "txtDcntRdiaAmt";
            appearance69.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance69.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance69.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance69.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance69.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance69.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtDcntRdiaAmt.NullTextAppearance = appearance69;
            this.txtDcntRdiaAmt.ReadOnly = true;
            this.txtDcntRdiaAmt.Size = new System.Drawing.Size(109, 23);
            this.txtDcntRdiaAmt.TabIndex = 26;
            this.txtDcntRdiaAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtDcntRdiaAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblScngPayTamt
            // 
            appearance70.BackColor = System.Drawing.Color.Transparent;
            appearance70.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance70.FontData.Name = "맑은 고딕";
            appearance70.FontData.SizeInPoints = 9F;
            appearance70.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance70.TextHAlignAsString = "Right";
            appearance70.TextVAlignAsString = "Middle";
            this.lblScngPayTamt.Appearance = appearance70;
            this.lblScngPayTamt.Location = new System.Drawing.Point(0, 82);
            this.lblScngPayTamt.Margin = new System.Windows.Forms.Padding(0);
            this.lblScngPayTamt.Name = "lblScngPayTamt";
            this.lblScngPayTamt.Size = new System.Drawing.Size(92, 23);
            this.lblScngPayTamt.TabIndex = 0;
            this.lblScngPayTamt.Text = "선별본인/청구";
            this.lblScngPayTamt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblScngPayTamt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtFrtmDcntRdiaAmt
            // 
            appearance71.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance71.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance71.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance71.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance71.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance71.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance71.TextHAlignAsString = "Right";
            this.txtFrtmDcntRdiaAmt.Appearance = appearance71;
            this.txtFrtmDcntRdiaAmt.AutoSize = false;
            this.txtFrtmDcntRdiaAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtFrtmDcntRdiaAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtFrtmDcntRdiaAmt.Enabled = false;
            this.txtFrtmDcntRdiaAmt.Location = new System.Drawing.Point(305, 107);
            this.txtFrtmDcntRdiaAmt.Name = "txtFrtmDcntRdiaAmt";
            appearance72.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance72.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance72.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance72.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance72.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance72.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFrtmDcntRdiaAmt.NullTextAppearance = appearance72;
            this.txtFrtmDcntRdiaAmt.ReadOnly = true;
            this.txtFrtmDcntRdiaAmt.Size = new System.Drawing.Size(79, 23);
            this.txtFrtmDcntRdiaAmt.TabIndex = 25;
            this.txtFrtmDcntRdiaAmt.TabStop = false;
            this.txtFrtmDcntRdiaAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtFrtmDcntRdiaAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblClamNopyTamt
            // 
            appearance73.BackColor = System.Drawing.Color.Transparent;
            appearance73.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance73.FontData.Name = "맑은 고딕";
            appearance73.FontData.SizeInPoints = 9F;
            appearance73.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance73.TextHAlignAsString = "Right";
            appearance73.TextVAlignAsString = "Middle";
            this.lblClamNopyTamt.Appearance = appearance73;
            this.lblClamNopyTamt.Location = new System.Drawing.Point(26, 107);
            this.lblClamNopyTamt.Margin = new System.Windows.Forms.Padding(0);
            this.lblClamNopyTamt.Name = "lblClamNopyTamt";
            this.lblClamNopyTamt.Size = new System.Drawing.Size(66, 23);
            this.lblClamNopyTamt.TabIndex = 0;
            this.lblClamNopyTamt.Text = "청구비급여";
            this.lblClamNopyTamt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblClamNopyTamt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtScngPayClamAmt
            // 
            appearance74.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance74.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance74.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance74.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance74.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance74.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance74.TextHAlignAsString = "Right";
            this.txtScngPayClamAmt.Appearance = appearance74;
            this.txtScngPayClamAmt.AutoSize = false;
            this.txtScngPayClamAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtScngPayClamAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtScngPayClamAmt.Location = new System.Drawing.Point(164, 82);
            this.txtScngPayClamAmt.Name = "txtScngPayClamAmt";
            appearance75.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance75.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance75.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance75.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance75.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance75.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtScngPayClamAmt.NullTextAppearance = appearance75;
            this.txtScngPayClamAmt.ReadOnly = true;
            this.txtScngPayClamAmt.Size = new System.Drawing.Size(67, 23);
            this.txtScngPayClamAmt.TabIndex = 5;
            this.txtScngPayClamAmt.TabStop = false;
            this.txtScngPayClamAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtScngPayClamAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblNopyTamt
            // 
            appearance76.BackColor = System.Drawing.Color.Transparent;
            appearance76.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance76.FontData.Name = "맑은 고딕";
            appearance76.FontData.SizeInPoints = 9F;
            appearance76.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance76.TextHAlignAsString = "Right";
            appearance76.TextVAlignAsString = "Middle";
            this.lblNopyTamt.Appearance = appearance76;
            this.lblNopyTamt.Location = new System.Drawing.Point(50, 132);
            this.lblNopyTamt.Margin = new System.Windows.Forms.Padding(0);
            this.lblNopyTamt.Name = "lblNopyTamt";
            this.lblNopyTamt.Size = new System.Drawing.Size(42, 23);
            this.lblNopyTamt.TabIndex = 0;
            this.lblNopyTamt.Text = "비급여";
            this.lblNopyTamt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblNopyTamt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblAdedValuTaxTamt
            // 
            appearance77.BackColor = System.Drawing.Color.Transparent;
            appearance77.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance77.FontData.Name = "맑은 고딕";
            appearance77.FontData.SizeInPoints = 9F;
            appearance77.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance77.TextHAlignAsString = "Right";
            appearance77.TextVAlignAsString = "Middle";
            this.lblAdedValuTaxTamt.Appearance = appearance77;
            this.lblAdedValuTaxTamt.Location = new System.Drawing.Point(50, 157);
            this.lblAdedValuTaxTamt.Margin = new System.Windows.Forms.Padding(0);
            this.lblAdedValuTaxTamt.Name = "lblAdedValuTaxTamt";
            this.lblAdedValuTaxTamt.Size = new System.Drawing.Size(42, 23);
            this.lblAdedValuTaxTamt.TabIndex = 0;
            this.lblAdedValuTaxTamt.Text = "부가세";
            this.lblAdedValuTaxTamt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblAdedValuTaxTamt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // LxTitleLabel1
            // 
            appearance78.BackColor = System.Drawing.Color.Transparent;
            appearance78.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance78.FontData.Name = "맑은 고딕";
            appearance78.FontData.SizeInPoints = 9F;
            appearance78.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance78.TextHAlignAsString = "Right";
            appearance78.TextVAlignAsString = "Middle";
            this.LxTitleLabel1.Appearance = appearance78;
            this.LxTitleLabel1.Location = new System.Drawing.Point(248, 7);
            this.LxTitleLabel1.Margin = new System.Windows.Forms.Padding(0);
            this.LxTitleLabel1.Name = "LxTitleLabel1";
            this.LxTitleLabel1.Size = new System.Drawing.Size(54, 23);
            this.LxTitleLabel1.TabIndex = 0;
            this.LxTitleLabel1.Text = "본인총액";
            this.LxTitleLabel1.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.LxTitleLabel1.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblFrtmRcptTotlAmt
            // 
            appearance79.BackColor = System.Drawing.Color.Transparent;
            appearance79.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance79.FontData.Name = "맑은 고딕";
            appearance79.FontData.SizeInPoints = 9F;
            appearance79.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance79.TextHAlignAsString = "Right";
            appearance79.TextVAlignAsString = "Middle";
            this.lblFrtmRcptTotlAmt.Appearance = appearance79;
            this.lblFrtmRcptTotlAmt.Location = new System.Drawing.Point(236, 32);
            this.lblFrtmRcptTotlAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblFrtmRcptTotlAmt.Name = "lblFrtmRcptTotlAmt";
            this.lblFrtmRcptTotlAmt.Size = new System.Drawing.Size(66, 23);
            this.lblFrtmRcptTotlAmt.TabIndex = 0;
            this.lblFrtmRcptTotlAmt.Text = "기수납합계";
            this.lblFrtmRcptTotlAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblFrtmRcptTotlAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblBlodRdiaAmt
            // 
            appearance80.BackColor = System.Drawing.Color.Transparent;
            appearance80.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance80.FontData.Name = "맑은 고딕";
            appearance80.FontData.SizeInPoints = 9F;
            appearance80.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance80.TextHAlignAsString = "Right";
            appearance80.TextVAlignAsString = "Middle";
            this.lblBlodRdiaAmt.Appearance = appearance80;
            this.lblBlodRdiaAmt.Location = new System.Drawing.Point(248, 57);
            this.lblBlodRdiaAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblBlodRdiaAmt.Name = "lblBlodRdiaAmt";
            this.lblBlodRdiaAmt.Size = new System.Drawing.Size(54, 23);
            this.lblBlodRdiaAmt.TabIndex = 0;
            this.lblBlodRdiaAmt.Text = "헌혈감액";
            this.lblBlodRdiaAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblBlodRdiaAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblDcntRdiaCd
            // 
            appearance81.BackColor = System.Drawing.Color.Transparent;
            appearance81.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance81.FontData.Name = "맑은 고딕";
            appearance81.FontData.SizeInPoints = 9F;
            appearance81.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance81.TextHAlignAsString = "Right";
            appearance81.TextVAlignAsString = "Middle";
            this.lblDcntRdiaCd.Appearance = appearance81;
            this.lblDcntRdiaCd.Location = new System.Drawing.Point(248, 82);
            this.lblDcntRdiaCd.Margin = new System.Windows.Forms.Padding(0);
            this.lblDcntRdiaCd.Name = "lblDcntRdiaCd";
            this.lblDcntRdiaCd.Size = new System.Drawing.Size(54, 23);
            this.lblDcntRdiaCd.TabIndex = 0;
            this.lblDcntRdiaCd.Text = "할인코드";
            this.lblDcntRdiaCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblDcntRdiaCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblSpclDcntAmt
            // 
            appearance82.BackColor = System.Drawing.Color.Transparent;
            appearance82.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance82.FontData.Name = "맑은 고딕";
            appearance82.FontData.SizeInPoints = 9F;
            appearance82.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance82.TextHAlignAsString = "Right";
            appearance82.TextVAlignAsString = "Middle";
            this.lblSpclDcntAmt.Appearance = appearance82;
            this.lblSpclDcntAmt.Location = new System.Drawing.Point(248, 107);
            this.lblSpclDcntAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblSpclDcntAmt.Name = "lblSpclDcntAmt";
            this.lblSpclDcntAmt.Size = new System.Drawing.Size(54, 23);
            this.lblSpclDcntAmt.TabIndex = 0;
            this.lblSpclDcntAmt.Text = "할인금액";
            this.lblSpclDcntAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblSpclDcntAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtFrtmCardRcptAmt
            // 
            appearance83.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance83.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance83.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance83.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance83.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance83.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance83.TextHAlignAsString = "Right";
            this.txtFrtmCardRcptAmt.Appearance = appearance83;
            this.txtFrtmCardRcptAmt.AutoSize = false;
            this.txtFrtmCardRcptAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtFrtmCardRcptAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtFrtmCardRcptAmt.Location = new System.Drawing.Point(386, 282);
            this.txtFrtmCardRcptAmt.Name = "txtFrtmCardRcptAmt";
            appearance84.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance84.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance84.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance84.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance84.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance84.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtFrtmCardRcptAmt.NullTextAppearance = appearance84;
            this.txtFrtmCardRcptAmt.ReadOnly = true;
            this.txtFrtmCardRcptAmt.Size = new System.Drawing.Size(109, 23);
            this.txtFrtmCardRcptAmt.TabIndex = 38;
            this.txtFrtmCardRcptAmt.TabStop = false;
            this.txtFrtmCardRcptAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtFrtmCardRcptAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblSpclDcntDvcd
            // 
            appearance85.BackColor = System.Drawing.Color.Transparent;
            appearance85.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance85.FontData.Name = "맑은 고딕";
            appearance85.FontData.SizeInPoints = 9F;
            appearance85.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance85.TextHAlignAsString = "Right";
            appearance85.TextVAlignAsString = "Middle";
            this.lblSpclDcntDvcd.Appearance = appearance85;
            this.lblSpclDcntDvcd.Location = new System.Drawing.Point(248, 182);
            this.lblSpclDcntDvcd.Margin = new System.Windows.Forms.Padding(0);
            this.lblSpclDcntDvcd.Name = "lblSpclDcntDvcd";
            this.lblSpclDcntDvcd.Size = new System.Drawing.Size(54, 23);
            this.lblSpclDcntDvcd.TabIndex = 0;
            this.lblSpclDcntDvcd.Text = "추가할인";
            this.lblSpclDcntDvcd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblSpclDcntDvcd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblDcntRdiaEmno
            // 
            appearance86.BackColor = System.Drawing.Color.Transparent;
            appearance86.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance86.FontData.Name = "맑은 고딕";
            appearance86.FontData.SizeInPoints = 9F;
            appearance86.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance86.TextHAlignAsString = "Right";
            appearance86.TextVAlignAsString = "Middle";
            this.lblDcntRdiaEmno.Appearance = appearance86;
            this.lblDcntRdiaEmno.Location = new System.Drawing.Point(248, 132);
            this.lblDcntRdiaEmno.Margin = new System.Windows.Forms.Padding(0);
            this.lblDcntRdiaEmno.Name = "lblDcntRdiaEmno";
            this.lblDcntRdiaEmno.Size = new System.Drawing.Size(54, 23);
            this.lblDcntRdiaEmno.TabIndex = 0;
            this.lblDcntRdiaEmno.Text = "직원번호";
            this.lblDcntRdiaEmno.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblDcntRdiaEmno.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtEmrgSuptAmt
            // 
            appearance87.BackColor = System.Drawing.Color.White;
            appearance87.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance87.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance87.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance87.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance87.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance87.TextHAlignAsString = "Right";
            this.txtEmrgSuptAmt.Appearance = appearance87;
            this.txtEmrgSuptAmt.AutoSize = false;
            this.txtEmrgSuptAmt.BackColor = System.Drawing.Color.White;
            this.txtEmrgSuptAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtEmrgSuptAmt.EnterKeyToTab = true;
            this.txtEmrgSuptAmt.Location = new System.Drawing.Point(95, 407);
            this.txtEmrgSuptAmt.Name = "txtEmrgSuptAmt";
            appearance88.BackColor = System.Drawing.Color.White;
            appearance88.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance88.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance88.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance88.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance88.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtEmrgSuptAmt.NullTextAppearance = appearance88;
            this.txtEmrgSuptAmt.Size = new System.Drawing.Size(136, 23);
            this.txtEmrgSuptAmt.TabIndex = 18;
            this.txtEmrgSuptAmt.TabStop = false;
            this.txtEmrgSuptAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtEmrgSuptAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblRcvdAmt
            // 
            appearance89.BackColor = System.Drawing.Color.Transparent;
            appearance89.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance89.FontData.Name = "맑은 고딕";
            appearance89.FontData.SizeInPoints = 9F;
            appearance89.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance89.TextHAlignAsString = "Right";
            appearance89.TextVAlignAsString = "Middle";
            this.lblRcvdAmt.Appearance = appearance89;
            this.lblRcvdAmt.Location = new System.Drawing.Point(248, 207);
            this.lblRcvdAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblRcvdAmt.Name = "lblRcvdAmt";
            this.lblRcvdAmt.Size = new System.Drawing.Size(54, 23);
            this.lblRcvdAmt.TabIndex = 0;
            this.lblRcvdAmt.Text = "현금 [F6]";
            this.lblRcvdAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblRcvdAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtUnclAmt
            // 
            appearance90.BackColor = System.Drawing.Color.White;
            appearance90.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance90.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance90.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance90.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance90.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance90.TextHAlignAsString = "Right";
            this.txtUnclAmt.Appearance = appearance90;
            this.txtUnclAmt.AutoSize = false;
            this.txtUnclAmt.BackColor = System.Drawing.Color.White;
            this.txtUnclAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtUnclAmt.EnterKeyToTab = true;
            this.txtUnclAmt.Location = new System.Drawing.Point(305, 382);
            this.txtUnclAmt.MaxLength = 12;
            this.txtUnclAmt.Name = "txtUnclAmt";
            appearance91.BackColor = System.Drawing.Color.White;
            appearance91.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance91.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance91.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance91.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance91.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtUnclAmt.NullTextAppearance = appearance91;
            this.txtUnclAmt.Size = new System.Drawing.Size(190, 23);
            this.txtUnclAmt.TabIndex = 44;
            this.txtUnclAmt.TabStop = false;
            this.txtUnclAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtUnclAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblFrtmCashRcptAmt
            // 
            appearance92.BackColor = System.Drawing.Color.Transparent;
            appearance92.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance92.FontData.Name = "맑은 고딕";
            appearance92.FontData.SizeInPoints = 9F;
            appearance92.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance92.TextHAlignAsString = "Right";
            appearance92.TextVAlignAsString = "Middle";
            this.lblFrtmCashRcptAmt.Appearance = appearance92;
            this.lblFrtmCashRcptAmt.Location = new System.Drawing.Point(248, 232);
            this.lblFrtmCashRcptAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblFrtmCashRcptAmt.Name = "lblFrtmCashRcptAmt";
            this.lblFrtmCashRcptAmt.Size = new System.Drawing.Size(54, 23);
            this.lblFrtmCashRcptAmt.TabIndex = 0;
            this.lblFrtmCashRcptAmt.Text = "기현금액";
            this.lblFrtmCashRcptAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblFrtmCashRcptAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtVcntClamAmt
            // 
            appearance93.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance93.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance93.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance93.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance93.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance93.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance93.TextHAlignAsString = "Right";
            this.txtVcntClamAmt.Appearance = appearance93;
            this.txtVcntClamAmt.AutoSize = false;
            this.txtVcntClamAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtVcntClamAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtVcntClamAmt.Location = new System.Drawing.Point(95, 382);
            this.txtVcntClamAmt.Name = "txtVcntClamAmt";
            appearance94.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance94.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance94.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance94.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance94.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance94.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtVcntClamAmt.NullTextAppearance = appearance94;
            this.txtVcntClamAmt.ReadOnly = true;
            this.txtVcntClamAmt.Size = new System.Drawing.Size(136, 23);
            this.txtVcntClamAmt.TabIndex = 17;
            this.txtVcntClamAmt.TabStop = false;
            this.txtVcntClamAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtVcntClamAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblCardRcptAmt
            // 
            appearance95.BackColor = System.Drawing.Color.Transparent;
            appearance95.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance95.FontData.Name = "맑은 고딕";
            appearance95.FontData.SizeInPoints = 9F;
            appearance95.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance95.TextHAlignAsString = "Right";
            appearance95.TextVAlignAsString = "Middle";
            this.lblCardRcptAmt.Appearance = appearance95;
            this.lblCardRcptAmt.Location = new System.Drawing.Point(248, 257);
            this.lblCardRcptAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblCardRcptAmt.Name = "lblCardRcptAmt";
            this.lblCardRcptAmt.Size = new System.Drawing.Size(54, 23);
            this.lblCardRcptAmt.TabIndex = 0;
            this.lblCardRcptAmt.Text = "카드 [F9]";
            this.lblCardRcptAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblCardRcptAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtTbrcCtctSuptAmt
            // 
            appearance96.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance96.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance96.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance96.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance96.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance96.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance96.TextHAlignAsString = "Right";
            this.txtTbrcCtctSuptAmt.Appearance = appearance96;
            this.txtTbrcCtctSuptAmt.AutoSize = false;
            this.txtTbrcCtctSuptAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtTbrcCtctSuptAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtTbrcCtctSuptAmt.Location = new System.Drawing.Point(95, 357);
            this.txtTbrcCtctSuptAmt.Name = "txtTbrcCtctSuptAmt";
            appearance97.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance97.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance97.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance97.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance97.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance97.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtTbrcCtctSuptAmt.NullTextAppearance = appearance97;
            this.txtTbrcCtctSuptAmt.ReadOnly = true;
            this.txtTbrcCtctSuptAmt.Size = new System.Drawing.Size(136, 23);
            this.txtTbrcCtctSuptAmt.TabIndex = 16;
            this.txtTbrcCtctSuptAmt.TabStop = false;
            this.txtTbrcCtctSuptAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtTbrcCtctSuptAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblFrtmCardRcptAmt
            // 
            appearance98.BackColor = System.Drawing.Color.Transparent;
            appearance98.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance98.FontData.Name = "맑은 고딕";
            appearance98.FontData.SizeInPoints = 9F;
            appearance98.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance98.TextHAlignAsString = "Right";
            appearance98.TextVAlignAsString = "Middle";
            this.lblFrtmCardRcptAmt.Appearance = appearance98;
            this.lblFrtmCardRcptAmt.Location = new System.Drawing.Point(248, 282);
            this.lblFrtmCardRcptAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblFrtmCardRcptAmt.Name = "lblFrtmCardRcptAmt";
            this.lblFrtmCardRcptAmt.Size = new System.Drawing.Size(54, 23);
            this.lblFrtmCardRcptAmt.TabIndex = 0;
            this.lblFrtmCardRcptAmt.Text = "기카드액";
            this.lblFrtmCardRcptAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblFrtmCardRcptAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtHllfMncsClamAmt
            // 
            appearance99.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance99.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance99.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance99.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance99.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance99.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance99.TextHAlignAsString = "Right";
            this.txtHllfMncsClamAmt.Appearance = appearance99;
            this.txtHllfMncsClamAmt.AutoSize = false;
            this.txtHllfMncsClamAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtHllfMncsClamAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtHllfMncsClamAmt.Location = new System.Drawing.Point(95, 332);
            this.txtHllfMncsClamAmt.Name = "txtHllfMncsClamAmt";
            appearance100.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance100.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance100.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance100.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance100.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance100.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtHllfMncsClamAmt.NullTextAppearance = appearance100;
            this.txtHllfMncsClamAmt.ReadOnly = true;
            this.txtHllfMncsClamAmt.Size = new System.Drawing.Size(136, 23);
            this.txtHllfMncsClamAmt.TabIndex = 15;
            this.txtHllfMncsClamAmt.TabStop = false;
            this.txtHllfMncsClamAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtHllfMncsClamAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblBnacRcptAmt
            // 
            appearance101.BackColor = System.Drawing.Color.Transparent;
            appearance101.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance101.FontData.Name = "맑은 고딕";
            appearance101.FontData.SizeInPoints = 9F;
            appearance101.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance101.TextHAlignAsString = "Right";
            appearance101.TextVAlignAsString = "Middle";
            this.lblBnacRcptAmt.Appearance = appearance101;
            this.lblBnacRcptAmt.Location = new System.Drawing.Point(248, 307);
            this.lblBnacRcptAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblBnacRcptAmt.Name = "lblBnacRcptAmt";
            this.lblBnacRcptAmt.Size = new System.Drawing.Size(54, 23);
            this.lblBnacRcptAmt.TabIndex = 0;
            this.lblBnacRcptAmt.Text = "통장 [F7]";
            this.lblBnacRcptAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblBnacRcptAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtSuptAmt
            // 
            appearance102.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance102.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance102.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance102.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance102.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance102.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance102.TextHAlignAsString = "Right";
            this.txtSuptAmt.Appearance = appearance102;
            this.txtSuptAmt.AutoSize = false;
            this.txtSuptAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtSuptAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtSuptAmt.Location = new System.Drawing.Point(95, 307);
            this.txtSuptAmt.Name = "txtSuptAmt";
            appearance103.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance103.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance103.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance103.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance103.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance103.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtSuptAmt.NullTextAppearance = appearance103;
            this.txtSuptAmt.ReadOnly = true;
            this.txtSuptAmt.Size = new System.Drawing.Size(136, 23);
            this.txtSuptAmt.TabIndex = 14;
            this.txtSuptAmt.TabStop = false;
            this.txtSuptAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtSuptAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblUnclCd
            // 
            appearance104.BackColor = System.Drawing.Color.Transparent;
            appearance104.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance104.FontData.Name = "맑은 고딕";
            appearance104.FontData.SizeInPoints = 9F;
            appearance104.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance104.TextHAlignAsString = "Right";
            appearance104.TextVAlignAsString = "Middle";
            this.lblUnclCd.Appearance = appearance104;
            this.lblUnclCd.Location = new System.Drawing.Point(248, 407);
            this.lblUnclCd.Margin = new System.Windows.Forms.Padding(0);
            this.lblUnclCd.Name = "lblUnclCd";
            this.lblUnclCd.Size = new System.Drawing.Size(54, 23);
            this.lblUnclCd.TabIndex = 0;
            this.lblUnclCd.Text = "미수코드";
            this.lblUnclCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblUnclCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtHmptPayTamt
            // 
            appearance105.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance105.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance105.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance105.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance105.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance105.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance105.TextHAlignAsString = "Right";
            this.txtHmptPayTamt.Appearance = appearance105;
            this.txtHmptPayTamt.AutoSize = false;
            this.txtHmptPayTamt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtHmptPayTamt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtHmptPayTamt.Location = new System.Drawing.Point(356, 467);
            this.txtHmptPayTamt.Name = "txtHmptPayTamt";
            appearance106.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance106.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance106.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance106.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance106.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance106.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtHmptPayTamt.NullTextAppearance = appearance106;
            this.txtHmptPayTamt.ReadOnly = true;
            this.txtHmptPayTamt.Size = new System.Drawing.Size(136, 23);
            this.txtHmptPayTamt.TabIndex = 133333;
            this.txtHmptPayTamt.TabStop = false;
            this.txtHmptPayTamt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtHmptPayTamt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtPayClamAmt
            // 
            appearance107.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance107.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance107.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance107.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance107.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance107.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance107.TextHAlignAsString = "Right";
            this.txtPayClamAmt.Appearance = appearance107;
            this.txtPayClamAmt.AutoSize = false;
            this.txtPayClamAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtPayClamAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtPayClamAmt.Location = new System.Drawing.Point(95, 232);
            this.txtPayClamAmt.Name = "txtPayClamAmt";
            appearance108.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance108.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance108.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance108.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance108.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance108.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtPayClamAmt.NullTextAppearance = appearance108;
            this.txtPayClamAmt.ReadOnly = true;
            this.txtPayClamAmt.Size = new System.Drawing.Size(136, 23);
            this.txtPayClamAmt.TabIndex = 11;
            this.txtPayClamAmt.TabStop = false;
            this.txtPayClamAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtPayClamAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtDsblFundAmt
            // 
            appearance109.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance109.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance109.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance109.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance109.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance109.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance109.TextHAlignAsString = "Right";
            this.txtDsblFundAmt.Appearance = appearance109;
            this.txtDsblFundAmt.AutoSize = false;
            this.txtDsblFundAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtDsblFundAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtDsblFundAmt.Location = new System.Drawing.Point(95, 257);
            this.txtDsblFundAmt.Name = "txtDsblFundAmt";
            appearance110.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance110.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance110.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance110.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance110.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance110.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtDsblFundAmt.NullTextAppearance = appearance110;
            this.txtDsblFundAmt.ReadOnly = true;
            this.txtDsblFundAmt.Size = new System.Drawing.Size(136, 23);
            this.txtDsblFundAmt.TabIndex = 12;
            this.txtDsblFundAmt.TabStop = false;
            this.txtDsblFundAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtDsblFundAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblUnclAmt
            // 
            appearance111.BackColor = System.Drawing.Color.Transparent;
            appearance111.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance111.FontData.Name = "맑은 고딕";
            appearance111.FontData.SizeInPoints = 9F;
            appearance111.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance111.TextHAlignAsString = "Right";
            appearance111.TextVAlignAsString = "Middle";
            this.lblUnclAmt.Appearance = appearance111;
            this.lblUnclAmt.Location = new System.Drawing.Point(248, 382);
            this.lblUnclAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblUnclAmt.Name = "lblUnclAmt";
            this.lblUnclAmt.Size = new System.Drawing.Size(54, 23);
            this.lblUnclAmt.TabIndex = 0;
            this.lblUnclAmt.Text = "미수금액";
            this.lblUnclAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblUnclAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtPayUschAmt
            // 
            appearance112.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance112.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance112.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance112.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance112.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance112.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance112.TextHAlignAsString = "Right";
            this.txtPayUschAmt.Appearance = appearance112;
            this.txtPayUschAmt.AutoSize = false;
            this.txtPayUschAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtPayUschAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtPayUschAmt.Location = new System.Drawing.Point(95, 207);
            this.txtPayUschAmt.Name = "txtPayUschAmt";
            appearance113.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance113.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance113.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance113.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance113.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance113.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtPayUschAmt.NullTextAppearance = appearance113;
            this.txtPayUschAmt.ReadOnly = true;
            this.txtPayUschAmt.Size = new System.Drawing.Size(136, 23);
            this.txtPayUschAmt.TabIndex = 10;
            this.txtPayUschAmt.TabStop = false;
            this.txtPayUschAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtPayUschAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblSmcrAmt
            // 
            appearance114.BackColor = System.Drawing.Color.Transparent;
            appearance114.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance114.FontData.Name = "맑은 고딕";
            appearance114.FontData.SizeInPoints = 9F;
            appearance114.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance114.TextHAlignAsString = "Right";
            appearance114.TextVAlignAsString = "Middle";
            this.lblSmcrAmt.Appearance = appearance114;
            this.lblSmcrAmt.Location = new System.Drawing.Point(26, 182);
            this.lblSmcrAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblSmcrAmt.Name = "lblSmcrAmt";
            this.lblSmcrAmt.Size = new System.Drawing.Size(66, 23);
            this.lblSmcrAmt.TabIndex = 0;
            this.lblSmcrAmt.Text = "선택진료료";
            this.lblSmcrAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblSmcrAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtSmcrAmt
            // 
            appearance115.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance115.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance115.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance115.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance115.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance115.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance115.TextHAlignAsString = "Right";
            this.txtSmcrAmt.Appearance = appearance115;
            this.txtSmcrAmt.AutoSize = false;
            this.txtSmcrAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtSmcrAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtSmcrAmt.Location = new System.Drawing.Point(95, 182);
            this.txtSmcrAmt.Name = "txtSmcrAmt";
            appearance116.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance116.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance116.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance116.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance116.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance116.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtSmcrAmt.NullTextAppearance = appearance116;
            this.txtSmcrAmt.ReadOnly = true;
            this.txtSmcrAmt.Size = new System.Drawing.Size(136, 23);
            this.txtSmcrAmt.TabIndex = 9;
            this.txtSmcrAmt.TabStop = false;
            this.txtSmcrAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtSmcrAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblPayUschAmt
            // 
            appearance117.BackColor = System.Drawing.Color.Transparent;
            appearance117.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance117.FontData.Name = "맑은 고딕";
            appearance117.FontData.SizeInPoints = 9F;
            appearance117.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance117.TextHAlignAsString = "Right";
            appearance117.TextVAlignAsString = "Middle";
            this.lblPayUschAmt.Appearance = appearance117;
            this.lblPayUschAmt.Location = new System.Drawing.Point(26, 207);
            this.lblPayUschAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblPayUschAmt.Name = "lblPayUschAmt";
            this.lblPayUschAmt.Size = new System.Drawing.Size(66, 23);
            this.lblPayUschAmt.TabIndex = 0;
            this.lblPayUschAmt.Text = "본인부담금";
            this.lblPayUschAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblPayUschAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtAdedValuTaxTamt
            // 
            appearance118.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance118.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance118.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance118.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance118.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance118.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance118.TextHAlignAsString = "Right";
            this.txtAdedValuTaxTamt.Appearance = appearance118;
            this.txtAdedValuTaxTamt.AutoSize = false;
            this.txtAdedValuTaxTamt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtAdedValuTaxTamt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtAdedValuTaxTamt.Location = new System.Drawing.Point(95, 157);
            this.txtAdedValuTaxTamt.Name = "txtAdedValuTaxTamt";
            appearance119.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance119.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance119.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance119.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance119.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance119.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtAdedValuTaxTamt.NullTextAppearance = appearance119;
            this.txtAdedValuTaxTamt.ReadOnly = true;
            this.txtAdedValuTaxTamt.Size = new System.Drawing.Size(136, 23);
            this.txtAdedValuTaxTamt.TabIndex = 8;
            this.txtAdedValuTaxTamt.TabStop = false;
            this.txtAdedValuTaxTamt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtAdedValuTaxTamt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lxTitleLabel3
            // 
            appearance120.BackColor = System.Drawing.Color.Transparent;
            appearance120.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance120.FontData.Name = "맑은 고딕";
            appearance120.FontData.SizeInPoints = 9F;
            appearance120.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance120.TextHAlignAsString = "Right";
            appearance120.TextVAlignAsString = "Middle";
            this.lxTitleLabel3.Appearance = appearance120;
            this.lxTitleLabel3.Location = new System.Drawing.Point(261, 467);
            this.lxTitleLabel3.Margin = new System.Windows.Forms.Padding(0);
            this.lxTitleLabel3.Name = "lxTitleLabel3";
            this.lxTitleLabel3.Size = new System.Drawing.Size(92, 23);
            this.lxTitleLabel3.TabIndex = 0;
            this.lxTitleLabel3.Text = "수진자급여총액";
            this.lxTitleLabel3.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lxTitleLabel3.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lxTitleLabel2
            // 
            appearance121.BackColor = System.Drawing.Color.Transparent;
            appearance121.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance121.FontData.Name = "맑은 고딕";
            appearance121.FontData.SizeInPoints = 9F;
            appearance121.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance121.TextHAlignAsString = "Right";
            appearance121.TextVAlignAsString = "Middle";
            this.lxTitleLabel2.Appearance = appearance121;
            this.lxTitleLabel2.Location = new System.Drawing.Point(26, 257);
            this.lxTitleLabel2.Margin = new System.Windows.Forms.Padding(0);
            this.lxTitleLabel2.Name = "lxTitleLabel2";
            this.lxTitleLabel2.Size = new System.Drawing.Size(66, 23);
            this.lxTitleLabel2.TabIndex = 0;
            this.lxTitleLabel2.Text = "장애인기금";
            this.lxTitleLabel2.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lxTitleLabel2.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblAsctSharAmt
            // 
            appearance122.BackColor = System.Drawing.Color.Transparent;
            appearance122.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance122.FontData.Name = "맑은 고딕";
            appearance122.FontData.SizeInPoints = 9F;
            appearance122.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance122.TextHAlignAsString = "Right";
            appearance122.TextVAlignAsString = "Middle";
            this.lblAsctSharAmt.Appearance = appearance122;
            this.lblAsctSharAmt.Location = new System.Drawing.Point(26, 232);
            this.lblAsctSharAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblAsctSharAmt.Name = "lblAsctSharAmt";
            this.lblAsctSharAmt.Size = new System.Drawing.Size(66, 23);
            this.lblAsctSharAmt.TabIndex = 0;
            this.lblAsctSharAmt.Text = "조합부담액";
            this.lblAsctSharAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblAsctSharAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtNopyTamt
            // 
            appearance123.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance123.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance123.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance123.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance123.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance123.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance123.TextHAlignAsString = "Right";
            this.txtNopyTamt.Appearance = appearance123;
            this.txtNopyTamt.AutoSize = false;
            this.txtNopyTamt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtNopyTamt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtNopyTamt.Location = new System.Drawing.Point(95, 132);
            this.txtNopyTamt.Name = "txtNopyTamt";
            appearance124.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance124.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance124.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance124.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance124.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance124.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtNopyTamt.NullTextAppearance = appearance124;
            this.txtNopyTamt.ReadOnly = true;
            this.txtNopyTamt.Size = new System.Drawing.Size(136, 23);
            this.txtNopyTamt.TabIndex = 7;
            this.txtNopyTamt.TabStop = false;
            this.txtNopyTamt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtNopyTamt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblSuptAmt
            // 
            appearance125.BackColor = System.Drawing.Color.Transparent;
            appearance125.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance125.FontData.Name = "맑은 고딕";
            appearance125.FontData.SizeInPoints = 9F;
            appearance125.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance125.TextHAlignAsString = "Right";
            appearance125.TextVAlignAsString = "Middle";
            this.lblSuptAmt.Appearance = appearance125;
            this.lblSuptAmt.Location = new System.Drawing.Point(26, 307);
            this.lblSuptAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblSuptAmt.Name = "lblSuptAmt";
            this.lblSuptAmt.Size = new System.Drawing.Size(66, 23);
            this.lblSuptAmt.TabIndex = 0;
            this.lblSuptAmt.Text = "공단지원금";
            this.lblSuptAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblSuptAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtClamNopyTamt
            // 
            appearance126.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance126.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance126.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance126.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance126.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance126.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance126.TextHAlignAsString = "Right";
            this.txtClamNopyTamt.Appearance = appearance126;
            this.txtClamNopyTamt.AutoSize = false;
            this.txtClamNopyTamt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtClamNopyTamt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtClamNopyTamt.Location = new System.Drawing.Point(95, 107);
            this.txtClamNopyTamt.Name = "txtClamNopyTamt";
            appearance127.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance127.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance127.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance127.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance127.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance127.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtClamNopyTamt.NullTextAppearance = appearance127;
            this.txtClamNopyTamt.ReadOnly = true;
            this.txtClamNopyTamt.Size = new System.Drawing.Size(136, 23);
            this.txtClamNopyTamt.TabIndex = 6;
            this.txtClamNopyTamt.TabStop = false;
            this.txtClamNopyTamt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtClamNopyTamt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblHllfMncsClamAmt
            // 
            appearance128.BackColor = System.Drawing.Color.Transparent;
            appearance128.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance128.FontData.Name = "맑은 고딕";
            appearance128.FontData.SizeInPoints = 9F;
            appearance128.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance128.TextHAlignAsString = "Right";
            appearance128.TextVAlignAsString = "Middle";
            this.lblHllfMncsClamAmt.Appearance = appearance128;
            this.lblHllfMncsClamAmt.Location = new System.Drawing.Point(26, 332);
            this.lblHllfMncsClamAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblHllfMncsClamAmt.Name = "lblHllfMncsClamAmt";
            this.lblHllfMncsClamAmt.Size = new System.Drawing.Size(66, 23);
            this.lblHllfMncsClamAmt.TabIndex = 0;
            this.lblHllfMncsClamAmt.Text = "건강청구액";
            this.lblHllfMncsClamAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblHllfMncsClamAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtScngPayUschAmt
            // 
            appearance129.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance129.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance129.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance129.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance129.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance129.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance129.TextHAlignAsString = "Right";
            this.txtScngPayUschAmt.Appearance = appearance129;
            this.txtScngPayUschAmt.AutoSize = false;
            this.txtScngPayUschAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtScngPayUschAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtScngPayUschAmt.Location = new System.Drawing.Point(95, 82);
            this.txtScngPayUschAmt.Name = "txtScngPayUschAmt";
            appearance130.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance130.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance130.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance130.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance130.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance130.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtScngPayUschAmt.NullTextAppearance = appearance130;
            this.txtScngPayUschAmt.ReadOnly = true;
            this.txtScngPayUschAmt.Size = new System.Drawing.Size(67, 23);
            this.txtScngPayUschAmt.TabIndex = 4;
            this.txtScngPayUschAmt.TabStop = false;
            this.txtScngPayUschAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtScngPayUschAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtInsn100Tamt
            // 
            appearance131.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance131.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance131.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance131.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance131.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance131.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance131.TextHAlignAsString = "Right";
            this.txtInsn100Tamt.Appearance = appearance131;
            this.txtInsn100Tamt.AutoSize = false;
            this.txtInsn100Tamt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtInsn100Tamt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtInsn100Tamt.Location = new System.Drawing.Point(95, 57);
            this.txtInsn100Tamt.Name = "txtInsn100Tamt";
            appearance132.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance132.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance132.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance132.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance132.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance132.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtInsn100Tamt.NullTextAppearance = appearance132;
            this.txtInsn100Tamt.ReadOnly = true;
            this.txtInsn100Tamt.Size = new System.Drawing.Size(136, 23);
            this.txtInsn100Tamt.TabIndex = 3;
            this.txtInsn100Tamt.TabStop = false;
            this.txtInsn100Tamt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtInsn100Tamt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtPayTamt
            // 
            appearance133.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance133.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance133.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance133.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance133.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance133.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance133.TextHAlignAsString = "Right";
            this.txtPayTamt.Appearance = appearance133;
            this.txtPayTamt.AutoSize = false;
            this.txtPayTamt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtPayTamt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtPayTamt.Location = new System.Drawing.Point(95, 32);
            this.txtPayTamt.Name = "txtPayTamt";
            appearance134.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance134.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance134.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance134.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance134.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance134.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtPayTamt.NullTextAppearance = appearance134;
            this.txtPayTamt.ReadOnly = true;
            this.txtPayTamt.Size = new System.Drawing.Size(136, 23);
            this.txtPayTamt.TabIndex = 2;
            this.txtPayTamt.TabStop = false;
            this.txtPayTamt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtPayTamt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblCttrUnclAplyAmt
            // 
            appearance135.BackColor = System.Drawing.Color.Transparent;
            appearance135.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance135.FontData.Name = "맑은 고딕";
            appearance135.FontData.SizeInPoints = 9F;
            appearance135.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance135.TextHAlignAsString = "Right";
            appearance135.TextVAlignAsString = "Middle";
            this.lblCttrUnclAplyAmt.Appearance = appearance135;
            this.lblCttrUnclAplyAmt.Location = new System.Drawing.Point(0, 432);
            this.lblCttrUnclAplyAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblCttrUnclAplyAmt.Name = "lblCttrUnclAplyAmt";
            this.lblCttrUnclAplyAmt.Size = new System.Drawing.Size(92, 23);
            this.lblCttrUnclAplyAmt.TabIndex = 0;
            this.lblCttrUnclAplyAmt.Text = "협력지원금액";
            this.lblCttrUnclAplyAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblCttrUnclAplyAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblEmrgSuptAmt
            // 
            appearance136.BackColor = System.Drawing.Color.Transparent;
            appearance136.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance136.FontData.Name = "맑은 고딕";
            appearance136.FontData.SizeInPoints = 9F;
            appearance136.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance136.TextHAlignAsString = "Right";
            appearance136.TextVAlignAsString = "Middle";
            this.lblEmrgSuptAmt.Appearance = appearance136;
            this.lblEmrgSuptAmt.Location = new System.Drawing.Point(26, 407);
            this.lblEmrgSuptAmt.Margin = new System.Windows.Forms.Padding(0);
            this.lblEmrgSuptAmt.Name = "lblEmrgSuptAmt";
            this.lblEmrgSuptAmt.Size = new System.Drawing.Size(66, 23);
            this.lblEmrgSuptAmt.TabIndex = 0;
            this.lblEmrgSuptAmt.Text = "의료비지원";
            this.lblEmrgSuptAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblEmrgSuptAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtTotlMdcrAmt
            // 
            appearance137.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance137.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance137.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance137.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance137.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance137.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance137.TextHAlignAsString = "Right";
            this.txtTotlMdcrAmt.Appearance = appearance137;
            this.txtTotlMdcrAmt.AutoSize = false;
            this.txtTotlMdcrAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtTotlMdcrAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtTotlMdcrAmt.Location = new System.Drawing.Point(95, 7);
            this.txtTotlMdcrAmt.Name = "txtTotlMdcrAmt";
            appearance138.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance138.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance138.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance138.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance138.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance138.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtTotlMdcrAmt.NullTextAppearance = appearance138;
            this.txtTotlMdcrAmt.ReadOnly = true;
            this.txtTotlMdcrAmt.Size = new System.Drawing.Size(136, 23);
            this.txtTotlMdcrAmt.TabIndex = 1;
            this.txtTotlMdcrAmt.TabStop = false;
            this.txtTotlMdcrAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtTotlMdcrAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboBldnYn
            // 
            appearance139.BackColor = System.Drawing.Color.White;
            appearance139.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance139.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance139.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance139.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance139.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboBldnYn.Appearance = appearance139;
            this.cboBldnYn.AutoSize = false;
            this.cboBldnYn.BackColor = System.Drawing.Color.White;
            this.cboBldnYn.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance140.BackColor = System.Drawing.Color.Transparent;
            appearance140.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance140.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance140.BorderColor = System.Drawing.Color.Transparent;
            appearance140.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance140.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboBldnYn.ButtonAppearance = appearance140;
            this.cboBldnYn.DropDownButtonDisplayStyle = Infragistics.Win.ButtonDisplayStyle.OnMouseEnter;
            this.cboBldnYn.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            valueListItem1.DataValue = "Y";
            valueListItem1.DisplayText = "YES";
            valueListItem2.DataValue = "N";
            valueListItem2.DisplayText = "NO";
            this.cboBldnYn.Items.AddRange(new Infragistics.Win.ValueListItem[] {
            valueListItem1,
            valueListItem2});
            this.cboBldnYn.Location = new System.Drawing.Point(305, 57);
            this.cboBldnYn.Name = "cboBldnYn";
            appearance141.BackColor = System.Drawing.Color.White;
            appearance141.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance141.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance141.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance141.ForeColor = System.Drawing.Color.DarkGray;
            appearance141.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboBldnYn.NullTextAppearance = appearance141;
            this.cboBldnYn.SelectedValue = "";
            this.cboBldnYn.Size = new System.Drawing.Size(48, 23);
            this.cboBldnYn.TabIndex = 22;
            this.cboBldnYn.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboBldnYn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboBldnYn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtDcntRdiaEmnm
            // 
            appearance142.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance142.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance142.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance142.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance142.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance142.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtDcntRdiaEmnm.Appearance = appearance142;
            this.txtDcntRdiaEmnm.AutoSize = false;
            this.txtDcntRdiaEmnm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtDcntRdiaEmnm.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance143.BackColor = System.Drawing.Color.Transparent;
            appearance143.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance143.BorderColor = System.Drawing.Color.Transparent;
            appearance143.BorderColor2 = System.Drawing.Color.Transparent;
            appearance143.Image = ((object)(resources.GetObject("appearance143.Image")));
            appearance143.ImageHAlign = Infragistics.Win.HAlign.Right;
            appearance143.ImageVAlign = Infragistics.Win.VAlign.Middle;
            editorButton6.Appearance = appearance143;
            editorButton6.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Button;
            editorButton6.Width = 18;
            this.txtDcntRdiaEmnm.ButtonsRight.Add(editorButton6);
            this.txtDcntRdiaEmnm.Enabled = false;
            this.txtDcntRdiaEmnm.ImeMode = System.Windows.Forms.ImeMode.Hangul;
            this.txtDcntRdiaEmnm.Location = new System.Drawing.Point(305, 132);
            this.txtDcntRdiaEmnm.Name = "txtDcntRdiaEmnm";
            appearance144.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance144.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance144.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance144.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance144.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance144.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtDcntRdiaEmnm.NullTextAppearance = appearance144;
            this.txtDcntRdiaEmnm.ReadOnly = true;
            this.txtDcntRdiaEmnm.Size = new System.Drawing.Size(190, 23);
            this.txtDcntRdiaEmnm.TabIndex = 27;
            this.txtDcntRdiaEmnm.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtDcntRdiaEmnm.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtDcntRdiaEmno
            // 
            appearance145.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance145.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance145.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance145.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance145.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance145.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtDcntRdiaEmno.Appearance = appearance145;
            this.txtDcntRdiaEmno.AutoSize = false;
            this.txtDcntRdiaEmno.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtDcntRdiaEmno.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance146.BackColor = System.Drawing.Color.Transparent;
            appearance146.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance146.BorderColor = System.Drawing.Color.Transparent;
            appearance146.BorderColor2 = System.Drawing.Color.Transparent;
            appearance146.Image = ((object)(resources.GetObject("appearance146.Image")));
            appearance146.ImageHAlign = Infragistics.Win.HAlign.Right;
            appearance146.ImageVAlign = Infragistics.Win.VAlign.Middle;
            editorButton7.Appearance = appearance146;
            editorButton7.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Button;
            editorButton7.Width = 18;
            this.txtDcntRdiaEmno.ButtonsRight.Add(editorButton7);
            this.txtDcntRdiaEmno.Location = new System.Drawing.Point(292, 463);
            this.txtDcntRdiaEmno.Name = "txtDcntRdiaEmno";
            appearance147.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance147.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance147.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance147.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance147.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance147.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtDcntRdiaEmno.NullTextAppearance = appearance147;
            this.txtDcntRdiaEmno.ReadOnly = true;
            this.txtDcntRdiaEmno.Size = new System.Drawing.Size(145, 23);
            this.txtDcntRdiaEmno.TabIndex = 4;
            this.txtDcntRdiaEmno.TabStop = false;
            this.txtDcntRdiaEmno.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtDcntRdiaEmno.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.txtDcntRdiaEmno.Visible = false;
            // 
            // cboDcntRdiaCd
            // 
            appearance148.BackColor = System.Drawing.Color.White;
            appearance148.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance148.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance148.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance148.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance148.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboDcntRdiaCd.Appearance = appearance148;
            this.cboDcntRdiaCd.AutoSize = false;
            this.cboDcntRdiaCd.BackColor = System.Drawing.Color.White;
            this.cboDcntRdiaCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance149.BackColor = System.Drawing.Color.Transparent;
            appearance149.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance149.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance149.BorderColor = System.Drawing.Color.Transparent;
            appearance149.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance149.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboDcntRdiaCd.ButtonAppearance = appearance149;
            this.cboDcntRdiaCd.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboDcntRdiaCd.Enabled = false;
            this.cboDcntRdiaCd.EnterKeyToTab = true;
            this.cboDcntRdiaCd.Location = new System.Drawing.Point(305, 82);
            this.cboDcntRdiaCd.Name = "cboDcntRdiaCd";
            appearance150.BackColor = System.Drawing.Color.White;
            appearance150.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance150.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance150.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance150.ForeColor = System.Drawing.Color.DarkGray;
            appearance150.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboDcntRdiaCd.NullTextAppearance = appearance150;
            this.cboDcntRdiaCd.SelectedValue = "";
            this.cboDcntRdiaCd.Size = new System.Drawing.Size(190, 23);
            this.cboDcntRdiaCd.TabIndex = 24;
            this.cboDcntRdiaCd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboDcntRdiaCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboDcntRdiaCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.cboDcntRdiaCd.ValueChangedMoveNextFocus = true;
            // 
            // txtRfndResn
            // 
            appearance151.BackColor = System.Drawing.Color.White;
            appearance151.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance151.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance151.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance151.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance151.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtRfndResn.Appearance = appearance151;
            this.txtRfndResn.AutoSize = false;
            this.txtRfndResn.BackColor = System.Drawing.Color.White;
            this.txtRfndResn.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtRfndResn.EnterKeyToTab = true;
            this.txtRfndResn.ImeMode = System.Windows.Forms.ImeMode.Hangul;
            this.txtRfndResn.Location = new System.Drawing.Point(248, 357);
            this.txtRfndResn.Name = "txtRfndResn";
            appearance152.BackColor = System.Drawing.Color.White;
            appearance152.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance152.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance152.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance152.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance152.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtRfndResn.NullTextAppearance = appearance152;
            this.txtRfndResn.Size = new System.Drawing.Size(247, 23);
            this.txtRfndResn.TabIndex = 43;
            this.txtRfndResn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtRfndResn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtUnclResn
            // 
            appearance153.BackColor = System.Drawing.Color.White;
            appearance153.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance153.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance153.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance153.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance153.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtUnclResn.Appearance = appearance153;
            this.txtUnclResn.AutoSize = false;
            this.txtUnclResn.BackColor = System.Drawing.Color.White;
            this.txtUnclResn.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtUnclResn.EnterKeyToTab = true;
            this.txtUnclResn.ImeMode = System.Windows.Forms.ImeMode.Hangul;
            this.txtUnclResn.Location = new System.Drawing.Point(248, 432);
            this.txtUnclResn.Name = "txtUnclResn";
            appearance154.BackColor = System.Drawing.Color.White;
            appearance154.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance154.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance154.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance154.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance154.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtUnclResn.NullTextAppearance = appearance154;
            this.txtUnclResn.Size = new System.Drawing.Size(247, 23);
            this.txtUnclResn.TabIndex = 46;
            this.txtUnclResn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtUnclResn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtDcntResn
            // 
            appearance155.BackColor = System.Drawing.Color.White;
            appearance155.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance155.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance155.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance155.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance155.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtDcntResn.Appearance = appearance155;
            this.txtDcntResn.AutoSize = false;
            this.txtDcntResn.BackColor = System.Drawing.Color.White;
            this.txtDcntResn.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtDcntResn.Enabled = false;
            this.txtDcntResn.EnterKeyToTab = true;
            this.txtDcntResn.ImeMode = System.Windows.Forms.ImeMode.Hangul;
            this.txtDcntResn.Location = new System.Drawing.Point(248, 157);
            this.txtDcntResn.Name = "txtDcntResn";
            appearance156.BackColor = System.Drawing.Color.White;
            appearance156.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance156.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance156.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance156.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance156.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtDcntResn.NullTextAppearance = appearance156;
            this.txtDcntResn.Size = new System.Drawing.Size(247, 23);
            this.txtDcntResn.TabIndex = 28;
            this.txtDcntResn.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtDcntResn.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtSpclDcntAmt
            // 
            appearance157.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance157.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance157.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance157.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance157.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance157.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance157.TextHAlignAsString = "Right";
            this.txtSpclDcntAmt.Appearance = appearance157;
            this.txtSpclDcntAmt.AutoSize = false;
            this.txtSpclDcntAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtSpclDcntAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtSpclDcntAmt.EnterKeyToTab = true;
            this.txtSpclDcntAmt.Location = new System.Drawing.Point(386, 182);
            this.txtSpclDcntAmt.Name = "txtSpclDcntAmt";
            appearance158.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance158.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance158.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance158.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance158.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance158.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtSpclDcntAmt.NullTextAppearance = appearance158;
            this.txtSpclDcntAmt.ReadOnly = true;
            this.txtSpclDcntAmt.Size = new System.Drawing.Size(109, 23);
            this.txtSpclDcntAmt.TabIndex = 30;
            this.txtSpclDcntAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtSpclDcntAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lxTitleLabel5
            // 
            appearance11.BackColor = System.Drawing.Color.Transparent;
            appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance11.FontData.Name = "맑은 고딕";
            appearance11.FontData.SizeInPoints = 9F;
            appearance11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance11.TextHAlignAsString = "Right";
            appearance11.TextVAlignAsString = "Middle";
            this.lxTitleLabel5.Appearance = appearance11;
            this.lxTitleLabel5.Location = new System.Drawing.Point(1, 282);
            this.lxTitleLabel5.Margin = new System.Windows.Forms.Padding(0);
            this.lxTitleLabel5.Name = "lxTitleLabel5";
            this.lxTitleLabel5.Size = new System.Drawing.Size(91, 23);
            this.lxTitleLabel5.TabIndex = 50;
            this.lxTitleLabel5.Text = "공무원공상청구";
            this.lxTitleLabel5.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lxTitleLabel5.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtGvrnClamAmt
            // 
            appearance12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance12.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance12.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance12.TextHAlignAsString = "Right";
            this.txtGvrnClamAmt.Appearance = appearance12;
            this.txtGvrnClamAmt.AutoSize = false;
            this.txtGvrnClamAmt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.txtGvrnClamAmt.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtGvrnClamAmt.Location = new System.Drawing.Point(95, 282);
            this.txtGvrnClamAmt.Name = "txtGvrnClamAmt";
            appearance13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance13.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance13.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtGvrnClamAmt.NullTextAppearance = appearance13;
            this.txtGvrnClamAmt.ReadOnly = true;
            this.txtGvrnClamAmt.Size = new System.Drawing.Size(136, 23);
            this.txtGvrnClamAmt.TabIndex = 13;
            this.txtGvrnClamAmt.TabStop = false;
            this.txtGvrnClamAmt.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtGvrnClamAmt.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // ucObillInf1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Name = "ucObillInf1";
            this.Size = new System.Drawing.Size(508, 523);
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).EndInit();
            this.pnlBase.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lxTitlePanel1)).EndInit();
            this.lxTitlePanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnTabletReceipt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnBillNoApply)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnPermitCancel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCashRcpt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel1)).EndInit();
            this.lxPanel1.ResumeLayout(false);
            this.lxPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtFocus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCttrUnclAplyAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboUnclCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrtmBnacAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBnacRcptAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrtmCashRcptAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrtmBnacAmt_C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrtmCardRcptAmt_C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrtmCashRcptAmt_C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBnacRcptAmt_ing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitleLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCardRcptAmt_ing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCashRcptAmt_ing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCardRcptAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCashRcptAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTextBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboSpclDcntDvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCashPrmtYn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTbrcCtctSuptAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblVcntClamAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTotlMdcrAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBlodRdiaAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPayTamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalPtSharAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPtSharAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrtmRcptTotlAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblInsn100Tamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDcntRdiaAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblScngPayTamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrtmDcntRdiaAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblClamNopyTamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtScngPayClamAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblNopyTamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblAdedValuTaxTamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LxTitleLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblFrtmRcptTotlAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBlodRdiaAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblDcntRdiaCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSpclDcntAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFrtmCardRcptAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSpclDcntDvcd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblDcntRdiaEmno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEmrgSuptAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblRcvdAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUnclAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblFrtmCashRcptAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVcntClamAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCardRcptAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTbrcCtctSuptAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblFrtmCardRcptAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHllfMncsClamAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblBnacRcptAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuptAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblUnclCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHmptPayTamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayClamAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDsblFundAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblUnclAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayUschAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSmcrAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSmcrAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPayUschAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAdedValuTaxTamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitleLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitleLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblAsctSharAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNopyTamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSuptAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtClamNopyTamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblHllfMncsClamAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtScngPayUschAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInsn100Tamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTamt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCttrUnclAplyAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblEmrgSuptAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotlMdcrAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboBldnYn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDcntRdiaEmnm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDcntRdiaEmno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDcntRdiaCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRfndResn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUnclResn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDcntResn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSpclDcntAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitleLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGvrnClamAmt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public Framework.Controls.LxTitleLabel lblSmcrAmt;
        public Framework.Controls.LxTitleLabel lblPayUschAmt;
        public Framework.Controls.LxTitleLabel lblAsctSharAmt;
        public Framework.Controls.LxTitleLabel lblSuptAmt;
        public Framework.Controls.LxTitleLabel lblHllfMncsClamAmt;
        public Framework.Controls.LxTitleLabel lblTbrcCtctSuptAmt;
        public Framework.Controls.LxTitleLabel lblVcntClamAmt;
        public Framework.Controls.LxTitleLabel lblEmrgSuptAmt;
        public Framework.Controls.LxTitleLabel lblPayTamt;
        public Framework.Controls.LxTitleLabel lblBlodRdiaAmt;
        public Framework.Controls.LxComboBox cboBldnYn;
        public Framework.Controls.LxTitleLabel lblInsn100Tamt;
        public Framework.Controls.LxTitleLabel lblDcntRdiaCd;
        public Framework.Controls.LxComboBox cboDcntRdiaCd;
        public Framework.Controls.LxTitleLabel lblScngPayTamt;
        public Framework.Controls.LxTitleLabel lblSpclDcntAmt;
        public Framework.Controls.LxTextBox txtSpclDcntAmt;
        public Framework.Controls.LxTitleLabel lblClamNopyTamt;
        public Framework.Controls.LxTitleLabel lblNopyTamt;
        public Framework.Controls.LxTitleLabel lblDcntRdiaEmno;
        public Framework.Controls.LxTextBox txtDcntRdiaEmno;
        public Framework.Controls.LxTitleLabel lblAdedValuTaxTamt;
        public Framework.Controls.LxTitleLabel lblRcvdAmt;
        public Framework.Controls.LxTextBox txtRfndResn;
        public Framework.Controls.LxTitleLabel lblFrtmCashRcptAmt;
        public Framework.Controls.LxTitleLabel lblCardRcptAmt;
        public Framework.Controls.LxTitleLabel lblFrtmCardRcptAmt;
        public Framework.Controls.LxTitleLabel lblBnacRcptAmt;
        public Framework.Controls.LxTitleLabel lblUnclCd;
        public Framework.Controls.LxTitleLabel lblUnclAmt;
        public Framework.Controls.LxTextBox txtUnclResn;
        public Framework.Controls.LxTextBox txtSmcrAmt;
        public Framework.Controls.LxTextBox txtPayUschAmt;
        public Framework.Controls.LxTextBox txtPayClamAmt;
        public Framework.Controls.LxTextBox txtSuptAmt;
        public Framework.Controls.LxTextBox txtHllfMncsClamAmt;
        public Framework.Controls.LxTextBox txtTbrcCtctSuptAmt;
        public Framework.Controls.LxTextBox txtVcntClamAmt;
        public Framework.Controls.LxTextBox txtEmrgSuptAmt;
        public Framework.Controls.LxTitleLabel lblTotlMdcrAmt;
        public Framework.Controls.LxTitleLabel lblFrtmRcptTotlAmt;
        public Framework.Controls.LxTextBox txtTotlMdcrAmt;
        public Framework.Controls.LxTextBox txtFrtmRcptTotlAmt;
        public Framework.Controls.LxTextBox txtPayTamt;
        public Framework.Controls.LxTextBox txtBlodRdiaAmt;
        public Framework.Controls.LxTextBox txtInsn100Tamt;
        public Framework.Controls.LxTextBox txtScngPayUschAmt;
        public Framework.Controls.LxTextBox txtScngPayClamAmt;
        public Framework.Controls.LxTextBox txtFrtmDcntRdiaAmt;
        public Framework.Controls.LxTextBox txtDcntRdiaAmt;
        public Framework.Controls.LxTextBox txtClamNopyTamt;
        public Framework.Controls.LxTextBox txtNopyTamt;
        public Framework.Controls.LxTextBox txtAdedValuTaxTamt;
        public Framework.Controls.LxTextBox txtFrtmCardRcptAmt;
        public Framework.Controls.LxTextBox txtUnclAmt;
        public Framework.Controls.LxTextBox txtDcntResn;
        public Framework.Controls.LxTextBox txtPtSharAmt;
        public Framework.Controls.LxTitleLabel LxTitleLabel1;
        public Framework.Controls.LxButton btnPermitCancel;
        public Framework.Controls.LxTextBox txtHmptPayTamt;
        public Framework.Controls.LxTextBox txtDsblFundAmt;
        public Framework.Controls.LxTitleLabel lxTitleLabel3;
        public Framework.Controls.LxTitleLabel lxTitleLabel2;
        public Framework.Controls.LxTitlePanel lxTitlePanel1;
        public Framework.Controls.LxPanel lxPanel1;
        public Framework.Controls.LxCheckBox chkCashPrmtYn;
        private Framework.Controls.LxComboBox cboSpclDcntDvcd;
        public Framework.Controls.LxTitleLabel lblSpclDcntDvcd;
        public Framework.Controls.LxTitleLabel lblCttrUnclAplyAmt;
        public Framework.Controls.LxTextBox txtTotalPtSharAmt;
        private Framework.Controls.LxLabel lblCashRcpt;
        public Framework.Controls.LxTextBox txtDcntRdiaEmnm;
        private Framework.Controls.LxTextBox lxTextBox1;
        public Framework.Controls.LxTextBox txtCardRcptAmt;
        public Framework.Controls.LxTextBox txtCashRcptAmt;
        public Framework.Controls.LxTextBox txtCardRcptAmt_ing;
        public Framework.Controls.LxTextBox txtCashRcptAmt_ing;
        public Framework.Controls.LxTextBox txtBnacRcptAmt_ing;
        public Framework.Controls.LxTitleLabel lxTitleLabel4;
        public Framework.Controls.LxTextBox txtFrtmBnacAmt_C;
        public Framework.Controls.LxTextBox txtFrtmCardRcptAmt_C;
        public Framework.Controls.LxTextBox txtFrtmCashRcptAmt_C;
        public Framework.Controls.LxTextBox txtFrtmCashRcptAmt;
        public Framework.Controls.LxTextBox txtFrtmBnacAmt;
        public Framework.Controls.LxTextBox txtBnacRcptAmt;
        private Framework.Controls.LxComboBox cboUnclCd;
        public Framework.Controls.LxTextBox txtCttrUnclAplyAmt;
        public Framework.Controls.LxButton btnBillNoApply;
        public Framework.Controls.LxButton btnTabletReceipt;
        private Framework.Controls.LxTextBox txtFocus;
        public Framework.Controls.LxTitleLabel lxTitleLabel5;
        public Framework.Controls.LxTextBox txtGvrnClamAmt;
    }
}
