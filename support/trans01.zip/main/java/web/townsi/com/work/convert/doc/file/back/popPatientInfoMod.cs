//********************************************************************************
// Class 명 : popPatientInfoMod
// 역    할 : 환자기본정보관리 UserControl 을 담는 팝업
// 작 성 자 : 유준선
// 작 성 일 : 2017-10-02
//********************************************************************************
// 수정내역 : 
//********************************************************************************

namespace Lime.BusinessControls
{
    public partial class popPatientInfoMod : Lime.Framework.BasePopUp
    {
        /// <summary>
        /// 넘기는 Flag에 따라, 수정/조회권한이 달라집니다.
        /// <para>원무 : "P" → 모든 정보 수정가능.</para>
        /// <para>간호,의사 : "N" → 전화번호/주소/특이사항만 수정가능.</para>
        /// <para>기타 : "E" 또는 그 외 → 조회만 가능</para>
        /// </summary>
        /// <param name="partflag">접근권한구분Flag</param>
        public popPatientInfoMod(string partflag)
        {
            InitializeComponent();

            ucPatientInfoModE1.m_partFlag = partflag;
        }

        /// <summary>
        /// 넘기는 Flag에 따라, 수정/조회권한이 달라집니다.
        /// <para>또한 pid를 넘기면 해당 환자번호로 조회가 된 상태로 팝업이 열립니다.</para>
        /// <para>원무 : "P" → 모든 정보 수정가능.</para>
        /// <para>간호,의사 : "N" → 전화번호/주소/특이사항만 수정가능.</para>
        /// <para>기타 : "E" 또는 그 외 → 조회만 가능</para>
        /// </summary>
        /// <param name="partflag">접근권한구분Flag</param>
        public popPatientInfoMod(string partflag, string pid)
        {
            InitializeComponent();ucPatientInfoModE

            ucPatientInfoModE1.m_partFlag = partflag;
            ucPatientInfoModE1.m_pid = pid;
        }

    }
}
