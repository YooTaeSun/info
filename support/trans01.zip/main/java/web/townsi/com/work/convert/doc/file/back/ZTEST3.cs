using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Lime.Framework
{
    public class ZTEST2
    {
    
	/// <summary>
	/// 01.환자접수등록정보를 확인한다.
	/// </summary>
	/// <param name="msg"></param>
	/// <returns></returns>
	public int CheckPatientRegistInfo(ref string msg)
	{
	
	clsPACommon.SetComboPA(cboAsstTycd, "ASST_TYCD", "LWRN_OVRL_CDNM", cbo.Value.ToString().Trim(), OutRegInfo.MDCR_DD);
	
		//string msg = String.Empty;
		string etcusecnts2 = String.Empty;
		string assttycd = String.Empty;
		string cfscrgnocd = String.Empty;
		//string ecoicd = String.Empty;
		string tbrcdvcd = String.Empty;
		string iovmsg = String.Empty;
		int unclamt = 0;                    // 미수잔액
		string uncldd = String.Empty;         // 미수발새일자
		int uschrtn = 0;                    // 본인부담리턴값
		string uschaplycd = String.Empty;          // 본인부담코드
		string uscherrorcd = String.Empty;          // 본인부담에러코드
		string uschmsg = String.Empty;          // 본인부담메시지
		string refchk = String.Empty;
		string refmsg = String.Empty;
		string cfhcRem = String.Empty;   // 건생비잔액
		bool nonmcchcmpt = false; // 진찰료산정안함여부
		try
		{
			EnableSave = true;
			//사망환자확인 루틴
			if (ConfigService.GetConfigValueBool("PA", "RECEIPT", "DEATH_CHECK", false))
			{
				// 사망환자 여부 확인
	
				if (StringService.IsNotNull(this.PatientInfo.DETH_DD) && DateTimeService.IsDateTime(this.PatientInfo.DETH_DD))
				{
					LxMessage.Show("사망환자로 등록된 환자등록번호입니다! [ 사망일자 : " + this.PatientInfo.DETH_DD + " ]");
				}
				else
				{
					// TODO : 사망진단서 확인 
					// EMR에서 뷰제공하기로 함.
	
				}
			}
	
			// 진료완료만 수납 처리 할것인지 확인?
			// 처방이 한건이라도 있는 경우만 체크함.
			if (int.Parse(OutRegInfo.PT_MDCR_STAT_DVCD) < 5 && clsPACommon.ReturnPrscIssuedCnt(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO, "%", "AC") >= 1)
			{
				msg = "처방입력 진료완료전(진료중)입니다. 처방입력 진료완료후 수납하세요!!";
	
				if (ConfigService.GetConfigValueString("%", "MDCR_STAT_CHECK_YN", "MDCR_STAT_CHECK_YN", "N").Equals("Y"))
				{
					return -1;
				}
			}
	
			// 당일 입원취소인 경우 알림메시지
			if (DBService.ExecuteInteger(SQL.PA.Sql.SelectAdmsCancelCount(), OutRegInfo.PID, OutRegInfo.MDCR_DD) > 0)
				LxMessage.Show("당일 입원 취소 환자입니다.", "확인");
	
			// OCS오픈일자를 확인한다.
			if (!clsPACommon.CheckOcsOpenDate(OutRegInfo.MDCR_DD))
				return -1;
	
			// TODO : 개인정보수집동의서 작성유무
	
			// TODO : 보훈인경우 보훈개인정보수집동의서를 작성했을 경우 EMR에 동의서 존재 여부를 확인한다.
	
			// TODO : OPEN CARD
	
			// 보조유형
			clsPACommon.SetComboPA(cboAsstTycd, "ASST_TYCD", "LWRN_OVRL_CDNM", OutRegInfo.INSN_TYCD, OutRegInfo.MDCR_DD);
			cboAsstTycd.SelectValue(OutRegInfo.ASST_TYCD);
	
			OutRegInfo.INSN_CLAM_DEPT_CD = " ";
	
			this.m_FrvsRvstDvcdSave = false;
			
			//초재진변경, 접수변경재계산의 경우 초재진변경을 체크하지 않는다.
			if (m_FrvsRvstDvcd == "Y" && m_ChangeFlag != "F")
			{
				string frvsrvstdvcd = OutRegInfo.FRVS_RVST_DVCD;
	
				if (!frvsrvstdvcd.Equals("1")) // 신환환자가 아니면
				{
					msg = String.Empty;
					if (!OutRegInfo.CheckFrvsRvstDvcd(ref msg))
					{
						LxMessage.Show(msg + " 초진재진 체크중 오류가 발생헀습니다. ", "초진재진체크", MessageBoxButtons.OK, MessageBoxIcon.Stop);
						return 1;
					}
	
					//미수납 처방이 있는지 확인한다.
					//미수납 처방이 있는 경우에 초진재진구분이 변경되는 경우 메시지를 띄운다.
					if (frvsrvstdvcd != OutRegInfo.FRVS_RVST_DVCD && clsPACommon.ReturnPrscIssuedCnt(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO, "N", "ALL") > 0)
					{
						string frvsrvstnm = OverallCodeList.GetColumnValue("FRVS_RVST_DVCD", OutRegInfo.FRVS_RVST_DVCD, "LWRN_OVRL_CDNM").ToString();
	
						if (LxMessage.Show("초진재진구분이 맞지 않습니다. 다음과 같이 변경하시겠습니까? \r\n [초진재진구분코드 : " + OutRegInfo.FRVS_RVST_DVCD + "(" + frvsrvstnm + ") ] \r\n 수납처리전까지는 저장되지 않습니다.", "초진재진변경확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
						{
	
							cboFrvsRvstDvcd.SelectValue(OutRegInfo.FRVS_RVST_DVCD);
							this.m_FrvsRvstDvcdSave = true;
						}
						else
						{
							OutRegInfo.FRVS_RVST_DVCD = frvsrvstdvcd;
						}
					}
					else if (frvsrvstdvcd != OutRegInfo.FRVS_RVST_DVCD)
					{
						// 초재구분이 변경되었더라도 처방이 없거나 수납 처방이 있는 경우에는 초재구분을 변경하지 않는다.
						OutRegInfo.FRVS_RVST_DVCD = frvsrvstdvcd;
					}
				}
			}
	
			if (m_ChangeFlag != "F")
			{//양한방 동일보험유형 진료내역 존재 확인
				if (!CheckWestMediAndOrieMedi(ref msg))
				{
					DBService.RollbackTransaction();
					LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
					return -1;
				}
			}
	
			/*************************** 내역변경 확인 Start ************************/
			if (m_ChangeFlag == "F")
			{
				// TODO : 접수정보 백업 생성
				// 내역정보변경있으면 변경내역저장
	
				OutRegInfo.MCCH_CMPT_DVCD = "N";   // 진찰료 산정 구분코드
				OutRegInfo.CMHS_DVCD = cboCmhsDvcd.SelectedValue;       // 내원구분코드
				OutRegInfo.FRVS_RVST_DVCD = cboFrvsRvstDvcd.SelectedValue;   // 초진재진구분코드
				OutRegInfo.DY_WARD_YN = "NO";       // 낮병동여부
			}
			else
			{
				// 미수내역을 메시지로 보여준다.
				if (clsPACommon.ShowMessage_UnclAmt(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), this))
				{
					OnPatientClear();
					return 1;
				}
	
				unclamt = 0;
				//현내원정보의 미수존재 여부확인
				if (!clsPACommon.GetUnclAmtNow(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO, "*", ref unclamt, ref msg))
					return -1;
	
				if (unclamt > 0)
				{
					LxMessage.Show("현 내원정보에 미수금이 존재합니다. \rn\n 미수금액은 " + string.Format("{0:#,##0}", unclamt) + " 원 입니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
	
				// TODO : 환불처리정보확인(외래입원확인)
				// TODO : 외래보관금 존재여부확인
				// TODO : 금연보험대상자확인
	
				m_Compare_ASST_TYCD = OutRegInfo.ASST_TYCD;
				m_Compare_CFSC_RGNO_CD = "";
	
				if ((OutRegInfo.INSN_TYCD == "11" || OutRegInfo.INSN_TYCD == "21" || OutRegInfo.INSN_TYCD == "22") && OutRegInfo.ASST_TYCD != "99" && OutRegInfo.ASST_TYCD != "D9"
																													&& OutRegInfo.ASST_TYCD != "91" && OutRegInfo.ASST_TYCD != "P9" && OutRegInfo.ASST_TYCD != "9C")
				{
					string ecoicd = string.Empty;
	
					// 2019-08-06 SJH 외래보조유형 세팅이력 history를 쌓자.
					if (!clsPACommon.InsertPAOPASRT(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), OutRegInfo.RCPN_SQNO.ToString(),
														assttycd, cfscrgnocd, ecoicd, tbrcdvcd, ref iovmsg))
					{
						msg = iovmsg;
						return -1;
					}
				
					//chkReBurn.Checked를 뺄예정
					if (chkReBurn.Checked || lblForceChange.Visible)
					{
						assttycd = OutRegInfo.ASST_TYCD;
						cfscrgnocd = "NO";
					}
								
				}
			}
			/*************************** 내역변경 확인 end ************************/
			// 처방을 가져와서 처방내역에 표시한다.
			// 방문할 곳을 표시한다.
			OnPatientSelected("PRSC", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO);
	
			if (m_QtyZeroYn.Equals("Y"))
			{
				LxMessage.Show("투여량이 0 인 처방이 있습니다. 진료부서에 문의하세요.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
				EnableSave = false;
	
			}
	
			// 접수내역을 조회한다.
			OnPatientSelected("REG", OutRegInfo.PID);
	
			// ++++++++++++++++++++++++++++++++++++++++++++++++++
			// 미수 내역을 확인한다.
			// ++++++++++++++++++++++++++++++++++++++++++++++++++
			DataTable dt = new DataTable();
			if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectUnclDpstAmt(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString()), ref dt))
				throw new Exception("미수 내역을 조회하는 중 에러가 발생했습니다.");
	
			// 개인미수 외에 입금된 내역이 있는 경우
			bool has_clam_dpst_amt = dt.AsEnumerable().Where(r => (!r["UNCL_OCRR_DVCD"].ToString().Equals("*") && decimal.Parse(r["DPST_AMT"].ToString()) > 0)).Any();
	
			if (dt.Rows.Count > 0)
			{
				if (has_clam_dpst_amt)
				{
					// 청구미수 등 입금내역이 있는 경우는 재수납 불가.
					EnableSave = false;
				}
				else
				{
					string message = string.Empty;
					message += "미수입금정보가 존재하므로 다음과 같은 작업 후\r\n재수납하세요.\r\n\r\n";
					message += "예       : 미수입금을 취소 후 수납\r\n";
					message += "아니오 : 미수입금 외래수납금으로 전환\r\n";
					message += "취소    : 금액 조회";
	
					DialogResult dialog = LxMessage.Show(message, "확인", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
	
					if (dialog == DialogResult.Yes)
					{
						// 미수입금 팝업을 띄운다.
						OnPatientSelected("SAVEYN", "RECALC");
	
						clsPACommon.ShowForm_UnclAmt(OutRegInfo.PID, dt.Rows[0]["UNCL_OCRR_DVCD"].ToString(), this);
						return -1;
					}
					else if (dialog == DialogResult.No)
					{
						// 미수입금된 내역의 paobilbd 들을 만든다.
						OnPatientSelected("CHANGEUNCOMABILBD", OutRegInfo.PID);
					}
					else
					{
						// 수납 불가.
						EnableSave = false;
					}
				}
			}
	
			bool editMode = true;
	
			if (IsLockedSystem(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), "PA"))
			{
				SystemLockInfo lockinfo = this.SystemLockService.SelectSystemLock(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), "PA");
	
				if (!string.IsNullOrWhiteSpace(lockinfo.LOCK_USER_CD) &&
					(!lockinfo.LOCK_USER_CD.Equals(DOPack.UserInfo.USER_CD) || !lockinfo.LOCK_IP.Equals(ClientEnvironment.IP)))
				{
					editMode = false;
	
					string message = string.Empty;
					message += $"이미 다른 유저가 사용중이므로, 조회모드로 들어갑니다.\r\n";
					message += $"\r\n 사용중인 유저 정보";
					message += $"\r\n    {lockinfo.LOCK_DEPT_NM} / {lockinfo.LOCK_USER_NM} ({lockinfo.LOCK_USER_CD})";
					message += $"\r\n    {DateTimeService.ConvertDateTime(lockinfo.LOCK_DT).ToString("yyyy-MM-dd HH:mm")} / {lockinfo.LOCK_IP}";
	
					if (DBService.ExecuteScalar("SELECT CONF_VAL FROM ADCONFDT T WHERE SYSTEM_CD = 'PA' AND CONF_TYPE = 'RECEIPT' AND CONF_CD = 'LOCK_QUESTION' ").ToString().Equals("Y"))
					{
						message += $"\r\n\r\nLock을 해제하고 수납가능 모드로 들어가시겠습니까?";
						if (LxMessage.ShowQuestion(message).Equals(DialogResult.Yes))
							editMode = true;
					}
					else
					{
						LxMessage.ShowError(message);
					}
				}
			}
	
			// lock 을 건다
			if (editMode)
				this.LockSystem(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString());
	
			SystemLocked?.Invoke(!editMode);
	
			/**************************** Transaction Start ***************************/
	
			DBService.BeginTransaction();
	
			if (m_ChangeFlag == "F")
			{
				// TODO : 접수정보 백업 생성
				// 내역정보변경있으면 변경내역저장
				if (!OutRegInfo.UpdateRegistInfoChangeAtRec(ref msg))
					return -1;
	
				// TODO :  보훈병원 지정시 저장
			}
	
			// 진찰료 산정안함으로 변경되어 있으면 외래접수를 변경한다.
			if (nonmcchcmpt)
			{
				string errordvcd = String.Empty;
				string errorcnts = String.Empty;
	
				if (!SqlPack.Procedure.PR_PA_PRC_PAOPATRTCH(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), OutRegInfo.RCPN_SQNO.ToString(), "MCCH_CMPT_DVCD", "N", DOPack.UserInfo.USER_CD, ref errordvcd, ref errorcnts))
				{
					throw new Exception(string.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));
				}
	
				if (StringService.IsNotNull(errordvcd))
				{
					throw new Exception("오류 내용[PR_PA_PRC_PAOPATRTCH] : [" + errordvcd + "]" + errorcnts);
				}
			}
	
			if (!OutRegInfo.RRNO.Length.Equals(13))
			{
				msg = string.Format("[PR_PA_COM_MEDICOSTMAIN] 주민번호가 13자리가 아닙니다. ({0}) : ", OutRegInfo.RRNO) + DBService.ErrorMessage;
				DBService.RollbackTransaction();
				return -1;
			}
	
			// 진료비계산 로직
			// 정산시작일자를 건생비잔액으로 사용한다. (인적정보 주민번호를 넘겨야 함!!!)
			if (!SqlPack.Procedure.PR_PA_COM_MEDICOSTMAIN(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString(), OutRegInfo.FRRN, OutRegInfo.SRRN, "O"
														, OutRegInfo.RCPN_SQNO.ToString(), OutRegInfo.MDCR_DD, OutRegInfo.FRVS_RVST_DVCD, OutRegInfo.INSN_TYCD, OutRegInfo.ASST_TYCD
														, cfsc_rgno_cd, OutRegInfo.MDCR_DD, this.m_FrvsRvstDvcdSave ? "Y" : "N", OutRegInfo.MDCR_DD, ""
														, "", cfhcRem, "", ref iovmsg))
			{
				msg = "[PR_PA_COM_MEDICOSTMAIN] 진료비 계산 처리 중 오류 발생[DB] : " + DBService.ErrorMessage;
				DBService.RollbackTransaction();
				return -1;
			}
	
			string a = this.m_FrvsRvstDvcdSave ? "Y" : "N";
	
			lblMediParams.Tag = $@"
	[PR_PA_COM_MEDICOSTMAIN]
	IV_PID                = {OutRegInfo.PID}
	IN_PT_CMHS_NO         = {OutRegInfo.PT_CMHS_NO}
	IV_FRRN               = {OutRegInfo.FRRN}
	IV_SRRN               = {OutRegInfo.SRRN}
	IV_OTPT_ADMS_DVCD     = O
	
	IN_RCPN_SQNO          = {OutRegInfo.RCPN_SQNO}
	IV_MDCR_DD            = {OutRegInfo.MDCR_DD}
	IV_MAIN_SUB_ADMS_DVCD = {OutRegInfo.FRVS_RVST_DVCD}
	IV_INSN_TYCD          = {OutRegInfo.INSN_TYCD}
	IV_ASST_TYCD          = {OutRegInfo.ASST_TYCD}
	IV_CFSC_RGNO_CD       = {cfsc_rgno_cd}
	
	IV_ADMS_DD            = {OutRegInfo.MDCR_DD}
	IV_ADMS_TIME          = {a}
	IV_DSCH_DD            = {OutRegInfo.MDCR_DD}
	IV_DSCH_TIME          = 
	IV_CLSN_DVCD          = 
	IV_CMPY_STRT_DD       = {cfhcRem}
	IV_CMPY_END_DD        =  ";
	
			if (StringService.IsNotNull(iovmsg))
			{
				msg = "[PR_PA_COM_MEDICOSTMAIN] 진료비 계산 처리 중 오류 발생[MSG] : " + iovmsg;
				DBService.RollbackTransaction();
				return -1;
			}
	
			// TODO : 약국 스크린 등록
	
			DBService.CommitTransaction();
	
			/**************************** Transaction End ***************************/
			// 처방갯수확인
			OutRegInfo.PRSC_COUNT = DBService.ExecuteInteger(SQL.PA.Sql.SelectPrscCountToCompare(), OutRegInfo.PID
																								  , OutRegInfo.PT_CMHS_NO.ToString()
																								  , OutRegInfo.MDCR_DD);
			// 영수증갯수확인
	
			OutRegInfo.BILL_COUNT = DBService.ExecuteInteger(SQL.PA.Sql.SelectBillCountToCompare(), OutRegInfo.PID
																								, OutRegInfo.PT_CMHS_NO.ToString());
			//수납처방
			OnPatientSelected("RECPRSC", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO);
			//수익별집계
			OnPatientSelected("PROFIT", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO);
			//영수내역
			OnPatientSelected("BILLHIS", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO);
			//영수정보
			OnPatientSelected("BILL", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO);
			//특이사항
			OnPatientSelected("REMARK", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO);
	
			// DRG환자확인
			string drgno = String.Empty;
			string insntycddrg = String.Empty;
			string assttycddrg = String.Empty;
			
			if (!EnableSave)
			{
				OnPatientSelected("SAVEYN", OutRegInfo.PID);
			}
	
			// 당일 이전 미수납 처방을 확인한다.
			string norcptmdcrdd = DBService.ExecuteScalar(SQL.PA.Sql.SelectNoReceipt(), OutRegInfo.PID
																					  , OutRegInfo.MDCR_DD).ToString();
	
			if (string.IsNullOrWhiteSpace(norcptmdcrdd) && DateTimeService.IsDateTime(norcptmdcrdd))
			{
				LxMessage.Show(clsPACommon.ConvertDateFormat(2, norcptmdcrdd) + " 에 미수납된 접수내역이 존재합니다. 확인하시기 바랍니다.",
							   "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
	
			// 당일퇴원환자인지를 확인한다.
			if (DBService.ExecuteInteger(SQL.PA.Sql.SelectPAIPATRT_DSCH_YN(), OutRegInfo.PID
																		, OutRegInfo.MDCR_DD) > 0)
			{
				LxMessage.Show("내원 당일 퇴원예정이거나 퇴원환자입니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
	
			// 재원중인 환자인지를 확인한다.
			if (DBService.ExecuteInteger(SQL.PA.Sql.SelectPAIPATRT_MAIN_ADMS_DVCD_J(OutRegInfo.PID)) > 0)
			{
				LxMessage.Show("재원중인 환자입니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			
			// 그룹처방의 경우 세부처방이 존재하는지 확인한다.
			string groupprscnm = DBService.ExecuteScalar(SQL.PA.Sql.SelectDetailPrscOfGroupPrsc(), OutRegInfo.PID
																								 , OutRegInfo.PT_CMHS_NO.ToString()).ToString();
	
			if (StringService.IsNotNull(groupprscnm))
			{
				LxMessage.Show("그룹수가 [" + groupprscnm + "] 의 세부수가가 없는 그룹수가가 존재합니다. 보험심사과나 전산실에 문의하세요.",
							   "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
	
			// 이벤트의 마지막인걸 알려준다.
			OnPatientSelected("END", OutRegInfo.PID);
	
			return 1;
		}
		catch (Exception ex)
		{
			if (DBService.IsTransaction)
				DBService.RollbackTransaction();
	
			LxMessage.Show(ex.Message, "외래수납 계산 중 오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
			return -1;
		}
		return 1;
	}    
    	
	}
}        
        
        
        
        
         
        
        


        