namespace Lime.Framework
{
    /// <summary>
    /// 기초정보
    /// </summary>
    public class DOPack
    {
        #region Define : Member

        /// <summary>
        /// 병원정보 DataObject
        /// </summary>
        private static DOHospitalInfo m_HospitalInfo = new DOHospitalInfo();
        /// <summary>
        /// 유저정보 DataObject
        /// </summary>
        private static DOUserInfo m_UserInfo = new DOUserInfo();
        /// <summary>
        /// 환자정보 DataObject
        /// </summary>
        private static DOPatientInfo m_PatientInfo = new DOPatientInfo();
        /// <summary>
        /// 메뉴정보 DataObject
        /// </summary>
        private static DOMenuInfo m_MenuInfo = new DOMenuInfo();

        #endregion

        #region Property

        /// <summary>
        /// 병원정보 DataObject
        /// </summary>
        public static DOHospitalInfo HospitalInfo { get { return m_HospitalInfo; } set { m_HospitalInfo = value; } }
        /// <summary>
        /// 유저정보 DataObject
        /// </summary>
        public static DOUserInfo UserInfo { get { return m_UserInfo; } set { m_UserInfo = value; } }
        /// <summary>                                                                                                                                 
        /// 환자정보 DataObject
        /// </summary>
        public static DOPatientInfo PatientInfo { get { return m_PatientInfo; } set { m_PatientInfo = value; } }
        /// <summary>
        /// 메뉴정보 DataObject
        /// </summary>
        public static DOMenuInfo MenuInfo { get { return m_MenuInfo; } set { m_MenuInfo = value; } }
        #endregion

        public static void Dispose()
        {
            m_HospitalInfo.Dispose();
            m_UserInfo.Dispose();
            m_PatientInfo.Dispose();
            m_MenuInfo.Dispose();
        }
    }
}
