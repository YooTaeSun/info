//********************************************************************************
// Class 명 : frmChangePnpyDvcdP
// 역    할 : 처방등록의 급여비급여구분, 계산보류여부을 변경한다.
// 작 성 자 : 박계훈
// 작 성 일 : 2017-10-25
//********************************************************************************
using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Lime.BusinessControls;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public partial class frmChangePnpyDvcdP : BasePopUp
    {
        #region Define : Member

        private string m_Pid = string.Empty;
        private int m_PtCmhsNo = 0;
        private string m_MdcrDd = string.Empty;

        public string Pid { get { return m_Pid; } set { m_Pid = value; } }
        public int PtCmhsNo { get { return m_PtCmhsNo; } set { m_PtCmhsNo = value; } }
        public string MdcrDD { get { return m_MdcrDd; } set { m_MdcrDd = value; } }

        clsOutRegistrationInfo OutRegInfo = new clsOutRegistrationInfo();

        private clsORCommon m_OrCommon = new clsORCommon();

        #endregion Define : Member

        #region Contruction

        public frmChangePnpyDvcdP(string pid, int ptcmhsno)
        {
            InitializeComponent();

            m_Pid = pid;
            m_PtCmhsNo = ptcmhsno;
        }

        #endregion Contruction

        #region Screen Load

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode)
                return;

            InitializeEvent();

            if (string.IsNullOrWhiteSpace(m_Pid) || m_PtCmhsNo.Equals(0))
                return;

            SelectPatientInfo();
            SelectData();
        }

        #endregion Screen Load

        #region Method : Initialize
        private void InitializeEvent()
        {
            btnButtonList.ButtonItems.Clear();
            btnButtonList.ButtonItems.Add(ButtonType.Edit, "주/야 변경");
            btnButtonList.ButtonItems.Add(ButtonType.Process, "금액 변경");
            btnButtonList.ButtonItems.Add(ButtonType.Save, "정보 변경");
            btnButtonList.ButtonItems.Add(ButtonType.Close, "닫 기");
            btnButtonList.InitializeButtons();

            btnButtonList.ButtonClick += btnButtonList_ButtonClick;
            sprPrsc.ComboSelChange += sprPrsc_ComboSelChange;
            sprPrsc.ComboCloseUp += SprPrsc_ComboCloseUp;
        }

        private void SprPrsc_ComboCloseUp(object sender, FarPoint.Win.Spread.EditorNotifyEventArgs e)
        {
            if (cboAsstTycd.SelectedValue.Equals("99"))
                return;

            // 선별적용이 변경된 경우
            string tag = sprPrsc.ActiveSheet.Columns[e.Column]?.Tag?.ToString() ?? string.Empty;
            if (!tag.Equals("ETC_USE_CNTS_2"))
                return;

            string scng_pay_dvcd = sprPrsc.GetValue(e.Row, "ETC_USE_CNTS_2").ToString();
            if (scng_pay_dvcd.Equals("0") || scng_pay_dvcd.Equals("1"))
            {
                sprPrsc.SetValue(e.Row, "ETC_USE_CNTS_2_BK", scng_pay_dvcd);
                return;
            }

            string mefe_cd = sprPrsc.GetValue(e.Row, "PRSC_CD").ToString();

            if (!CheckScngPayNopy(mefe_cd, m_MdcrDd, cboInsnTycd.SelectedValue, scng_pay_dvcd))
            {
                // 기존에 조회한 데이터로 돌려놓자.
                sprPrsc.ActiveSheet.Cells[e.Row, e.Column].Value = sprPrsc.GetValue(e.Row, "ETC_USE_CNTS_2_BK").ToString();
            }
            else
            {
                sprPrsc.SetValue(e.Row, "ETC_USE_CNTS_2_BK", scng_pay_dvcd);
            }
        }

        #endregion Method : Initialize

        #region Method : Private Method

        private void SelectPatientInfo()
        {
            try
            {
                DOPatientInfo pt_info = new DOPatientInfo();
                if (!pt_info.Load(m_Pid))
                    throw new Exception("환자 기본정보를 조회하는 중 에러가 발생했습니다.");

                txtPid.Text = pt_info.PID;
                txtPtNm.Text = pt_info.PT_NM;
                txtFrrn.Text = pt_info.FRRN;
                txtSrrn.Text = pt_info.SRRN;
                txtSex.Text = pt_info.SEX_DVCD;
                txtAge.Text = pt_info.AGE.ToString();

                if (!OutRegInfo.Load(m_Pid, m_PtCmhsNo))
                    throw new Exception("환자 접수정보를 조회하는 중 에러가 발생했습니다.");

                m_MdcrDd = OutRegInfo.MDCR_DD;
                mskMdcrDd.Text = OutRegInfo.MDCR_DD;
                cboMdcrDeptCd.SelectValue(OutRegInfo.MDCR_DEPT_CD);
                cboMdcrDrCd.SelectValue(OutRegInfo.MDCR_DR_CD);
                cboInsnTycd.SelectValue(OutRegInfo.INSN_TYCD);
                cboAsstTycd.SelectValue(OutRegInfo.ASST_TYCD);

                sprPrsc.SetComboItems("PRSC_TIME_DVNM", OverallCodeList.GetDataList("PA_PRSC_TIME_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.AddNone);
                sprPrsc.SetComboItems("PNPY_DVCD", OverallCodeList.GetDataList("PAY_NOPY_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");

                // mdcr_dd가 필요해서 여기서 세팅 함
                // [보험100적용] => [선별적용]으로 변경 됨
                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable($@"SELECT LWRN_OVRL_CD, LWRN_OVRL_CDNM FROM BICDINDT WHERE OVRL_CD = 'OR_SCNG_PAY_DVCD' AND '{m_MdcrDd}' BETWEEN APLY_STRT_DD AND APLY_END_DD ORDER BY SORT_SEQ ", ref dt))
                    throw new Exception("선별적용 코드를 조회하는 중 에러가 발생했습니다.");

                sprPrsc.SetComboItems("ETC_USE_CNTS_2", dt, "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        private void SelectData()
        {
            try
            {
                sprPrsc.ActiveSheet.Rows.Count = 0;

                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectToChangePrsc(), ref dt, m_Pid, m_PtCmhsNo.ToString()))
                    throw new Exception("처방내역을 조회하는 중 에러가 발생했습니다.");

                if (dt.Rows.Count.Equals(0))
                    return;

                sprPrsc.FillDataTag(dt);
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        /// <summary>
        /// 처방변경내역을 저장한다.
        /// </summary>
        private void SavePrscChange()
        {
            try
            {
                // 청구된 자료는 변경할 수 없다.
                /*
                if (DBService.ExecuteScalar(SqlPack.Function.SelectFN_CL_PRC_CHKCLAMCRTN(), this.Pid
                                                                                          , this.PtCmhsNo.ToString()
                                                                                          , msg).ToString() == "Y")
                {
                    LxMessage.Show(" 해당 환자는 청구심사 중이거나 이미 청구가 완료되어 수정이 불가합니다. \r\n" +
                                   " 보험 심사과에 문의하세요 !", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                */

                if (!sprPrsc.IsModified())
                {
                    LxMessage.ShowError("변경 내역이 없습니다.");
                    return;
                }

                DBService.BeginTransaction();

                for (int i = 0; i < sprPrsc.ActiveSheet.RowCount; i++)
                {
                    if (sprPrsc.GetCRUDFromRow(i) != CRUD_TYPE.Update)
                        continue;

                    string pnpydvcd = sprPrsc.GetValue(i, "PNPY_DVCD").ToString();
                    string clclholdyn = sprPrsc.GetValue(i, "CLCL_HOLD_YN").ToString();
                    string smcraplyyn = sprPrsc.GetValue(i, "SMCR_APLY_YN").ToString();
                    string prscssqno = sprPrsc.GetValue(i, "PRSC_SQNO").ToString();
                    string bndlprscsqno = sprPrsc.GetValue(i, "BNDL_PRSC_SQNO").ToString();
                    string bndlprscdvcd = sprPrsc.GetValue(i, "BNDL_PRSC_DVCD").ToString();
                    string prsc_time_dvnm = sprPrsc.GetValue(i, "PRSC_TIME_DVNM").ToString().Equals("NO") ? string.Empty : sprPrsc.GetValue(i, "PRSC_TIME_DVNM").ToString();

                    if (bndlprscdvcd.Equals("1"))
                    {
                        if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePrscChange(), m_Pid
                                                                                    , m_PtCmhsNo.ToString()
                                                                                    , prscssqno
                                                                                    , pnpydvcd
                                                                                    , clclholdyn
                                                                                    , smcraplyyn
                                                                                    , sprPrsc.GetValue(i, "ETC_USE_CNTS_2").ToString()
                                                                                    , prsc_time_dvnm
                                                                                    ))
                            throw new Exception("처방내역을 변경하는 중 에러가 발생했습니다.");
                    }
                    else
                    {
                        if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateBndlPrscChange(), m_Pid
                                                                                        , m_PtCmhsNo.ToString()
                                                                                        , m_MdcrDd
                                                                                        , prscssqno
                                                                                        , bndlprscsqno
                                                                                        , pnpydvcd
                                                                                        , clclholdyn
                                                                                        , prsc_time_dvnm))
                            throw new Exception("그룹처방내역을 변경하는 중 에러가 발생했습니다.");
                    }
                }

                DBService.CommitTransaction();

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                if (DBService.IsTransaction)
                    DBService.RollbackTransaction();

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        private void SetAmtChange()
        {
            if (sprPrsc.ActiveSheet.RowCount <= 0)
                return;

            string price_dvcd = sprPrsc.GetValue(sprPrsc.ActiveSheet.ActiveRowIndex, "PRICE_DVCD").ToString();

            if (price_dvcd != "Y")
            {
                LxMessage.ShowError("MRI 비급여 처방만 금액변경 가능합니다.");
                return;
            }

            string prsc_sqno = sprPrsc.GetValue(sprPrsc.ActiveSheet.ActiveRowIndex, "PRSC_SQNO").ToString();

            using (popSetAmtChange pop = new popSetAmtChange(m_Pid, m_PtCmhsNo.ToString(), m_MdcrDd, prsc_sqno))
            {
                if (pop.ShowDialog(this).Equals(DialogResult.OK))
                {
                    LxMessage.ShowInformation("외래수납화면에서 [접수변경재계산] 처리하면\r\n변경한 금액이 수납금액에 반영됩니다.");
                }
            }
        }

        #endregion Method : Private Method


        #region Event : Event Process

        private void btnButtonList_ButtonClick(object sender, ButtonClickEventArgs e)
        {
            switch (e.ButtonType)
            {
                // 주/야 변경
                case ButtonType.Edit:
                    ChangeDayNight();
                    break;

                // 금액 변경
                case ButtonType.Process:
                    SetAmtChange();
                    break;

                // 정보 변경
                case ButtonType.Save:
                    SavePrscChange();
                    break;

                case ButtonType.Close:
                    Close();
                    break;
            }
        }

        private void ChangeDayNight()
        {
            try
            {
                // 뭔가 이렇게 매번 안해도 될거같은데 m_orcommon에서 뭔 일 있을거 같으니까 그냥 두자...ㅠㅠ
                this.PatientInfo.Load(m_Pid);

                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.OR.Sql.SelectOPPatientInfoO(), ref dt, m_Pid, m_PtCmhsNo.ToString(), this.PatientInfo.SRRN_ECPT, m_MdcrDd))
                    throw new Exception("외래접수정보를 조회하는 중 에러가 발생했습니다.");

                if (dt.Rows.Count.Equals(0))
                    throw new Exception("외래접수정보를 조회하는 중 에러가 발생했습니다.\r\n접수정보가 없습니다.");

                if (m_OrCommon.SetOpWkNtER(sprPrsc, m_Pid, m_PtCmhsNo.ToString(), m_MdcrDd, "O", dt.Rows[0]["MDCR_DEPT_CD"].ToString(), dt.Rows[0]["MDCR_DR_CD"].ToString(), dt.Rows[0]["PRSC_NOTM"].ToString(), "PA"))
                    SelectData();
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        private bool CheckScngPayNopy(string mefe_cd, string aply_strt_dd, string insn_tycd, string scng_pay_nopy_dvcd)
        {
            try
            {
                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectBIMFECMA(mefe_cd, aply_strt_dd, insn_tycd), ref dt))
                    throw new Exception("선별 적용 가능한 리스트를 조회하는 중 에러가 발생했습니다.");

                var temp = dt.AsEnumerable().Where(r => r["APLY_CNTS"].ToString().Equals(scng_pay_nopy_dvcd));
                if (!temp.Any())
                {
                    string scng_pay_dvnm = string.Join("\r\n", dt.AsEnumerable().Select(r => $"    - {r["SCNG_PAY_CDNM"].ToString()}"));
                    LxMessage.ShowError($"아래 선별급여만 선택 가능합니다.\r\n{scng_pay_dvnm}");
                    return false;
                }
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
                return false;
            }

            return true;
        }

        private void sprPrsc_ComboSelChange(object sender, FarPoint.Win.Spread.EditorNotifyEventArgs e)
        {
            //처방타이틀이 CRC가 아닌데 급비구분에 임상시험이 들어오면 안되게 막아야함.
            if (sprPrsc.GetText(e.Row, "PRSC_INPT_DVCD") != "88")
            {
                if (sprPrsc.GetValue(e.Row, "PNPY_DVCD").ToString() == "9")
                {
                    LxMessage.Show("처방타이틀이 " + OverallCodeList.GetColumnValue("PRSC_INPT_DVCD", "88", "LWRN_OVRL_CDNM").ToString() + "가 아닌경우\r\n급비구분을 " + OverallCodeList.GetColumnValue("PAY_NOPY_DVCD", "9", "LWRN_OVRL_CDNM").ToString() + "로 변경할 수 없습니다.", "처방타이틀 확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    sprPrsc.SetValue(e.Row, "PNPY_DVCD", sprPrsc.GetValue(e.Row, "PNPY_DVCD1").ToString());
                }
            }

            //바뀐걸 PNPY_DVCD1컬럼에 넣어둔다.
            sprPrsc.SetValue(e.Row, "PNPY_DVCD1", sprPrsc.GetValue(e.Row, "PNPY_DVCD").ToString());
        }

        #endregion Event : Event Process
    }
}
