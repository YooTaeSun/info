
import { LogService } from "@/app/framework/CommonService/LogService";
import LxMessage from "@/app/framework/Controls/LxMessage.vue";
import "@/app/utils/number.extensions";

{
      // [ToolboxItem(false)]
    {
        // #region Enum : public Enum

        public enum MESSAGETYPE
        {
            /// <summary>
            /// 저장 완료
            /// </summary>
            SaveComplete = 0,

            /// <summary>
            /// 저장 실패
            /// </summary>
            SaveFail,

            /// <summary>
            /// 수정된 내역
            /// </summary>
            ModifyCheck,

            /// <summary>
            /// 필수 입력 값
            /// </summary>
            RequireInput,

            /// <summary>
            /// 잘 못 입력된 값
            /// </summary>
            ErrorInput,

            /// <summary>
            /// 중복 입력
            /// </summary>
            DuplicateInput,

            /// <summary>
            /// 기준 중복 입력(적용일자)
            /// </summary>
            DuplicateAplyDade,

            /// <summary>
            /// 삭제 확인
            /// </summary>
            Delete_YN,

            /// <summary>
            /// 삭제 확인(선택한 정보)
            /// </summary>
            DeleteSelect_YN,

            /// <summary>
            /// 삭제할 정보 없음
            /// </summary>
            DeleteNot
        }

        // #endregion Enum : public Enum

        // #region Define : Member

        m_LxMessageStr;
        private String m_LxMessageStr;
        private LxMessage m_LxMessage;
        private Timer m_CloseTimer;
        private let m_HideSecond:number = 0;
        private let m_ElapseTime:number = 0;
        //private double    m_Opacity      = 1;
        private const let m_ButtonWidth:number = 80;
        private const let m_ButtonHeight:number = 30;

        // #endregion Define : Member

        // #region Construction

        public LxMessage(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton)
        {
            InitializeComponent();

            Initialize(text, caption, buttons, icon, defaultButton);
        }

        public LxMessage(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, int hidesecond)
        {
            InitializeComponent();

            Initialize(text, caption, buttons, icon, defaultButton, hidesecond);
        }

        // #endregion Construction

        // #region Method : Public Method

        // #region [ Show ]

        public DialogResult Show(MESSAGETYPE msgtype, let ControlName:string = "")
        {
            let HideSec:number = 0;
            let Message:string = String.Empty;
            let Caption:string = String.Empty;
            MessageBoxButtons MsgButtons = MessageBoxButtons.OK;
            MessageBoxIcon MsgIcon = MessageBoxIcon.Information;

            switch (msgtype)
            {
                case MESSAGETYPE.SaveComplete:
                    Message = "저장 되었습니다.";
                    Caption = "확인";
                    MsgButtons = MessageBoxButtons.OK;
                    MsgIcon = MessageBoxIcon.Information;
                    HideSec = 2;
                    break;

                case MESSAGETYPE.SaveFail:
                    Message = "저장에 실패하였습니다.";
                    Caption = "오류";
                    MsgButtons = MessageBoxButtons.OK;
                    MsgIcon = MessageBoxIcon.Error;
                    HideSec = 0;
                    break;

                case MESSAGETYPE.ModifyCheck:
                    Message = "변경된 내역이 있습니다.\r\n계속 진행하시겠습니까?";
                    Caption = "확인";
                    MsgButtons = MessageBoxButtons.YesNo;
                    MsgIcon = MessageBoxIcon.Question;
                    HideSec = 0;
                    break;

                case MESSAGETYPE.RequireInput:
                    Message = String.Format("{0}의 값이 입력되지 않았습니다.\r\n{0}에 값을 입력하여 주십시오!", ControlName);
                    Caption = "확인";
                    MsgButtons = MessageBoxButtons.OK;
                    MsgIcon = MessageBoxIcon.Information;
                    HideSec = 0;
                    break;

                case MESSAGETYPE.ErrorInput:
                    Message = String.Format("{0}의 입력이 잘 못 되었습니다.", ControlName);
                    Caption = "확인";
                    MsgButtons = MessageBoxButtons.OK;
                    MsgIcon = MessageBoxIcon.Information;
                    HideSec = 0;
                    break;

                case MESSAGETYPE.DuplicateInput:
                    Message = String.Format("{0}의 값은 중복으로 입력 될 수 없습니다.", ControlName);
                    Caption = "확인";
                    MsgButtons = MessageBoxButtons.OK;
                    MsgIcon = MessageBoxIcon.Information;
                    HideSec = 0;
                    break;

                case MESSAGETYPE.DuplicateAplyDade:
                    Message = "적용일자가 다른 적용일자와 중복 됩니다.";
                    Caption = "확인";
                    MsgButtons = MessageBoxButtons.OK;
                    MsgIcon = MessageBoxIcon.Information;
                    HideSec = 0;
                    break;

                case MESSAGETYPE.Delete_YN:
                    Message = "삭제 하시겠습니까?";
                    Caption = "확인";
                    MsgButtons = MessageBoxButtons.YesNo;
                    MsgIcon = MessageBoxIcon.Question;
                    HideSec = 0;
                    break;

                case MESSAGETYPE.DeleteSelect_YN:
                    Message = "선택한 정보를 삭제하시겠습니까?";
                    Caption = "확인";
                    MsgButtons = MessageBoxButtons.YesNo;
                    MsgIcon = MessageBoxIcon.Question;
                    HideSec = 0;
                    break;

                case MESSAGETYPE.DeleteNot:
                    Message = "삭제할 내역이 없습니다.";
                    Caption = "확인";
                    MsgButtons = MessageBoxButtons.YesNo;
                    MsgIcon = MessageBoxIcon.Question;
                    HideSec = 0;
                    break;

                default:
                    break;
            }

            return Show(Message, Caption, MsgButtons, MsgIcon, HideSec);
        }

        public DialogResult Show(string text)
        {
            return Show(text, String.Empty);
        }

        public DialogResult Show(string text, string caption)
        {
            return Show(text, caption, MessageBoxButtons.OK);
        }

        public DialogResult Show(string text, string caption, MessageBoxButtons buttons)
        {
            return Show(text, caption, buttons, MessageBoxIcon.None);
        }

        public DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
        {
            return Show(text, caption, buttons, icon, MessageBoxDefaultButton.Button1);
        }

        public DialogResult ShowFromSpread(LxSpread owner, string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
        {
            m_LxMessage = new LxMessage(text, caption, buttons, icon, MessageBoxDefaultButton.Button1);
            return m_LxMessage.ShowDialog(owner);
        }

        public DialogResult ShowWithOwner(Control owner, string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
        {
            if (m_LxMessage != null) // TODO : 메모리 확인
                m_LxMessage.Dispose();

            m_LxMessage = new LxMessage(text, caption, buttons, icon, MessageBoxDefaultButton.Button1);
            return m_LxMessage.ShowDialog(owner);
        }

        public DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton)
        {
            if (m_LxMessage != null) // TODO : 메모리 확인
                m_LxMessage.Dispose();

            m_LxMessage = new LxMessage(text, caption, buttons, icon, defaultButton);
            m_LxMessage.BringToFront();
            m_LxMessage.TopMost = true;
            m_LxMessage.Focus();
            return m_LxMessage.ShowDialog();
        }

        public DialogResult ShowError(string text)
        {
            return Show(text, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public DialogResult ShowError(string text, string caption)
        {
            return Show(text, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public DialogResult ShowWarning(string text)
        {
            return Show(text, "확인", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public DialogResult ShowWarning(string text, string caption)
        {
            return Show(text, caption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public DialogResult ShowInformation(string text)
        {
            return Show(text, "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public DialogResult ShowInformation(string text, string caption)
        {
            return Show(text, caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public DialogResult ShowInformation(string text, int hidesecond)
        {
            return Show(text, "확인", MessageBoxButtons.OK, MessageBoxIcon.Information, hidesecond);
        }

        public DialogResult ShowQuestion(string text)
        {
            return Show(text, "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
        }

        public DialogResult ShowQuestion(string text, string caption)
        {
            return Show(text, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
        }

        public DialogResult ShowQuestion(string text, string caption, MessageBoxButtons buttons)
        {
            return Show(text, caption, buttons, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
        }

        public DialogResult ShowQuestion(string text, string caption, MessageBoxButtons buttons, MessageBoxDefaultButton defaultButton)
        {
            if (m_LxMessage != null) // TODO : 메모리 확인
                m_LxMessage.Dispose();

            m_LxMessage = new LxMessage(text, caption, buttons, MessageBoxIcon.Question, defaultButton);
            return m_LxMessage.ShowDialog();
        }

        // #endregion [ Show ]

        // #region [ Show (hidesecond) ]

        public DialogResult Show(string text, int hidesecond)
        {
            return Show(text, String.Empty, hidesecond);
        }

        public DialogResult Show(string text, string caption, int hidesecond)
        {
            return Show(text, caption, MessageBoxButtons.OK, hidesecond);
        }

        public DialogResult Show(string text, string caption, MessageBoxButtons buttons, int hidesecond)
        {
            return Show(text, caption, buttons, MessageBoxIcon.None, hidesecond);
        }

        public DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, int hidesecond)
        {
            return Show(text, caption, buttons, icon, MessageBoxDefaultButton.Button1, hidesecond);
        }

        public DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, int hidesecond)
        {
            if (m_LxMessage != null) // TODO : 메모리 확인
                m_LxMessage.Dispose();

            hidesecond = buttons != MessageBoxButtons.OK ? 0 : hidesecond;
            m_LxMessage = new LxMessage(text, caption, buttons, icon, defaultButton, hidesecond);
            m_LxMessage.BringToFront();
            m_LxMessage.TopMost = true;
            m_LxMessage.Focus();
            return m_LxMessage.ShowDialog();
        }

        // #endregion [ Show (hidesecond) ]

        // #endregion Method : Public Method

        // #region Method : Initialize Method

        Initialize(text:string, caption:string, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, let hidesecond:number = 0)
        {
            //****************************************************************************************************
            // 메세지 박스 폼 세팅
            //****************************************************************************************************
            this.InitializeForm(text);

            //****************************************************************************************************
            // 메세지 아이콘 이미지 설정
            //****************************************************************************************************
            this.InitializeIconList(icon);

            //****************************************************************************************************
            // 메세지 표시
            //****************************************************************************************************
            this.InitializeText(text, caption);

            //****************************************************************************************************
            // Hide 타이머
            //****************************************************************************************************
            this.InitializeTimer(hidesecond);

            //****************************************************************************************************
            // 버튼 설정
            //****************************************************************************************************
            this.InitializeButton(buttons);

            //****************************************************************************************************
            // 이벤트
            //****************************************************************************************************
            this.InitializeEvent();

            //****************************************************************************************************
            // 포커스
            //****************************************************************************************************
            this.BringToFront();
            this.TopMost = true;
            this.Focus();
        }

        InitializeForm(text:string)
        {
            this.pbxIcon.SizeMode = PictureBoxSizeMode.Zoom;

            this.SizeGripStyle = SizeGripStyle.Hide;
            this.ShowInTaskbar = false;
            this.MinimizeBox = false;
            this.MaximizeBox = false;
            this.ControlBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            /*
            this.Size = new Size(400, 230);
            */
            Size size = GetMessageSize(text);
            this.Size = size;
            this.MaximumSize = size;
            this.MinimumSize = size;

            this.FormBorderStyle = FormBorderStyle.None;
            this.Opacity = 1;
        }

        InitializeIconList(MessageBoxIcon icon)
        {
            try
            {
                MessageBoxIcon ICon = icon.Equals(MessageBoxIcon.None) ? MessageBoxIcon.None :
                                      icon.Equals(MessageBoxIcon.Error) ? MessageBoxIcon.Error :
                                      icon.Equals(MessageBoxIcon.Hand) ? MessageBoxIcon.Error :
                                      icon.Equals(MessageBoxIcon.Stop) ? MessageBoxIcon.Error :
                                      icon.Equals(MessageBoxIcon.Question) ? MessageBoxIcon.Question :
                                      icon.Equals(MessageBoxIcon.Exclamation) ? MessageBoxIcon.Warning :
                                      icon.Equals(MessageBoxIcon.Warning) ? MessageBoxIcon.Warning :
                                      icon.Equals(MessageBoxIcon.Information) ? MessageBoxIcon.Information :
                                      icon.Equals(MessageBoxIcon.Asterisk) ? MessageBoxIcon.Information : icon;

                switch (icon.ToString())
                {
                    case "Error":
                    case "Stop":
                        this.pbxIcon.Image = global::Lime.Framework.Controls.Properties.Resources.Error;
                        break;
                    case "Hand":
                        this.pbxIcon.Image = global::Lime.Framework.Controls.Properties.Resources.Hand;
                        break;
                    case "Question":
                        this.pbxIcon.Image = global::Lime.Framework.Controls.Properties.Resources.Question;
                        break;
                    case "Information":
                    case "Asterisk":
                        this.pbxIcon.Image = global::Lime.Framework.Controls.Properties.Resources.Info;
                        break;
                    case "Exclamation":
                    case "Warning":
                        this.pbxIcon.Image = global::Lime.Framework.Controls.Properties.Resources.Warning;
                        break;

                    case "None":
                    default:
                        this.pbxIcon.Image = null;
                        break;
                }
            }
            catch (ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        InitializeText(text:string, caption:string)
        {
            this.lblMsg.Text = text;
            this.Text = caption;
        }

        InitializeTimer(hidesecond:number)
        {
            m_HideSecond = hidesecond < 1 ? 0 : hidesecond;
            m_HideSecond = (m_HideSecond != 0 && m_HideSecond < 2) ? 2 : m_HideSecond;

            if (m_HideSecond > 0)
            {
                if (m_CloseTimer == null)
                    m_CloseTimer = new Timer();
                m_CloseTimer.Interval = 1000;
                m_CloseTimer.Tick += OnCloseMessageBox;
                m_CloseTimer.Start();
            }
        }

        InitializeButton(MessageBoxButtons buttons)
        {
            LxButton btn;

            switch (buttons)
            {
                case MessageBoxButtons.OK:
                    btn = new LxButton();
                    btn.Name = "OK";
                    btn.Text = "확 인(O)";
                    btn.Size = new Size(m_ButtonWidth, m_ButtonHeight);
                    btn.Location = this.GetButtonLocation(1, 1);
                    btn.Click += this.OnButton_Click;
                    btn.KeyDown += this.OnButton_KeyDown;
                    this.pnlButton.Controls.Add(btn);
                    btn.BringToFront();
                    break;

                case MessageBoxButtons.OKCancel:
                    btn = new LxButton();
                    btn.Name = "OK";
                    btn.Text = "확 인(O)";
                    btn.Size = new Size(m_ButtonWidth, m_ButtonHeight);
                    btn.Location = this.GetButtonLocation(2, 1);
                    btn.Click += this.OnButton_Click;
                    btn.KeyDown += this.OnButton_KeyDown;
                    this.pnlButton.Controls.Add(btn);
                    btn.BringToFront();
                    btn = new LxButton();
                    btn.Name = "Cancel";
                    btn.Text = "취 소(C)";
                    btn.Size = new Size(m_ButtonWidth, m_ButtonHeight);
                    btn.Location = this.GetButtonLocation(2, 2);
                    btn.Click += this.OnButton_Click;
                    btn.KeyDown += this.OnButton_KeyDown;
                    this.pnlButton.Controls.Add(btn);
                    btn.BringToFront();
                    break;

                case MessageBoxButtons.YesNo:
                    btn = new LxButton();
                    btn.Name = "Yes";
                    btn.Text = "예(Y)";
                    btn.Size = new Size(m_ButtonWidth, m_ButtonHeight);
                    btn.Location = this.GetButtonLocation(2, 1);
                    btn.Click += this.OnButton_Click;
                    btn.KeyDown += this.OnButton_KeyDown;
                    this.pnlButton.Controls.Add(btn);
                    btn.BringToFront();
                    btn = new LxButton();
                    btn.Name = "No";
                    btn.Text = "아니오(N)";
                    btn.Size = new Size(m_ButtonWidth, m_ButtonHeight);
                    btn.Location = this.GetButtonLocation(2, 2);
                    btn.Click += this.OnButton_Click;
                    btn.KeyDown += this.OnButton_KeyDown;
                    this.pnlButton.Controls.Add(btn);
                    btn.BringToFront();
                    break;

                case MessageBoxButtons.YesNoCancel:
                    btn = new LxButton();
                    btn.Name = "Yes";
                    btn.Text = "예(Y)";
                    btn.Size = new Size(m_ButtonWidth, m_ButtonHeight);
                    btn.Location = this.GetButtonLocation(3, 1);
                    btn.Click += this.OnButton_Click;
                    btn.KeyDown += this.OnButton_KeyDown;
                    this.pnlButton.Controls.Add(btn);
                    btn.BringToFront();
                    btn = new LxButton();
                    btn.Name = "No";
                    btn.Text = "아니오(N)";
                    btn.Size = new Size(m_ButtonWidth, m_ButtonHeight);
                    btn.Location = this.GetButtonLocation(3, 2);
                    btn.Click += this.OnButton_Click;
                    btn.KeyDown += this.OnButton_KeyDown;
                    this.pnlButton.Controls.Add(btn);
                    btn.BringToFront();
                    btn = new LxButton();
                    btn.Name = "Cancel";
                    btn.Text = "취 소(C)";
                    btn.Size = new Size(m_ButtonWidth, m_ButtonHeight);
                    btn.Location = this.GetButtonLocation(3, 3);
                    btn.Click += this.OnButton_Click;
                    btn.KeyDown += this.OnButton_KeyDown;
                    this.pnlButton.Controls.Add(btn);
                    btn.BringToFront();
                    break;

                default:
                    break;
            }
        }

        InitializeEvent()
        {
            this.lblMsg.KeyDown += this.OnlblMsg_KeyDown;
        }

        // #endregion Method : Initialize Method

        // #region Method : Private Method

        private Point GetButtonLocation(int buttoncount, int rank)
        {
            let X:number = 0;
            let Y:number = 0;
            let ButtonWidth:number = 0;
            Point ButtonLocation = new Point();
            Size ButtonPanelRectangle = this.pnlButton.Size;

            Y = (ButtonPanelRectangle.Height - m_ButtonHeight) / 2;

            ButtonWidth = (buttoncount == 2) ? (m_ButtonWidth * buttoncount) + 10 :
                          (buttoncount == 3) ? (m_ButtonWidth * buttoncount) + 10 : m_ButtonWidth;

            X = (ButtonPanelRectangle.Width / 2) - (ButtonWidth / 2);

            X = (rank == 2) ? X + (m_ButtonWidth) + 10 :
                (rank == 3) ? X + (m_ButtonWidth * 2) + 20 : X;

            ButtonLocation.X = X;
            ButtonLocation.Y = Y;

            return ButtonLocation;
        }

        private Size GetMessageSize(string Message)
        {
            // 200 : form  height
            // 112 : label height

            let defaultHeihgt:number = 112;
            // lblMsg.Width = 324 였는데 오송 (625900141) 코드 심사지침 메시지가 처방창에서 제대로 열리지 않아서 -10으로 fix함
            //let height:number = (int)lblMsg.CreateGraphics().MeasureString(Message, new System.Drawing.Font("맑은 고딕", 9), lblMsg.Width, StringFormat.GenericTypographic).Height;
            let height:number = (int)lblMsg.CreateGraphics().MeasureString(Message, new System.Drawing.Font("맑은 고딕", 9), lblMsg.Width - 10, StringFormat.GenericTypographic).Height;
            if (height < defaultHeihgt)
            {
                height = defaultHeihgt;
                lblMsg.Appearance.TextVAlign = Infragistics.Win.VAlign.Middle;
            }
            else
            {
                lblMsg.Appearance.TextVAlign = Infragistics.Win.VAlign.Top;
            }

            height += 100;

            return new Size(this.Width, height);

            // TODO : 텍스트 사이즈

            //Graphics g = LxMessage.CreateGraphics();
            //let width:number = 500;
            //let height:number = 230;

            //SizeF size = g.MeasureString(Message.Trim(), new System.Drawing.Font("굴림", 9));

            //if (Message.Length < 150)
            //{
            //    if ((int)size.Width > 500)
            //    {
            //        width = (int)size.Width;
            //    }
            //}
            //else
            //{
            //    string[] groups = (from Match m in Regex.Matches(Message.Trim(), ".{1,180}") select m.Value).ToArray();
            //    let lines:number = groups.Length + 1;
            //    let iOneLineH:number = 15;

            //    width = 700;

            //    if (lines > 0)
            //    {
            //        height += (iOneLineH * lines) + 10; // 총 높이 = 기본높이 + (한라인 높이 * 라인수) + 여유분
            //    }
            //    else
            //    {
            //        height += (int)size.Height;
            //    }                         
            //}

            //return new Size(width, height);
        }

        FindButton(Control ctrl, keyName:string)
        {
            try
            {
                foreach (Control x in ctrl.Controls)
                {
                    if (x is LxButton btn)
                        if ((btn.Name ?? "").Length > 0)
                            if (btn.Name.Substring(0, 1).Equals(keyName))
                                btn.PerformClick();

                    if (x.HasChildren)
                        FindButton(x, keyName);
                }
            }
            catch
            {
            }
        }
        // #endregion Method : Private Method

        // #region Event : Event Process

        OnCloseMessageBox(sender:object, e)
        {
            m_ElapseTime++;
            this.SuspendLayout();
            this.Opacity = this.Opacity - 0.1;
            this.Refresh();
            this.ResumeLayout();

            if (m_ElapseTime >= m_HideSecond)
            {
                m_CloseTimer.Stop();
                m_CloseTimer.Enabled = false;

                this.DialogResult = DialogResult.OK;
            }
        }

        OnButton_Click(sender:object, e)
        {
            if (m_CloseTimer != null && m_CloseTimer.Enabled)
            {
                m_CloseTimer.Enabled = false;
                m_CloseTimer.Stop();
            }

            switch (((LxButton)sender).Name)
            {
                case "OK":
                    this.DialogResult = DialogResult.OK;
                    break;

                case "Yes":
                    this.DialogResult = DialogResult.Yes;
                    break;

                case "No":
                    this.DialogResult = DialogResult.No;
                    break;

                case "Cancel":
                    this.DialogResult = DialogResult.Cancel;
                    break;

                default:
                    this.DialogResult = DialogResult.Cancel;
                    break;
            }
        }

        OnButton_KeyDown(sender:object, KeyEventArgs e)
        {
            if (e.KeyData == (Keys.Control | Keys.C))
            {
                this.ProcessDialogKey(Keys.Control | Keys.C);
            }
            else if (e.KeyData == Keys.O || e.KeyData == Keys.Y || e.KeyData == Keys.N || e.KeyData == Keys.C)
            {
                ProcessDialogKey(e.KeyData);
            }
        }

        OnlblMsg_KeyDown(sender:object, KeyEventArgs e)
        {
            if (e.KeyData == (Keys.Control | Keys.C))
            {
                this.ProcessDialogKey(Keys.Control | Keys.C);
            }
            else if (e.KeyData == Keys.O || e.KeyData == Keys.Y || e.KeyData == Keys.N || e.KeyData == Keys.C)
            {
                ProcessDialogKey(e.KeyData);
            }
        }

        // #endregion Event : Event Process

        // #region Event : Raise Event

        ProcessDialogKey(Keys keyData)
        {
            if (keyData == (Keys.Control | Keys.C))
            {
                Clipboard.SetText(this.lblMsg.Text);
            }
            else if (keyData == Keys.O || keyData == Keys.Y || keyData == Keys.N || keyData == Keys.C)
            {
                if (m_LxMessage != null)
                    FindButton(m_LxMessage, keyData.ToString());
            }

            return base.ProcessDialogKey(keyData);
        }

        // #endregion Event : Raise Event
    }
}
