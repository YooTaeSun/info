package web.townsi.com.work.convert.doc;

import java.util.List;
import java.util.Map;

import web.townsi.com.utils.Util;

public class DocImport {
	
	public static String IMPORT_START_STR = "// import start";

	public static boolean contains(String content, String s) {
		if (content.contains(s) || content.contains(":"+Util.lTrim(s)) || content.contains("("+ Util.lTrim(s)) || content.contains("!"+ Util.lTrim(s))) {
			return true;
		} else {
			return false;	
		}
	}
	
	public static String addImport(String content, String docType, List<String> formCompList, String initCompStr, String designVeri, String tagStr, Map<String, String> variMap) {
		StringBuilder importSb = new StringBuilder();
		StringBuilder startSb = new StringBuilder();
		StringBuilder controlsSb = new StringBuilder();
		StringBuilder endSb = new StringBuilder();
		
		String docType2 = "";
		
		if (docType.equals("POP")) {
			docType = "VUE";
			docType2 = "POP";
		}

		if (docType.equals("VUE")) {
			if (docType2.equals("POP")) {
				importSb.append("import { ref, reactive, onMounted, defineExpose, computed, getCurrentInstance } from \"vue\";" + "\r\n");
			} else {
				importSb.append("import { ref, reactive, onMounted, defineExpose, computed } from \"vue\";" + "\r\n");	
			}
			
			importSb.append("import { $ref, $computed } from 'vue/macros'" + "\r\n");
		}

		//framework

		if (DocImport.contains(content," DateTime.")) {
			importSb.append("import { DateTime } from \"@/app/framework/CommonService/DateTime\";" + "\r\n");
		}

		// ------------------------------- 	app/framework/DataType/ start -------------------------------		
		if (DocImport.contains(content," DataTable") 
				|| DocImport.contains(content," DataColumn")
				|| DocImport.contains(content," DataColumnCollection ")
				
					) {
				
			String is = "";
			if (DocImport.contains(content," DataTable")) {is = is + ", DataTable";}
			if (DocImport.contains(content," DataColumn")) {is = is + ", DataColumn";}
			if (DocImport.contains(content," DataColumnCollection ")) {is = is + ", DataColumnCollection";}
			
			is = is.replaceFirst(", ", "");
			importSb.append("import { "+ is +" } from \"@/app/framework/DataType/DataTable\";" + "\r\n");
		}
		
		
		if (DocImport.contains(content," DataType.")) {
			importSb.append("import { DataType } from \"@/app/framework/DataType/DataType\";" + "\r\n");
		}
		
		if (DocImport.contains(content," HOSPITAL_SIGN_TYPE.") 
				|| DocImport.contains(content," COMBO_ADD_ITEM_TYPE.") 
				|| DocImport.contains(content," EMR_DATAFIELD_TYPE.")
				|| DocImport.contains(content," CRUD_TYPE.")
					) {
				
			String is = "";
			if (DocImport.contains(content," HOSPITAL_SIGN_TYPE.")) {is = is + ", HOSPITAL_SIGN_TYPE";}
			if (DocImport.contains(content," COMBO_ADD_ITEM_TYPE.")) {is = is + ", COMBO_ADD_ITEM_TYPE";}
			if (DocImport.contains(content," EMR_DATAFIELD_TYPE.")) {is = is + ", EMR_DATAFIELD_TYPE";}
			if (DocImport.contains(content," CRUD_TYPE.")) {is = is + ", CRUD_TYPE";}
			
			is = is.replaceFirst(", ", "");
			importSb.append("import { "+ is +" } from \"@/app/framework/DataType/PublicEnum\";" + "\r\n");
		}
		
		if (DocImport.contains(content," SheetView.")) {
			importSb.append("import { SheetView } from \"@/app/framework/DataType/SheetView\";" + "\r\n");
		}
		if (DocImport.contains(content," CellType.")) {
			importSb.append("import { CellType } from \"@/app/framework/DataType/CellType\";" + "\r\n");
		}
//		if (DocImport.contains(content," StringCollection.")) {
		if (content.contains("StringCollection")) {
			importSb.append("import { StringCollection } from \"@/app/framework/DataType/StringCollection\";" + "\r\n");
		}
		// ------------------------------- 	app/framework/DataType/ end -------------------------------


		if (DocImport.contains(content," DOPack.")) {
			importSb.append("import { DOPack } from \"@/app/framework/DataObject/DOPack\";" + "\r\n");
		}
		
		if (DocImport.contains(content," DOPatientInfo")) {
			importSb.append("import { DOPatientInfo } from \"@/app/framework/DataObject/DOPatientInfo\";" + "\r\n");
		}
		if (DocImport.contains(content," DOHospitalInfo")) {
			importSb.append("import { DOHospitalInfo } from \"@/app/framework/DataObject/DOHospitalInfo\";" + "\r\n");
		}
		if (DocImport.contains(content," DOUserInfo")) {
			importSb.append("import { DOUserInfo } from \"@/app/framework/DataObject/DOUserInfo\";" + "\r\n");
		}
		
		if (DocImport.contains(content," DBService.")) {
			importSb.append("import { DBService } from \"@/app/framework/DBService/DBService\";" + "\r\n");
		}

		if (DocImport.contains(content," ConfigService.")) {
			importSb.append("import { ConfigService } from \"@/app/framework/ConfigService/ConfigService\";" + "\r\n");
		}
		if (DocImport.contains(content," StringService.")) {
			importSb.append("import { StringService } from \"@/app/framework/CommonService/StringService\";" + "\r\n");
		}
		if (DocImport.contains(content," DateTimeService.")) {
			importSb.append("import { DateTimeService } from \"@/app/framework/CommonService/DateTimeService\";" + "\r\n");
		}
		if (DocImport.contains(content," LogService.")) {
			importSb.append("import { LogService } from \"@/app/framework/CommonService/LogService\";" + "\r\n");
		}
		if (DocImport.contains(content," ClientService.")) {
			importSb.append("import { ClientService } from \"@/app/framework/CommonService/ClientService\";" + "\r\n");
		}
		if (DocImport.contains(content," NetworkService.")) {
			importSb.append("import { NetworkService } from \"@/app/framework/CommonService/NetworkService\";" + "\r\n");
		}
		if (DocImport.contains(content," EncryptionService.")) {
			importSb.append("import { EncryptionService } from \"@/app/framework/CommonService/EncryptionService\";" + "\r\n");
		}
		if (DocImport.contains(content," Math.")) {
			importSb.append("import \"@/app/utils/Math.extensions\"\";" + "\r\n");
		}

		// class 형

		if (DocImport.contains(content," ScreenParameters(")) {
			importSb.append("import { ScreenParameters } from \"@/app/framework/BaseForms/TypeClass/SreenParameters\";"+ "\r\n");
		}

		if (DocImport.contains(content," DeptList.")) {
			importSb.append("import { DeptList } from \"@/app/framework/DataService/DeptList\";" + "\r\n");
		}
		if (DocImport.contains(content," UserList.")) {
			importSb.append("import { UserList } from \"@/app/framework/DataService/UserList\";" + "\r\n");
		}
		
		if (DocImport.contains(content," DoctorList.")) {
			importSb.append("import { DoctorList } from \"@/app/framework/DataService/DoctorList\";" + "\r\n");
		}
		if (DocImport.contains(content," OverallCodeList.")) {
			importSb.append("import { OverallCodeList } from \"@/app/framework/DataService/OverallCodeList\";" + "\r\n");
		}
		if (DocImport.contains(content," ClinicList.")) {
			importSb.append("import { ClinicList } from \"@/app/framework/DataService/ClinicList\";" + "\r\n");
		}
		if (DocImport.contains(content," ButtonType")) {
			importSb.append("import { ButtonType } from \"@/app/framework/Controls/TypeClass/ButtonList/ButtonType\";" + "\r\n");
		}
		if (DocImport.contains(content," clsNhisM1")) {
			importSb.append("import { clsNhisM1 } from \"@/app/framework/BusinessService/Nhis/clsNhisM1\";" + "\r\n");
		}
		if (DocImport.contains(content," clsNhisM2")) {
			importSb.append("import { clsNhisM2 } from \"@/app/framework/BusinessService/Nhis/clsNhisM2\";" + "\r\n");
		}
		if (DocImport.contains(content," clsNhisM3")) {
			importSb.append("import { clsNhisM3 } from \"@/app/framework/BusinessService/Nhis/clsNhisM3\";" + "\r\n");
		}
		if (DocImport.contains(content," clsNhisM4")) {
			importSb.append("import { clsNhisM4 } from \"@/app/framework/BusinessService/Nhis/clsNhisM4\";" + "\r\n");
		}
		if (DocImport.contains(content," clsNhisM5")) {
			importSb.append("import { clsNhisM5 } from \"@/app/framework/BusinessService/Nhis/clsNhisM5\";" + "\r\n");
		}if (DocImport.contains(content," clsNhisM6")) {
			importSb.append("import { clsNhisM6 } from \"@/app/framework/BusinessService/Nhis/clsNhisM6\";" + "\r\n");
		}
		if (DocImport.contains(content," clsNhisDB.")) {
			importSb.append("import { clsNhisDB } from \"@/app/framework/BusinessService/Nhis/clsNhisDB\";" + "\r\n");
		}
		if (DocImport.contains(content," ORBizCommon.")) {
			importSb.append("import { ORBizCommon } from \"@/app/framework/BusinessService/ORBizCommon\";" + "\r\n");
		}
		if (DocImport.contains(content," clsCommon")) {
			importSb.append("import { clsCommon } from \"@/app/framework/BusinessControls/Common/clsCommon\";" + "\r\n");
		}
		if (DocImport.contains(content," Function")) {
			importSb.append("import { Function } from \"@/app/framework/SqlPack/Function/Function\";" + "\r\n");
		}
		

		if (DocImport.contains(content," Procedure")) {
			importSb.append("import { Procedure } from \"@/app/framework/SqlPack/Procedure/Procedure\";" + "\r\n");
		}
		// ------------------------------- 	app/utils/ start -------------------------------
		if (DocImport.contains(content," Int.")) {
			importSb.append("import { Int } from \"@/app/utils/Int\";" + "\r\n");
		}
		if (DocImport.contains(content," double.")) {
			importSb.append("import { double } from \"@/app/utils/double.extensions\";" + "\r\n");
		}
		if (DocImport.contains(content," decimal.")) {
			importSb.append("import { decimal } from \"@/app/utils/decimal.extensions\";" + "\r\n");
		}
		
		if (DocImport.contains(content," Convert.")) {
			importSb.append("import { Convert } from \"@/app/utils/convert\";" + "\r\n");
		}
		if (DocImport.contains(content," MessageBoxButtons.")) {
			importSb.append("import { MessageBoxButtons } from \"@/app/utils/MessageBoxButtons\";" + "\r\n");
		}
		if (DocImport.contains(content," MessageBoxIcon.")) {
			importSb.append("import { MessageBoxIcon } from \"@/app/utils/MessageBoxIcon\";" + "\r\n");
		}
		if (DocImport.contains(content," DialogResult.")) {
			importSb.append("import { DialogResult } from \"@/app/utils/DialogResult\";" + "\r\n");
		}
		if (DocImport.contains(content," new clsSevereDiseaseInfo(")) {
			importSb.append("import { clsSevereDiseaseInfo } from \"@/modules/n_pa/views/CommonClass/clsSevereDiseaseInfo\";" + "\r\n");
		}
		if (DocImport.contains(content," new clsOutRegistrationInfo(")) {
			importSb.append("import { clsOutRegistrationInfo } from \"@/modules/n_pa/views/CommonClass/clsOutRegistrationInfo\";" + "\r\n");
		}
		if (DocImport.contains(content," new clsPastRegistrationInfo(")) {
			importSb.append("import { clsPastRegistrationInfo } from \"@/modules/n_pa/views/CommonClass/clsPastRegistrationInfo\";" + "\r\n");
		}
		// ------------------------------- 	app/utils/ end -------------------------------
		
		if (DocImport.contains(content," clsPACommon.")) {
			importSb.append("import { clsPACommon } from \"@/modules/n_pa/views/CommonClass/clsPACommon\";" + "\r\n");
		}
		if (DocImport.contains(content," clsUncollectedDpstInfo")) {
			importSb.append("import { clsUncollectedDpstInfo } from \"@/modules/n_pa/views/CommonClass/clsUncollectedDpstInfo\";" + "\r\n");
		}
		if (DocImport.contains(content," clsCardCashPermitInfo")) {
			importSb.append("import { clsCardCashPermitInfo } from \"@/modules/n_pa/views/CommonClass/clsCardCashPermitInfo\";" + "\r\n");
		}		
		if (DocImport.contains(content," clsTraiLimitInfo")) {
			importSb.append("import { clsTraiLimitInfo } from \"@/modules/n_pa/views/CommonClass/clsTraiLimitInfo\";" + "\r\n");
		}		
		if (DocImport.contains(content," clsOutReceiptBreakDown")) {
			importSb.append("import { clsOutReceiptBreakDown } from \"@/modules/n_pa/views/CommonClass/clsOutReceiptBreakDown\";" + "\r\n");
		}		
		
		
		if (DocImport.contains(content," clsPatientRemark")) {
			importSb.append("import { clsPatientRemark } from \"@/modules/n_pa/views/CommonClass/clsPatientRemark\";" + "\r\n");
		}
		if (DocImport.contains(content," clsOutBillBreakdown")) {
			importSb.append("import { clsOutBillBreakdown } from \"@/modules/n_pa/views/CommonClass/clsOutBillBreakdown\";" + "\r\n");
		}
		if (DocImport.contains(content," clsOutBillTemp")) {
			importSb.append("import { clsOutBillTemp } from \"@/modules/n_pa/views/CommonClass/clsOutBillTemp\";" + "\r\n");
		}

		
		
		if (DocImport.contains(content," ucMedicalReceipt(")) {
			importSb.append("import { ucMedicalReceipt } from \"@/app/framework/BusinessControls/Report/ucMedicalReceipt\";" + "\r\n");
		}

		if (DocImport.contains(content," BizCommon.")) {
			importSb.append("import { BizCommon } from \"@/app/utils/BizCommon\";" + "\r\n");
		}
		if (DocImport.contains(content," PABizCommon.")) {
			importSb.append("import { PABizCommon } from \"@/app/utils/PABizCommon\";" + "\r\n");
		}
		if (DocImport.contains(content," clsBICommon.")) {
			importSb.append("import { clsBICommon } from \"@/modules/n_bi/views/CommonClass/clsBICommon\";" + "\r\n");
		}
		if (DocImport.contains(content," clsPACheckCommon.")) {
			importSb.append("import { clsPACheckCommon } from \"@/modules/n_bi/views/CommonClass/clsPACheckCommon\";" + "\r\n");
		}

		
		if (docType.equals("VUE")) {
			// --------------  importSb VUE
			if (DocImport.contains(content," LxMessage.")) {
				importSb.append("import LxMessageComp from \"@/app/framework/Controls/LxMessage/_index.vue\";" + "\r\n");
			}
		}
		//--------------  importSb 

		if (DocImport.contains(content," LxProgressMessage.")) {
			importSb.append("import { LxProgressMessage } from \"@/app/utils/LxProgressMessage\";" + "\r\n");
		}
		
		if (DocImport.contains(content," UnLockSystem") || DocImport.contains(content," SaveActionLog")) {
			importSb.append("import { useBaseUCF } from \"@/app/framework/BaseForms/BaseUCF\";" + "\r\n");
		}
		if (DocImport.contains(content," Keys.")) {
			importSb.append("import Keys = System.Windows.Forms.Keys;" + "\r\n");
		}
		if (DocImport.contains(content," DockStyle.")) {
			importSb.append("import DockStyle = System.Windows.Forms.DockStyle;" + "\r\n");
		}
		if (DocImport.contains(content," Color.")) {
			importSb.append("import Color = System.Drawing.Color;" + "\r\n");
		}
		if (DocImport.contains(content," Font.")) {
			importSb.append("import Font = System.Drawing.Font;" + "\r\n");
		}
//		if (DocImport.contains(content," FontStyle.")) {
//			importSb.append("import FontStyle = System.Drawing.FontStyle;" + "\r\n");
//		}
		if (DocImport.contains(content," Size,") || DocImport.contains(content," Size(")) {
			importSb.append("import Size = System.Drawing.Size;" + "\r\n");
		}
		if (importSb.toString().contains(" System.") ||DocImport.contains(content," System.") || DocImport.contains(content," System.") ) {
			importSb.append("import { System } from \"@/app/utils/System\";" + "\r\n");
		}
		if (importSb.toString().contains(" DialogResult.") ||DocImport.contains(content," DialogResult.") || DocImport.contains(content," DialogResult.") ) {
			importSb.append("import { DialogResult } from \"@/app/utils/DialogResult\";" + "\r\n");
		}
				
		// --------------  소스코드
		if (docType.equals("VUE")) {
			
			if (!designVeri.isEmpty()) {
				startSb.append("\r\n");
				startSb.append(designVeri);
			}
			
			// --------------  소스코드
			startSb.append("\r\n");
			
			String controlsStr = makeControlsStr(variMap);
			if (controlsStr.length() > 0) {
				controlsStr = "  Controls = [\r\n" + controlsStr.substring(1) + "];\r\n";
			}
			
			if (docType2.equals("POP")) {
				startSb.append("/* Life Cycles */\r\n" + "onMounted(() => {\r\n"
						+ "  instance.value = getCurrentInstance();\r\n"
						+ "  Caption.value = '제목';\r\n"
						+ "  ClientSize.value = { width: 1238, height: 1000 };\r\n"
						+ "  InitializeComponent();\r\n");
				
				if (controlsStr.length() > 0) {
					startSb.append(controlsStr);
				}
				startSb.append("  OnLoad();\r\n" + "});\r\n");
				
				startSb.append("let m_DialogResult = DialogResult.OK;\r\n"
						+ "let { Caption, ClientSize } = useBasePopUp_TP();\r\n"
						+ "\r\n"
						+ "const instance = ref(null);\r\n"
						+ "//클로즈만 할때\r\n"
						+ "const ClosePopup = () => {\r\n"
						+ "  //셀 더블 클릭하지 않고 폼 닫을 때,\r\n"
						+ "  const { hidePopup } = usePopup();\r\n"
						+ "  hidePopup(instance.value, DialogResult.Cancel);\r\n"
						+ "};\r\n"
						+ "\r\n"
						+ "const Close = () => {\r\n"
						+ "  //셀 더블 클릭하지 않고 폼 닫을 때,\r\n"
						+ "  const { hidePopup } = usePopup();\r\n"
						+ "  hidePopup(instance.value, m_DialogResult);\r\n"
						+ "};\r\n"
						+ "\r\n"
						+ "const ShowDialog = async () => {\r\n"
						+ "  const { showPopup } = usePopup();\r\n"
						+ "  return await showPopup(instance.value);\r\n"
						+ "};\r\n"
						+ "\r\n"
						+ "const getKey = () => {\r\n"
						+ "  if (instance.value) {\r\n"
						+ "    return instance.value.uid;\r\n"
						+ "  }\r\n"
						+ "  return \"\";\r\n"
						+ "};\r\n\r\n");
				
			} else {
				startSb.append("/* Life Cycles */\r\n" + "onMounted(() => {\r\n" + "  InitializeComponent();\r\n");
				if (controlsStr.length() > 0) {
					startSb.append(controlsStr);
				}
				startSb.append("  OnLoad();\r\n" + "});\r\n");				
			}
			
			endSb.append("/* Expose */\r\n" + "defineExpose({ });\r\n" + "</script>\r\n\r\n");
			
			endSb.append("<template>\r\n");
			if (docType2.equals("POP")) {
				endSb.append("<PopupTemplate :Key=\"getKey()\" :ClientSize=\"ClientSize\" :Caption=\"Caption\">\r\n");
				endSb.append("</PopupTemplate>\r\n\r\n");
			}
			if (!tagStr.isEmpty()) {
				endSb.append(tagStr);
			}
			endSb.append("</template>\r\n");
			
			if (!initCompStr.isEmpty()) {
				
				if (initCompStr.contains("InitializeComponent()")) {
					initCompStr = initCompStr.replace("InitializeComponent()", "const InitializeComponent = () => ");	
				} else {
					startSb.append("const InitializeComponent = () => {\r\n" + initCompStr + "}\r\n");	
				}
			} else {
				startSb.append("\r\n");
				startSb.append("const InitializeComponent = () => {\r\n" + "}\r\n");	
			}
		}
		
		if (DocImport.contains(content," UnLockSystem") || DocImport.contains(content," SaveActionLog")) {
			startSb.append("\r\n");
			if (DocImport.contains(content," UnLockSystem") && DocImport.contains(content," SaveActionLog")) {
				startSb.append("const { UnLockSystem, SaveActionLog } = useBaseUCF();" + "\r\n");	
			} else if (DocImport.contains(content," UnLockSystem")) {
				startSb.append("const { UnLockSystem } = useBaseUCF();" + "\r\n");
			} else if (DocImport.contains(content," SaveActionLog")) {
				startSb.append("const { SaveActionLog } = useBaseUCF();" + "\r\n");
			}
		}
		
		if (docType.equals("VUE")) {
			String nType = "";
			if (formCompList != null && formCompList.size() > 0) {
				
				for (String fromComp : formCompList) {
					if (fromComp.equals("LxSpread")) {
						importSb.append("import LxSpread from \"@/app/framework/Controls/LxSpread/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("SheetView")) {
						importSb.append("import { SheetView } from \"@/app/framework/DataType/SheetView\";" + "\r\n");
					} else if (fromComp.equals("LxTitleLabel")) {
						importSb.append("// import LxTitleLabel from \"@/app/framework/Controls/LxTitleLabel/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxTextBox")) {
						importSb.append("import LxTextBox from \"@/app/framework/Controls/LxTextBox/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxComboBox")) {
						importSb.append("import LxComboBox from \"@/app/framework/Controls/LxComboBox/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxLabel")) {
						importSb.append("import LxLabel from \"@/app/framework/Controls/LxLabel/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxDoctorListCombo")) {
						importSb.append("import LxDoctorListCombo from \"@/app/framework/Controls/LxDoctorListCombo/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxMaskedEdit")) {
						importSb.append("import LxMaskedEdit from \"@/app/framework/Controls/LxMaskedEdit/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxTitlePanel")) {
						importSb.append("// import LxTitlePanel from \"@/app/framework/Controls/LxTitlePanel/index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxPanel")) {
						importSb.append("// import LxPanel from \"@/app/framework/Controls/LxPanel/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxClinicCombo")) {
						importSb.append("import LxClinicCombo from \"@/app/framework/Controls/LxClinicCombo/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxDeptCombo")) {
						importSb.append("import LxDeptCombo from \"@/app/framework/Controls/LxDeptCombo/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxLoginUserDeptCombo")) {
						importSb.append("import LxLoginUserDeptCombo from \"@/app/framework/Controls/LxLoginUserDeptCombo/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxLoginUserDeptListBox")) {
						importSb.append("import LxLoginUserDeptListBox from \"@/app/framework/Controls/LxLoginUserDeptListBox/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxOverallCombo")) {
						importSb.append("import LxOverallCombo from \"@/app/framework/Controls/LxComboBox/LxOverallCombo.vue\";" + "\r\n");
					} else if (fromComp.equals("LxRoomCombo")) {
						importSb.append("import LxRoomCombo from \"@/app/framework/Controls/LxRoomCombo/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxSlipCombo")) {
						importSb.append("import LxSlipCombo from \"@/app/framework/Controls/LxSlipCombo/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxUserListCombo")) {
						importSb.append("import LxUserListCombo from \"@/app/framework/Controls/LxUserListCombo/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxWardCombo")) {
						importSb.append("import LxWardCombo from \"@/app/framework/Controls/LxWardCombo/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxCheckBox")) {
						importSb.append("import LxCheckBox from \"@/app/framework/Controls/LxCheckBox/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxButton")) {
						importSb.append("import LxButton from \"@/app/framework/Controls/LxButton/_index.vue\";" + "\r\n");						
					} else if (fromComp.equals("System") && !importSb.toString().contains("{ System }")) {
						importSb.append("import { System } from \"@/app/utils/System\";" + "\r\n");
					} else if (fromComp.equals("CellType") && !importSb.toString().contains("{ CellType }")) {
						importSb.append("import { CellType } from \"@/app/framework/DataType/CellType\";" + "\r\n");
					} else if (fromComp.equals("DockStyle") && !importSb.toString().contains("{ DockStyle }")) {
						importSb.append("import DockStyle = System.Windows.Forms.DockStyle;" + "\r\n");
					} else if (fromComp.equals("LxSpread") && !importSb.toString().contains("{ LxSpread }")) {
						importSb.append("import LxSpread from \"@/app/framework/Controls/LxSpread/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("COMBO_ADD_ITEM_TYPE")) {
						importSb.append("import { COMBO_ADD_ITEM_TYPE } from \"@/app/framework/DataType/PublicEnum\";" + "\r\n");
					} else if (fromComp.equals("LxDateTimeEditor") || fromComp.equals("LxDateTimePicker")) {
//						importSb.append("import LxDateTimeEditor from \"@/app/framework/Controls/LxDateTimeEditor/_index.vue\";" + "\r\n");
						importSb.append("import LxDateTimePicker from \"@/app/framework/Controls/LxDateTimePicker/_index.vue\";" + "\r\n");
					} else if (fromComp.equals("LxButtonList")) {
						importSb.append("import { LxButtonList } from \"@/app/framework/Controls/LxButtonList/_index.vue\";" + "\r\n");
					}
				}
			}
			
			//POP일때 import
			if (docType2.equals("POP")) {
				importSb.append("import { usePopup } from \"@/app/utils/usePopup\";" + "\r\n");
				importSb.append("import { useBasePopUp_TP } from \"@/app/framework/BaseForms/BasePopUp_TP\";" + "\r\n");
				importSb.append("import PopupTemplate from \"@/app/components/Popup/PopupTemplate.vue\";" + "\r\n");
			}			
		}
		
		// 내용에 LxSpread가 있으면 
		if (DocImport.contains(content," LxSpread") && !importSb.toString().contains(" LxSpread ")) {
			importSb.append("import LxSpread from \"@/app/framework/Controls/LxSpread/_index.vue\";" + "\r\n");
		}
		
		// 내용에 SheetView가 있으면 
		if (DocImport.contains(content," SheetView") && !importSb.toString().contains(" SheetView ")) {
			importSb.append("import { SheetView } from \"@/app/framework/DataType/SheetView\";" + "\r\n");
		}
		
		if (DocImport.contains(content," clsPAReceiptInfo") && !importSb.toString().contains(" clsPAReceiptInfo ")) {
			importSb.append("import { clsPAReceiptInfo } from \"@/app/services/BusinessControls/pa/interface/clsPAReceiptInfo\";" + "\r\n");
		}
		
		if (DocImport.contains(content," clsPAReceiptInfo") && !importSb.toString().contains(" clsPAReceiptInfo ")) {
			importSb.append("import { clsPAReceiptInfo } from \"@/app/services/BusinessControls/pa/interface/clsPAReceiptInfo\";" + "\r\n");
		}
		
		String importContent = importSb.toString();
		
//		initCompStr importSb
		
		if (DocImport.contains(content," CELLTYPE.") || DocImport.contains(initCompStr," CELLTYPE.") 
				|| DocImport.contains(content," CELL_HALIGNMENT.") || DocImport.contains(initCompStr," CELL_HALIGNMENT.")
				|| DocImport.contains(content," CELL_VALIGNMENT.") || DocImport.contains(initCompStr," CELL_VALIGNMENT.")
				|| DocImport.contains(content," DATETIME_TYPE.") || DocImport.contains(initCompStr," DATETIME_TYPE.")
				|| DocImport.contains(content," CellHorizontalAlignment.") || DocImport.contains(initCompStr," CellHorizontalAlignment.")
				|| DocImport.contains(content," CellVerticalAlignment.") || DocImport.contains(initCompStr," CellVerticalAlignment.")
				|| DocImport.contains(content," VerticalPosition.") || DocImport.contains(initCompStr," VerticalPosition.")
				|| DocImport.contains(content," HorizontalPosition.") || DocImport.contains(initCompStr," HorizontalPosition.")
				) {
			
			String is = "";
			if (DocImport.contains(content," CELLTYPE.") || DocImport.contains(initCompStr," CELLTYPE.")) {
				is = is + ", CELLTYPE";
			}
			if (DocImport.contains(content," CELL_HALIGNMENT.") || DocImport.contains(initCompStr," CELL_HALIGNMENT.")) {
				is = is + ", CELL_HALIGNMENT";
				}
			if (DocImport.contains(content," CELL_VALIGNMENT.") || DocImport.contains(initCompStr," CELL_VALIGNMENT.")) {
				is = is + ", CELL_VALIGNMENT";
				}
			if (DocImport.contains(content," DATETIME_TYPE.") || DocImport.contains(initCompStr," DATETIME_TYPE.")) {
				is = is + ", DATETIME_TYPE";
				}
			if (DocImport.contains(content," CellHorizontalAlignment.") || DocImport.contains(initCompStr," CellHorizontalAlignment.")) {
				is = is + ", CellHorizontalAlignment";
				}
			if (DocImport.contains(content," CellVerticalAlignment.") || DocImport.contains(initCompStr," CellVerticalAlignment.")) {
				is = is + ", CellVerticalAlignment";
				}
			if (DocImport.contains(content," VerticalPosition.") || DocImport.contains(initCompStr," VerticalPosition.")) {
				is = is + ", VerticalPosition";
				}
			if (DocImport.contains(content," HorizontalPosition.") || DocImport.contains(initCompStr," HorizontalPosition.")) {
				is = is + ", HorizontalPosition";
				}
			
			is = is.replaceFirst(", ", "");
			importSb.append("import { "+ is +" } from \"@/app/framework/Controls/LxSpread/LxSpreadNS\";" + "\r\n");
		} else {
		}		
			

		

		String contentStart = startSb.toString();
		content = content.replace(DocImport.IMPORT_START_STR, importSb.toString() + contentStart);
		String contentEnd = endSb.toString();

		return content + contentEnd;
	}

	private static String makeControlsStr(Map<String, String> variMap) {
		
		StringBuilder lxMaskedEdit_Sb = new StringBuilder();
		StringBuilder lxTextBox_Sb = new StringBuilder();
		StringBuilder lxComboBox_Sb = new StringBuilder();
		StringBuilder lxGroupBox_Sb = new StringBuilder();
		StringBuilder lxOverallCombo_Sb = new StringBuilder();
		StringBuilder lxDoctorListCombo_Sb = new StringBuilder();
		StringBuilder lxLoginUserDeptCombo_Sb = new StringBuilder();
		StringBuilder lxLoginUserDeptListBox_Sb = new StringBuilder();
		StringBuilder lxCheckBoxRadioGroup_Sb = new StringBuilder();
		StringBuilder lxDeptCombo_Sb = new StringBuilder();
		StringBuilder lxRoomCombo_Sb = new StringBuilder();
		StringBuilder lxSlipCombo_Sb = new StringBuilder();
		StringBuilder lxUserListCombo_Sb = new StringBuilder();
		StringBuilder lxWardCombo_Sb = new StringBuilder();
		StringBuilder lxCheckBox_Sb = new StringBuilder();
		StringBuilder lxButton_Sb = new StringBuilder();
		StringBuilder lxDateTimeEditor_Sb = new StringBuilder();
		StringBuilder lxDateTimePicker_Sb = new StringBuilder();
		StringBuilder lxComboBoxMultiCheck_Sb = new StringBuilder();
		StringBuilder lxRadioButton_Sb = new StringBuilder();		
		
		StringBuilder controlsSb = new StringBuilder();
		int xidx = 0;
		if (variMap != null) {
			for (String refNm : variMap.keySet()) {
				String compNm = variMap.get(refNm);
				System.out.println("refNm >> " + refNm + ", compNm >>" + compNm);
	
				if (compNm.equals("LxMaskedEdit")) {
					lxMaskedEdit_Sb.append(", " + refNm);
				} else if (compNm.equals("LxTextBox")) {
					lxTextBox_Sb.append(", " + refNm);
				} else if (compNm.equals("LxComboBox")) {
					lxComboBox_Sb.append(", " + refNm);
				} else if (compNm.equals("LxGroupBox")) {
					lxGroupBox_Sb.append(", " + refNm);
				} else if (compNm.equals("LxOverallCombo")) {
					lxOverallCombo_Sb.append(", " + refNm);
				} else if (compNm.equals("LxDoctorListCombo")) {
					lxDoctorListCombo_Sb.append(", " + refNm);
				} else if (compNm.equals("LxLoginUserDeptCombo")) {
					lxLoginUserDeptCombo_Sb.append(", " + refNm);
				} else if (compNm.equals("LxLoginUserDeptListBox")) {
					lxLoginUserDeptListBox_Sb.append(", " + refNm);
				} else if (compNm.equals("LxCheckBoxRadioGroup")) {
					lxCheckBoxRadioGroup_Sb.append(", " + refNm);
				} else if (compNm.equals("LxDeptCombo")) {
					lxDeptCombo_Sb.append(", " + refNm);
				} else if (compNm.equals("LxRoomCombo")) {
					lxRoomCombo_Sb.append(", " + refNm);
				} else if (compNm.equals("LxSlipCombo")) {
					lxSlipCombo_Sb.append(", " + refNm);
				} else if (compNm.equals("LxUserListCombo")) {
					lxUserListCombo_Sb.append(", " + refNm);
				} else if (compNm.equals("LxWardCombo")) {
					lxWardCombo_Sb.append(", " + refNm);
				} else if (compNm.equals("LxCheckBox")) {
					lxCheckBox_Sb.append(", " + refNm);
				} else if (compNm.equals("LxButton")) {
					lxButton_Sb.append(", " + refNm);
				} else if (compNm.equals("LxDateTimeEditor")) {
					lxDateTimeEditor_Sb.append(", " + refNm);
				} else if (compNm.equals("LxDateTimePicker")) {
					lxDateTimePicker_Sb.append(", " + refNm);
				} else if (compNm.equals("LxComboBoxMultiCheck")) {
					lxComboBoxMultiCheck_Sb.append(", " + refNm);
				} else if (compNm.equals("LxRadioButton")) {
					lxRadioButton_Sb.append(", " + refNm);
				}
			}
		}
		
		String lxMaskedEdit= lxMaskedEdit_Sb.toString();
		String lxTextBox= lxTextBox_Sb.toString();
		String lxComboBox= lxComboBox_Sb.toString();
		String lxGroupBox= lxGroupBox_Sb.toString();
		String lxOverallCombo= lxOverallCombo_Sb.toString();
		String lxDoctorListCombo= lxDoctorListCombo_Sb.toString();
		String lxLoginUserDeptCombo= lxLoginUserDeptCombo_Sb.toString();
		String lxLoginUserDeptListBox= lxLoginUserDeptListBox_Sb.toString();
		String lxCheckBoxRadioGroup= lxCheckBoxRadioGroup_Sb.toString();
		String lxDeptCombo= lxDeptCombo_Sb.toString();
		String lxRoomCombo= lxRoomCombo_Sb.toString();
		String lxSlipCombo= lxSlipCombo_Sb.toString();
		String lxUserListCombo= lxUserListCombo_Sb.toString();
		String lxWardCombo= lxWardCombo_Sb.toString();
		String lxCheckBox= lxCheckBox_Sb.toString();
		String lxButton= lxButton_Sb.toString();
		String lxDateTimeEditor= lxDateTimeEditor_Sb.toString();
		String lxDateTimePicker= lxDateTimePicker_Sb.toString();
		String lxComboBoxMultiCheck= lxComboBoxMultiCheck_Sb.toString();
		String lxRadioButton= lxRadioButton_Sb.toString();
		
		if (!lxMaskedEdit.isEmpty()) { controlsSb.append("     /*LxMaskedEdit*/\r\n    "); controlsSb.append(lxMaskedEdit + "\r\n");}
		if (!lxTextBox.isEmpty()) { controlsSb.append("     /*lxTextBox*/\r\n    "); controlsSb.append(lxTextBox + "\r\n");} 
		if (!lxComboBox.isEmpty()) { controlsSb.append("     /*lxComboBox*/\r\n    "); controlsSb.append(lxComboBox + "\r\n");} 
		if (!lxGroupBox.isEmpty()) { controlsSb.append("     /*lxGroupBox*/\r\n    "); controlsSb.append(lxGroupBox + "\r\n");} 
		if (!lxOverallCombo.isEmpty()) { controlsSb.append("     /*lxOverallCombo*/\r\n    "); controlsSb.append(lxOverallCombo + "\r\n");}         
		if (!lxDoctorListCombo.isEmpty()) { controlsSb.append("     /*lxDoctorListCombo*/\r\n    "); controlsSb.append(lxDoctorListCombo + "\r\n");}          
		if (!lxLoginUserDeptCombo.isEmpty()) { controlsSb.append("     /*lxLoginUserDeptCombo*/\r\n    "); controlsSb.append(lxLoginUserDeptCombo + "\r\n");}       
		if (!lxLoginUserDeptListBox.isEmpty()) { controlsSb.append("     /*lxLoginUserDeptListBox*/\r\n    "); controlsSb.append(lxLoginUserDeptListBox + "\r\n");}    
		if (!lxCheckBoxRadioGroup.isEmpty()) { controlsSb.append("     /*lxCheckBoxRadioGroup*/\r\n    "); controlsSb.append(lxCheckBoxRadioGroup + "\r\n");}       
		if (!lxDeptCombo.isEmpty()) { controlsSb.append("     /*lxDeptCombo*/\r\n    "); controlsSb.append(lxDeptCombo + "\r\n");}  
		if (!lxRoomCombo.isEmpty()) { controlsSb.append("     /*lxRoomCombo*/\r\n    "); controlsSb.append(lxRoomCombo + "\r\n");}  
		if (!lxSlipCombo.isEmpty()) { controlsSb.append("     /*lxSlipCombo*/\r\n    "); controlsSb.append(lxSlipCombo + "\r\n");}  
		if (!lxUserListCombo.isEmpty()) { controlsSb.append("     /*lxUserListCombo*/\r\n    "); controlsSb.append(lxUserListCombo + "\r\n");}            
		if (!lxWardCombo.isEmpty()) { controlsSb.append("     /*lxWardCombo*/\r\n    "); controlsSb.append(lxWardCombo + "\r\n");}  
		if (!lxCheckBox.isEmpty()) { controlsSb.append("     /*lxCheckBox*/\r\n    "); controlsSb.append(lxCheckBox + "\r\n");}   
		if (!lxButton.isEmpty()) { controlsSb.append("     /*lxButton*/\r\n    "); controlsSb.append(lxButton + "\r\n");}   
		if (!lxDateTimeEditor.isEmpty()) { controlsSb.append("     /*lxDateTimeEditor*/\r\n    "); controlsSb.append(lxDateTimeEditor + "\r\n");}           
		if (!lxDateTimePicker.isEmpty()) { controlsSb.append("     /*lxDateTimePicker*/\r\n    "); controlsSb.append(lxDateTimePicker + "\r\n");}           
		if (!lxComboBoxMultiCheck.isEmpty()) { controlsSb.append("     /*lxComboBoxMultiCheck*/\r\n    "); controlsSb.append(lxComboBoxMultiCheck + "\r\n");}       
		if (!lxRadioButton.isEmpty()) { controlsSb.append("     /*lxRadioButton*/\r\n    "); controlsSb.append(lxRadioButton + "\r\n");}              

		String controlsStr = controlsSb.toString();
		return controlsStr;
	}
	

}