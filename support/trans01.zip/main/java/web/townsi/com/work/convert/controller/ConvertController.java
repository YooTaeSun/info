package web.townsi.com.work.convert.controller;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import web.townsi.com.framework.fixed.AppConst;
import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;
import web.townsi.com.utils.StrUtil;
import web.townsi.com.work.convert.biz.ConvertBiz;


@Controller
@RequestMapping({ "/convert" })
@SuppressWarnings({"rawtypes","unchecked"})
public class ConvertController {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	public static LinkedHashMap<String, String> tableMap = new LinkedHashMap<String, String>();
	
	@Autowired
	private LinkedHashMap<String, String> propMap;

	@Autowired
	private ConvertBiz convertBiz;
	
	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();
	
	@PostConstruct
	static private void init() {
	}
	
	
	@RequestMapping({ "/view" })
	public String covertPage(@RequestParam HashMap params, Model model) throws Exception {
		return "setting/convertView";
	}
	
	@RequestMapping({ "/langView" })
	public String langPage(@RequestParam HashMap params, Model model) throws Exception {
		return "setting/langView";
	}
	
	@RequestMapping({ "/chgLangIdView" })
	public String Page(@RequestParam HashMap params, Model model) throws Exception {
		return "setting/chgLangIdView";
	}

	@RequestMapping({ "/info" })
	public ResponseEntity<HashMap> info(@RequestParam HashMap params, Model model) throws Exception {
		LinkedHashMap resultMap = new LinkedHashMap();
		ResponseEntity entity = null;
		try {
			Iterator it = this.propMap.keySet().iterator();
			while (it.hasNext()) {
				String key = (String) it.next();
				resultMap.put(key, this.propMap.get(key));
			}

			resultMap.put("param", params);
			entity = new ResponseEntity(resultMap, HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage());
			resultMap.put("error", e.getMessage());
			entity = new ResponseEntity(resultMap, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return entity;
	}


	@RequestMapping({ "/save" })
	public ResponseEntity<HashMap> save(HttpServletRequest request, @RequestParam HashMap params, Model model) throws Exception {
		HashMap resultMap = new HashMap();
		ResponseEntity entity = null;
		try {

			StrUtil.addMap(this.propMap, params);
			String content = FileUtil.changeContent(AppConst.settingProp, params);
			FileUtil.writeFile(AppConst.settingProp, content);

			resultMap.put("param", params);
			entity = new ResponseEntity(resultMap, HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage());
			resultMap.put("error", e.getMessage());
			entity = new ResponseEntity(resultMap, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return entity;
	}


    @RequestMapping("/source")
    public ResponseEntity<HashMap> source(@RequestParam HashMap params, Model model) throws Exception {
    	HashMap resultMap = new HashMap();
    	ResponseEntity entity = null;
		try {
			
			HashMap dataMap = this.convertBiz.source(params);
			resultMap.put("data", dataMap);
			resultMap.put("param", params);

			entity = new ResponseEntity(resultMap, HttpStatus.OK);
			logger.debug("source params : {}" , params);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			resultMap.put("error", e.getMessage());
			entity = new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return entity;
    }
    
    @RequestMapping("/makeLangFile")
    public ResponseEntity<HashMap> makeLangFile(@RequestParam HashMap params, Model model) throws Exception {
    	HashMap resultMap = new HashMap();
    	ResponseEntity entity = null;
    	try {
    		
    		
    		HashMap dataMap = this.convertBiz.makeLangFile(params);
    		resultMap.put("data", dataMap);
    		resultMap.put("param", params);
    		
    		entity = new ResponseEntity(resultMap, HttpStatus.OK);
    		logger.debug("source params : {}" , params);
    	} catch (Exception e) {
    		e.printStackTrace();
    		logger.error(e.getMessage());
    		resultMap.put("error", e.getMessage());
    		entity = new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    	return entity;
    }
    
    @RequestMapping("/readLang")
    public ResponseEntity<HashMap> readLang(@RequestParam HashMap params, Model model) throws Exception {
    	HashMap resultMap = new HashMap();
    	ResponseEntity entity = null;
    	try {
    		HashMap dataMap = this.convertBiz.readLang(params);
    		resultMap.put("data", dataMap);
    		resultMap.put("param", params);
    		
    		entity = new ResponseEntity(resultMap, HttpStatus.OK);
    		logger.debug("source params : {}" , params);
    	} catch (Exception e) {
    		e.printStackTrace();
    		logger.error(e.getMessage());
    		resultMap.put("error", e.getMessage());
    		entity = new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    	return entity;
    }
    
    @RequestMapping("/chgLangId")
    public ResponseEntity<HashMap> chgLangId(@RequestParam HashMap params, Model model) throws Exception {
    	HashMap resultMap = new HashMap();
    	ResponseEntity entity = null;
    	try {
    		HashMap dataMap = this.convertBiz.chgLangId(params);
    		resultMap.put("data", dataMap);
    		resultMap.put("param", params);
    		
    		entity = new ResponseEntity(resultMap, HttpStatus.OK);
    		logger.debug("source params : {}" , params);
    	} catch (Exception e) {
    		e.printStackTrace();
    		logger.error(e.getMessage());
    		resultMap.put("error", e.getMessage());
    		entity = new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    	return entity;
    }

}