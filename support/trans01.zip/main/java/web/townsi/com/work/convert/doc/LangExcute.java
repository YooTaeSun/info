package web.townsi.com.work.convert.doc;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;

public class LangExcute {
	
//	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();
	final static String SITE_WEB_ROOT = "D:\\project_java/workspace/tran01";
	
	
	private static Logger logger = LoggerFactory.getLogger(LangExcute.class);
	public static String[] LANGS = {"ko", "en", "ru", "uz"};
	
	
	public static HashMap process(String lang_kind) throws Exception {
		logger.info("=================	make_lang_file start 	======================");
		HashMap dataMap = new HashMap();
		BufferedReader br = null;
		
		try {
			String cmd = "";
			// 없으면 배포			
			if (lang_kind.equals("") || lang_kind.equals("dev")) {
				cmd = SITE_WEB_ROOT + "/test/ex_py39/python make_lang_file.py";
			} else {
				cmd = SITE_WEB_ROOT + "/test/ex_py39/python make_lang_file.py prod";
			}
			
			
			File dir = new File(SITE_WEB_ROOT + "/test"); //경로
			Runtime runtime = Runtime.getRuntime();
			Process p = runtime.exec(cmd, null, dir); 
			
			br = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line = null;
			while ((line = br.readLine()) != null) {
				logger.info(line);
			}
			
			
		} catch (IOException err) {
			logger.error(err.getMessage());
		} finally {
			if (br != null) {
				br.close();	
			}
		}
		logger.info("=================	make_lang_file end 	======================");
		return dataMap;
	}
	
	public static List<HashMap> readLang() throws Exception {
		logger.info("=================	readLang start 	======================");
		List<HashMap> list = new ArrayList<HashMap>();
		
		File root = new File(SITE_WEB_ROOT + "/test/result"); //경로
		File[] listOfFiles = root.listFiles();
		String content = "";
		String result = SITE_WEB_ROOT;
		String str = "";
		
		for (File file : listOfFiles) {
			if (file.isFile()) {
				
				String fileNm = file.getName();
				String rfullPath = file.getPath();
				String ext = FilenameUtils.getExtension(fileNm);
				
				if (fileNm.equals("ko.json") 
						|| fileNm.equals("en.json")
						|| fileNm.equals("ru.json")
						|| fileNm.equals("uz.json")
						) {
					
					str = FileUtil.readFile(rfullPath);
					HashMap dataMap = new HashMap();
					dataMap.put("fileNm", fileNm);
					dataMap.put("fullPath", rfullPath);
					dataMap.put("str", str);
					list.add(dataMap);
				}
			}
		}
		logger.info("=================	readLang end 	======================");
		return list;
	}
	
	public static void main(String[] args) throws Exception {
		System.out.println("=================	make_lang_file start 	======================");
		String lang_kind = "dev"; // prod dev
		HashMap resultMap = LangExcute.process(lang_kind);
		List<HashMap> listMap = LangExcute.readLang();
		
		if(!listMap.isEmpty()) {
			for (HashMap hashMap : listMap) {
				String str = (String) hashMap.get("str");
				System.out.println(str);
			}
		}
		System.out.println("=================	make_lang_file end 	======================");

	}
}