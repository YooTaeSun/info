package web.townsi.com.work.setting.biz;

import java.util.HashMap;
import java.util.List;

public interface SettingBiz {
	public abstract HashMap<String, Object> source(HashMap paramHashMap) throws Exception;
	public abstract HashMap<String, Object> makeMapper(HashMap paramHashMap) throws Exception;
	public abstract HashMap<String, Object> makeApi(HashMap paramHashMap) throws Exception;
	public abstract HashMap<String, Object> validator(HashMap paramHashMap) throws Exception;

	HashMap<String, Object> makeSetGet(HashMap vo) throws Exception;
	public abstract String takeComment(HashMap paramHashMap) throws Exception;
	public List<HashMap> selectTableInfo(HashMap params, String dbName, String tableSchema, String tableName);
	public List<HashMap> selectTableList(HashMap params);
	public abstract String selectTableAutoIncrement(HashMap paramHashMap) throws Exception;
	
}