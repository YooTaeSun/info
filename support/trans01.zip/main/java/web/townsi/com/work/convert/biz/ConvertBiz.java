package web.townsi.com.work.convert.biz;

import java.util.HashMap;

public interface ConvertBiz {
	public abstract HashMap<String, Object> source(HashMap paramHashMap) throws Exception;
	public abstract HashMap<String, Object> makeLangFile(HashMap paramHashMap) throws Exception;
	public abstract HashMap<String, Object> readLang(HashMap paramHashMap) throws Exception;
	public abstract HashMap<String, Object> chgLangId(HashMap paramHashMap) throws Exception;
	public abstract HashMap<String, Object> translation(HashMap paramHashMap) throws Exception;
	
}