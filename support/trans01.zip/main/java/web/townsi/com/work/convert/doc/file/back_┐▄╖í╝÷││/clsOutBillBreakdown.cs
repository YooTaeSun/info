//********************************************************************
// Class 명 : clsOutBillBreakdown
// 역    할 : 외래영수내역
// 작 성 자 : PGH
// 작 성 일 : 2017-09-14
//********************************************************************                                                   
// 수정내역 : 
//********************************************************************
using System;
using System.Data;
using Lime.Framework;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public class clsOutBillBreakdown
    {
        #region Define Variable Member
        private string m_PID = String.Empty;    //환자등록번호                     VARCHAR2(10)
        private int m_PT_CMHS_NO = 0;               //환자내원번호                     NUMBER(10, 0)
        private int m_RCPT_SQNO = 0;               //수납일련번호                     NUMBER(5, 0)
        private string m_MDCR_DD = String.Empty;    //진료일자                         VARCHAR2(8)
        private string m_BILL_NO = String.Empty;    //영수증번호                       VARCHAR2(10)
        private string m_RCPT_OCRR_UNIQ_NO = String.Empty;    //수납발생고유번호                 VARCHAR2(13)
        private string m_INSN_TYCD = String.Empty;    //보험유형코드                     VARCHAR2(2)
        private string m_ASST_TYCD = String.Empty;    //보조유형코드                     VARCHAR2(2)
        private string m_ASCT_RGNO_CD = String.Empty;    //조합기호코드                     VARCHAR2(20)
        private string m_MDCR_DEPT_CD = String.Empty;    //진료부서코드                     VARCHAR2(10)
        private string m_MDCR_DR_CD = String.Empty;    //진료의사코드                     VARCHAR2(10)
        private int m_TOTL_MDCR_AMT = 0;               //총진료금액                       NUMBER(10, 0)
        private int m_PAY_TAMT = 0;               //급여총금액                       NUMBER(10, 0)
        private int m_INSN_100_TAMT = 0;               //보험100총금액                    NUMBER(10, 0)
        private int m_SCNG_PAY_TAMT = 0;               //선별급여총금액                   NUMBER(10, 0)
        private int m_NOPY_TAMT = 0;               //비급여총금액                     NUMBER(10, 0)
        private int m_CLAM_NOPY_TAMT = 0;               //청구비급여총금액                 NUMBER(10, 0)
        private int m_ADED_VALU_TAX_TAMT = 0;               //부가가치세총금액                 NUMBER(10, 0)
        private int m_VTRN_TAMT = 0;               //보훈총금액                       NUMBER(10, 0)
        private int m_BYKN_ADTN_AMT = 0;               //종별가산금액                     NUMBER(10, 0)
        private int m_SMCR_AMT = 0;               //선택진료금액                     NUMBER(10, 0)
        private int m_PAY_USCH_AMT = 0;               //급여본인부담금액                 NUMBER(10, 0)
        private int m_SCNG_PAY_USCH_AMT = 0;               //선별급여본인부담금액             NUMBER(10, 0)
        private int m_PAY_CLAM_AMT = 0;               //급여청구금액                     NUMBER(10, 0)
        private int m_SCNG_PAY_CLAM_AMT = 0;               //선별급여청구금액                 NUMBER(10, 0)
        private int m_MDCN_UPLM_DIAM = 0;               //약제상한차액                     NUMBER(10, 0)
        private int m_HMPT_PAY_TAMT = 0;               //수진자급여총금액                 NUMBER(10, 0)
        private int m_DSBL_FUND_AMT = 0;               //장애기금금액                     NUMBER(10, 0)
        private int m_PFAN_AMT = 0;               //대불금액                         NUMBER(10, 0)
        private int m_USCH_UPLM_AMT = 0;               //본인부담상한금액                 NUMBER(10, 0)
        private int m_SUPT_AMT = 0;               //지원금액                         NUMBER(10, 0)
        private int m_EMRG_SUPT_AMT = 0;               //긴급지원금액                     NUMBER(10, 0)
        private int m_TBRC_CTCT_SUPT_AMT = 0;               //결핵접촉지원금액                 NUMBER(10, 0)
        private int m_MTWM_CLAM_AMT = 0;               //산모청구금액                     NUMBER(10, 0)
        private int m_MTWM_BLCE = 0;               //산모잔액                         NUMBER(10, 0)
        private int m_MTWM_PAY_CLAM_AMT = 0;               //산모급여청구금액                 NUMBER(10, 0)
        private int m_MTWM_I100_CLAM_AMT = 0;               //산모보험100청구금액              NUMBER(10, 0)
        private int m_MTWM_NOPY_CLAM_AMT = 0;               //산모비급여청구금액               NUMBER(10, 0)
        private int m_MTWM_SCPY_CLAM_AMT = 0;               //산모선별급여청구금액             NUMBER(10, 0)
        private int m_INDP_MOMR_CLAM_AMT = 0;               //독립유공자청구금액               NUMBER(10, 0)
        private int m_VCNT_CLAM_AMT = 0;               //예방접종청구금액                 NUMBER(10, 0)
        private int m_CT_USCH_AMT = 0;               //CT본인부담금액                   NUMBER(10, 0)
        private int m_MRI_USCH_AMT = 0;               //MRI본인부담금액                  NUMBER(10, 0)
        private int m_PET_USCH_AMT = 0;               //PET본인부담금액                  NUMBER(10, 0)
        private int m_FRTM_CARD_RCPT_AMT = 0;               //이전카드수납금액                 NUMBER(10, 0)
        private int m_FRTM_CASH_RCPT_AMT = 0;               //이전현금수납금액                 NUMBER(10, 0)
        private int m_FRTM_BNAC_AMT = 0;               //이전계좌금액                     NUMBER(10, 0)
        private int m_VTRN_RNE_AMT = 0;               //보훈감면금액                     NUMBER(10, 0)
        private string m_DCNT_RDIA_CD = String.Empty;    //할인감액코드                     VARCHAR2(10)
        private string m_DCNT_RDIA_EMNO = String.Empty;    //할인감액직원번호                 VARCHAR2(10)
        private int m_DCNT_RDIA_AMT = 0;               //할인감액금액                     NUMBER(10, 0)
        private int m_FRTM_DCNT_RDIA_AMT = 0;               //이전할인감액금액                 NUMBER(10, 0)
        private string m_SPCL_DCNT_DVCD = String.Empty;    //특별할인구분                     VARCHAR2(10)
        private int m_SPCL_DCNT_AMT = 0;               //특별할인금액                     NUMBER(10, 0)
        private string m_BLDN_YN = String.Empty;    //헌혈여부                         VARCHAR2(1)
        private int m_BLOD_RDIA_AMT = 0;               //혈액감액금액                     NUMBER(10, 0)
        private string m_VTRD_APLY_DVCD = String.Empty;    //수직감액적용구분코드             VARCHAR2(2)
        private int m_VTRD_AMT = 0;               //수직감액금액                     NUMBER(10, 0)
        private string m_CTTR_NO_CD = String.Empty;    //계약처번호코드                   VARCHAR2(10)
        private int m_CTTR_UNCL_APLY_AMT = 0;               //계약처미수적용금액               NUMBER(10, 0)
        private int m_CLNC_UNCL_APLY_AMT = 0;               //임상미수적용금액                 NUMBER(10, 0)
        private int m_GURN_CARD_AMT = 0;               //보증카드금액                     NUMBER(10, 0)
        private int m_GURN_CASH_AMT = 0;               //보증현금금액                     NUMBER(10, 0)
        private int m_GURN_BNAC_AMT = 0;               //보증계좌금액                     NUMBER(10, 0)
        private int m_HLLF_MNCS_CLAM_AMT = 0;               //건강생활유지비청구금액           NUMBER(10, 0)
        private int m_HLLF_MNCS_BLCE = 0;               //건강생활유지비잔액               NUMBER(10, 0)
        private int m_PT_SHAR_AMT = 0;               //환자부담금액                     NUMBER(10, 0)
        private int m_TRNC_AMT = 0;               //절사금액                         NUMBER(10, 0)
        private int m_CARD_RCPT_AMT = 0;               //카드수납금액                     NUMBER(10, 0)
        private string m_BANO = String.Empty;    //계좌번호                         VARCHAR2(20)
        private string m_BNAC_DPPR_NM = String.Empty;    //계좌입금자명                     VARCHAR2(50)
        private string m_BNAC_DPST_DD = String.Empty;    //계좌입금일자                     VARCHAR2(8)
        private int m_BNAC_RCPT_AMT = 0;               //계좌수납금액                     NUMBER(10, 0)
        private int m_CASH_RCPT_AMT = 0;               //현금수납금액                     NUMBER(10, 0)
        private string m_RFND_RESN = String.Empty;    //환불사유                         VARCHAR2(100)
        private string m_DCNT_RESN = String.Empty;    //할인사유                         VARCHAR2(100)
        private string m_UNCL_RESN = String.Empty;    //미수사유                         VARCHAR2(100)
        private string m_CASH_PRMT_YN = String.Empty;    //현금승인여부                     VARCHAR2(1)
        private string m_MDAD_PRMT_NO = String.Empty;    //의료급여승인번호                 VARCHAR2(50)
        private int m_FXAM_MCCS = 0;               //정액진료비                       NUMBER(10, 0)
        private int m_FXAM_MCCS_REAL_AMT = 0;               //정액진료비 실금액                NUMBER(10, 0)
        private string m_UNCL_CD = String.Empty;    //미수코드                         VARCHAR2(10)
        private int m_UNCL_AMT = 0;               //미수금액                         NUMBER(10, 0)
        private string m_RCPT_DD = String.Empty;    //수납일자                         VARCHAR2(8)
        private string m_RCPT_TIME = String.Empty;    //수납시간                         VARCHAR2(4)
        private string m_AFRS_STAT_DVCD = String.Empty;    //업무상태구분코드                 VARCHAR2(2)
        private string m_ROW_STAT_DVCD = String.Empty;    //행상태구분코드                   VARCHAR2(2)
        private string m_DLWT_IP_ADDR = String.Empty;    //처리IP주소                       VARCHAR2(10)
        private string m_RGST_DT = String.Empty;    //등록일시                         VARCHAR2(14)
        private string m_RGSTR_ID = String.Empty;    //등록자ID                         VARCHAR2(10)
        private int m_GVRN_CLAM_AMT = 0;    // 공무원공상청구금액

        private int m_NEW_RCPT_RQNO = 0;               //새로운 수납일련번호
        private string m_NEW_ROW_STAT_DVCD = String.Empty;    //변경할 행상태구분코드
        private string m_OTPT_AMDT_DVCD = String.Empty;    //외래입원구분코드
        private int m_GURN_TAMT = 0;               // 보증금(입원)

        private int m_STATVAL1 = 1;             //행상태구분에 따른 값 ROW_STAT_DVCD = 'D' -> -1, ROW_STAT_DVCD = 'A' -> 1, ROW_STAT_DVCD = 'F' -> 0
        private int m_STATVAL2 = 1;             // 0, -1, 1
        private int m_STATVAL3 = 1;             // 0, -1, 1

        //TO-DO : 미수카드입금액, 미수현금입금액, 미수계좌입금액, 미수할인금액 변수와 프로퍼티 만들어서 넘기기만 하였음. (추후에, 박부장님 처리하신다고 하심)
        private int m_UNCL_CARD_AMT = 0;                //미수카드입금금액
        private int m_UNCL_CASH_AMT = 0;                //미수현금입금금액
        private int m_UNCL_BNAC_AMT = 0;                //미수계좌입금금액
        private int m_UNCL_CUT_AMT = 0;                 //미수할인금액
        private int m_USCH_AMT = 0;
        private int m_CLAM_AMT = 0;

        private clsUnCollectedOcrrInfo m_UnclOcrrInfo = new clsUnCollectedOcrrInfo();

        #endregion

        #region Define Member Property
        public string PID { get { return m_PID; } set { m_PID = value; } }
        public int PT_CMHS_NO { get { return m_PT_CMHS_NO; } set { m_PT_CMHS_NO = value; } }
        public int RCPT_SQNO { get { return m_RCPT_SQNO; } set { m_RCPT_SQNO = value; } }
        public string MDCR_DD { get { return m_MDCR_DD; } set { m_MDCR_DD = value; } }
        public string BILL_NO { get { return m_BILL_NO; } set { m_BILL_NO = value; } }
        public string RCPT_OCRR_UNIQ_NO { get { return m_RCPT_OCRR_UNIQ_NO; } set { m_RCPT_OCRR_UNIQ_NO = value; } }
        public string INSN_TYCD { get { return m_INSN_TYCD; } set { m_INSN_TYCD = value; } }
        public string ASST_TYCD { get { return m_ASST_TYCD; } set { m_ASST_TYCD = value; } }
        public string ASCT_RGNO_CD { get { return m_ASCT_RGNO_CD; } set { m_ASCT_RGNO_CD = value; } }
        public string MDCR_DEPT_CD { get { return m_MDCR_DEPT_CD; } set { m_MDCR_DEPT_CD = value; } }
        public string MDCR_DR_CD { get { return m_MDCR_DR_CD; } set { m_MDCR_DR_CD = value; } }
        public int TOTL_MDCR_AMT { get { return m_TOTL_MDCR_AMT; } set { m_TOTL_MDCR_AMT = value; } }
        public int PAY_TAMT { get { return m_PAY_TAMT; } set { m_PAY_TAMT = value; } }
        public int INSN_100_TAMT { get { return m_INSN_100_TAMT; } set { m_INSN_100_TAMT = value; } }
        public int SCNG_PAY_TAMT { get { return m_SCNG_PAY_TAMT; } set { m_SCNG_PAY_TAMT = value; } }
        public int NOPY_TAMT { get { return m_NOPY_TAMT; } set { m_NOPY_TAMT = value; } }
        public int CLAM_NOPY_TAMT { get { return m_CLAM_NOPY_TAMT; } set { m_CLAM_NOPY_TAMT = value; } }
        public int ADED_VALU_TAX_TAMT { get { return m_ADED_VALU_TAX_TAMT; } set { m_ADED_VALU_TAX_TAMT = value; } }
        public int VTRN_TAMT { get { return m_VTRN_TAMT; } set { m_VTRN_TAMT = value; } }
        public int BYKN_ADTN_AMT { get { return m_BYKN_ADTN_AMT; } set { m_BYKN_ADTN_AMT = value; } }
        public int SMCR_AMT { get { return m_SMCR_AMT; } set { m_SMCR_AMT = value; } }
        public int PAY_USCH_AMT { get { return m_PAY_USCH_AMT; } set { m_PAY_USCH_AMT = value; } }
        public int SCNG_PAY_USCH_AMT { get { return m_SCNG_PAY_USCH_AMT; } set { m_SCNG_PAY_USCH_AMT = value; } }
        public int PAY_CLAM_AMT { get { return m_PAY_CLAM_AMT; } set { m_PAY_CLAM_AMT = value; } }
        public int SCNG_PAY_CLAM_AMT { get { return m_SCNG_PAY_CLAM_AMT; } set { m_SCNG_PAY_CLAM_AMT = value; } }
        public int MDCN_UPLM_DIAM { get { return m_MDCN_UPLM_DIAM; } set { m_MDCN_UPLM_DIAM = value; } }
        public int HMPT_PAY_TAMT { get { return m_HMPT_PAY_TAMT; } set { m_HMPT_PAY_TAMT = value; } }
        public int DSBL_FUND_AMT { get { return m_DSBL_FUND_AMT; } set { m_DSBL_FUND_AMT = value; } }
        public int PFAN_AMT { get { return m_PFAN_AMT; } set { m_PFAN_AMT = value; } }
        public int USCH_UPLM_AMT { get { return m_USCH_UPLM_AMT; } set { m_USCH_UPLM_AMT = value; } }
        public int SUPT_AMT { get { return m_SUPT_AMT; } set { m_SUPT_AMT = value; } }
        public int EMRG_SUPT_AMT { get { return m_EMRG_SUPT_AMT; } set { m_EMRG_SUPT_AMT = value; } }
        public int TBRC_CTCT_SUPT_AMT { get { return m_TBRC_CTCT_SUPT_AMT; } set { m_TBRC_CTCT_SUPT_AMT = value; } }
        public int MTWM_CLAM_AMT { get { return m_MTWM_CLAM_AMT; } set { m_MTWM_CLAM_AMT = value; } }
        public int MTWM_BLCE { get { return m_MTWM_BLCE; } set { m_MTWM_BLCE = value; } }
        public int MTWM_PAY_CLAM_AMT { get { return m_MTWM_PAY_CLAM_AMT; } set { m_MTWM_PAY_CLAM_AMT = value; } }
        public int MTWM_I100_CLAM_AMT { get { return m_MTWM_I100_CLAM_AMT; } set { m_MTWM_I100_CLAM_AMT = value; } }
        public int MTWM_NOPY_CLAM_AMT { get { return m_MTWM_NOPY_CLAM_AMT; } set { m_MTWM_NOPY_CLAM_AMT = value; } }
        public int MTWM_SCPY_CLAM_AMT { get { return m_MTWM_SCPY_CLAM_AMT; } set { m_MTWM_SCPY_CLAM_AMT = value; } }
        public int INDP_MOMR_CLAM_AMT { get { return m_INDP_MOMR_CLAM_AMT; } set { m_INDP_MOMR_CLAM_AMT = value; } }
        public int VCNT_CLAM_AMT { get { return m_VCNT_CLAM_AMT; } set { m_VCNT_CLAM_AMT = value; } }
        public int CT_USCH_AMT { get { return m_CT_USCH_AMT; } set { m_CT_USCH_AMT = value; } }
        public int MRI_USCH_AMT { get { return m_MRI_USCH_AMT; } set { m_MRI_USCH_AMT = value; } }
        public int PET_USCH_AMT { get { return m_PET_USCH_AMT; } set { m_PET_USCH_AMT = value; } }
        public int FRTM_CARD_RCPT_AMT { get { return m_FRTM_CARD_RCPT_AMT; } set { m_FRTM_CARD_RCPT_AMT = value; } }
        public int FRTM_CASH_RCPT_AMT { get { return m_FRTM_CASH_RCPT_AMT; } set { m_FRTM_CASH_RCPT_AMT = value; } }
        public int FRTM_BNAC_AMT { get { return m_FRTM_BNAC_AMT; } set { m_FRTM_BNAC_AMT = value; } }
        public int VTRN_RNE_AMT { get { return m_VTRN_RNE_AMT; } set { m_VTRN_RNE_AMT = value; } }
        public string DCNT_RDIA_CD { get { return m_DCNT_RDIA_CD; } set { m_DCNT_RDIA_CD = value; } }
        public string DCNT_RDIA_EMNO { get { return m_DCNT_RDIA_EMNO; } set { m_DCNT_RDIA_EMNO = value; } }
        public int DCNT_RDIA_AMT { get { return m_DCNT_RDIA_AMT; } set { m_DCNT_RDIA_AMT = value; } }
        public int FRTM_DCNT_RDIA_AMT { get { return m_FRTM_DCNT_RDIA_AMT; } set { m_FRTM_DCNT_RDIA_AMT = value; } }
        public string SPCL_DCNT_DVCD { get { return m_SPCL_DCNT_DVCD; } set { m_SPCL_DCNT_DVCD = value; } }
        public int SPCL_DCNT_AMT { get { return m_SPCL_DCNT_AMT; } set { m_SPCL_DCNT_AMT = value; } }
        public string BLDN_YN { get { return m_BLDN_YN; } set { m_BLDN_YN = value; } }
        public int BLOD_RDIA_AMT { get { return m_BLOD_RDIA_AMT; } set { m_BLOD_RDIA_AMT = value; } }
        public string VTRD_APLY_DVCD { get { return m_VTRD_APLY_DVCD; } set { m_VTRD_APLY_DVCD = value; } }
        public int VTRD_AMT { get { return m_VTRD_AMT; } set { m_VTRD_AMT = value; } }
        public string CTTR_NO_CD { get { return m_CTTR_NO_CD; } set { m_CTTR_NO_CD = value; } }
        public int CTTR_UNCL_APLY_AMT { get { return m_CTTR_UNCL_APLY_AMT; } set { m_CTTR_UNCL_APLY_AMT = value; } }
        public int CLNC_UNCL_APLY_AMT { get { return m_CLNC_UNCL_APLY_AMT; } set { m_CLNC_UNCL_APLY_AMT = value; } }
        public int GURN_CARD_AMT { get { return m_GURN_CARD_AMT; } set { m_GURN_CARD_AMT = value; } }
        public int GURN_CASH_AMT { get { return m_GURN_CASH_AMT; } set { m_GURN_CASH_AMT = value; } }
        public int GURN_BNAC_AMT { get { return m_GURN_BNAC_AMT; } set { m_GURN_BNAC_AMT = value; } }
        public int HLLF_MNCS_CLAM_AMT { get { return m_HLLF_MNCS_CLAM_AMT; } set { m_HLLF_MNCS_CLAM_AMT = value; } }
        public int HLLF_MNCS_BLCE { get { return m_HLLF_MNCS_BLCE; } set { m_HLLF_MNCS_BLCE = value; } }
        public int PT_SHAR_AMT { get { return m_PT_SHAR_AMT; } set { m_PT_SHAR_AMT = value; } }
        public int TRNC_AMT { get { return m_TRNC_AMT; } set { m_TRNC_AMT = value; } }
        public int CARD_RCPT_AMT { get { return m_CARD_RCPT_AMT; } set { m_CARD_RCPT_AMT = value; } }
        public string BANO { get { return m_BANO; } set { m_BANO = value; } }
        public string BNAC_DPPR_NM { get { return m_BNAC_DPPR_NM; } set { m_BNAC_DPPR_NM = value; } }
        public string BNAC_DPST_DD { get { return m_BNAC_DPST_DD; } set { m_BNAC_DPST_DD = value; } }
        public int BNAC_RCPT_AMT { get { return m_BNAC_RCPT_AMT; } set { m_BNAC_RCPT_AMT = value; } }
        public int CASH_RCPT_AMT { get { return m_CASH_RCPT_AMT; } set { m_CASH_RCPT_AMT = value; } }
        public string RFND_RESN { get { return m_RFND_RESN; } set { m_RFND_RESN = value; } }
        public string DCNT_RESN { get { return m_DCNT_RESN; } set { m_DCNT_RESN = value; } }
        public string UNCL_RESN { get { return m_UNCL_RESN; } set { m_UNCL_RESN = value; } }
        public string CASH_PRMT_YN { get { return m_CASH_PRMT_YN; } set { m_CASH_PRMT_YN = value; } }
        public string MDAD_PRMT_NO { get { return m_MDAD_PRMT_NO; } set { m_MDAD_PRMT_NO = value; } }
        public int FXAM_MCCS { get { return m_FXAM_MCCS; } set { m_FXAM_MCCS = value; } }
        public int FXAM_MCCS_REAL_AMT { get { return m_FXAM_MCCS_REAL_AMT; } set { m_FXAM_MCCS_REAL_AMT = value; } }
        public string UNCL_CD { get { return m_UNCL_CD; } set { m_UNCL_CD = value; } }
        public int UNCL_AMT { get { return m_UNCL_AMT; } set { m_UNCL_AMT = value; } }
        public string RCPT_DD { get { return m_RCPT_DD; } set { m_RCPT_DD = value; } }
        public string RCPT_TIME { get { return m_RCPT_TIME; } set { m_RCPT_TIME = value; } }
        public string AFRS_STAT_DVCD { get { return m_AFRS_STAT_DVCD; } set { m_AFRS_STAT_DVCD = value; } }
        public string ROW_STAT_DVCD { get { return m_ROW_STAT_DVCD; } set { m_ROW_STAT_DVCD = value; } }
        public string DLWT_IP_ADDR { get { return m_DLWT_IP_ADDR; } set { m_DLWT_IP_ADDR = value; } }
        public string RGST_DT { get { return m_RGST_DT; } set { m_RGST_DT = value; } }
        public string RGSTR_ID { get { return m_RGSTR_ID; } set { m_RGSTR_ID = value; } }
        public int GVRN_CLAM_AMT {  get { return m_GVRN_CLAM_AMT; } set { m_GVRN_CLAM_AMT = value; } }

        public int NEW_RCPT_RQNO { get { return m_NEW_RCPT_RQNO; } set { m_NEW_RCPT_RQNO = value; } }
        public string NEW_ROW_STAT_DVCD { get { return m_NEW_ROW_STAT_DVCD; } set { m_NEW_ROW_STAT_DVCD = value; } }
        public string OTPT_AMDT_DVCD { get { return m_OTPT_AMDT_DVCD; } set { m_OTPT_AMDT_DVCD = value; } }
        public int GURN_TAMT { get { return m_GURN_TAMT; } set { m_GURN_TAMT = value; } }

        public int STATVAL1 { get { return m_STATVAL1; } set { m_STATVAL1 = value; } }
        public int STATVAL2 { get { return m_STATVAL2; } set { m_STATVAL2 = value; } }
        public int STATVAL3 { get { return m_STATVAL3; } set { m_STATVAL3 = value; } }

        //TO-DO : 미수카드입금액, 미수현금입금액, 미수계좌입금액, 미수할인금액 변수와 프로퍼티 만들어서 넘기기만 하였음. (추후에, 박부장님 처리하신다고 하심)
        public int UNCL_CARD_AMT { get { return m_UNCL_CARD_AMT; } set { m_UNCL_CARD_AMT = value; } }
        public int UNCL_CASH_AMT { get { return m_UNCL_CASH_AMT; } set { m_UNCL_CASH_AMT = value; } }
        public int UNCL_BNAC_AMT { get { return m_UNCL_BNAC_AMT; } set { m_UNCL_BNAC_AMT = value; } }
        public int UNCL_CUT_AMT { get { return m_UNCL_CUT_AMT; } set { m_UNCL_CUT_AMT = value; } }

        public int USCH_AMT { get { return m_USCH_AMT; } set { m_USCH_AMT = value; } }
        public int CLAM_AMT { get { return m_CLAM_AMT; } set { m_CLAM_AMT = value; } }

        #endregion

        #region Constructor
        public clsOutBillBreakdown()
        {
            Clear();
        }
        #endregion

        #region Method : General
        public void Clear()
        {
            m_PID = String.Empty;
            m_PT_CMHS_NO = 0;
            m_RCPT_SQNO = 0;
            m_MDCR_DD = String.Empty;
            m_BILL_NO = String.Empty;
            m_RCPT_OCRR_UNIQ_NO = String.Empty;
            m_INSN_TYCD = String.Empty;
            m_ASST_TYCD = String.Empty;
            m_ASCT_RGNO_CD = String.Empty;
            m_MDCR_DEPT_CD = String.Empty;
            m_MDCR_DR_CD = String.Empty;
            m_TOTL_MDCR_AMT = 0;
            m_PAY_TAMT = 0;
            m_INSN_100_TAMT = 0;
            m_SCNG_PAY_TAMT = 0;
            m_NOPY_TAMT = 0;
            m_CLAM_NOPY_TAMT = 0;
            m_ADED_VALU_TAX_TAMT = 0;
            m_VTRN_TAMT = 0;
            m_BYKN_ADTN_AMT = 0;
            m_SMCR_AMT = 0;
            m_PAY_USCH_AMT = 0;
            m_SCNG_PAY_USCH_AMT = 0;
            m_PAY_CLAM_AMT = 0;
            m_SCNG_PAY_CLAM_AMT = 0;
            m_MDCN_UPLM_DIAM = 0;
            m_HMPT_PAY_TAMT = 0;
            m_DSBL_FUND_AMT = 0;
            m_PFAN_AMT = 0;
            m_USCH_UPLM_AMT = 0;
            m_SUPT_AMT = 0;
            m_EMRG_SUPT_AMT = 0;
            m_TBRC_CTCT_SUPT_AMT = 0;
            m_MTWM_CLAM_AMT = 0;
            m_MTWM_BLCE = 0;
            m_MTWM_PAY_CLAM_AMT = 0;
            m_MTWM_I100_CLAM_AMT = 0;
            m_MTWM_NOPY_CLAM_AMT = 0;
            m_MTWM_SCPY_CLAM_AMT = 0;
            m_INDP_MOMR_CLAM_AMT = 0;
            m_VCNT_CLAM_AMT = 0;
            m_CT_USCH_AMT = 0;
            m_MRI_USCH_AMT = 0;
            m_PET_USCH_AMT = 0;
            m_FRTM_CARD_RCPT_AMT = 0;
            m_FRTM_CASH_RCPT_AMT = 0;
            m_FRTM_BNAC_AMT = 0;
            m_VTRN_RNE_AMT = 0;
            m_DCNT_RDIA_CD = String.Empty;
            m_DCNT_RDIA_EMNO = String.Empty;
            m_DCNT_RDIA_AMT = 0;
            m_FRTM_DCNT_RDIA_AMT = 0;
            m_SPCL_DCNT_DVCD = String.Empty;
            m_SPCL_DCNT_AMT = 0;
            m_BLDN_YN = String.Empty;
            m_BLOD_RDIA_AMT = 0;
            m_VTRD_APLY_DVCD = String.Empty;
            m_VTRD_AMT = 0;
            m_CTTR_NO_CD = String.Empty;
            m_CTTR_UNCL_APLY_AMT = 0;
            m_CLNC_UNCL_APLY_AMT = 0;
            m_GURN_CARD_AMT = 0;
            m_GURN_CASH_AMT = 0;
            m_GURN_BNAC_AMT = 0;
            m_HLLF_MNCS_CLAM_AMT = 0;
            m_HLLF_MNCS_BLCE = 0;
            m_PT_SHAR_AMT = 0;
            m_TRNC_AMT = 0;
            m_CARD_RCPT_AMT = 0;
            m_BANO = String.Empty;
            m_BNAC_DPPR_NM = String.Empty;
            m_BNAC_DPST_DD = String.Empty;
            m_BNAC_RCPT_AMT = 0;
            m_CASH_RCPT_AMT = 0;
            m_RFND_RESN = String.Empty;
            m_DCNT_RESN = String.Empty;
            m_UNCL_RESN = String.Empty;
            m_CASH_PRMT_YN = String.Empty;
            m_MDAD_PRMT_NO = String.Empty;
            m_FXAM_MCCS = 0;
            m_FXAM_MCCS_REAL_AMT = 0;
            m_UNCL_CD = String.Empty;
            m_UNCL_AMT = 0;
            m_RCPT_DD = String.Empty;
            m_RCPT_TIME = String.Empty;
            m_AFRS_STAT_DVCD = String.Empty;
            m_ROW_STAT_DVCD = String.Empty;
            m_DLWT_IP_ADDR = String.Empty;
            m_RGST_DT = String.Empty;
            m_RGSTR_ID = String.Empty;
            m_GVRN_CLAM_AMT = 0;

            m_NEW_RCPT_RQNO = 0;
            m_NEW_ROW_STAT_DVCD = String.Empty;
            m_OTPT_AMDT_DVCD = String.Empty;
            m_GURN_TAMT = 0;

            m_STATVAL1 = 1;
            m_STATVAL2 = 1;
            m_STATVAL3 = 1;
        }
        #endregion

        #region Method : Public Method

        #region Method : SelectData Method

        public bool Load(string pid, int ptcmhsno)
        {
            return GetPAOBILBD(pid, ptcmhsno);
        }

        /// <summary>
        /// 최종영수증 수납일련번호를 가져온다.
        /// </summary>
        /// <returns></returns>
        public int SelectMaxRcptSqno(string pid, int ptcmhsno, out string outmsg)
        {
            int result = 0;
            result = DBService.ExecuteInteger(SQL.PA.Sql.SelectPAOBILBD_MaxRcptSqno(), pid, ptcmhsno.ToString());
            outmsg = DBService.ErrorMessage;
            return result;
        }

        /// <summary>
        /// 최종영수증 수납일련번호를 가져온다.
        /// </summary>
        /// <returns></returns>
        public int SelectMaxRcptSqno(out string outmsg)
        {
            int result = 0;
            result = DBService.ExecuteInteger(SQL.PA.Sql.SelectPAOBILBD_MaxRcptSqno(), m_PID, m_PT_CMHS_NO.ToString());
            outmsg = DBService.ErrorMessage;
            return result;
        }

        public bool GetPAOBILBD(string pid, int ptcmhsno)
        {
            try
            {
                DataTable dtOutBill = new DataTable();

                try
                {
                    DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOBILBD(), ref dtOutBill, pid
                                                                                         , ptcmhsno.ToString()
                                                                                         , "A");
                }
                catch (Exception ex)
                {
                    LogService.ErrorLog(ex);
                }

                if (dtOutBill.Rows.Count > 0)
                {
                    DataRow row = dtOutBill.Rows[0];

                    m_PID = row["PID"].ToString();
                    m_PT_CMHS_NO = int.Parse(row["PT_CMHS_NO"].ToString());
                    m_RCPT_SQNO = int.Parse(row["RCPT_SQNO"].ToString());
                    m_MDCR_DD = row["MDCR_DD"].ToString();
                    m_BILL_NO = row["BILL_NO"].ToString();
                    m_RCPT_OCRR_UNIQ_NO = row["RCPT_OCRR_UNIQ_NO"].ToString();
                    m_INSN_TYCD = row["INSN_TYCD"].ToString();
                    m_ASST_TYCD = row["ASST_TYCD"].ToString();
                    m_ASCT_RGNO_CD = row["ASCT_RGNO_CD"].ToString();
                    m_MDCR_DEPT_CD = row["MDCR_DEPT_CD"].ToString();
                    m_MDCR_DR_CD = row["MDCR_DR_CD"].ToString();
                    m_TOTL_MDCR_AMT = int.Parse(row["TOTL_MDCR_AMT"].ToString());
                    m_PAY_TAMT = int.Parse(row["PAY_TAMT"].ToString());
                    m_INSN_100_TAMT = int.Parse(row["INSN_100_TAMT"].ToString());
                    m_SCNG_PAY_TAMT = int.Parse(row["SCNG_PAY_TAMT"].ToString());
                    m_NOPY_TAMT = int.Parse(row["NOPY_TAMT"].ToString());
                    m_CLAM_NOPY_TAMT = int.Parse(row["CLAM_NOPY_TAMT"].ToString());
                    m_ADED_VALU_TAX_TAMT = int.Parse(row["ADED_VALU_TAX_TAMT"].ToString());
                    m_VTRN_TAMT = int.Parse(row["VTRN_TAMT"].ToString());
                    m_BYKN_ADTN_AMT = int.Parse(row["BYKN_ADTN_AMT"].ToString());
                    m_SMCR_AMT = int.Parse(row["SMCR_AMT"].ToString());
                    m_PAY_USCH_AMT = int.Parse(row["PAY_USCH_AMT"].ToString());
                    m_SCNG_PAY_USCH_AMT = int.Parse(row["SCNG_PAY_USCH_AMT"].ToString());
                    m_PAY_CLAM_AMT = int.Parse(row["PAY_CLAM_AMT"].ToString());
                    m_SCNG_PAY_CLAM_AMT = int.Parse(row["SCNG_PAY_CLAM_AMT"].ToString());
                    m_MDCN_UPLM_DIAM = int.Parse(row["MDCN_UPLM_DIAM"].ToString());
                    m_HMPT_PAY_TAMT = int.Parse(row["HMPT_PAY_TAMT"].ToString());
                    m_DSBL_FUND_AMT = int.Parse(row["DSBL_FUND_AMT"].ToString());
                    m_PFAN_AMT = int.Parse(row["PFAN_AMT"].ToString());
                    m_USCH_UPLM_AMT = int.Parse(row["USCH_UPLM_AMT"].ToString());
                    m_SUPT_AMT = int.Parse(row["SUPT_AMT"].ToString());
                    m_EMRG_SUPT_AMT = int.Parse(row["EMRG_SUPT_AMT"].ToString());
                    m_TBRC_CTCT_SUPT_AMT = int.Parse(row["TBRC_CTCT_SUPT_AMT"].ToString());
                    m_MTWM_CLAM_AMT = int.Parse(row["MTWM_CLAM_AMT"].ToString());
                    m_MTWM_BLCE = int.Parse(row["MTWM_BLCE"].ToString());
                    m_MTWM_PAY_CLAM_AMT = int.Parse(row["MTWM_PAY_CLAM_AMT"].ToString());
                    m_MTWM_I100_CLAM_AMT = int.Parse(row["MTWM_I100_CLAM_AMT"].ToString());
                    m_MTWM_NOPY_CLAM_AMT = int.Parse(row["MTWM_NOPY_CLAM_AMT"].ToString());
                    m_MTWM_SCPY_CLAM_AMT = int.Parse(row["MTWM_SCPY_CLAM_AMT"].ToString());
                    m_INDP_MOMR_CLAM_AMT = int.Parse(row["INDP_MOMR_CLAM_AMT"].ToString());
                    m_VCNT_CLAM_AMT = int.Parse(row["VCNT_CLAM_AMT"].ToString());
                    m_CT_USCH_AMT = int.Parse(row["CT_USCH_AMT"].ToString());
                    m_MRI_USCH_AMT = int.Parse(row["MRI_USCH_AMT"].ToString());
                    m_PET_USCH_AMT = int.Parse(row["PET_USCH_AMT"].ToString());
                    m_FRTM_CARD_RCPT_AMT = int.Parse(row["FRTM_CARD_RCPT_AMT"].ToString());
                    m_FRTM_CASH_RCPT_AMT = int.Parse(row["FRTM_CASH_RCPT_AMT"].ToString());
                    m_FRTM_BNAC_AMT = int.Parse(row["FRTM_BNAC_AMT"].ToString());
                    m_VTRN_RNE_AMT = int.Parse(row["VTRN_RNE_AMT"].ToString());
                    m_DCNT_RDIA_CD = row["DCNT_RDIA_CD"].ToString();
                    m_DCNT_RDIA_EMNO = row["DCNT_RDIA_EMNO"].ToString();
                    m_DCNT_RDIA_AMT = int.Parse(row["DCNT_RDIA_AMT"].ToString());
                    m_FRTM_DCNT_RDIA_AMT = int.Parse(row["FRTM_DCNT_RDIA_AMT"].ToString());
                    m_SPCL_DCNT_AMT = int.Parse(row["SPCL_DCNT_AMT"].ToString());
                    m_BLDN_YN = row["BLDN_YN"].ToString();
                    m_BLOD_RDIA_AMT = int.Parse(row["BLOD_RDIA_AMT"].ToString());
                    m_VTRD_APLY_DVCD = row["VTRD_APLY_DVCD"].ToString();
                    m_VTRD_AMT = int.Parse(row["VTRD_AMT"].ToString());
                    m_CTTR_NO_CD = row["CTTR_NO_CD"].ToString();
                    m_CTTR_UNCL_APLY_AMT = int.Parse(row["CTTR_UNCL_APLY_AMT"].ToString());
                    m_CLNC_UNCL_APLY_AMT = int.Parse(row["CLNC_UNCL_APLY_AMT"].ToString());
                    m_GURN_CARD_AMT = int.Parse(row["GURN_CARD_AMT"].ToString());
                    m_GURN_CASH_AMT = int.Parse(row["GURN_CASH_AMT"].ToString());
                    m_GURN_BNAC_AMT = int.Parse(row["GURN_BNAC_AMT"].ToString());
                    m_HLLF_MNCS_CLAM_AMT = int.Parse(row["HLLF_MNCS_CLAM_AMT"].ToString());
                    m_HLLF_MNCS_BLCE = int.Parse(row["HLLF_MNCS_BLCE"].ToString());
                    m_PT_SHAR_AMT = int.Parse(row["PT_SHAR_AMT"].ToString());
                    m_TRNC_AMT = int.Parse(row["TRNC_AMT"].ToString());
                    m_CARD_RCPT_AMT = int.Parse(row["CARD_RCPT_AMT"].ToString());
                    m_BANO = row["BANO"].ToString();
                    m_BNAC_DPPR_NM = row["BNAC_DPPR_NM"].ToString();
                    m_BNAC_DPST_DD = row["BNAC_DPST_DD"].ToString();
                    m_BNAC_RCPT_AMT = int.Parse(row["BNAC_RCPT_AMT"].ToString());
                    m_CASH_RCPT_AMT = int.Parse(row["CASH_RCPT_AMT"].ToString());
                    m_RFND_RESN = row["RFND_RESN"].ToString();
                    m_DCNT_RESN = row["DCNT_RESN"].ToString();
                    m_UNCL_RESN = row["UNCL_RESN"].ToString();
                    m_CASH_PRMT_YN = row["CASH_PRMT_YN"].ToString();
                    m_MDAD_PRMT_NO = row["MDAD_PRMT_NO"].ToString();
                    m_FXAM_MCCS = int.Parse(row["FXAM_MCCS"].ToString());
                    m_FXAM_MCCS_REAL_AMT = int.Parse(row["FXAM_MCCS_REAL_AMT"].ToString());
                    m_UNCL_CD = row["UNCL_CD"].ToString();
                    m_UNCL_AMT = int.Parse(row["UNCL_AMT"].ToString());
                    m_RCPT_DD = row["RCPT_DD"].ToString();
                    m_RCPT_TIME = row["RCPT_TIME"].ToString();
                    m_AFRS_STAT_DVCD = row["AFRS_STAT_DVCD"].ToString();
                    m_ROW_STAT_DVCD = row["ROW_STAT_DVCD"].ToString();
                    m_DLWT_IP_ADDR = row["DLWT_IP_ADDR"].ToString();
                    m_RGST_DT = row["RGST_DT"].ToString();
                    m_RGSTR_ID = row["RGSTR_ID"].ToString();
                   
                    int.TryParse(row["GVRN_CLAM_AMT"].ToString(), out m_GVRN_CLAM_AMT);

                    m_USCH_AMT = int.Parse(row["USCH_AMT"].ToString());
                    m_CLAM_AMT = int.Parse(row["CLAM_AMT"].ToString());
                    m_UNCL_CARD_AMT = int.Parse(row["UNCL_CARD_AMT"].ToString());
                    m_UNCL_CASH_AMT = int.Parse(row["UNCL_CASH_AMT"].ToString());
                    m_UNCL_BNAC_AMT = int.Parse(row["UNCL_BNAC_AMT"].ToString());
                    m_UNCL_CUT_AMT = int.Parse(row["UNCL_CUT_AMT"].ToString());

                    return true;
                }
                else
                {
                    LogService.DebugLog(String.Format("Patient Bill not found.({0})", pid));
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return false;
        }

        #endregion Method : SelectData Method


        #region Method : SaveData Method


        /// <summary>
        /// 영수증정보를 생성한다.
        /// 미수발생한다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool SavePaObilBd(ref string msg)
        {
            DataTable dtPaObilBd = new DataTable();

            if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOBILBD(), ref dtPaObilBd, m_PID
                                                                                      , m_PT_CMHS_NO.ToString()
                                                                                      , m_ROW_STAT_DVCD))
            {
                if (dtPaObilBd.Rows.Count > 0)
                {
                    bool is7AF = false;
                    // 입원시 OR 입원취소시
                    if ((this.AFRS_STAT_DVCD == "7" && this.ROW_STAT_DVCD == "A" && this.NEW_ROW_STAT_DVCD == "F") ||
                        (this.AFRS_STAT_DVCD == "9" && this.ROW_STAT_DVCD == "F" && this.NEW_ROW_STAT_DVCD == "D") ||
                        (this.AFRS_STAT_DVCD == "9" && this.ROW_STAT_DVCD == "I" && this.NEW_ROW_STAT_DVCD == "A"))
                        is7AF = true;

                    DataRow row = dtPaObilBd.Rows[0];
                    m_PID = row["PID"].ToString();
                    m_PT_CMHS_NO = int.Parse(row["PT_CMHS_NO"].ToString());
                    m_RCPT_SQNO = m_NEW_RCPT_RQNO;
                    m_MDCR_DD = row["MDCR_DD"].ToString();
                    m_INSN_TYCD = row["INSN_TYCD"].ToString();
                    m_ASST_TYCD = row["ASST_TYCD"].ToString();
                    m_ASCT_RGNO_CD = row["ASCT_RGNO_CD"].ToString();
                    m_MDCR_DEPT_CD = row["MDCR_DEPT_CD"].ToString();
                    m_MDCR_DR_CD = row["MDCR_DR_CD"].ToString();
                    m_TOTL_MDCR_AMT = m_STATVAL1 * int.Parse(row["TOTL_MDCR_AMT"].ToString());
                    m_PAY_TAMT = m_STATVAL1 * int.Parse(row["PAY_TAMT"].ToString());
                    m_INSN_100_TAMT = m_STATVAL1 * int.Parse(row["INSN_100_TAMT"].ToString());
                    m_SCNG_PAY_TAMT = m_STATVAL1 * int.Parse(row["SCNG_PAY_TAMT"].ToString());
                    m_NOPY_TAMT = m_STATVAL1 * int.Parse(row["NOPY_TAMT"].ToString());
                    m_CLAM_NOPY_TAMT = m_STATVAL1 * int.Parse(row["CLAM_NOPY_TAMT"].ToString());
                    m_ADED_VALU_TAX_TAMT = m_STATVAL1 * int.Parse(row["ADED_VALU_TAX_TAMT"].ToString());
                    m_VTRN_TAMT = m_STATVAL1 * int.Parse(row["VTRN_TAMT"].ToString());
                    m_BYKN_ADTN_AMT = m_STATVAL1 * int.Parse(row["BYKN_ADTN_AMT"].ToString());
                    m_SMCR_AMT = m_STATVAL1 * int.Parse(row["SMCR_AMT"].ToString());
                    m_PAY_USCH_AMT = m_STATVAL1 * int.Parse(row["PAY_USCH_AMT"].ToString());
                    m_SCNG_PAY_USCH_AMT = m_STATVAL1 * int.Parse(row["SCNG_PAY_USCH_AMT"].ToString());
                    m_PAY_CLAM_AMT = m_STATVAL1 * int.Parse(row["PAY_CLAM_AMT"].ToString());
                    m_SCNG_PAY_CLAM_AMT = m_STATVAL1 * int.Parse(row["SCNG_PAY_CLAM_AMT"].ToString());
                    m_MDCN_UPLM_DIAM = m_STATVAL1 * int.Parse(row["MDCN_UPLM_DIAM"].ToString());
                    m_HMPT_PAY_TAMT = m_STATVAL1 * int.Parse(row["HMPT_PAY_TAMT"].ToString());
                    m_DSBL_FUND_AMT = m_STATVAL1 * int.Parse(row["DSBL_FUND_AMT"].ToString());
                    m_PFAN_AMT = m_STATVAL1 * int.Parse(row["PFAN_AMT"].ToString());
                    m_USCH_UPLM_AMT = m_STATVAL1 * int.Parse(row["USCH_UPLM_AMT"].ToString());
                    m_SUPT_AMT = m_STATVAL1 * int.Parse(row["SUPT_AMT"].ToString());
                    m_EMRG_SUPT_AMT = m_STATVAL1 * int.Parse(row["EMRG_SUPT_AMT"].ToString());
                    m_TBRC_CTCT_SUPT_AMT = m_STATVAL1 * int.Parse(row["TBRC_CTCT_SUPT_AMT"].ToString());
                    m_MTWM_CLAM_AMT = m_STATVAL1 * int.Parse(row["MTWM_CLAM_AMT"].ToString());
                    m_MTWM_BLCE = m_STATVAL1 * int.Parse(row["MTWM_BLCE"].ToString());
                    m_MTWM_PAY_CLAM_AMT = m_STATVAL1 * int.Parse(row["MTWM_PAY_CLAM_AMT"].ToString());
                    m_MTWM_I100_CLAM_AMT = m_STATVAL1 * int.Parse(row["MTWM_I100_CLAM_AMT"].ToString());
                    m_MTWM_NOPY_CLAM_AMT = m_STATVAL1 * int.Parse(row["MTWM_NOPY_CLAM_AMT"].ToString());
                    m_MTWM_SCPY_CLAM_AMT = m_STATVAL1 * int.Parse(row["MTWM_SCPY_CLAM_AMT"].ToString());
                    m_INDP_MOMR_CLAM_AMT = m_STATVAL1 * int.Parse(row["INDP_MOMR_CLAM_AMT"].ToString());
                    m_VCNT_CLAM_AMT = m_STATVAL1 * int.Parse(row["VCNT_CLAM_AMT"].ToString());
                    m_CT_USCH_AMT = m_STATVAL1 * int.Parse(row["CT_USCH_AMT"].ToString());
                    m_MRI_USCH_AMT = m_STATVAL1 * int.Parse(row["MRI_USCH_AMT"].ToString());
                    m_PET_USCH_AMT = m_STATVAL1 * int.Parse(row["PET_USCH_AMT"].ToString());
                    m_FRTM_CARD_RCPT_AMT = m_STATVAL3 * int.Parse(row["FRTM_CARD_RCPT_AMT"].ToString());
                    m_FRTM_CASH_RCPT_AMT = m_STATVAL3 * int.Parse(row["FRTM_CASH_RCPT_AMT"].ToString());
                    m_FRTM_BNAC_AMT = m_STATVAL3 * int.Parse(row["FRTM_BNAC_AMT"].ToString());
                    m_VTRN_RNE_AMT = m_STATVAL1 * int.Parse(row["VTRN_RNE_AMT"].ToString());
                    m_DCNT_RDIA_CD = row["DCNT_RDIA_CD"].ToString();
                    m_DCNT_RDIA_EMNO = row["DCNT_RDIA_EMNO"].ToString();
                    m_DCNT_RDIA_AMT = m_STATVAL1 * int.Parse(row["DCNT_RDIA_AMT"].ToString());
                    m_FRTM_DCNT_RDIA_AMT = m_STATVAL1 * int.Parse(row["FRTM_DCNT_RDIA_AMT"].ToString());
                    m_SPCL_DCNT_DVCD = row["SPCL_DCNT_DVCD"].ToString();
                    m_SPCL_DCNT_AMT = m_STATVAL1 * int.Parse(row["SPCL_DCNT_AMT"].ToString());
                    m_BLDN_YN = row["BLDN_YN"].ToString();
                    m_BLOD_RDIA_AMT = m_STATVAL1 * int.Parse(row["BLOD_RDIA_AMT"].ToString());
                    m_VTRD_APLY_DVCD = row["VTRD_APLY_DVCD"].ToString();
                    m_VTRD_AMT = m_STATVAL1 * int.Parse(row["VTRD_AMT"].ToString());
                    m_CTTR_NO_CD = row["CTTR_NO_CD"].ToString();
                    m_CTTR_UNCL_APLY_AMT = m_STATVAL1 * int.Parse(row["CTTR_UNCL_APLY_AMT"].ToString());
                    m_CLNC_UNCL_APLY_AMT = m_STATVAL1 * int.Parse(row["CLNC_UNCL_APLY_AMT"].ToString());
                    m_GURN_CARD_AMT = m_STATVAL1 * int.Parse(row["GURN_CARD_AMT"].ToString());
                    m_GURN_CASH_AMT = m_STATVAL1 * int.Parse(row["GURN_CASH_AMT"].ToString());
                    m_GURN_BNAC_AMT = m_STATVAL1 * int.Parse(row["GURN_BNAC_AMT"].ToString());
                    m_HLLF_MNCS_CLAM_AMT = m_STATVAL1 * int.Parse(row["HLLF_MNCS_CLAM_AMT"].ToString());
                    m_HLLF_MNCS_BLCE = m_STATVAL1 * int.Parse(row["HLLF_MNCS_BLCE"].ToString());
                    m_PT_SHAR_AMT = m_STATVAL1 * int.Parse(row["PT_SHAR_AMT"].ToString());
                    m_TRNC_AMT = m_STATVAL1 * int.Parse(row["TRNC_AMT"].ToString());
                    m_CARD_RCPT_AMT = m_STATVAL2 * int.Parse(row["CARD_RCPT_AMT"].ToString());
                    m_BANO = row["BANO"].ToString();
                    m_BNAC_DPPR_NM = row["BNAC_DPPR_NM"].ToString();
                    m_BNAC_DPST_DD = row["BNAC_DPST_DD"].ToString();
                    m_BNAC_RCPT_AMT = m_STATVAL2 * int.Parse(row["BNAC_RCPT_AMT"].ToString());
                    m_CASH_RCPT_AMT = m_STATVAL2 * int.Parse(row["CASH_RCPT_AMT"].ToString());
                    m_RFND_RESN = row["RFND_RESN"].ToString();
                    m_DCNT_RESN = row["DCNT_RESN"].ToString();
                    m_UNCL_RESN = row["UNCL_RESN"].ToString();
                    m_CASH_PRMT_YN = row["CASH_PRMT_YN"].ToString();
                    m_MDAD_PRMT_NO = row["MDAD_PRMT_NO"].ToString();
                    m_FXAM_MCCS = m_STATVAL1 * int.Parse(row["FXAM_MCCS"].ToString());
                    m_FXAM_MCCS_REAL_AMT = m_STATVAL1 * int.Parse(row["FXAM_MCCS_REAL_AMT"].ToString());
                    m_UNCL_CD = row["UNCL_CD"].ToString();
                    m_UNCL_AMT = m_STATVAL1 * int.Parse(row["UNCL_AMT"].ToString());

                    m_GVRN_CLAM_AMT = m_STATVAL1 * int.Parse(row["GVRN_CLAM_AMT"].ToString());

                    m_RCPT_DD = row["RCPT_DD"].ToString();
                    m_RCPT_TIME = row["RCPT_TIME"].ToString();
                    m_ROW_STAT_DVCD = m_NEW_ROW_STAT_DVCD;
                    m_DLWT_IP_ADDR = row["DLWT_IP_ADDR"].ToString();

                    // 입원전환에서 7AF의 경우, 기영수금액 +  영수금액을 => 기영수금액으로 세팅한다.
                    if (is7AF)
                    {
                        m_FRTM_CARD_RCPT_AMT = m_STATVAL3 * (int.Parse(row["FRTM_CARD_RCPT_AMT"].ToString()) + int.Parse(row["CARD_RCPT_AMT"].ToString()));  //이전카드수납금액 <= 카드수납금액
                        m_FRTM_CASH_RCPT_AMT = m_STATVAL3 * (int.Parse(row["FRTM_CASH_RCPT_AMT"].ToString()) + int.Parse(row["CASH_RCPT_AMT"].ToString()));  //이전카드수납금액 <= 카드수납금액
                        m_FRTM_BNAC_AMT = m_STATVAL3 * (int.Parse(row["FRTM_BNAC_AMT"].ToString()) + int.Parse(row["BNAC_RCPT_AMT"].ToString()));       //이전카드수납금액 <= 카드수납금액
                    }

                    if (!InsertPaObilBd(ref msg))
                        return false;

                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 외래영수내역 INSERT
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool InsertPaObilBd(ref string msg)
        {
            bool success = true;

            if (!DBService.ExecuteNonQuery(SQL.PA.BaseSql.Insert.PAOBILBD(), m_PID
                                                                           , m_PT_CMHS_NO.ToString()
                                                                           , m_RCPT_SQNO.ToString()
                                                                           , m_MDCR_DD
                                                                           , m_BILL_NO
                                                                           , m_RCPT_OCRR_UNIQ_NO
                                                                           , m_INSN_TYCD
                                                                           , m_ASST_TYCD
                                                                           , m_ASCT_RGNO_CD
                                                                           , m_MDCR_DEPT_CD
                                                                           , m_MDCR_DR_CD
                                                                           , m_TOTL_MDCR_AMT.ToString()
                                                                           , m_PAY_TAMT.ToString()
                                                                           , m_INSN_100_TAMT.ToString()
                                                                           , m_SCNG_PAY_TAMT.ToString()
                                                                           , m_NOPY_TAMT.ToString()
                                                                           , m_CLAM_NOPY_TAMT.ToString()
                                                                           , m_ADED_VALU_TAX_TAMT.ToString()
                                                                           , m_VTRN_TAMT.ToString()
                                                                           , m_BYKN_ADTN_AMT.ToString()
                                                                           , m_SMCR_AMT.ToString()
                                                                           , m_PAY_USCH_AMT.ToString()
                                                                           , m_SCNG_PAY_USCH_AMT.ToString()
                                                                           , m_PAY_CLAM_AMT.ToString()
                                                                           , m_SCNG_PAY_CLAM_AMT.ToString()
                                                                           , m_MDCN_UPLM_DIAM.ToString()
                                                                           , m_HMPT_PAY_TAMT.ToString()
                                                                           , m_DSBL_FUND_AMT.ToString()
                                                                           , m_PFAN_AMT.ToString()
                                                                           , m_USCH_UPLM_AMT.ToString()
                                                                           , m_SUPT_AMT.ToString()
                                                                           , m_EMRG_SUPT_AMT.ToString()
                                                                           , m_TBRC_CTCT_SUPT_AMT.ToString()
                                                                           , m_MTWM_CLAM_AMT.ToString()
                                                                           , m_MTWM_BLCE.ToString()
                                                                           , m_MTWM_PAY_CLAM_AMT.ToString()
                                                                           , m_MTWM_I100_CLAM_AMT.ToString()
                                                                           , m_MTWM_NOPY_CLAM_AMT.ToString()
                                                                           , m_MTWM_SCPY_CLAM_AMT.ToString()
                                                                           , m_INDP_MOMR_CLAM_AMT.ToString()
                                                                           , m_VCNT_CLAM_AMT.ToString()
                                                                           , m_CT_USCH_AMT.ToString()
                                                                           , m_MRI_USCH_AMT.ToString()
                                                                           , m_PET_USCH_AMT.ToString()
                                                                           , m_FRTM_CARD_RCPT_AMT.ToString()
                                                                           , m_FRTM_CASH_RCPT_AMT.ToString()
                                                                           , m_FRTM_BNAC_AMT.ToString()
                                                                           , m_VTRN_RNE_AMT.ToString()
                                                                           , m_DCNT_RDIA_CD
                                                                           , m_DCNT_RDIA_EMNO
                                                                           , m_DCNT_RDIA_AMT.ToString()
                                                                           , m_FRTM_DCNT_RDIA_AMT.ToString()
                                                                           , m_SPCL_DCNT_DVCD
                                                                           , m_SPCL_DCNT_AMT.ToString()
                                                                           , m_BLDN_YN
                                                                           , m_BLOD_RDIA_AMT.ToString()
                                                                           , m_VTRD_APLY_DVCD
                                                                           , m_VTRD_AMT.ToString()
                                                                           , m_CTTR_NO_CD
                                                                           , m_CTTR_UNCL_APLY_AMT.ToString()
                                                                           , m_CLNC_UNCL_APLY_AMT.ToString()
                                                                           , m_GURN_CARD_AMT.ToString()
                                                                           , m_GURN_CASH_AMT.ToString()
                                                                           , m_GURN_BNAC_AMT.ToString()
                                                                           , m_HLLF_MNCS_CLAM_AMT.ToString()
                                                                           , m_HLLF_MNCS_BLCE.ToString()
                                                                           , m_PT_SHAR_AMT.ToString()
                                                                           , m_TRNC_AMT.ToString()
                                                                           , ""   // 카드회사코드
                                                                           , m_CARD_RCPT_AMT.ToString()
                                                                           , m_BANO
                                                                           , m_BNAC_DPPR_NM
                                                                           , m_BNAC_DPST_DD
                                                                           , m_BNAC_RCPT_AMT.ToString()
                                                                           , m_CASH_RCPT_AMT.ToString()
                                                                           , m_RFND_RESN
                                                                           , m_DCNT_RESN
                                                                           , m_UNCL_RESN
                                                                           , m_CASH_PRMT_YN
                                                                           , m_MDAD_PRMT_NO
                                                                           , m_FXAM_MCCS.ToString()
                                                                           , m_FXAM_MCCS_REAL_AMT.ToString()
                                                                           , m_UNCL_CD
                                                                           , m_UNCL_AMT.ToString()
                                                                           , ""   // 
                                                                           , m_RCPT_DD
                                                                           , m_RCPT_TIME
                                                                           , m_AFRS_STAT_DVCD
                                                                           , m_ROW_STAT_DVCD
                                                                           , m_DLWT_IP_ADDR
                                                                           , m_RGST_DT
                                                                           , m_RGSTR_ID
                                                                           , m_GVRN_CLAM_AMT.ToString()))
            {

                msg = DBService.ErrorMessage + "\r\n 외래영수내역 발생중 오류발생[ ROW_STAT_DVCD = " + m_ROW_STAT_DVCD + " ]";
                DBService.RollbackTransaction();
                success = false;
            }

            //this.Clear();
            return success;
        }
        /// <summary>
        /// 외래영수내역 행상태구분코드 UPDATE
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool UpdateRowStatDvcdOfPaObilBd(ref string msg)
        {
            bool success = true;

            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePAOBILBD_RowStatDvcd(), this.PID
                                                                                  , this.PT_CMHS_NO.ToString()
                                                                                  , this.ROW_STAT_DVCD
                                                                                  , this.NEW_ROW_STAT_DVCD))
            {
                success = false;
                msg = DBService.ErrorMessage + "\r\n 외래영수내역의 행상태구분코드 변경중 오류가 발생하였습니다. 확인하시기 바랍니다.";
                DBService.RollbackTransaction();
            }
            return success;
        }

        #endregion Method : SaveData Method

        #endregion Method : Public Method

        #region Method : Private Method
        public bool CreateUnclOcrrInfo(string cfsc_rgno_cd, ref string msg)
        {
            try
            {
                // 미수발생금액을 생성한다.

                // 미수발생기본정보를 가져온다.
                if (!this.GetUnclOcrrInfo())
                {
                    DBService.RollbackTransaction();
                    return false;
                }

                // 재난지원
                var temp = DBService.ExecuteScalar(SQL.PA.Sql.SelectPATRTEIF_ETC21(m_UnclOcrrInfo.PID, m_UnclOcrrInfo.PT_CMHS_NO.ToString())).ToString();

                // 미수발생구분별로 미수금액을 설정한다.
                foreach (DataRow row in OverallCodeList.GetDataList("UNCL_OCRR_DVCD").Rows)
                {
                    m_UnclOcrrInfo.UNCL_OCRR_DVCD = row["LWRN_OVRL_CD"].ToString();

                    switch (row["LWRN_OVRL_CD"].ToString())
                    {
                        case "*":                   // 개인미수
                            m_UnclOcrrInfo.UNCL_AMT = this.m_UNCL_AMT;
                            break;
                        case "CHUNG":               // 청구미수 자보, 산재
                            if ((this.m_INSN_TYCD.Equals("31") && (this.m_ASST_TYCD.Equals("00") || this.m_ASST_TYCD.Equals("G"))) || (this.m_INSN_TYCD.Equals("41") && this.ASST_TYCD.Equals("00")))
                            {
                                m_UnclOcrrInfo.UNCL_AMT = this.m_PAY_CLAM_AMT;
                                m_UnclOcrrInfo.UNCL_CD = "NO";
                            }
                            break;
                        case "BLOOD":               // 혈액미수
                            m_UnclOcrrInfo.UNCL_AMT = this.m_BLOD_RDIA_AMT;
                            break;
                        case "BOHUN":               // 보훈미수
                            m_UnclOcrrInfo.UNCL_AMT = this.m_VTRN_TAMT;
                            break;
                        case "UBOHN":               // 보훈감면
                            m_UnclOcrrInfo.UNCL_AMT = this.m_VTRN_RNE_AMT;
                            break;
                        case "IBOHN":               // 독립유공
                            m_UnclOcrrInfo.UNCL_AMT = this.m_INDP_MOMR_CLAM_AMT;
                            break;
                        case "VACC":                // 예방접종
                            m_UnclOcrrInfo.UNCL_AMT = this.m_VCNT_CLAM_AMT;
                            break;
                        case "VACCT":               // 수직감면
                            m_UnclOcrrInfo.UNCL_AMT = this.m_VTRD_AMT;
                            break;
                        case "IMERG":               // 의료비지원
                            m_UnclOcrrInfo.UNCL_AMT = this.m_EMRG_SUPT_AMT;
                            break;
                        case "PEDTB":               // 결핵접촉
                            m_UnclOcrrInfo.UNCL_AMT = this.m_TBRC_CTCT_SUPT_AMT;

                            if (cfsc_rgno_cd.Contains("F009"))
                                m_UnclOcrrInfo.UNCL_AMT += this.m_SUPT_AMT;
                            break;
                        case "COMPC":               // 계약업체미수
                            m_UnclOcrrInfo.UNCL_AMT = this.m_CTTR_UNCL_APLY_AMT;
                            break;

                        case "STSMO":               // 금연미수
                            if (this.m_ASST_TYCD.Equals("91") || this.m_ASST_TYCD.Equals("9C"))
                            {
                                m_UnclOcrrInfo.UNCL_AMT = this.m_PAY_CLAM_AMT;
                                m_UnclOcrrInfo.UNCL_CD = "NO";
                            }
                            break;

                        // 2020-02-26 이후부터 적용 SJH
                        case "COVID":
                            if (this.m_ASST_TYCD.Contains("0T") || temp.Contains("CVD"))
                                m_UnclOcrrInfo.UNCL_AMT = this.m_SUPT_AMT;
                            break;

                        // 2020-03-01 이후부터 적용 SJH
                        case "RARE":
                            if (this.m_INSN_TYCD.Length > 0 && (this.m_INSN_TYCD.Substring(0, 1).Equals("1") || this.m_INSN_TYCD.Substring(0, 1).Equals("2")) &&
                                this.m_ASST_TYCD.Contains("H"))
                                m_UnclOcrrInfo.UNCL_AMT = this.m_SUPT_AMT;
                            break;

                        // 2020-09-15 추가함 SJH
                        case "GVRN":
                            if (this.m_INSN_TYCD.Equals("11") && this.m_ASST_TYCD.Equals("G"))
                                m_UnclOcrrInfo.UNCL_AMT = this.m_GVRN_CLAM_AMT;
                            break;
                    }

                    // 미수발생정보를 생성한다.
                    if (!m_UnclOcrrInfo.SavePAUNCOMA(ref msg))
                    {
                        DBService.RollbackTransaction();
                        return false;
                    }
                    m_UnclOcrrInfo.UNCL_AMT = 0;
                }
                return true;

            }
            catch (Exception ex)
            {
                DBService.RollbackTransaction();
                msg = ex.Message;
                return false;
            }
        }

        /// <summary>
        /// 미수발생 기본정보를 가져온다.
        /// </summary>
        /// <returns></returns>
        private bool GetUnclOcrrInfo()
        {
            try
            {
                m_UnclOcrrInfo.PID = this.m_PID;
                //m_UnclOcrrInfo.UNCL_OCRR_SQNO         = ;
                m_UnclOcrrInfo.OTPT_ADMS_DVCD = "O";
                m_UnclOcrrInfo.PT_CMHS_NO = this.m_PT_CMHS_NO;
                m_UnclOcrrInfo.UNCL_CD = this.m_UNCL_CD;
                m_UnclOcrrInfo.RCPT_SQNO = this.m_RCPT_SQNO;
                m_UnclOcrrInfo.MDCR_DD = this.m_MDCR_DD;
                m_UnclOcrrInfo.CMPY_STRT_DD = this.m_MDCR_DD;
                m_UnclOcrrInfo.CMPY_END_DD = this.m_MDCR_DD;
                m_UnclOcrrInfo.MDCR_DEPT_CD = this.m_MDCR_DEPT_CD;
                m_UnclOcrrInfo.MDCR_DR_CD = this.m_MDCR_DR_CD;
                m_UnclOcrrInfo.INSN_TYCD = this.m_INSN_TYCD;
                m_UnclOcrrInfo.ASST_TYCD = this.m_ASST_TYCD;
                m_UnclOcrrInfo.CMHS_DVCD = String.Empty;
                m_UnclOcrrInfo.TOTL_MDCR_AMT = this.m_TOTL_MDCR_AMT;
                // 급여청구금액 +  장애인기금+ 보훈청구액 + 청구비급여총액 + 건생비청구금액 +
                // 산모청구금액 + 예방접종청구금액 + 수직감염금액 + 보훈감면금액 + 긴급지원금액 +
                // 결핵접촉지원금액 + 지원금액 + 계약처미수적용금액 + 선별급여청구금액
                m_UnclOcrrInfo.PAY_TAMT = this.m_PAY_TAMT;
                m_UnclOcrrInfo.NOPY_TAMT = this.m_NOPY_TAMT + this.m_INSN_100_TAMT + this.SCNG_PAY_USCH_AMT; // 비급여총액 + 보험100% + 선별급여본인부담금액 + 간병비총액
                m_UnclOcrrInfo.PAY_CLAM_AMT = this.m_PAY_CLAM_AMT + this.m_DSBL_FUND_AMT + this.m_VTRD_AMT + this.m_CLAM_NOPY_TAMT + this.m_HLLF_MNCS_CLAM_AMT +
                                                        this.m_MTWM_CLAM_AMT + this.m_VCNT_CLAM_AMT + this.m_VTRD_AMT + this.m_VTRN_RNE_AMT + this.m_EMRG_SUPT_AMT +
                                                        this.m_TBRC_CTCT_SUPT_AMT + this.m_SUPT_AMT + this.m_CTTR_UNCL_APLY_AMT + this.m_SCNG_PAY_CLAM_AMT; ;
                m_UnclOcrrInfo.PAY_USCH_AMT = this.m_PAY_USCH_AMT;
                m_UnclOcrrInfo.DCNT_RDIA_AMT = this.m_DCNT_RDIA_AMT;
                m_UnclOcrrInfo.CARD_RCPT_AMT = this.m_CARD_RCPT_AMT;
                m_UnclOcrrInfo.BNAC_RCPT_AMT = this.m_BNAC_RCPT_AMT;
                m_UnclOcrrInfo.CASH_RCPT_AMT = this.m_CASH_RCPT_AMT;
                m_UnclOcrrInfo.CTTR_NO_CD = this.m_CTTR_NO_CD.ToString();
                m_UnclOcrrInfo.RCPT_OCRR_UNIQ_NO = this.m_RCPT_OCRR_UNIQ_NO;
                m_UnclOcrrInfo.UNCL_OCRR_PCFT = this.m_UNCL_RESN;
                m_UnclOcrrInfo.PCLR_MATR = String.Empty;
                m_UnclOcrrInfo.PTAF_CLSN_YN = "N";
                m_UnclOcrrInfo.RCPT_DD = this.RCPT_DD;
                m_UnclOcrrInfo.RCPT_TIME = this.RCPT_TIME;
                m_UnclOcrrInfo.ETC_USE_CNTS_1 = String.Empty;
                m_UnclOcrrInfo.ETC_USE_CNTS_2 = String.Empty;
                m_UnclOcrrInfo.ETC_USE_CNTS_3 = String.Empty;
                m_UnclOcrrInfo.ETC_USE_CNTS_4 = String.Empty;
                m_UnclOcrrInfo.ETC_USE_CNTS_5 = String.Empty;
                m_UnclOcrrInfo.ROW_STAT_DVCD = "A";
                m_UnclOcrrInfo.RGST_DT = DateTimeService.NowDateTimeNoneSeperatorString();
                m_UnclOcrrInfo.RGSTR_ID = DOPack.UserInfo.USER_CD;
                m_UnclOcrrInfo.UPDT_DT = DateTimeService.NowDateTimeNoneSeperatorString();
                m_UnclOcrrInfo.UPDTR_ID = DOPack.UserInfo.USER_CD;

                string dcntrdiacd = StringService.IsNvl(this.m_DCNT_RDIA_CD, "NO");

                if (this.INSN_TYCD.Equals("31") && this.ASST_TYCD.Equals("G") && dcntrdiacd.Substring(0, 2).Equals("SG"))
                {
                    m_UnclOcrrInfo.UNCL_AJAM = this.m_DCNT_RDIA_AMT;
                    m_UnclOcrrInfo.DCNT_RDIA_AMT = 0;
                }
                else
                {
                    m_UnclOcrrInfo.UNCL_AJAM = 0;
                }
                return true;

            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
        }
        #endregion Method : Private Method

    }
}
