package web.townsi.com.work.setting.biz;

import java.util.HashMap;

public interface SettingRepoBiz {
	public abstract HashMap<String, Object> makeRepo(HashMap paramHashMap) throws Exception;
}