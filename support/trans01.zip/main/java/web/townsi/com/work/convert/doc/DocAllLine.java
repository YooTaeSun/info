package web.townsi.com.work.convert.doc;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import web.townsi.com.utils.Util;

public class DocAllLine {

	public static StringBuilder contentSb = null;
	public static String strOfLine = "<rEaDlInE>";
	
	public static String getClassNm(String content, String onlyFileNm) {
		
		List<String> classNmList = new ArrayList<String>();
		String retVal =  "";
		
		String[] str_araay = content.split("\\r\\n");
		List<String> list = Arrays.asList(str_araay);
		String noBlankLine = "";
		String line = "";
		String lineChg = "";
		String regex = "";
		String classNm = "";
		
		for (int i = 0; i < list.size(); i++) {
			line = list.get(i);
			
			
			noBlankLine = Util.removeBlank(line);
			if (noBlankLine.contains(Util.removeBlank(" class "))) {
				
				String[] array = line.split("\\s");
				
				regex = "";
				for (int j = 0; j < array.length; j++) {
					String s = array[j].trim();
					if (!array[j].trim().isEmpty()) {
						regex += s + "[\\s]*";
						if (s.equals("class")) {
							break;
						}
					}
				}
				
				lineChg = line.replaceAll(regex, "");
				if (!lineChg.equals(line)) {
					classNm = lineChg.trim();
					if (classNm.contains(":")) {
						classNm = classNm.substring(0, classNm.indexOf(":")).trim();
					} 
					if (classNm.equals(onlyFileNm)) {
						retVal = classNm;
						classNmList.clear();
						break;
					} else {
						if (!classNm.isEmpty()) {
							classNmList.add(classNm);	
						}
					}
					
					
				}
			}
		}
		
		if (classNmList.size() > 0) {
			retVal =  classNmList.get(0);	
		}
		
		return retVal;
	}
	
	public static String removeLargeBracket(String content, String docType) {
		if (docType.equals("TS")) {
			if (content.contains("export ")) {
				content = content.replaceFirst("\\{", "");
				content = removeLastStr(content, "}", 1);
			}
		} else if (docType.equals("VUE")) {
			if (content.contains(Doc.IMPORT_START_STR)) {
				content = content.replaceFirst("\\{", "").replaceFirst("\\{", "");
				content = removeLastStr(content, "}", 2);
			}
		}
		return content;
	}	
	
	private static String removeLastStr(String content, String targetStr, int repeatCnt) {

		int totalLength = -1;
		int idx = -1;

		for (int i = 0; i < repeatCnt; i++) {
			totalLength = content.length();
			idx = content.lastIndexOf(targetStr);
			content = content.substring(0, idx - 1) + content.substring(idx + 1, totalLength);
		}

		return content;
	}
	
	public static String convertAllLine(String docType, String content) {
		contentSb = new StringBuilder(1024 * 10);
		content = content.replaceAll("\r\n", strOfLine);
		String reContent =  chgGetSetObj(docType, content);
		content = contentSb.toString() + reContent;
		content = content.replaceAll(strOfLine, "\r\n");
		return content;
	}
	
	public static String chgGetSetObj(String docType, String content) {
		Pattern pattern = Pattern.compile("[\\s]+public(.*?)[{]");
//		Pattern pattern = Pattern.compile("[\\s]+public[\\s]+(.*?)[\\s]+[{]");
//		Pattern pattern = Pattern.compile("[\\s]+public[\\s{0,}](.*?)[\\s{0,}]*[{]");

		Matcher matcher = pattern.matcher(content);
		int sIdx = -1;
		boolean isChg = false;
		String chgStr = "";
		int idxGetEnd = -1;
		int idxSetEnd = -1;
		int idxGetStart = -1;
		int idxSetStart = -1;
		boolean isGet = false;
		boolean isSet = false;
		String get = "";
		String set = "";
		String all = "";
		
		if (matcher.find()) {

			String targetWord = matcher.group(0);
			String spaceVal = matcher.group(1).trim();
			String target = targetWord.replace("{", "").replace("<rEaDlInE>", "").trim();
			
//			System.out.println(" targetWord >> " + targetWord);
//			System.out.println(" spaceVal >> " + spaceVal);
			
			int idx1 = content.indexOf(targetWord);
			all = content.substring(idx1);
			all = Util.findBracketPairStr(all);
			String all2 = all.replaceAll(strOfLine, "\r\n");
			
			int cnt = -1;
			if (spaceVal.contains("static ")) {
				cnt = spaceVal.trim().split(" ").length - 1;
			} else {
				cnt = spaceVal.trim().split(" ").length;
			}
			
			if (!spaceVal.contains("class ") && (cnt <= 2 || spaceVal.trim().split("\\s").length <= 2)) {
				
				try {
						
					if (all.contains(" get") && !all.contains(" get;")) {
						isGet = true;
						idxGetStart = all.indexOf("get");
//						all = Util.findBracketPairStr(all);
					}
					if (all.contains(" set") && !all.contains(" set;")) {
						isSet = true;
						idxSetStart = all.indexOf("set");
					}
					
					if (isGet || isSet) {
						if (isGet) {
							get = Util.findBracketPairStr(all.substring(idxGetStart));
						} 
						if (isSet) {
							set = Util.findBracketPairStr(all.substring(idxSetStart));							idxSetEnd = all.indexOf("}");
						}
						
						String noBlanAll = Util.removeBlank(all).replaceAll(strOfLine, "");
						int cnt01 = StringUtils.countMatches(noBlanAll, "{");
						int cnt02 = StringUtils.countMatches(noBlanAll, "}");
					
						isChg = true;
						String allVari = all.substring(0, all.indexOf("{"));
						String startBlank = Util.makeStartBlank(allVari);
						String[] targetArray = target.trim().split("\\s");
						String type = targetArray[targetArray.length - 1].replace("<rEaDlInE>", "");
	
						String get3 = "";
						String set3 = "";
						
						if (get.contains("get") && set.contains("set")) {
							if (docType.equals("TS")) {
								if (target.contains("static")) {
									get3 = get.replace("get", startBlank + "static get " + type + "()");
									set3 = set.replace("set", startBlank + "static set " + type + "(value: any)");
								} else {
									get3 = get.replace("get", startBlank + "get " + type + "()");
									set3 = set.replace("set", startBlank + "set " + type + "(value: any)");
								}
								chgStr = (get3 + "<rEaDlInE>" + set3);
							} else {
								get3 = get.replace("get", startBlank + "get" + "() ");
								set3 = set.replace("set", startBlank + "set" + "(value: any) ");
								chgStr = startBlank + "const "+ type +" = $computed({"
										+ "<rEaDlInE>" + Util.TAB_SIZE + get3 + ", "
										+ "<rEaDlInE>" + Util.TAB_SIZE + set3
										+ "<rEaDlInE>" + startBlank + "});";
							}
							content = content.replace(all, chgStr);
							
							
						} else if (get.contains("get")) {
							if (docType.equals("TS")) {
								if (target.contains("static")) {
									get3 = get.replace("get", startBlank + "static get " + type + "()");
								} else {
									get3 = get.replace("get", startBlank + "get " + type + "()");
								}
								chgStr = (get3 + "<rEaDlInE>");
								
							} else {
	//							get3 = get.replace("get", startBlank + "get " + type + "()");
	//							chgStr = startBlank + "const "+ type +" = $computed({"
	//									+ "<rEaDlInE>" + startBlank + Util.TAB_SIZE + get
	//									+ "<rEaDlInE>" + startBlank + "});";
								get3 = get.replace("get", startBlank + "get()");
								chgStr = startBlank + "const "+ type +" = $computed({"
										+ "<rEaDlInE>" + Util.TAB_SIZE + get3
										+ "<rEaDlInE>" + startBlank + "});";							
							}
							content = content.replace(all, chgStr);
							
						} else if (set.contains("set")) {
							if (docType.equals("TS")) {
								if (target.contains("static")) {
									set3 = set.replace("set", startBlank + "static set " + type + "()");
								} else {
									set3 = set.replace("set", startBlank + "set " + type + "()");
								}
								chgStr = (set3 + "<rEaDlInE>");
								
							} else {
								set3 = set.replace("set", startBlank + "set" + "(value: any)");
								chgStr = startBlank + "const "+ type +" = $computed({"
										+ "<rEaDlInE>" + Util.TAB_SIZE + set3
										+ "<rEaDlInE>" + startBlank + "});";
							}
							content = content.replace(all, chgStr);
						}		
						
					}
					//여기서 {} 안에 있는 문자열만
					
				} catch (Exception e) {
					int lineIdx = targetWord.indexOf("<rEaDlInE>");
					if (lineIdx > -1) {
						lineIdx = lineIdx + "<rEaDlInE>".length();
						targetWord = targetWord.substring(0, lineIdx);
					}
				}
	
			} else {
				int lineIdx = targetWord.indexOf("<rEaDlInE>");
				if (lineIdx > -1) {
					lineIdx = lineIdx + "<rEaDlInE>".length();
					targetWord = targetWord.substring(0, lineIdx);
				}
			}

			if (!isChg) {
				sIdx = content.indexOf(targetWord) + targetWord.length();
				String sliceStr = content.substring(0, sIdx);
				contentSb.append(sliceStr);
				content = content.substring(sIdx, content.length());
			} else {
				sIdx = content.indexOf(chgStr) + chgStr.length();
				String sliceStr = content.substring(0, sIdx);
				contentSb.append(sliceStr);
				content = content.substring(sIdx, content.length());
			}

			return chgGetSetObj(docType, content);
		} else {
			return content;
		}
	}
	





}