
namespace Lime.Framework.BusinessService
{
    public class clsNhisM4
    {
        #region [ 공단 제공 변수 ]

        /// <summary>
        /// DB에 저장할 환자번호
        /// </summary>
        public string PID = string.Empty;

        /// <summary>
        /// 외래입원여부
        /// </summary>
        public string OTPT_ADMS_YN = string.Empty;

        /// <summary>
        /// 환자내원번호
        /// </summary>
        public string PT_CMHS_NO = string.Empty;

        /// <summary>
        /// 수납발생고유번호
        /// </summary>
        public string RCPT_OCRR_UNIQ_NO = string.Empty;

        /// <summary>
        /// 수진자 주민 등록번호
        /// </summary>
        public string sujinjaJuminNo = string.Empty;

        /// <summary>
        /// 수진자 성명
        /// </summary>
        public string sujinjaJuminNm = string.Empty;

        /// <summary>
        /// 의료 급여 기관기호
        /// </summary>
        public string ykiho = string.Empty;

        /// <summary>
        /// 승인여부
        /// </summary>
        public string admType = string.Empty;

        /// <summary>
        /// 진료확인번호
        /// </summary>
        public string cfhcCfrNo = string.Empty;

        /// <summary>
        /// 본인 일부 부담금
        /// </summary>
        public string selfPartBrdnAmt = string.Empty;

        /// <summary>
        /// 건강생활 유지비 청구액
        /// </summary>
        public string cfhcDmdAmt = string.Empty;

        /// <summary>
        /// 건강생활 유지비 잔액
        /// </summary>
        public string cfhcRem = string.Empty;

        /// <summary>
        /// 산전지원비청구액
        /// </summary>
        public string pregDmndAmt = string.Empty;

        /// <summary>
        /// 의료급여 산전 지원금 잔액
        /// </summary>
        public string pregRemAmt = string.Empty;

        /// <summary>
        /// 데이터 입력 일자( 년월일-시분초)
        /// </summary>
        public string InputDate = string.Empty;

        /// <summary>
        /// 요양기관처리여부(해당없음)
        /// </summary>
        public string PICKUP_FLAG = string.Empty;

        /// <summary>
        /// 서버로부터의 메시지 Code
        /// </summary>
        public string messageCode = string.Empty;

        /// <summary>
        /// 서버로부터의 메시지
        /// </summary>
        public string message = string.Empty;

        /// <summary>
        /// 메시지 타입
        /// </summary>
        public string msgType = "M4";

        /// <summary>
        /// 화면 클라이언트의 개별 고유 값
        /// </summary>
        public string clientInfo = string.Empty;

        /// <summary>
        /// 담당자 주민번호
        /// </summary>
        public string operatorJuminNo = string.Empty;

        /// <summary>
        /// 프로그램 구분
        /// </summary>
        public string pgmType = string.Empty;

        /// <summary>
        /// DLL 버전
        /// </summary>
        public string version = string.Empty;

        public string RCPT_SQNO = string.Empty;

        public string diagDt = string.Empty;

        #endregion [ 공단 제공 변수 ]

        #region Method : Public Method

        public void Clear()
        {
            //this.requestResult = false;
            this.PID = string.Empty;
            this.OTPT_ADMS_YN = string.Empty;
            this.PT_CMHS_NO = string.Empty;
            this.RCPT_OCRR_UNIQ_NO = string.Empty;
            this.sujinjaJuminNo = string.Empty;
            this.sujinjaJuminNm = string.Empty;
            this.ykiho = string.Empty;
            this.admType = string.Empty;
            this.cfhcCfrNo = string.Empty;
            this.selfPartBrdnAmt = string.Empty;
            this.cfhcDmdAmt = string.Empty;
            this.cfhcRem = string.Empty;
            this.pregDmndAmt = string.Empty;
            this.pregRemAmt = string.Empty;
            this.InputDate = string.Empty;
            this.PICKUP_FLAG = string.Empty;
            this.messageCode = string.Empty;
            this.message = string.Empty;
            this.msgType = "M4";
            this.clientInfo = string.Empty;
            this.operatorJuminNo = string.Empty;
            this.pgmType = string.Empty;
            this.version = string.Empty;
            this.RCPT_SQNO = string.Empty;
            this.diagDt = string.Empty;
        }

        #endregion Method : Public Method
    }
}