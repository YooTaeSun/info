//********************************************************************************
// Class 명 : clsUnCollectedOcrrInfo
// 역    할 : 미수발생정보
// 작 성 자 : PGH
// 작 성 일 : 2018-01-08
//********************************************************************************
// 수정내역 : 
//********************************************************************************                                                             
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public class clsUnCollectedOcrrInfo
    {
        #region Define : Member
        private string m_PID = String.Empty;    //환자등록번호                     VARCHAR2(10)
        private int m_UNCL_OCRR_SQNO = 0;               //미수발생일련번호                 NUMBER(5, 0)
        private string m_OTPT_ADMS_DVCD = String.Empty;    //외래입원구분코드                 VARCHAR2(2)
        private int m_PT_CMHS_NO = 0;               //환자내원번호                     NUMBER(10, 0)
        private string m_UNCL_OCRR_DVCD = String.Empty;    //미수발생구분코드                 VARCHAR2(4)
        private string m_UNCL_CD = String.Empty;    //미수코드                         VARCHAR2(10)
        private int m_RCPT_SQNO = 0;               //수납일련번호                     NUMBER(5, 0)
        private string m_MDCR_DD = String.Empty;    //진료일자                         VARCHAR2(8)
        private string m_CMPY_STRT_DD = String.Empty;    //정산시작일자                     VARCHAR2(8)
        private string m_CMPY_END_DD = String.Empty;    //정산종료일자                     VARCHAR2(8)
        private string m_MDCR_DEPT_CD = String.Empty;    //진료부서코드                     VARCHAR2(10)
        private string m_MDCR_DR_CD = String.Empty;    //진료의사코드                     VARCHAR2(10)
        private string m_INSN_TYCD = String.Empty;    //보험유형코드                     VARCHAR2(2)
        private string m_ASST_TYCD = String.Empty;    //보조유형코드                     VARCHAR2(2)
        private string m_CMHS_DVCD = String.Empty;    //내원구분코드                     VARCHAR2(2)
        private int m_TOTL_MDCR_AMT = 0;               //총진료금액                       NUMBER(10, 0)
        private int m_PAY_TAMT = 0;               //급여총금액                       NUMBER(10, 0)
        private int m_NOPY_TAMT = 0;               //비급여총금액                     NUMBER(10, 0)
        private int m_PAY_CLAM_AMT = 0;               //급여청구금액                     NUMBER(10, 0)
        private int m_PAY_USCH_AMT = 0;               //급여본인부담금액                 NUMBER(10, 0)
        private int m_DCNT_RDIA_AMT = 0;               //할인감액금액                     NUMBER(10, 0)
        private int m_CARD_RCPT_AMT = 0;               //카드수납금액                     NUMBER(10, 0)
        private int m_BNAC_RCPT_AMT = 0;               //계좌수납금액                     NUMBER(10, 0)
        private int m_CASH_RCPT_AMT = 0;               //현금수납금액                     NUMBER(10, 0)
        private string m_CTTR_NO_CD = String.Empty;    //계약처번호코드                   VARCHAR2(10)
        private string m_RCPT_OCRR_UNIQ_NO = String.Empty;    //수납발생고유번호                 VARCHAR2(13)
        private int m_UNCL_AMT = 0;               //미수금액                         NUMBER(10, 0)
        private int m_UNCL_BLCE = 0;               //미수잔액                         NUMBER(10, 0)
        private int m_UNCL_AJAM = 0;               //미수조정금액                     NUMBER(10, 0)
        private string m_UNCL_OCRR_PCFT = String.Empty;    //미수발생특이사항                 VARCHAR2(100)
        private string m_PCLR_MATR = String.Empty;    //특이사항                         VARCHAR2(200)
        private string m_PTAF_CLSN_YN = String.Empty;    //원무마감여부                     VARCHAR2(1)
        private string m_RCPT_DD = String.Empty;    //수납일자                         VARCHAR2(8)
        private string m_RCPT_TIME = String.Empty;    //수납시간                         VARCHAR2(4)
        private string m_ETC_USE_CNTS_1 = String.Empty;    //기타사용내용첫째                 VARCHAR2(10)
        private string m_ETC_USE_CNTS_2 = String.Empty;    //기타사용내용둘째                 VARCHAR2(10)
        private string m_ETC_USE_CNTS_3 = String.Empty;    //기타사용내용셋째                 VARCHAR2(10)
        private string m_ETC_USE_CNTS_4 = String.Empty;    //기타사용내용넷째                 VARCHAR2(10)
        private string m_ETC_USE_CNTS_5 = String.Empty;    //기타사용내용다섯째               VARCHAR2(10)
        private string m_ROW_STAT_DVCD = String.Empty;    //행상태구분코드                   VARCHAR2(2)
        private string m_RGST_DT = String.Empty;    //등록일시                         VARCHAR2(14)
        private string m_RGSTR_ID = String.Empty;    //등록자ID                         VARCHAR2(10)
        private string m_UPDT_DT = String.Empty;    //수정일시                         VARCHAR2(14)
        private string m_UPDTR_ID = String.Empty;    //수정자ID                         VARCHAR2(10)

        private string m_BILL_NO = String.Empty; //영수증번호
        #endregion Define : Member

        #region Define : Property
        public string PID { get { return m_PID; } set { m_PID = value; } }    //환자등록번호                     VARCHAR2(10)
        public int UNCL_OCRR_SQNO { get { return m_UNCL_OCRR_SQNO; } set { m_UNCL_OCRR_SQNO = value; } }    //미수발생일련번호                 NUMBER(5, 0)
        public string OTPT_ADMS_DVCD { get { return m_OTPT_ADMS_DVCD; } set { m_OTPT_ADMS_DVCD = value; } }    //외래입원구분코드                 VARCHAR2(2)
        public int PT_CMHS_NO { get { return m_PT_CMHS_NO; } set { m_PT_CMHS_NO = value; } }    //환자내원번호                     NUMBER(10, 0)
        public string UNCL_OCRR_DVCD { get { return m_UNCL_OCRR_DVCD; } set { m_UNCL_OCRR_DVCD = value; } }    //미수발생구분코드                 VARCHAR2(4)
        public string UNCL_CD { get { return m_UNCL_CD; } set { m_UNCL_CD = value; } }    //미수코드                         VARCHAR2(10)
        public int RCPT_SQNO { get { return m_RCPT_SQNO; } set { m_RCPT_SQNO = value; } }    //수납일련번호                     NUMBER(5, 0)
        public string MDCR_DD { get { return m_MDCR_DD; } set { m_MDCR_DD = value; } }    //진료일자                         VARCHAR2(8)
        public string CMPY_STRT_DD { get { return m_CMPY_STRT_DD; } set { m_CMPY_STRT_DD = value; } }    //정산시작일자                     VARCHAR2(8)
        public string CMPY_END_DD { get { return m_CMPY_END_DD; } set { m_CMPY_END_DD = value; } }    //정산종료일자                     VARCHAR2(8)
        public string MDCR_DEPT_CD { get { return m_MDCR_DEPT_CD; } set { m_MDCR_DEPT_CD = value; } }    //진료부서코드                     VARCHAR2(10)
        public string MDCR_DR_CD { get { return m_MDCR_DR_CD; } set { m_MDCR_DR_CD = value; } }    //진료의사코드                     VARCHAR2(10)
        public string INSN_TYCD { get { return m_INSN_TYCD; } set { m_INSN_TYCD = value; } }    //보험유형코드                     VARCHAR2(2)
        public string ASST_TYCD { get { return m_ASST_TYCD; } set { m_ASST_TYCD = value; } }    //보조유형코드                     VARCHAR2(2)
        public string CMHS_DVCD { get { return m_CMHS_DVCD; } set { m_CMHS_DVCD = value; } }    //내원구분코드                     VARCHAR2(2)
        public int TOTL_MDCR_AMT { get { return m_TOTL_MDCR_AMT; } set { m_TOTL_MDCR_AMT = value; } }    //총진료금액                       NUMBER(10, 0)
        public int PAY_TAMT { get { return m_PAY_TAMT; } set { m_PAY_TAMT = value; } }    //급여총금액                       NUMBER(10, 0)
        public int NOPY_TAMT { get { return m_NOPY_TAMT; } set { m_NOPY_TAMT = value; } }    //비급여총금액                     NUMBER(10, 0)
        public int PAY_CLAM_AMT { get { return m_PAY_CLAM_AMT; } set { m_PAY_CLAM_AMT = value; } }    //급여청구금액                     NUMBER(10, 0)
        public int PAY_USCH_AMT { get { return m_PAY_USCH_AMT; } set { m_PAY_USCH_AMT = value; } }    //급여본인부담금액                 NUMBER(10, 0)
        public int DCNT_RDIA_AMT { get { return m_DCNT_RDIA_AMT; } set { m_DCNT_RDIA_AMT = value; } }    //할인감액금액                     NUMBER(10, 0)
        public int CARD_RCPT_AMT { get { return m_CARD_RCPT_AMT; } set { m_CARD_RCPT_AMT = value; } }    //카드수납금액                     NUMBER(10, 0)
        public int BNAC_RCPT_AMT { get { return m_BNAC_RCPT_AMT; } set { m_BNAC_RCPT_AMT = value; } }    //계좌수납금액                     NUMBER(10, 0)
        public int CASH_RCPT_AMT { get { return m_CASH_RCPT_AMT; } set { m_CASH_RCPT_AMT = value; } }    //현금수납금액                     NUMBER(10, 0)
        public string CTTR_NO_CD { get { return m_CTTR_NO_CD; } set { m_CTTR_NO_CD = value; } }    //계약처번호코드                   VARCHAR2(10)
        public string RCPT_OCRR_UNIQ_NO { get { return m_RCPT_OCRR_UNIQ_NO; } set { m_RCPT_OCRR_UNIQ_NO = value; } }    //수납발생고유번호                 VARCHAR2(13)
        public int UNCL_AMT { get { return m_UNCL_AMT; } set { m_UNCL_AMT = value; } }    //미수금액                         NUMBER(10, 0)
        public int UNCL_BLCE { get { return m_UNCL_BLCE; } set { m_UNCL_BLCE = value; } }    //미수잔액                         NUMBER(10, 0)
        public int UNCL_AJAM { get { return m_UNCL_AJAM; } set { m_UNCL_AJAM = value; } }    //미수조정금액                     NUMBER(10, 0)
        public string UNCL_OCRR_PCFT { get { return m_UNCL_OCRR_PCFT; } set { m_UNCL_OCRR_PCFT = value; } }    //미수발생특이사항                 VARCHAR2(100)
        public string PCLR_MATR { get { return m_PCLR_MATR; } set { m_PCLR_MATR = value; } }    //특이사항                         VARCHAR2(200)
        public string PTAF_CLSN_YN { get { return m_PTAF_CLSN_YN; } set { m_PTAF_CLSN_YN = value; } }    //원무마감여부                     VARCHAR2(1)
        public string RCPT_DD { get { return m_RCPT_DD; } set { m_RCPT_DD = value; } }    //수납일자                         VARCHAR2(8)
        public string RCPT_TIME { get { return m_RCPT_TIME; } set { m_RCPT_TIME = value; } }    //수납시간                         VARCHAR2(4)
        public string ETC_USE_CNTS_1 { get { return m_ETC_USE_CNTS_1; } set { m_ETC_USE_CNTS_1 = value; } }    //기타사용내용첫째                 VARCHAR2(10)
        public string ETC_USE_CNTS_2 { get { return m_ETC_USE_CNTS_2; } set { m_ETC_USE_CNTS_2 = value; } }    //기타사용내용둘째                 VARCHAR2(10)
        public string ETC_USE_CNTS_3 { get { return m_ETC_USE_CNTS_3; } set { m_ETC_USE_CNTS_3 = value; } }    //기타사용내용셋째                 VARCHAR2(10)
        public string ETC_USE_CNTS_4 { get { return m_ETC_USE_CNTS_4; } set { m_ETC_USE_CNTS_4 = value; } }    //기타사용내용넷째                 VARCHAR2(10)
        public string ETC_USE_CNTS_5 { get { return m_ETC_USE_CNTS_5; } set { m_ETC_USE_CNTS_5 = value; } }    //기타사용내용다섯째               VARCHAR2(10)
        public string ROW_STAT_DVCD { get { return m_ROW_STAT_DVCD; } set { m_ROW_STAT_DVCD = value; } }    //행상태구분코드                   VARCHAR2(2)
        public string RGST_DT { get { return m_RGST_DT; } set { m_RGST_DT = value; } }    //등록일시                         VARCHAR2(14)
        public string RGSTR_ID { get { return m_RGSTR_ID; } set { m_RGSTR_ID = value; } }    //등록자ID                         VARCHAR2(10)
        public string UPDT_DT { get { return m_UPDT_DT; } set { m_UPDT_DT = value; } }    //수정일시                         VARCHAR2(14)
        public string UPDTR_ID { get { return m_UPDTR_ID; } set { m_UPDTR_ID = value; } }    //수정자ID                         VARCHAR2(10)

        public string BILL_NO { get { return m_BILL_NO; } set { m_BILL_NO = value; } }    //수정자ID                         VARCHAR2(10)

        #endregion Define : Property

        #region Construction
        public clsUnCollectedOcrrInfo()
        {
            Clear();
        }
        #endregion Construction

        #region Method : Initialize
        public void Clear()
        {
            m_PID = String.Empty;
            m_UNCL_OCRR_SQNO = 0;
            m_OTPT_ADMS_DVCD = String.Empty;
            m_PT_CMHS_NO = 0;
            m_UNCL_OCRR_DVCD = String.Empty;
            m_UNCL_CD = String.Empty;
            m_RCPT_SQNO = 0;
            m_MDCR_DD = String.Empty;
            m_CMPY_STRT_DD = String.Empty;
            m_CMPY_END_DD = String.Empty;
            m_MDCR_DEPT_CD = String.Empty;
            m_MDCR_DR_CD = String.Empty;
            m_INSN_TYCD = String.Empty;
            m_ASST_TYCD = String.Empty;
            m_CMHS_DVCD = String.Empty;
            m_TOTL_MDCR_AMT = 0;
            m_PAY_TAMT = 0;
            m_NOPY_TAMT = 0;
            m_PAY_CLAM_AMT = 0;
            m_PAY_USCH_AMT = 0;
            m_DCNT_RDIA_AMT = 0;
            m_CARD_RCPT_AMT = 0;
            m_BNAC_RCPT_AMT = 0;
            m_CASH_RCPT_AMT = 0;
            m_CTTR_NO_CD = String.Empty;
            m_RCPT_OCRR_UNIQ_NO = String.Empty;
            m_UNCL_AMT = 0;
            m_UNCL_BLCE = 0;
            m_UNCL_AJAM = 0;
            m_UNCL_OCRR_PCFT = String.Empty;
            m_PCLR_MATR = String.Empty;
            m_PTAF_CLSN_YN = String.Empty;
            m_RCPT_DD = String.Empty;
            m_RCPT_TIME = String.Empty;
            m_ETC_USE_CNTS_1 = String.Empty;
            m_ETC_USE_CNTS_2 = String.Empty;
            m_ETC_USE_CNTS_3 = String.Empty;
            m_ETC_USE_CNTS_4 = String.Empty;
            m_ETC_USE_CNTS_5 = String.Empty;
            m_ROW_STAT_DVCD = String.Empty;
            m_RGST_DT = String.Empty;
            m_RGSTR_ID = String.Empty;
            m_UPDT_DT = String.Empty;
            m_UPDTR_ID = String.Empty;

            m_BILL_NO = String.Empty;
        }
        #endregion Method : Initialize

        #region Method : Public Method

        /// <summary>
        /// 미수발생정보를 가져온다.
        /// </summary>
        /// <param name="pid">환자등록번호</param>
        /// <param name="otptadmsdvcd">외래입원구분코드</param>
        /// <param name="ptcmhsno">환자내원번호</param>
        /// <param name="unclocrrdvcd">미수발생구분코드</param>
        /// <param name="strtdd">정산시작일자</param>
        /// <param name="rowstatdvcd">행상태구분코드</param>
        /// <param name="unclocrrsqno">미수발생일련번호</param>
        /// <param name="unclamt">미수금액</param>
        /// <param name="ptafclsnyn">원무확인여부</param>
        /// <param name="msg">오류메시지</param>
        /// <returns></returns>
        public bool SelectIsUnclOcrr(string pid, string otptadmsdvcd, string ptcmhsno, string unclocrrdvcd, string strtdd, string rowstatdvcd, 
        ref int unclocrrsqno, ref int unclamt, ref string ptafclsnyn, ref string msg)
        {
            try
            {
                unclocrrsqno = 0;
                unclamt = 0;
                DataTable dt = new DataTable();
                if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectIsUnclOcrr_New(), ref dt, pid
                                                                                        , otptadmsdvcd
                                                                                        , ptcmhsno
                                                                                        , unclocrrdvcd
                                                                                        , strtdd
                                                                                        , rowstatdvcd))
                {
                    if (dt.Rows.Count > 0)
                    {
                        DataRow row = dt.Rows[0];

                        int.TryParse(row["UNCL_OCRR_SQNO"].ToString(), out unclocrrsqno);
                        int.TryParse(row["UNCL_AMT"].ToString(), out unclamt);
                        ptafclsnyn = row["PTAF_CLSN_YN"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                msg = "미수발생자료 조회 중 오류를 발생했습니다.\r\n " +
                      "Method :  [SelectIsUnclOcrr] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }
            return true;
        }

        /// <summary>
        /// 미수발생정보를 생성한다. 입원영수금액생성.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool SavePAUNCOMA(ref string msg)
        {
            try
            {
                int unclocrrsqno = 0;               // 이전미수발생일련번호
                int maxunclocrrsqno = 0;            // 미수발생일련번호 MAX Value
                int unclamt = 0;                    // 이전미수발생금액
                string ptafclsnyn = String.Empty;   // 원무마감여부

                /*
                 * unclocrrcnt = DBService.ExecuteInteger(SQL.PA.Sql.SelectCountIsUnclOcrr(), pid
                                                                                         , otptadmsdvcd
                                                                                         , ptcmhsno.ToString());

                if (unclocrrcnt < 0)
                {
                    msg = "미수발생일련번호를 조회하는 중 오류를 발생헀습니다. \r\n " +
                          "Method : [SavePAUNCOMA -> SelectMaxUnclOcrrSqno] \r\n  " +
                          "오류메시지 : " + DBService.ErrorMessage;
                    DBService.RollbackTransaction();
                    return false;
                }
                */
                // 이전미수발생정보를 가져온다.
                // 환자번호, 외래입원구분, 환자내원번호, 미수발생구분, 시작일자(진료일자, 접수일자), 행상태구분, 이전미수일련번호, 미수발생금액, 원무마감여부, 오류메시지
                if (!SelectIsUnclOcrr(this.m_PID, this.m_OTPT_ADMS_DVCD, this.m_PT_CMHS_NO.ToString(), this.m_UNCL_OCRR_DVCD, this.m_CMPY_STRT_DD, this.m_ROW_STAT_DVCD, ref unclocrrsqno, ref unclamt, ref ptafclsnyn, ref msg))
                    return false;


                if (unclamt > 0 || this.m_UNCL_AMT > 0)
                {
                    // 미수발생일련번호 MAX값을 가져온다.
                    maxunclocrrsqno = DBService.ExecuteInteger(SQL.PA.Sql.SelectMaxUnclOcrrSqno(), this.m_PID);

                    if (maxunclocrrsqno < 0)
                    {
                        msg = "미수발생일련번호 MAX 값을 조회하는 중 오류를 발생헀습니다. \r\n " +
                              "Method : [SavePAUNCOMA -> SelectMaxUnclOcrrSqno] \r\n  " +
                              "오류메시지 : " + DBService.ErrorMessage;
                        DBService.RollbackTransaction();
                        return false;
                    }


                    // 이전미수정보를 변경한다.
                    if (unclocrrsqno > 0)
                    {
                        // 이전미수발생정보를 취소한다.
                        if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateRowStatDvcdOfPAUNCOMA(), this.m_PID
                                                                                               , unclocrrsqno.ToString()
                                                                                               , this.m_ROW_STAT_DVCD))
                        {
                            msg = "미수발생정보의 행상태구분코드를 [ " + this.m_ROW_STAT_DVCD + " ] 변경하는 중 오류를 발생헀습니다. \r\n " +
                                  "Method : [SavePAUNCOMA -> UpdateRowStatDvcdOfPAUNCOMA] \r\n  " +
                                  "오류메시지 : " + DBService.ErrorMessage;
                            DBService.RollbackTransaction();
                            return false;
                        }

                        maxunclocrrsqno++;

                        // 취소 미수발생정보를 생성한다.
                        if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertCancelOrRestoreOfPAUNCOMA_New(), this.m_PID                         // 환자등록번호
                                                                                                       , unclocrrsqno.ToString()            // 이전미수발생일련번호
                                                                                                       , maxunclocrrsqno.ToString()         // 미수발생일련번호
                                                                                                       , "-1"                               // 금액 마이너스
                                                                                                       , "N"                                // 원무마감여부
                                                                                                       , "D"))                              // 행상태구분코드
                        {
                            msg = "미수발생의 취소정보를 생성하는 중 오류를 발생헀습니다. \r\n " +
                                  "Method : [SavePAUNCOMA -> InsertCancelOrRestoreOfPAUNCOMA] \r\n  " +
                                  "오류메시지 : " + DBService.ErrorMessage;
                            DBService.RollbackTransaction();
                            return false;
                        }
                    }


                    maxunclocrrsqno++;
                    //개인미수도 기타미수도 아닌경우 미수발생구분코드를 발생시키지 않는다.
                    if (!this.m_UNCL_OCRR_DVCD.Equals("*") && !this.m_UNCL_OCRR_DVCD.Equals("X10"))
                    {
                        //this.m_UNCL_CD = String.Empty;
                        this.m_UNCL_CD = "NO";
                    }

                    if (this.m_UNCL_AMT.Equals(0))
                    {
                        this.m_UNCL_CD = "NO";  // 미수금액이 없는 경우 미수코드가 없으므로 'NO' 로 설정한다.
                    }
                    this.m_UNCL_OCRR_SQNO = maxunclocrrsqno;

                    // 새로운 미수발생정보를 생성한다.
                    if (!InsertPAUNCOMA(ref msg))
                        return false;
                }

            }
            catch (Exception ex)
            {
                msg = "미수발생정보 저장 중 오류를 발생했습니다.\r\n " +
                      "Method :  [SavePAUNCOMA] \r\n " +
                      "오류 메시지 : " + ex.Message;
                DBService.RollbackTransaction();
                return false;
            }
            return true;
        }


        /// <summary>
        /// 미수발생정보를 저장한다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool CancelUnclOcrrInfo(string pid, string ptcmhsno, string strtdd, ref string msg)
        {
            try
            {
                int unclocrrsqno = 0;
                int unclamt = 0;
                int uncldpstamt = 0;
                string uncldpstyn = "N";
                string ptafclsnyn = String.Empty;
                string unclmsg = String.Empty;
                DataTable dt = new DataTable();
                dt = OverallCodeList.GetDataList("UNCL_OCRR_DVCD");
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        if (row["LWRN_OVRL_CD"].ToString().Equals("X10")) continue;  // TODO : 일단 기타미수 통과
                        // 미수발생정보를 가져온다.
                        if (!SelectIsUnclOcrr(pid, "I", ptcmhsno, row["LWRN_OVRL_CD"].ToString(), strtdd, "A", ref unclocrrsqno, ref unclamt, ref ptafclsnyn, ref msg))
                            return false;

                        if (unclamt > 0)
                        {
                            if (!this.CancelPAUNCOMA(pid, unclocrrsqno.ToString(), row["LWRN_OVRL_CD"].ToString(), ref msg))
                                return false;

                            if (StringService.IsNull(unclmsg))
                            {
                                unclmsg = "미수입금에 대한 처리 현황입니다. \r\n";
                            }

                            if (row["LWRN_OVRL_CD"].ToString().Equals("*"))
                            {
                                unclmsg = unclmsg + "\r\n " + row["LWRN_OVRL_CDNM"].ToString() + " " + string.Format("{0:#,##0}", (this.m_CARD_RCPT_AMT + this.m_CASH_RCPT_AMT + this.m_BNAC_RCPT_AMT)) + "원은 보증금으로 대체";
                            }
                            else
                            {
                                unclmsg = unclmsg + "\r\n " + row["LWRN_OVRL_CDNM"].ToString() + " " + string.Format("{0:#,##0}", (this.m_CARD_RCPT_AMT + this.m_CASH_RCPT_AMT + this.m_BNAC_RCPT_AMT)) + "원은 재영수후 미수입금처리 필요";
                            }
                        }

                        // 미수입금 처리내역을 표시하기 위해서..
                        this.m_PCLR_MATR = unclmsg;
                    }
                }
            }
            catch (Exception ex)
            {
                msg = "미수발생정보 저장 중 오류를 발생했습니다.\r\n " +
                      "Method :  [SaveUnclOcrrInfo] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }
            return true;
        }
        #endregion Method : Public Method

        #region Method : Private Method
        private bool InsertPAUNCOMA(ref string msg)
        {
            try
            {
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertPAUNCOMA(), m_PID                                // 환자등록번호
                                                                          , m_UNCL_OCRR_SQNO.ToString()          // 미수발생일련번호
                                                                          , m_OTPT_ADMS_DVCD                     // 외래입원구분코드
                                                                          , m_PT_CMHS_NO.ToString()              // 환자내원번호
                                                                          , m_UNCL_OCRR_DVCD                     // 미수발생구분코드
                                                                          , m_UNCL_CD                            // 미수코드
                                                                          , m_RCPT_SQNO.ToString()               // 수납일련번호
                                                                          , m_MDCR_DD                            // 진료일자
                                                                          , m_CMPY_STRT_DD                       // 정산시작일자
                                                                          , m_CMPY_END_DD                        // 정산종료일자
                                                                          , m_MDCR_DEPT_CD                       // 진료부서코드
                                                                          , m_MDCR_DR_CD                         // 진료의사코드
                                                                          , m_INSN_TYCD                          // 보험유형코드
                                                                          , m_ASST_TYCD                          // 보조유형코드
                                                                          , m_CMHS_DVCD                          // 내원구분코드
                                                                          , m_TOTL_MDCR_AMT.ToString()           // 총진료금액
                                                                          , m_PAY_TAMT.ToString()                // 급여총금액
                                                                          , m_NOPY_TAMT.ToString()               // 비급여총금액
                                                                          , m_PAY_CLAM_AMT.ToString()            // 급여청구금액
                                                                          , m_PAY_USCH_AMT.ToString()            // 급여본인부담금액
                                                                          , m_DCNT_RDIA_AMT.ToString()           // 할인감액금액
                                                                          , m_CARD_RCPT_AMT.ToString()           // 카드수납금액
                                                                          , m_BNAC_RCPT_AMT.ToString()           // 계좌수납금액
                                                                          , m_CASH_RCPT_AMT.ToString()           // 현금수납금액
                                                                          , m_CTTR_NO_CD                         // 계약처번호코드
                                                                          , m_RCPT_OCRR_UNIQ_NO                  // 수납발생고유번호
                                                                          , m_UNCL_AMT.ToString()                // 미수금액
                                                                          , m_UNCL_BLCE.ToString()               // 미수잔액
                                                                          , m_UNCL_AJAM.ToString()               // 미수조정금액
                                                                          , m_UNCL_OCRR_PCFT                     // 미수발생특이사항
                                                                          , m_PCLR_MATR                          // 특이사항
                                                                          , m_PTAF_CLSN_YN                       // 원무마감여부
                                                                          , m_RCPT_DD                            // 수납일자
                                                                          , m_RCPT_TIME                          // 수납시간
                                                                          , m_ETC_USE_CNTS_1                     // 기타사용내용첫째
                                                                          , m_ETC_USE_CNTS_2                     // 기타사용내용둘째
                                                                          , m_ETC_USE_CNTS_3                     // 기타사용내용셋째
                                                                          , m_ETC_USE_CNTS_4                     // 기타사용내용넷째
                                                                          , m_ETC_USE_CNTS_5                     // 기타사용내용다섯째
                                                                          , m_ROW_STAT_DVCD                      // 행상태구분코드
                                                                          , m_RGST_DT                            // 등록일시
                                                                          , m_RGSTR_ID                           // 등록자ID
                                                                          , m_UPDT_DT                            // 수정일시
                                                                          , m_UPDTR_ID))                         // 수정자ID
                {
                    msg = "미수발생정보를 생성하는 중 오류를 발생헀습니다. \r\n " +
                          "Method : SavePAUNCOMA -> InsertPAUNCOMA \r\n  " +
                          "오류메시지 : " + DBService.ErrorMessage;
                    DBService.RollbackTransaction();
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                DBService.RollbackTransaction();
                LogService.ErrorLog(ex);
                msg = "미수발생정보 저장 중 오류를 발생했습니다.\r\n " +
                      "Method :  InsertPAUNCOMA \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }
        }

        /// <summary>
        /// 미수관련 취소작업을 한다.
        /// </summary>
        /// <param name="pid">환자등록번호</param>
        /// <param name="unclocrrsqno">미수발생일련번호</param>
        /// <param name="unclocrrdvcd">미수발생구분코드</param>
        /// <param name="msg"></param>
        /// <returns></returns>
        private bool CancelPAUNCOMA(string pid, string unclocrrsqno, string unclocrrdvcd, ref string msg)
        {
            try
            {
                int carddpstamt = 0;
                int cashdpstamt = 0;
                int bnacdpstamt = 0;
                clsAdmsIntermediateAmt interamt = new clsAdmsIntermediateAmt();

                // 미수발생일련번호 MAX VALUE
                int maxunclocrrsqno = SelectMaxUnclOcrrSqno(pid, ref msg);

                if (maxunclocrrsqno < 0) return false;


                maxunclocrrsqno++;

                // 미수발생취소정보를 생성한다.(-)
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertCancelOrRestoreOfPAUNCOMA_New(), pid
                                                                                               , unclocrrsqno
                                                                                               , maxunclocrrsqno.ToString()
                                                                                               , "-1"
                                                                                               , "N"
                                                                                               , "D"))
                {
                    msg = "미수발생의 취소정보를 생성하는 중 오류를 발생헀습니다. \r\n " +
                          "Method : CancelPAUNCOMA -> InsertCancelOrRestoreOfPAUNCOMA_New \r\n  " +
                          "오류메시지 : " + DBService.ErrorMessage;
                    DBService.RollbackTransaction();
                    return false;
                }

                // 기존미수발생정보를 취소한다. (C)
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateRowStatDvcdOfPAUNCOMA2(), pid
                                                                                       , unclocrrsqno.ToString()
                                                                                       , "C"))
                {
                    msg = "미수발생정보의 행상태구분코드를 [ A -> C ]변경하는 중 오류를 발생헀습니다. \r\n " +
                          "Method : [SavePAUNCOMA -> UpdateRowStatDvcdOfPAUNCOMA2 \r\n  " +
                          "오류메시지 : " + DBService.ErrorMessage;
                    DBService.RollbackTransaction();
                    return false;
                }

                // 미수입금정보를 가져온다.
                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectUnclDpstAmt2(), ref dt, pid
                                                                                     , unclocrrsqno.ToString()))
                {
                    return false;
                }

                if (dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];
                    int.TryParse(row["CARD_DPST_AMT"].ToString(), out carddpstamt);
                    int.TryParse(row["CASH_DPST_AMT"].ToString(), out cashdpstamt);
                    int.TryParse(row["BNAC_DPST_AMT"].ToString(), out bnacdpstamt);

                }


                // 개인미수의 경우 미수입금금액이 있으면 보증금으로 전환한다.
                if ((carddpstamt + cashdpstamt + bnacdpstamt) > 0 && unclocrrdvcd.Equals("*"))
                {
                    interamt.PID = m_PID; interamt.PT_CMHS_NO = m_PT_CMHS_NO; interamt.DPST_DD = m_CMPY_STRT_DD; interamt.MDCR_DEPT_CD = m_MDCR_DEPT_CD;
                    interamt.MDCR_DR_CD = m_MDCR_DR_CD; interamt.INSN_TYCD = m_INSN_TYCD; interamt.ASST_TYCD = m_ASST_TYCD; interamt.DPST_DVCD = "B";
                    interamt.CARD_AMT = carddpstamt; interamt.CASH_DPST_AMT = cashdpstamt; interamt.BNAC_DPST_AMT = bnacdpstamt; interamt.ROW_STAT_DVCD = "A";
                    interamt.RGST_DT = DateTimeService.NowDateTimeNoneSeperatorString(); interamt.RGSTR_ID = DOPack.UserInfo.USER_CD;
                    interamt.BILL_NO = m_BILL_NO; interamt.RCPT_OCRR_UNIQ_NO = m_RCPT_OCRR_UNIQ_NO;

                    // 보증금을 생성한다.
                    if (!interamt.SavePAIMDMMA(ref msg))
                    {
                        return false;
                    }

                    // 미수입금 취소정보를 생성한다.
                    if (!InsertCancelPAUNCDMA(pid, unclocrrsqno, ref msg))
                    {
                        return false;
                    }
                }
                // 개인미수외의 경우는 미수입금만 취소한다.
                else if ((carddpstamt + cashdpstamt + bnacdpstamt) > 0 && !unclocrrdvcd.Equals("*"))
                {
                    // 미수입금 취소정보를 생성한다.
                    if (!InsertCancelPAUNCDMA(pid, unclocrrsqno, ref msg))
                    {
                        return false;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }

        }
        /// <summary>
        /// 미수발생일련번호 Max Value 를 가져온다;
        /// </summary>
        /// <param name="pid"></param>
        /// <returns></returns>
        private int SelectMaxUnclOcrrSqno(string pid, ref string msg)
        {
            try
            {
                int maxunclocrrsqno = 0;

                maxunclocrrsqno = DBService.ExecuteInteger(SQL.PA.Sql.SelectMaxUnclOcrrSqno(), pid);
                if (maxunclocrrsqno < 0)
                {
                    msg = "미수발생일련번호 MAX 값을 조회하는 중 오류를 발생헀습니다. \r\n " +
                          "Method : SelectMaxUnclOcrrSqno \r\n  " +
                          "오류메시지 : " + DBService.ErrorMessage;
                    DBService.RollbackTransaction();
                    return -1;
                }
                return maxunclocrrsqno;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                msg = "미수발생일련번호 MAX 값을 조회하는 중 오류를 발생헀습니다. \r\n " +
                      "Method : SelectMaxUnclOcrrSqno \r\n  " +
                      "오류메시지 : " + ex.Message;
                return -100;
            }
        }

        private bool InsertCancelPAUNCDMA(string pid, string unclocrrsqno, ref string msg)
        {
            try
            {
                int uncldpstsqno = 0;

                uncldpstsqno = DBService.ExecuteInteger(SQL.PA.Sql.SelectMaxUnclDpstSqnoOfPAUNCDMA(), pid
                                                                                                    , unclocrrsqno);
                DataTable dt = new DataTable();

                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectUnclDpstSqnoOfPAUNCDMA(), ref dt, pid
                                                                                                , unclocrrsqno))
                {
                    throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                }

                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        uncldpstsqno++;

                        if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertCancelPAUNCDMA(), pid
                                                                                       , unclocrrsqno
                                                                                       , row["UNCL_DPST_SQNO"].ToString()
                                                                                       , uncldpstsqno.ToString()
                                                                                       , "-1"
                                                                                       , DateTimeService.NowDateTimeNoneSeperatorString()
                                                                                       , DOPack.UserInfo.USER_CD))
                        {

                            throw new Exception(string.Format("[{0}]\r\n{1}", DBService.ErrorCode, DBService.ErrorMessage));
                        }
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                DBService.RollbackTransaction();
                LogService.ErrorLog(ex);
                msg = "미수입금정보 취소자료 생성 중 오류를 발생했습니다.\r\n " +
                      "Method : InsertCancelPAUNCDMA \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }
        }
        #endregion Method : Private Method
    }
}
