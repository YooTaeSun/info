#region 어셈블리 Interop.HiraDur, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// C:\Lime\Lib\DUR\Interop.HiraDur.dll
#endregion

using System.Runtime.InteropServices;

namespace HiraDur
{
    [Guid("DCAD8E6F-DC73-4F2A-8CBB-C17A90A5CCDA")]
    [InterfaceType(2)]
    [TypeLibType(4224)]
    public interface IHIRAPrescription
    {
        [DispId(1)]
        int AddMedicine([ComAliasName("HiraDur.PrscType")] PrscType PrscType, string medcCD, string medcNM, string GnlNMCD, string gnlNM, float ddMqtyFreq, float ddExecFreq, int mdcnExecFreq, string insudmdtype, string ioHsp, string prscUsg);
        [DispId(2)]
        int RemoveMedicine([ComAliasName("HiraDur.PrscType")] PrscType PrscType, string medcCD, string medcNM, string GnlNMCD, string gnlNM, float ddMqtyFreq, float ddExecFreq, int mdcnExecFreq);
        [DispId(3)]
        bool NextMedicine();
        [DispId(4)]
        int ClearMedicine();
        [DispId(5)]
        void RewindMedicine();
        [DispId(52)]
        int ChkPwCtdDrug(string GnlNMCD, string chkDate);
        [DispId(54)]
        int CheckAgeLimit(string JuminNo, string IssueDate, string GnlCode, string MedCode);

        [DispId(6)]
        int CountMedicine { get; }
        [DispId(7)]
        string JuminNo { get; set; }
        [DispId(8)]
        string PrscAdminName { get; set; }
        [DispId(9)]
        string MprscIssueAdmin { get; set; }
        [DispId(10)]
        string mprscGrantNo { get; set; }
        [DispId(11)]
        string MakerClCode { get; set; }
        [DispId(12)]
        string DrLicNo { get; set; }
        [DispId(13)]
        string AppIssueAdmin { get; set; }
        [DispId(14)]
        string AdminType { get; set; }
        [DispId(15)]
        string PrscPresDt { get; set; }
        [DispId(16)]
        string PrscPresTm { get; set; }
        [DispId(17)]
        string InsurerType { get; set; }
        [DispId(18)]
        string MakerUsage { get; set; }
        [DispId(19)]
        string Dsbjt { get; set; }
        [DispId(20)]
        string MainSick { get; set; }
        [DispId(21)]
        string PregWmnYN { get; set; }
        [DispId(22)]
        string PatNm { get; set; }
        [DispId(23)]
        string PatTelNo { get; set; }
        [DispId(24)]
        string PrscYN { get; set; }
        [ComAliasName("HiraDur.PrscType")]
        [DispId(25)]
        PrscType PrscTypeRcp { get; }
        [DispId(26)]
        string medcCD { get; }
        [DispId(27)]
        string medcNM { get; }
        [DispId(28)]
        string GnlNMCD { get; }
        [DispId(29)]
        string gnlNM { get; }
        [DispId(30)]
        float ddMqtyFreq { get; }
        [DispId(31)]
        float ddExecFreq { get; }
        [DispId(32)]
        int mdcnExecFreq { get; }
        [DispId(33)]
        string insudmdtype { get; }
        [DispId(34)]
        string PrscTel { get; set; }
        [DispId(35)]
        string PrscFax { get; set; }
        [DispId(36)]
        string PrscLicType { get; set; }
        [DispId(37)]
        string PrscName { get; set; }
        [DispId(38)]
        string PrscMdFee { get; set; }
        [DispId(39)]
        string PrscClCode { get; set; }
        [DispId(40)]
        string PrscRef { get; set; }
        [DispId(41)]
        string PrscIjCtm { get; set; }
        [DispId(42)]
        string PrscPeriod { get; set; }
        [DispId(43)]
        string PrscUsage { get; set; }
        [DispId(44)]
        string MakerDate { get; set; }
        [DispId(45)]
        string MakerTime { get; set; }
        [DispId(46)]
        string MakerIssueAdmin { get; set; }
        [DispId(47)]
        string MakerTel { get; set; }
        [DispId(48)]
        string MakerLic { get; set; }
        [DispId(49)]
        string MakerName { get; set; }
        [DispId(50)]
        string MakerAdminName { get; set; }
        [DispId(51)]
        string ioHsp { get; }
        [DispId(53)]
        string AppIssueCode { get; set; }
        [DispId(55)]
        string OrgPrscPresDt { get; set; }
        [DispId(56)]
        string OrgMprscGrantNo { get; set; }
        [DispId(57)]
        string OrgMrgNo { get; set; }
    }
}