
namespace Lime.Framework.BusinessService
{
    public class clsNhisM3
    {
        #region [ 공단 제공 변수 ]

        /// <summary>
        /// DB에 저장할 환자번호
        /// </summary>
        public string PID = string.Empty;

        /// <summary>
        /// 외래입원여부
        /// </summary>
        public string OTPT_ADMS_YN = string.Empty;

        /// <summary>
        /// 환자내원번호
        /// </summary>
        public string PT_CMHS_NO = string.Empty;

        /// <summary>
        /// 수납발생고유번호
        /// </summary>
        public string RCPT_OCRR_UNIQ_NO = string.Empty;

        /// <summary>
        /// 수진자 주민 등록번호
        /// </summary>
        public string sujinjaJuminNo = string.Empty;

        /// <summary>
        /// 수진자 성명
        /// </summary>
        public string sujinjaJuminNm = string.Empty;

        /// <summary>
        /// 의료 급여 기관기호
        /// </summary>
        public string ykiho = string.Empty;

        /// <summary>
        /// 진료형태
        /// </summary>
        public string diagType = string.Empty;

        /// <summary>
        /// 입(내)원 일수
        /// </summary>
        public string payDdCnt = string.Empty;

        /// <summary>
        /// 투약일수
        /// </summary>
        public string tuyakDdCnt = string.Empty;

        /// <summary>
        /// 본인 일부 부담금
        /// </summary>
        public string selfPartBrdnAmt = string.Empty;

        /// <summary>
        /// 건강생활 유지비 청구액
        /// </summary>
        public string cfhcDmdAmt = string.Empty;

        /// <summary>
        /// 기관부담금
        /// </summary>
        public string adminBrdnAmt = string.Empty;

        /// <summary>
        /// 주상병분류기호(약국직접조제-증상기호)
        /// </summary>
        public string mainSickSym = string.Empty;

        /// <summary>
        /// 진료일자
        /// </summary>
        public string diagDt = string.Empty;

        /// <summary>
        /// 처방전 교부 기관 기호(약국)
        /// </summary>
        public string piadmin = string.Empty;

        /// <summary>
        /// 처방전교부번호(의료급여기관, 약국)
        /// </summary>
        public string prscGnoAdmin = string.Empty;

        /// <summary>
        /// 본인부담여부
        /// </summary>
        public string sbrdnType = string.Empty;

        /// <summary>
        /// 타기관 의뢰여부
        /// </summary>
        public string otherRequestYn = string.Empty;

        /// <summary>
        /// 장애시 진료확인번호
        /// </summary>
        public string cfhcCfrNo = string.Empty;

        /// <summary>
        /// 진료과 코드
        /// </summary>
        public string diagItem = string.Empty;

        /// <summary>
        /// 처방전 발급유무
        /// </summary>
        public string prscGnoYn = string.Empty;

        /// <summary>
        /// 퇴원구분코드
        /// </summary>
        public string diagOutCode = string.Empty;

        /// <summary>
        /// 비급여 총금액
        /// </summary>
        public string pregSumAmt = string.Empty;

        /// <summary>
        /// 출산전 진료비 청구액
        /// </summary>
        public string pregDmndAmt = string.Empty;

        /// <summary>
        /// 진료의뢰 의료급여기관기호
        /// </summary>
        public string diagReqYkiho = string.Empty;

        /// <summary>
        /// 로그인 아이디
        /// </summary>
        public string loginId = string.Empty;

        /// <summary>
        /// "청구개발업체 및 자체개발병원 사업자등록번호" 개발구분(1)+사업자증록번호(10) 개발구분:1:자체개발 2:청구업체
        /// </summary>
        public string password = string.Empty;

        /// <summary>
        /// 데이터 입력 일자( 년월일-시분초)
        /// </summary>
        public string InputDate = string.Empty;

        /// <summary>
        /// 메시지 처리상태
        /// </summary>
        public string status = string.Empty;

        /// <summary>
        /// 메시지 타입
        /// </summary>
        public string msgType = "M3";

        /// <summary>
        /// 화면 클라이언트의 개별 고유 값
        /// </summary>
        public string clientInfo = string.Empty;

        /// <summary>
        /// 담당자주민등록번호
        /// </summary>
        public string operatorJuminNo = string.Empty;

        /// <summary>
        /// 프로그램 구분
        /// </summary>
        public string pgmType = string.Empty;

        /// <summary>
        /// DLL 버전
        /// </summary>
        public string version = string.Empty;

        public string DSBL_DVCD = string.Empty;

        #endregion [ 공단 제공 변수 ]

        #region Method : Public Method

        public void Clear()
        {
            this.PID = string.Empty;
            this.OTPT_ADMS_YN = string.Empty;
            this.PT_CMHS_NO = string.Empty;
            this.RCPT_OCRR_UNIQ_NO = string.Empty;
            this.sujinjaJuminNo = string.Empty;
            this.sujinjaJuminNm = string.Empty;
            this.ykiho = string.Empty;
            this.diagType = string.Empty;
            this.payDdCnt = string.Empty;
            this.tuyakDdCnt = string.Empty;
            this.selfPartBrdnAmt = string.Empty;
            this.cfhcDmdAmt = string.Empty;
            this.adminBrdnAmt = string.Empty;
            this.mainSickSym = string.Empty;
            this.diagDt = string.Empty;
            this.piadmin = string.Empty;
            this.prscGnoAdmin = string.Empty;
            this.sbrdnType = string.Empty;
            this.otherRequestYn = string.Empty;
            this.cfhcCfrNo = string.Empty;
            this.diagItem = string.Empty;
            this.prscGnoYn = string.Empty;
            this.diagOutCode = string.Empty;
            this.pregSumAmt = string.Empty;
            this.pregDmndAmt = string.Empty;
            this.diagReqYkiho = string.Empty;
            this.loginId = string.Empty;
            this.password = string.Empty;
            this.InputDate = string.Empty;
            this.status = string.Empty;
            this.msgType = "M3";
            this.clientInfo = string.Empty;
            this.operatorJuminNo = string.Empty;
            this.pgmType = string.Empty;
            this.version = string.Empty;
            this.DSBL_DVCD = string.Empty;
        }

        #endregion Method : Public Method
    }
}