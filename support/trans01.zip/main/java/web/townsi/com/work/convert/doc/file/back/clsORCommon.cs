using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.BusinessControls
{
    public class clsORCommon
    {
        /// <summary>
        /// 입원환자 기타정보를 저장한다.
        /// </summary>
        /// <param name="pid">환자번호</param>
        /// <param name="pt_cmhs_no">내원번호</param>
        /// <param name="mdcr_dd">처방일자</param>
        /// <param name="etc_dvsn_cnts">기타구분내용</param>
        /// <param name="prsp_grnt_no_1">처방전교부번호첫째</param>
        /// <param name="prsp_grnt_no_2">처방전교부번호둘째</param>
        /// <param name="dur_chck_excl_yn">DUR점검제외여부</param>
        /// <param name="etc_use_cnts_1">기타사용내용첫째</param>
        /// <param name="etc_use_cnts_2">기타사용내용둘째</param>
        /// <param name="etc_use_cnts_3">기타사용내용셋째</param>
        /// <param name="etc_use_cnts_4">기타사용내용넷째</param>
        /// <param name="etc_use_cnts_5">기타사용내용다섯째</param>
        /// <param name="errmsg">에러메세지</param>
        /// <returns></returns>
        public bool SaveORIETCMA(string pid, string pt_cmhs_no, string mdcr_dd, string etc_dvsn_cnts, string prsp_grnt_no_1, string prsp_grnt_no_2, string dur_chck_excl_yn, string etc_use_cnts_1, string etc_use_cnts_2, string etc_use_cnts_3, string etc_use_cnts_4, string etc_use_cnts_5, string todate, ref string errmsg)
        {
            if (DBService.ExecuteInteger(SQL.OR.Sql.SelectCountORIETCMA(), pid
                                                                        , pt_cmhs_no
                                                                        , mdcr_dd) <= 0)
            {
                if (!(DBService.ExecuteNonQuery(SQL.OR.BaseSql.Insert.ORIETCMA(), pid
                                                                               , pt_cmhs_no
                                                                               , mdcr_dd
                                                                               , prsp_grnt_no_1
                                                                               , prsp_grnt_no_2
                                                                               , dur_chck_excl_yn
                                                                               , etc_dvsn_cnts
                                                                               , etc_use_cnts_1
                                                                               , etc_use_cnts_2
                                                                               , etc_use_cnts_3
                                                                               , etc_use_cnts_4
                                                                               , etc_use_cnts_5
                                                                               , "A"
                                                                               , todate
                                                                               , DOPack.UserInfo.USER_CD
                                                                               , todate
                                                                               , DOPack.UserInfo.USER_CD)))
                {
                    errmsg = "입원환자 기타정보 저장 중 오류가 발생했습니다.";
                    return false;
                }
            }
            else
            {
                if (!(DBService.ExecuteNonQuery(SQL.OR.BaseSql.Update.ORIETCMA(), pid
                                                                               , pt_cmhs_no
                                                                               , mdcr_dd
                                                                               , pid
                                                                               , pt_cmhs_no
                                                                               , mdcr_dd
                                                                               , prsp_grnt_no_1
                                                                               , prsp_grnt_no_2
                                                                               , dur_chck_excl_yn
                                                                               , etc_dvsn_cnts
                                                                               , etc_use_cnts_1
                                                                               , etc_use_cnts_2
                                                                               , etc_use_cnts_3
                                                                               , etc_use_cnts_4
                                                                               , etc_use_cnts_5
                                                                               , "A"
                                                                               , todate
                                                                               , DOPack.UserInfo.USER_CD)))
                {
                    errmsg = "입원환자 기타정보 저장 중 오류가 발생했습니다.";
                    return false;
                }
            }

            return true;
        }

        public bool SetOpWkNtER(LxSpread sprMefe, string pid, string pt_cmhs_no, string mdcr_dd, string otpt_adms_dvcd, string mdcr_dept_cd, string mdcr_dr_cd, string prsc_notm, string work_dvcd)
        {
            string prsc_cd = string.Empty;
            string prsc_nm = string.Empty;
            string pcpt_yn = string.Empty;
            string pcup_yn = string.Empty;
            string errmsg = string.Empty;
            string op_dvcd1 = string.Empty;
            string op_dvcd2 = string.Empty;
            string op_dvcd3 = string.Empty;
            string emer_kpr = string.Empty;
            string emer_kts = string.Empty;
            string emer_area = string.Empty;
            string emer_ktas_flag = string.Empty;
            string emer_flag = "N";
            string sql = string.Empty;
            int emer_ktas_rtn = 0;
            int start = 0;
            int end = 0;
            DataRow mefeinfo = null;
            DataTable dt = new DataTable();
            bool saveflag = false;
            bool chekflag = false;

            if (sprMefe.ActiveSheet.RowCount <= 0)
                return false;

            // 체크가 되었다면
            if (BizCommon.CheckChooseColumn(sprMefe, "FLAG"))
            {
                start = 0;
                end = sprMefe.ActiveSheet.RowCount;
                chekflag = true;
            }
            else
            {
                start = sprMefe.ActiveSheet.ActiveRowIndex;
                end = start + 1;
                chekflag = false;
            }

            for (int i = start; i < end; i++)
            {

                prsc_cd = sprMefe.GetValue(i, "PRSC_CD").ToString();
                prsc_nm = sprMefe.GetValue(i, "PRSC_NM").ToString();
                pcpt_yn = sprMefe.GetValue(i, "RCPT_YN").ToString();
                pcup_yn = sprMefe.GetValue(i, "PCUP_YN").ToString();

                if (work_dvcd == "OR")
                {
                    if (sprMefe.GetValue(i, "TITLECODE").ToString() != "3")
                        continue;
                }

                if (string.IsNullOrWhiteSpace(prsc_cd))
                    return false;

                if (sprMefe.GetValue(i, "FLAG").ToString() == "Y" || chekflag == false)
                {
                    if (string.IsNullOrWhiteSpace(pcpt_yn))
                        pcpt_yn = "N";

                    if (string.IsNullOrWhiteSpace(pcup_yn))
                        pcup_yn = "N";

                    if (!(DBService.ExecuteDataTable(SQL.OR.Sql.SelectMefeOpInfo(), ref dt
                                                                                    , prsc_cd
                                                                                    , mdcr_dd)))
                    {
                        LxMessage.Show("수가 정보 조회 중 오류가 발생했습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        return false;
                    }

                    if (dt.Rows.Count <= 0)
                        return false;

                    // 수가정보를 불러온다.
                    mefeinfo = ORBizCommon.GetMefeInfo(sprMefe.GetValue(i, "PRSC_CD").ToString(), mdcr_dd, "%", ref errmsg);
                    if (mefeinfo == null)
                    {
                        errmsg = "처방코드 : " + sprMefe.GetValue(i, "PRSC_CD").ToString() + "수가정보가 없어 처방입력 할 수 없습니다.\r\n보험심사팀으로 문의 바랍니다.";
                        return false;
                    }

                    if (!(string.IsNullOrWhiteSpace(errmsg)))
                    {
                        LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        return false;
                    }

                    // 저장되는 처방 확인
                    //if (!(String.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_SQNO").ToString()) || sprMefe.GetValue(i, "PRSC_SQNO").ToString() == "0"))
                    //{
                    //    if (m_OTPT_ADMS_DVCD == "I")
                    //    {
                    //        // 계산적용이 되었다면 적용불가능
                    //        if (DBService.ExecuteScalar(SQL.OR.Sql.SelectPtafClclAplyYnORORDRRT(), m_PID
                    //                                                                            , m_PT_CMHS_NO
                    //                                                                            , m_MDCR_DD
                    //                                                                            , sprMefe.GetValue(i, "PRSC_SQNO").ToString()).ToString() == "Y")
                    //        {
                    //            LxMessage.Show("처방코드 : " + prsc_cd + "\r\n" +
                    //                           "처방명   : " + prsc_nm + "\r\n" +
                    //                           "원무 계산적용 되었으므로 수정할 수 없습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //            BizCommon.SetRowFocus(sprMefe, i);
                    //            continue;
                    //        }
                    //    }
                    //}

                    op_dvcd1 = dt.Rows[0]["OP_DVCD1"].ToString();
                    op_dvcd2 = dt.Rows[0]["OP_DVCD2"].ToString();
                    op_dvcd3 = dt.Rows[0]["OP_DVCD3"].ToString();

                    // 수술구분 과 야간 및 휴일 가산 항목 인 경우
                    if (op_dvcd1 == "Y" || op_dvcd2 == "Y" || op_dvcd3 == "Y")
                    {
                        if (string.IsNullOrWhiteSpace(mefeinfo["EMRG_ACTN_DVCD"].ToString()))
                            mefeinfo["EMRG_ACTN_DVCD"] = "00";

                        if ((mefeinfo["EMRG_ACTN_DVCD"].ToString() == "01" || mefeinfo["EMRG_ACTN_DVCD"].ToString() == "02") && (mdcr_dept_cd == "2400" || DOPack.UserInfo.DEPT_CD == "2400") && op_dvcd3 == "Y")
                        {
                            // KTAS 정보 조회
                            if (!(SQL.Procedure.PR_ER_READ_KTAS(pid, int.Parse(pt_cmhs_no), ref emer_kpr, ref emer_kts, ref emer_area, ref errmsg, ref emer_ktas_rtn)))
                            {
                                LxMessage.Show("KTAS 조회 중 오류가 발생했습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                return false;
                            }

                            // KTAS 조회 성공 시 KTAS 구분을 변경, 조회를 또 하지 않기위함
                            emer_ktas_flag = "Y";

                            // KTAS 정보로 응급구분 설정
                            if (emer_ktas_rtn < 1)
                            {
                                if (mefeinfo["EMRG_ACTN_DVCD"].ToString() == "01")
                                    emer_flag = "Y";
                                else
                                    emer_flag = "N";
                            }
                            else
                            {
                                switch (emer_kts)
                                {
                                    case "1":
                                    case "2":
                                    case "3":
                                        emer_flag = "E";
                                        break;
                                    default:
                                        if (mefeinfo["EMRG_ACTN_DVCD"].ToString() == "01")
                                            emer_flag = "Y";
                                        else
                                            emer_flag = "N";

                                        break;
                                }
                            }

                            // 응급구분이 적용 또는 가산적용일 때
                            if (emer_flag == "Y" || emer_flag == "E")
                            {
                                // 응급/시간 가산구분 설정
                                popSetEmerTimeAdd pop = new popSetEmerTimeAdd("V", emer_flag, sprMefe.GetValue(i, "PRSC_TIME").ToString(), sprMefe.GetValue(i, "PRSC_TIME_DVCD").ToString(), mdcr_dr_cd, sprMefe.GetValue(i, "PRSC_NM").ToString());
                                if (pop.ShowDialog() == DialogResult.OK)
                                {
                                    sprMefe.SetText(i, "EMRG_ADTN_YN", pop.EMRG_ADTN_YN);
                                    sprMefe.SetText(i, "PRSC_TIME_DVCD", pop.PRSC_TIME_DVCD);
                                    sprMefe.SetText(i, "PRSC_TIME", pop.PRSC_TIME);
                                    sprMefe.SetText(i, "REAL_PRDC_CD", pop.REAL_PRDC_CD);
                                    sprMefe.SetText(i, "POPUP_DVCD", "03");
                                    //if(sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Read)
                                    //{
                                    //    sprMefe.SetCRUDToRow(i, CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "EMRG_ADTN_YN",   CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "PRSC_TIME_DVCD", CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "PRSC_TIME",      CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "REAL_PRDC_CD",   CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "POPUP_DVCD",     CRUD_TYPE.Update);
                                    //}
                                    //else if(sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Update)
                                    //{
                                    //    sprMefe.SetCRUDCell(i, "EMRG_ADTN_YN",   CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "PRSC_TIME_DVCD", CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "PRSC_TIME",      CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "REAL_PRDC_CD",   CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "POPUP_DVCD",     CRUD_TYPE.Update);
                                    //}

                                    // 저장되었다면 변경
                                    if (!(string.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_SQNO").ToString()) || sprMefe.GetValue(i, "PRSC_SQNO").ToString() == "0"))
                                    {
                                        if (!(ORBizCommon.UpdateOpInfo(otpt_adms_dvcd, pid, pt_cmhs_no, mdcr_dd,
                                                                       sprMefe.GetValue(i, "PRSC_SQNO").ToString(), prsc_notm, "EMCFLAG", sprMefe.GetValue(i, "RCPT_YN").ToString(),
                                                                       sprMefe.GetValue(i, "OP_DVCD").ToString(), "", "", "", pop.PRSC_TIME_DVCD, pop.PRSC_TIME, pop.EMRG_ADTN_YN,
                                                                       pop.REAL_PRDC_CD, sprMefe.GetValue(i, "POPUP_DVCD").ToString(), ref errmsg)))
                                        {
                                            LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                            pop.Dispose();
                                            return false;
                                        }

                                        saveflag = true;
                                    }
                                }

                                pop.Dispose();
                            }
                        }

                        // 응급가산적용이 아닐 때
                        if (emer_flag == "N")
                        {
                            // 수술구분 과 야간 및 휴일 가산 항목 인 경우
                            if (op_dvcd2 == "Y")
                            {
                                // 수술구분/시간가산구분 설정
                                popSetOperFlagTimeAdd pop = new popSetOperFlagTimeAdd("V", sprMefe.GetValue(i, "OP_DVCD").ToString(), sprMefe.GetValue(i, "PRSC_TIME").ToString(), sprMefe.GetValue(i, "PRSC_TIME_DVCD").ToString(), mefeinfo["CMPT_DLWT_CD_1"].ToString(), sprMefe.GetValue(i, "PRSC_NM").ToString());
                                if (pop.ShowDialog() == DialogResult.OK)
                                {

                                    sprMefe.SetText(i, "OP_DVCD", pop.OP_DVCD);
                                    sprMefe.SetText(i, "EMRG_ADTN_YN", pop.EMRG_ADTN_YN);
                                    sprMefe.SetText(i, "PRSC_TIME_DVCD", pop.PRSC_TIME_DVCD);
                                    sprMefe.SetText(i, "PRSC_TIME", pop.PRSC_TIME);
                                    sprMefe.SetText(i, "POPUP_DVCD", "04");
                                    //if(sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Read)
                                    //{
                                    //    sprMefe.SetCRUDToRow(i,                  CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "OP_DVCD",        CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "EMRG_ADTN_YN",   CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "PRSC_TIME_DVCD", CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "PRSC_TIME",      CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "POPUP_DVCD",     CRUD_TYPE.Update);
                                    //}
                                    //else if(sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Update)
                                    //{
                                    //    sprMefe.SetCRUDCell(i, "OP_DVCD",        CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "EMRG_ADTN_YN",   CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "PRSC_TIME_DVCD", CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "PRSC_TIME",      CRUD_TYPE.Update);
                                    //    sprMefe.SetCRUDCell(i, "POPUP_DVCD",     CRUD_TYPE.Update);
                                    //}

                                    // 저장되었다면 변경
                                    if (!(string.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_SQNO").ToString()) || sprMefe.GetValue(i, "PRSC_SQNO").ToString() == "0"))
                                    {
                                        if (!(ORBizCommon.UpdateOpInfo(otpt_adms_dvcd, pid, pt_cmhs_no, mdcr_dd,
                                                                       sprMefe.GetValue(i, "PRSC_SQNO").ToString(), prsc_notm, "OPFLAG", sprMefe.GetValue(i, "RCPT_YN").ToString(),
                                                                       pop.OP_DVCD, "", "", "", pop.PRSC_TIME_DVCD, pop.PRSC_TIME, pop.EMRG_ADTN_YN,
                                                                       sprMefe.GetValue(i, "REAL_PRDC_CD").ToString(),
                                                                       sprMefe.GetValue(i, "POPUP_DVCD").ToString(), ref errmsg)))
                                        {
                                            LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                            pop.Dispose();
                                            return false;
                                        }

                                        saveflag = true;
                                    }
                                }

                                pop.Dispose();
                            }
                            // 그 외
                            else
                            {
                                // 야간 및 휴일 가산 항목 인 경우
                                if (op_dvcd1 == "Y")
                                {
                                    // 마취항목 설정
                                    if (mefeinfo["HLNS_CLUS_DVCD"].ToString() == "05")
                                        mefeinfo["CMPT_DLWT_CD_1"] = "1";

                                    // 수술/시간가산구분 설정
                                    popSetOperTimeAdd pop = new popSetOperTimeAdd("V", sprMefe.GetValue(i, "PRSC_TIME").ToString(), sprMefe.GetValue(i, "PRSC_TIME_DVCD").ToString(), mefeinfo["CMPT_DLWT_CD_1"].ToString(), sprMefe.GetValue(i, "PRSC_NM").ToString());
                                    if (pop.ShowDialog() == DialogResult.OK)
                                    {
                                        sprMefe.SetText(i, "EMRG_ADTN_YN", pop.EMRG_ADTN_YN);
                                        sprMefe.SetText(i, "PRSC_TIME_DVCD", pop.PRSC_TIME_DVCD);
                                        sprMefe.SetText(i, "PRSC_TIME", pop.PRSC_TIME);
                                        sprMefe.SetText(i, "POPUP_DVCD", "05");
                                        //if(sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Read)
                                        //{
                                        //    sprMefe.SetCRUDToRow(i, CRUD_TYPE.Update);
                                        //    sprMefe.SetCRUDCell(i, "EMRG_ADTN_YN",   CRUD_TYPE.Update);
                                        //    sprMefe.SetCRUDCell(i, "PRSC_TIME_DVCD", CRUD_TYPE.Update);
                                        //    sprMefe.SetCRUDCell(i, "PRSC_TIME",      CRUD_TYPE.Update);
                                        //    sprMefe.SetCRUDCell(i, "POPUP_DVCD",     CRUD_TYPE.Update);
                                        //}
                                        //else if(sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Update)
                                        //{
                                        //    sprMefe.SetCRUDCell(i, "EMRG_ADTN_YN",   CRUD_TYPE.Update);
                                        //    sprMefe.SetCRUDCell(i, "PRSC_TIME_DVCD", CRUD_TYPE.Update);
                                        //    sprMefe.SetCRUDCell(i, "PRSC_TIME",      CRUD_TYPE.Update);
                                        //    sprMefe.SetCRUDCell(i, "POPUP_DVCD",     CRUD_TYPE.Update);
                                        //}

                                        // 저장되었다면 변경
                                        if (!(string.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_SQNO").ToString()) || sprMefe.GetValue(i, "PRSC_SQNO").ToString() == "0"))
                                        {
                                            if (!(ORBizCommon.UpdateOpInfo(otpt_adms_dvcd, pid, pt_cmhs_no, mdcr_dd,
                                                                           sprMefe.GetValue(i, "PRSC_SQNO").ToString(), prsc_notm, "OPFLAG", sprMefe.GetValue(i, "RCPT_YN").ToString(),
                                                                           sprMefe.GetValue(i, "OP_DVCD").ToString(), "", "", "", pop.PRSC_TIME_DVCD, pop.PRSC_TIME, pop.EMRG_ADTN_YN,
                                                                           sprMefe.GetValue(i, "REAL_PRDC_CD").ToString(),
                                                                           sprMefe.GetValue(i, "POPUP_DVCD").ToString(), ref errmsg)))
                                            {
                                                LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                                pop.Dispose();
                                                return false;
                                            }

                                            saveflag = true;
                                        }
                                    }

                                    pop.Dispose();
                                }
                            }
                        }
                    }

                    // 마취 Set코드 관리항목 설정
                    if (mefeinfo["HLNS_CLUS_DVCD"].ToString() == "05" && mefeinfo["HLNS_SBIT_DVCD"].ToString() == "01" && mefeinfo["CMPT_DLWT_CD_2"].ToString() == "1")
                    {
                        DataRow anstinfo = null;

                        // 마취정보를 불러온다.
                        anstinfo = ORBizCommon.GetPatAnstInfo(pid, mdcr_dd, ref errmsg);
                        if (anstinfo == null && !string.IsNullOrWhiteSpace(errmsg))
                        {
                            return false;
                        }

                        // 마취시간 및 야간가산 구분을 입력받는다.
                        popSetAnstInfoTimeAdd pop = new popSetAnstInfoTimeAdd("V", sprMefe.GetValue(i, "ANST_MTHD_DVCD").ToString(), sprMefe.GetValue(i, "ANST_TIME").ToString(), sprMefe.GetValue(i, "ANST_INHL_PRDT_CD").ToString(), sprMefe.GetValue(i, "PRSC_TIME_DVCD").ToString(), anstinfo["ANST_STRT_TIME"].ToString(), anstinfo["ANST_TIME"].ToString(),
                                                    anstinfo["ANST_CD"].ToString(), anstinfo["ANST_NM"].ToString(), sprMefe.GetValue(i, "PRSC_TIME_DVCD").ToString(), sprMefe.GetValue(i, "PRSC_NM").ToString(), mdcr_dd);
                        pop.PRSC_TIME = sprMefe.GetValue(i, "PRSC_TIME").ToString();
                        if (pop.ShowDialog() == DialogResult.OK)
                        {
                            DataTable anstcd = new DataTable();
                            string anst_pnpy_dvcd = string.Empty;

                            sprMefe.SetText(i, "ANST_MTHD_DVCD", pop.ANST_MTHD_DVCD);
                            sprMefe.SetText(i, "ANST_INHL_PRDT_CD", pop.ANST_INHL_PRDT_CD);
                            sprMefe.SetText(i, "ANST_TIME", pop.ANST_TIME);
                            sprMefe.SetText(i, "PRSC_TIME_DVCD", pop.PRSC_TIME_DVCD);
                            sprMefe.SetText(i, "PRSC_TIME", pop.PRSC_TIME);
                            sprMefe.SetText(i, "POPUP_DVCD", "02");
                            //if(sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Read)
                            //{
                            //    sprMefe.SetCRUDToRow(i, CRUD_TYPE.Update);
                            //    sprMefe.SetCRUDCell(i, "ANST_MTHD_DVCD",    CRUD_TYPE.Update);
                            //    sprMefe.SetCRUDCell(i, "ANST_INHL_PRDT_CD", CRUD_TYPE.Update);
                            //    sprMefe.SetCRUDCell(i, "ANST_TIME",         CRUD_TYPE.Update);
                            //    sprMefe.SetCRUDCell(i, "PRSC_TIME_DVCD",    CRUD_TYPE.Update);
                            //    sprMefe.SetCRUDCell(i, "PRSC_TIME",         CRUD_TYPE.Update);
                            //    sprMefe.SetCRUDCell(i, "POPUP_DVCD",        CRUD_TYPE.Update);
                            //}
                            //else if(sprMefe.GetCRUDFromRow(i) == CRUD_TYPE.Update)
                            //{
                            //    sprMefe.SetCRUDCell(i, "ANST_MTHD_DVCD",    CRUD_TYPE.Update);
                            //    sprMefe.SetCRUDCell(i, "ANST_INHL_PRDT_CD", CRUD_TYPE.Update);
                            //    sprMefe.SetCRUDCell(i, "ANST_TIME",         CRUD_TYPE.Update);
                            //    sprMefe.SetCRUDCell(i, "PRSC_TIME_DVCD",    CRUD_TYPE.Update);
                            //    sprMefe.SetCRUDCell(i, "PRSC_TIME",         CRUD_TYPE.Update);
                            //    sprMefe.SetCRUDCell(i, "POPUP_DVCD",        CRUD_TYPE.Update);
                            //}

                            // 저장되었다면 변경
                            if (!(string.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_SQNO").ToString()) || sprMefe.GetValue(i, "PRSC_SQNO").ToString() == "0"))
                            {
                                if (!(ORBizCommon.UpdateOpInfo(otpt_adms_dvcd, pid, pt_cmhs_no, mdcr_dd,
                                                               sprMefe.GetValue(i, "PRSC_SQNO").ToString(), prsc_notm, "ANSTFLAG", sprMefe.GetValue(i, "RCPT_YN").ToString(),
                                                               sprMefe.GetValue(i, "OP_DVCD").ToString(), pop.ANST_MTHD_DVCD, pop.ANST_INHL_PRDT_CD, pop.ANST_TIME, pop.PRSC_TIME_DVCD, pop.PRSC_TIME, "",
                                                               sprMefe.GetValue(i, "REAL_PRDC_CD").ToString(),
                                                               sprMefe.GetValue(i, "POPUP_DVCD").ToString(), ref errmsg)))
                                {
                                    LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                    pop.Dispose();
                                    return false;
                                }

                                saveflag = true;
                            }
                        }
                        pop.Dispose();
                    }

                    // 건강보험 항구분코드로 가산설정
                    switch (mefeinfo["HLNS_CLUS_DVCD"].ToString())
                    {
                        // 화상 치료 목적 항목
                        case "08":
                            if (mefeinfo["MEFE_DVCD"].ToString() == "1" && (mefeinfo["CMPT_DLWT_CD_3"].ToString() == "3" || mefeinfo["CMPT_DLWT_CD_3"].ToString() == "9"))
                            {
                                //2018.03.28 박민규 옵션 추가
                                if (ConfigService.GetConfigValueString("OR", "BURN_APP_YN", "USE_YN") == "Y")
                                {
                                    sprMefe.SetText(i, "ANST_MTHD_DVCD", "A");

                                    sql = "UPDATE ORORDRRT SET ANST_MTHD_DVCD = 'A' WHERE PID = '{0}' AND PT_CMHS_NO = {1} AND MDCR_DD = '{2}' AND PRSC_SQNO = {3}";

                                    // 저장되었다면 변경
                                    if (!(string.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_SQNO").ToString()) || sprMefe.GetValue(i, "PRSC_SQNO").ToString() == "0"))
                                    {
                                        if (!DBService.ExecuteNonQuery(string.Format(sql, pid, pt_cmhs_no, mdcr_dd, sprMefe.GetValue(i, "PRSC_SQNO").ToString())))
                                        {
                                            errmsg = "화상 치료 목적 항목 변경 중 오류가 발생했습니다.";
                                            LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                            return false;
                                        }

                                        saveflag = true;
                                    }
                                }
                                else
                                {
                                    DialogResult result = LxMessage.Show("화상 치료 목적입니까?\r\n화상 치료 목적의 경우 30% 가산됩니다.", "알림", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                    if (result == DialogResult.Yes)
                                    {
                                        sprMefe.SetText(i, "ANST_MTHD_DVCD", "A");

                                        sql = "UPDATE ORORDRRT SET ANST_MTHD_DVCD = 'A' WHERE PID = '{0}' AND PT_CMHS_NO = {1} AND MDCR_DD = '{2}' AND PRSC_SQNO = {3}";

                                        // 저장되었다면 변경
                                        if (!(string.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_SQNO").ToString()) || sprMefe.GetValue(i, "PRSC_SQNO").ToString() == "0"))
                                        {
                                            if (!DBService.ExecuteNonQuery(string.Format(sql, pid, pt_cmhs_no, mdcr_dd, sprMefe.GetValue(i, "PRSC_SQNO").ToString())))
                                            {
                                                errmsg = "화상 치료 목적 항목 변경 중 오류가 발생했습니다.";
                                                LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                                return false;
                                            }

                                            saveflag = true;
                                        }
                                    }
                                    else
                                    {
                                        sprMefe.SetText(i, "ANST_MTHD_DVCD", "");

                                        sql = "UPDATE ORORDRRT SET ANST_MTHD_DVCD = '' WHERE PID = '{0}' AND PT_CMHS_NO = {1} AND MDCR_DD = '{2}' AND PRSC_SQNO = {3}";

                                        // 저장되었다면 변경
                                        if (!(string.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_SQNO").ToString()) || sprMefe.GetValue(i, "PRSC_SQNO").ToString() == "0"))
                                        {
                                            if (!DBService.ExecuteNonQuery(string.Format(sql, pid, pt_cmhs_no, mdcr_dd, sprMefe.GetValue(i, "PRSC_SQNO").ToString())))
                                            {
                                                errmsg = "화상 치료 목적 항목 변경 중 오류가 발생했습니다.";
                                                LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                                return false;
                                            }

                                            saveflag = true;
                                        }
                                    }
                                }
                            }
                            break;

                        case "09":
                            if (mefeinfo["MEFE_DVCD"].ToString() == "1")
                            {
                                // 치료목적 천자실시
                                if (mefeinfo["CMPT_DLWT_CD_3"].ToString() == "3")
                                {

                                    //2018.03.28 박민규 문구변경
                                    DialogResult result = LxMessage.Show("치료 목적에 의한 천자실시입니까?\r\n치료 목적의 경우 30% 가산됩니다.", "알림", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                    if (result == DialogResult.Yes)
                                    {
                                        sprMefe.SetText(i, "OP_DVCD", "3");

                                        sql = "UPDATE ORORDRRT SET OP_DVCD = '3' WHERE PID = '{0}' AND PT_CMHS_NO = {1} AND MDCR_DD = '{2}' AND PRSC_SQNO = {3}";

                                        // 저장되었다면 변경
                                        if (!(string.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_SQNO").ToString()) || sprMefe.GetValue(i, "PRSC_SQNO").ToString() == "0"))
                                        {
                                            if (!DBService.ExecuteNonQuery(string.Format(sql, pid, pt_cmhs_no, mdcr_dd, sprMefe.GetValue(i, "PRSC_SQNO").ToString())))
                                            {
                                                errmsg = "천자실시 치료 목적 항목 변경 중 오류가 발생했습니다.";
                                                LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                                return false;
                                            }

                                            saveflag = true;
                                        }
                                    }
                                    else
                                    {
                                        sprMefe.SetText(i, "OP_DVCD", "");

                                        sql = "UPDATE ORORDRRT SET OP_DVCD = '' WHERE PID = '{0}' AND PT_CMHS_NO = {1} AND MDCR_DD = '{2}' AND PRSC_SQNO = {3}";

                                        // 저장되었다면 변경
                                        if (!(string.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_SQNO").ToString()) || sprMefe.GetValue(i, "PRSC_SQNO").ToString() == "0"))
                                        {
                                            if (!DBService.ExecuteNonQuery(string.Format(sql, pid, pt_cmhs_no, mdcr_dd, sprMefe.GetValue(i, "PRSC_SQNO").ToString())))
                                            {
                                                errmsg = "천자실시 치료 목적 항목 변경 중 오류가 발생했습니다.";
                                                LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                                return false;
                                            }

                                            saveflag = true;
                                        }
                                    }
                                }

                                // 도플러검사(초음파)
                                if (mefeinfo["CMPT_DLWT_CD_2"].ToString() == "2")
                                {
                                    sql = "UPDATE ORORDRRT " +
                                          "   SET OP_DVCD = 'A' " +
                                          "     , PRSC_NM = '[Doppler]" + sprMefe.GetValue(i, "PRSC_NM").ToString() + "' " +
                                          " WHERE PID = '{0}' AND PT_CMHS_NO = {1} AND MDCR_DD = '{2}' AND PRSC_SQNO = {3}";

                                    DialogResult result = LxMessage.Show("도플러검사(초음파)를 실시하는 경우입니까?\r\n도플러검사의 경우 10% 가산됩니다.", "알림", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                    if (result == DialogResult.Yes)
                                    {
                                        sprMefe.SetText(i, "OP_DVCD", "A");
                                        sprMefe.SetText(i, "PRSC_NM", "[Doppler]" + sprMefe.GetValue(i, "PRSC_NM").ToString());

                                        sprMefe.SetOldValue(i, "PRSC_NM", "[Doppler]" + sprMefe.GetValue(i, "PRSC_NM").ToString());

                                        ORBizCommon.SetRowMefeData(sprMefe, i);

                                        // 저장되었다면 변경
                                        if (!(string.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_SQNO").ToString()) || sprMefe.GetValue(i, "PRSC_SQNO").ToString() == "0"))
                                        {
                                            if (!DBService.ExecuteNonQuery(string.Format(sql, pid, pt_cmhs_no, mdcr_dd, sprMefe.GetValue(i, "PRSC_SQNO").ToString())))
                                            {
                                                errmsg = "도플러검사(초음파) 항목 변경 중 오류가 발생했습니다.";
                                                LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                                return false;
                                            }

                                            saveflag = true;
                                        }
                                    }
                                    else
                                    {
                                        sprMefe.SetText(i, "OP_DVCD", "");
                                        sprMefe.SetText(i, "PRSC_NM", sprMefe.GetValue(i, "PRSC_NM").ToString().Replace("[Doppler]", ""));

                                        sprMefe.SetOldValue(i, "PRSC_NM", sprMefe.GetValue(i, "PRSC_NM").ToString().Replace("[Doppler]", ""));

                                        ORBizCommon.SetRowMefeData(sprMefe, i);

                                        sql = "UPDATE ORORDRRT " +
                                          "   SET OP_DVCD = '' " +
                                          "     , PRSC_NM = '" + sprMefe.GetValue(i, "PRSC_NM").ToString().Replace("[Doppler]", "") + "' " +
                                          " WHERE PID = '{0}' AND PT_CMHS_NO = {1} AND MDCR_DD = '{2}' AND PRSC_SQNO = {3}";

                                        // 저장되었다면 변경
                                        if (!(string.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_SQNO").ToString()) || sprMefe.GetValue(i, "PRSC_SQNO").ToString() == "0"))
                                        {
                                            if (!DBService.ExecuteNonQuery(string.Format(sql, pid, pt_cmhs_no, mdcr_dd, sprMefe.GetValue(i, "PRSC_SQNO").ToString())))
                                            {
                                                errmsg = "도플러검사(초음파) 항목 변경 중 오류가 발생했습니다.";
                                                LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                                return false;
                                            }

                                            saveflag = true;
                                        }
                                    }
                                }

                                // 근전도 검사(부위 설정)
                                if (mefeinfo["SITE_APLY_DVCD"].ToString() == "1" || mefeinfo["SITE_APLY_DVCD"].ToString() == "3")
                                {
                                    string site_code = string.Empty;
                                    string site_name = string.Empty;

                                    popMefeSite pop = new popMefeSite("2", mefeinfo["SITE_APLY_DVCD"].ToString());
                                    if (pop.ShowDialog() == DialogResult.OK)
                                    {
                                        site_code = pop.Codeflag;
                                        site_name = pop.Codename;

                                        sprMefe.SetText(i, "PRSC_NM", site_name + sprMefe.GetValue(i, "PRSC_NM").ToString());

                                        sql = "UPDATE ORORDRRT " +
                                              "   SET PRSC_NM = '" + site_name + sprMefe.GetValue(i, "PRSC_NM").ToString() + "'" +
                                              " WHERE PID = '{0}' AND PT_CMHS_NO = {1} AND MDCR_DD = '{2}' AND PRSC_SQNO = {3}";

                                        // Both일 경우
                                        if (site_code == "3")
                                        {
                                            sprMefe.SetText(i, "PRSC_INPT_QTY", "2");
                                            sprMefe.SetText(i, "ONTM_QTY", "2");
                                            sprMefe.SetText(i, "CNFR_DVCD", "POS");
                                            sprMefe.SetText(i, "CNFR_CD", "B");

                                            sql = "UPDATE ORORDRRT " +
                                                  "   SET PRSC_INPT_QTY = 2 " +
                                                  "     , ONTM_QTY      = 2 " +
                                                  "     , CNFR_DVCD     = 'POS' " +
                                                  "     , CNFR_CD       = 'B' " +
                                                  "     , PRSC_NM       = '" + site_name + sprMefe.GetValue(i, "PRSC_NM").ToString() + "'" +
                                                  " WHERE PID = '{0}' AND PT_CMHS_NO = {1} AND MDCR_DD = '{2}' AND PRSC_SQNO = {3}";
                                        }

                                        // 저장되었다면 변경
                                        if (!(string.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_SQNO").ToString()) || sprMefe.GetValue(i, "PRSC_SQNO").ToString() == "0"))
                                        {
                                            if (!DBService.ExecuteNonQuery(string.Format(sql, pid, pt_cmhs_no, mdcr_dd, sprMefe.GetValue(i, "PRSC_SQNO").ToString())))
                                            {
                                                errmsg = "근전도 검사 항목 변경 중 오류가 발생했습니다.";
                                                LxMessage.Show(errmsg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                                pop.Dispose();
                                                return false;
                                            }

                                            saveflag = true;
                                        }
                                    }

                                    pop.Dispose();
                                }
                            }
                            break;
                    }

                    // 산소 투여시간 설정(EDI[A00000002], [699900020])
                    if (mefeinfo["EDI_CD"].ToString() == "A00000002" || mefeinfo["EDI_CD"].ToString() == "699900020")
                    {
                        string[] o2data = new string[4];
                        string etc_use_cnts_4 = string.Empty;

                        etc_use_cnts_4 = sprMefe.GetValue(i, "ETC_USE_CNTS_4").ToString();
                        if (string.IsNullOrWhiteSpace(etc_use_cnts_4))
                            continue;

                        o2data = etc_use_cnts_4.Split('/');

                        popSetOxygenInfo pop = new popSetOxygenInfo(o2data[0], o2data[1], o2data[2], o2data[3]);
                        if (pop.ShowDialog() == DialogResult.OK)
                        {
                            if (!(string.IsNullOrWhiteSpace(pop.Qty)))
                            {
                                sprMefe.SetText(i, "PRSC_INPT_QTY", pop.Qty);
                                sprMefe.SetText(i, "ONTM_QTY", pop.Qty);
                                sprMefe.SetText(i, "PRSC_NM", mefeinfo["MEFE_HNM"].ToString() + pop.Set_cnts);
                                sprMefe.SetText(i, "ETC_USE_CNTS_4", pop.Liter + "/" + pop.Strt_Time + "/" + pop.End_Time + "/" + pop.AllCheck);

                                sprMefe.SetOldValue(i, "PRSC_INPT_QTY", pop.Qty);
                                sprMefe.SetOldValue(i, "ONTM_QTY", pop.Qty);
                                sprMefe.SetOldValue(i, "PRSC_NM", mefeinfo["MEFE_HNM"].ToString() + pop.Set_cnts);
                                sprMefe.SetOldValue(i, "ETC_USE_CNTS_4", pop.Liter + "/" + pop.Strt_Time + "/" + pop.End_Time + "/" + pop.AllCheck);

                                ORBizCommon.SetRowMefeData(sprMefe, i);

                                // 저장되었다면 변경
                                if (!(string.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_SQNO").ToString()) || sprMefe.GetValue(i, "PRSC_SQNO").ToString() == "0"))
                                {
                                    if (!DBService.ExecuteNonQuery(SQL.OR.Sql.UpdateO2ORORDRRT(), pid
                                                                                               , pt_cmhs_no
                                                                                               , mdcr_dd
                                                                                               , sprMefe.GetValue(i, "PRSC_SQNO").ToString()
                                                                                               , pop.Qty
                                                                                               , sprMefe.GetValue(i, "PRSC_NM").ToString()
                                                                                               , sprMefe.GetValue(i, "ETC_USE_CNTS_4").ToString()))
                                    {
                                        LxMessage.Show("산소정보 저장 중 오류가 발생했습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                        pop.Dispose();
                                        return false;
                                    }

                                    saveflag = true;
                                }
                            }
                        }

                        pop.Dispose();
                    }

                    // 제한적 / 조영제 사용 / 도플러 가산
                    if (mefeinfo["HLNS_CLUS_DVCD"].ToString() == "09" &&
                        mefeinfo["HLNS_SBIT_DVCD"].ToString() == "01" &&
                        new string[] { "1", "2" }.Any(s => s == sprMefe.GetValue(i, "PNPY_DVCD").ToString()) &&
                        new string[] { "R", "S", "T", "U", "V", "W" }.Any(s => s == mefeinfo["CMPT_DLWT_CD_2"].ToString()))
                    {
                        string sqltext = "update orordrrt set op_dvcd = '{4}' where pid = '{0}' and pt_cmhs_no = '{1}' and mdcr_dd = '{2}' and prsc_sqno = '{3}'";

                        using (popSetSonoContrast pop = new popSetSonoContrast(mefeinfo["CMPT_DLWT_CD_2"].ToString(), prsc_cd, prsc_nm, sprMefe.GetValue(i, "OP_DVCD").ToString()))
                        {
                            pop.ShowDialog();

                            string currentOpDvcd = sprMefe.GetValue(i, "OP_DVCD").ToString();
                            string changeOpDvcd = pop.OP_DVCD;

                            sprMefe.SetText(i, "OP_DVCD", changeOpDvcd);

                            if (!string.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_SQNO").ToString()) &&
                                currentOpDvcd != changeOpDvcd)
                            {
                                if (!DBService.ExecuteNonQuery(sqltext
                                    , pid
                                    , pt_cmhs_no
                                    , mdcr_dd
                                    , sprMefe.GetValue(i, "PRSC_SQNO").ToString()
                                    , changeOpDvcd
                                    ))
                                {
                                    LxMessage.ShowError("초음파 가산 정보 저장 중 오류가 발생하였습니다.");
                                    return false;
                                }

                                saveflag = true;
                            }
                        }
                    }

                    // 창상봉합술
                    if (mefeinfo["HLNS_CLUS_DVCD"].ToString() == "08" && mefeinfo["HLNS_SBIT_DVCD"].ToString() == "01" && mefeinfo["CMPT_DLWT_CD_3"].ToString() == "W" && sprMefe.GetValue(i, "DC_PRSC_DVCD").ToString() == "A")
                    {
                        using (popSetWoundSuture pop = new popSetWoundSuture(mefeinfo["MEFE_CD"].ToString(), mefeinfo["MEFE_HNM"].ToString(), sprMefe.GetValue(i, "WNDS_DVCD").ToString()))
                        {
                            if (pop.ShowDialog() == DialogResult.OK)
                            {
                                string chng_prsc_nm = $"{mefeinfo["MEFE_HNM"].ToString()}({pop.GetText("-")})";
                                string chng_wnds_dvcd = pop.GetValue("|");

                                if ((sprMefe.ActiveColumn?.Tag?.ToString() ?? "") == "PRSC_NM")
                                    BizCommon.SetRowFocus(sprMefe, i, "FLAG");

                                sprMefe.SetText(i, "PRSC_NM", chng_prsc_nm);
                                sprMefe.SetText(i, "WNDS_DVCD", chng_wnds_dvcd);
                                sprMefe.SetOldValue(i, "PRSC_NM", chng_prsc_nm);
                                sprMefe.SetOldValue(i, "WNDS_DVCD", chng_wnds_dvcd);

                                if (!string.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_UNIQ_NO").ToString()))
                                {
                                    if (!DBService.ExecuteNonQuery($"update orordrrt set prsc_nm = '{chng_prsc_nm}' where prsc_uniq_no = {sprMefe.GetValue(i, "PRSC_UNIQ_NO").ToString()}"))
                                    {
                                        LxMessage.ShowError("창상봉합술 가산 정보 저장 중 오류가 발생하였습니다.");
                                        return false;
                                    }
                                    if (!DBService.ExecuteNonQuery($"update oradecma set etc_use_cnts_18 = '{chng_wnds_dvcd}' where pid = '{pid}' and prsc_uniq_no = {sprMefe.GetValue(i, "PRSC_UNIQ_NO").ToString()}"))
                                    {
                                        LxMessage.ShowError("창상봉합술 가산 정보 저장 중 오류가 발생하였습니다.");
                                        return false;
                                    }

                                    saveflag = true;
                                }
                            }
                        }
                    }

                    // 원무계산적용여부를 업데이트한다.
                    // 저장되는 처방 확인
                    if (saveflag)
                    {
                        if (!(string.IsNullOrWhiteSpace(sprMefe.GetValue(i, "PRSC_SQNO").ToString()) || sprMefe.GetValue(i, "PRSC_SQNO").ToString() == "0"))
                        {
                            if (otpt_adms_dvcd == "I")
                            {
                                sprMefe.SetText(i, "PTAF_CLCL_APLY_YN", "N");

                                // 계산적용 변경
                                if (!DBService.ExecuteNonQuery(SQL.OR.Sql.UpdatePtafClclAplyYnORORDRRT(), DateTime.Now.ToString("yyyyMMddHHmmss")
                                                                                                        , DOPack.UserInfo.USER_CD
                                                                                                        , pid
                                                                                                        , pt_cmhs_no
                                                                                                        , mdcr_dd
                                                                                                        , sprMefe.GetValue(i, "PRSC_SQNO").ToString()))
                                {
                                    LxMessage.Show("계산적용 여부 변경 중 오류가 발생했습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                    return false;
                                }

                                saveflag = true;
                            }
                        }
                    }
                }
            }

            if (saveflag)
            {
                LxMessage.Show("저장 되었습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information, 2);
            }

            return true;
        }
    }
}
