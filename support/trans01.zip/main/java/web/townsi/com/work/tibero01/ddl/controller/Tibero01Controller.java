//package web.townsi.com.work.tibero01.ddl.controller;
//
//import java.util.HashMap;
//import java.util.LinkedHashMap;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//
//import web.townsi.com.work.tibero01.ddl.biz.Tibero01Biz;
//
//@Controller
//@RequestMapping({ "/tibero01" })
//@SuppressWarnings({"rawtypes","unchecked"})
//public class Tibero01Controller {
//
//	private Logger logger = LoggerFactory.getLogger(Tibero01Controller.class);
//
//	@Autowired
//	private Tibero01Biz tibero01Biz;
//
//	@RequestMapping({ "/selectTableCountList" })
//	public ResponseEntity<HashMap> selectTableCountList(@RequestParam HashMap<String, Object> params, Model model) throws Exception {
//		LinkedHashMap resultMap = new LinkedHashMap();
//		ResponseEntity entity = null;
//		try {
//			HashMap resultObj  = this.tibero01Biz.selectTableCountList(params);
//			resultMap.put("resultObj", resultObj);
//			resultMap.put("param", params);
//			entity = new ResponseEntity(resultMap, HttpStatus.OK);
//		} catch (Exception e) {
//			logger.error("{}", e);
//			resultMap.put("error", e.getMessage());
//			entity = new ResponseEntity(resultMap, HttpStatus.INTERNAL_SERVER_ERROR);
//			
//		}
//		return entity;
//	}
//	
//	@RequestMapping({ "/dropCreateTable" })
//	public ResponseEntity<HashMap> dropCreateTable(@RequestParam HashMap<String, Object> params, Model model) throws Exception {
//		LinkedHashMap resultMap = new LinkedHashMap();
//		ResponseEntity entity = null;
//		try {
//			HashMap resultObj  = this.tibero01Biz.dropCreateTable(params);
//			resultMap.put("resultObj", resultObj);
//			resultMap.put("param", params);
//			entity = new ResponseEntity(resultMap, HttpStatus.OK);
//		} catch (Exception e) {
//			logger.error("{}", e);
//			resultMap.put("error", e.getMessage());
//			entity = new ResponseEntity(resultMap, HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//		return entity;
//	}
//	
//	@RequestMapping({ "/dropTable" })
//	public ResponseEntity<HashMap> dropTable(@RequestParam HashMap<String, Object> params, Model model) throws Exception {
//		LinkedHashMap resultMap = new LinkedHashMap();
//		ResponseEntity entity = null;
//		try {
//			tibero01Biz.dropTable(params);
//			resultMap.put("param", params);
//			entity = new ResponseEntity(resultMap, HttpStatus.OK);
//		} catch (Exception e) {
//			logger.error("{}", e);
//			resultMap.put("error", e.getMessage());
//			entity = new ResponseEntity(resultMap, HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//		return entity;
//	}
//	
//	@RequestMapping({ "/deleteTable" })
//	public ResponseEntity<HashMap> deleteTable(@RequestParam HashMap<String, Object> params, Model model) throws Exception {
//		LinkedHashMap resultMap = new LinkedHashMap();
//		ResponseEntity entity = null;
//		try {
//			HashMap resultObj  = tibero01Biz.deleteTable(params);
//			resultMap.put("resultObj", resultObj);
//			resultMap.put("param", params);
//			entity = new ResponseEntity(resultMap, HttpStatus.OK);
//		} catch (Exception e) {
//			logger.error("{}", e);
//			resultMap.put("error", e.getMessage());
//			entity = new ResponseEntity(resultMap, HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//		return entity;
//	}
//	
//	@RequestMapping({ "/copyData" })
//	public ResponseEntity<HashMap> copyData(@RequestParam HashMap<String, Object> params, Model model) throws Exception {
//		LinkedHashMap resultMap = new LinkedHashMap();
//		ResponseEntity entity = null;
//		try {
//			HashMap resultObj  = this.tibero01Biz.dropCreateTable(params);
//			resultMap.put("resultObj", resultObj);
//			resultMap.put("param", params);
//			entity = new ResponseEntity(resultMap, HttpStatus.OK);
//		} catch (Exception e) {
//			logger.error("{}", e);
//			resultMap.put("error", e.getMessage());
//			entity = new ResponseEntity(resultMap, HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//		return entity;
//	}
//	
//
//
//
//}