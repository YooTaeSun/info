//**********************************************************
// Class 명 : ucIRegistInf
// 역    할 : 입원접수등록정보 UserControl
// 작 성 자 : PGH
// 작 성 일 : 2017-09-07
//**********************************************************
using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public partial class ucIRegistInf : BaseUserControl
    {
        #region Define : Event

        public delegate void PatientSelectedEventHandler();
        public event PatientSelectedEventHandler PatientSelected;

        #endregion Define: Event

        #region Define : Member
        
        private string m_MainSubAdmsDvcd = string.Empty;
        clsAdmsRegistrationInfo m_AdmsRegInfo = new clsAdmsRegistrationInfo();          // 입원접수정보
        clsAdmsChangeInfo m_AdmsChngInfo = new clsAdmsChangeInfo();               // 입원변경정보

        private ucIPatientInf1 m_UcIPateintInfo = null;       // 환자정보
        private ucORegistLst m_UcORegistLst = null;       // 외래접수내역
        private ucODiseaseLst m_UcODiseaseLst = null;       // 외래주상병내역
        private ucIRoomStt m_UcRoomStt = null;       // 병실현황
        private ucIAdmissionInf m_UcIAdmsDecInf = null;       // 입원결정추가정보

        public string m_AllOutReg = "N";                        // 입원일 이후 모든 접수정보 표시여부

        private bool m_IsUpdate_PARMAPMA = false;

        public delegate void GetAdmsDdTime(ref string adms_dd, ref string adms_time);
        public event GetAdmsDdTime OnGetAdmsDdTime;

        private string m_MainPtCmhsNo = string.Empty;
        public string MainPtCmhsNo { get => m_MainPtCmhsNo; set => m_MainPtCmhsNo = value; }

        #endregion Define : Member

        #region Define : Member Property

        public clsAdmsRegistrationInfo AdmsRegInfo
        {
            get { return m_AdmsRegInfo; }
            set { m_AdmsRegInfo = value; }
        }

        public clsAdmsChangeInfo AdmsChngInfo
        {
            get { return m_AdmsChngInfo; }
            set { m_AdmsChngInfo = value; }
        }

        public ucIPatientInf1 UcIPateintInfo
        {
            get { return m_UcIPateintInfo; }
            set { m_UcIPateintInfo = value; }
        }

        public ucORegistLst UcORegistLst
        {
            get { return m_UcORegistLst; }
            set { m_UcORegistLst = value; }
        }

        public ucODiseaseLst UcODiseaseLst
        {
            get { return m_UcODiseaseLst; }
            set { m_UcODiseaseLst = value; }
        }

        public ucIRoomStt UcRoomStt
        {
            get { return m_UcRoomStt; }
            set { m_UcRoomStt = value; }
        }

        public ucIAdmissionInf UcIAdmsDecInf
        {
            get { return m_UcIAdmsDecInf; }
            set { m_UcIAdmsDecInf = value; }
        }

        DataTable m_BedNoDT = new DataTable();

        private string m_FCLT_APLY_YN = "N";

        #endregion  Define : Member Property

        #region Construction

        public ucIRegistInf()
        {
            InitializeComponent();
        }

        #endregion Construction

        #region Screen Load

    }
}
