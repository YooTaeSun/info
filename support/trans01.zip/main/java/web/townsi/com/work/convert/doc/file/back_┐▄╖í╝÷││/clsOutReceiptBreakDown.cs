// *******************************************************
// Class 명 : clsOutReceiptBreakDown
// 역    할 : 외래수납처방내역 (PAORECBD)
// 작 성 자 : PGH
// 작 성 일 : 2017-09-14
// *******************************************************
using System;
using System.Data;
using Lime.Framework;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public class clsOutReceiptBreakDown
    {
        #region Define Member Property

        private string m_PID = String.Empty;    //환자등록번호                     VARCHAR2(10)
        private int m_PT_CMHS_NO = 0;               //환자내원번호                     NUMBER(10, 0)
        private int m_RCPT_SQNO = 0;               //수납일련번호                     NUMBER(5, 0)
        private int m_APLY_SQNO = 0;               //적용일련번호                     NUMBER(3, 0)
        private int m_PRSC_SQNO = 0;               //처방일련번호                     NUMBER(5, 0)
        private string m_MDCR_DD = String.Empty;    //진료일자                         VARCHAR2(8)
        private string m_ACTG_DD = String.Empty;    //시행일자                         VARCHAR2(8)
        private string m_CLAM_CRTN_YN = String.Empty;    //청구생성여부                     VARCHAR2(1)
        private string m_REAL_PRDC_CD = String.Empty;    //실제처방의코드                   VARCHAR2(10)
        private string m_PRSC_DVCD = String.Empty;    //처방구분코드                     VARCHAR2(2)
        private int m_BNDL_PRSC_SQNO = 0;               //묶음처방일련번호                 NUMBER(3, 0)
        private string m_BNDL_MEFE_CD = String.Empty;    //묶음수가코드                     VARCHAR2(10)
        private string m_MEFE_CD = String.Empty;    //수가코드                         VARCHAR2(10)
        private string m_MEFE_NM = String.Empty;    //수가명                           VARCHAR2(200)
        private string m_EDI_CD = String.Empty;    //EDI코드                          VARCHAR2(10)
        private string m_PRFT_CD = String.Empty;    //수익코드                         VARCHAR2(10)
        private double m_ONTM_QTY = 0;               //1회수량                          NUMBER(10, 4)
        private int m_NOTM = 0;               //횟수                             NUMBER(3, 0)
        private int m_NODY = 0;               //일수                             NUMBER(3, 0)
        private string m_AOMD_MTHD_CD = String.Empty;    //투여방법코드                     VARCHAR2(10)
        private string m_OUPR_GRNT_NO = String.Empty;    //원외처방교부번호                 VARCHAR2(13)
        private string m_EXCP_RESN_CD = String.Empty;    //예외사유코드                     VARCHAR2(2)
        private string m_DLVR_DEPT_CD = String.Empty;    //전달부서코드                     VARCHAR2(10)
        private string m_ACTG_DEPT_CD = String.Empty;    //시행부서코드                     VARCHAR2(10)
        private string m_CLCL_DVCD = String.Empty;    //계산구분코드                     VARCHAR2(2)
        private string m_ACTN_MATL_DVCD = String.Empty;    //행위재료구분코드                 VARCHAR2(2)
        private string m_CLUS_DVCD = String.Empty;    //항구분코드                       VARCHAR2(2)
        private string m_SBIT_DVCD = String.Empty;    //목구분코드                       VARCHAR2(2)
        private string m_MEFE_DVCD = String.Empty;    //수가구분코드                     VARCHAR2(2)
        private string m_PAY_NOPY_DVCD = String.Empty;    //급여비급여구분코드               VARCHAR2(2)
        private string m_SCNG_PAY_CD = String.Empty;    //선별급여코드                     VARCHAR2(10)
        private string m_CNFR_DVCD = String.Empty;    //확인구분코드                     VARCHAR2(2)
        private string m_CNFR_CD = String.Empty;    //확인코드                         VARCHAR2(30)
        private string m_CMPT_CD = String.Empty;    //산정코드                         VARCHAR2(4)
        private string m_TIME_ADTN_DVCD = String.Empty;    //시간가산구분코드                 VARCHAR2(10)
        private string m_VTRN_PT_YN = String.Empty;    //보훈환자여부                     VARCHAR2(1)
        private int m_UNPR = 0;               //단가                             NUMBER(10, 0)
        private int m_ADTN_CMPT_AMT = 0;               //가산산정금액                     NUMBER(10, 0)
        private int m_BYKN_ADTN_AMT = 0;               //종별가산금액                     NUMBER(10, 0)
        private int m_SMCR_AMT = 0;               //선택진료금액                     NUMBER(10, 0)
        private int m_CLCL_AMT = 0;               //계산금액                         NUMBER(10, 0)
        private int m_ORIG_CLCL_AMT = 0;               //원계산금액                       NUMBER(10, 0)
        private int m_ADED_VALU_TAX_AMT = 0;               //부가가치세금액                   NUMBER(10, 0)
        private double m_PAY_USCH_AMT = 0;               //급여본인부담금액                 NUMBER(10, 0)
        private double m_PAY_CLAM_AMT = 0;               //급여청구금액                     NUMBER(10, 0)
        private double m_SCNG_PAY_USCH_AMT = 0;               //선별급여본인부담금액             NUMBER(10, 0)
        private double m_SCNG_PAY_CLAM_AMT = 0;               //선별급여청구금액                 NUMBER(10, 0)
        private int m_VTRN_TAMT = 0;               //보훈총금액                       NUMBER(10, 0)
        private int m_DCNT_AMT = 0;               //할인금액                         NUMBER(10, 0)
        private string m_ADTN_APLY_TIME = String.Empty;    //가산적용시간                     VARCHAR2(4)
        private string m_CMPT_DLWT_DVCD_1 = String.Empty;    //산정처리구분코드첫째             VARCHAR2(10)
        private string m_CMPT_DLWT_DVCD_2 = String.Empty;    //산정처리구분코드둘째             VARCHAR2(10)
        private string m_CMPT_DLWT_DVCD_3 = String.Empty;    //산정처리구분코드셋째             VARCHAR2(10)
        private string m_CMPT_DLWT_DVCD_4 = String.Empty;    //산정처리구분코드넷째             VARCHAR2(10)
        private double m_CNVR_PNT = 0;               //환산점수                         NUMBER(10, 2)
        private string m_GRP_UNPR_APLY_YN = String.Empty;    //그룹단가적용여부                 VARCHAR2(1)
        private string m_DNFR_RGUP_CNTS = String.Empty;    //치식우위내용                     VARCHAR2(8)
        private string m_DNFR_LFUP_CNTS = String.Empty;    //치식좌위내용                     VARCHAR2(8)
        private string m_DNFR_RGHT_LOW_CNTS = String.Empty;    //치식우하내용                     VARCHAR2(8)
        private string m_DNFR_LEFT_LOW_CNTS = String.Empty;    //치식좌하내용                     VARCHAR2(8)
        private string m_HPMD_CLCL_DVCD = String.Empty;    //고가약제계산구분코드             VARCHAR2(10)
        private double m_HPMD_CLCL_QTY = 0;               //고가약제계산수량                 NUMBER(10, 4)
        private string m_ENTS_ENTD_DVCD = String.Empty;    //위탁수탁구분코드                 VARCHAR2(2)
        private string m_ENTS_ENTD_INSTNO = String.Empty;    //위탁수탁기관기호                 VARCHAR2(10)
        private int m_SLCT_MCFE = 0;               //선택진료료                       NUMBER(10, 0)
        private double m_SMCR_RATE = 0;               //선택진료율                       NUMBER(7, 2)
        private string m_FXAM_INCL_YN = String.Empty;    //정액포함여부                     VARCHAR2(1)
        private double m_TOTL_AOMD_QTY = 0;               //총투여수량                       NUMBER(10, 4)
        private string m_ORMD_ANS_DVCD = String.Empty;    //한방가감구분코드                 VARCHAR2(2)
        private string m_ORMD_ANS_ORIG_DVCD = String.Empty;    //한방가감원구분코드               VARCHAR2(10)
        private string m_ORMD_ANS_ORIG_CD = String.Empty;    //한방가감원코드                   VARCHAR2(10)
        private string m_ORMD_SITE_DVCD = String.Empty;    //한방부위구분코드                 VARCHAR2(2)
        private string m_ORMD_SITE_CD = String.Empty;    //한방부위코드                     VARCHAR2(10)
        private int m_MDCN_UPLM_AMT = 0;               //약제상한금액                     NUMBER(10, 0)
        private int m_MDCN_UPLM_DIAM = 0;               //약제상한차액                     NUMBER(10, 0)
        private int m_ORIG_PRSC_SQNO = 0;               //원처방일련번호                   NUMBER(5, 0)
        private int m_ORIG_SQNO = 0;               //원일련번호                       NUMBER(3, 0)
        private string m_PCLR_MATR = String.Empty;    //특이사항                         VARCHAR2(200)
        private string m_AFRS_STAT_DVCD = String.Empty;    //업무상태구분코드                 VARCHAR2(2)
        private string m_ROW_STAT_DVCD = String.Empty;    //행상태구분코드                   VARCHAR2(2)
        private string m_RGST_DT = String.Empty;    //등록일시                         VARCHAR2(14)
        private string m_RGSTR_ID = String.Empty;    //등록자ID                         VARCHAR2(10)
        private int m_NEW_RCPT_RQNO = 0;               //새로운 수납일련번호
        private string m_NEW_ROW_STAT_DVCD = String.Empty;

        private int m_STATVAL1 = 1;             //행상태구분에 따른 값 ROW_STAT_DVCD = 'D' -> -1, ROW_STAT_DVCD = 'A' -> 1, ROW_STAT_DVCD = 'F' -> 0
        private int m_STATVAL2 = 1;             // 0, -1, 1
        private string m_CLUR_DSBL_DVCD = String.Empty;   // 장루요루구분코드 1 : YES, 0 : NO

        DataTable m_DtPrsc = new DataTable();

        public string PID { get { return m_PID; } set { m_PID = value; } }
        public int PT_CMHS_NO { get { return m_PT_CMHS_NO; } set { m_PT_CMHS_NO = value; } }
        public int RCPT_SQNO { get { return m_RCPT_SQNO; } set { m_RCPT_SQNO = value; } }
        public int APLY_SQNO { get { return m_APLY_SQNO; } set { m_APLY_SQNO = value; } }
        public int PRSC_SQNO { get { return m_PRSC_SQNO; } set { m_PRSC_SQNO = value; } }
        public string MDCR_DD { get { return m_MDCR_DD; } set { m_MDCR_DD = value; } }
        public string ACTG_DD { get { return m_ACTG_DD; } set { m_ACTG_DD = value; } }
        public string CLAM_CRTN_YN { get { return m_CLAM_CRTN_YN; } set { m_CLAM_CRTN_YN = value; } }
        public string REAL_PRDC_CD { get { return m_REAL_PRDC_CD; } set { m_REAL_PRDC_CD = value; } }
        public string PRSC_DVCD { get { return m_PRSC_DVCD; } set { m_PRSC_DVCD = value; } }
        public int BNDL_PRSC_SQNO { get { return m_BNDL_PRSC_SQNO; } set { m_BNDL_PRSC_SQNO = value; } }
        public string BNDL_MEFE_CD { get { return m_BNDL_MEFE_CD; } set { m_BNDL_MEFE_CD = value; } }
        public string MEFE_CD { get { return m_MEFE_CD; } set { m_MEFE_CD = value; } }
        public string MEFE_NM { get { return m_MEFE_NM; } set { m_MEFE_NM = value; } }
        public string EDI_CD { get { return m_EDI_CD; } set { m_EDI_CD = value; } }
        public string PRFT_CD { get { return m_PRFT_CD; } set { m_PRFT_CD = value; } }
        public double ONTM_QTY { get { return m_ONTM_QTY; } set { m_ONTM_QTY = value; } }
        public int NOTM { get { return m_NOTM; } set { m_NOTM = value; } }
        public int NODY { get { return m_NODY; } set { m_NODY = value; } }
        public string AOMD_MTHD_CD { get { return m_AOMD_MTHD_CD; } set { m_AOMD_MTHD_CD = value; } }
        public string OUPR_GRNT_NO { get { return m_OUPR_GRNT_NO; } set { m_OUPR_GRNT_NO = value; } }
        public string EXCP_RESN_CD { get { return m_EXCP_RESN_CD; } set { m_EXCP_RESN_CD = value; } }
        public string DLVR_DEPT_CD { get { return m_DLVR_DEPT_CD; } set { m_DLVR_DEPT_CD = value; } }
        public string ACTG_DEPT_CD { get { return m_ACTG_DEPT_CD; } set { m_ACTG_DEPT_CD = value; } }
        public string CLCL_DVCD { get { return m_CLCL_DVCD; } set { m_CLCL_DVCD = value; } }
        public string ACTN_MATL_DVCD { get { return m_ACTN_MATL_DVCD; } set { m_ACTN_MATL_DVCD = value; } }
        public string CLUS_DVCD { get { return m_CLUS_DVCD; } set { m_CLUS_DVCD = value; } }
        public string SBIT_DVCD { get { return m_SBIT_DVCD; } set { m_SBIT_DVCD = value; } }
        public string MEFE_DVCD { get { return m_MEFE_DVCD; } set { m_MEFE_DVCD = value; } }
        public string PAY_NOPY_DVCD { get { return m_PAY_NOPY_DVCD; } set { m_PAY_NOPY_DVCD = value; } }
        public string SCNG_PAY_CD { get { return m_SCNG_PAY_CD; } set { m_SCNG_PAY_CD = value; } }
        public string CNFR_DVCD { get { return m_CNFR_DVCD; } set { m_CNFR_DVCD = value; } }
        public string CNFR_CD { get { return m_CNFR_CD; } set { m_CNFR_CD = value; } }
        public string CMPT_CD { get { return m_CMPT_CD; } set { m_CMPT_CD = value; } }
        public string TIME_ADTN_DVCD { get { return m_TIME_ADTN_DVCD; } set { m_TIME_ADTN_DVCD = value; } }
        public string VTRN_PT_YN { get { return m_VTRN_PT_YN; } set { m_VTRN_PT_YN = value; } }
        public int UNPR { get { return m_UNPR; } set { m_UNPR = value; } }
        public int ADTN_CMPT_AMT { get { return m_ADTN_CMPT_AMT; } set { m_ADTN_CMPT_AMT = value; } }
        public int BYKN_ADTN_AMT { get { return m_BYKN_ADTN_AMT; } set { m_BYKN_ADTN_AMT = value; } }
        public int SMCR_AMT { get { return m_SMCR_AMT; } set { m_SMCR_AMT = value; } }
        public int CLCL_AMT { get { return m_CLCL_AMT; } set { m_CLCL_AMT = value; } }
        public int ORIG_CLCL_AMT { get { return m_ORIG_CLCL_AMT; } set { m_ORIG_CLCL_AMT = value; } }
        public int ADED_VALU_TAX_AMT { get { return m_ADED_VALU_TAX_AMT; } set { m_ADED_VALU_TAX_AMT = value; } }
        public double PAY_USCH_AMT { get { return m_PAY_USCH_AMT; } set { m_PAY_USCH_AMT = value; } }
        public double PAY_CLAM_AMT { get { return m_PAY_CLAM_AMT; } set { m_PAY_CLAM_AMT = value; } }
        public double SCNG_PAY_USCH_AMT { get { return m_SCNG_PAY_USCH_AMT; } set { m_SCNG_PAY_USCH_AMT = value; } }
        public double SCNG_PAY_CLAM_AMT { get { return m_SCNG_PAY_CLAM_AMT; } set { m_SCNG_PAY_CLAM_AMT = value; } }
        public int VTRN_TAMT { get { return m_VTRN_TAMT; } set { m_VTRN_TAMT = value; } }
        public int DCNT_AMT { get { return m_DCNT_AMT; } set { m_DCNT_AMT = value; } }
        public string ADTN_APLY_TIME { get { return m_ADTN_APLY_TIME; } set { m_ADTN_APLY_TIME = value; } }
        public string CMPT_DLWT_DVCD_1 { get { return m_CMPT_DLWT_DVCD_1; } set { m_CMPT_DLWT_DVCD_1 = value; } }
        public string CMPT_DLWT_DVCD_2 { get { return m_CMPT_DLWT_DVCD_2; } set { m_CMPT_DLWT_DVCD_2 = value; } }
        public string CMPT_DLWT_DVCD_3 { get { return m_CMPT_DLWT_DVCD_3; } set { m_CMPT_DLWT_DVCD_3 = value; } }
        public string CMPT_DLWT_DVCD_4 { get { return m_CMPT_DLWT_DVCD_4; } set { m_CMPT_DLWT_DVCD_4 = value; } }
        public double CNVR_PNT { get { return m_CNVR_PNT; } set { m_CNVR_PNT = value; } }
        public string GRP_UNPR_APLY_YN { get { return m_GRP_UNPR_APLY_YN; } set { m_GRP_UNPR_APLY_YN = value; } }
        public string DNFR_RGUP_CNTS { get { return m_DNFR_RGUP_CNTS; } set { m_DNFR_RGUP_CNTS = value; } }
        public string DNFR_LFUP_CNTS { get { return m_DNFR_LFUP_CNTS; } set { m_DNFR_LFUP_CNTS = value; } }
        public string DNFR_RGHT_LOW_CNTS { get { return m_DNFR_RGHT_LOW_CNTS; } set { m_DNFR_RGHT_LOW_CNTS = value; } }
        public string DNFR_LEFT_LOW_CNTS { get { return m_DNFR_LEFT_LOW_CNTS; } set { m_DNFR_LEFT_LOW_CNTS = value; } }
        public string HPMD_CLCL_DVCD { get { return m_HPMD_CLCL_DVCD; } set { m_HPMD_CLCL_DVCD = value; } }
        public double HPMD_CLCL_QTY { get { return m_HPMD_CLCL_QTY; } set { m_HPMD_CLCL_QTY = value; } }
        public string ENTS_ENTD_DVCD { get { return m_ENTS_ENTD_DVCD; } set { m_ENTS_ENTD_DVCD = value; } }
        public string ENTS_ENTD_INSTNO { get { return m_ENTS_ENTD_INSTNO; } set { m_ENTS_ENTD_INSTNO = value; } }
        public int SLCT_MCFE { get { return m_SLCT_MCFE; } set { m_SLCT_MCFE = value; } }
        public double SMCR_RATE { get { return m_SMCR_RATE; } set { m_SMCR_RATE = value; } }
        public string FXAM_INCL_YN { get { return m_FXAM_INCL_YN; } set { m_FXAM_INCL_YN = value; } }
        public double TOTL_AOMD_QTY { get { return m_TOTL_AOMD_QTY; } set { m_TOTL_AOMD_QTY = value; } }
        public string ORMD_ANS_DVCD { get { return m_ORMD_ANS_DVCD; } set { m_ORMD_ANS_DVCD = value; } }
        public string ORMD_ANS_ORIG_DVCD { get { return m_ORMD_ANS_ORIG_DVCD; } set { m_ORMD_ANS_ORIG_DVCD = value; } }
        public string ORMD_ANS_ORIG_CD { get { return m_ORMD_ANS_ORIG_CD; } set { m_ORMD_ANS_ORIG_CD = value; } }
        public string ORMD_SITE_DVCD { get { return m_ORMD_SITE_DVCD; } set { m_ORMD_SITE_DVCD = value; } }
        public string ORMD_SITE_CD { get { return m_ORMD_SITE_CD; } set { m_ORMD_SITE_CD = value; } }
        public int MDCN_UPLM_AMT { get { return m_MDCN_UPLM_AMT; } set { m_MDCN_UPLM_AMT = value; } }
        public int MDCN_UPLM_DIAM { get { return m_MDCN_UPLM_DIAM; } set { m_MDCN_UPLM_DIAM = value; } }
        public int ORIG_PRSC_SQNO { get { return m_ORIG_PRSC_SQNO; } set { m_ORIG_PRSC_SQNO = value; } }
        public int ORIG_SQNO { get { return m_ORIG_SQNO; } set { m_ORIG_SQNO = value; } }
        public string PCLR_MATR { get { return m_PCLR_MATR; } set { m_PCLR_MATR = value; } }
        public string AFRS_STAT_DVCD { get { return m_AFRS_STAT_DVCD; } set { m_AFRS_STAT_DVCD = value; } }
        public string ROW_STAT_DVCD { get { return m_ROW_STAT_DVCD; } set { m_ROW_STAT_DVCD = value; } }
        public string RGST_DT { get { return m_RGST_DT; } set { m_RGST_DT = value; } }
        public string RGSTR_ID { get { return m_RGSTR_ID; } set { m_RGSTR_ID = value; } }

        public int NEW_RCPT_RQNO { get { return m_NEW_RCPT_RQNO++; } set { m_NEW_RCPT_RQNO = value; } }
        public string NEW_ROW_STAT_DVCD { get { return m_NEW_ROW_STAT_DVCD; } set { m_NEW_ROW_STAT_DVCD = value; } }

        public int STATVAL1 { get { return m_STATVAL1; } set { m_STATVAL1 = value; } }
        public int STATVAL2 { get { return m_STATVAL2; } set { m_STATVAL2 = value; } }
        public string CLUR_DSBL_DVCD { get { return m_CLUR_DSBL_DVCD; } set { m_CLUR_DSBL_DVCD = value; } }

        public DataTable DtPrsc
        {
            get { return m_DtPrsc; }
            set { m_DtPrsc = value; }
        }
        #endregion

        #region Constructor

        public clsOutReceiptBreakDown()
        {
            Clear();
        }

        #endregion

        #region Method General

        public void Clear()
        {
            m_PID = String.Empty;
            m_PT_CMHS_NO = 0;
            m_RCPT_SQNO = 0;
            m_APLY_SQNO = 0;
            m_PRSC_SQNO = 0;
            m_MDCR_DD = String.Empty;
            m_ACTG_DD = String.Empty;
            m_CLAM_CRTN_YN = String.Empty;
            m_REAL_PRDC_CD = String.Empty;
            m_PRSC_DVCD = String.Empty;
            m_BNDL_PRSC_SQNO = 0;
            m_BNDL_MEFE_CD = String.Empty;
            m_MEFE_CD = String.Empty;
            m_MEFE_NM = String.Empty;
            m_EDI_CD = String.Empty;
            m_PRFT_CD = String.Empty;
            m_ONTM_QTY = 0;
            m_NOTM = 0;
            m_NODY = 0;
            m_AOMD_MTHD_CD = String.Empty;
            m_OUPR_GRNT_NO = String.Empty;
            m_EXCP_RESN_CD = String.Empty;
            m_DLVR_DEPT_CD = String.Empty;
            m_ACTG_DEPT_CD = String.Empty;
            m_CLCL_DVCD = String.Empty;
            m_ACTN_MATL_DVCD = String.Empty;
            m_CLUS_DVCD = String.Empty;
            m_SBIT_DVCD = String.Empty;
            m_MEFE_DVCD = String.Empty;
            m_PAY_NOPY_DVCD = String.Empty;
            m_SCNG_PAY_CD = String.Empty;
            m_CNFR_DVCD = String.Empty;
            m_CNFR_CD = String.Empty;
            m_CMPT_CD = String.Empty;
            m_TIME_ADTN_DVCD = String.Empty;
            m_VTRN_PT_YN = String.Empty;
            m_UNPR = 0;
            m_ADTN_CMPT_AMT = 0;
            m_BYKN_ADTN_AMT = 0;
            m_SMCR_AMT = 0;
            m_CLCL_AMT = 0;
            m_ORIG_CLCL_AMT = 0;
            m_ADED_VALU_TAX_AMT = 0;
            m_PAY_USCH_AMT = 0;
            m_PAY_CLAM_AMT = 0;
            m_SCNG_PAY_USCH_AMT = 0;
            m_SCNG_PAY_CLAM_AMT = 0;
            m_VTRN_TAMT = 0;
            m_DCNT_AMT = 0;
            m_ADTN_APLY_TIME = String.Empty;
            m_CMPT_DLWT_DVCD_1 = String.Empty;
            m_CMPT_DLWT_DVCD_2 = String.Empty;
            m_CMPT_DLWT_DVCD_3 = String.Empty;
            m_CMPT_DLWT_DVCD_4 = String.Empty;
            m_CNVR_PNT = 0;
            m_GRP_UNPR_APLY_YN = String.Empty;
            m_DNFR_RGUP_CNTS = String.Empty;
            m_DNFR_LFUP_CNTS = String.Empty;
            m_DNFR_RGHT_LOW_CNTS = String.Empty;
            m_DNFR_LEFT_LOW_CNTS = String.Empty;
            m_HPMD_CLCL_DVCD = String.Empty;
            m_HPMD_CLCL_QTY = 0;
            m_ENTS_ENTD_DVCD = String.Empty;
            m_ENTS_ENTD_INSTNO = String.Empty;
            m_SLCT_MCFE = 0;
            m_SMCR_RATE = 0;
            m_FXAM_INCL_YN = String.Empty;
            m_TOTL_AOMD_QTY = 0;
            m_ORMD_ANS_DVCD = String.Empty;
            m_ORMD_ANS_ORIG_DVCD = String.Empty;
            m_ORMD_ANS_ORIG_CD = String.Empty;
            m_ORMD_SITE_DVCD = String.Empty;
            m_ORMD_SITE_CD = String.Empty;
            m_MDCN_UPLM_AMT = 0;
            m_MDCN_UPLM_DIAM = 0;
            m_ORIG_PRSC_SQNO = 0;
            m_ORIG_SQNO = 0;
            m_PCLR_MATR = String.Empty;
            m_AFRS_STAT_DVCD = String.Empty;
            m_ROW_STAT_DVCD = String.Empty;
            m_RGST_DT = String.Empty;
            m_RGSTR_ID = String.Empty;
            m_NEW_RCPT_RQNO = 0;
            m_NEW_ROW_STAT_DVCD = String.Empty;

            m_STATVAL1 = 1;
            m_STATVAL2 = 1;

            m_CLUR_DSBL_DVCD = String.Empty;

            m_DtPrsc.Clear();
        }

        #endregion

        #region Method : Public Method

        /// <summary>
        /// 외래수납처방내역을 DataTable에 담아서 PaOrecBd Insert.
        /// </summary>
        /// <returns></returns>
        public bool SavePaOrecBd(ref string msg, string optionString = "")
        {
            try
            {
                DataTable dtPaOrecBd = new DataTable();

                // 입원취소에서 A행을 생성할 경우
                if (m_NEW_ROW_STAT_DVCD.Equals("A") && m_AFRS_STAT_DVCD.Equals("9"))
                {
                    DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAORECBD(true), ref dtPaOrecBd, m_PID
                                                                                          , m_PT_CMHS_NO.ToString()
                                                                                          , m_ROW_STAT_DVCD);
                }
                else
                {
                    DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAORECBD(false), ref dtPaOrecBd, m_PID
                                                                                          , m_PT_CMHS_NO.ToString()
                                                                                          , m_RCPT_SQNO.ToString()
                                                                                          , m_ROW_STAT_DVCD);
                }

                if (dtPaOrecBd.Rows.Count > 0)
                {
                    return InsertPaOrecBd(dtPaOrecBd, ref msg, optionString);
                }

                return false;
            }
            catch (Exception ex)
            {
                msg = "외래접수내역 취소 중 오류를 발생했습니다.\r\n " +
                      "Method :  [SavePaOrecBd] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }
            return true;
        }

        /// <summary>
        /// 외래수납처방내역을 DataTable에 담아서 PaOrecBd Insert.
        /// </summary>
        /// <returns></returns>
        public bool SavePaOrecBd_Uncl(ref string msg, string optionString = "")
        {
            try
            {
                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAORECBD(true), ref dt, m_PID, m_PT_CMHS_NO.ToString(), m_ROW_STAT_DVCD))
                    throw new Exception("이전 수납처방내역을 조회하는 중 에러가 발생했습니다.");

                if (dt.Rows.Count > 0)
                {
                    return InsertPaOrecBd(dt, ref msg, optionString);
                }

                return false;
            }
            catch (Exception ex)
            {
                msg = "외래접수내역 취소 중 오류를 발생했습니다.\r\n " +
                      "Method :  [SavePaOrecBd] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }
            return true;
        }

        /// <summary>
        /// 외래수납처방내역 Insert
        /// </summary>
        /// <param name="dtpaorecdb"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool InsertPaOrecBd(DataTable dtpaorecdb, ref string msg, string optionString = "")
        {
            try
            {
                int clurdsblcount = 0;
                string pid = String.Empty;
                string ptcmhsno = String.Empty;

                foreach (DataRow row in dtpaorecdb.Rows)
                {
                    if (optionString.Equals("D"))
                    {
                        #region 입원등록 D Insert

                        if (!DBService.ExecuteNonQuery(SQL.PA.BaseSql.Insert.PAORECBD(), row["PID"].ToString()
                                                                                       , row["PT_CMHS_NO"].ToString()
                                                                                       , m_NEW_RCPT_RQNO.ToString()
                                                                                       , row["APLY_SQNO"].ToString()
                                                                                       , row["PRSC_SQNO"].ToString()
                                                                                       , row["MDCR_DD"].ToString()
                                                                                       , row["ACTG_DD"].ToString()
                                                                                       , row["CLAM_CRTN_YN"].ToString()
                                                                                       , row["REAL_PRDC_CD"].ToString()
                                                                                       , row["PRSC_DVCD"].ToString()
                                                                                       , row["BNDL_PRSC_SQNO"].ToString()
                                                                                       , row["BNDL_MEFE_CD"].ToString()
                                                                                       , row["MEFE_CD"].ToString()
                                                                                       , row["MEFE_NM"].ToString()
                                                                                       , row["EDI_CD"].ToString()
                                                                                       , row["PRFT_CD"].ToString()
                                                                                       , row["ONTM_QTY"].ToString()
                                                                                       , row["NOTM"].ToString()
                                                                                       , (int.Parse(row["NODY"].ToString()) * -1).ToString()            // 일수는 -1곱함
                                                                                       , row["AOMD_MTHD_CD"].ToString()
                                                                                       , row["OUPR_GRNT_NO"].ToString()
                                                                                       , row["EXCP_RESN_CD"].ToString()
                                                                                       , row["DLVR_DEPT_CD"].ToString()
                                                                                       , row["ACTG_DEPT_CD"].ToString()
                                                                                       , row["CLCL_DVCD"].ToString()
                                                                                       , row["ACTN_MATL_DVCD"].ToString()
                                                                                       , row["CLUS_DVCD"].ToString()
                                                                                       , row["SBIT_DVCD"].ToString()
                                                                                       , row["MEFE_DVCD"].ToString()
                                                                                       , row["PAY_NOPY_DVCD"].ToString()
                                                                                       , row["SCNG_PAY_CD"].ToString()
                                                                                       , row["CNFR_DVCD"].ToString()
                                                                                       , row["CNFR_CD"].ToString()
                                                                                       , row["CMPT_CD"].ToString()
                                                                                       , row["TIME_ADTN_DVCD"].ToString()
                                                                                       , row["VTRN_PT_YN"].ToString()
                                                                                       , row["UNPR"].ToString()
                                                                                       , row["ADTN_CMPT_AMT"].ToString()
                                                                                       , row["BYKN_ADTN_AMT"].ToString()
                                                                                       , row["SMCR_AMT"].ToString()
                                                                                       , (int.Parse(row["CLCL_AMT"].ToString()) * -1).ToString()        // 계산금액도 -1곱함
                                                                                       , row["ORIG_CLCL_AMT"].ToString()
                                                                                       , row["ADED_VALU_TAX_AMT"].ToString()
                                                                                       , row["PAY_USCH_AMT"].ToString()
                                                                                       , row["PAY_CLAM_AMT"].ToString()
                                                                                       , row["SCNG_PAY_USCH_AMT"].ToString()
                                                                                       , row["SCNG_PAY_CLAM_AMT"].ToString()
                                                                                       , row["VTRN_TAMT"].ToString()
                                                                                       , row["DCNT_AMT"].ToString()
                                                                                       , row["ADTN_APLY_TIME"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_1"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_2"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_3"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_4"].ToString()
                                                                                       , row["CNVR_PNT"].ToString()
                                                                                       , row["GRP_UNPR_APLY_YN"].ToString()
                                                                                       , row["DNFR_RGUP_CNTS"].ToString()
                                                                                       , row["DNFR_LFUP_CNTS"].ToString()
                                                                                       , row["DNFR_RGHT_LOW_CNTS"].ToString()
                                                                                       , row["DNFR_LEFT_LOW_CNTS"].ToString()
                                                                                       , row["HPMD_CLCL_DVCD"].ToString()
                                                                                       , row["HPMD_CLCL_QTY"].ToString()
                                                                                       , row["ENTS_ENTD_DVCD"].ToString()
                                                                                       , row["ENTS_ENTD_INSTNO"].ToString()
                                                                                       , row["SLCT_MCFE"].ToString()
                                                                                       , row["SMCR_RATE"].ToString()
                                                                                       , row["FXAM_INCL_YN"].ToString()
                                                                                       , row["TOTL_AOMD_QTY"].ToString()
                                                                                       , row["ORMD_ANS_YN"].ToString()
                                                                                       , row["ORMD_ANS_CD"].ToString()
                                                                                       , row["ORMD_ANS_NM"].ToString()
                                                                                       , row["ORMD_SITE_DVCD"].ToString()
                                                                                       , row["ORMD_SITE_CD"].ToString()
                                                                                       , row["MDCN_UPLM_AMT"].ToString()
                                                                                       , row["MDCN_UPLM_DIAM"].ToString()
                                                                                       , row["ORIG_PRSC_SQNO"].ToString()
                                                                                       , row["ORIG_SQNO"].ToString()
                                                                                       , row["PCLR_MATR"].ToString()
                                                                                       , m_AFRS_STAT_DVCD
                                                                                       , m_NEW_ROW_STAT_DVCD
                                                                                       , m_RGST_DT
                                                                                       , m_RGSTR_ID))
                        {
                            msg = DBService.ErrorMessage + "\r\n 외래수납처방내역 발생중 오류발생[ ROW_STAT_DVCD = " + m_ROW_STAT_DVCD + " ]";
                            DBService.RollbackTransaction();
                            return false;
                        }
                        #endregion 입원등록 D Insert
                    }
                    else if (optionString.Equals("F"))
                    {
                        #region F Insert

                        if (!DBService.ExecuteNonQuery(SQL.PA.BaseSql.Insert.PAORECBD(), row["PID"].ToString()
                                                                                       , row["PT_CMHS_NO"].ToString()
                                                                                       , m_NEW_RCPT_RQNO.ToString()
                                                                                       , row["APLY_SQNO"].ToString()
                                                                                       , row["PRSC_SQNO"].ToString()
                                                                                       , row["MDCR_DD"].ToString()
                                                                                       , row["ACTG_DD"].ToString()
                                                                                       , row["CLAM_CRTN_YN"].ToString()
                                                                                       , row["REAL_PRDC_CD"].ToString()
                                                                                       , row["PRSC_DVCD"].ToString()
                                                                                       , row["BNDL_PRSC_SQNO"].ToString()
                                                                                       , row["BNDL_MEFE_CD"].ToString()
                                                                                       , row["MEFE_CD"].ToString()
                                                                                       , row["MEFE_NM"].ToString()
                                                                                       , row["EDI_CD"].ToString()
                                                                                       , row["PRFT_CD"].ToString()
                                                                                       , row["ONTM_QTY"].ToString()
                                                                                       , row["NOTM"].ToString()
                                                                                       , row["NODY"].ToString()
                                                                                       , row["AOMD_MTHD_CD"].ToString()
                                                                                       , row["OUPR_GRNT_NO"].ToString()
                                                                                       , row["EXCP_RESN_CD"].ToString()
                                                                                       , row["DLVR_DEPT_CD"].ToString()
                                                                                       , row["ACTG_DEPT_CD"].ToString()
                                                                                       , row["CLCL_DVCD"].ToString()
                                                                                       , row["ACTN_MATL_DVCD"].ToString()
                                                                                       , row["CLUS_DVCD"].ToString()
                                                                                       , row["SBIT_DVCD"].ToString()
                                                                                       , row["MEFE_DVCD"].ToString()
                                                                                       , row["PAY_NOPY_DVCD"].ToString()
                                                                                       , row["SCNG_PAY_CD"].ToString()
                                                                                       , row["CNFR_DVCD"].ToString()
                                                                                       , row["CNFR_CD"].ToString()
                                                                                       , row["CMPT_CD"].ToString()
                                                                                       , row["TIME_ADTN_DVCD"].ToString()
                                                                                       , row["VTRN_PT_YN"].ToString()
                                                                                       , row["UNPR"].ToString()
                                                                                       , row["ADTN_CMPT_AMT"].ToString()
                                                                                       , row["BYKN_ADTN_AMT"].ToString()
                                                                                       , row["SMCR_AMT"].ToString()
                                                                                       , "0"                                        // 계산금액 0 설정
                                                                                       , row["ORIG_CLCL_AMT"].ToString()
                                                                                       , row["ADED_VALU_TAX_AMT"].ToString()
                                                                                       , row["PAY_USCH_AMT"].ToString()
                                                                                       , row["PAY_CLAM_AMT"].ToString()
                                                                                       , row["SCNG_PAY_USCH_AMT"].ToString()
                                                                                       , row["SCNG_PAY_CLAM_AMT"].ToString()
                                                                                       , row["VTRN_TAMT"].ToString()
                                                                                       , row["DCNT_AMT"].ToString()
                                                                                       , row["ADTN_APLY_TIME"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_1"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_2"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_3"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_4"].ToString()
                                                                                       , row["CNVR_PNT"].ToString()
                                                                                       , row["GRP_UNPR_APLY_YN"].ToString()
                                                                                       , row["DNFR_RGUP_CNTS"].ToString()
                                                                                       , row["DNFR_LFUP_CNTS"].ToString()
                                                                                       , row["DNFR_RGHT_LOW_CNTS"].ToString()
                                                                                       , row["DNFR_LEFT_LOW_CNTS"].ToString()
                                                                                       , row["HPMD_CLCL_DVCD"].ToString()
                                                                                       , row["HPMD_CLCL_QTY"].ToString()
                                                                                       , row["ENTS_ENTD_DVCD"].ToString()
                                                                                       , row["ENTS_ENTD_INSTNO"].ToString()
                                                                                       , row["SLCT_MCFE"].ToString()
                                                                                       , row["SMCR_RATE"].ToString()
                                                                                       , row["FXAM_INCL_YN"].ToString()
                                                                                       , row["TOTL_AOMD_QTY"].ToString()
                                                                                       , row["ORMD_ANS_YN"].ToString()
                                                                                       , row["ORMD_ANS_CD"].ToString()
                                                                                       , row["ORMD_ANS_NM"].ToString()
                                                                                       , row["ORMD_SITE_DVCD"].ToString()
                                                                                       , row["ORMD_SITE_CD"].ToString()
                                                                                       , row["MDCN_UPLM_AMT"].ToString()
                                                                                       , row["MDCN_UPLM_DIAM"].ToString()
                                                                                       , row["ORIG_PRSC_SQNO"].ToString()
                                                                                       , row["ORIG_SQNO"].ToString()
                                                                                       , row["PCLR_MATR"].ToString()
                                                                                       , m_AFRS_STAT_DVCD
                                                                                       , m_NEW_ROW_STAT_DVCD
                                                                                       , m_RGST_DT
                                                                                       , m_RGSTR_ID))
                        {
                            msg = DBService.ErrorMessage + "\r\n 외래수납처방내역 발생중 오류발생[ ROW_STAT_DVCD = " + m_ROW_STAT_DVCD + " ]";
                            DBService.RollbackTransaction();
                            return false;
                        }
                        #endregion F Insert
                    }
                    else
                    {
                        #region Default Insert

                        if (!DBService.ExecuteNonQuery(SQL.PA.BaseSql.Insert.PAORECBD(), row["PID"].ToString()
                                                                                       , row["PT_CMHS_NO"].ToString()
                                                                                       , m_NEW_RCPT_RQNO.ToString()
                                                                                       , row["APLY_SQNO"].ToString()
                                                                                       , row["PRSC_SQNO"].ToString()
                                                                                       , row["MDCR_DD"].ToString()
                                                                                       , row["ACTG_DD"].ToString()
                                                                                       , row["CLAM_CRTN_YN"].ToString()
                                                                                       , row["REAL_PRDC_CD"].ToString()
                                                                                       , row["PRSC_DVCD"].ToString()
                                                                                       , row["BNDL_PRSC_SQNO"].ToString()
                                                                                       , row["BNDL_MEFE_CD"].ToString()
                                                                                       , row["MEFE_CD"].ToString()
                                                                                       , row["MEFE_NM"].ToString()
                                                                                       , row["EDI_CD"].ToString()
                                                                                       , row["PRFT_CD"].ToString()
                                                                                       , row["ONTM_QTY"].ToString()
                                                                                       , row["NOTM"].ToString()
                                                                                       , row["NODY"].ToString()
                                                                                       , row["AOMD_MTHD_CD"].ToString()
                                                                                       , row["OUPR_GRNT_NO"].ToString()
                                                                                       , row["EXCP_RESN_CD"].ToString()
                                                                                       , row["DLVR_DEPT_CD"].ToString()
                                                                                       , row["ACTG_DEPT_CD"].ToString()
                                                                                       , row["CLCL_DVCD"].ToString()
                                                                                       , row["ACTN_MATL_DVCD"].ToString()
                                                                                       , row["CLUS_DVCD"].ToString()
                                                                                       , row["SBIT_DVCD"].ToString()
                                                                                       , row["MEFE_DVCD"].ToString()
                                                                                       , row["PAY_NOPY_DVCD"].ToString()
                                                                                       , row["SCNG_PAY_CD"].ToString()
                                                                                       , row["CNFR_DVCD"].ToString()
                                                                                       , row["CNFR_CD"].ToString()
                                                                                       , row["CMPT_CD"].ToString()
                                                                                       , row["TIME_ADTN_DVCD"].ToString()
                                                                                       , row["VTRN_PT_YN"].ToString()
                                                                                       , row["UNPR"].ToString()
                                                                                       , row["ADTN_CMPT_AMT"].ToString()
                                                                                       , row["BYKN_ADTN_AMT"].ToString()
                                                                                       , row["SMCR_AMT"].ToString()
                                                                                       , row["CLCL_AMT"].ToString()
                                                                                       , row["ORIG_CLCL_AMT"].ToString()
                                                                                       , row["ADED_VALU_TAX_AMT"].ToString()
                                                                                       , row["PAY_USCH_AMT"].ToString()
                                                                                       , row["PAY_CLAM_AMT"].ToString()
                                                                                       , row["SCNG_PAY_USCH_AMT"].ToString()
                                                                                       , row["SCNG_PAY_CLAM_AMT"].ToString()
                                                                                       , row["VTRN_TAMT"].ToString()
                                                                                       , row["DCNT_AMT"].ToString()
                                                                                       , row["ADTN_APLY_TIME"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_1"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_2"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_3"].ToString()
                                                                                       , row["CMPT_DLWT_DVCD_4"].ToString()
                                                                                       , row["CNVR_PNT"].ToString()
                                                                                       , row["GRP_UNPR_APLY_YN"].ToString()
                                                                                       , row["DNFR_RGUP_CNTS"].ToString()
                                                                                       , row["DNFR_LFUP_CNTS"].ToString()
                                                                                       , row["DNFR_RGHT_LOW_CNTS"].ToString()
                                                                                       , row["DNFR_LEFT_LOW_CNTS"].ToString()
                                                                                       , row["HPMD_CLCL_DVCD"].ToString()
                                                                                       , row["HPMD_CLCL_QTY"].ToString()
                                                                                       , row["ENTS_ENTD_DVCD"].ToString()
                                                                                       , row["ENTS_ENTD_INSTNO"].ToString()
                                                                                       , row["SLCT_MCFE"].ToString()
                                                                                       , row["SMCR_RATE"].ToString()
                                                                                       , row["FXAM_INCL_YN"].ToString()
                                                                                       , row["TOTL_AOMD_QTY"].ToString()
                                                                                       , row["ORMD_ANS_YN"].ToString()
                                                                                       , row["ORMD_ANS_CD"].ToString()
                                                                                       , row["ORMD_ANS_NM"].ToString()
                                                                                       , row["ORMD_SITE_DVCD"].ToString()
                                                                                       , row["ORMD_SITE_CD"].ToString()
                                                                                       , row["MDCN_UPLM_AMT"].ToString()
                                                                                       , row["MDCN_UPLM_DIAM"].ToString()
                                                                                       , row["ORIG_PRSC_SQNO"].ToString()
                                                                                       , row["ORIG_SQNO"].ToString()
                                                                                       , row["PCLR_MATR"].ToString()
                                                                                       , m_AFRS_STAT_DVCD
                                                                                       , m_NEW_ROW_STAT_DVCD
                                                                                       , m_RGST_DT
                                                                                       , m_RGSTR_ID))
                        {
                            msg = DBService.ErrorMessage + "\r\n 외래수납처방내역 발생중 오류발생[ ROW_STAT_DVCD = " + m_ROW_STAT_DVCD + " ]";
                            DBService.RollbackTransaction();
                            return false;
                        }
                        #endregion Default Insert
                    }

                    if (row["CLUS_DVCD"].ToString().Equals("T") && row["SBIT_DVCD"].ToString().Equals("01"))
                    {
                        clurdsblcount++;
                        pid = row["PID"].ToString();
                        ptcmhsno = row["PT_CMHS_NO"].ToString();
                    }

                }
                //this.Clear();
                //장루요루구분코드 변경
                if (clurdsblcount > 0)
                {
                    m_CLUR_DSBL_DVCD = "1";
                }
                else
                {
                    m_CLUR_DSBL_DVCD = "0";
                }

                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateClurDsblDvcdOfPAOPATRT(), pid
                                                                                        , ptcmhsno
                                                                                        , m_CLUR_DSBL_DVCD))
                {
                    msg = "외래접수정보 장루요루구분코드 변경중 오류발생 \r\n Error Message : " + DBService.ErrorMessage;
                    DBService.RollbackTransaction();
                    return false;
                }
            }
            catch (Exception ex)
            {
                msg = "외래수납내역 취소 중 오류를 발생했습니다.\r\n " +
                      "Method :  [InsertPaOrecBd] \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }
            return true;
        }

        /// <summary>
        /// 외래수납처방내역의 행상태구분코드 UPDATE
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool UpdateRowStatDvcdOfPaOrecBd(ref string msg)
        {
            bool success = true;

            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePAORECBD_RowStatDvcd(), this.PID
                                                                                  , this.PT_CMHS_NO.ToString()
                                                                                  , this.ROW_STAT_DVCD
                                                                                  , this.NEW_ROW_STAT_DVCD))
            {
                success = false;
                msg = DBService.ErrorMessage + "\r\n 외래수납처방내역의 행상태구분코드 변경중 오류가 발생하였습니다. 확인하시기 바랍니다.";
                DBService.RollbackTransaction();
            }
            return success;
        }

        public bool GetORORDRRT(string pid, int ptcmhsno)
        {
            bool result = true;
            try
            {
                result = DBService.ExecuteDataTable(SQL.PA.Sql.SelectORORDRRT_Receipt(true), ref this.m_DtPrsc, pid, ptcmhsno.ToString());
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                result = false;
            }
            return result;
        }

        #endregion Method : Public Method
    }
}
