using System;
using System.ComponentModel;


namespace Lime.Framework.Controls
{
    [ToolboxItem(true)]
    public partial class LxDoctorListCombo : LxComboBox, ISupportInitialize
    {
        #region Define : Variable

        private COMBO_ADD_ITEM_TYPE m_ComboAddItemType = COMBO_ADD_ITEM_TYPE.None;
        private string m_DefaultSelectValue = "";
        private string m_DeptCD = "";
        private bool m_DisplayDept = false;

        #endregion

        #region Property : Member Property

        [Browsable(true)]
        [Category("Lime Custom"), Description("ComboBox의 Items에 [전체] 또는 [없음] 추가여부")]
        public COMBO_ADD_ITEM_TYPE ComboAddItemType
        {
            get
            {
                return m_ComboAddItemType;
            }
            set
            {
                m_ComboAddItemType = value;
            }
        }

        [Browsable(true)]
        [Category("Lime Custom"), Description("ComboBox에서 처음 선택되어질 데이터")]
        public string DefaultSelectValue
        {
            get
            {
                return m_DefaultSelectValue;
            }
            set
            {
                m_DefaultSelectValue = value;

                if (StringService.IsNotNull(m_DefaultSelectValue) && this.Items.Count > 0)
                {
                    this.SelectValue(m_DefaultSelectValue);
                }
            }
        }

        [Browsable(true)]
        [Category("Lime Custom"), Description("리스트를 조회 할 진료과 코드")]
        public string DeptCD
        {
            get
            {
                return m_DeptCD;
            }
            set
            {
                m_DeptCD = value;

                //if (this.Items.Count > 0)
                Initialize();
            }
        }

        /// <summary>
        /// 부서명을 함께 표시 할 지 여부
        /// </summary>
        [Browsable(true)]
        [Category("Lime Custom"), Description("부서명을 함께 표시 할 지 여부")]
        public bool DisplayDept
        {
            get
            {
                return m_DisplayDept;
            }
            set
            {
                m_DisplayDept = value;

                //if (this.Items.Count > 0)
                Initialize();
            }
        }

        #endregion

        #region Construction

        public LxDoctorListCombo()
        {
        }

        #endregion 

        #region Method : Initialize Method

        public void Initialize()
        {
            this.Clear();

            if (this.DesignMode)
                return;

            try
            {
                this.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;

                if (StringService.IsNull(m_DeptCD))
                    this.SetComboItems(DoctorList.ListTable, "USER_CD", (m_DisplayDept ? "USER_NM_DEPT" : "USER_NM"), m_ComboAddItemType, m_DefaultSelectValue);
                else
                    this.SetComboItems(DoctorList.GetDataList(m_DeptCD), "USER_CD", (m_DisplayDept ? "USER_NM_DEPT" : "USER_NM"), m_ComboAddItemType, m_DefaultSelectValue);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        #endregion

        #region Event : Override Events

        protected override void OnEndInit()
        {
            base.OnEndInit();

            if (!this.DesignMode)
                Initialize();
        }

        #endregion
    }
}
