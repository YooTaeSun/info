package web.townsi.com.work.setting.biz;

import java.util.HashMap;

public interface SettingToBiz {
	public abstract HashMap<String, Object> makeTo(HashMap paramHashMap) throws Exception;
}