using System;
using System.Management;
using System.Net;

namespace Lime.Framework
{
    public class NetworkService
    {
        private static string m_IP = "";

        /// <summary>
		/// Get System IP
		/// </summary>
		public static string IP
        {
            get
            {
                if (m_IP != "")
                    return m_IP;

                try
                {
                    string hostname = Dns.GetHostName();

                    IPAddress[] iplist = Dns.GetHostEntry(hostname).AddressList;

                    if (iplist.Length > 0)
                    {
                        for (int i = 0; i < iplist.Length; i++)
                        {
                            if (iplist[i].AddressFamily.Equals(System.Net.Sockets.AddressFamily.InterNetwork))
                            {
                                if (StringService.IsNull(m_IP))
                                {
                                    m_IP = iplist[i].ToString();
                                }
                                else
                                {
                                    //사설IP나 유동IP 보다 공인IP나 고정IP를 우선한다.
                                    if (iplist[i].ToString().IndexOf("192.", 0) != 0 && iplist[i].ToString().IndexOf("10.", 0) != 0 && iplist[i].ToString().IndexOf("172.", 0) != 0)
                                    {
                                        m_IP = iplist[i].ToString();
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    LogService.ErrorLog(ex);
                }

                m_IP = StringService.IsNull(m_IP) ? "127.0.0.1" : m_IP;

                return m_IP;
            }
        }

        /// <summary>
        /// Get MacAddress
        /// </summary>
        /// <returns></returns>
        public static string GetMacAddress()
        {
            ManagementClass mc = new ManagementClass("Win32_NetworkAdapterConfiguration");
            ManagementObjectCollection moc = mc.GetInstances();

            string mac = string.Empty;

            foreach (ManagementObject mo in moc)
            {
                // only return MAC Address from first card
                if (mac == string.Empty)
                {
                    if ((bool)mo["IPEnabled"] == true)
                        mac = mo["MacAddress"].ToString();
                }

                mo.Dispose();
            }

            return mac.Replace(":", "");
        }

        private static bool m_CheckNetworkEnable = true;
        public static bool CheckNetworkEnable { get { return m_CheckNetworkEnable; } set { m_CheckNetworkEnable = value; } }

        private static bool m_IsNetworkAvailable = true;
        public static bool IsNetworkAvailable { get { return m_IsNetworkAvailable; } set { m_IsNetworkAvailable = value; } }

        public static bool CheckNetworkAvailable()
        {
            if (!m_CheckNetworkEnable)
            {
                m_IsNetworkAvailable = true;
                return true;
            }

            if (System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable())
            {
                m_IsNetworkAvailable = true;
                return true;
            }

            m_IsNetworkAvailable = false;
            LogService.ErrorLog("Network not available.");
            return false;
        }
    }
}
