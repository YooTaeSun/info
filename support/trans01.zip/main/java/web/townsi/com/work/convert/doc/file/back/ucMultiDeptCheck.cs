using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Lime.Framework;
using SQL = Lime.SqlPack;

namespace Lime.BusinessControls
{
    public partial class ucMultiDeptCheck : UserControl
    {
        #region Delegate & Raise Events

        public delegate void OnValueChange();
        public event OnValueChange ValueChange;

        #endregion

        public ucMultiDeptCheck()
        {
            InitializeComponent();

            this.MaximumSize = new Size(0, this.cboMultiDeptCheck.Height + 3);

            this.InitializeEvents();
        }

        #region Events

        void cboMultiDeptCheck_AfterCloseUp(object sender, EventArgs e)
        {
            try
            {
                if (this.ValueChange != null)
                    this.ValueChange();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        #endregion

        #region Public Methods

        public void SetMultiDeptCheck(string pKey, string pFileName)
        {
            try
            {
                this.SetMultiDept();

                if (string.IsNullOrEmpty(pFileName)) return;

                string sDept = IniService.IniReadValue("SELECT_DEPT", pKey, ClientEnvironment.ConfigFolder + @"\" + pFileName);

                if (!string.IsNullOrEmpty(sDept))
                {
                    string[] aryDept = sDept.Split(new char[] { '/' });

                    foreach (string s in aryDept)
                    {
                        for (int ii = 0; ii < cboMultiDeptCheck.Items.Count; ii++)
                        {
                            if (s == cboMultiDeptCheck.Items[ii].DataValue.ToString())
                                cboMultiDeptCheck.Items[ii].CheckState = CheckState.Checked;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void SaveIni(string pKey, string pFileName)
        {
            try
            {
                string sItem = GetCheckedItems();

                //if (!string.IsNullOrEmpty(sItem))
                //{
                IniService.IniWriteValue("SELECT_DEPT", pKey, sItem, ClientEnvironment.ConfigFolder + @"\" + pFileName);
                //}
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public string GetCheckedItemsInWhere()
        {
            try
            {
                string sInItems = string.Empty;
                string sItems = GetCheckedItems();

                if (!string.IsNullOrEmpty(sItems))
                {
                    string[] aryItems = sItems.Split(new char[] { '/' });

                    foreach (string s in aryItems)
                    {
                        if (string.IsNullOrEmpty(sInItems))
                            sInItems = "'" + s + "'";
                        else
                            sInItems += ", '" + s + "'";
                    }
                }

                return sInItems;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public string GetCheckedItems()
        {
            try
            {
                string sItem = string.Empty;

                Infragistics.Win.CheckedValueListItemsCollection checkedItems = cboMultiDeptCheck.CheckedItems;

                foreach (Infragistics.Win.ValueListItem item in checkedItems)
                {
                    if (string.IsNullOrEmpty(sItem))
                        sItem = item.DataValue.ToString();
                    else
                        sItem += "/" + item.DataValue.ToString();
                }

                return sItem;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        #endregion

        #region Private Methods

        private void InitializeEvents()
        {
            try
            {
                this.cboMultiDeptCheck.AfterCloseUp += cboMultiDeptCheck_AfterCloseUp;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// 조회하고싶은 부서 멀티 체크
        /// </summary>
        private void SetMultiDept()
        {
            DataTable dt = new DataTable();

            if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectBIDEPTMA_CLSF_CD(true)
                                           , ref dt
                                           , "1", DateTimeService.TodayDateNoneSeperatorString(), "Y"))
                throw new Exception("SQL.PA.Sql.SelectBIDEPTMA_CLSF_CD - " + DBService.ErrorMessage + "[" + DBService.ErrorCode + "]");

            foreach (DataRow dr in dt.Rows)
                cboMultiDeptCheck.Items.Add(dr["DEPT_CD"].ToString(), dr["DEPT_HNM"].ToString());
        }

        #endregion
    }
}
