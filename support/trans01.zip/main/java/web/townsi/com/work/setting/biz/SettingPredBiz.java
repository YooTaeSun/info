package web.townsi.com.work.setting.biz;

import java.util.HashMap;
import java.util.List;

public interface SettingPredBiz {
	public abstract HashMap<String, Object> makePred(HashMap paramHashMap) throws Exception;
}