using System;
using System.Data;

using SQL = Lime.Framework.DataListService.Sql;

namespace Lime.Framework
{
    #region Define : Enum

    /// <summary>
    /// 부서종류구분코드
    /// </summary>
    public enum DEPT_CLSF_TYPE
    {
        All = 0,
        Clinic = 1,
        Ward = 2,
        Support = 3,
        ServiceDept = 4
    }

    public enum DEPT_NAME_TYPE
    {
        Korean,
        English,
        NickNmae
    }

    #endregion

    /// <summary>
    /// Dept List Class
    /// </summary>
    public class DeptList
    {
        #region Define : Member

        private static DataTable m_dtList = new DataTable();
        private static bool m_Initialized = false;

        #endregion

        #region Property : Member Property

        public static DataTable ListTable
        {
            get
            {
                if (!m_Initialized)
                    SelectList();

                return m_dtList.Copy();
            }

            set
            {
                m_dtList = value;
            }
        }

        #endregion

        #region Method : Initialize Method

        public static void Clear()
        {
            m_dtList.Clear();

            m_Initialized = false;
        }

        #endregion

        #region Method : Get Data Method

        /// <summary>
        /// 진료과명 조회(한글/영어/약어)
        /// </summary>
        /// <param name="code"></param>
        /// <param name="nametype"></param>
        /// <returns>string</returns>
        public static string GetName(string code, DEPT_NAME_TYPE nametype = DEPT_NAME_TYPE.Korean)
        {
            if (!m_Initialized)
                SelectList();

            foreach (DataRow row in m_dtList.Select("DEPT_CD = '" + code + "'"))
            {
                switch (nametype)
                {
                    case DEPT_NAME_TYPE.Korean:
                        return row["DEPT_HNM"].ToString().Trim();
                    case DEPT_NAME_TYPE.English:
                        return row["DEPT_ENM"].ToString().Trim();
                    case DEPT_NAME_TYPE.NickNmae:
                        return row["CLAM_CNFR_CD"].ToString().Trim();
                }
            }

            return "";
        }

        /// <summary>
        /// 진료과코드 조회(한글/영문/약어)
        /// </summary>
        /// <param name="name"></param>
        /// <returns>string</returns>
        public static string GetCode(string name)
        {
            if (!m_Initialized)
                SelectList();

            string wheretext = @"DEPT_HNM  = '{0}' OR DEPT_ENM = '{0}' OR CLAM_CNFR_CD = '{0}'";
            wheretext = string.Format(wheretext, name);

            foreach (DataRow row in m_dtList.Select(wheretext))
            {
                return row["DEPT_CD"].ToString().Trim();
            }

            return "";
        }

        /// <summary>
        /// 진료과 정보중 지정한 컬럼의 정보 조회
        /// </summary>
        /// <param name="code"></param>
        /// <param name="columnname"></param>
        /// <returns>object</returns>
        public static object GetColumnValue(string code, string columnname)
        {
            if (!m_Initialized)
                SelectList();

            foreach (DataRow row in m_dtList.Select("DEPT_CD = '" + code + "'"))
            {
                return row[columnname];
            }

            return "";
        }

        #endregion

        #region Method : Get Data List

        /// <summary>
        /// 진료과 조회
        /// </summary>
        /// <param name="additemtype"></param>
        /// <returns>string</returns>
        public static DataTable GetDataList(COMBO_ADD_ITEM_TYPE additemtype = COMBO_ADD_ITEM_TYPE.None)
        {
            if (!m_Initialized)
                SelectList();

            DataTable dt = m_dtList.Copy();

            if (!additemtype.Equals(COMBO_ADD_ITEM_TYPE.None))
                dt = AddComboItem(dt, additemtype);

            return dt;
        }

        /// <summary>
        /// 진료과 타입별 조회
        /// </summary>
        /// <param name="CLSF_CD"></param>
        /// <param name="additemtype"></param>
        /// <returns>string</returns>
        public static DataTable GetDataList(DEPT_CLSF_TYPE CLSF_CD, COMBO_ADD_ITEM_TYPE additemtype = COMBO_ADD_ITEM_TYPE.None)
        {
            if (!m_Initialized)
                SelectList();

            DataTable dt = new DataTable();

            try
            {
                if (m_dtList.Rows.Count > 0)
                {
                    if (CLSF_CD.Equals(DEPT_CLSF_TYPE.All))
                    {
                        dt = m_dtList.Copy();
                    }
                    else
                    {
                        dt = m_dtList.Clone();

                        //해당 부서코드만 조회하여 리스트를 만든다.
                        foreach (DataRow row in m_dtList.Select("DEPT_CLSF_CD = '" + ((int)CLSF_CD).ToString() + "'"))
                        {
                            dt.ImportRow(row);
                        }
                    }

                    if (!additemtype.Equals(COMBO_ADD_ITEM_TYPE.None))
                        dt = AddComboItem(dt, additemtype);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return dt;
        }

        private static DataTable AddComboItem(DataTable dt, COMBO_ADD_ITEM_TYPE additemtype = COMBO_ADD_ITEM_TYPE.None)
        {
            try
            {
                //전체/없음 추가.
                if (!additemtype.Equals(COMBO_ADD_ITEM_TYPE.None))
                {
                    DataRow newrow = dt.NewRow();
                    newrow["DEPT_CD"] = (additemtype.Equals(COMBO_ADD_ITEM_TYPE.AddAll) ? DataType.COMBO_ADD_ITEM_TYPE_CODE_ALL : DataType.COMBO_ADD_ITEM_TYPE_CODE_NONE);
                    newrow["DEPT_HNM"] = (additemtype.Equals(COMBO_ADD_ITEM_TYPE.AddAll) ? DataType.COMBO_ADD_ITEM_TYPE_STRING_ALL : DataType.COMBO_ADD_ITEM_TYPE_STRING_NONE);
                    newrow["DEPT_ENM"] = (additemtype.Equals(COMBO_ADD_ITEM_TYPE.AddAll) ? DataType.COMBO_ADD_ITEM_TYPE_STRING_ALL : DataType.COMBO_ADD_ITEM_TYPE_STRING_NONE);
                    dt.Rows.InsertAt(newrow, 0);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return dt;
        }

        #endregion

        #region Method : Load Data Method

        /// <summary>
        /// Load list
        /// </summary>
        /// <returns></returns>
        public static DataTable LoadList()
        {
            SelectList();

            return m_dtList;
        }

        /// <summary>
        /// Select list
        /// </summary>
        private static void SelectList()
        {
            if (ClientEnvironment.DesignMode)
                return;

            try
            {
                m_dtList = new DataTable();

                //진료과 목록 조회
                DBService.ExecuteDataTable(SQL.SelectBIDEPTMA(), ref m_dtList);

                m_Initialized = true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        #endregion
    }
}
