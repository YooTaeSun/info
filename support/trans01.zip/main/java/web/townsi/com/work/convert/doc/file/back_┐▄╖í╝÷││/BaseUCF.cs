//********************************************************************************
// Class 명 : BaseUCF
// 역    할 : 각 업무화면을 작성하기 위한 Base Screen(UserControl)
// 작 성 자 : LDJ
// 작 성 일 : 2017-07-17
//********************************************************************************
// 수정내역 : 
//********************************************************************************
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Infragistics.Win.UltraWinToolbars;

namespace Lime.Framework
{
    [ToolboxItem(false)]
    public partial class BaseUCF : UserControl, ISupportInitialize, IMessageFilter, IBaseScreen
    {
        #region Define : Event

        /// <summary>
        /// 화면의 Load가 끝난 후 에 발생합니다.
        /// </summary>
        [Browsable(true), Category("Lime Custom"), Description("화면의 Load가 끝난 후 에 발생합니다.")]
        public event EventHandler Loaded;

        /// <summary>
        /// Timer Event Second
        /// </summary>
        [Browsable(true), Category("Lime Custom Timer"), Description("1초 간격으로 발생합니다.")]
        public event EventHandler TimeEventSecond;
        [Browsable(true), Category("Lime Custom Timer"), Description("5초 간격으로 발생합니다.")]
        public event EventHandler TimeEvent5Second;
        [Browsable(true), Category("Lime Custom Timer"), Description("10초 간격으로 발생합니다.")]
        public event EventHandler TimeEvent10Second;
        [Browsable(true), Category("Lime Custom Timer"), Description("15초 간격으로 발생합니다.")]
        public event EventHandler TimeEvent15Second;
        [Browsable(true), Category("Lime Custom Timer"), Description("30초 간격으로 발생합니다.")]
        public event EventHandler TimeEvent30Second;
        [Browsable(true), Category("Lime Custom Timer"), Description("1분 간격으로 발생합니다.")]
        public event EventHandler TimeEventMinute;
        [Browsable(true), Category("Lime Custom Timer"), Description("5분 간격으로 발생합니다.")]
        public event EventHandler TimeEvent5Minute;
        [Browsable(true), Category("Lime Custom Timer"), Description("10분 간격으로 발생합니다.")]
        public event EventHandler TimeEvent10Minute;
        [Browsable(true), Category("Lime Custom Timer"), Description("15분 간격으로 발생합니다.")]
        public event EventHandler TimeEvent15Minute;
        [Browsable(true), Category("Lime Custom Timer"), Description("30분 간격으로 발생합니다.")]
        public event EventHandler TimeEvent30Minute;
        [Browsable(true), Category("Lime Custom Timer"), Description("1시간 간격으로 발생합니다.")]
        public event EventHandler TimeEventHour;
        [Browsable(true), Category("Lime Custom Timer"), Description("사용자가 지정한 간격으로 발생합니다.")]
        public event EventHandler TimeEventCustomInterval;

        [Browsable(true), Category("Lime Custom"), Description("Context Menu가 Open 될 때 발생합니다.")]
        public event ContextMenuOpenEventHandler ContextMenuOpen;

        [Browsable(true), Category("Lime Custom"), Description("Context Menu가 Close 될 때 발생합니다.")]
        public event ContextMenuCloseEventHandler ContextMenuClose;

        [Browsable(true), Category("Lime Custom"), Description("Context Menu가 Click 되었을 때 발생합니다.")]
        public event ContextMenuClickEventHandler ContextMenuClick;

        [Browsable(true), Category("Lime Custom"), Description("Screen Parameter가 변경되었을 때 발생합니다.")]
        public event EventHandler ParameterChanged;


        [Browsable(true), Category("Lime Custom"), Description("Screen이 종료 될 때 발생합니다.")]
        public event CancelEventHandler ScreenClosing;
        [Browsable(true), Category("Lime Custom"), Description("Screen이 종료 된 후에 발생합니다.")]
        public event EventHandler ScreenClosed;

        #endregion

        #region Define : Member

        private BaseMDI m_BaseMDI = null;

        private string m_ScreenKey = "";

        private string m_Caption = "";
        private Icon m_Icon = Properties.Resources.Limeicon;

        private DOPatientInfo m_PatientInfo = new DOPatientInfo();
        private ScreenParameters m_Parameters = new ScreenParameters();
        private UltraToolbarsManager m_ContextMenuToolBar = new UltraToolbarsManager();
        private Control m_FirstFocusControl = null;

        private Timer m_TimeCountTimer = new Timer();
        private int m_Second = 0;
        private int m_Minute = 0;
        private int m_CustomTimerInterval = 0;
        private int m_CustomSecond = 0;

        private bool m_KeyPreview = false;
        private bool m_ContextPopUpVisible = true;

        #endregion


        #region Property : BaseMDI Property

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public BaseMDI BaseMDI
        {
            get
            {
                if (this.m_BaseMDI != null)
                    return m_BaseMDI;
                else if (this.TopLevelControl != null && this.TopLevelControl is BaseMDI)
                    return (BaseMDI)this.TopLevelControl;
                else
                    return null;
            }
            set
            {
                m_BaseMDI = value;
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string SystemCode
        {
            get
            {
                if (BaseMDI != null)
                    return BaseMDI.SystemCode;
                else
                    return "";
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ScreenKey
        {
            get
            {
                return m_ScreenKey;
            }
            set
            {
                m_ScreenKey = value;
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SystemConfig SystemConfig
        {
            get
            {
                if (BaseMDI != null)
                    return BaseMDI.SystemConfig;
                else
                    return null;
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SystemLockService SystemLockService
        {
            get
            {
                if (BaseMDI != null)
                    return BaseMDI.SystemLockService;
                else
                    return null;
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DOPatientInfo SystemPatientInfo
        {
            get
            {
                if (BaseMDI != null)
                    return BaseMDI.SystemPatientInfo;
                else
                    return null;
            }
            setClose

            {
                if (BaseMDI != null)
                    BaseMDI.SystemPatientInfo = value;
            }
        }

        #endregion

        #region Property : Member Property

        [Browsable(true)]
        [Category("Lime Custom"), Description("화면의 Caption을 지정합니다.")]
        [DefaultValue("")]
        public string Caption
        {
            get
            {
                return m_Caption;
            }
            set
            {
                m_Caption = value;
            }
        }

        [Browsable(true)]
        [Category("모양"), Description("화면의 Caption을 지정합니다.")]
        [DefaultValue("")]
        public new string Text
        {
            get
            {
                return m_Caption;
            }
            set
            {
                m_Caption = value;
            }
        }

        [Browsable(true)]
        [Category("Lime Custom"), Description("화면의 Icon을 지정합니다.")]
        public Icon Icon
        {
            get
            {
                return m_Icon;
            }
            set
            {
                m_Icon = value;
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DOPatientInfo PatientInfo
        {
            get
            {
                return m_PatientInfo;
            }
            set
            {
                m_PatientInfo = value;
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Infragistics.Win.UltraWinToolbars.UltraToolbarsManager ContextMenuToolBar
        {
            get
            {
                return m_ContextMenuToolBar;
            }
            set
            {
                m_ContextMenuToolBar = value;
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public ScreenParameters Parameters
        {
            get
            {
                if (m_Parameters == null)
                    m_Parameters = new ScreenParameters();

                return m_Parameters;
            }
            set
            {
                m_Parameters = value;

                if (this.ParameterChanged != null)
                    this.ParameterChanged(m_Parameters, new EventArgs());
            }
        }

        [Browsable(true)]
        [Category("Lime Custom"), Description("화면 Load후 최초로 Focus를 받을 Control을 지정합니다.")]
        [DefaultValue(null)]
        public Control FirstFocusControl
        {
            get
            {
                return m_FirstFocusControl;
            }
            set
            {
                m_FirstFocusControl = value;
            }
        }

        [Browsable(true)]
        [Category("Lime Custom"), Description("사용자 정의 Timer Interval입니다.")]
        [DefaultValue(0)]
        public int CustomTimerInterval
        {
            get
            {
                return m_CustomTimerInterval;
            }
            set
            {
                m_CustomTimerInterval = value;
                m_CustomSecond = m_CustomTimerInterval;
            }
        }


        [Browsable(true)]
        [Category("Lime Custom"), Description("포커스가 있는 컨트롤에 이벤트가 전달되기 전에 폼이 키 이벤트를 받을지 여부를 나타내는 값을 가져오거나 설정합니다.")]
        [DefaultValue(false)]
        public bool KeyPreview
        {
            get
            {
                return m_KeyPreview;
            }
            set
            {
                m_KeyPreview = value;
            }
        }

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool ContextPopUpVisible
        {
            get
            {
                return m_ContextPopUpVisible;
            }
            set
            {
                m_ContextPopUpVisible = value;
            }
        }

        #endregion


        #region Construction

        public BaseUCF()
        {
            InitializeComponent();

            if (this.TopLevelControl != null && this.TopLevelControl is BaseMDI)
                m_BaseMDI = (BaseMDI)this.TopLevelControl;

            this.Disposed += BaseUCF_Disposed;

            //Add Pre Message Filter
            this.AddMessageFilter();

            Initialize();
        }

        private void BaseUCF_Disposed(object sender, EventArgs e)
        {
        }

        #endregion

        #region ISupportInitialize

        /// <summary>
        /// 객체의 초기화 시작
        /// </summary>
        public virtual void BeginInit()
        {
            //아직 객체의 구성요소가 모두 생성된것이 아니므로 특별히 할 일은 없다.
        }

        /// <summary>
        /// 객체의 초기화 종료(객체의 초기화가 종료된 후에 스프레드를 세팅한다.)
        /// </summary>
        public virtual void EndInit()
        {
            //디자인모드가 아닐 경우 스프레드를 초기화 한다.
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Font = new Font("맑은 고딕", 9F, FontStyle.Regular);
        }

        #endregion

        #region Application Message Filter(for Keyboard & Mouse Hooking)

        /// <summary>
        /// Add Message Filter
        /// </summary>
        private void AddMessageFilter()
        {
            if (!m_KeyPreview)
                return;

            try
            {
                Application.AddMessageFilter(this);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        /// <summary>
        /// Remove Message Filter
        /// </summary>
        private void RemoveMessageFilter()
        {
            if (!m_KeyPreview)
                return;

            try
            {
                Application.RemoveMessageFilter(this);
            }
            catch
            {
            }
        }

        public bool PreFilterMessage(ref System.Windows.Forms.Message m)
        {
            //메시지 처리 여부
            bool result = false;

            //KeyPreview 모드 일 때만 동작
            if (!m_KeyPreview)
                return result;

            try
            {
                Keys key = Keys.None;
                KeyEventArgs args;

                switch (m.Msg)
                {
                    case (int)Lime.Framework.Win32.Msgs.WM_KEYDOWN:
                        //메시지를 Keys로 변환.
                        key = (Keys)Enum.Parse(typeof(Keys), m.WParam.ToInt32().ToString());

                        //KeyDown 이벤트 발생
                        args = new KeyEventArgs(key);
                        this.OnKeyDown(args);
                        result = args.SuppressKeyPress; //SuppressKeyPress 처리

                        break;
                    case (int)Lime.Framework.Win32.Msgs.WM_KEYUP:
                        //메시지를 Keys로 변환.
                        key = (Keys)Enum.Parse(typeof(Keys), m.WParam.ToInt32().ToString());

                        //KeyUp 이벤트 발생
                        args = new KeyEventArgs(key);
                        this.OnKeyUp(args);
                        result = args.SuppressKeyPress; //SuppressKeyPress 처리
                        break;
                }
            }
            catch
            {
            }

            return result;
        }

        #endregion


        #region Screen Load

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            m_TimeCountTimer.Interval = 1000;
            m_TimeCountTimer.Tick += TimeCountTimer_Tick;
            m_TimeCountTimer.Start();

            //Loaded Event 발생
            PostCallService.PostCall(new PostMethod(OnLoaded));

            //화면 Load후 최초로 Focus를 받을 Control을 지정.
            if (m_FirstFocusControl != null)
                PostCallService.PostCall(new PostMethod(PostCallFirstFocus));
        }

        #endregion


        #region Method : Initialize Method

        private void Initialize()
        {
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Font = new Font("맑은 고딕", 9F, FontStyle.Regular);

            m_ContextMenuToolBar.DockWithinContainer = this;
            m_ContextMenuToolBar.MiniToolbar.AutoShow = MiniToolbarAutoShow.Never;

            //ContextMenu Event
            m_ContextMenuToolBar.ToolClick += ContextMenuToolBar_ToolClick;
            m_ContextMenuToolBar.BeforeToolDropdown += ContextMenuToolBar_BeforeToolDropdown;
            m_ContextMenuToolBar.AfterToolCloseup += ContextMenuToolBar_AfterToolCloseup;
        }

        private void PostCallFirstFocus()
        {
            if (m_FirstFocusControl != null)
                m_FirstFocusControl.Focus();
        }

        #endregion

        #region Method : Public Method

        public void Close()
        {
            try
            {
                m_TimeCountTimer.Stop();

                if (this.ParentForm != null)
                    ParentForm.Close();
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        public void SaveActionLog(string action, string pid)
        {
            try
            {
                if (this.Tag != null)
                {
                    if (this.Tag is ScreenInfo)
                    {
                        string assmfilename = ((ScreenInfo)this.Tag).AssemblyName;
                        string screenname = ((ScreenInfo)this.Tag).ClassName;

                        //Open System Log 기록
                        if (DOPack.MenuInfo.GetMenuPersonalYN(screenname) == "Y")
                            DBService.ExecuteNonQuery(Lime.Framework.Controls.Sql.InsertActionLog(assmfilename, screenname, action, pid));
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        #endregion

        #region Method : Call Screen Method

        public object CallScreen(ScreenInfo screeninfo)
        {
            return this.CallScreen(screeninfo, null);
        }

        public object CallScreen(ScreenInfo screeninfo, ScreenParameters para)
        {
            if (BaseMDI != null)
            {
                return BaseMDI.CallScreen(screeninfo, para);
            }

            return null;
        }

        public object CallScreen(string assmblyname, string classname, string screenname)
        {
            return this.CallScreen(assmblyname, classname, screenname, null);
        }

        public object CallScreen(string assmblyname, string classname, string screenname, ScreenParameters para)
        {
            if (BaseMDI != null)
            {
                return BaseMDI.CallScreen(assmblyname, classname, screenname, para);
            }

            return null;
        }

        #endregion

        #region Method : Call PopUp Method

        public DialogResult CallPopUp(ScreenInfo screeninfo)
        {
            return this.CallPopUp(screeninfo, null);
        }

        public DialogResult CallPopUp(ScreenInfo screeninfo, ScreenParameters para)
        {
            try
            {
                if (BaseMDI != null)
                {
                    return BaseMDI.CallPopUp(screeninfo, para);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return DialogResult.None;
        }

        public DialogResult CallPopUp(string assmblyname, string classname, string screenname)
        {
            return this.CallPopUp(assmblyname, classname, screenname, null);
        }

        public DialogResult CallPopUp(string assmblyname, string classname, string screenname, ScreenParameters para)
        {
            try
            {
                if (BaseMDI != null)
                {
                    return BaseMDI.CallPopUp(assmblyname, classname, screenname, para);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return DialogResult.None;
        }

        public DialogResult CallPopUp(IWin32Window owner, ScreenInfo screeninfo)
        {
            return this.CallPopUp(owner, screeninfo, null);
        }

        public DialogResult CallPopUp(IWin32Window owner, ScreenInfo screeninfo, ScreenParameters para)
        {
            try
            {
                if (BaseMDI != null)
                {
                    return BaseMDI.CallPopUp(owner, screeninfo, para);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return DialogResult.None;
        }

        public DialogResult CallPopUp(IWin32Window owner, string assmblyname, string classname, string screenname)
        {
            return this.CallPopUp(owner, assmblyname, classname, screenname, null);
        }

        public DialogResult CallPopUp(IWin32Window owner, string assmblyname, string classname, string screenname, ScreenParameters para)
        {
            try
            {
                if (BaseMDI != null)
                {
                    return BaseMDI.CallPopUp(owner, assmblyname, classname, screenname, para);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return DialogResult.None;
        }

        #endregion

        #region Method : Screen Method

        /// <summary>
        /// Load 된 Screen중에서 해당 Screen이 있는지 검색한다.
        /// </summary>
        /// <param name="classname"></param>
        /// <returns></returns>
        public bool ContainsScreen(string classname)
        {
            try
            {
                if (BaseMDI != null)
                {
                    return BaseMDI.ContainsScreen(classname);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return false;
        }

        /// <summary>
        /// Load 된 Screen중에서 해당 Screen을 반환한다.
        /// </summary>
        /// <param name="classname"></param>
        /// <returns></returns>
        public object GetScreen(string classname)
        {
            try
            {
                if (BaseMDI != null)
                {
                    return BaseMDI.GetScreen(classname);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return null;
        }

        /// <summary>
        /// Load 된 Screen중에서 해당 Screen을 Close한다.
        /// </summary>
        /// <param name="classname"></param>
        /// <returns></returns>
        public bool CloseScreen(string classname)
        {
            try
            {
                if (BaseMDI != null)
                {
                    return BaseMDI.CloseScreen(classname);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return false;
        }

        /// <summary>
        /// Load 된 Screen중에서 해당 Screen을 찾아 Parameter를 전송한다.
        /// </summary>
        /// <param name="classname"></param>
        /// <returns></returns>
        public void SendParameterToScreen(string classname, ScreenParameters para)
        {
            try
            {
                if (BaseMDI != null)
                {
                    BaseMDI.SendParameterToScreen(classname, para);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        #endregion


        #region Method : Context Menu Method

        #region Method : Create Context Menu

        /// <summary>
        /// Context Menu 생성
        /// </summary>
        public void CreateScreenContextMenu()
        {
            if (m_ContextMenuToolBar != null)
            {
                ContextMenuService.CreateScreenContextMenu(m_ContextMenuToolBar, this, this.Name);
            }
        }

        /// <summary>
        /// Context Menu 생성
        /// </summary>
        /// <param name="ctmncd"></param>
        public bool CreateContextMenu(string ctmncd)
        {
            if (m_ContextMenuToolBar != null)
            {
                try
                {
                    //이미 로드 되었는지 체크
                    if (m_ContextMenuToolBar.MiniToolbar.Tools.Exists(ctmncd))
                        return true;

                    //Context Menu를 생성한다.
                    if (ContextMenuService.CreateContextMenu(m_ContextMenuToolBar, this, ctmncd))
                    {
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    LogService.ErrorLog(ex);
                }
            }

            return false;
        }

        /// <summary>
        /// Context Menu 생성
        /// </summary>
        /// <param name="ctmncd"></param>
        public bool CreateContextSubMenu(string ctmncd)
        {
            if (m_ContextMenuToolBar != null)
            {
                try
                {
                    //이미 로드 되었는지 체크
                    if (m_ContextMenuToolBar.MiniToolbar.Tools.Exists(ctmncd))
                        return true;

                    //Context Menu를 생성한다.
                    if (ContextMenuService.CreateContextSubMenu(m_ContextMenuToolBar, this, ctmncd))
                    {
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    LogService.ErrorLog(ex);
                }
            }

            return false;
        }

        #endregion

        #region Method : Show Context Menu

        /// <summary>
        /// Show Context Menu
        /// </summary>
        /// <param name="ctmncd"></param>
        public void ShowContextMenu(string ctmncd)
        {
            this.ShowContextMenu(ctmncd, -1, -1);
        }

        /// <summary>
        /// Show Context Menu
        /// </summary>
        /// <param name="ctmncd"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public void ShowContextMenu(string ctmncd, int x, int y)
        {
            if (m_ContextMenuToolBar != null)
            {
                try
                {
                    //해당 메뉴가 없으면 생성한다.
                    if (this.CreateContextMenu(ctmncd))
                    {
                        if (x.Equals(-1) && y.Equals(-1))
                            m_ContextMenuToolBar.ShowPopup(ctmncd, this);
                        else
                            m_ContextMenuToolBar.ShowPopup(ctmncd, this, new Point(x, y));
                    }
                }
                catch (Exception ex)
                {
                    LogService.ErrorLog(ex);
                }
            }
        }

        /// <summary>
        /// Show Context Menu
        /// </summary>
        /// <param name="ctmncd"></param>
        public void ShowContextSubMenu(string ctmncd)
        {
            this.ShowContextSubMenu(ctmncd, -1, -1);
        }

        /// <summary>
        /// Show Context Menu
        /// </summary>
        /// <param name="ctmncd"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public void ShowContextSubMenu(string ctmncd, int x, int y)
        {
            if (m_ContextMenuToolBar != null)
            {
                try
                {
                    //해당 메뉴가 없으면 생성한다.
                    if (this.CreateContextSubMenu(ctmncd))
                    {
                        if (x.Equals(-1) && y.Equals(-1))
                            m_ContextMenuToolBar.ShowPopup(ctmncd, this);
                        else
                            m_ContextMenuToolBar.ShowPopup(ctmncd, this, new Point(x, y));
                    }
                }
                catch (Exception ex)
                {
                    LogService.ErrorLog(ex);
                }
            }
        }

        #endregion 

        #region Method : Get Context Menu

        /// <summary>
        /// Context Menu 조회
        /// </summary>
        /// <param name="ctmncd"></param>
        /// <returns></returns>
        public PopupMenuTool GetContextMenu(string ctmncd)
        {
            ToolBase tool = null;

            try
            {
                if (m_ContextMenuToolBar.MiniToolbar.Tools.Exists(ctmncd))
                {
                    tool = m_ContextMenuToolBar.MiniToolbar.Tools[ctmncd];

                    if (tool is PopupMenuTool)
                        return (PopupMenuTool)tool;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return null;
        }

        /// <summary>
        /// Context Menu 내의 Tool 조회
        /// </summary>
        /// <param name="ctmncd"></param>
        /// <param name="menucd"></param>
        /// <returns></returns>
        public ToolBase GetContextMenuTool(string ctmncd, string menucd)
        {
            ToolBase tool = null;

            try
            {
                if (m_ContextMenuToolBar.MiniToolbar.Tools.Exists(ctmncd))
                {
                    tool = m_ContextMenuToolBar.MiniToolbar.Tools[ctmncd];

                    if (tool is PopupMenuTool)
                    {
                        if (((PopupMenuTool)tool).Tools.Exists(menucd))
                        {
                            return ((PopupMenuTool)tool).Tools[menucd];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return null;
        }

        /// <summary>
        /// 전체 Tool 중 Tool 조회
        /// </summary>
        /// <param name="menucd"></param>
        /// <returns></returns>
        public ToolBase GetContextMenuTool(string menucd)
        {
            try
            {
                foreach (ToolBase tool in m_ContextMenuToolBar.MiniToolbar.Tools)
                {
                    if (tool is PopupMenuTool)
                    {
                        if (((PopupMenuTool)tool).Tools.Exists(menucd))
                        {
                            return ((PopupMenuTool)tool).Tools[menucd];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return null;
        }

        #endregion

        #endregion

        #region Method : System Lock Method

        /// <summary>
        /// System Lock이 걸려 있는지 확인
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="system_cd"></param>
        /// <returns></returns>
        public bool IsLockedSystem(string pid, string pt_cmhs_no)
        {
            return SystemLockService.IsLocked(pid, pt_cmhs_no);
        }

        /// <summary>
        /// System Lock이 걸려 있는지 확인
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="system_cd"></param>
        /// <returns></returns>
        public bool IsLockedSystem(string pid, string pt_cmhs_no, string system_cd)
        {
            return SystemLockService.IsLocked(pid, pt_cmhs_no, system_cd);
        }

        /// <summary>
        /// System Lock을 생성하여 Lock을 건다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="system_cd"></param>
        /// <returns></returns>
        public bool LockSystem(string pid, string pt_cmhs_no)
        {
            return SystemLockService.Lock(pid, pt_cmhs_no, this.SystemCode);
        }

        /// <summary>
        /// System Lock을 생성하여 Lock을 건다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="system_cd"></param>
        /// <returns></returns>
        public bool LockSystem(string pid, string pt_cmhs_no, string system_cd)
        {
            return SystemLockService.Lock(pid, pt_cmhs_no, system_cd);
        }

        /// <summary>
        /// System Lock을 삭제하여 Lock을 푼다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="system_cd"></param>
        /// <returns></returns>
        public bool UnLockSystem(string pid, string pt_cmhs_no)
        {
            return UnLockSystem(pid, pt_cmhs_no, false);
        }

        /// <summary>
        /// System Lock을 삭제하여 Lock을 푼다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="system_cd"></param>
        /// <returns></returns>
        public bool UnLockSystem(string pid, string pt_cmhs_no, string system_cd)
        {
            return SystemLockService.UnLock(pid, pt_cmhs_no, system_cd);
        }

        /// <summary>
        /// System Lock을 삭제하여 Lock을 푼다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="pt_cmhs_no"></param>
        /// <param name="system_cd"></param>
        /// <returns></returns>
        public bool UnLockSystem(string pid, string pt_cmhs_no, bool allsystem = false)
        {
            if (allsystem)
                return SystemLockService.UnLock(pid, pt_cmhs_no);
            else
                return SystemLockService.UnLock(pid, pt_cmhs_no, this.SystemCode);
        }

        #endregion


        #region Method : ErrorProvider Method

        public void SetError(Control control, string msg)
        {
            ErrorProvider.SetError(control, msg);
            ErrorProvider.SetIconAlignment(control, ErrorIconAlignment.MiddleRight);
            ErrorProvider.SetIconPadding(control, -9);
        }

        public void ClearError()
        {
            ErrorProvider.Clear();
        }

        #endregion


        #region Event : Timer Event Process

        private void TimeCountTimer_Tick(object sender, EventArgs e)
        {
            m_TimeCountTimer.Stop();

            this.OnTimeEventSecond();

            //Custom Interval
            if (--m_CustomSecond == 0)
            {
                m_CustomSecond = m_CustomTimerInterval;
                this.OnTimeEventCustomInterval();
            }

            m_Second++;

            if (m_Second % 5 == 0)
                this.OnTimeEvent5Second();
            if (m_Second % 10 == 0)
                this.OnTimeEvent10Second();
            if (m_Second % 15 == 0)
                this.OnTimeEvent15Second();
            if (m_Second % 30 == 0)
                this.OnTimeEvent30Second();

            if (m_Second >= 60)
            {
                m_Second = 0;
                m_Minute++;

                this.OnTimeEventMinute();

                if (m_Minute % 5 == 0)
                    this.OnTimeEvent5Minute();
                if (m_Minute % 10 == 0)
                    this.OnTimeEvent10Minute();
                if (m_Minute % 15 == 0)
                    this.OnTimeEvent15Minute();
                if (m_Minute % 30 == 0)
                    this.OnTimeEvent30Minute();
                if (m_Minute % 60 == 0)
                {
                    m_Minute = 0;
                    this.OnTimeEventHour();
                }
            }

            if (m_TimeCountTimer != null)
                m_TimeCountTimer.Start();
        }

        #endregion

        #region Event : ContextMenu Event Process

        private void ContextMenuToolBar_BeforeToolDropdown(object sender, BeforeToolDropdownEventArgs e)
        {
            if (!m_ContextPopUpVisible)
                e.Cancel = true;

            if (e.Tool is PopupMenuTool && e.Tool.IsRootTool)
                this.OnContextMenuOpen(e.Tool.Key, (PopupMenuTool)e.Tool);
        }

        private void ContextMenuToolBar_AfterToolCloseup(object sender, ToolDropdownEventArgs e)
        {
            //if (e.Tool is PopupMenuTool && e.Tool.IsRootTool)
            //    this.OnContextMenuClose(e.Tool.Key, (PopupMenuTool)e.Tool);
        }

        private void ContextMenuToolBar_ToolClick(object sender, ToolClickEventArgs e)
        {
            this.OnContextMenuClick(e.Tool.OwningMenu.Key, e.Tool.Key, e.Tool.SharedProps.Caption, e.Tool);
        }

        #endregion


        #region Event : Raise Events

        /// <summary>
        /// 화면의 Load가 끝난 후에 발생하는 이벤트
        /// </summary>
        private void OnLoaded()
        {
            if (this.Loaded != null)
            {
                EventArgs arg = new EventArgs();

                this.Loaded(this, arg);
            }
        }

        public bool OnScreenClosing()
        {
            CancelEventArgs args = new CancelEventArgs();

            if (this.ScreenClosing != null)
            {
                this.ScreenClosing(this, args);
            }

            return args.Cancel;
        }

        public void OnScreenClosed()
        {
            if (this.ScreenClosed != null)
            {
                EventArgs args = new EventArgs();

                this.ScreenClosed(this, args);
            }
        }

        #endregion

        #region Event : Raise Context Menu Event 

        private void OnContextMenuOpen(string contextmenucode, PopupMenuTool tool)
        {
            try
            {
                if (this.ContextMenuOpen != null)
                {
                    ContextMenuOpenCloseEventArgs args = new ContextMenuOpenCloseEventArgs(contextmenucode, tool);

                    this.ContextMenuOpen(args);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        private void OnContextMenuClose(string contextmenucode, PopupMenuTool tool)
        {
            try
            {
                if (this.ContextMenuClose != null)
                {
                    ContextMenuOpenCloseEventArgs args = new ContextMenuOpenCloseEventArgs(contextmenucode, tool);

                    this.ContextMenuClose(args);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        private void OnContextMenuClick(string contextmenucode, string menucode, string menuname, ToolBase tool)
        {
            try
            {
                if (this.ContextMenuClick != null)
                {
                    ContextMenuClickEventArgs args = new ContextMenuClickEventArgs(contextmenucode, menucode, menuname, tool);

                    this.ContextMenuClick(args);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        #endregion

        #region Event : Raise Timer Events

        private void OnTimeEventSecond()
        {
            if (TimeEventSecond != null)
                TimeEventSecond(this, new EventArgs());
        }

        private void OnTimeEvent5Second()
        {
            if (TimeEvent5Second != null)
                TimeEvent5Second(this, new EventArgs());
        }

        private void OnTimeEvent10Second()
        {
            if (TimeEvent10Second != null)
                TimeEvent10Second(this, new EventArgs());
        }

        private void OnTimeEvent15Second()
        {
            if (TimeEvent15Second != null)
                TimeEvent15Second(this, new EventArgs());
        }

        private void OnTimeEvent30Second()
        {
            if (TimeEvent30Second != null)
                TimeEvent30Second(this, new EventArgs());
        }

        private void OnTimeEventMinute()
        {
            if (TimeEventMinute != null)
                TimeEventMinute(this, new EventArgs());
        }

        private void OnTimeEvent5Minute()
        {
            if (TimeEvent5Minute != null)
                TimeEvent5Minute(this, new EventArgs());
        }

        private void OnTimeEvent10Minute()
        {
            if (TimeEvent10Minute != null)
                TimeEvent10Minute(this, new EventArgs());
        }

        private void OnTimeEvent15Minute()
        {
            if (TimeEvent15Minute != null)
                TimeEvent15Minute(this, new EventArgs());
        }

        private void OnTimeEvent30Minute()
        {
            if (TimeEvent30Minute != null)
                TimeEvent30Minute(this, new EventArgs());
        }

        private void OnTimeEventHour()
        {
            if (TimeEventHour != null)
                TimeEventHour(this, new EventArgs());
        }

        private void OnTimeEventCustomInterval()
        {
            if (TimeEventCustomInterval != null)
                TimeEventCustomInterval(this, new EventArgs());


        }

        #endregion

    }
}
