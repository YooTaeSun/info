//package web.townsi.com.work.tibero01.ddl.mapper;
//
//
//import java.lang.invoke.MethodHandles;
//import java.util.HashMap;
//import java.util.List;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.stereotype.Repository;
//
//import web.townsi.com.work.tibero01.MapperTibero01;
//
//@Repository
//public class Tibero01Mapper extends MapperTibero01 {
//
//	private Logger logger = LoggerFactory.getLogger(Tibero01Mapper.class);
//
//	private final static String NAMESPACE = MethodHandles.lookup().lookupClass().getCanonicalName() + ".";
//
//    public int insert(String queryId, Object params) {
//    	return sqlSession.insert(NAMESPACE + queryId, params);
//    }
//
//    public int update(String queryId, Object params) {
//    	return sqlSession.update(NAMESPACE + queryId, params);
//    }
//
//    public int delete(String queryId, Object params) {
//    	return sqlSession.delete(NAMESPACE + queryId, params);
//    }
//
//	public List selectList(String queryId, Object params) {
//		return sqlSession.selectList(NAMESPACE + queryId, params);
//	}
//
//	public Object selectOne(String queryId, Object params) {
//		return sqlSession.selectOne(NAMESPACE + queryId, params);
//	}
//
////---------------------------------------------------------------------------
//	
//    public int dropTable(HashMap params) {
//    	return sqlSession.update(NAMESPACE + "dropTable", params);
//    }
//	
//	public List<HashMap> selectTableList(HashMap params){
//		return sqlSession.selectList(NAMESPACE + "selectTableList", params);
//	}
//	
//	public List<HashMap> selectTableInfo(HashMap params){
//		return sqlSession.selectList(NAMESPACE + "selectTableInfo", params);
//	}
//	 
//	public int createTable(String value){
//		return sqlSession.update(NAMESPACE + "createTable", value);
//	}
//	
//	public int deleteTable(HashMap params){
//		return sqlSession.delete(NAMESPACE + "deleteTable", params);
//	}
//	
//
//}