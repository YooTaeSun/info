package web.townsi.com.work.setting.biz;

import java.util.HashMap;
import java.util.List;

public interface SettingServiceBiz {
	public abstract HashMap<String, Object> makeService(HashMap paramHashMap) throws Exception;
	public abstract HashMap<String, Object> makeServiceImpl(HashMap paramHashMap) throws Exception;
}