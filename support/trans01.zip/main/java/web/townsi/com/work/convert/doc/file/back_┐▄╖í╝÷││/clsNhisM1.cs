using System;
using System.Data;
using System.Diagnostics;

namespace Lime.Framework.BusinessService
{
    public class clsNhisM1
    {
        #region Define : Member

        #region Member Field

        private int m_UniqNo = 0;
        private System.Windows.Forms.Timer m_SelectTime = new System.Windows.Forms.Timer();
        private Stopwatch m_Stopwatch = new Stopwatch();
        private clsNhisM2 m_M2 = new clsNhisM2();

        #endregion Member Field

        #region 공단 제공 변수

        /// <summary>
        /// DB에 저장할 환자번호
        /// </summary>
        public string PID = string.Empty;

        /// <summary>
        /// 수진자주민번호
        /// </summary>
        public string sujinjaJuminNo = string.Empty;

        /// <summary>
        /// 요양기관기호
        /// </summary>
        public string ykiho = string.Empty;

        /// <summary>
        /// 수진자성명
        /// </summary>
        public string sujinjaJuminNm = string.Empty;

        /// <summary>
        /// 진료일자 및 현재일자
        /// </summary>
        public string diagDt = string.Empty;

        /// <summary>
        /// 건강보험증번호
        /// </summary>
        public string hiCardNo = string.Empty;

        /// <summary>
        /// 생년월일
        /// </summary>
        public string birthDay = string.Empty;

        /// <summary>
        /// 건보로그인ID
        /// </summary>
        public string loginId = string.Empty;

        /// <summary>
        /// 건보로그인 password
        /// </summary>
        public string password = string.Empty;

        /// <summary>
        /// 시스템일자
        /// </summary>
        public string InputDate = string.Empty;

        /// <summary>
        /// 처리결과 (공단 해당없음.)
        /// </summary>
        public string status = string.Empty;

        /// <summary>
        /// 메시지타입
        /// </summary>
        public string msgType = "M1";

        /// <summary>
        /// 클라이언트 정보
        /// </summary>
        public string clientInfo = string.Empty;

        /// <summary>
        /// 담당자 주민번호
        /// </summary>
        public string operatorJuminNo = string.Empty;

        /// <summary>
        /// 프로그램 구분
        /// </summary>
        public string pgmType = string.Empty;

        /// <summary>
        /// DLL 버전
        /// </summary>
        public string version = string.Empty;

        /// <summary>
        /// 장애구분코드
        /// </summary>
        public string dsbldvcd = string.Empty; //2017-11-08. M1테이블 컬럼추가로인해 유준선 추가.

        /// <summary>
        /// 처리구분코드
        /// </summary>
        public string dlwtdvcd = string.Empty; //2017-11-08. M1테이블 컬럼추가로인해 유준선 추가.

        /// <summary>
        /// 등록일시
        /// </summary>
        public string rgstdt = string.Empty; //2017-11-08. M1테이블 컬럼추가로인해 유준선 추가.

        /// <summary>
        /// 등록자ID
        /// </summary>
        public string rgstrid = string.Empty; //2017-11-08. M1테이블 컬럼추가로인해 유준선 추가.

        public string DSBL_DVCD = string.Empty;

        #endregion 공단 제공 변수

        #endregion Define : Member

        #region Define : Member Property

        public clsNhisM2 M2
        {
            get { return this.m_M2; }
        }

        public int Uniqno
        {
            get { return this.m_UniqNo; }
        }
        #endregion Define : Member Property

        #region Define : Property

        public delegate void GetMessage2(clsNhisM2 m2);
        public delegate void SendProblem(); //YJS추가, 자격조회 장애 발생 시 자격조회를 중단하고, 메시지를 띄우는데 사용.(외래접수,외래접수변경,보험정보관리)

        public event GetMessage2 OnGetMessage2;
        public event SendProblem OnSendProblem;

        #endregion Define : Property

        #region Method : Public Method

        public void Clear()
        {
            this.PID = string.Empty;
            this.sujinjaJuminNo = string.Empty;
            this.ykiho = string.Empty;
            this.sujinjaJuminNm = string.Empty;
            this.diagDt = string.Empty;
            this.hiCardNo = string.Empty;
            this.birthDay = string.Empty;
            this.loginId = string.Empty;
            this.password = string.Empty;
            this.InputDate = string.Empty;
            this.status = string.Empty;
            this.msgType = "M1";
            this.clientInfo = string.Empty;
            this.operatorJuminNo = string.Empty;
            this.pgmType = string.Empty;
            this.version = string.Empty;
            this.DSBL_DVCD = string.Empty;
        }

        public bool SendM1(string diagdate, string patientname = "", string patientRRNO = "")
        {
            bool NewPatient = false;
            DataTable ResultTable = new DataTable();
            FileVersionInfo lFileVersionInfo;

            //****************************************************************************************************
            // 신환 환자를 위해 체크한다
            //****************************************************************************************************
            NewPatient = (!string.IsNullOrWhiteSpace(patientname) && !string.IsNullOrWhiteSpace(patientRRNO)) ? true : false;

            this.Clear();

            //****************************************************************************************************
            // FileVersion
            //****************************************************************************************************
            lFileVersionInfo = FileVersionInfo.GetVersionInfo(ClientEnvironment.SolutionPath + @"\Lib\WebService.dll");

            //****************************************************************************************************
            // Timer (응답 M2 테이블 데이터 들어왔는지 확인)
            //****************************************************************************************************
            this.m_SelectTime.Interval = 1000;
            this.m_SelectTime.Tick -= this.OnSelectTime_Tick;
            this.m_SelectTime.Tick += this.OnSelectTime_Tick;
            this.m_SelectTime.Start();

            //****************************************************************************************************
            // 너무 오래기다리지 않게 Stopwatch로 처리
            //****************************************************************************************************
            this.m_Stopwatch.Reset();
            this.m_Stopwatch.Start();

            //****************************************************************************************************
            // M1 데이터
            //****************************************************************************************************
            this.PID = NewPatient ? string.Empty : DOPack.PatientInfo.PID;
            this.sujinjaJuminNo = NewPatient ? patientRRNO : DOPack.PatientInfo.FRRN + DOPack.PatientInfo.SRRN_ECPT;
            this.ykiho = DOPack.HospitalInfo.HPTL_RGNO_CD;
            this.sujinjaJuminNm = NewPatient ? patientname : DOPack.PatientInfo.PT_NM;
            this.diagDt = diagdate;
            //this.hiCardNo        = NewPatient ? string.Empty : DOPack.PatientInfo.InsuranceNo;
            this.birthDay = NewPatient ? patientRRNO.Substring(0, 6) : DOPack.PatientInfo.FRRN;
            this.loginId = DOPack.HospitalInfo.NHIC_LOGN_ID;
            this.password = DOPack.HospitalInfo.NHIC_LOGN_PW;
            this.InputDate = DateTime.UtcNow.AddHours(9).ToString("yyyyMMdd-HHmmss");
            this.msgType = "M1";
            this.clientInfo = StringService.SubStringByte(ClientEnvironment.ComputerName + "/" + ClientEnvironment.IP, 0, 50);
            this.operatorJuminNo = DOPack.UserInfo.FRRN + DOPack.UserInfo.SRRN_ECPT;
            this.status = "0";
            this.pgmType = "2";
            this.version = lFileVersionInfo.FileVersion;
            this.dsbldvcd = string.Empty;                                 //2017-11-08. M1테이블 컬럼추가로인해 유준선 추가.
            this.dlwtdvcd = "0";                                          //2017-11-08. M1테이블 컬럼추가로인해 유준선 추가.
            this.rgstdt = DateTime.Now.ToString("yyyyMMddHHmmss");      //2017-11-08. M1테이블 컬럼추가로인해 유준선 추가.
            this.rgstrid = DOPack.UserInfo.USER_CD;                      //2017-11-08. M1테이블 컬럼추가로인해 유준선 추가.
            this.DSBL_DVCD = "1";

            //****************************************************************************************************
            // Unique Number
            //****************************************************************************************************
            this.GetUniqNo();

            if (!clsNhisDB.SaveM1(this, this.m_UniqNo))
            {
                LogService.Write("★★★ 자격조회 M1정보 저장실패 ★★★");
                return false;
            }

            return true;
        }

        public bool SendM1(string diagdate, bool isNewPatient, string patientname = "", string patientRRNO = "")
        {
            DataTable ResultTable = new DataTable();
            FileVersionInfo lFileVersionInfo;

            this.Clear();

            //****************************************************************************************************
            // FileVersion
            //****************************************************************************************************
            lFileVersionInfo = FileVersionInfo.GetVersionInfo(ClientEnvironment.SolutionPath + @"\Lib\WebService.dll");

            //****************************************************************************************************
            // Timer (응답 M2 테이블 데이터 들어왔는지 확인)
            //****************************************************************************************************
            this.m_SelectTime.Interval = 1000;
            this.m_SelectTime.Tick -= this.OnSelectTime_Tick;
            this.m_SelectTime.Tick += this.OnSelectTime_Tick;
            this.m_SelectTime.Start();

            //****************************************************************************************************
            // 너무 오래기다리지 않게 Stopwatch로 처리
            //****************************************************************************************************
            this.m_Stopwatch.Reset();
            this.m_Stopwatch.Start();

            //****************************************************************************************************
            // M1 데이터
            //****************************************************************************************************
            this.PID = isNewPatient ? string.Empty : DOPack.PatientInfo.PID;
            this.sujinjaJuminNo = string.IsNullOrWhiteSpace(patientRRNO) ? DOPack.PatientInfo.FRRN + DOPack.PatientInfo.SRRN_ECPT : patientRRNO;
            this.ykiho = DOPack.HospitalInfo.HPTL_RGNO_CD;
            this.sujinjaJuminNm = string.IsNullOrWhiteSpace(patientname) ? DOPack.PatientInfo.PT_NM : patientname;
            this.diagDt = diagdate;
            //this.hiCardNo        = NewPatient ? string.Empty : DOPack.PatientInfo.InsuranceNo;
            this.birthDay = patientRRNO.Length < 6 ? DOPack.PatientInfo.FRRN : patientRRNO.Substring(0, 6);
            this.loginId = DOPack.HospitalInfo.NHIC_LOGN_ID;
            this.password = DOPack.HospitalInfo.NHIC_LOGN_PW;
            this.InputDate = DateTime.UtcNow.AddHours(9).ToString("yyyyMMdd-HHmmss");
            this.msgType = "M1";
            this.clientInfo = StringService.SubStringByte(ClientEnvironment.ComputerName + "/" + ClientEnvironment.IP, 0, 50);
            this.operatorJuminNo = DOPack.UserInfo.FRRN + DOPack.UserInfo.SRRN_ECPT;
            this.status = "0";
            this.pgmType = "2";
            this.version = lFileVersionInfo.FileVersion;
            this.dsbldvcd = string.Empty;                                 //2017-11-08. M1테이블 컬럼추가로인해 유준선 추가.
            this.dlwtdvcd = "0";                                          //2017-11-08. M1테이블 컬럼추가로인해 유준선 추가.
            this.rgstdt = DateTime.Now.ToString("yyyyMMddHHmmss");      //2017-11-08. M1테이블 컬럼추가로인해 유준선 추가.
            this.rgstrid = DOPack.UserInfo.USER_CD;                      //2017-11-08. M1테이블 컬럼추가로인해 유준선 추가.
            this.DSBL_DVCD = "1";

            //****************************************************************************************************
            // Unique Number
            //****************************************************************************************************
            this.GetUniqNo();

            if (!clsNhisDB.SaveM1(this, this.m_UniqNo))
            {
                LogService.Write("★★★ 자격조회 M1정보 저장실패 ★★★");
                return false;
            }

            return true;
        }

        #endregion Method : Public Method

        #region Method : Private Method

        private void SelectM2()
        {
            this.m_SelectTime.Stop();

            if (this.m_Stopwatch.Elapsed.TotalSeconds > 30)
            {
                this.m_SelectTime.Stop();
                this.m_UniqNo = 0;
                if (this.OnSendProblem != null)
                    OnSendProblem();
                return;
            }

            DataTable M2Table = new DataTable();
            M2Table = clsNhisDB.SelectPANHM2MA(this.m_UniqNo.ToString().Trim());

            if (M2Table == null || M2Table.Rows.Count < 1)
            {
                this.m_SelectTime.Start();
            }
            else
            {
                this.GetM2(M2Table.Rows[0]);
                if (this.OnGetMessage2 != null)
                    this.OnGetMessage2(this.m_M2);
            }
        }

        private clsNhisM2 GetM2(DataRow M2DataRow)
        {
            this.m_M2.m1_sujinjaJuminNm = M2DataRow["M1_SUJINJAJUMINNM"].ToString();
            this.m_M2.sujinjaJuminNo = M2DataRow["SUJINJAJUMINNO"].ToString();
            this.m_M2.sujinjaJuminNm = M2DataRow["SUJINJAJUMINNM"].ToString();
            this.m_M2.requestResult = (M2DataRow["MESSAGECODE"].ToString() == "IWS10001") ? true : false;
            this.m_M2.ykiho = M2DataRow["YKIHO"].ToString();
            this.m_M2.qlfType = M2DataRow["QLFTYPE"].ToString();
            this.m_M2.qlfTypeNm = this.m_M2.qlfType.Equals("1") ? "지역가입자" :
                                        this.m_M2.qlfType.Equals("2") ? "지역세대원" :
                                        this.m_M2.qlfType.Equals("4") ? "임의계속직장가입자" :
                                        this.m_M2.qlfType.Equals("5") ? "직장가입자" :
                                        this.m_M2.qlfType.Equals("6") ? "직장피부양자" :
                                        this.m_M2.qlfType.Equals("7") ? "의료급여1종" :
                                        this.m_M2.qlfType.Equals("8") ? "의료급여2종" : this.m_M2.qlfTypeNm;
            this.m_M2.qlfChwidukDt = M2DataRow["QLFCHWIDUKDT"].ToString();
            this.m_M2.sedaejuNm = M2DataRow["SEDAEJUNM"].ToString();
            this.m_M2.protAdminSym = M2DataRow["PROTADMINSYM"].ToString();
            this.m_M2.asylmSym = M2DataRow["ASYLMSYM"].ToString();
            this.m_M2.payRestricDt = M2DataRow["PAYRESTRICDT"].ToString();
            this.m_M2.sbrdnType = M2DataRow["SBRDNTYPE"].ToString();
            this.m_M2.cfhcRem = M2DataRow["CFHCREM"].ToString();
            this.m_M2.ykiho1 = M2DataRow["YKIHO1"].ToString();
            this.m_M2.ykiho2 = M2DataRow["YKIHO2"].ToString();
            this.m_M2.ykiho3 = M2DataRow["YKIHO3"].ToString();
            this.m_M2.ykiho4 = M2DataRow["YKIHO4"].ToString();
            this.m_M2.yoyangNm1 = M2DataRow["YOYANGNM1"].ToString();
            this.m_M2.yoyangNm2 = M2DataRow["YOYANGNM2"].ToString();
            this.m_M2.yoyangNm3 = M2DataRow["YOYANGNM3"].ToString();
            this.m_M2.yoyangNm4 = M2DataRow["YOYANGNM4"].ToString();
            this.m_M2.dprtYn = M2DataRow["DPRTYN"].ToString();
            this.m_M2.obstRegDt = M2DataRow["OBSTREGDT"].ToString();
            this.m_M2.disRegPrson1 = M2DataRow["DISREGPRSON1"].ToString();
            this.m_M2.disRegPrson2 = M2DataRow["DISREGPRSON2"].ToString();
            this.m_M2.disRegPrson3 = M2DataRow["DISREGPRSON3"].ToString();
            this.m_M2.disRegPrson4 = M2DataRow["DISREGPRSON4"].ToString();
            this.m_M2.reqPatInfo = M2DataRow["REQPATINFO"].ToString();
            this.m_M2.pregRemAmt = M2DataRow["PREGREMAMT"].ToString();
            this.m_M2.disRegPrson5 = M2DataRow["DISREGPRSON5"].ToString();
            this.m_M2.disRegPrson6 = M2DataRow["DISREGPRSON6"].ToString();
            this.m_M2.disRegPrson7 = M2DataRow["DISREGPRSON7"].ToString();
            this.m_M2.dentTop = M2DataRow["DENTTOP"].ToString();
            this.m_M2.dentBottom = M2DataRow["DENTBOTTOM"].ToString();
            this.m_M2.sangsilProcDt = M2DataRow["SANGSILPROCDT"].ToString();
            this.m_M2.disRegPrson8 = M2DataRow["DISREGPRSON8"].ToString();
            this.m_M2.qlfRestrictCd = M2DataRow["QLFRESTRICTCD"].ToString();
            this.m_M2.disRegPrson9 = M2DataRow["DISREGPRSON9"].ToString();
            this.m_M2.dentImpl1 = M2DataRow["DENTIMPL1"].ToString();
            this.m_M2.dentImpl2 = M2DataRow["DENTIMPL2"].ToString();
            this.m_M2.obstYn = M2DataRow["OBSTYN"].ToString();
            this.m_M2.diabetesCd = M2DataRow["DIABETESCD"].ToString();
            this.m_M2.disRegPrson10 = M2DataRow["DISREGPRSON10"].ToString();
            this.m_M2.disRegPrson11 = M2DataRow["DISREGPRSON11"].ToString();
            this.m_M2.preInfant = M2DataRow["PREINFANT"].ToString();
            this.m_M2.disRegPrson12 = M2DataRow["DISREGPRSON12"].ToString();
            this.m_M2.disRegPrson13 = M2DataRow["DISREGPRSON13"].ToString();
            this.m_M2.disRegPrson14 = M2DataRow["DISREGPRSON14"].ToString();
            this.m_M2.disRegPrson15 = M2DataRow["DISREGPRSON15"].ToString();
            this.m_M2.disRegPrson16 = M2DataRow["DISREGPRSON16"].ToString();
            this.m_M2.disRegPrson17 = M2DataRow["DISREGPRSON17"].ToString();
            this.m_M2.InputDate = M2DataRow["INPUTDATE"].ToString();
            this.m_M2.PICKUP_FLAG = M2DataRow["PICKUPFLAG"].ToString();
            this.m_M2.messageCode = M2DataRow["MESSAGECODE"].ToString();
            this.m_M2.message = M2DataRow["MESSAGE"].ToString();
            this.m_M2.msgType = M2DataRow["MSGTYPE"].ToString();
            this.m_M2.clientInfo = M2DataRow["CLIENTINFO"].ToString();
            this.m_M2.operatorJuminNo = M2DataRow["OPERATORJUMINNO"].ToString();
            this.m_M2.pgmType = M2DataRow["PGMTYPE"].ToString();
            this.m_M2.version = M2DataRow["VERSION"].ToString();
            this.m_M2.disRegPrson18 = M2DataRow["DISREGPRSON18"].ToString();
            this.m_M2.disRegPrson19 = M2DataRow["DISREGPRSON19"].ToString();
            this.m_M2.ntntType = M2DataRow["NTNTTYPE"].ToString();
            this.m_M2.mdcareHsptHsptzYn = M2DataRow["MDCAREHSPTHSPTZYN"].ToString();
            this.m_M2.mdcareHsptAdminSym = M2DataRow["MDCAREHSPTADMINSYM"].ToString();
            this.m_M2.disRegPrson20 = M2DataRow["DISREGPRSON20"].ToString();

            return this.m_M2;
        }

        private void GetUniqNo()
        {
            this.m_UniqNo = 0;

            object RetVal = DBService.ExecuteScalar(@"SELECT CONF_VAL FROM ADCONFDT WHERE SYSTEM_CD = 'NH' AND CONF_TYPE = 'NHIS_TEST' AND CONF_CD = 'KEY'").ToString();
            if (RetVal == null || RetVal.ToString() == "N")
            {
                System.Text.StringBuilder lsSQL = new System.Text.StringBuilder();
                lsSQL.Clear();
                lsSQL.AppendLine(" SELECT MAX(TO_NUMBER(MSGREQUESTKEY)) ");
                lsSQL.AppendLine("   FROM PANHM1MA                      ");

                RetVal = null;
                RetVal = DBService.ExecuteScalar(lsSQL.ToString());
                if (RetVal != null)
                    int.TryParse(RetVal.ToString(), out this.m_UniqNo);

                this.m_UniqNo++;
            }
            else
            {
                string sqltextLog = string.Empty;

                // 한번 취득하고 실패하면 한번 더 해보자,,
                if (!Lime.SqlPack.Procedure.PR_AD_READ_UNIQSQ("PANHM1MA", "M1", "N", "N", "N", "N", ref this.m_UniqNo))
                {
                    throw new Exception("자격조회 중 에러가 발생했습니다.(MSGREQUESTKEY취득 중 에러 발생)");
                }
                else
                {
                    while (true)
                    {
                        int cnt = DBService.ExecuteInteger(string.Format(@"SELECT COUNT(1) FROM PANHM1MA WHERE TO_NUMBER(MSGREQUESTKEY) = {0}", this.m_UniqNo));
                        if (cnt.Equals(0))
                            break;

                        sqltextLog = string.Format(@"
INSERT INTO ADERROLG (ERROR_DT, ERROR_TIMESTAMP, PROCESS_NM, ERROR_SEQ, ERROR_MSG, USER_CD, PC_IP, PC_NM, PC_USER)
              VALUES (   '{0}',           '{1}',       {2} ,      {3} ,     '{4}',   '{5}', '{6}', '{7}',   '{8}') ",
                        DateTime.Now.ToString("yyyyMMddHHmmss"), DateTime.Now.ToString("yyyyMMddHHmmss"), "0", "0", string.Format("[PANHM1MA MSGREQUESTKEY]{0}_{1}_{2}_{3}", this.m_UniqNo, this.PID, this.sujinjaJuminNo, this.sujinjaJuminNm),
                        DOPack.UserInfo.USER_CD, ClientEnvironment.IP, "M1_UP", string.Empty);
                        DBService.ExecuteNonQuery(sqltextLog);

                        Lime.SqlPack.Procedure.PR_AD_READ_UNIQSQ("PANHM1MA", "M1", "N", "N", "N", "N", ref this.m_UniqNo);
                    }
                }

                // ++++++++++++++++++++++++++++++++++++++++++++++++
                // 로그를 쌓자.
                // ++++++++++++++++++++++++++++++++++++++++++++++++
                sqltextLog = string.Format(@"
INSERT INTO ADERROLG (ERROR_DT, ERROR_TIMESTAMP, PROCESS_NM, ERROR_SEQ, ERROR_MSG, USER_CD, PC_IP, PC_NM, PC_USER)
              VALUES (   '{0}',           '{1}',       {2} ,      {3} ,     '{4}',   '{5}', '{6}', '{7}',   '{8}') ",
                DateTime.Now.ToString("yyyyMMddHHmmss"), DateTime.Now.ToString("yyyyMMddHHmmss"), "0", "0", string.Format("[PANHM1MA MSGREQUESTKEY]{0}_{1}_{2}_{3}", this.m_UniqNo, this.PID, this.sujinjaJuminNo, this.sujinjaJuminNm),
                DOPack.UserInfo.USER_CD, ClientEnvironment.IP, "M1", string.Empty);
                DBService.ExecuteNonQuery(sqltextLog);
            }
        }

        #endregion Method : Private Method

        #region Event : Event Process

        private void OnSelectTime_Tick(object sender, EventArgs e)
        {
            this.SelectM2();
        }

        #endregion Event : Event Process
    }
}