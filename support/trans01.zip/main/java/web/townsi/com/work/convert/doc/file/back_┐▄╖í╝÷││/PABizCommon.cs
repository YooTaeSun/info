using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Lime.Framework.Controls;
using SQL_NR = Lime.SqlPack.NR;
using SQL_PA = Lime.SqlPack.PA;

namespace Lime.Framework
{
    public class PABizCommon
    {
        public static bool RegistAndCancelDschPrar(DataRow datarow)
        {
            return RegistAndCacnelDschPrar(datarow, null);
        }

        public static bool RegistAndCacnelDschPrar(DataRow datarow, LxSpread spread)
        {

            string msg = string.Empty;
            try
            {
                string roomdvcd = string.Empty;      // 병실구분코드

                string pid = datarow["PID"].ToString();
                string ptnm = datarow["PT_NM"].ToString();
                string ptcmhsno = datarow["PT_CMHS_NO"].ToString();
                string admsdd = datarow["ADMS_DD"].ToString();
                string pclrmatr = datarow["PCLR_MATR"].ToString();
                string drgyn = datarow["DRG_YN"].ToString();
                string wardcd = datarow["WARD_CD"].ToString();
                string roomcd = datarow["ROOM_CD"].ToString();
                string dschdd = datarow["DSCH_DD"].ToString();
                string insntycd = datarow["INSN_TYCD"].ToString();
                string assttycd = datarow["ASST_TYCD"].ToString();
                string registcancelyn = string.Empty;
                string prardvcd = string.Empty;
                string oldprardvcd = string.Empty;
                string emropendd = string.Empty;
                int mainilnscnt = 0;
                string drgcheckyn = string.Empty;       // DRG 의료질 향상점검표
                string poayn = string.Empty;       // PODA구분
                string prardvnm = string.Empty;
                DialogResult dr = DialogResult.Cancel;

                prardvcd = datarow["DSCH_PRAR_DVCD"].ToString();
                oldprardvcd = datarow["OLD_DSCH_PRAR_DVCD"].ToString();

                if (oldprardvcd.Equals("0") && !prardvcd.Equals("0"))      // 퇴원예정 또는 가퇴원예정 선택시
                    registcancelyn = "R";
                else if (!oldprardvcd.Equals("0") && prardvcd.Equals("0")) // 없음 선택시
                    registcancelyn = "C";

                // 1. 입원접수변경관리에서 병실구분을 가져온다. 
                roomdvcd = DBService.ExecuteScalar(SQL_PA.Sql.SelectRoomDvcdFromPAIPCHMA(), pid
                                                                                          , ptcmhsno
                                                                                          , DateTimeService.NowDateNoneSeperatorString()).ToString();

                // 1. EMR시행일자 : 옵션
                emropendd = ConfigService.GetConfigValueString("%", "EMR", "OPEN_DATE", "19000101");

                // 1. 퇴원예정 DSCH_PRAR_DVCD
                if (!prardvcd.Equals("1") && !prardvcd.Equals("2") && !prardvcd.Equals("0"))
                    return false;

                // 1. 등록이면
                if (registcancelyn.Equals("R"))
                {
                    prardvnm = prardvcd.Equals("2") ? "가퇴원예정" : "퇴원예정";

                    // 1.1. 신생아(NORAMAL) <> '2' AND 모자동실 <> '8'
                    if (!roomdvcd.Equals("2") && !roomdvcd.Equals("8"))
                    {
                        // 1.1.0 간호초기평가지가 존재하는지 확인한다.
                        DataTable temp = new DataTable();
                        DBService.ExecuteDataTable(SQL_NR.Sql.SelectNRINEXIF(), ref temp, pid, ptcmhsno);
                        if (temp.Rows.Count.Equals(0))
                        {
                            msg = "간호초기평가지가 작성되지 않았습니다.";
                            if (spread == null)
                                LxMessage.ShowError(msg);
                            else
                                LxMessage.ShowFromSpread(spread, msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }

                        // 1.1.1 퇴원지시형처방이 존재하는 지 확인한다. 리턴
                        if (DBService.ExecuteInteger(SQL_PA.Sql.SelectDschDirectionPrsc(), pid
                                                                                        , ptcmhsno) < 1)
                        {
                            msg = "퇴원 지시 처방이 존재하지 않습니다.";
                            if (spread == null)
                                LxMessage.ShowError(msg);
                            else
                                LxMessage.ShowFromSpread(spread, msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                        // 1.2.1 상병이 존재하는지 확인한다. 리턴
                        int count = DBService.ExecuteInteger(SQL_PA.Sql.SelectCountIsIlns(), pid, ptcmhsno);
                        if (count < 1)
                        {
                            msg = "재원 중 상병이 존재하지 않습니다. \r\n" +
                                    "상병을 등록하여 주시기 바랍니다.";
                            if (spread == null)
                                LxMessage.ShowError(msg);
                            else
                                LxMessage.ShowFromSpread(spread, msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                        // 1.3.1 주상병 존재하는지 확인한다. 주상병은 하나만 존재해야 한다.
                        mainilnscnt = DBService.ExecuteInteger(SQL_PA.Sql.SelectCountIsMainIlns(), pid, ptcmhsno);
                        if (mainilnscnt > 1)
                        {
                            msg = "주상병은 하나만 존재해야 합니다..";
                            if (spread == null)
                                LxMessage.ShowError(msg);
                            else
                                LxMessage.ShowFromSpread(spread, msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                        else if (mainilnscnt < 1)
                        {
                            msg = "주상병이 존재하지 않습니다.주상병을 등록하여 주시기 바랍니다..";
                            if (spread == null)
                                LxMessage.ShowError(msg);
                            else
                                LxMessage.ShowFromSpread(spread, msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }

                        // TODO : 1.4.1 미 등록된 챠트가 존재하는지 확인한다.
                    }
                    // 1.2. DRG여부가 'Y' 이면
                    if (drgyn.Equals("Y"))
                    {
                        // 1.2.1 DRG 질점검표가 존재하는지 확인, 상병에 POA구분이 존재하는지 확인한다.
                        if (DBService.ExecuteInteger(SQL_PA.Sql.SelectCountIsPADRGCMA(), pid
                                                                                        , ptcmhsno
                                                                                        , admsdd) < 1)
                        {
                            msg = "DRG 대상 환자입니다. \r\n" +
                                    "의료의 질 점검표가 누락되었습니다.";
                            if (spread == null)
                                LxMessage.ShowError(msg);
                            else
                                LxMessage.ShowFromSpread(spread, msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }

                        if (DBService.ExecuteInteger(SQL_PA.Sql.SelectCountIsPoa(), pid
                                                                                    , ptcmhsno) < 1)
                        {
                            msg = "DRG 대상 환자입니다. \r\n" +
                                    "상병 POA 구분이 누락되었습니다.";
                            if (spread == null)
                                LxMessage.ShowError(msg);
                            else
                                LxMessage.ShowFromSpread(spread, msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }

                        // TODO : 1.2.2 DRG관련 미등록챠트가 존재하는 지 확인한다.
                    }
                    // 1.3. 퇴원예정, 가퇴원예정, 퇴원여부 확인한후 진행여부를 확인한다. 
                    if (CheckDoingDschPrar(pid, ptcmhsno, wardcd, roomcd, dschdd, prardvcd, registcancelyn))
                    {
                        msg = ptnm + "[" + pid + "] 님의 " + prardvnm + "등록을 하시겠습니까?";

                        if (spread == null)
                        {
                            dr = LxMessage.ShowQuestion(msg);
                            if (dr.Equals(DialogResult.Yes))
                                return true;
                        }
                        else
                        {
                            dr = LxMessage.ShowFromSpread(spread, msg, "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (dr.Equals(DialogResult.Yes))
                                return true;
                        }

                        // TODO : 이하, 메시지 살리고 위에거 없애기 (메시지 표시되는데, [예]눌러도 리턴값이 캔슬이 되어서... 해결해야함)
                        //if (LxMessage.ShowQuestion(msg).Equals(DialogResult.Yes))
                        //    return true;
                    }
                }
                // 2. 취소이면
                else if (registcancelyn.Equals("C"))
                {
                    prardvnm = oldprardvcd.Equals("2") ? "가퇴원예정" : "퇴원예정";

                    // 1.3. 퇴원예정, 가퇴원예정, 퇴원여부 확인한후 진행여부를 확인한다. 
                    if (CheckDoingDschPrar(pid, ptcmhsno, wardcd, roomcd, dschdd, oldprardvcd, registcancelyn))
                    {
                        msg = ptnm + "[" + pid + "] 님의 " + prardvnm + "등록을 취소 하시겠습니까?";
                        //DialogResult dr = MessageBox.Show(msg, "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        //if (dr.Equals(DialogResult.Yes))
                        //    return true;

                        if (spread == null)
                        {
                            dr = LxMessage.ShowQuestion(msg);
                            if (dr.Equals(DialogResult.Yes))
                                return true;
                        }
                        else
                        {
                            dr = LxMessage.ShowFromSpread(spread, msg, "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (dr.Equals(DialogResult.Yes))
                                return true;
                        }

                        // TODO : 이하, 메시지 살리고 위에거 없애기 (메시지 표시되는데, [예]눌러도 리턴값이 캔슬이 되어서... 해결해야함)
                        //if (LxMessage.ShowQuestion(msg).Equals(DialogResult.Yes))
                        //    return true;
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                DBService.RollbackTransaction();
                LogService.ErrorLog(ex);
                msg = "퇴원요청 등록 또는 취소 작업 중 오류를 발생했습니다.\r\n" +
                      "Method : RegistAndCancelDschRqst \r\n" +
                      "오류 메시지 : " + ex.Message;
                if (spread == null)
                    LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                    LxMessage.ShowFromSpread(spread, msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }


        /// <summary>
        /// 퇴원예정, 가퇴원예정 등록 및 취소를 할 수 있는지 확인한다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="wardcd"></param>
        /// <param name="roomcd"></param>
        /// <param name="dschdd">퇴원일자</param>
        /// <param name="prardvcd">퇴원예정, 가퇴원예정, 퇴실등록 구분코드</param>
        /// <param name="registcancel">예정등록여부</param>
        /// <returns></returns>
        public static bool CheckDoingDschPrar(string pid, string ptcmhsno, string wardcd, string roomcd, string dschdd, string prardvcd, string registcancel)
        {
            try
            {
                string msg = string.Empty;
                string dschprardvcd = string.Empty;         // 퇴원예정구분  "1":퇴원예정, "2":가퇴원예정, "0" : 해당없음.
                string sthsdschdvcd = string.Empty;         // 재원퇴원구분
                string revwstatdvcd = string.Empty;         // 심사상태구분코드
                string rcptstatdvcd = string.Empty;         // 퇴원수납구분코드

                if (!CheckRevwRcptStatDvcd(pid, ptcmhsno, dschdd, ref revwstatdvcd, ref rcptstatdvcd))
                    return false;

                DataTable dt = new DataTable();
                if (DBService.ExecuteDataTable(SQL_PA.Sql.SelectPAIPATRT(), ref dt, "PT_CMHS_NO"
                                                                                 , pid
                                                                                 , ptcmhsno))
                {
                    if (dt.Rows.Count > 0)
                    {
                        DataRow row = dt.Rows[0];
                        dschprardvcd = row["DSCH_PRAR_DVCD"].ToString();
                        sthsdschdvcd = row["STHS_DSCH_DVCD"].ToString();
                        if (!row["WARD_CD"].ToString().Equals(wardcd)) return false;

                        switch (prardvcd)
                        {
                            case "1":
                                if (registcancel.Equals("R"))        // 퇴원예정등록시 체크할 사항
                                {
                                    if (dschprardvcd.Equals("2"))
                                    {
                                        msg = "가퇴원예정으로 등록되어 있습니다. 가퇴원예정을 취소하시기 바랍니다.";
                                        LxMessage.ShowError(msg);
                                        return false;
                                    }

                                    if (sthsdschdvcd.Equals("T"))
                                    {
                                        msg = "퇴원 처리 되었습니다. 퇴원예정등록을 할 수 없습니다.";
                                        LxMessage.ShowError(msg);
                                        return false;
                                    }
                                }
                                else if (registcancel.Equals("C"))  // 퇴원예정취소시 체크할 사항
                                {
                                    if (sthsdschdvcd.Equals("T"))
                                    {
                                        msg = "퇴원 처리 되었습니다. 퇴원예정을 취소 할 수 없습니다.";
                                        LxMessage.ShowError(msg);
                                        return false;
                                    }

                                    if (rcptstatdvcd.Equals("Y"))
                                    {
                                        msg = "퇴원 수납 처리 되었습니다. 퇴원예정을 취소 할 수 없습니다.";
                                        LxMessage.ShowError(msg);
                                        return false;
                                    }

                                    //if (revwstatdvcd.Equals("J") || revwstatdvcd.Equals("Y"))
                                    if (revwstatdvcd.Equals("Y"))
                                    {
                                        msg = "심사중이거나 심사완료 되었습니다. 퇴원예정을 취소 할 수 없습니다.";
                                        LxMessage.ShowError(msg);
                                        return false;
                                    }

                                    if (dschprardvcd.Equals("2"))
                                    {
                                        msg = "가퇴원예정으로 등록 되어 있습니다. 가퇴원예정을 취소하시기 바랍니다.";
                                        LxMessage.ShowError(msg);
                                        return false;
                                    }

                                }
                                break;
                            case "2":

                                if (registcancel.Equals("R"))        // 가퇴원예정등록시 체크할 사항
                                {
                                    if (dschprardvcd.Equals("1"))
                                    {
                                        msg = "퇴원예정으로 등록되어 있습니다. 퇴원예정을 취소하시기 바랍니다.";
                                        LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        return false;
                                    }

                                    if (sthsdschdvcd.Equals("T"))
                                    {
                                        msg = "퇴원 처리 되었습니다. 가퇴원예정등록을 할 수 없습니다.";
                                        LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        return false;
                                    }
                                }
                                else if (registcancel.Equals("C"))  // 가퇴원예정취소시 체크할 사항
                                {
                                    if (sthsdschdvcd.Equals("T"))
                                    {
                                        msg = "퇴원 처리 되었습니다. 가퇴원예정을 취소 할 수 없습니다.";
                                        LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        return false;
                                    }

                                    //if (revwstatdvcd.Equals("J") || revwstatdvcd.Equals("Y"))
                                    if (revwstatdvcd.Equals("Y"))
                                    {
                                        msg = "심사중이거나 심사완료 되었습니다. 퇴원예정을 취소 할 수 없습니다.";
                                        LxMessage.ShowError(msg);
                                        return false;
                                    }
                                }
                                break;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return false;
            }
            return true;
        }

        /// <summary>
        /// 심사상태구분, 수납상태구분을 조회한다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        /// <param name="dschdd">퇴원일자</param>
        /// <param name="revwstatdvcd">심사상태구분코드</param>
        /// <param name="rcptstatdvcd">수납상태구분코드/param>
        /// <returns></returns>
        public static bool CheckRevwRcptStatDvcd(string pid, string ptcmhsno, string dschdd, ref string revwstatdvcd, ref string rcptstatdvcd)
        {
            string msg = string.Empty;
            try
            {
                DataTable dt = new DataTable();
                if (DBService.ExecuteDataTable(SQL_PA.Sql.SelectRevwRcptStatDvcdOfPAAREBMA(), ref dt, pid
                                                                                                  , ptcmhsno
                                                                                                  , dschdd))
                {
                    if (dt.Rows.Count > 0)
                    {
                        DataRow row = dt.Rows[0];
                        revwstatdvcd = row["REVW_STAT_DVCD"].ToString();
                        rcptstatdvcd = row["RCPT_STAT_DVCD"].ToString();
                    }
                    return true;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                msg = "심사상태 수납상택 조회 중 오류를 발생했습니다.\r\n" +
                      "Method : CheckRevwRcptStatDvcd \r\n" +
                      "오류 메시지 : " + ex.Message;
                LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return false;
        }

        public static int CheckSamePatientNameInWard(string pid, string pt_nm, string ward_cd, string aply_dd)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(pid) || string.IsNullOrWhiteSpace(pt_nm) || string.IsNullOrWhiteSpace(ward_cd) || string.IsNullOrWhiteSpace(aply_dd))
                    return 0;

                DataTable dt = new DataTable();

                if (!DBService.ExecuteDataTable(SqlPack.PA.Sql.SelectSpDyIPat(pid, pt_nm, ward_cd, aply_dd), ref dt))
                    throw new Exception(string.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));

                return dt == null ? 0 : dt.Rows.Count;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                return -1;
            }
        }

        public static bool ResultSamePatientNameInWard(string pt_nm, string ward_cd, string aply_dd, ref string msg)
        {
            try
            {
                DataTable dt = new DataTable();

                if (!DBService.ExecuteDataTable(SqlPack.PA.Sql.SelectSpDyIPat(), ref dt, aply_dd, ward_cd, pt_nm))
                    throw new Exception(string.Format("[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));

                StringBuilder sb = new StringBuilder();

                foreach (DataRow row in dt.Rows)
                {
                    sb.AppendFormat("{0}({1}/{2}/{3})\r\n", row["PT_SAME_NM"].ToString(), row["ROOM_CD"].ToString(), row["AGE"].ToString(), row["SEX_DVCD"].ToString());
                }

                msg = sb.ToString();

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                msg = string.Format("{0}\r\n{1}", ex.Message, ex.StackTrace);
                return false;
            }
        }

        private static DataTable m_BIHOSPMA = new DataTable();

        /// <summary>
        /// 기준일에 따른 요양기관기호를 찾는다.
        /// </summary>
        /// <param name="aply_dd">기준일</param>
        /// <param name="search_column">찾을 컬럼(기본으로 요양기관기호)</param>
        /// <returns></returns>
        public static string GetHPTL_RGNO_CD(string aply_dd, string search_column = "HPTL_RGNO_CD")
        {
            try
            {
                if (m_BIHOSPMA == null || m_BIHOSPMA.Rows.Count.Equals(0))
                {
                    m_BIHOSPMA.Reset();

                    if (!DBService.ExecuteDataTable("SELECT APLY_DD, HPTL_RGNO_CD, EDI_PRMT_NO, EDI_SEND_NO, INCS_DSGT_RGNO, INCS_SEND_ID FROM BIHOSPMA ORDER BY APLY_DD ", ref m_BIHOSPMA))
                        throw new Exception("병원정보를 읽는 중 오류가 발생했습니다.");
                }

                // 서울병원 외에는 1행만 있을거니까...
                if (m_BIHOSPMA.Rows.Count.Equals(1))
                    return m_BIHOSPMA.Rows[0][search_column].ToString();

                aply_dd = aply_dd.Length.Equals(6) ? $"{aply_dd}01" : aply_dd;

                // 기간에 맞는 aply_dd를 찾는다.
                var temp = m_BIHOSPMA.AsEnumerable().Where(r => DateTimeService.ConvertDateTime(r["APLY_DD"].ToString()) <= DateTimeService.ConvertDateTime(aply_dd))
                                                            .OrderByDescending(r => r["APLY_DD"].ToString())
                                                            .Select(r => r[search_column].ToString())
                                                            .FirstOrDefault();

                // 요양기관 기호 등을 넘겨준다.
                return temp;
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
                return string.Empty;
            }
        }
    }
}
