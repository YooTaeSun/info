package web.townsi.com.work.setting.biz;

import java.util.HashMap;

public interface SqlByMybaitisSamsBiz {
	public abstract HashMap makeSql(HashMap params) throws Exception;
}