//********************************************************************************
// Class 명 : clsCardCashPermitInfo
// 역    할 : 카드/현금 승인 처리하는 Class
// 작 성 자 : PGH
// 작 성 일 : 2017-09-27
//********************************************************************************
// 수정내역 : 
//********************************************************************************
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public class clsCardCashPermitInfo
    {
        #region Define : Member

        private string m_PID = String.Empty;    //환자등록번호                  VARCHAR2(10)
        private string m_RQST_DD = String.Empty;    //요청일자                     VARCHAR2(8)
        private int m_PRMT_SQNO = 0;               //승인일련번호                  NUMBER(3, 0)
        private string m_RCPT_OCRR_UNIQ_NO = String.Empty;    //수납발생고유번호               VARCHAR2(13)
        private string m_CCCS_OCRR_DVCD = String.Empty;    //신용카드현금발생구분코드         VARCHAR2(2)
        private int m_PT_CMHS_NO = 0;               //환자내원번호                  NUMBER(10, 0)
        private string m_CMPY_DD = String.Empty;    //정산일자                     VARCHAR2(8)
        private int m_RCPT_SQNO = 0;               //수납일련번호                  NUMBER(5, 0)
        private string m_BILL_NO = String.Empty;    //영수증번호                    VARCHAR2(13)
        private string m_CASH_CARD_DVCD = String.Empty;    //현금카드구분코드               VARCHAR2(2)
        private string m_PRMT_RQST_DVCD = String.Empty;    //승인요청구분코드               VARCHAR2(2)
        private string m_DEAL_DVCD = String.Empty;    //거래구분코드                  VARCHAR2(2)
        private string m_INTM_CNTS_CD = String.Empty;    //할부내용코드                  VARCHAR2(2)
        private int m_CASH_PRMT_AMT = 0;               //현금수납금액                  NUMBER(10, 0)
        private int m_BNAC_PRMT_AMT = 0;               //통장수납금액                  NUMBER(10, 0)
        private int m_CARD_PRMT_AMT = 0;               //카드수납금액                  NUMBER(10, 0)
        private string m_CARD_CASH_NO = String.Empty;    //카드현금영수번호               VARCHAR2(50)
        private string m_CARD_VALD_DD = String.Empty;    //카드유효일자                  VARCHAR2(8)
        private string m_CARD_CASH_PRMT_NO = String.Empty;    //카드현금승인번호               VARCHAR2(50)
        private string m_PRMT_DT = String.Empty;    //승인일시                     VARCHAR2(14)
        private string m_CARD_CO_CD = String.Empty;    //카드회사코드                  VARCHAR2(10)
        private string m_CNCL_YN = String.Empty;    //취소여부                     VARCHAR2(1)
        private string m_CNCL_ORIG_DEAL_DD = String.Empty;    //취소시원거래일자               VARCHAR2(8)
        private string m_CNCL_ORIG_PRMT_NO = String.Empty;    //취소시원거래승인번호            VARCHAR2(50)
        private string m_PRCH_CO_CD = String.Empty;    //매입회사사코드                 VARCHAR2(3)
        private string m_PRCH_CO_NM = String.Empty;    //매입회사사명                  VARCHAR2(20)
        private string m_ISUE_CO_CD = String.Empty;    //발급회사코드                  VARCHAR2(3)
        private string m_ISUE_CO_NM = String.Empty;    //발급회사명                    VARCHAR2(20)
        private string m_MSG_1 = String.Empty;    //메시지 첫째                   VARCHAR2(40)
        private string m_MSG_2 = String.Empty;    //메시지 둘째                   VARCHAR2(80)
        private string m_APP_CARD_BRCD_NO = String.Empty;    //앱카드바코드번호                VARCHAR2(8)
        private string m_ETC_USE_CNTS_1 = String.Empty;    //기타사용내용첫째                VARCHAR2(10)
        private string m_ETC_USE_CNTS_2 = String.Empty;    //기타사용내용둘째                VARCHAR2(10)
        private string m_ETC_USE_CNTS_3 = String.Empty;    //기타사용내용셋째                VARCHAR2(10)
        private string m_ETC_USE_CNTS_4 = String.Empty;    //기타사용내용넷째                VARCHAR2(10)
        private string m_ETC_USE_CNTS_5 = String.Empty;    //기타사용내용다섯째               VARCHAR2(10)
        private string m_RCPT_DD = String.Empty;    //수납일자                      VARCHAR2(8)
        private string m_RCPT_TIME = String.Empty;    //수납시간                      VARCHAR2(4)
        private string m_DLWT_IP_ADDR = String.Empty;    //처리IP주소                    VARCHAR2(10)
        private string m_RGST_DT = String.Empty;    //등록일시                      VARCHAR2(14)
        private string m_RGSTR_ID = String.Empty;    //등록자ID                      VARCHAR2(10)
        private int m_TOTAL_AMT = 0;               //승인할 총 금액
        private int m_CARD_AMT = 0;               //승인할 카드 금액
        private int m_CASH_AMT = 0;               //승인할 현금 영수증 금액
        private int m_BNAC_AMT = 0;               //승인할 통장 영수증 금액
        private bool m_SUCCESS = false;           //승인성공여부
        private string m_OLD_BILL_NO = string.Empty;    //영수증번호 - 취소할때 사용 : 해당영수증번호만 삭제할 수 있게 처리
        private string m_FORMNAME = string.Empty;
        private int m_AFFECTEDROWS = 0;               //DBService실행시 적용된 행의수

        private bool m_CheckBillNo = false;

        #endregion

        #region Property : Member Property

        public string PID { get { return m_PID; } set { m_PID = value; } }
        public string RQST_DD { get { return m_RQST_DD; } set { m_RQST_DD = value; } }
        public int PRMT_SQNO { get { return m_PRMT_SQNO; } set { m_PRMT_SQNO = value; } }
        public string RCPT_OCRR_UNIQ_NO { get { return m_RCPT_OCRR_UNIQ_NO; } set { m_RCPT_OCRR_UNIQ_NO = value; } }
        public string CCCS_OCRR_DVCD { get { return m_CCCS_OCRR_DVCD; } set { m_CCCS_OCRR_DVCD = value; } }
        public int PT_CMHS_NO { get { return m_PT_CMHS_NO; } set { m_PT_CMHS_NO = value; } }
        public string CMPY_DD { get { return m_CMPY_DD; } set { m_CMPY_DD = value; } }
        public int RCPT_SQNO { get { return m_RCPT_SQNO; } set { m_RCPT_SQNO = value; } }
        public string BILL_NO { get { return m_BILL_NO; } set { m_BILL_NO = value; } }
        public string CASH_CARD_DVCD { get { return m_CASH_CARD_DVCD; } set { m_CASH_CARD_DVCD = value; } }
        public string PRMT_RQST_DVCD { get { return m_PRMT_RQST_DVCD; } set { m_PRMT_RQST_DVCD = value; } }
        public string DEAL_DVCD { get { return m_DEAL_DVCD; } set { m_DEAL_DVCD = value; } }
        public string INTM_CNTS_CD { get { return m_INTM_CNTS_CD; } set { m_INTM_CNTS_CD = StringService.IsNvl(value, "00"); } }
        public int CASH_PRMT_AMT { get { return m_CASH_PRMT_AMT; } set { m_CASH_PRMT_AMT = value; } }
        public int BNAC_PRMT_AMT { get { return m_BNAC_PRMT_AMT; } set { m_BNAC_PRMT_AMT = value; } }
        public int CARD_PRMT_AMT { get { return m_CARD_PRMT_AMT; } set { m_CARD_PRMT_AMT = value; } }
        public string CARD_CASH_NO { get { return m_CARD_CASH_NO; } set { m_CARD_CASH_NO = value; } }
        public string CARD_VALD_DD { get { return m_CARD_VALD_DD; } set { m_CARD_VALD_DD = value; } }
        public string CARD_CASH_PRMT_NO { get { return m_CARD_CASH_PRMT_NO; } set { m_CARD_CASH_PRMT_NO = value; } }
        public string PRMT_DT { get { return m_PRMT_DT; } set { m_PRMT_DT = value; } }
        public string CARD_CO_CD { get { return m_CARD_CO_CD; } set { m_CARD_CO_CD = value; } }    //카드회사코드  
        public string CNCL_YN { get { return m_CNCL_YN; } set { m_CNCL_YN = value; } }    //취소여부                         VARCHAR2(1)
        public string CNCL_ORIG_DEAL_DD { get { return m_CNCL_ORIG_DEAL_DD; } set { m_CNCL_ORIG_DEAL_DD = value; } }    //취소시원거래일자                 VARCHAR2(8)
        public string CNCL_ORIG_PRMT_NO { get { return m_CNCL_ORIG_PRMT_NO; } set { m_CNCL_ORIG_PRMT_NO = value; } }    //취소시원거래승인번호             VARCHAR2(50)                   VARCHAR2(10)
        public string PRCH_CO_CD { get { return m_PRCH_CO_CD; } set { m_PRCH_CO_CD = value; } }    //매입회사사코드                   VARCHAR2(3)
        public string PRCH_CO_NM { get { return m_PRCH_CO_NM; } set { m_PRCH_CO_NM = value; } }    //매입회사사명                     VARCHAR2(20)
        public string ISUE_CO_CD { get { return m_ISUE_CO_CD; } set { m_ISUE_CO_CD = value; } }    //발급회사코드                     VARCHAR2(3)
        public string ISUE_CO_NM { get { return m_ISUE_CO_NM; } set { m_ISUE_CO_NM = value; } }    //발급회사명                       VARCHAR2(20)
        public string MSG_1 { get { return m_MSG_1; } set { m_MSG_1 = value; } }    //메시지 첫째                      VARCHAR2(40)
        public string MSG_2 { get { return m_MSG_2; } set { m_MSG_2 = value; } }    //메시지 둘째                      VARCHAR2(80)
        public string APP_CARD_BRCD_NO { get { return m_APP_CARD_BRCD_NO; } set { m_APP_CARD_BRCD_NO = value; } }    //앱카드바코드번호                 VARCHAR2(8)
        public string ETC_USE_CNTS_1 { get { return m_ETC_USE_CNTS_1; } set { m_ETC_USE_CNTS_1 = value; } }    //기타사용내용첫째                 VARCHAR2(10)
        public string ETC_USE_CNTS_2 { get { return m_ETC_USE_CNTS_2; } set { m_ETC_USE_CNTS_2 = value; } }    //기타사용내용둘째                 VARCHAR2(10)
        public string ETC_USE_CNTS_3 { get { return m_ETC_USE_CNTS_3; } set { m_ETC_USE_CNTS_3 = value; } }    //기타사용내용셋째                 VARCHAR2(10)
        public string ETC_USE_CNTS_4 { get { return m_ETC_USE_CNTS_4; } set { m_ETC_USE_CNTS_4 = value; } }    //기타사용내용넷째                 VARCHAR2(10)
        public string ETC_USE_CNTS_5 { get { return m_ETC_USE_CNTS_5; } set { m_ETC_USE_CNTS_5 = value; } }    //기타사용내용다섯째               VARCHAR2(10)
        public string RCPT_DD { get { return m_RCPT_DD; } set { m_RCPT_DD = value; } }
        public string RCPT_TIME { get { return m_RCPT_TIME; } set { m_RCPT_TIME = value; } }
        public string DLWT_IP_ADDR { get { return m_DLWT_IP_ADDR; } set { m_DLWT_IP_ADDR = ClientEnvironment.IP; } }
        public string RGST_DT { get { return m_RGST_DT; } set { m_RGST_DT = value; } }
        public string RGSTR_ID { get { return m_RGSTR_ID; } set { m_RGSTR_ID = value; } }
        public int TOTAL_AMT { get { return m_TOTAL_AMT; } set { m_TOTAL_AMT = value; } }
        public int CARD_AMT { get { return m_CARD_AMT; } set { m_CARD_AMT = value; } }
        public int CASH_AMT { get { return m_CASH_AMT; } set { m_CASH_AMT = value; } }
        public int BNAC_AMT { get { return m_BNAC_AMT; } set { m_BNAC_AMT = value; } }
        public bool SUCCESS { get { return m_SUCCESS; } set { m_SUCCESS = value; } }
        public string OLD_BILL_NO { get { return m_OLD_BILL_NO; } set { m_OLD_BILL_NO = value; } }
        public string FORMNAME { get { return m_FORMNAME; } set { m_FORMNAME = value; } }
        public int AFFECTEDROWS { get { return m_AFFECTEDROWS; } set { m_AFFECTEDROWS = value; } }
        public bool CheckBillNo { get { return m_CheckBillNo; } set { m_CheckBillNo = value; } }

        #endregion

        #region Construction

        public clsCardCashPermitInfo()
        {
            Clear();
        }
        #endregion 

        public void Clear()
        {
            m_PID = String.Empty;
            m_RQST_DD = String.Empty;
            m_PRMT_SQNO = 0;
            m_RCPT_OCRR_UNIQ_NO = String.Empty;
            m_CCCS_OCRR_DVCD = String.Empty;
            m_PT_CMHS_NO = 0;
            m_CMPY_DD = String.Empty;
            m_RCPT_SQNO = 0;
            m_BILL_NO = String.Empty;
            m_CASH_CARD_DVCD = String.Empty;
            m_PRMT_RQST_DVCD = String.Empty;
            m_DEAL_DVCD = String.Empty;
            m_INTM_CNTS_CD = String.Empty;
            m_CASH_PRMT_AMT = 0;
            m_BNAC_PRMT_AMT = 0;
            m_CARD_PRMT_AMT = 0;
            m_CARD_CASH_NO = String.Empty;
            m_CARD_VALD_DD = String.Empty;
            m_CARD_CASH_PRMT_NO = String.Empty;
            m_PRMT_DT = String.Empty;
            m_CARD_CO_CD = String.Empty;    //카드회사코드                     VARCHAR2(10)
            m_CNCL_YN = String.Empty;    //취소여부                         VARCHAR2(1)
            m_CNCL_ORIG_DEAL_DD = String.Empty;    //취소시원거래일자                 VARCHAR2(8)
            m_CNCL_ORIG_PRMT_NO = String.Empty;    //취소시원거래승인번호             VARCHAR2(50)
            m_PRCH_CO_CD = String.Empty;    //매입회사사코드                   VARCHAR2(3)
            m_PRCH_CO_NM = String.Empty;    //매입회사사명                     VARCHAR2(20)
            m_ISUE_CO_CD = String.Empty;    //발급회사코드                     VARCHAR2(3)
            m_ISUE_CO_NM = String.Empty;    //발급회사명                       VARCHAR2(20)
            m_MSG_1 = String.Empty;    //메시지 첫째                      VARCHAR2(40)
            m_MSG_2 = String.Empty;    //메시지 둘째                      VARCHAR2(80)
            m_APP_CARD_BRCD_NO = String.Empty;    //앱카드바코드번호                 VARCHAR2(8)
            m_ETC_USE_CNTS_1 = String.Empty;    //기타사용내용첫째                 VARCHAR2(10)
            m_ETC_USE_CNTS_2 = String.Empty;    //기타사용내용둘째                 VARCHAR2(10)
            m_ETC_USE_CNTS_3 = String.Empty;    //기타사용내용셋째                 VARCHAR2(10)
            m_ETC_USE_CNTS_4 = String.Empty;    //기타사용내용넷째                 VARCHAR2(10)
            m_ETC_USE_CNTS_5 = String.Empty;    //기타사용내용다섯째               VARCHAR2(10)
            m_RCPT_DD = String.Empty;
            m_RCPT_TIME = String.Empty;
            m_DLWT_IP_ADDR = String.Empty;
            m_RGST_DT = String.Empty;
            m_RGSTR_ID = String.Empty;
            m_TOTAL_AMT = 0;
            m_CARD_AMT = 0;
            m_CASH_AMT = 0;
            m_BNAC_AMT = 0;
            m_SUCCESS = false;
            m_FORMNAME = string.Empty;
            m_AFFECTEDROWS = 0;
            CheckBillNo = false;
        }

        public object Clone()
        {
            clsCardCashPermitInfo ccpi = new clsCardCashPermitInfo();

            ccpi.m_PID = m_PID;
            ccpi.m_RQST_DD = m_RQST_DD;
            ccpi.m_PRMT_SQNO = m_PRMT_SQNO;
            ccpi.m_RCPT_OCRR_UNIQ_NO = m_RCPT_OCRR_UNIQ_NO;
            ccpi.m_CCCS_OCRR_DVCD = m_CCCS_OCRR_DVCD;
            ccpi.m_PT_CMHS_NO = m_PT_CMHS_NO;
            ccpi.m_CMPY_DD = m_CMPY_DD;
            ccpi.m_RCPT_SQNO = m_RCPT_SQNO;
            ccpi.m_BILL_NO = m_BILL_NO;
            ccpi.m_CASH_CARD_DVCD = m_CASH_CARD_DVCD;
            ccpi.m_PRMT_RQST_DVCD = m_PRMT_RQST_DVCD;
            ccpi.m_DEAL_DVCD = m_DEAL_DVCD;
            ccpi.m_INTM_CNTS_CD = m_INTM_CNTS_CD;
            ccpi.m_CASH_PRMT_AMT = m_CASH_PRMT_AMT;
            ccpi.m_BNAC_PRMT_AMT = m_BNAC_PRMT_AMT;
            ccpi.m_CARD_PRMT_AMT = m_CARD_PRMT_AMT;
            ccpi.m_CARD_CASH_NO = m_CARD_CASH_NO;
            ccpi.m_CARD_VALD_DD = m_CARD_VALD_DD;
            ccpi.m_CARD_CASH_PRMT_NO = m_CARD_CASH_PRMT_NO;
            ccpi.m_PRMT_DT = m_PRMT_DT;
            ccpi.m_CARD_CO_CD = m_CARD_CO_CD;
            ccpi.m_RCPT_DD = m_RCPT_DD;
            ccpi.m_RCPT_TIME = m_RCPT_TIME;
            ccpi.m_DLWT_IP_ADDR = m_DLWT_IP_ADDR;
            ccpi.m_RGST_DT = m_RGST_DT;
            ccpi.m_RGSTR_ID = m_RGSTR_ID;
            ccpi.m_TOTAL_AMT = m_TOTAL_AMT;
            ccpi.m_CARD_AMT = m_CARD_AMT;
            ccpi.m_CASH_AMT = m_CASH_AMT;
            ccpi.m_BNAC_AMT = m_BNAC_AMT;

            return ccpi;
        }

        #region Method : SaveData Method

        /// <summary>
        /// 승인내역을 발생한다.
        /// </summary>        
        public void InsertPACAPEMA()
        {
            try
            {
                if (!DBService.ExecuteNonQuery(SQL.PA.BaseSql.Insert.PACAPEMA(), this.PID
                                                                               , this.RQST_DD
                                                                               , this.PRMT_SQNO.ToString()
                                                                               , this.RCPT_OCRR_UNIQ_NO
                                                                               , this.CCCS_OCRR_DVCD
                                                                               , this.PT_CMHS_NO.ToString()
                                                                               , this.CMPY_DD
                                                                               , this.RCPT_SQNO.ToString()
                                                                               , this.BILL_NO
                                                                               , this.CASH_CARD_DVCD
                                                                               , this.PRMT_RQST_DVCD
                                                                               , this.DEAL_DVCD
                                                                               , this.INTM_CNTS_CD
                                                                               , this.CASH_CARD_DVCD == "02" ? this.CASH_PRMT_AMT.ToString() : this.BNAC_PRMT_AMT.ToString()
                                                                               , this.CARD_PRMT_AMT.ToString()
                                                                               , this.CARD_CASH_NO
                                                                               , this.CARD_VALD_DD
                                                                               , this.CARD_CASH_PRMT_NO
                                                                               , this.PRMT_DT
                                                                               , this.CARD_CO_CD
                                                                               , this.CNCL_YN
                                                                               , this.CNCL_ORIG_DEAL_DD
                                                                               , this.CNCL_ORIG_PRMT_NO
                                                                               , this.PRCH_CO_CD
                                                                               , this.PRCH_CO_NM
                                                                               , this.ISUE_CO_CD
                                                                               , this.ISUE_CO_NM
                                                                               , this.MSG_1
                                                                               , this.MSG_2
                                                                               , this.APP_CARD_BRCD_NO
                                                                               , this.ETC_USE_CNTS_1
                                                                               , this.ETC_USE_CNTS_2
                                                                               , this.ETC_USE_CNTS_3
                                                                               , this.ETC_USE_CNTS_4
                                                                               , this.ETC_USE_CNTS_5
                                                                               , this.RCPT_DD
                                                                               , this.RCPT_TIME
                                                                               , ClientEnvironment.IP
                                                                               , DateTimeService.NowDateTimeNoneSeperatorString()
                                                                               , DOPack.UserInfo.USER_CD))
                    throw new Exception("카드/현금 승인내역 등록 저장 중 오류가 발생했습니다.\r\n [" + DBService.ErrorMessage + "]");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// 승인내역을 발생한다.
        /// </summary>
        /// <returns></returns>
        public void InsertNonPrmtPACAPEMA(string rqstdd, string prmtsqno)
        {
            try
            {
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertCanceNonPrmt(), this.PID
                                                                              , rqstdd
                                                                              , prmtsqno
                                                                              , this.RQST_DD
                                                                              , this.PRMT_SQNO.ToString()
                                                                              , this.RCPT_OCRR_UNIQ_NO
                                                                              , this.RCPT_SQNO.ToString()
                                                                              , this.BILL_NO
                                                                              , this.PRMT_RQST_DVCD
                                                                              , this.CNCL_YN
                                                                              , this.RCPT_DD
                                                                              , this.RCPT_TIME
                                                                              , ClientEnvironment.IP
                                                                              , DateTimeService.NowDateTimeNoneSeperatorString()
                                                                              , DOPack.UserInfo.USER_CD
                                                                              , this.ETC_USE_CNTS_2))
                    throw new Exception("카드/현금 미승인 취소 등록 저장 중 오류가 발생했습니다.\r\n[" + DBService.ErrorMessage + "]");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// 카드/현금 승인내역의 영수정보 변경한다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool UpdatePACAPEMA(ref string msg)
        {
            bool success = true;

            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePACAPEMAafterRcpt(this.PID, this.PT_CMHS_NO.ToString(), this.CMPY_DD, this.CCCS_OCRR_DVCD, this.CASH_CARD_DVCD
                                                                            , this.RCPT_OCRR_UNIQ_NO, this.RCPT_SQNO.ToString(), this.BILL_NO, this.RCPT_DD, this.RCPT_TIME
                                                                            , this.RGST_DT)))
            {
                success = false;
                msg = " 카드/현금 승인내역 변경 저장 중 오류가 발생했습니다. 확인하세요. \r\n [" + DBService.ErrorMessage + "]";
                DBService.RollbackTransaction();
            }

            if (this.CCCS_OCRR_DVCD != "J")
                return success;

            if (DBService.AffectedRows > 1)
            {
                // 이렇게 하면 안되는데...ㅡㅡ;;;;
                string sqltext = SQL.PA.Sql.UpdatePACAPEMA_DupData(this.PID, this.RCPT_OCRR_UNIQ_NO, ClientService.IP);

                if (!DBService.ExecuteNonQuery(sqltext))
                {
                    success = false;
                    msg = string.Format("카드/현금 승인내역 저장 중 에러가 발생했습니다.{0}", string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage));
                    DBService.RollbackTransaction();
                }
            }

            return success;
        }

        /// <summary>
        /// 카드/현금 승인취소내역 변경한다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool UpdatePACAPEMA_CancelAmt(ref string msg)
        {
            bool success;
            success = true;
            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePACAPEMA_CancelAmt(), this.PID
                                                                                , this.RQST_DD
                                                                                , this.PRMT_SQNO.ToString()
                                                                                , (-1 * this.CARD_PRMT_AMT).ToString()
                                                                                , (-1 * this.CASH_PRMT_AMT).ToString()
                                                                                , this.PRMT_RQST_DVCD))
            {
                success = false;
                msg = " 카드/현금 승인취소내역 변경 저장 중 오류가 발생했습니다. 확인하세요. \r\n [" + DBService.ErrorMessage + "]";
                DBService.RollbackTransaction();
            }

            return success;
        }

        /// <summary>
        /// 카드/현금 승인취소내역 변경한다.
        /// </summary>
        /// <param name="cnclyn"></param>
        /// <param name="rqstdd"></param>
        /// <param name="prmtsqno"></param>
        public void UpdateCnclYnOfPACAPEMA(string cnclyn, string rqstdd, string prmtsqno)
        {
            try
            {
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdateCnclYnOfPACAPEMA()
                                         , this.PID
                                         , rqstdd
                                         , prmtsqno
                                         , cnclyn))
                    throw new Exception("신용카드/현금 원승인내역의 취소여부 변경 저장 중 오류가 발생했습니다. 확인하세요. \r\n [" + DBService.ErrorMessage + "]");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// 현금영수증 재승인
        /// </summary>
        public void UpdatePACAPEMA_CASH_RECEIPT()
        {
            try
            {
                //현금영수증 재발행을 안했으면 카드테이블에 원래 없었던 것이 지금은 안해도 발생되게 변경되었음
                //그래서 변경된 후에 현금영수증을 안한후에 재승인을 하면 여기서 Update하고 끝난다.
                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePACAPEMA_CASH_RECEIPT(this.PID, this.PT_CMHS_NO.ToString(), this.CMPY_DD, this.CCCS_OCRR_DVCD, this.BILL_NO
                                                                                    , this.CARD_CASH_NO, this.CARD_VALD_DD, this.CARD_CASH_PRMT_NO, this.PRMT_DT, this.CARD_CO_CD)))
                    throw new Exception("현금영수증 승인중 오류가 발생했습니다.\r\n [" + DBService.ErrorMessage + "]");

                //적용된 것이 없으면 변경되기 전에 현금영수증을 안했던 것들이므로, 예전 로직대로 흘러야 에러가 안난다.
                if (DBService.AffectedRows == 0)
                    InsertPACAPEMA();

                //적용된 행을 가지고 있는다. - Insert를 했으면 바깥에서 Update해주는 로직이 있기때문에 넘겨준다.
                this.m_AFFECTEDROWS = DBService.AffectedRows;
            }
            catch (Exception ex)
            {
                this.m_AFFECTEDROWS = 0;

                throw new Exception(ex.Message);
            }
        }

        #endregion

        #region Method : SelectData Method

        public DataTable GetPermitInfo()
        {
            DataTable dtPermit = new DataTable();

            try
            {
                if (this.CheckBillNo)
                {
                    if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectPACAPEMA_BillNo(), ref dtPermit, this.PID, this.PT_CMHS_NO.ToString(), this.CMPY_DD, this.BILL_NO))
                    {
                        return dtPermit;
                    }
                }
                else 
                {
                    if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectPACAPEMA(), ref dtPermit, this.PID, this.PT_CMHS_NO.ToString(), this.CMPY_DD))
                    {
                        return dtPermit;
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }

            return dtPermit;
        }

        #endregion

        /*
        #region Method : Card Permit PopUp

        /// <summary>
        /// 신용카드/현금영수증 승인 프로그램 실행.
        /// </summary>
        public bool PopUpCardCashPermit(ref string msg)
        {
            try
            {
                // VAN사 무승인 수기승인처리여부
                frmCardCashPermitP popPermit = new frmCardCashPermitP(this);
                popPermit.ShowDialog();

                if (popPermit.DialogResult == DialogResult.OK)
                {
                    m_SUCCESS = true;
                }
                else
                {
                    this.Clear();
                    m_SUCCESS = false;
                }

                popPermit.Dispose();
                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                msg = "[clsCardCashPermitinfo -> PopUpCardCashPermit]" + ex.Message;
                return false;
            }
        }

        /// <summary>
        /// 신용카드/현금영수증 승인 프로그램 실행.
        /// </summary>
        public bool PopUpCardCashPermit(string prmtdvcd, BaseMDI mdi, ref string msg)
        {
            try
            {
                // VAN사 무승인 수기승인처리여부
                frmCardCashPermitP popPermit = new frmCardCashPermitP(this, prmtdvcd);
                popPermit.BaseMDI = mdi;
                popPermit.ShowDialog();

                if (popPermit.DialogResult == DialogResult.OK)
                {
                    m_SUCCESS = true;
                }
                else
                {
                    this.Clear();
                    m_SUCCESS = false;
                }

                popPermit.Dispose();
                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                msg = "[clsCardCashPermitinfo -> PopUpCardCashPermit]" + ex.Message;
                return false;
            }
        }

        #endregion
        */
    }
}
