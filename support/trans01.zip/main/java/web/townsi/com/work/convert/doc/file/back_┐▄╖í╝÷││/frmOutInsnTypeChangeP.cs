//****************************************************
// Class 명 : frmOutInsnTypeChangeP
// 역    할 : 내역변경
// 작 성 자 : 박계훈
// 작 성 일 : 2017-10-23
//****************************************************
using System;
using System.Data;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.BusinessService;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public partial class frmOutInsnTypeChangeP : BasePopUp
    {
        #region Define : Member Property

        private string m_Pid = string.Empty; public string Pid { get { return m_Pid; } }
        private int m_PtCmhsNo = 0; public int PtCmhsNo { get { return m_PtCmhsNo; } }
        private string m_MdcrDd = string.Empty; public string MdcrDd { get { return m_MdcrDd; } }
        private string m_ReBurn = string.Empty; public string ReBurn { get { return m_ReBurn; } }

        #endregion 

        #region Construction

        public frmOutInsnTypeChangeP(string pid, int ptcmhsno, bool readOnlyYn)
        {
            InitializeComponent();

            m_Pid = pid;
            m_PtCmhsNo = ptcmhsno;

            if (readOnlyYn)
                lxPanel2.Visible = false;
        }

        #endregion Construction

        #region Screen Load
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode)
                return;

            Initialize();
        }

        #endregion Screen Load

        #region Method : Initialize Method
        private void Initialize()
        {
            //접수정보UC로 PID 보내기.
            ucOrecTypeChange1.OnShowPop += ShowChoosePop;

            btnButtonList.ButtonClick += btnButtonList_ButtonClick;
            ucOrecTypeChange1.PatientSelected += (s, e) =>
            {
                if (e.SeletedUserControl.Equals("INSNTYCD") || e.SeletedUserControl.Equals("ASSTTYCD"))
                {
                    if (ucOrecTypeChange1.cboInsnTycd.Value != null && ucOrecTypeChange1.cboAsstTycd.Value != null)
                    {
                        // 2020-07-15 asct_rgno_cd 보험정보가 자보인 경우에는 asct_rgno_cd = '' 로 보낸다.
                        // ex)건보 => 자보로 변경시, asct_rgno_cd = '.'이었으므로 검색시에 asct_rgno_cd ='.'로만 보험내역을 조회해서 papinsif에 자보데이터가 있어도 못 찾음.
                        string asct_rgno_cd = ucOrecTypeChange1.cboInsnTycd.SelectedValue.Equals("41") ? string.Empty : ucOrecTypeChange1.OutRegInfo.ASCT_RGNO_CD;
                        SetInsuranceInfo(asct_rgno_cd);
                    }
                }
            };
            ucPatRegistLst1.OnNewPatientSelect += ucPatRegistLst1_OnNewPatientSelect;
            ucPatRegistLst1.OnPatRegSelected += ucPatRegistLst1_OnPatRegSelected;
            ucInsuranceNew1.OnRltnComboChanged += SetRltnCombo;

            if (lxPanel2.Visible == false)
                SetPatientInfo(m_Pid, true);    //ReadOnly상태로 넘기자
            else
                SetPatientInfo(m_Pid, m_PtCmhsNo);
        }

        private void SetRltnCombo()
        {
            ucInsuranceNew1.SetRltnInfo(ucOrecTypeChange1.OutRegInfo.PT_NM
                                      , ucOrecTypeChange1.OutRegInfo.FRRN
                                      , ucOrecTypeChange1.OutRegInfo.SRRN
                                      , ucOrecTypeChange1.OutRegInfo.INSN_TYCD);
        }
        #endregion Method : Initialize Method

        #region Method : Private Method

        private void SelectData(string pid, int pt_cmhs_no = -1, bool selectPaopatrt = true)
        {
            try
            {
                if (selectPaopatrt)
                {
                    // 내원이력
                    ucPatRegistLst1.SelectData();

                    if (pt_cmhs_no.Equals(-1))
                    {
                        //변경 적용할 접수 정보를 표시한다.
                        if (ucPatRegistLst1.sprList.ActiveSheet.RowCount < 1)
                            throw new Exception("접수 내역이 존재하지 않습니다.");

                        int.TryParse(ucPatRegistLst1.sprList.GetValue(0, "PT_CMHS_NO").ToString(), out pt_cmhs_no);
                    }
                }

                ucOrecTypeChange1.OutRegInfo.Load(pid, pt_cmhs_no);   // 접수정보LOAD
                ucOrecTypeChange1.SetComboPaOregRt();               // 접수정보Control 초기화

                if (string.IsNullOrWhiteSpace(ucOrecTypeChange1.OutRegInfo.MDCR_DD))
                    return;

                ucOrecTypeChange1.SetDefaultValueToInputCtl();      // 접수정보를 표시한다.
                SetlblMessage(pid, pt_cmhs_no.ToString());

                SetInsuranceInfo(ucOrecTypeChange1.OutRegInfo.ASCT_RGNO_CD);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        /// <summary>
        /// 환자기본정보를 가져온다.
        /// 접수이력를 가져온다.
        /// 환자내원번호에 해당하는 row를 선택한다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        private void SetPatientInfo(string pid, int ptcmhsno)
        {
            try
            {
                this.PatientInfo.Clear();
                ucInsuranceNew1.ClearAll();

                this.Text = "내역변경";

                btnButtonList.ButtonItems.Clear();
                btnButtonList.ButtonItems.Add(ButtonType.Save, "내역변경");
                btnButtonList.ButtonItems.Add(ButtonType.Check, "자격조회");
                btnButtonList.ButtonItems.Add(ButtonType.Close, "닫 기");
                btnButtonList.Initialize();

                if (this.PatientInfo.Load(pid))
                {
                    txtPid.Text = this.PatientInfo.PID;
                    txtPtNm.Text = this.PatientInfo.PT_NM;
                    txtFrrn.Text = this.PatientInfo.FRRN;
                    txtSrrn.Text = this.PatientInfo.SRRN_ECPT;
                    txtSex.Text = this.PatientInfo.SEX_DVCD;
                    txtAge.Text = this.PatientInfo.AGE.ToString();

                    if (ucPatRegistLst1.PatientInfo.Load(pid))
                    {
                        this.SelectData(pid, ptcmhsno, true);

                        ucOrecTypeChange1.PatientInfo.AGE = this.PatientInfo.AGE;
                        ucOrecTypeChange1.PatientInfo.ADDR_CD = this.PatientInfo.ADDR_CD;
                    }
                }
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError("내역변경 환자접수정보 조회 중 에러가 발생했습니다.\r\n" + ex.Message + error);
            }
        }

        /// <summary>
        /// 환자기본정보를 가져온다.
        /// 접수이력를 가져온다.
        /// 환자내원번호에 해당하는 row를 선택한다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        private void SetPatientInfo(string pid, bool readonlyyn)
        {
            try
            {
                this.Text = "내원이력";

                btnButtonList.ButtonItems.Clear();
                btnButtonList.ButtonItems.Add(ButtonType.Close, "닫 기");
                btnButtonList.Initialize();

                int ptcmhsno = 0;
                this.PatientInfo.Clear();
                if (this.PatientInfo.Load(pid))
                {
                    txtPid.Text = this.PatientInfo.PID;
                    txtPtNm.Text = this.PatientInfo.PT_NM;
                    txtFrrn.Text = this.PatientInfo.FRRN;
                    txtSrrn.Text = this.PatientInfo.SRRN_ECPT;
                    txtSex.Text = this.PatientInfo.SEX_DVCD;
                    txtAge.Text = this.PatientInfo.AGE.ToString();

                    if (ucPatRegistLst1.PatientInfo.Load(pid))
                    {
                        //내원이력
                        ucPatRegistLst1.ReadOnly = true;

                        ucPatRegistLst1.isREGCHNG = true;

                        this.SelectData(pid, -1, true);

                        ucOrecTypeChange1.PatientInfo.AGE = this.PatientInfo.AGE;
                        ucOrecTypeChange1.PatientInfo.ADDR_CD = this.PatientInfo.ADDR_CD;
                        ucOrecTypeChange1.Enabled = false;

                        ucInsuranceNew1.Enabled = false;

                        btnButtonList.SetButtonEnable(ButtonType.Save, false);
                        btnButtonList.SetButtonEnable(ButtonType.Check, false);
                    }
                }
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError("내역변경 환자접수정보 조회 중 에러가 발생했습니다.\r\n" + ex.Message + error);
            }
        }

        void dteFromTo_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                string pid = ucPatRegistLst1.PatientInfo.PID;
                this.SelectData(pid, -1, true);
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        /// <summary>
        /// 보험정보를 가져온다.
        /// </summary>
        private void SetInsuranceInfo(string asct_rgno_cd)
        {
            string msg = string.Empty;
            if (!ucInsuranceNew1.SetLatestInfo(ucOrecTypeChange1.OutRegInfo.PID
                                            , ucOrecTypeChange1.OutRegInfo.INSN_TYCD
                                            , ucOrecTypeChange1.OutRegInfo.MDCR_DD
                                            , asct_rgno_cd
                                            , ref msg))
            {
                LxMessage.Show(msg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
        }

        /// <summary>
        /// 접수변경 
        /// </summary>
        private void SaveData()
        {
            try
            {
                string msg = "";
                int rtnValue;
                string hospopendd = "";

                string b_insn_tycd = string.Empty;
                string b_asst_tycd = string.Empty;
                string b_mdcr_dept_cd = string.Empty;
                string b_mdcr_dr_cd = string.Empty;

                string insn_tycd = string.Empty;
                string asst_tycd = string.Empty;
                string mdcr_dept_cd = string.Empty;
                string mdcr_dr_cd = string.Empty;

                string clrs_resn_cnts = string.Empty;
                string pacl_resn_dvcd = "RO"; // 외래청구간 사유 구분코드

                // 환자기본정보 입력 항목 확인 Validation
                // 환자접수정보 입력 항목 확인 Validation
                // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                // 입원된 내역이면 변경못하게 한다.
                // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                string sqltext = string.Format(@"
    SELECT ROW_STAT_DVCD
      FROM PAOPATRT 
     WHERE PID = '{0}'
       AND PT_CMHS_NO = {1} 
       AND ROW_STAT_DVCD IN ('A', 'I')
       AND RCPN_SQNO = (SELECT MAX(RCPN_SQNO)
                          FROM PAOPATRT
                         WHERE PID = '{0}'
                           AND PT_CMHS_NO = {1}
                           AND ROW_STAT_DVCD IN ('A', 'I')) ", ucOrecTypeChange1.OutRegInfo.PID, ucOrecTypeChange1.OutRegInfo.PT_CMHS_NO.ToString());

                string rowStatDvcd = DBService.ExecuteScalar(sqltext).ToString();

                if (rowStatDvcd == null || rowStatDvcd.Equals(string.Empty))
                {
                    LxMessage.ShowError("해당 내원이력의 접수정보를 취득하는 중 에러가 발생했습니다.\r\n" + DBService.ErrorMessage);
                    return;
                }

                if (rowStatDvcd.Equals("I"))
                {
                    LxMessage.ShowError("입원전환된 내역은 변경할 수 없습니다.\r\n" + DBService.ErrorMessage);
                    return;
                }
                // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

                // 진료의가 변경된 경우에 체크한다.
                if (!ucOrecTypeChange1.CheckRealMdcrDrCd())
                    return;

                //청구된 내역이면 진행못하게 한다.
                // 청구생성확인 = "Y" AND 청구생성에 상관없이 수정작업가능자가 아닌경우

                //if (ConfigService.GetConfigValueString("%", "CLAM_CRTN_CFRM_YN", "CLAM_CRTN_CFRM_YN") == "Y" &&
                //    ConfigService.GetConfigValueString("%", "NO_CLAM_CRTN_USER", "NO_CLAM_CRTN_USER") != DOPack.UserInfo.USER_CD)
                //{
                //    if (DBService.ExecuteScalar(SqlPack.Function.SelectFN_CL_PRC_CHKCLAMCRTN(), ucOrecTypeChange1.OutRegInfo.PID
                //                                                                              , ucOrecTypeChange1.OutRegInfo.PT_CMHS_NO.ToString()
                //                                                                              , msg).ToString() == "Y")
                //    {
                //        LxMessage.Show(" 해당 환자는 청구심사 중이거나 이미 청구가 완료되어 수정이 불가합니다. \r\n" +
                //                       " 보험 심사과에 문의하세요 !", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //        return;
                //    }
                //}

                // 청구 생성 되었는지 확인한다.
                bool trms_cmpl_yn = false;
                if (!clsPACommon.CheckCLAM_CRTN_YN(ucOrecTypeChange1.OutRegInfo.PID, ucOrecTypeChange1.OutRegInfo.PT_CMHS_NO.ToString(), ucOrecTypeChange1.OutRegInfo.RCPN_SQNO.ToString(), true, false, ref msg, ref trms_cmpl_yn))
                    return;

                rtnValue = ucOrecTypeChange1.ValidateOutRegInfo(ref msg);
                if (rtnValue == 1)
                {
                    throw new Exception("[ValidateOutRegInfo] " + msg);
                }
                // 환자보험정보 입력 항목 확인 Validation
                if (!ucInsuranceNew1.Validation(ucOrecTypeChange1.cboInsnTycd.SelectedValue, ucOrecTypeChange1.cboAsstTycd.SelectedValue, ucOrecTypeChange1.dteMdcrDd.DateTime.ToString("yyyyMMdd"), ref msg))
                    throw new Exception("[Validation]보험정보 저장 중 에러가 발생했습니다.\r\n" + msg);
                /*
                ucInsuranceInfo1.OutRegInfo.INSN_TYCD = ucOrecTypeChange1.cboInsnTycd.SelectedValue;
                ucInsuranceInfo1.OutRegInfo.ASST_TYCD = ucOrecTypeChange1.cboAsstTycd.SelectedValue;

                rtnValue = ucInsuranceInfo1.ValidatePatInsuranceInfo(ucInsuranceInfo1.OutRegInfo.INSN_TYCD, ucInsuranceInfo1.OutRegInfo.ASST_TYCD, ref msg);
                if (rtnValue == 1)
                {
                    throw new Exception("[ValidatePatInsuranceInfo] " + msg);
                }
                 * */
                // 시설유무 확인 시설환자의 경우 의료급여 1종에 해당 
                // 진료가능여부를 확인.(진료일정확인)
                // 병원 OPEN일자 확인
                hospopendd = ConfigService.GetConfigValueString("%", "OCS", "OPEN_DATE", "19000101").ToString();
                if (!string.IsNullOrWhiteSpace(hospopendd))
                {
                    if (DateTimeService.ConvertDateTime(ucOrecTypeChange1.OutRegInfo.MDCR_DD) < DateTimeService.ConvertDateTime(hospopendd))
                    {
                        LxMessage.Show("진료일자가 OCS 오픈일자보다 이전입니다. 접수변경을 할 수 없습니다.");
                        return;
                    }
                }
                /*
                // 수납된 처방 갯수 확인
                if (clsPACommon.ReturnPrscIssuedCnt(ucOrecTypeChange1.OutRegInfo.PID, ucOrecTypeChange1.OutRegInfo.PT_CMHS_NO, "Y", "AC") >= 1)
                {
                    // 보험유형, 보조유형 변경만 못하게 할것인지 확인?

                    LxMessage.Show("수납 완료된 처방이 존재합니다. 접수 변경을 할 수 없습니다.", "처방확인", MessageBoxIcon.Stop);
                    return;
                }
                // 수납에 상관없이 처방난 갯수 확인
                if (clsPACommon.ReturnPrscIssuedCnt(ucOrecTypeChange1.OutRegInfo.PID, ucOrecTypeChange1.OutRegInfo.PT_CMHS_NO, "N", "AC") >= 1)
                {
                    if (LxMessage.Show("등록된 처방이 존재합니다. 접수 변경을 하시겠습니까?.", "처방확인", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
                    {
                        return;
                    }
                }
                */
                // 진료마감(확인)

                // 보험정보저장

                if (trms_cmpl_yn)
                {
                    DataTable dtTmp = new DataTable();

                    if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOPATRT_KJH(), ref dtTmp
                        , ucOrecTypeChange1.OutRegInfo.PID
                        , ucOrecTypeChange1.OutRegInfo.PT_CMHS_NO.ToString()
                        , ucOrecTypeChange1.OutRegInfo.RCPN_SQNO.ToString()
                        ))
                    {
                    }

                    if (dtTmp != null && dtTmp.Rows.Count > 0)
                    {
                        b_insn_tycd = dtTmp.Rows[0]["INSN_TYCD"].ToString();
                        b_asst_tycd = dtTmp.Rows[0]["ASST_TYCD"].ToString();
                        b_mdcr_dept_cd = dtTmp.Rows[0]["MDCR_DEPT_CD"].ToString();
                        b_mdcr_dr_cd = dtTmp.Rows[0]["MDCR_DR_CD"].ToString();

                        popClRsResn pop = new popClRsResn();
                        pop.ShowDialog(this);
                        clrs_resn_cnts = pop.RESN_CNTS;
                        pop.Dispose();
                        pop = null;
                    }

                    dtTmp.Dispose();
                    dtTmp = null;
                }

                DBService.BeginTransaction();

                string key = string.Empty;
                if (!ucInsuranceNew1.SaveData(ucOrecTypeChange1.OutRegInfo.PID, ucOrecTypeChange1.cboInsnTycd.SelectedValue
                                            , ucOrecTypeChange1.cboAsstTycd.SelectedValue, ucOrecTypeChange1.dteMdcrDd.DateTime.ToString("yyyyMMdd")
                                            , ref key, ref msg))
                    throw new Exception($"보험정보 저장 중 에러가 발생했습니다.\r\n{msg}");

                // 청구생성요청정보를 다시 읽는다.
                DataTable dt = new DataTable();
                sqltext = $" SELECT T.* FROM PAOPATRT T WHERE PID = '{ucOrecTypeChange1.OutRegInfo.PID}' AND PT_CMHS_NO = {ucOrecTypeChange1.OutRegInfo.PT_CMHS_NO.ToString()} AND ROW_STAT_DVCD IN ('A', 'I') ";
                if (!DBService.ExecuteDataTable(sqltext, ref dt))
                    throw new Exception("최신 접수정보를 조회하는 중 에러가 발생했습니다.");

                if (dt.Rows.Count > 0)
                {
                    ucOrecTypeChange1.OutRegInfo.CLAM_CRTN_YN = dt.Rows[0]["CLAM_CRTN_YN"].ToString();
                    ucOrecTypeChange1.OutRegInfo.CLAM_REVW_YN = dt.Rows[0]["CLAM_REVW_YN"].ToString();
                    ucOrecTypeChange1.OutRegInfo.CLAM_CRTN_DEL_RESN = dt.Rows[0]["CLAM_CRTN_DEL_RESN"].ToString();
                }

                // 기존 접수정보는 취소 
                // 이전접수정보 로우상태구분코드 'C'로 변경
                if (!ucOrecTypeChange1.OutRegInfo.UpdateRowStatDvcdOfPaOpatRt("C", ref msg))
                {
                    throw new Exception("[UpdateRowStatDvcdOfPaOpatRt 기존 접수정보 취소 오류] " + msg);
                }

                // 접수정보저장
                // 외래접수등록정보 저장.
                string asct_rgno_cd = ucInsuranceNew1.GetASCT_RGNO_CD(ucOrecTypeChange1.cboInsnTycd.SelectedValue);
                if (!ucOrecTypeChange1.SetOutRegistrationInfo(txtPid.Text, asct_rgno_cd, key, "6", "A", ref msg))
                {
                    throw new Exception("[SetOutRegistrationInfo] " + msg);
                }

                // 진료의뢰회송 / 재난지원(코로나)
                if (!ucOrecTypeChange1.SavePATRTEIF_ETC56())
                {
                    throw new Exception("[SavePATRTEIF_ETC56] 저장 오류");
                }

                if (!ucOrecTypeChange1.OutRegInfo.InsertOutRegistrationInfo(ref msg))
                {
                    throw new Exception("[InsertOutRegistrationInfo 내역변경 접수정보 생성 오류] " + msg);
                }

                if (!ucOrecTypeChange1.OutRegInfo.UpdatePrscNotmOfPaOpaRt(ref msg))
                {
                    throw new Exception("[UpdatePrscNotmOfPaOpaRt] " + msg);
                }
                /*
                // 환자특이사항정보 저장
                ucOrecTypeChange1.SetPatientRemark();

                if (!ucOrecTypeChange1.PatRem.SavePatientRemark(ref msg))
                {
                    LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    return;
                }
                */
                // 자격조회에서 리턴한 정보를 중증질환관리에 등록한다.
                // 자격조회 프로그램 확인후 수정한다.

                // 보훈

                if (trms_cmpl_yn)
                {
                    // PACLRSMA Insert
                    if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertPACLRSMA()
                        , ucOrecTypeChange1.OutRegInfo.PID
                        , ucOrecTypeChange1.OutRegInfo.PT_CMHS_NO.ToString()
                        , ucOrecTypeChange1.OutRegInfo.RCPN_SQNO.ToString()
                        , ucOrecTypeChange1.OutRegInfo.MDCR_DD
                        , b_insn_tycd
                        , b_asst_tycd
                        , ucOrecTypeChange1.OutRegInfo.INSN_TYCD
                        , ucOrecTypeChange1.OutRegInfo.ASST_TYCD
                        , b_mdcr_dept_cd
                        , b_mdcr_dr_cd
                        , ucOrecTypeChange1.OutRegInfo.MDCR_DEPT_CD
                        , ucOrecTypeChange1.OutRegInfo.MDCR_DR_CD
                        , "N"
                        , ""
                        , ""
                        , clrs_resn_cnts
                        , pacl_resn_dvcd
                        , ""
                        , ""
                        , ""
                        , ""))
                        throw new Exception("InsertPACLRSMA [" + DBService.ErrorCode + "] " + DBService.ErrorMessage);
                }

                DBService.CommitTransaction();
                this.m_Pid = ucOrecTypeChange1.OutRegInfo.PID;
                this.m_PtCmhsNo = ucOrecTypeChange1.OutRegInfo.PT_CMHS_NO;
                this.m_MdcrDd = ucOrecTypeChange1.OutRegInfo.MDCR_DD;
                this.m_ReBurn = ucOrecTypeChange1.OutRegInfo.REBURN;
                this.DialogResult = DialogResult.OK;
                Close();
            }

            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                if (DBService.IsTransaction)
                    DBService.RollbackTransaction();
                
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError("내역변경 중 에러가 발생했습니다.\r\n" + ex.Message + error);
            }
        }

        private void ShowNhisMessage()
        {
            string msg = String.Empty;
            try
            {
                LxProgressMessage.Show("자격조회 중입니다.");
                Cursor = Cursors.WaitCursor;

                string pid = String.Empty;
                string ptnm = String.Empty;
                string rrno = String.Empty;
                string basisdate = String.Empty;
                string mothernm = String.Empty;
                string motherrrno = String.Empty;
                string inpnrrno = String.Empty;

                pid = txtPid.Text.Trim();
                ptnm = txtPtNm.Text.Trim();
                rrno = txtFrrn.Text + txtSrrn.Text;
                basisdate = ucOrecTypeChange1.dteMdcrDd.DateTime.ToString("yyyyMMdd");

                //  [ 이름 / 주민번호 누락체크 ]
                if (string.IsNullOrWhiteSpace(ptnm))
                {
                    if (StringService.IsNull(ptnm))
                        txtPid.Focus();
                    else
                        txtPtNm.Focus();

                    LxMessage.Show("환자성명이 누락되었습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                //  [ 신생아인경우 엄마번호로 자격조회 ]
                if (!Lime.BusinessControls.clsPACommon.ReturnMotherInfo(pid, ref mothernm, ref motherrrno, basisdate))
                {
                    throw new Exception(msg);
                }

                if (StringService.IsNotNull(mothernm) && StringService.IsNotNull(motherrrno))
                {
                    ptnm = mothernm;
                    rrno = motherrrno;
                }

                // [ 시설환자의 경우 보험정보의 주민번호를 가져온다 ]
                string sqltext = string.Format(@"SELECT FCLT_APLY_YN FROM PAOPATRT WHERE PID = '{0}' AND PT_CMHS_NO = {1} AND ROW_STAT_DVCD IN ('A', 'I') ", pid, m_PtCmhsNo.ToString());
                object retVal = DBService.ExecuteScalar(sqltext);
                if (retVal != null && retVal.ToString().Equals("Y"))
                {
                    if (!clsPACommon.GetInpnRrno(pid, (ucOrecTypeChange1.cboInsnTycd.Value == null ? "" : ucOrecTypeChange1.cboInsnTycd.Value.ToString()), basisdate, ref inpnrrno, ref msg))
                    {
                        throw new Exception(msg);
                    }

                    if (StringService.IsNotNull(inpnrrno) && !inpnrrno.Equals("NO"))
                    {
                        rrno = inpnrrno;
                    }
                }

                DOPack.PatientInfo.Load(txtPid.Text.Trim());

                this.Enabled = false;

                clsNhisM1 m1 = new clsNhisM1();
                if (!m1.SendM1(basisdate, false, ptnm, rrno))
                {
                    this.Enabled = true;
                    LxMessage.Show("자격 조회중 오류가 발생하였습니다.\r\n 오류메시지 : ", "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                m1.OnGetMessage2 += m1_OnGetMessage2;
                m1.OnSendProblem += m1_OnSendProblem; //장애가 생길 시(EX. 서버가 꺼져있는 등,,) m1에서 10초뒤 발생시키는 이벤트. YJS
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("자격 조회중 오류가 발생하였습니다.\r\n 오류메시지 : " + ex.Message, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                LxProgressMessage.Hide();
                Cursor = Cursors.Default;
            }
        }

        /// <summary>
        /// 일정시간 자격조회 팝업 안뜰 시 동작, YJS추가.
        /// </summary>
        private void m1_OnSendProblem()
        {
            this.Enabled = true;
            LxProgressMessage.Hide();
            Cursor = Cursors.Default;
            LxMessage.Show("자격조회 서버가 정상동작하지 않습니다.\r\n전산실에 문의바랍니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            return;
        }

        private void m1_OnGetMessage2(clsNhisM2 m2)
        {
            Lime.BusinessControls.popMessage2Response pop = null;

            try
            {
                pop = new Lime.BusinessControls.popMessage2Response();
                pop.SetM2Data(m2);
                pop.StartPosition = FormStartPosition.CenterParent;
                LxProgressMessage.Hide();
                Cursor = Cursors.Default;

                pop.ShowDialog(this);
                this.Enabled = true;

                if (pop.DialogResult == DialogResult.OK)
                {
                    AplyMessage2(m2);
                }

            }
            catch (Exception ex)
            {
                LxProgressMessage.Hide();
                Cursor = Cursors.Default;
                LogService.ErrorLog(ex);
                LxMessage.Show("자격 조회중 오류가 발생하였습니다.\r\n 오류메시지 : " + ex.Message, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (pop != null)
                    pop.Dispose();
            }
        }

        /// <summary>
        /// 자격정보를 적용한다.
        /// </summary>
        /// <param name="m2"></param>
        private void AplyMessage2(clsNhisM2 m2)
        {
            try
            {
                string insntycd = String.Empty;     // 보험유형
                string assttycd = String.Empty;     // 보조유형
                string pid = String.Empty;     // 환자번호
                string asctrgnocd = String.Empty;     // 조합기호코드
                string mdcrdd = String.Empty;     // 진료일자
                string ptnm = String.Empty;     // 환자성명
                string frrn = String.Empty;     // 주민등록번호앞자리
                string srrn = String.Empty;     // 주민등록번호뒷자리
                string payrestricdt = String.Empty;     // 급여제한일자
                string msg = String.Empty;
                switch (m2.qlfType)             // 자격여부
                {
                    case "7":
                        insntycd = "21";        // 의료급여1종
                        break;
                    case "8":
                        insntycd = "22";        // 의료급여2종
                        break;
                    default:
                        insntycd = "11";
                        break;
                }

                ucOrecTypeChange1.cboInsnTycd.SelectValue(insntycd);
                // 보조유형 가져오기
                clsPACommon.SetComboPA(ucOrecTypeChange1.cboAsstTycd, "ASST_TYCD", "LWRN_OVRL_CDNM", ucOrecTypeChange1.cboInsnTycd.Value.ToString().Trim(), ucOrecTypeChange1.dteMdcrDd.DateTimeValue.ToString("yyyyMMdd"));

                if (m2.protAdminSym.Equals("00000000000") || string.IsNullOrWhiteSpace(m2.protAdminSym))
                    ucOrecTypeChange1.txtAsctRgnoCd.Text = "."; // 조합기호
                else
                    ucOrecTypeChange1.txtAsctRgnoCd.Text = m2.protAdminSym; // 조합기호

                ucOrecTypeChange1.txtHlnsCrtfNo.Text = m2.asylmSym; // 증번호

                if (insntycd.Equals("11"))
                {
                    ucOrecTypeChange1.cboUschAplyCd.SelectValue("NO");     // 본인부담코드
                    //ucOregistInf11.txtHllfMncsBlce.Text = "0";          // 건생비잔액
                    //ucOregistInf11.txtMtwmYn.Text = "N";                // 산모여부
                    //ucOregistInf11.txtMtwmBlce.Text = "0";              // 산모잔액
                }
                else
                {
                    ucOrecTypeChange1.cboUschAplyCd.SelectValue(m2.sbrdnType);     // 본인부담코드
                    //ucOregistInf11.txtHllfMncsBlce.Text = m2.cfhcRem;           // 건생비잔액
                    //ucOregistInf11.txtMtwmBlce.Text = m2.pregRemAmt;            // 산모잔액
                    //if (long.Parse(string.IsNullOrWhiteSpace(m2.pregRemAmt) ? "0" : m2.pregRemAmt) > 0) //YJS 수정, 산모잔액이 NULL이라 파싱이 안되므로 수정.
                    //{
                    //    ucOregistInf11.txtMtwmYn.Text = "Y";                // 산모여부
                    //}
                    //else
                    //{
                    //    ucOregistInf11.txtMtwmYn.Text = "N";                // 산모여부
                    //}
                }

                // 차상위 유형보조
                if (StringService.IsNotNull(m2.disRegPrson3) && m2.disRegPrson3.Substring(0, 1).Equals("C"))            // 차상위1종
                {
                    ucOrecTypeChange1.cboAsstTycd.SelectValue("C"); // 보조유형
                }
                else if (StringService.IsNotNull(m2.disRegPrson3) && m2.disRegPrson3.Substring(0, 1).Equals("E"))       // 차상위2종
                {
                    if (m2.obstYn.Equals("Y"))
                    {
                        ucOrecTypeChange1.cboAsstTycd.SelectValue("F0"); // 보조유형
                    }
                    else
                    {
                        ucOrecTypeChange1.cboAsstTycd.SelectValue("E0"); // 보조유형
                    }
                }
                else if (StringService.IsNotNull(m2.disRegPrson3) && m2.disRegPrson3.Substring(0, 1).Equals("F"))       // 차상위2종
                {
                    ucOrecTypeChange1.cboAsstTycd.SelectValue("F0"); // 보조유형
                }

                // 보험정보 설정하기
                pid = txtPid.Text.Trim();
                insntycd = ucOrecTypeChange1.cboInsnTycd.Value == null ? "" : ucOrecTypeChange1.cboInsnTycd.Value.ToString();
                assttycd = ucOrecTypeChange1.cboAsstTycd.Value == null ? "" : ucOrecTypeChange1.cboAsstTycd.Value.ToString();
                asctrgnocd = ucOrecTypeChange1.txtAsctRgnoCd.Text;
                mdcrdd = ucOrecTypeChange1.dteMdcrDd.DateTime.ToString("yyyyMMdd");
                ptnm = txtPtNm.Text.Trim();
                frrn = txtFrrn.Text;
                srrn = txtSrrn.Text;

                // 중증정보에 등록한다.
                clsSevereDiseaseInfo clsSevDisInfo = new clsSevereDiseaseInfo();
                clsSevDisInfo.PID = pid;
                if (!clsSevDisInfo.SaveSevereDiseaseInfo(m2, ref msg))
                {
                    LxMessage.Show(msg, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                clsSevDisInfo.Clear(true);

                #region [ 보험정보 세팅 ]

                string rltnCode = "";//관계구분코드
                if (m2.sujinjaJuminNo.Equals(frrn + srrn))
                    rltnCode = "1";
                else
                    rltnCode = "6";

                if (insntycd.Equals("11"))
                {
                    ucInsuranceNew1.SetHLNS(pid, asctrgnocd, m2.asylmSym, m2.qlfChwidukDt, rltnCode, m2.sedaejuNm
                                          , m2.sujinjaJuminNo.Substring(0, 6), m2.sujinjaJuminNo.Substring(6, 7), mdcrdd, "29991231");
                    ucInsuranceNew1.tabInsnType.SelectedTab = ucInsuranceNew1.tabInsnType.Tabs[0];

                    ucInsuranceNew1.SetReadOnly(false, true, true, true);
                }

                if (insntycd.Equals("21") || insntycd.Equals("22"))
                {
                    ucInsuranceNew1.SetMDAD(pid, asctrgnocd, m2.asylmSym, m2.qlfChwidukDt, rltnCode, m2.sedaejuNm
                                          , m2.sujinjaJuminNo.Substring(0, 6), m2.sujinjaJuminNo.Substring(6, 7), mdcrdd, "29991231");
                    ucInsuranceNew1.tabInsnType.SelectedTab = ucInsuranceNew1.tabInsnType.Tabs[1];

                    ucInsuranceNew1.SetReadOnly(true, false, true, true);
                }

                ucInsuranceNew1.SelectPAPSDSMA(pid, insntycd.Length.Equals(2) ? insntycd.Substring(0, 1) : "1");

                #endregion [ 보험정보 세팅 ]

                if (StringService.IsNull(m2.payRestricDt))
                {
                    if (StringService.IsNull(m2.qlfChwidukDt))
                    {
                        payrestricdt = "0";             // 보험100% 적용을 위해서
                    }
                }

                if (StringService.IsNull(m2.sbrdnType) && StringService.IsNotNull(m2.payRestricDt) && DateTimeService.ConvertDateTime(m2.payRestricDt) <= DateTimeService.ConvertDateTime(mdcrdd))
                {
                    ucInsuranceNew1.mskEndHLNS.Text = m2.payRestricDt;   // 급여제한일자
                    ucOrecTypeChange1.cboAsstTycd.SelectValue("99");         // 보종유형변경 : 보험100%

                    // TODO : 보훈환자이면 무자격 설정한다.
                    if (ucOrecTypeChange1.OutRegInfo.VTRN_PT_YN.Equals("Y") && !ucOrecTypeChange1.OutRegInfo.VTRN_NON_QLFC_YN.Equals("Y"))
                    {
                        //ucOregistInf11.txtVtrnNonQlfcYn.Text = "Y";
                        //ucOregistInf11.OutRegInfo.VTRN_NON_QLFC_YN = "Y";
                    }

                    if (m2.qlfRestrictCd.Equals("01"))
                    {
                        ucOrecTypeChange1.cboPayQlfcDvcd.SelectValue("01");
                        LxMessage.ShowInformation(string.Format("{0}님은 무자격자입니다.", m2.sujinjaJuminNm));
                    }
                    else if (m2.qlfRestrictCd.Equals("02") || m2.qlfRestrictCd.Equals("03"))
                    {
                        ucOrecTypeChange1.cboPayQlfcDvcd.SelectValue("02");
                        LxMessage.ShowInformation(string.Format("{0}님은 급여제한자입니다.", m2.sujinjaJuminNm));
                    }
                    else if (m2.dprtYn.Equals("Y"))
                    {
                        ucOrecTypeChange1.cboPayQlfcDvcd.SelectValue("03");
                        LxMessage.ShowInformation(string.Format("{0}님은 출국자입니다.", m2.sujinjaJuminNm));
                    }
                    else
                    {
                        ucOrecTypeChange1.cboPayQlfcDvcd.SelectValue("0");
                    }
                }
                else if (m2.sbrdnType.Equals("M011"))     // 행려환자
                {
                    ucOrecTypeChange1.cboAsstTycd.SelectValue("80");
                }
                else if (m2.sbrdnType.Equals("M012"))    // 노숙인대상자
                {
                    ucOrecTypeChange1.cboAsstTycd.SelectValue("99");
                }
                else
                {
                    if (!ucOrecTypeChange1.cboAsstTycd.Value.ToString().Equals("60") && !ucOrecTypeChange1.cboAsstTycd.Value.ToString().Equals("C") &&
                       !ucOrecTypeChange1.cboAsstTycd.Value.ToString().Equals("E0") && !ucOrecTypeChange1.cboAsstTycd.Value.ToString().Equals("F0"))
                    {
                        ucOrecTypeChange1.cboAsstTycd.SelectValue("00");
                        // 의료급여2종 장애인 설정한다.
                        if (insntycd.Equals("22") && m2.obstYn.Equals("Y") && !ucOrecTypeChange1.OutRegInfo.VTRN_PT_YN.Equals("Y"))
                        {
                            ucOrecTypeChange1.cboAsstTycd.SelectValue("F");
                        }
                    }

                    if (m2.qlfRestrictCd.Equals("01"))
                    {
                        ucOrecTypeChange1.cboAsstTycd.SelectValue("99");
                        ucOrecTypeChange1.cboPayQlfcDvcd.SelectValue("01");
                        LxMessage.ShowInformation(string.Format("{0}님은 무자격자입니다.", m2.sujinjaJuminNm));
                    }
                    else if (m2.qlfRestrictCd.Equals("02") || m2.qlfRestrictCd.Equals("03"))
                    {
                        ucOrecTypeChange1.cboAsstTycd.SelectValue("99");
                        ucOrecTypeChange1.cboPayQlfcDvcd.SelectValue("02");
                        LxMessage.ShowInformation(string.Format("{0}님은 급여제한자입니다.", m2.sujinjaJuminNm));
                    }
                    else if (m2.dprtYn.Equals("Y"))
                    {
                        ucOrecTypeChange1.cboAsstTycd.SelectValue("99");
                        ucOrecTypeChange1.cboPayQlfcDvcd.SelectValue("03");
                        LxMessage.ShowInformation(string.Format("{0}님은 출국자입니다.", m2.sujinjaJuminNm));
                    }
                    else
                    {
                        ucOrecTypeChange1.cboPayQlfcDvcd.SelectValue("0");
                    }
                }

                clsPACommon.SetComboboxForeColor(ucOrecTypeChange1.cboPayQlfcDvcd, "01_PAYQLFCDVCD");

                #region [ 환자성명이 다른경우 공단자료로 변경 ]
                if (!ptnm.Equals(m2.sujinjaJuminNm))
                {
                    DialogResult dr = LxMessage.Show("환자기본정보의 환자명이 공단자료와 동일하지 않습니다.\r\n" +
                                                     "공단자료로 변경하시겠습니까?\r\n\r\n" +
                                                     "병원 환자성명 : " + ptnm + "\r\n공단 환자성명 : " + m2.sujinjaJuminNm,
                                                     "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dr == DialogResult.Yes)
                    {
                        txtPtNm.Text = m2.sujinjaJuminNm;
                    }
                }
                #endregion [ 환자성명이 다른경우 공단자료로 변경 ]

                #region [ 주민등록번호가 다른 경우 공단주민등록번호를 적용한다. ]
                if (!m2.sujinjaJuminNo.Equals(frrn + srrn))
                {
                    txtFrrn.Text = m2.sujinjaJuminNo.Substring(0, 5);
                    txtSrrn.Text = m2.sujinjaJuminNo.Substring(6, 7);
                    txtSex.Text = DBService.ExecuteScalar(SqlPack.Function.FN_PA_READ_SEXDVCD(), srrn).ToString();
                    txtAge.Text = DBService.ExecuteScalar(SqlPack.Function.FN_PA_READ_AGE(), frrn, srrn).ToString();
                }
                #endregion [ 주민등록번호가 다른 경우 공단주민등록번호를 적용한다. ]

                #region [ YJS 추후 추가 체크로직 2018-03-05, 외래접수/외래접수 변경에서만 필요]
                string insnTycdValue = ucOrecTypeChange1.cboInsnTycd.Value == null ? "" : ucOrecTypeChange1.cboInsnTycd.Value.ToString(); //보험정보 콤보박스
                string asstTycdValue = ucOrecTypeChange1.cboAsstTycd.Value == null ? "" : ucOrecTypeChange1.cboAsstTycd.Value.ToString(); //보조유형 콤보박스
                string owncode = ucOrecTypeChange1.cboUschAplyCd.Value == null ? "" : ucOrecTypeChange1.cboUschAplyCd.Value.ToString(); //본인코드
                string nwflag = ucOrecTypeChange1.cboCmhsDvcd.Value == null ? "" : ucOrecTypeChange1.cboCmhsDvcd.Value.ToString();      //내원구분
                string deptcode = ucOrecTypeChange1.cboMdcrDeptCd.Value == null ? "" : ucOrecTypeChange1.cboMdcrDeptCd.Value.ToString();//진료과목

                int uschrtn = 0; //본인부담여부코드 확인 메서드에서 받을 리턴 값.
                string uschmsg = ""; //본인부담여부코코드 확인 메서드에서 받을 에러메시지.
                string referror = ""; //에러메시지박스 헤더
                string uschaplycd = ""; //공단본인부담적용코드

                #region [ 차상위는 해당 유형보조를 넣어준다. ]
                if (insnTycdValue.Equals("11") && !asstTycdValue.Equals("99") && !asstTycdValue.Equals("D9") && !asstTycdValue.Equals("P9"))
                {
                    if (!string.IsNullOrWhiteSpace(m2.disRegPrson3))
                    {
                        if (m2.disRegPrson3.Substring(0, 1).Equals("C"))
                            ucOrecTypeChange1.cboAsstTycd.SelectValue("C");
                        else if (m2.disRegPrson3.Substring(0, 1).Equals("E"))
                            ucOrecTypeChange1.cboAsstTycd.SelectValue("E0");
                        else if (m2.disRegPrson3.Substring(0, 1).Equals("F"))
                            ucOrecTypeChange1.cboAsstTycd.SelectValue("F0");
                    }

                    if (DateTime.Today >= DateTimeService.ConvertDateTime("20190101") && int.Parse(txtAge.Text) < 1)
                        ucOrecTypeChange1.cboAsstTycd.SelectValue("W0");
                    else if (int.Parse(txtAge.Text) < 6)
                        ucOrecTypeChange1.cboAsstTycd.SelectValue("60");
                    else
                        ucOrecTypeChange1.cboAsstTycd.SelectValue("00");
                }
                #endregion [ 차상위는 해당 유형보조를 넣어준다. ]

                #region [ 자격조회 정보를 다시 읽어서 환자가 의료급여 환자인지 체크한다. ]
                if (insnTycdValue.Substring(0, 1).Equals("2"))
                {
                    string qlftype = "";
                    string sbrdntype = "";
                    string ykiho1 = "";
                    string ykiho2 = "";
                    string ykiho3 = "";
                    string ykiho4 = "";

                    DataTable dt = new DataTable();
                    if (DBService.ExecuteDataTable(SQL.PA.Sql.Check_PANHM2MA(), ref dt, m2.sujinjaJuminNo, m2.sujinjaJuminNm))
                    {
                        if (dt.Rows.Count > 0)
                        {
                            qlftype = dt.Rows[0]["QLFTYPE"].ToString();
                            sbrdntype = dt.Rows[0]["SBRDNTYPE"].ToString();
                            ykiho1 = dt.Rows[0]["YKIHO1"].ToString();
                            ykiho2 = dt.Rows[0]["YKIHO2"].ToString();
                            ykiho3 = dt.Rows[0]["YKIHO3"].ToString();
                            ykiho4 = dt.Rows[0]["YKIHO4"].ToString();

                            if (qlftype.Equals("N") || (!qlftype.Equals("7") && !qlftype.Equals("8")))
                            {
                                LxMessage.Show("현재 환자는 의료급여 자격자가 아닙니다.\r\n보험100% 또는 자격 재조회를 하여 처리하십시오.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                return;
                            }
                        }
                    }
                    else
                    {
                        LxMessage.Show("의료급여환자 체크 중 오류가 발생했습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        return;
                    }
                }
                #endregion [ 자격조회 정보를 다시 읽어서 환자가 의료급여 환자인지 체크한다. ]

                #region [ 본인부담여부코드가 제대로 입력이 되었는지 확인하자 ]
                uschrtn = clsPACommon.CheckUschAplyCd(txtPid.Text.Trim()
                                                    , deptcode
                                                    , ucOrecTypeChange1.dteMdcrDd.DateTime.ToString("yyyyMMdd")
                                                    , owncode
                                                    , nwflag
                                                    , m2.sbrdnType
                                                    , m2.ykiho1
                                                    , m2.ykiho2
                                                    , m2.ykiho3
                                                    , m2.ykiho4
                                                    , ref uschaplycd, ref referror, ref uschmsg);

                if (referror.Equals("ERROR"))
                {
                    // B009의 경우, B005로 할 것인지 B009로 할 것인지 선택받는다.
                    if (uschaplycd.Equals("B009"))
                    {
                        DialogResult dr = LxMessage.ShowQuestion(string.Format("현재 본인부담코드 : {0}\r\n가능 본인부담코드 : B005, B009 입니다.\r\n\r\n본인부담코드를 선택해주세요.\r\n   [    예    ] B005\r\n   [ 아니오 ] B009", owncode));
                        if (dr.Equals(DialogResult.Yes))
                        {
                            ucOrecTypeChange1.cboUschAplyCd.SelectValue("B005");
                        }
                        else
                        {
                            ucOrecTypeChange1.cboUschAplyCd.SelectValue("B009");
                        }
                    }
                    else
                    {
                        LxMessage.Show(string.Format("현재 본인부담코드 : {0}\r\n가능 본인부담코드 : {1} 입니다.\r\n본인부담코드가 변경됩니다.", owncode, uschaplycd));
                        ucOrecTypeChange1.cboUschAplyCd.SelectValue(uschaplycd);
                    }
                }
                #endregion [ 본인부담여부코드가 제대로 입력이 되었는지 확인하자 ]

                #endregion [ YJS 추후 추가 체크로직 2018-03-05, 외래접수/외래접수 변경에서만 필요]

                // +++++++++++++++++++++++++++++++++++++++++++++++++++++
                // 선택기관 세팅 (본인부담코드가 M001, M002 인 경우)
                // +++++++++++++++++++++++++++++++++++++++++++++++++++++
                if (StringService.IsNull(ucOrecTypeChange1.txtRefrInstno.Text) && (m2.sbrdnType.Equals("M001") || m2.sbrdnType.Equals("M002")) && (ucOrecTypeChange1.cboUschAplyCd.Value.ToString().Equals("B005") || ucOrecTypeChange1.cboUschAplyCd.Value.ToString().Equals("B006")))
                {
                    frmYkihoP pop = new frmYkihoP(pid);

                    if (!pop.ShowDialog(this).Equals(DialogResult.OK))
                    {
                        this.ActiveControl = ucOrecTypeChange1.txtRefrInstno;
                        LxMessage.Show("의뢰기관기호를 입력하여 주십시오!", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }

                    ucOrecTypeChange1.txtRefrInstno.Text = pop.YKIHO;
                    pop.Dispose();
                }
            }
            catch (Exception ex)
            {
                LxMessage.Show("환자의 자격을 적용하는 중 오류를 발생했습니다.\r\n" +
                               "Method : [AplyMessage2] \r\n" +
                               "오류 메시지 : " + ex.Message,
                               "확인",
                               MessageBoxButtons.OK,
                               MessageBoxIcon.Error);
            }
            DOPack.PatientInfo.Clear();
        }

        #endregion Method : Private Method

        #region Event : Event Process

        private void btnButtonList_ButtonClick(object sender, ButtonClickEventArgs e)
        {
            switch (e.ButtonType)
            {
                case ButtonType.Save:         // 내역변경저장
                    SaveData();
                    break;

                case ButtonType.Check:        // 자격조회
                    ShowNhisMessage();
                    break;

                case ButtonType.Close:
                    Close();
                    break;
            }
        }

        void ucPatRegistLst1_OnNewPatientSelect(string pid, int pt_cmhs_no)
        {
            try
            {
                this.SelectData(pid, pt_cmhs_no, false);

                ucOrecTypeChange1.PatientInfo.AGE = this.PatientInfo.AGE;
                ucOrecTypeChange1.PatientInfo.ADDR_CD = this.PatientInfo.ADDR_CD;
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        private void SetlblMessage(string pid, string ptcmhsno)
        {
            string message = string.Empty;
            lblMessage.Text = string.Empty;

            string sqltext = string.Format("SELECT RCPN_SQNO FROM PAOPATRT WHERE PID = '{0}' AND PT_CMHS_NO = '{1}' AND ROW_STAT_DVCD = 'A'", pid, ptcmhsno);
            string rcpnsqno = DBService.ExecuteScalar(sqltext).ToString();

            // 청구 생성 되었는지 확인한다.
            bool trms_cmpl_yn = false;
            if (!clsPACommon.CheckCLAM_CRTN_YN(pid, ptcmhsno, rcpnsqno, false, false, ref message, ref trms_cmpl_yn))
                lblMessage.Text = message;
        }

        private void ShowChoosePop()
        {
            frmYkihoP pop = new frmYkihoP(txtPid.Text);
            if (pop.ShowDialog(this) == DialogResult.OK)
            {
                ucOrecTypeChange1.txtRefrInstno.Text = pop.YKIHO;
            }
            pop.Dispose();
        }

        private void ucPatRegistLst1_OnPatRegSelected(string pid, string ptcmhsno, string mdcrdd)
        {
            this.m_Pid = pid;
            int.TryParse(ptcmhsno, out this.m_PtCmhsNo);
            this.m_MdcrDd = mdcrdd;
            this.DialogResult = DialogResult.OK;
            this.Close();

        }

        #endregion Event : Event Process
    }
}
