#region 어셈블리 Interop.HiraDur, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// C:\Lime\Lib\DUR\Interop.HiraDur.dll
#endregion

using System.Runtime.InteropServices;

namespace HiraDur
{
    [Guid("5D976593-FD79-4E44-BD91-3D1F9CED28CE")]
    [InterfaceType(2)]
    [TypeLibType(4224)]
    public interface IHIRAClient
    {
        [DispId(1)]
        int SyncDB(string yKiHo);
        [DispId(2)]
        int Check(object pPrescription, object pResultSet);
        [DispId(3)]
        int Report(object pPrescription, object pResultSet);
        [DispId(4)]
        int GetUnreportedResultsCount();
        [DispId(5)]
        int SendUnreportedResults();
        [DispId(6)]
        int Cancel(object pPrescription, string reasonCd, string reasonText, string MakerCode);
        [DispId(7)]
        int MprscCancel(string prscMake, string patJuminNo, string prscDate, string yKiHo, string mprscGrantNo, string reasonCd, string reasonText, string MakerCode);
        [DispId(8)]
        int MprscGrantNoUpdate(string patJuminNo, string prscData, string prscIssueAdmin, string mprscGrantNo, string MprscGrantNoUpdate);
        [DispId(9)]
        int MprscInformation(object pPrescription, string patJuminNo, string prscDate, string prscIssueAdmin, string prscGrantNo);
        [DispId(10)]
        string GetHelpMessage(int nDurCode);
        [DispId(11)]
        int Test(object pPrescription, object pResultSet);
        [DispId(14)]
        int ShowHelp(int nDurCode);
        [DispId(15)]
        int CheckOnlyFirstStep(object pPrescription, object pResultSet);
        [DispId(18)]
        int LoginCert();
        [DispId(19)]
        int SendReasonContent(string strRC);
        [DispId(20)]
        int GetReasonContent(string strRC, ref object pValRCs);
        [DispId(21)]
        int InsertExMedi(string strMediCode);
        [DispId(22)]
        int RequestAlimi();
        [DispId(23)]
        int CancelUnrptResultsMode();
        [DispId(24)]
        int GetUnrptResultsMode();
        [DispId(25)]
        int GetBizStdInfoURL();
        [DispId(26)]
        int SearchMediInfo(string strMediCode);
        [DispId(27)]
        int ParticularDiseaseCheck(object pPrescription, object pResultSet);
        [DispId(28)]
        int CheckMediHistory(string patJuminNo, string IssueAdmin, string LicenseNo);
        [DispId(29)]
        int CheckSWVersion(string yKiHo, string SimVersion);
        [DispId(30)]
        int SendGenericSubstitution(object pPrescription);
        [DispId(31)]
        int CheckAllergySeft(string patJuminNo, string IssueAdmin, string LicenseNo);
        [DispId(32)]
        int CheckMediHistoryEmy(string patJuminNo, string IssueAdmin, string LicenseNo);
        [DispId(33)]
        int CheckMediHistoryList(string patJuminNo, string IssueAdmin, string LicenseNo);
        [DispId(34)]
        int CheckIoHspDaily(object pPrescription);
        [DispId(35)]
        int InputRstReason(string patJumin, string LicenseNo, string medCdA, string gnlCdA, string medCdB, string gnlCdB, string exmKnd, string rsCd, string rsTxt, string insCd);
        [DispId(36)]
        int SearchStandInfo(string standParam);
        [DispId(37)]
        int SendBirthInfo(string yKiHo, string lcsNo, string ppdNm, string ppdBth, string nbyBth, string nbyBthHms, string nbySex, string membTpCd, string nbyOrd);

        [DispId(12)]
        string AdminCode { get; set; }
        [DispId(13)]
        string LastErrorMsg { get; }
        [DispId(16)]
        int CertLogined { get; }
        [DispId(17)]
        int SavedLocal { get; }
    }
}