package web.townsi.com.work.setting.biz;

import java.util.HashMap;

public interface SettingEntityBiz {
	public abstract HashMap<String, Object> makeEntity(HashMap paramHashMap) throws Exception;
	public abstract HashMap<String, Object> searchEntity(HashMap paramHashMap) throws Exception;
}