//********************************************************************************
// Class 명 : ucOregistInf1
// 역    할 : 외래 접수 정보를 입력하는 사용자 정의 컨트롤
// 작 성 자 : 박계훈
// 작 성 일 : 2017-08-18
//********************************************************************************
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Lime.BusinessControls;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public partial class ucOregistInf1 : BaseUserControl
    {
        #region Define Event
        public delegate void PatientSelectedEventHandler(object sender, SelectDataEventArgs e);
        public event PatientSelectedEventHandler PatientSelected;

        //부모화면에서 PID 받아 의뢰기관 팝업열기
        public delegate void ShowPop();
        public event ShowPop OnShowPop;

        private string m_DefaultSetting = "N";
        private string m_MdcrDd = String.Empty;
        #endregion

        #region Define Variable Member
        public DOPatientInfo m_PatientInfo = new DOPatientInfo();
        private clsOutRegistrationInfo m_OutRegInfo = new clsOutRegistrationInfo();
        private clsPatientRemark m_PatRem = new clsPatientRemark();

        private DOPatientInfo tempPatientInfo = new DOPatientInfo();

        public delegate void GetPatientRRNOEventHandler(ref string frrn, ref string srrn);
        public event GetPatientRRNOEventHandler GetPatientRRNO;

        private string m_OtherHospitalCd = "";
        private string m_OtherHospitalNm = "";

        #endregion

        #region Member Property
        public DOPatientInfo PatientInfo
        {
            get
            {
                return m_PatientInfo;
            }
            set
            {
                m_PatientInfo = value;
            }
        }

        public clsOutRegistrationInfo OutRegInfo
        {
            get
            {
                return m_OutRegInfo;
            }
            set
            {
                m_OutRegInfo = value;
            }
        }

        public clsPatientRemark PatRem
        {
            get { return m_PatRem; }
            set { m_PatRem = value; }
        }

        private bool m_MdcrDDTime_Modify = true;
        public bool MdcrDDTime_Modify
        {
            get { return m_MdcrDDTime_Modify; }
            set { m_MdcrDDTime_Modify = value; }
        }

        public string DisasterSuptCd { get { return cboDisasterSupt.SelectedValue; } }

        #endregion

        #region  Construction
        public ucOregistInf1()
        {
            InitializeComponent();

        }
        #endregion Construction

        #region Screen Load
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode)
                return;

            lblDisasterSupt.Enabled = cboDisasterSupt.Enabled = ConfigService.GetConfigValueBool("CL", "DISASTER_SUPT", "USE_YN", false);
            DataTable dt = OverallCodeList.GetDataList("DISASTER_SUPT");
            dt = dt.AsEnumerable().Where(r => !r["ETC_USE_CNTS_1"].ToString().Equals("I")).CopyToDataTable();
            cboDisasterSupt.SetComboItems(dt, "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.None, "NO");

            cboDisasterSupt.SelectionChangeCommitted += CboDisasterSupt_SelectionChangeCommitted;

            InitializeEvent();

            txtOtherHospital.ReadOnly = true;

            // 주/야 구분코드
            cboDYNT_DVCD_DRG.SetComboItems(OverallCodeList.GetDataList("DYNT_DVCD_DRG"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");

            SetComboPaOregRt();

            m_DefaultSetting = "Y";

            if (!m_MdcrDDTime_Modify)
            {
                dteMdcrDd.ReadOnly = true;
            }
        }

        private void CboDisasterSupt_SelectionChangeCommitted(object sender, EventArgs e)
        {
            // 의료급여환자이고 본인100이 아니면
            if (!cboInsnTycd.SelectedValue.Equals("21") && !cboInsnTycd.SelectedValue.Equals("22"))
                return;

            if (cboAsstTycd.SelectedValue.Equals("99"))
                return;

            if (cboDisasterSupt.SelectedValue.Equals("CVD19") && !cboUschAplyCd.SelectedValue.Equals("B099"))
            {
                LxMessage.ShowInformation("본인코드 [B099]로 자동 세팅됩니다.");
                cboUschAplyCd.SelectedValue = "B099";
            }
            else if (!cboDisasterSupt.SelectedValue.Equals("CVD19") && cboUschAplyCd.SelectedValue.Equals("B099"))
            {
                LxMessage.ShowInformation("본인코드 [NO]로 자동 세팅됩니다.");
                cboUschAplyCd.SelectedValue = "NO";
            }
        }

        #endregion Screen Load

        #region Method : Initialize

        private void InitializeEvent()
        {
            cboDcntRdiaCd.ValueChanged += Control_ValueChanged;
            txtDcntRdiaEmnm.KeyDown += txtDcntRdiaEmnm_KeyDown;
            txtRefrInstno.EditorButtonClick += txtRefrInstno_EditorButtonClick;
            txtDcntRdiaEmnm.EditorButtonClick += txtDcntRdiaEmnm_EditorButtonClick;
            txtPtPclrMatr.EditorButtonClick += txtPtPclrMatr_EditorButtonClick;
            txtOtherHospital.EditorButtonClick += txtOtherHospital_EditorButtonClick;

            cboMdcrDeptCd.Leave += Control_Leave; //진료과목
            mskMdcrTime.Leave += Control_Leave;
            dteMdcrDd.Leave += Control_Leave;
            txtDcntRdiaEmnm.Leave += Control_Leave;
            cboApntYn.ValueChanged += Control_ValueChanged;
            btnApntReg.Click += btnApntReg_Click;
            cboMdcrDeptCd.AfterCloseUp += cboMdcrDeptCd_AfterCloseUp;

            cboInsnTycd.TextChanged += cboInsnTycd_TextChanged;
            cboPayQlfcDvcd.TextChanged += cboPayQlfcDvcd_TextChanged;
            cboMcchCmptDvcd.TextChanged += cboMcchCmptDvcd_TextChanged;

            cboInsnTycd.SelectionChangeCommitted += CboInsnAsstTycd_SelectionChangeCommitted;
            cboAsstTycd.SelectionChangeCommitted += CboInsnAsstTycd_SelectionChangeCommitted;

            cboCmhsMotvDvcd.ValueChanged += cboCmhsMotvDvcd_ValueChanged;

            cboCmhsDvcd.ValueChanged += CboCmhsDvcd_ValueChanged;
        }

        #endregion Method : Initialize

        #region Method : Method Public
        /// <summary>
        /// 외래접수정보 CobmoBox Data Setting
        /// </summary>
        public void SetComboPaOregRt()
        {
            if (this.DesignMode)
                return;
            try
            {
                string defaultvalue = String.Empty;
                m_MdcrDd = DateTimeService.NowDateNoneSeperatorString();
                dteMdcrDd.DateTime = DateTimeService.ConvertDateTime(DateTime.Now.ToString("yyyyMMdd"));
                mskMdcrTime.Text = DateTimeService.TodayDateTimeNoneSeperatorString().Substring(8, 4);

                // 예약여부
                if (cboApntYn.Value == null)
                {
                    cboApntYn.SelectValue("N");
                    cboApntPathDvcd.Enabled = false; // 추가 YJS
                }

                // 예약구분코드
                if (cboApntPathDvcd.Value == null)
                    cboApntPathDvcd.SetComboItems(clsPACommon.GetDtBICDINDT("APNT_PATH_DVCD", "N", m_MdcrDd, ref defaultvalue), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.None, defaultvalue);
                // 진료과목코드
                // clsPACommon.SetComboPA(cboMdcrDeptCd, "DEPT_CD", "DEPT_HNM", "1", m_MdcrDd, "0010");
                if (cboMdcrDeptCd.Value == null)
                    clsPACommon.SetComboPA(cboMdcrDeptCd, "DEPT_CD", "DEPT_CDNM", "1", m_MdcrDd);
                // 진료의사
                if (cboMdcrDrCd.Value == null)
                    clsPACommon.SetComboPA(cboMdcrDrCd, "USER_CD", "USER_NM", (cboMdcrDeptCd.Value != null ? cboMdcrDeptCd.Value.ToString().Trim() : ""), m_MdcrDd);
                // 초재구분코드
                if (cboFrvsRvstDvcd.Value == null)
                    cboFrvsRvstDvcd.SetComboItems(clsPACommon.GetDtBICDINDT("FRVS_RVST_DVCD", "N", m_MdcrDd, ref defaultvalue), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.None, defaultvalue);
                //// 선택진료여부
                //if (cboSmcrYn.Value == null)
                //    cboSmcrYn.SelectValue("N");
                // 보험유형코드
                if (cboInsnTycd.Value == null)
                {
                    //cboInsnTycd.SetComboItems(clsPACommon.GetDtBICDINDT("INSN_TYCD", "N", m_MdcrDd, ref defaultvalue), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.None, defaultvalue);

                    SetCodeCombo(cboInsnTycd, OverallCodeList.GetDataList("INSN_TYCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", "11");
                }
                // 보조유형
                if (cboAsstTycd.Value == null)
                    clsPACommon.SetComboPA(cboAsstTycd, "ASST_TYCD", "LWRN_OVRL_CDNM", cboInsnTycd.Value.ToString().Trim(), m_MdcrDd, "00");
                // 진찰료산정구분코드
                if (cboMcchCmptDvcd.Value == null)
                    cboMcchCmptDvcd.SetComboItems(clsPACommon.GetDtBICDINDT("MCCH_CMPT_DVCD", "N", m_MdcrDd, ref defaultvalue), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.None, defaultvalue);
                // 내원구분코드
                if (cboCmhsDvcd.Value == null)
                    cboCmhsDvcd.SetComboItems(clsPACommon.GetDtBICDINDT("CMHS_DVCD", "N", m_MdcrDd, ref defaultvalue), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.None, defaultvalue);
                // 예외사유코드
                if (cboExcpResnCd.Value == null)
                {
                    //clsPACommon.SetComboPA(cboExcpResnCd, "EXCP_RESN_CD", "EXCP_RESN_CNTS", "1", m_MdcrDd, "NO");

                    DataTable dtExcp = new DataTable();
                    if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectBIEXCDMA_RESN_CD(), ref dtExcp, m_MdcrDd))
                    {
                        LxMessage.Show("예외사유코드 세팅 중 오류가 발생했습니다.\r\n확인 바랍니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                    else
                        SetCodeCombo(cboExcpResnCd, dtExcp, "EXCP_RESN_CD", "EXCP_RESN_CNTS", "NO");
                }
                // 본인부담코드 산정특례코드관리
                if (cboUschAplyCd.Value == null)
                    clsPACommon.SetComboPA(cboUschAplyCd, "CFSC_CD", "CFSC_CD_NM", "1", m_MdcrDd, "NO");
                // 급여자격구분코드
                if (cboPayQlfcDvcd.Value == null)
                    cboPayQlfcDvcd.SetComboItems(clsPACommon.GetDtBICDINDT("PAY_QLFC_DVCD", "N", m_MdcrDd, ref defaultvalue), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM", COMBO_ADD_ITEM_TYPE.None, defaultvalue);
                // 할인코드
                if (cboDcntRdiaCd.Value == null)
                {
                    clsPACommon.SetComboPA(cboDcntRdiaCd, "DCNT_CD", "DCNT_CDNM", "1", m_MdcrDd, "NO");
                    //txtDcntRdiaEmnm.ReadOnly = true;
                }

                // 내원경로구분코드
                if (cboCmhsMotvDvcd.Value == null)
                    cboCmhsMotvDvcd.SetComboItems(OverallCodeList.GetDataList("CMHS_MOTV_DVCD"), COMBO_ADD_ITEM_TYPE.AddNone, "01");

                // 협진여부
                if (cboCnstRefrYn.Value == null)
                    cboCnstRefrYn.SelectValue("N");

                // 재난 지원
                if (cboDisasterSupt.Items.Count > 0)
                    cboDisasterSupt.SelectedValue = "NO";

                SetDayNightCombobox();//주야 콤보박스 세팅.

            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show(ex.Message, "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 보험유형에 따른 보조유형 콤보박스 값 변경. YJS
        /// </summary>
        public void SetASST_TYCD()
        {
            try
            {
                if (cboInsnTycd.Value != null)
                {
                    OutRegInfo.INSN_TYCD = cboInsnTycd.Value.ToString();
                    // 보조유형 가져오기
                    clsPACommon.SetComboPA(cboAsstTycd, "ASST_TYCD", "LWRN_OVRL_CDNM", cboInsnTycd.Value.ToString().Trim(), m_MdcrDd, "00");


                    if (this.OutRegInfo.NEW_PID_YN.Equals("Y"))
                    {
                        OnPatientSelected("AGE");
                    }

                    if (OutRegInfo.INSN_TYCD.Equals("11"))
                    {
                        if (DateTime.Today >= DateTimeService.ConvertDateTime("20190101") && this.PatientInfo.AGE < 1)
                        {
                            OutRegInfo.ASST_TYCD = "W0";
                            cboAsstTycd.SelectValue("W0");

                            if (cboAsstTycd.SelectedIndex == -1)
                            {
                                LxMessage.ShowWarning("2019-01-01 이후, 유형보조에 [만1세미만]이 추가되었습니다.\r\nLime프로그램을 다시 실행해 주세요.");
                            }
                        }
                        else if (this.PatientInfo.AGE < 6)
                        {
                            OutRegInfo.ASST_TYCD = "60";
                            cboAsstTycd.SelectValue("60");
                        }
                    }

                    // 진찰료산정구분 세팅
                    SetcboMcchCmptDvcd();
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show(ex.Message, "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 진찰료산정구분을 세팅한다.
        /// </summary>
        private void SetcboMcchCmptDvcd()
        {
            // 접수
            if (StringService.IsNull(OutRegInfo.PT_CMHS_NO.ToString()))
            {
                // 당일 동일진료과, 보험유형으로 접수된 접수정보 확인해서 진찰료산정구분 설정
                if (DBService.ExecuteInteger(SQL.PA.Sql.SelectPAOPATRT_SAMEDEPT_COUNT(), OutRegInfo.PID
                                                                                       , OutRegInfo.MDCR_DD
                                                                                       , OutRegInfo.MDCR_DEPT_CD
                                                                                       , OutRegInfo.INSN_TYCD) > 0)
                {
                    cboMcchCmptDvcd.SelectValue("N");
                }
                else
                {
                    cboMcchCmptDvcd.SelectValue("Y");
                }
            }
            // 변경
            else
            {
                // 당일 동일진료과, 보험유형으로 접수된 접수정보 확인해서 진찰료산정구분 설정
                if (DBService.ExecuteInteger(SQL.PA.Sql.SelectPAOPATRT_SAMEDEPT_COUNT_Change(), OutRegInfo.PID
                                                                                       , OutRegInfo.MDCR_DD
                                                                                       , OutRegInfo.MDCR_DEPT_CD
                                                                                       , OutRegInfo.INSN_TYCD
                                                                                       , OutRegInfo.PT_CMHS_NO.ToString()) > 0)
                {
                    cboMcchCmptDvcd.SelectValue("N");
                }
                else
                {
                    cboMcchCmptDvcd.SelectValue("Y");
                }
            }
        }

        /// <summary>
        /// Control 초기화
        /// </summary>
        public void Clear()
        {
            try
            {
                m_OtherHospitalCd = "";
                m_OtherHospitalNm = "";
                txtOtherHospital.Text = "";

                txtAsctRgnoCd.Text = string.Empty;
                //btnApntYn.Clear();
                //btnMdcrDrCd.Clear();
                //btnRefrInstno.Clear();
                cboDcntRdiaCd.Clear();
                txtDcntRdiaEmno.Text = "";
                txtDcntRdiaEmnm.Text = "";
                txtDcntRdiaEmnm.ReadOnly = true;
                txtPtPclrMatr.Text = "";
                txtRefrInstno.Text = "";
                mskMdcrTime.Text = DateTimeService.TodayDateTimeNoneSeperatorString().Substring(8, 4);
                cboApntYn.Clear();
                cboApntPathDvcd.Clear();
                cboMdcrDeptCd.Clear();
                cboMdcrDrCd.Clear();
                cboFrvsRvstDvcd.Clear();
                //cboSmcrYn.Clear();
                cboInsnTycd.Clear();
                cboAsstTycd.Clear();
                cboMcchCmptDvcd.Clear();
                cboCmhsDvcd.Clear();
                cboExcpResnCd.Clear();
                cboUschAplyCd.Clear();
                cboFcltAplyYn.Clear();
                cboMtwmYn.Clear();
                cboPayQlfcDvcd.Clear();
                cboCnstRefrYn.Clear();
                dteMdcrDd.DateTime = DateTimeService.ConvertDateTime(DateTime.Now.ToString("yyyyMMdd"));
                cboCmhsMotvDvcd.Clear();
                OutRegInfo.Clear();
                PatientInfo.Clear();
                //lblApntPosYn.Text = ""; // 2018-05-30 현재 안쓰므로 주석
                //SetComboPaOregRt();

                SetDayNightCombobox();//주야 콤보박스 세팅.
                chkFcltAplyYn.Checked = false;

                cboDisasterSupt.SelectedIndex = -1;

                lblMDCAREHSPTHSPTZYN.Visible = false;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show(ex.Message, "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 입력한 접수정보의 유효성 점검.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool ValidateOutRegInfo(ref string msg)
        {
            try
            {
                if (cboMdcrDeptCd.Value == null || string.IsNullOrWhiteSpace(cboMdcrDeptCd.Value.ToString()))
                {
                    cboMdcrDeptCd.Focus();
                    msg = "진료과목이 누락되었습니다. 입력하여 주시기 바랍니다.";
                    return false;
                }

                if (cboMdcrDrCd.Value == null || string.IsNullOrWhiteSpace(cboMdcrDrCd.Value.ToString()))
                {
                    cboMdcrDrCd.Focus();
                    msg = "진료의가 누락되었습니다. 입력하여 주시기 바랍니다.";
                    return false;
                }

                if (ClinicList.GetColumnValue((cboMdcrDeptCd.Value == null ? "" : cboMdcrDeptCd.Value.ToString()), "OTPT_RCPN_PSBL_YN").ToString().Equals("N"))
                {
                    cboMdcrDeptCd.Focus();
                    msg = "외래 접수 가능 부서과목이 아닙니다. 확인하여 주시기 바랍니다.";
                    return false;
                }
                /*
                if (clsPACommon.ReturnValidityOfColumnValue("PAOPATRT", "MDCR_DR_CD", (cboMdcrDrCd.Value == null ? "" : cboMdcrDrCd.Value.ToString()), cboMdcrDeptCd.Value.ToString()) == "N")
                {
                    //cboMdcrDrCd.Focus();
                    this.ActiveControl = cboMdcrDrCd;
                    msg = "입력한 의사코드가 유효하지 않는 의사코드입니다. 확인하여 주시기 바랍니다.";
                    return false;
                }
                */
                if (cboMdcrDrCd.Value == null || string.IsNullOrWhiteSpace(cboMdcrDrCd.Value.ToString()))
                {
                    cboMdcrDrCd.Focus();
                    msg = "진료의사코드가 누락되었습니다. 입력하여 주시기 바랍니다.";
                    return false;
                }

                int i = DBService.ExecuteInteger($"SELECT COUNT(1) FROM BIUSERMT WHERE USER_CD = '{cboMdcrDrCd.SelectedValue}' AND USE_YN = 'Y'");
                if (i.Equals(0))
                {
                    msg = "접수 불가능한 진료의사입니다.\r\n진료의를 다시 확인해 주세요.";
                    return false;
                }  

                if (cboFrvsRvstDvcd.Value == null || string.IsNullOrWhiteSpace(cboFrvsRvstDvcd.Value.ToString()))
                {
                    cboFrvsRvstDvcd.Focus();
                    msg = "초진재진구분코드가 누락되었습니다. 입력하여 주시기 바랍니다.";
                    return false;
                }
                OutRegInfo.FRVS_RVST_DVCD = cboFrvsRvstDvcd.Value.ToString();

                if (StringService.IsNull(mskMdcrTime.Text.Trim()))
                {
                    mskMdcrTime.Focus();
                    msg = "진료시간이 누락되었습니다. 입력하여 주시기 바랍니다.";
                    return false;
                }

                // TODO : 시간형식

                if (cboInsnTycd.Value == null || string.IsNullOrWhiteSpace(cboInsnTycd.Value.ToString()))
                {
                    cboInsnTycd.Focus();
                    msg = "보험유형코드가 누락되었습니다. 입력하여 주시기 바랍니다.";
                    return false;
                }
                OutRegInfo.INSN_TYCD = cboInsnTycd.Value.ToString();

                if (cboAsstTycd.Value == null || string.IsNullOrWhiteSpace(cboAsstTycd.Value.ToString()))
                {
                    cboAsstTycd.Focus();
                    msg = "보조유형코드가 누락되었습니다. 입력하여 주시기 바랍니다.";
                    return false;
                }
                OutRegInfo.ASST_TYCD = cboAsstTycd.Value.ToString();

                if (cboMcchCmptDvcd.Value == null || string.IsNullOrWhiteSpace(cboMcchCmptDvcd.Value.ToString()))
                {
                    cboMcchCmptDvcd.Focus();
                    msg = "진찰료산정구분코드가 누락되었습니다. 입력하여 주시기 바랍니다.";
                    return false;
                }

                if (cboCmhsDvcd.Value == null || string.IsNullOrWhiteSpace(cboCmhsDvcd.Value.ToString()))
                {
                    cboCmhsDvcd.Focus();
                    msg = "내원구분코드가 누락되었습니다. 입력하여 주시기 바랍니다.";
                    return false;
                }
                OutRegInfo.CMHS_DVCD = cboCmhsDvcd.Value.ToString();

                // 해당 보험유형, 보조유형에 맞는 유형별계산자원관리에 정보가 존재하는지 확인한다.
                if (IsInsnTypeToBiTpclMa() < 1)
                {
                    msg = "현재 입력된 보험유형 및 보조유형은 존재하지 않습니다. 확인하여 주시기 바랍니다.";
                    return false;
                }

                if (OutRegInfo.CMHS_DVCD.Equals("0") && (!OutRegInfo.FRVS_RVST_DVCD.Equals("0") && !OutRegInfo.FRVS_RVST_DVCD.Equals("3")))
                {
                    msg = "보호자내원하여 처방전만 발행하는 경우는 재진환자만 가능합니다.";
                    return false;
                }

                // TODO : 상해외인E(NP의뢰)의 경우는 의료급여인 경우만 해당한다.
                //OutRegInfo.ECOI_CD = cboEcoiCd.Value.ToString();
                if (OutRegInfo.ECOI_CD.Equals("E"))
                {
                    if (!(OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("1") && !OutRegInfo.ASST_TYCD.Equals("99")))
                    {
                        msg = "상해외인E(NP의뢰)의 경우는 의료급여환자만 가능합니다.";
                        return false;
                    }
                }

                if (cboDcntRdiaCd.Value != null && !StringService.IsNvl(cboDcntRdiaCd.SelectedItem.DataValue.ToString(), "NO").Equals("NO"))
                {
                    if (StringService.IsNull(txtDcntRdiaEmnm.Text.Trim()) || StringService.IsNull(txtDcntRdiaEmno.Text.Trim()))
                    {
                        txtDcntRdiaEmnm.Focus();
                        if (LxMessage.Show("할인감액적용 직원번호가 없습니다. 입력하시겠습니까?\r\nYes : 할인감액적용 직원번호 입력\r\nNo : 접수저장", "확인",
                                        MessageBoxButtons.YesNo, MessageBoxIcon.Question).Equals(DialogResult.Yes))
                        {
                            msg = "할인감액적용 직원번호를 입력하기 위해 접수를 취소하였습니다.";
                            return false;
                        }
                    }
                }

                // 의료급여 환자의 경우 
                if ((cboInsnTycd.SelectedValue.Equals("21") || cboInsnTycd.SelectedValue.Equals("22")) && !cboAsstTycd.SelectedValue.Equals("99"))
                {
                    if (cboUschAplyCd.SelectedValue.Equals("M001") && txtRefrInstno.Text.Equals(DOPack.HospitalInfo.HPTL_RGNO_CD))
                    {
                        msg = "의뢰기관이 우리병원인 경우는 의뢰기관을 입력하지 말고 진행해 주세요.";
                        return false;
                    }
                    else if (txtRefrInstno.Text.Length.Equals(8) && !cboUschAplyCd.SelectedValue.Equals("B005") && !cboUschAplyCd.SelectedValue.Equals("B006"))
                    {
                        if (!LxMessage.ShowQuestion("진료의뢰 의료급여기관기호를 입력하신 경우에는 본인부담여부에 B005 또는 B006을 입력하셔야 합니다.\r\n\r\n이대로 진행하는 경우 [진료확인번호] 취득에 실패합니다.\r\n\r\n그래도 이대로 진행하시겠습니까?").Equals(DialogResult.Yes))
                        {
                            msg = "저장을 취소하였습니다.";
                            return false;
                        }
                    }
                    else if (string.IsNullOrWhiteSpace(txtRefrInstno.Text) && (cboUschAplyCd.SelectedValue.Equals("B005") || cboUschAplyCd.SelectedValue.Equals("B006")))
                    {
                        msg = "본인코드 B005 또는 B006 입력시에는 의뢰기관을 반드시 입력해야 합니다.";
                        txtRefrInstno.Focus();
                        return false;
                    }
                }

                // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                // 요양병원에 입원중이며 건강보험 or 의료급여1/2종으로 접수한 경우
                // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                string insn_tycd = this.cboInsnTycd.Value == null ? string.Empty : this.cboInsnTycd.Value.ToString();
                if (this.lblMDCAREHSPTHSPTZYN.Visible && (insn_tycd.Equals("11") || insn_tycd.Equals("21") || insn_tycd.Equals("22")))
                {
                    string asst_tycd = this.cboAsstTycd.Value == null ? string.Empty : this.cboAsstTycd.Value.ToString();
                    if (asst_tycd.Contains("V") || asst_tycd.Contains("H"))
                    {
                        // 산정특례 보조유형이 세팅된 경우, 의뢰기관기호가 존재하는지 확인한다.
                        if (string.IsNullOrWhiteSpace(this.txtRefrInstno.Text))
                        {
                            this.txtRefrInstno.Focus();
                            msg = "요양병원 입원중인 환자입니다.\r\n\r\n[의뢰기관]기호를 입력해 주세요.";
                            return false;
                        }
                    }
                    else if (asst_tycd.Equals("99"))
                    {
                        // 보조유형 본인100인 경우
                    }
                    else
                    {
                        // 그 외의 보조유형인 경우
                        LxMessage.ShowInformation("요양병원 입원중인 환자입니다.\r\n산정특례인 경우만 급여처리 가능하며,\r\n산정특례가 아닌 경우 본인부담100%로 처리하세요.");
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show(ex.Message, "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /// <summary>
        /// 접수한 정보를 선택시 접수내역을 가져온다.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="ptcmhsno"></param>
        public void DisplayRegistrationInfo(string pid, int ptcmhsno)
        {
            try
            {
                if (OutRegInfo.Load(pid, ptcmhsno))
                {
                    SetDefaultValueToInputCtl();
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show(ex.Message, "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 접수정보uc 내 컨트롤 정보 세팅.  (접수리스트, 동명환자리스트 사용)
        /// </summary>
        public void SetDefaultValueToInputCtl()
        {
            try
            {
                this.PatientInfo.Load(this.OutRegInfo.PID);

                dteMdcrDd.DateTime = DateTimeService.ConvertDateTime(OutRegInfo.MDCR_DD);           //진료일자
                mskMdcrTime.Text = OutRegInfo.MDCR_TIME;                                         //진료시간
                cboApntYn.SelectedValue = OutRegInfo.APNT_YN;                                   //예약여부
                cboApntPathDvcd.Clear();                                                         //예약경로구분코드                
                cboApntPathDvcd.SelectValue(OutRegInfo.APNT_PATH_DVCD);                          // 방문접수
                cboApntPathDvcd.Enabled = false;
                cboMdcrDeptCd.SelectedValue = OutRegInfo.MDCR_DEPT_CD;                           //진료부서

                clsPACommon.SetComboPA(cboMdcrDrCd, "USER_CD", "USER_NM", (cboMdcrDeptCd.Value != null ? cboMdcrDeptCd.Value.ToString().Trim() : ""), m_MdcrDd);
                cboMdcrDrCd.SelectedValue = OutRegInfo.MDCR_DR_CD;                              //진료의사
                cboFrvsRvstDvcd.SelectedValue = OutRegInfo.FRVS_RVST_DVCD;                      //초진재진구분
                //cboSmcrYn.SelectedValue = OutRegInfo.SMCR_YN;                                   //선택진료
                cboInsnTycd.SelectValue(OutRegInfo.INSN_TYCD);                                  //보험유형

                //접수리스트 DoubleClick 시 보험유형에 따른 보조유형 바뀌도록 추가, YJS
                SetASST_TYCD();
                OnPatientSelected("INSNTYCD");

                cboAsstTycd.SelectValue(OutRegInfo.ASST_TYCD);                                  //보조유형
                cboMcchCmptDvcd.SelectValue(OutRegInfo.MCCH_CMPT_DVCD);                         //진찰료산정구분
                cboCmhsDvcd.SelectValue(OutRegInfo.CMHS_DVCD);                                  //내원구분
                cboCmhsMotvDvcd.SelectValue(OutRegInfo.CMHS_MOTV_DVCD);                         //내원경로구분
                cboExcpResnCd.SelectValue(OutRegInfo.EXCP_RESN_CD);                             //예외사유
                //산정특례코드
                cboUschAplyCd.SelectValue(OutRegInfo.USCH_APLY_CD);                             //본인부담코드
                cboPayQlfcDvcd.SelectValue(OutRegInfo.PAY_QLFC_DVCD);                           //급여자격구분
                cboCnstRefrYn.SelectValue(OutRegInfo.CNST_REFR_YN);                             //협진여부
                cboDcntRdiaCd.SelectValue(OutRegInfo.DCNT_RDIA_CD);                             //할인감액여부
                txtDcntRdiaEmno.Text = OutRegInfo.DCNT_RDIA_EMNO;                               //할인감액적용직원번호
                txtDcntRdiaEmnm.Text = UserList.GetColumnValue(OutRegInfo.DCNT_RDIA_EMNO, "USER_NM").ToString(); //할인감액적용직원성명
                if (OutRegInfo.DCNT_RDIA_CD != "NO")
                {
                    txtDcntRdiaEmno.ReadOnly = true;
                    txtDcntRdiaEmnm.ReadOnly = true;
                }
                txtAsctRgnoCd.Text = OutRegInfo.ASCT_RGNO_CD;
                txtPtPclrMatr.Text = clsPACommon.ViewRemark(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO, "O", "P");       // 환자특이사항 

                if (OutRegInfo.ETC_USE_CNTS_1 != "")
                    cboDYNT_DVCD_DRG.SelectValue(OutRegInfo.ETC_USE_CNTS_1); //주/야
                else
                    SetDayNightCombobox();

                //의뢰기관기호
                txtRefrInstno.Text = OutRegInfo.REFR_INSTNO;

                // 타병원
                m_OtherHospitalCd = OutRegInfo.ETC_USE_CNTS_4;
                // 종합코드 OVERALLCODELIST에서 못 가져온다.... 바로 추가한 거 사용할 경우가 있으므로
                m_OtherHospitalNm = DBService.ExecuteScalar(string.Format("SELECT LWRN_OVRL_CDNM FROM BICDINDT WHERE OVRL_CD ='CHMS_MOTV1_CD' AND LWRN_OVRL_CD = '{0}' ", m_OtherHospitalCd)).ToString();
                txtOtherHospital.Text = m_OtherHospitalNm;
                chkFcltAplyYn.Checked = OutRegInfo.FCLT_APLY_YN == "Y" ? true : false;

                if (!string.IsNullOrWhiteSpace(OutRegInfo.PT_CMHS_NO.ToString()) && !OutRegInfo.PT_CMHS_NO.ToString().Equals("0"))
                    lblMDCAREHSPTHSPTZYN.Visible = Lime.BusinessControls.clsPACommon.SelectMDCAREHSPTHSPTZYN(false, OutRegInfo.PID, OutRegInfo.PT_CMHS_NO.ToString());

                string sqltext = $@"
SELECT NVL(ETC_USE_CNTS_21, '0') AS ETC21
  FROM PATRTEIF
 WHERE PID = '{OutRegInfo.PID}'
   AND PT_CMHS_NO = {OutRegInfo.PT_CMHS_NO.ToString()}";

                var temp = DBService.ExecuteScalar(sqltext).ToString();

                cboDisasterSupt.SelectedValue = string.IsNullOrWhiteSpace(temp) || temp.Equals("0") ? "NO" : temp;
            }
            catch (Exception ex)
            {
                LxMessage.Show("접수정보설정중 오류를 발생하였습니다.\r\n [SetDefaultValueToInputCtl] 오류메시지 : " + ex.Message, "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void DisableAllControl()
        {
            btnApntYn.Enabled = false;
            btnMdcrDrCd.Enabled = false;
            btnRefrInstno.Enabled = false;
            cboDcntRdiaCd.Enabled = false;
            txtDcntRdiaEmno.ReadOnly = true;
            txtDcntRdiaEmnm.ReadOnly = true;
            txtPtPclrMatr.Enabled = false;
            txtRefrInstno.Enabled = false;
            mskMdcrTime.Enabled = false;
            cboApntYn.Enabled = false;
            cboApntPathDvcd.Enabled = false;
            cboMdcrDeptCd.Enabled = false;
            cboMdcrDrCd.Enabled = false;
            cboFrvsRvstDvcd.Enabled = false;
            //cboSmcrYn.Enabled = false;
            cboInsnTycd.Enabled = false;
            cboAsstTycd.Enabled = false;
            cboMcchCmptDvcd.Enabled = false;
            cboCmhsDvcd.Enabled = false;
            cboExcpResnCd.Enabled = false;
            cboUschAplyCd.Enabled = false;
            cboFcltAplyYn.Enabled = false;
            cboMtwmYn.Enabled = false;
            cboPayQlfcDvcd.Enabled = false;
            cboCnstRefrYn.Enabled = false;
            dteMdcrDd.Enabled = false;
            cboCmhsMotvDvcd.Enabled = false;

            txtOtherHospital.Enabled = false;
            chkFcltAplyYn.Enabled = false;
        }

        public bool CheckRegInputionInfo(ref string msg)
        {
            try
            {
                OutRegInfo.INSN_TYCD = cboInsnTycd.Value.ToString();
                OutRegInfo.ASST_TYCD = cboAsstTycd.Value.ToString();

                //TODO : 시설적용여부
                OutRegInfo.FCLT_APLY_YN = "N";
                if (OutRegInfo.FCLT_APLY_YN == "Y")
                {
                    if (!OutRegInfo.INSN_TYCD.Equals("21"))
                    {
                        cboInsnTycd.Focus();
                        msg = "시설환자인데 보험유형이 의료급여1종이 아닙니다. 확인하고 접수하시기 바랍니다.";
                        return false;
                    }

                    if (PatientInfo.FCLT_APLY_YN != OutRegInfo.FCLT_APLY_YN)
                    {
                        PatientInfo.FCLT_APLY_YN = OutRegInfo.VTRN_FALU_YN;
                    }
                }

                OutRegInfo.FRVS_RVST_DVCD = cboFrvsRvstDvcd.Value.ToString();
                if (OutRegInfo.NEW_PID_YN.Equals("N") && OutRegInfo.FRVS_RVST_DVCD.Equals("1"))
                {
                    msg = "신환환자등록이 아닙니다. 신환 접수를 할 수 없습니다.";
                    this.ActiveControl = cboFrvsRvstDvcd;
                    return false;
                }

                OutRegInfo.RGST_DT = DateTimeService.NowDateTimeNoneSeperatorString();
                OutRegInfo.MDCR_DD = dteMdcrDd.DateTime.ToString("yyyyMMdd");
                OutRegInfo.MDCR_TIME = mskMdcrTime.Text.Replace(":", "");
                OutRegInfo.MDCR_DEPT_CD = cboMdcrDeptCd.Value.ToString();
                OutRegInfo.EMRM_MMCD_CD = OutRegInfo.MDCR_DEPT_CD;
                OutRegInfo.MDCR_DR_CD = cboMdcrDrCd.Value.ToString();
                OutRegInfo.INSN_CLAM_DEPT_CD = string.IsNullOrWhiteSpace(OutRegInfo.INSN_CLAM_DEPT_CD) ? ClinicList.GetColumnValue(OutRegInfo.MDCR_DEPT_CD, "INSN_CLAM_DEPT_CD").ToString() : OutRegInfo.INSN_CLAM_DEPT_CD;
                OutRegInfo.ISCL_EMRM_MMCD_CD = OutRegInfo.INSN_CLAM_DEPT_CD;
                OutRegInfo.SNDT_TGPS_DVCD = "0";

                if ((OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("1") || OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("2")) && !OutRegInfo.NEW_PID_YN.Equals("Y") && !OutRegInfo.INSN_CLAM_DEPT_CD.Equals("24")
                    && !OutRegInfo.CMHS_DVCD.Equals("R"))
                {
                    string ptmdcrstatdvcd = StringService.IsNvl(DBService.ExecuteScalar(SQL.PA.Sql.SelectPtMdcrDvcdOfPaOpatRt(), OutRegInfo.PID
                                                                                                                               , OutRegInfo.MDCR_DD
                                                                                                                               , OutRegInfo.MDCR_DEPT_CD
                                                                                                                               , OutRegInfo.MDCR_DR_CD
                                                                                                                               , OutRegInfo.INSN_TYCD
                                                                                                                               , OutRegInfo.ASST_TYCD
                                                                                                                               , cboDisasterSupt.SelectedValue.Equals("NO") ? "0" : cboDisasterSupt.SelectedValue
                                                                                                                               , cboMcchCmptDvcd.SelectedValue).ToString(), "0");

                    if (ptmdcrstatdvcd.Equals("9"))
                    {
                        msg = "당일 진료부서/진료의사/보험유형/진찰료산정구분이\r\n동일한 과취소된 접수정보가 존재합니다.\r\n\r\n추가 접수하지 않고 해당과에서 과취소된 접수정보를 취소하면 됩니다.";
                        return false;
                    }
                    else if (!ptmdcrstatdvcd.Equals("0"))
                    {
                        msg = "당일 진료부서/진료의사/보험유형/진찰료산정구분이\r\n동일한 접수정보가 존재합니다.\r\n추가 접수 불가합니다. ";
                        return false;
                    }
                }

                if (DBService.ExecuteInteger(SQL.PA.Sql.SelectCountOfDrgYn(), OutRegInfo.PID
                                                                           , OutRegInfo.MDCR_DD
                                                                           , OutRegInfo.PT_CMHS_NO.ToString()) > 0)
                {
                    msg = "당일 DRG 타과 진료내역이 존재합니다. \r\n 타과 접수가 발생하지 않도록 주의하시기 바랍니다.";

                }
                else
                {
                    if (DBService.ExecuteInteger(SQL.PA.Sql.SelectCountOfDrgPrsc(), OutRegInfo.PID
                                                                                , OutRegInfo.PT_CMHS_NO.ToString()
                                                                                , OutRegInfo.MDCR_DD) > 0)
                    {
                        msg = "당일 타과 DRG 시술내역이 존재합니다. \r\n 타과 접수가 발생하지 않도록 주의하시기 바랍니다.";
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                msg = "외래접수 입력정보 확인 중 오류를 발생했습니다.\r\n " +
                      "Method :  CheckRegInputionInfo \r\n " +
                      "오류 메시지 : " + ex.Message;
                return false;
            }

            return true;
        }

        /// <summary>
        /// 입력받은 접수정보를 접수 멤버변수에 담는다.
        /// </summary>
        public bool SetOutRegistrationInfo(string pid, string asct_rgno_cd, string afrsstatdvcd, string rowstatdvcd, ref string msg)
        {
            string emrm_dept_cd = string.Empty;

            //변경한 환자기본정보로 외래접수등록정보에 넣기 위해 다시 Load - YJS
            PatientInfo.Load(pid);

            int pt_cmhs_no = 0;
            int rcpn_sqno = OutRegInfo.RCPN_SQNO;

            OutRegInfo.PID = pid;
            if (string.IsNullOrWhiteSpace(OutRegInfo.PID))
            {
                msg = "환자등록번호가 없습니다. 접수할 수 없습니다.";
                return false;
            }

            // 내역변경 6, 접수변경 4, 접수취소 3
            if (!afrsstatdvcd.Equals("6") && !afrsstatdvcd.Equals("4") && !afrsstatdvcd.Equals("3"))
            {
                SqlPack.Procedure.PR_PA_READ_PTCMHSNO(OutRegInfo.PID, DOPack.UserInfo.USER_CD, ref pt_cmhs_no);
                // 오류체크하기
                OutRegInfo.PT_CMHS_NO = pt_cmhs_no;
            }

            OutRegInfo.RCPN_SQNO = clsPACommon.SelectMaxRcpnSqno("O", OutRegInfo.PID, OutRegInfo.PT_CMHS_NO);
            OutRegInfo.MDCR_DD = dteMdcrDd.DateTime.ToString("yyyyMMdd");     //m_MdcrDd;
            OutRegInfo.APNT_TIME = mskMdcrTime.Text.Replace(":", "");
            OutRegInfo.MDCR_TIME = mskMdcrTime.Text.Replace(":", "");
            //OutRegInfo.MDCR_DEPT_CD   = cboMdcrDeptCd.Value.ToString();
            //if (string.IsNullOrWhiteSpace(OutRegInfo.INSN_CLAM_DEPT_CD))
            //{
            //    OutRegInfo.INSN_CLAM_DEPT_CD = DBService.ExecuteScalar(SQL.PA.Sql.SelectBIDEPTMA_READ_COLUMN(), OutRegInfo.MDCR_DEPT_CD, m_MdcrDd, "INSN_CLAM_DEPT_CD").ToString();
            //}
            //else
            //{
            //    OutRegInfo.INSN_CLAM_DEPT_CD = OutRegInfo.INSN_CLAM_DEPT_CD;
            //}

            // 내역/접수 변경
            if (afrsstatdvcd == "4" || afrsstatdvcd == "6")
            {
                DataTable dt = new DataTable();

                // 부서가 변경되었는지 확인
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectMaxMdcrDeptCdOrEmrmMmcdCd(), ref dt
                                                                                           , OutRegInfo.PID
                                                                                           , OutRegInfo.PT_CMHS_NO.ToString()
                                                                                           , rcpn_sqno.ToString()))
                {
                    msg = "외래접수정보 조회 중 오류를 발생했습니다.\r\n Method :  [SetOutRegistrationInfo]";
                    return false;
                }

                if (dt.Rows.Count <= 0)
                {
                    msg = "외래접수정보가 없습니다. 확인 바랍니다.\r\n Method :  [SetOutRegistrationInfo]";
                    return false;
                }

                // 부서가 바뀌었을 때
                if (dt.Rows[0]["MDCR_DEPT_CD"].ToString() != OutRegInfo.MDCR_DEPT_CD)
                {
                    OutRegInfo.EMRM_MMCD_CD = OutRegInfo.MDCR_DEPT_CD;                  // 응급실주진료부서코드
                    OutRegInfo.ISCL_EMRM_MMCD_CD = OutRegInfo.INSN_CLAM_DEPT_CD;        // 보험청구응급실주진료부서코드

                    // 변경한 부서가 응급실 일때
                    if (OutRegInfo.MDCR_DEPT_CD.Equals("2400"))
                    {
                        // 응급실주진료부서코드 - 옵션에서 읽어서 응급의학과인 경우, 설정된 부서로 접수한다.
                        if (ConfigService.GetConfigValueString("PA", "EMRM_DEFAULT", "EMRM_DEFAULT").Equals("Y"))
                        {
                            emrm_dept_cd = ConfigService.GetConfigValueString("PA", "EMRM_DEFAULT", "EMRM_DEPT_CD");
                            if (!String.IsNullOrWhiteSpace(emrm_dept_cd))
                            {
                                OutRegInfo.EMRM_MMCD_CD = emrm_dept_cd;
                                OutRegInfo.ISCL_EMRM_MMCD_CD = DeptList.GetColumnValue(emrm_dept_cd, "INSN_CLAM_DEPT_CD").ToString();
                            }
                        }
                    }
                }
            }
            else
            {
                OutRegInfo.EMRM_MMCD_CD = OutRegInfo.MDCR_DEPT_CD;              // 응급실주진료부서코드
                OutRegInfo.ISCL_EMRM_MMCD_CD = OutRegInfo.INSN_CLAM_DEPT_CD;         // 보험청구응급실주진료부서코드

                // 응급실주진료부서코드 - 옵션에서 읽어서 응급의학과인 경우, 설정된 부서로 접수한다.
                if (ConfigService.GetConfigValueString("PA", "EMRM_DEFAULT", "EMRM_DEFAULT").Equals("Y"))
                {
                    if (cboMdcrDeptCd.SelectedValue.Equals("2400"))
                    {
                        emrm_dept_cd = ConfigService.GetConfigValueString("PA", "EMRM_DEFAULT", "EMRM_DEPT_CD");
                        if (!String.IsNullOrWhiteSpace(emrm_dept_cd))
                        {
                            OutRegInfo.EMRM_MMCD_CD = emrm_dept_cd;
                            OutRegInfo.ISCL_EMRM_MMCD_CD = DeptList.GetColumnValue(emrm_dept_cd, "INSN_CLAM_DEPT_CD").ToString();
                        }
                    }
                }
            }

            OutRegInfo.MDCR_DR_CD = cboMdcrDrCd.Value == null ? "" : cboMdcrDrCd.Value.ToString();
            OutRegInfo.REAL_MDCR_DR_CD = cboMdcrDrCd.Value == null ? "" : cboMdcrDrCd.Value.ToString();
            OutRegInfo.INSN_TYCD = cboInsnTycd.Value.ToString();
            OutRegInfo.ASST_TYCD = cboAsstTycd.Value.ToString();
            OutRegInfo.ASCT_RGNO_CD = asct_rgno_cd;
            OutRegInfo.FRVS_RVST_DVCD = cboFrvsRvstDvcd.Value.ToString(); //초재구분
            OutRegInfo.MCCH_CMPT_DVCD = cboMcchCmptDvcd.Value.ToString();
            OutRegInfo.HMCR_YN = "N";
            OutRegInfo.SMCR_YN = "N";
            OutRegInfo.CMHS_DVCD = cboCmhsDvcd.Value.ToString();
            OutRegInfo.CMHS_MOTV_DVCD = cboCmhsMotvDvcd.Value == null ? "NO" : cboCmhsMotvDvcd.Value.ToString();
            OutRegInfo.APNT_YN = cboApntYn.Value.ToString();
            OutRegInfo.APNT_PATH_DVCD = cboApntPathDvcd.SelectedItem.DataValue == null ? "R" : cboApntPathDvcd.SelectedItem.DataValue.ToString();
            OutRegInfo.MCSP_APNT_DVCD = "N";
            OutRegInfo.CNTT_PRSC_DVCD = "N";
            OutRegInfo.NRSN_CNFR_YN = "Y";    // 
            OutRegInfo.MDCR_STRT_DT = "";
            OutRegInfo.MDCR_END_DT = "";
            OutRegInfo.PT_MDCR_STAT_DVCD = "2";
            OutRegInfo.PRSC_NOTM = 0;
            OutRegInfo.RCPT_NOTM = 0;
            OutRegInfo.EXCP_RESN_CD = cboExcpResnCd == null ? "NO" : cboExcpResnCd.Value.ToString();
            OutRegInfo.VTRN_PT_YN = "N";
            OutRegInfo.MOMR_AGE_DVCD = "";
            OutRegInfo.INDP_MOMR_YN = "N";
            OutRegInfo.VTRN_FALU_YN = "N";
            OutRegInfo.VTRN_USCH_DVCD = "";
            OutRegInfo.VTRN_NON_QLFC_YN = "N";
            OutRegInfo.CLUR_DSBL_DVCD = "";
            OutRegInfo.MAIN_ILNS_CD = "";
            OutRegInfo.CFSC_RGNO_CD = "";
            OutRegInfo.CHRN_DSSE_DVCD = "N";
            OutRegInfo.TBRC_DVCD = "";
            OutRegInfo.USCH_APLY_CD = cboUschAplyCd.Value == null ? "NO" : cboUschAplyCd.Value.ToString();
            OutRegInfo.REFR_INSTNO = txtRefrInstno.Text;
            OutRegInfo.ECOI_CD = cboEcoiCd.Value == null ? "*" : cboEcoiCd.SelectedItem.DataValue.ToString();
            OutRegInfo.HLLF_MNCS_BLCE = 0;
            OutRegInfo.OTHR_HSPT_HPTF_YN = "N";
            OutRegInfo.MTWM_YN = "N";
            OutRegInfo.MTWM_BLCE = 0;
            OutRegInfo.VCNT_CLTP_YN = "N";
            OutRegInfo.VCNT_PRTW_YN = "N";
            OutRegInfo.FCLT_APLY_YN = chkFcltAplyYn.Checked ? "Y" : "N";
            //OutRegInfo.FCLT_APLY_DVCD     = ucInsuranceInfo1.InsuranceInfo.HLNS_CRTF_NO ; //시설구분코드 : 보험정보의 증번호를 가져옴.(확인)
            OutRegInfo.QLFC_RTRV_YN = "N";
            OutRegInfo.PAY_QLFC_DVCD = cboPayQlfcDvcd.Value == null ? "0" : cboPayQlfcDvcd.Value.ToString();
            OutRegInfo.SNDT_TGPS_DVCD = "";
            OutRegInfo.CNST_REFR_YN = cboCnstRefrYn.Value == null ? "N" : cboCnstRefrYn.Value.ToString();
            OutRegInfo.FXAM_FXRT_DVCD = "9";
            OutRegInfo.RRNS_FAFR_DVCD = "";
            OutRegInfo.OTPT_DRG_YN = "";
            OutRegInfo.DRG_DVCD = "";
            OutRegInfo.DRG_NO = "";
            OutRegInfo.DY_WARD_YN = "N";
            OutRegInfo.ENTS_ENTD_DVCD = "";
            OutRegInfo.DYTM_CNTR_USE_YN = "";
            OutRegInfo.EMRM_WTNG_YN = "";
            //OutRegInfo.TAIC_PT_UNIQ_NO    = ucInsuranceInfo1.InsuranceInfo.TAIC_PT_UNIQ_NO;
            OutRegInfo.CLAM_CRTN_YN = "";
            OutRegInfo.CLAM_REVW_YN = "";
            OutRegInfo.CLAM_CRTN_DEL_RESN = "";
            OutRegInfo.DCNT_RDIA_CD = cboDcntRdiaCd.Value == null ? "NO" : cboDcntRdiaCd.Value.ToString();
            OutRegInfo.DCNT_RDIA_EMNO = txtDcntRdiaEmno.Text.Trim();
            OutRegInfo.RCPN_AGE = PatientInfo.AGE;
            OutRegInfo.RCPN_ADDR_CD = StringService.IsNvl(PatientInfo.ADDR_BLDG_NO, "00000");
            OutRegInfo.DC_DD = OutRegInfo.MDCR_DD;
            OutRegInfo.AFRS_STAT_DVCD = afrsstatdvcd;
            OutRegInfo.ROW_STAT_DVCD = rowstatdvcd;
            OutRegInfo.RGST_DT = DateTimeService.NowDateTimeNoneSeperatorString();
            OutRegInfo.RGSTR_ID = DOPack.UserInfo.USER_CD;
            OutRegInfo.ETC_USE_CNTS_4 = m_OtherHospitalCd;

            // 외래접수정보 입력값을 최종 확인한다.
            return OutRegInfo.CheckDataOfPAOPATRT(afrsstatdvcd, rowstatdvcd, ref msg) > 0;
        }

        /// <summary>
        /// 입력한 특이사항을 특이사항 멤버변수에 담는다.
        /// </summary>
        public void SetPatientRemark()
        {
            PatRem.PID = OutRegInfo.PID;
            PatRem.PCLR_MATR_SQNO = PatRem.SelectMaxSqno();
            PatRem.OTPT_ADMS_DVCD = "O";
            PatRem.PTAF_MDCR_DVCD = "P";
            PatRem.PT_CMHS_NO = OutRegInfo.PT_CMHS_NO;
            PatRem.WRTN_DD = OutRegInfo.MDCR_DD;
            PatRem.PT_PCLR_MATR = txtPtPclrMatr.Text.Trim();
            PatRem.DEL_YN = "A";
            PatRem.RGST_DT = DateTime.Now.ToString("yyyyMMddhhmmss");
            PatRem.RGSTR_ID = DOPack.UserInfo.USER_CD;
            PatRem.UPDT_DT = DateTime.Now.ToString("yyyyMMddhhmmss");
            PatRem.UPDTR_ID = DOPack.UserInfo.USER_CD;
        }

        /// <summary>
        /// 외래접수정보 저장 시 접수정보의 진료일자가 현재일자보다 작은지 체크, YJS 추가.
        /// <para>True : 정상접수</para>
        /// <para>False : 과거일자로 접수</para>
        /// </summary>
        /// <returns></returns>
        public bool CheckPastDateReceipt()
        {
            try
            {
                int sysdate = int.Parse(DateTime.Now.ToString("yyyyMMdd"));
                string date = DateTimeService.ConvertDateStringToNoneSeperatorString(dteMdcrDd.Text);

                if (int.Parse(date) < sysdate)
                {
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show(ex.Message, "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public void CheckHasToday70017002()
        {
            if (!OutRegInfo.PID.Equals(string.Empty) && !cboMdcrDeptCd.SelectedValue.Equals("7001") && !cboMdcrDeptCd.SelectedValue.Equals("7002") && !cboMdcrDeptCd.SelectedValue.Equals("7004"))
            {
                string sqltext = string.Format(@"
    SELECT COUNT(*)
      FROM PAOPATRT 
     WHERE PID = '{0}' 
       AND MDCR_DD = '{1}'
       AND ROW_STAT_DVCD = 'A' 
       AND MDCR_DEPT_CD IN ('7001', '7002', '7004') ", OutRegInfo.PID, dteMdcrDd.DateTime.ToString("yyyyMMdd"));

                int resultCount = DBService.ExecuteInteger(sqltext);
                if (resultCount != null && resultCount > 0)
                {
                    cboCmhsDvcd.SelectedValue = "T";   // 내원구분 : 일반검진
                    cboMcchCmptDvcd.SelectedValue = "Y";   // 진찰료 산정구분 : 진찰료산정

                    LxMessage.ShowInformation("당일 검진 접수된 환자입니다.\r\n추가진료가 있는 경우만 진찰료 산정이 가능합니다.");
                }
            }
        }

        #endregion Method : Method Public

        #region Method : Private Method

        /// <summary>
        /// Master코드의 Sub 코드 Set Combo
        /// </summary>
        /// <param name="ctl"></param>
        private void SetInputValueChanged(Control ctl)
        {
            string msg = "";
            string frvsrvstdvcd = "";
            try
            {
                if (m_DefaultSetting == "N")
                    return;

                switch (ctl.Name)
                {
                    case "dteMdcrDd":
                        // [ YJS추가, 진료일자를 미래료 바꾸면 예약구분, 예약경로 Default 세팅 ]
                        if (dteMdcrDd.DateTime > DateTime.Now)
                        {
                            cboApntYn.SelectValue("Y"); // '예'
                            cboApntPathDvcd.SelectValue("J"); // '방문예약'
                            cboApntPathDvcd.Enabled = true;
                        }

                        m_MdcrDd = dteMdcrDd.DateTimeValue.ToString("yyyyMMdd");
                        OutRegInfo.MDCR_DD = dteMdcrDd.DateTimeValue.ToString("yyyyMMdd");

                        // TODO : 보훈정보를 가져온다.
                        // TODO : 보훈정보를 설정한다.

                        OutRegInfo.INSN_CLAM_DEPT_CD = ClinicList.GetColumnValue(OutRegInfo.MDCR_DEPT_CD, "INSN_CLAM_DEPT_CD").ToString();

                        if (!OutRegInfo.CheckFrvsRvstDvcd(ref msg))
                        {
                            LxMessage.Show(msg + " 초진재진 체크중 오류가 발생헀습니다. ", "초진재진체크", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            return;
                        }

                        cboFrvsRvstDvcd.SelectValue(OutRegInfo.FRVS_RVST_DVCD);

                        // TODO : 가접수 대상자인지 확인한다.
                        // TODO : 진료의 예약스케줄을 보여준다.

                        // 2018-07-31 SEO
                        //OnPatientSelected("INSNTYCD");
                        break;
                    case "mskMdcrTime":             // 접수일자
                        // 진료의 진료일정 확인
                        CheckMdcrApntPossibleYn();
                        break;
                    case "cboInsnTycd":
                        SetASST_TYCD();
                        OnPatientSelected("INSNTYCD");
                        break;
                    case "cboAsstTycd":
                        // 보험정보 표시하기
                        if (cboInsnTycd.Value != null)
                            OnPatientSelected("ASSTTYCD");
                        break;
                    case "cboMdcrDeptCd":

                        if (cboMdcrDeptCd.Value != null)
                        {
                            OutRegInfo.MDCR_DEPT_CD = cboMdcrDeptCd.Value.ToString();

                            // 의사코드조회
                            cboMdcrDrCd.Clear();
                            clsPACommon.SetComboPA(cboMdcrDrCd, "USER_CD", "USER_NM", OutRegInfo.MDCR_DEPT_CD, m_MdcrDd);

                            // 응급의학과 선택시 내원구분 응급으로 변경
                            if (cboMdcrDeptCd.Value.Equals("2400"))
                            {
                                cboCmhsDvcd.SelectedValue = "2";
                            }

                            // 청구부서 가져온다.
                            OutRegInfo.INSN_CLAM_DEPT_CD = ClinicList.GetColumnValue(OutRegInfo.MDCR_DEPT_CD, "INSN_CLAM_DEPT_CD").ToString();

                            // 예외사유코드설정
                            switch (OutRegInfo.INSN_CLAM_DEPT_CD)
                            {
                                case "24":
                                    // 병원에 응급센터 등이 아닌 응급실이 있고, 진료외 시간일 경우 예외사유코드는 11로 세팅한다.
                                    string excpResnCd = clsPACommon.GetExcpResnCd(dteMdcrDd.DateTime.ToString("yyyyMMdd"), mskMdcrTime.Value.ToString().Replace(":", "").Replace("_", ""));
                                    cboExcpResnCd.SelectedValue = excpResnCd;

                                    /*
                                    string confVal = ConfigService.GetConfigValueString("PA", "ER_AUTO_YN", "ER_AUTO_YN");
                                    int EHOP_STRT_TIME = int.Parse(DOPack.HospitalInfo.EHOP_STRT_TIME);
                                    int EHOP_END_TIME = int.Parse(DOPack.HospitalInfo.EHOP_END_TIME);
                                    int systime = int.Parse(DateTime.Now.ToString("HHmm"));

                                    if (confVal.Equals("Y"))
                                        cboExcpResnCd.SelectValue("11");
                                    else
                                    {
                                        if ((EHOP_STRT_TIME <= systime) && (EHOP_END_TIME >= systime))
                                        {
                                            cboExcpResnCd.SelectValue("NO");
                                        }
                                        else
                                            cboExcpResnCd.SelectValue("11");
                                    }
                                     * */

                                    break;
                                case "03":
                                    cboExcpResnCd.SelectValue("13");
                                    break;
                                default:
                                    cboExcpResnCd.SelectValue("NO");
                                    break;
                            }

                            //진료과목에서 '['와 ']'가 쌍이 맞지 않으면 '대괄호가 누락되었습니다'에러가 뜨므로 추가. YJS
                            if (OutRegInfo.MDCR_DEPT_CD.Contains("[") || OutRegInfo.MDCR_DEPT_CD.Contains("]"))
                                OutRegInfo.MDCR_DEPT_CD = "";

                            // 당일 동일진료과, 보험유형으로 접수된 접수정보 확인해서 진찰료산정구분 설정
                            SetcboMcchCmptDvcd();

                            // 신환이 아닌경우 과거접수정보 확인하여 초진재진구분 설정
                            if (OutRegInfo.NEW_PID_YN != "Y")
                            {
                                if (!OutRegInfo.CheckFrvsRvstDvcd(ref msg))
                                {
                                    LxMessage.Show(msg + " 초진재진 체크중 오류가 발생헀습니다. ", "초진재진체크", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                                    return;
                                }

                                cboFrvsRvstDvcd.SelectValue(OutRegInfo.FRVS_RVST_DVCD);
                            }

                            //접수시간, 예약시간설정
                            if (MdcrDDTime_Modify)
                            {
                                if (OutRegInfo.MDCR_DD == DateTime.Now.ToString("yyyyMMdd"))
                                {
                                    OutRegInfo.MDCR_TIME = DateTimeService.TodayDateTimeNoneSeperatorString().Substring(8, 4);
                                    OutRegInfo.APNT_TIME = DateTimeService.TodayDateTimeNoneSeperatorString().Substring(8, 4);
                                    mskMdcrTime.Text = OutRegInfo.MDCR_TIME;

                                    SetDayNightCombobox();
                                }
                            }

                            // 진료의 진료일정 확인
                            CheckMdcrApntPossibleYn();
                            // TODO : 진료의 예약스케줄을 보여준다.

                            // 종합검진 또는 일반검진인 경우 보험유형 일반에 내원구분 종검 진찰료 산정안함으로 설정.
                            string mdcrdeptcd = cboMdcrDeptCd.Value.ToString();

                            // 종합검진
                            if (mdcrdeptcd.Equals("7001"))
                            {
                                OutRegInfo.MCCH_CMPT_DVCD = "N";
                                OutRegInfo.CMHS_DVCD = "3";
                                OutRegInfo.INSN_TYCD = "11";
                                OutRegInfo.ASST_TYCD = "99";

                                cboMcchCmptDvcd.Value = "N";
                                cboCmhsDvcd.Value = "3";
                                cboInsnTycd.Value = "11";
                                cboAsstTycd.Value = "99";
                            }
                            // 일반검진
                            else if (mdcrdeptcd.Equals("7002"))
                            {
                                OutRegInfo.MCCH_CMPT_DVCD = "N";
                                OutRegInfo.CMHS_DVCD = "T";
                                OutRegInfo.INSN_TYCD = "11";
                                OutRegInfo.ASST_TYCD = "99";

                                cboMcchCmptDvcd.Value = "N";
                                cboCmhsDvcd.Value = "T";
                                cboInsnTycd.Value = "11";
                                cboAsstTycd.Value = "99";
                            }
                            // 특수검진
                            else if (mdcrdeptcd.Equals("7004"))
                            {
                                OutRegInfo.MCCH_CMPT_DVCD = "N";
                                OutRegInfo.CMHS_DVCD = "E";
                                OutRegInfo.INSN_TYCD = "11";
                                OutRegInfo.ASST_TYCD = "99";

                                cboMcchCmptDvcd.Value = "N";
                                cboCmhsDvcd.Value = "E";
                                cboInsnTycd.Value = "11";
                                cboAsstTycd.Value = "99";
                            }

                            // L090:임상시험
                            if (cboMdcrDeptCd.SelectedValue.Equals("L090"))
                            {
                                OutRegInfo.MCCH_CMPT_DVCD = "N";
                                OutRegInfo.INSN_TYCD = "51";
                                OutRegInfo.ASST_TYCD = "G";
                                OutRegInfo.CMHS_DVCD = "C";

                                cboMcchCmptDvcd.SelectValue("N");
                                cboInsnTycd.SelectValue("51");
                                clsPACommon.SetComboPA(cboAsstTycd, "ASST_TYCD", "LWRN_OVRL_CDNM", cboInsnTycd.Value.ToString().Trim(), m_MdcrDd);
                                cboAsstTycd.SelectValue("G");
                                cboCmhsDvcd.SelectValue("C");
                            }

                            CheckHasToday70017002();
                        }
                        else
                            cboMdcrDrCd.Clear();
                        break;
                    case "cboMdcrDrCd":

                        // 선택진료여부 설정
                        OutRegInfo.MDCR_DR_CD = cboMdcrDrCd.SelectedValue;
                        //cboSmcrYn.SelectValue(clsPACommon.SelectBiUserDtSlctDrYn(OutRegInfo.MDCR_DEPT_CD, OutRegInfo.MDCR_DR_CD, m_MdcrDd));

                        // 진료의 진료일정 확인
                        CheckMdcrApntPossibleYn();
                        // TODO : 진료의 예약스케줄을 보여준다.
                        break;
                    case "cboApntYn":           // 예약여부
                        if (cboApntYn.SelectedValue.Equals("Y"))
                        {
                            cboApntPathDvcd.Enabled = true;
                            cboApntPathDvcd.SelectValue("J");
                        }
                        else
                        {
                            //lblApntPosYn.Visible = false; // 2018-05-30 현재 안쓰므로 주석
                            //lblApntPosYn.Text = ""; // 2018-05-30 현재 안쓰므로 주석
                            cboApntPathDvcd.Enabled = false;
                            cboApntPathDvcd.SelectValue("R");
                        }

                        if (m_MdcrDDTime_Modify)
                        {
                            mskMdcrTime.Text = DateTimeService.ConvertDateTimeStringToFormatString(DateTimeService.NowDateTimeNoneSeperatorString(), "HHmm");
                            SetDayNightCombobox();
                        }
                        // TODO : 진료의 진료일정 보여주기
                        break;
                    case "cboFrvsRvstDvcd":     // 초진재진구분코드
                        break;
                    case "cboCmhsDvcd":         // 내원구분코드
                        if (cboCmhsDvcd.Value == null)
                            return;

                        OutRegInfo.CMHS_DVCD = cboCmhsDvcd.Value.ToString();
                        switch (OutRegInfo.CMHS_DVCD)
                        {
                            // 내원구분:환자가족처방 => 산정구분:보호자 내원 처방전 수령
                            case "5":
                                OutRegInfo.MCCH_CMPT_DVCD = "O";
                                cboMcchCmptDvcd.SelectValue("O");
                                break;
                            //case "4":
                            case "3": // 종검
                            case "9": // 영유아검진
                            case "T": // 일반검진
                            case "E": // 특수검진
                                OutRegInfo.MCCH_CMPT_DVCD = "N";
                                OutRegInfo.INSN_TYCD = "11";
                                OutRegInfo.ASST_TYCD = "99";
                                cboMcchCmptDvcd.SelectValue("N");
                                cboInsnTycd.SelectValue("11");
                                cboAsstTycd.SelectValue("99");

                                SetInputValueChanged((Control)cboInsnTycd);
                                OutRegInfo.ASST_TYCD = "99";
                                cboAsstTycd.SelectValue("99");
                                OutRegInfo.MCCH_CMPT_DVCD = "N";
                                cboMcchCmptDvcd.SelectValue("N");
                                break;
                            case "4": // 진단서발행
                            case "S": // 예방접종
                            case "10": // 레이저
                                OutRegInfo.MCCH_CMPT_DVCD = "N";
                                OutRegInfo.INSN_TYCD = "51";
                                OutRegInfo.ASST_TYCD = "99";
                                cboMcchCmptDvcd.SelectValue("N");
                                cboInsnTycd.SelectValue("51");
                                cboAsstTycd.SelectValue("99");
                                break;
                            case "11": // (산재) 수수료 청구
                                OutRegInfo.MCCH_CMPT_DVCD = "N";
                                OutRegInfo.INSN_TYCD = "31";
                                OutRegInfo.ASST_TYCD = "00";
                                cboMcchCmptDvcd.SelectValue("N");
                                cboInsnTycd.SelectValue("31");
                                cboAsstTycd.SelectValue("00");

                                SetInputValueChanged((Control)cboInsnTycd);
                                OutRegInfo.MCCH_CMPT_DVCD = "N";
                                OutRegInfo.ASST_TYCD = "00";
                                cboMcchCmptDvcd.SelectValue("N");
                                cboAsstTycd.SelectValue("00");
                                break;
                            case "7": //물리치료/주사이면, 산정구분 '병원관리료 재진 50%' 설정
                                OutRegInfo.MCCH_CMPT_DVCD = "P";
                                cboMcchCmptDvcd.SelectValue("P");
                                break;
                            default: // 그외
                                OutRegInfo.MCCH_CMPT_DVCD = "Y";
                                cboMcchCmptDvcd.SelectValue("Y");
                                break;
                        }
                        break;
                        /* 당일 검진을 목적으로 내원한 경우 */
                        // 내원구분

                        switch (OverallCodeList.GetColumnValue("CMHS_DVCD", OutRegInfo.CMHS_DVCD, "ETC_USE_CNTS_2").ToString())
                        {
                            case "2": //영유아검진
                            case "3": //일반검진
                            case "4": //생애전환기
                            case "5": //암검진
                                OutRegInfo.MCCH_CMPT_DVCD = "N";
                                OutRegInfo.INSN_TYCD = "11";
                                OutRegInfo.ASST_TYCD = "99";
                                cboMcchCmptDvcd.SelectValue("N");
                                cboInsnTycd.SelectValue("11");
                                cboAsstTycd.SelectValue("99");

                                SetInputValueChanged((Control)cboInsnTycd);
                                OutRegInfo.MCCH_CMPT_DVCD = "N";
                                cboMcchCmptDvcd.SelectValue("N");
                                break;
                        }
                    case "cboDcntRdiaCd":
                        if (cboDcntRdiaCd.Value == null) return;
                        if (cboDcntRdiaCd.Value.ToString().Equals("NO"))
                        {
                            txtDcntRdiaEmno.Text = String.Empty;
                            txtDcntRdiaEmnm.Text = String.Empty;
                            txtDcntRdiaEmnm.ReadOnly = true;
                            cboCmhsMotvDvcd.SelectValue("NO");

                        }
                        else
                        {
                            // TODO : 일단 할인코드가 선택되면 내원경로 지인소개로 변경함..
                            cboCmhsMotvDvcd.SelectValue("02");
                            txtDcntRdiaEmnm.ReadOnly = false;
                        }
                        break;
                    //case "cbo"
                    case "txtDcntRdiaEmnm":    // 직원번호
                        //------------ YJS, Leave 이벤트에서 처리.
                        // 직원번호 확인
                        if (txtDcntRdiaEmnm.ReadOnly) break;

                        if (!GetUser())
                        {
                            txtDcntRdiaEmnm.Focus();
                            LxMessage.Show("사원ID가 존재하지 않습니다. 확인하세요.!!", "확인", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            txtDcntRdiaEmno.Text = String.Empty;
                        }
                        else
                            SendKeys.Send("\t");

                        break;
                }
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        private bool GetUser()
        {
            bool result = true;
            try
            {
                string dcntrdiaemnm = String.Empty;
                string inputvalue = txtDcntRdiaEmnm.Text.Trim();
                if (StringService.IsNull(inputvalue)) return false;

                dcntrdiaemnm = UserList.GetColumnValue(inputvalue, "USER_NM").ToString();
                if (StringService.IsNotNull(dcntrdiaemnm))
                {
                    txtDcntRdiaEmno.Text = inputvalue;
                    txtDcntRdiaEmnm.Text = dcntrdiaemnm;
                }
                else
                {
                    DataTable dt = new DataTable();
                    if (DBService.ExecuteDataTable(SQL.BI.Sql.SelectUserORSEDSDT(), ref dt, "USER_NM", inputvalue))
                    {
                        if (dt.Rows.Count == 1)
                        {
                            txtDcntRdiaEmno.Text = dt.Rows[0]["USER_CD"].ToString();
                            txtDcntRdiaEmnm.Text = dt.Rows[0]["USER_NM"].ToString();
                        }
                        else if (dt.Rows.Count > 1)
                        {
                            PopUpForm("USER_NM");
                        }
                        else
                        {
                            result = false;
                        }
                    }
                    else
                    {
                        result = false;
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                result = false;
            }
            return result;
        }
        /// <summary>
        /// 유형별계산자원에 보험유형,보조유형이 존재하는지 확인한다.
        /// </summary>
        /// <returns></returns>
        private int IsInsnTypeToBiTpclMa()
        {
            try
            {
                return DBService.ExecuteInteger(SQL.PA.Sql.SelectCountOfBITPCLMA(), cboInsnTycd.Value.ToString()
                                                                              , cboAsstTycd.Value.ToString()
                                                                              , DateTimeService.ConvertDateToNoneSeperatorString(dteMdcrDd.DateTime));
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show(ex.Message, "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
        }

        /// <summary>
        /// 의뢰기관 팝업
        /// </summary>
        private void ViewChoosePlace()
        {
            try
            {
                DataTable insn_info = new DataTable();

                DialogResult result = LxMessage.Show("진료의뢰정보를 등록하시겠습니까?\r\n[   예   ]진료의뢰정보등록\r\n[아니오]선택기관만 선택", "확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    if (StringService.SubString(OutRegInfo.INSN_TYCD, 1) == "1" || StringService.SubString(OutRegInfo.INSN_TYCD, 1) == "2")
                    {
                        DBService.ExecuteDataTable(SQL.PA.Sql.SelectInsnInfo(), ref insn_info, PatientInfo.PID, OutRegInfo.INSN_TYCD);

                        if (insn_info.Rows.Count > 0)
                        {
                            frmMedReferInfoP popRefer = new frmMedReferInfoP(PatientInfo.PID, PatientInfo.PT_NM, PatientInfo.FRRN, PatientInfo.SRRN, PatientInfo.Sex
                                                                           , PatientInfo.Age, insn_info.Rows[0]["HLNS_INPN_NM"].ToString(), insn_info.Rows[0]["INPN_FRRN"].ToString(), insn_info.Rows[0]["INPN_SRRN"].ToString(), OutRegInfo.MDCR_DD, OutRegInfo.MDCR_DEPT_CD, OutRegInfo.MDCR_DR_CD, 0);

                            popRefer.ShowDialog(this);
                            popRefer.Dispose();
                        }
                        else
                        {
                            frmMedReferInfoP popRefer = new frmMedReferInfoP(PatientInfo.PID, PatientInfo.PT_NM, PatientInfo.FRRN, PatientInfo.SRRN, PatientInfo.Sex
                                                                           , PatientInfo.Age, PatientInfo.PT_NM, PatientInfo.FRRN, PatientInfo.SRRN, OutRegInfo.MDCR_DD, OutRegInfo.MDCR_DEPT_CD, OutRegInfo.MDCR_DR_CD, 0);

                            popRefer.ShowDialog(this);
                            popRefer.Dispose();
                        }
                    }
                    else
                    {
                        frmMedReferInfoP popRefer = new frmMedReferInfoP(PatientInfo.PID, PatientInfo.PT_NM, PatientInfo.FRRN, PatientInfo.SRRN, PatientInfo.Sex
                                                                       , PatientInfo.Age, string.Empty, string.Empty, string.Empty, OutRegInfo.MDCR_DD, OutRegInfo.MDCR_DEPT_CD, OutRegInfo.MDCR_DR_CD, 0);

                        popRefer.ShowDialog(this);
                        popRefer.Dispose();
                    }
                }
                else
                {
                    if (OnShowPop != null)
                        OnShowPop();
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show(ex.Message, "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PopUpForm(string frmName)
        {
            try
            {
                switch (frmName)
                {
                    case "REFER":
                        //ViewChoosePlace();
                        OnShowPop();
                        break;
                    case "USER":
                        if (cboDcntRdiaCd.Value != null && StringService.IsNvl(cboDcntRdiaCd.SelectedItem.DataValue.ToString(), "NO").Equals("NO"))
                            return;

                        popSearchUser popUser = new popSearchUser();
                        popUser.ShowDialog(this);
                        if (popUser.DialogResult == DialogResult.OK)
                        {
                            txtDcntRdiaEmno.Text = popUser.USER_CD;
                            txtDcntRdiaEmnm.Text = popUser.USER_NM;
                        }
                        popUser.Dispose();
                        break;
                    case "USER_NM":
                        popSearchUser popUserNm = new popSearchUser("USER_NM", txtDcntRdiaEmnm.Text.Trim(), true);
                        popUserNm.ShowDialog(this);
                        if (popUserNm.DialogResult == DialogResult.OK)
                        {
                            txtDcntRdiaEmno.Text = popUserNm.USER_CD;
                            txtDcntRdiaEmnm.Text = popUserNm.USER_NM;
                        }
                        popUserNm.Dispose();
                        break;
                    case "PCLR":
                        //if(OutRegInfo.PID)
                        frmPatientPclrMatrP popPclrMatr = new frmPatientPclrMatrP(OutRegInfo.PID, "0", "O", "P");
                        popPclrMatr.BaseMDI = this.BaseMDI;
                        popPclrMatr.ShowDialog(this);
                        popPclrMatr.Dispose();
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show(ex.Message, "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 예약 진료 가능여부를 확인한다.
        /// </summary>
        private void CheckMdcrApntPossibleYn()
        {
            try
            {
                string mdcrdeptcd = String.Empty;
                string mdcrdrcd = String.Empty;
                string mdcrdd = String.Empty;
                string mdcrtime = String.Empty;
                string apntyn = String.Empty;
                string mdcrapntyn = String.Empty;

                mdcrdeptcd = cboMdcrDeptCd.Value == null ? "" : cboMdcrDeptCd.SelectedItem.DataValue.ToString();
                mdcrdrcd = cboMdcrDrCd.Value == null ? "" : cboMdcrDrCd.SelectedItem.DataValue.ToString();
                mdcrdd = dteMdcrDd.DateTimeValue.ToString("yyyyMMdd");
                mdcrtime = mskMdcrTime.Text.Replace(":", "");
                apntyn = cboApntYn.Value == null ? "" : cboApntYn.SelectedItem.DataValue.ToString();

                mdcrapntyn = DBService.ExecuteScalar(SqlPack.Function.FN_PA_PRC_DRSCHEDULE(), mdcrdeptcd
                                                                                            , mdcrdrcd
                                                                                            , mdcrdd
                                                                                            , mdcrtime
                                                                                            , apntyn).ToString();

                if (!StringService.IsNvl(mdcrapntyn, "Y").Equals("Y"))
                {
                    mdcrtime = StringService.IsNvl(mdcrtime, DateTimeService.ConvertDateTimeStringToFormatString(DateTimeService.NowDateTimeNoneSeperatorString(), "HHmm"));

                    // 2018-05-30 현재 안쓰므로 주석
                    //lblApntPosYn.Text = mdcrtime.Substring(0, 2) + ":" + mdcrtime.Substring(2, 2) + " 진료불가";
                    //lblApntPosYn.Visible = true;
                    //lblApntPosYn.Appearance.ForeColor = Color.Red;
                }
                else
                {
                    //lblApntPosYn.Visible = false; // 2018-05-30 현재 안쓰므로 주석
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        public void Appointment(string pid, string otptadmsdvcd, string deptcd, string drcd)
        {
            try
            {
                ScreenParameters param = new ScreenParameters();

                param.Add("pid", pid);
                param.Add("otptadmsdvcd", otptadmsdvcd);
                param.Add("deptcd", deptcd);
                param.Add("drcd", drcd);

                //this.CallPopUp((BaseMDI)(this.ParentForm.ParentForm) , this, "Lime.PA.dll", "Lime.PA.ucfDrAppMaE", "의사별예약관리", param);
                this.CallPopUp(this, "Lime.PA.dll", "Lime.PA.ucfDrAppMaE", "의사별예약관리", param);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show(ex.Message, "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        /// <summary>
        /// 콤보박스에 코드와 함께 값을 보여준다.
        /// </summary>
        private void SetCodeCombo(LxComboBox cbo, DataTable dt, string valueMember, string displayMember, string DefaultValue)
        {
            try
            {
                if (cbo.Items.Count == 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        cbo.Items.Add(dt.Rows[i][valueMember].ToString(), "[" + dt.Rows[i][valueMember].ToString() + "]" + dt.Rows[i][displayMember].ToString());
                    }
                }

                cbo.SelectValue(DefaultValue);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show(ex.Message, "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 한글이면 True, 아니면 False
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private bool isKorean(string data)
        {
            try
            {
                char[] charArr = data.ToCharArray();
                foreach (char word in charArr)
                {
                    if (!(char.GetUnicodeCategory(word) == System.Globalization.UnicodeCategory.OtherLetter))
                    {
                        return false;
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show(ex.Message, "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }


        /// <summary>
        /// 동일한 접수정보로 저장하는지 확인.
        /// </summary>
        /// <returns></returns>
        public void CheckDupData()
        {
            // 건강보험이거나 의료급여이고 신환이 아니고 응급실 내원건이 아닌 경우
            if ((OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("1") || OutRegInfo.INSN_TYCD.Substring(0, 1).Equals("2")) && !OutRegInfo.NEW_PID_YN.Equals("Y") && !OutRegInfo.INSN_CLAM_DEPT_CD.Equals("24")
                && !OutRegInfo.CMHS_DVCD.Equals("R"))
            {
                string ptmdcrstatdvcd = StringService.IsNvl(DBService.ExecuteScalar(SQL.PA.Sql.SelectPtMdcrDvcdOfPaOpatRt(), OutRegInfo.PID
                                                                                                                            , OutRegInfo.MDCR_DD
                                                                                                                            , OutRegInfo.MDCR_DEPT_CD
                                                                                                                            , OutRegInfo.MDCR_DR_CD
                                                                                                                            , OutRegInfo.INSN_TYCD
                                                                                                                            , OutRegInfo.ASST_TYCD
                                                                                                                            , cboDisasterSupt.SelectedValue.Equals("NO") ? "0" : cboDisasterSupt.SelectedValue
                                                                                                                            , cboMcchCmptDvcd.SelectedValue).ToString(), "0");

                if (ptmdcrstatdvcd.Equals("9"))
                    throw new Exception("당일 진료부서/진료의사/보험유형/진찰료산정구분이\r\n동일한 과취소된 접수정보가 존재합니다.\r\n\r\n추가 접수하지 않고 해당과에서 과취소된 접수정보를 취소하면 됩니다.");
                else if (!ptmdcrstatdvcd.Equals("0"))
                    throw new Exception("당일 진료부서/진료의사/보험유형/진찰료산정구분이\r\n동일한 접수정보가 존재합니다.\r\n추가 접수 불가합니다.");
            }
        }

        /// <summary>
        /// 주야구분코드 콤보박스 세팅
        /// </summary>
        public void SetDayNightCombobox()
        {
            try
            {
                cboDYNT_DVCD_DRG.SuspendLayout();

                cboDYNT_DVCD_DRG.SelectIndex(0);

                string timeDvcd = "";
                string msg = "";

                // ++++++++++++++++++++++++++++++++++++++
                // 1. PR_PA_COM_TIMEDVCD 주야 구분을 취득한다.
                // ++++++++++++++++++++++++++++++++++++++
                if (!SqlPack.Procedure.PR_PA_COM_TIMEDVCD(dteMdcrDd.DateTime.ToString("yyyyMMdd"), mskMdcrTime.Text.Replace(":", ""), "1", ref timeDvcd, ref msg))
                {
                    // 콤보박스에 세팅한다.
                    cboDYNT_DVCD_DRG.SelectValue(timeDvcd);

                    LxMessage.ShowError(string.Format("주/야구분 세팅 중 오류가 발생했습니다.(PR_PA_COM_TIMEDVCD)\r\n{0}", msg));
                    return;
                }

                // ++++++++++++++++++++++++++++++++++++++
                // 2. 주민등록번호 취득
                // ++++++++++++++++++++++++++++++++++++++
                string frrn = "";
                string srrn = "";

                // 신환의 경우
                if (StringService.IsNull(OutRegInfo.PID))
                {
                    if (GetPatientRRNO != null)
                        GetPatientRRNO(ref frrn, ref srrn);
                }
                // 구환의 경우
                else
                {
                    tempPatientInfo.PID = OutRegInfo.PID;
                    tempPatientInfo.Load();

                    frrn = tempPatientInfo.FRRN;
                    srrn = tempPatientInfo.SRRN_ECPT;
                }

                // 취득하지 못한 경우 리턴.
                if (StringService.IsNull(frrn) || StringService.IsNull(srrn))
                    return;

                string ages = "";
                string agedvcd = "";
                string errMsg = "";

                string mdcr_dd = dteMdcrDd.DateTime.ToString("yyyyMMdd");

                // ++++++++++++++++++++++++++++++++++++++
                // 3. PR_PA_COM_AGEDVCD 나이 구분을 취득한다.
                // ++++++++++++++++++++++++++++++++++++++
                if (!SqlPack.Procedure.PR_PA_COM_AGEDVCD(frrn, srrn, mdcr_dd, ref ages, ref agedvcd, ref errMsg))
                {
                    LxMessage.ShowError(string.Format("주/야구분 세팅 중 오류가 발생했습니다.(PR_PA_COM_AGEDVCD)\r\n{0}", msg));
                    return;
                }

                if (StringService.IsNotNull(errMsg))
                {
                    LxMessage.ShowError(string.Format("주/야구분 세팅 중 오류가 발생했습니다.\r\n{0}", errMsg));
                    return;
                }

                // 심야인 경우, 나이 계산한다.
                if (timeDvcd.Equals("S"))
                {
                    // 베스티안 서울병원 종병==>병원 떼문에 dopack 쓰면 안됨
                    string bykn_dvcd = DBService.ExecuteScalar($@"SELECT FN_BI_READ_BIHOSPMA('0000001', '{mdcr_dd}', 'BYKN_DVCD') FROM DUAL").ToString();

                    // 병원급이면서 6세 미만(AGE_DVCD <= '4')이면 심야 'S'
                    if (bykn_dvcd.Equals("3") && int.Parse(agedvcd) <= 4)
                    {
                        timeDvcd = "S";
                    }
                    else
                    {
                        int cnt = int.Parse(DBService.ExecuteScalar("SELECT COUNT(*) FROM BIHODYMA WHERE PBHL_DD = '{0}' AND PBHL_ADTN_APLY_YN = 'Y'", dteMdcrDd.DateTime.ToString("yyyyMMdd")).ToString());
                        bool SunDay = (dteMdcrDd.DateTime.DayOfWeek == DayOfWeek.Sunday);

                        // 공휴일이거나 일요일이면 휴일 'H'
                        if (cnt > 0 || SunDay)
                            timeDvcd = "H";
                        // 아니면 야간 'N'
                        else
                            timeDvcd = "N";
                    }
                }

                // 콤보박스에 세팅한다.
                cboDYNT_DVCD_DRG.SelectValue(timeDvcd);
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.ShowError(ex.Message);
            }
            finally
            {
                cboDYNT_DVCD_DRG.ResumeLayout();
            }
        }

        /// <summary>
        /// 주/야 콤보박스 세팅.
        /// </summary>
        private void SetDayNight()
        {
            try
            {
                //주간야간
                //if (cboDYNT_DVCD_DRG.Items.Count == 0)
                cboDYNT_DVCD_DRG.SetComboItems(OverallCodeList.GetDataList("DYNT_DVCD_DRG"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");

                string timeDvcd = "";
                string msg = "";

                if (!SqlPack.Procedure.PR_PA_COM_TIMEDVCD(dteMdcrDd.DateTime.ToString("yyyyMMdd")
                                                       , mskMdcrTime.Text.Replace(":", "")
                                                       , "1"
                                                       , ref timeDvcd
                                                       , ref msg
                    ))
                {
                    LxMessage.Show("주/야구분 세팅 중 오류가 발생했습니다.(PR_PA_COM_TIMEDVCD)\r\n" + msg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    string ages = "";
                    string agedvcd = "";
                    string errMsg = "";

                    if (!this.OutRegInfo.PID.Equals(""))
                    {
                        this.PatientInfo.Load(this.OutRegInfo.PID);
                        if (!SqlPack.Procedure.PR_PA_COM_AGEDVCD(PatientInfo.FRRN
                                                                , PatientInfo.SRRN_ECPT
                                                                , dteMdcrDd.DateTime.ToString("yyyyMMdd")
                                                                , ref ages
                                                                , ref agedvcd
                                                                , ref errMsg
                            ))
                        {
                            //LxMessage.Show("주/야구분 세팅 중 오류가 발생했습니다.(PR_PA_COM_AGEDVCD)\r\n" + msg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        }
                        else
                        {
                            if (!errMsg.Equals(""))
                                LxMessage.Show("주/야구분 세팅 중 오류가 발생했습니다.(PR_PA_COM_AGEDVCD)\r\n" + msg, "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                            if (timeDvcd.Equals("S")) //심야인 경우
                            {
                                //병원급이면서 PR_PA_COM_TIMEDVCD 가 심야이면서 1세 미만이면 심야, 아니면 야간.
                                if (DOPack.HospitalInfo.BYKN_DVCD.Equals("3")
                                 && timeDvcd.Equals("S")
                                 && (int.Parse(agedvcd) <= 4) // YDG 2018-08-13 <= 4
                                    )
                                {
                                    timeDvcd = "S";
                                }
                                else
                                {
                                    int cnt = int.Parse(DBService.ExecuteScalar("SELECT COUNT(*) FROM BIHODYMA WHERE PBHL_DD = '{0}' AND PBHL_ADTN_APLY_YN = 'Y'", dteMdcrDd.DateTime.ToString("yyyyMMdd")).ToString());

                                    //YDG 2018-08-23
                                    bool SunDay = (dteMdcrDd.DateTime.DayOfWeek == DayOfWeek.Sunday);

                                    if (cnt > 0) //공휴일이면
                                        timeDvcd = "H";
                                    else if (SunDay)
                                        timeDvcd = "H";
                                    else
                                        timeDvcd = "N";
                                }
                            }
                        }
                    }

                    cboDYNT_DVCD_DRG.SelectValue(timeDvcd);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show(ex.Message, "알림", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        #endregion Method : Private Method

        #region Event : Event Process

        public void Control_ValueChanged(object sender, EventArgs e)
        {
            SetInputValueChanged((Control)sender);
        }

        private void txtDcntRdiaEmnm_EditorButtonClick(object sender, Infragistics.Win.UltraWinEditors.EditorButtonEventArgs e)
        {
            if (!txtDcntRdiaEmnm.ReadOnly)
                PopUpForm("USER");
        }

        private void txtRefrInstno_EditorButtonClick(object sender, Infragistics.Win.UltraWinEditors.EditorButtonEventArgs e)
        {
            PopUpForm("REFER");
        }

        private void txtDcntRdiaEmnm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
                SetInputValueChanged((Control)sender);
        }

        private void Control_Leave(object sender, EventArgs e)
        {
            if ((sender == mskMdcrTime) || (sender == dteMdcrDd)) //진료일자, 진료시간
            {
                SetInputValueChanged((Control)sender);

                SetDayNightCombobox();
            }

            #region [ 할인사번 ]
            if (sender == txtDcntRdiaEmnm) //할인사번
            {
                //할인직원명이 NULL이면, 숨겨둔 컨트롤의 할인사번도 NULL세팅.
                if (string.IsNullOrWhiteSpace(txtDcntRdiaEmnm.Text))
                {
                    txtDcntRdiaEmno.Text = "";
                    //cboDcntRdiaCd.SelectedValue = "NO";
                    //txtDcntRdiaEmnm.ReadOnly = true;
                }
                else //할인직원명이 있을 때, 숨겨진 사번과 직원명을 비교한다.
                {
                    string name = DBService.ExecuteScalar(SQL.Function.SelectFN_BI_READ_USERNM(), txtDcntRdiaEmno.Text).ToString();
                    if (!name.Equals(txtDcntRdiaEmnm.Text))
                    {
                        //LxMessage.Show("유효하지 않은 직원명입니다.\r\n직원명 입력 후 Enter를 누르시거나 우측 버튼을 눌러 직원을 다시한번 선택해주세요.","알림",MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        txtDcntRdiaEmnm.Focus();
                        return;
                    }
                }
            }
            #endregion [ 할인사번 ]

            #region [ 진료과목 ]
            if (sender == cboMdcrDeptCd)
            {
                if (cboMdcrDeptCd.Value == null)
                    return;

                bool isValue = false;
                for (int i = 0; i < cboMdcrDeptCd.Items.Count; i++)
                {
                    if (cboMdcrDeptCd.Items[i].DataValue.Equals(cboMdcrDeptCd.Value == null ? "" : cboMdcrDeptCd.Value.ToString()))
                        isValue = true;
                }

                if (!isValue)
                {
                    cboMdcrDeptCd.Focus();
                    LxMessage.Show("입력한 진료과목코드에 해당하는 진료과목명이 존재하지 않습니다.\r\n진료과코드를 다시 확인해주세요.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
            }
            #endregion [ 진료과목 ]

        }

        private void txtPtPclrMatr_EditorButtonClick(object sender, Infragistics.Win.UltraWinEditors.EditorButtonEventArgs e)
        {
            PopUpForm("PCLR");
        }

        private void btnApntReg_Click(object sender, EventArgs e)
        {
            if (StringService.IsNull(OutRegInfo.PID))
            {
                LxMessage.Show("환자를 선택해주세요", "확인", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Appointment(OutRegInfo.PID, "O", cboMdcrDeptCd.SelectedItem.DataValue.ToString(), cboMdcrDrCd.SelectedItem.DataValue.ToString());
        }

        #endregion Event : Event Process

        #region Method : Raised Event
        public void OnPatientSelected(string argsValue)
        {
            SelectDataEventArgs args = new SelectDataEventArgs(argsValue);
            if (this.PatientSelected != null)
            {
                this.PatientSelected(this, args);
            }
        }
        #endregion

        #region EventArgs
        public class SelectDataEventArgs : EventArgs
        {
            private string m_SeletedUserControl = String.Empty;

            public string SeletedUserControl
            {
                get { return m_SeletedUserControl; }
                set { m_SeletedUserControl = value; }
            }
            public SelectDataEventArgs(string SeletedUserControl)
            {
                this.m_SeletedUserControl = SeletedUserControl;
            }

        }

        //YJS 추가, 콤보박스 접힐 때 코드가 잘 보이게 하기 위해.
        private void cboMdcrDeptCd_AfterCloseUp(object sender, EventArgs e)
        {
            cboMdcrDeptCd.Select(0, 0);
        }

        private void txtOtherHospital_EditorButtonClick(object sender, Infragistics.Win.UltraWinEditors.EditorButtonEventArgs e)
        {
            if (!txtOtherHospital.Enabled)
                return;

            string cmhsMotvDvcd = cboCmhsMotvDvcd.SelectedValue.ToString();
            if (!cmhsMotvDvcd.Equals("03") && !cmhsMotvDvcd.Equals("08"))
            {
                LxMessage.ShowError("내원경로가 [타병원경유], [구급차 이송] 시에만 선택 가능합니다");
                return;
            }

            popOverallCodeE popup = new popOverallCodeE("CHMS_MOTV1_CD", "병원 선택");

            try
            {
                popup.ShowDialog(this);

                if (StringService.IsNull(popup.ReturnCode))
                    return;

                m_OtherHospitalCd = popup.ReturnCode;

                popup.Dispose();
                // 종합코드 OVERALLCODELIST에서 못 가져온다.... 바로 추가한 거 사용할 경우가 있으므로
                m_OtherHospitalNm = DBService.ExecuteScalar(string.Format("SELECT LWRN_OVRL_CDNM FROM BICDINDT WHERE OVRL_CD ='CHMS_MOTV1_CD' AND LWRN_OVRL_CD = '{0}' ", m_OtherHospitalCd)).ToString();
                txtOtherHospital.Text = m_OtherHospitalNm;
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.ShowError(ex.Message);
            }
            finally
            {
                popup.Dispose();
                popup = null;
            }
        }

        private void cboCmhsMotvDvcd_ValueChanged(object sender, EventArgs e)
        {
            string cmhsMotvDvcd = cboCmhsMotvDvcd.SelectedValue.ToString();

            if (!cmhsMotvDvcd.Equals("03") && !cmhsMotvDvcd.Equals("08"))
            {
                m_OtherHospitalCd = "";
                m_OtherHospitalNm = "";
                txtOtherHospital.Text = "";
            }
        }

        void cboPayQlfcDvcd_TextChanged(object sender, EventArgs e)
        {
            clsPACommon.SetComboboxForeColor(cboPayQlfcDvcd, "01_PAYQLFCDVCD");
        }

        void cboInsnTycd_TextChanged(object sender, EventArgs e)
        {
            clsPACommon.SetComboboxForeColor(cboInsnTycd, "02_INSNTYCD");
        }

        void cboMcchCmptDvcd_TextChanged(object sender, EventArgs e)
        {
            clsPACommon.SetComboboxForeColor(cboMcchCmptDvcd, "03_MCCHCMPTDVCD");
        }

        private void CboCmhsDvcd_ValueChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(OutRegInfo.PID))
                return;

            if (cboCmhsDvcd.SelectedValue.Equals("R"))
            {
                // 재진인 경우 초진으로 세팅
                if (cboFrvsRvstDvcd.SelectedValue.Equals("3"))
                {
                    cboFrvsRvstDvcd.SelectValue("2");
                    LxMessage.ShowInformation("내원구분이 [건강진단결과서]인 경우,\r\n초재구분은 [초진]으로 세팅됩니다.");
                }
            }
            else if (OutRegInfo.NEW_PID_YN != "Y")
            {
                // 초재구분을 다시 계산해보자. (메시지 없이 자동 세팅)
                string msg = string.Empty;
                string frvs_rvst_dvcd = string.Empty;
                if (SqlPack.Procedure.PR_PA_PRC_FRVSRVSTSET(OutRegInfo.PID, OutRegInfo.PT_CMHS_NO, OutRegInfo.MDCR_DD, OutRegInfo.INSN_CLAM_DEPT_CD, ref frvs_rvst_dvcd, ref msg))
                {
                    cboFrvsRvstDvcd.SelectValue(frvs_rvst_dvcd);
                }
            }
        }

        private void CboInsnAsstTycd_SelectionChangeCommitted(object sender, EventArgs e)
        {
            clsPACommon.SetAutoB099(cboInsnTycd, cboAsstTycd, cboUschAplyCd);
        }

        #endregion
    }
}
