package web.townsi.com.work.common;

import java.nio.file.AccessDeniedException;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.NoHandlerFoundException;

@ControllerAdvice
@Controller
public class ExceptionController {
	
	private Logger logger = LoggerFactory.getLogger(ExceptionController.class);
	
    @ExceptionHandler(Exception.class)
    @RequestMapping("/error/500")
    public String handleError(HttpServletRequest request, Exception e)   {
        return "error/500";
    }

    @ExceptionHandler(NoHandlerFoundException.class)
    @RequestMapping("/error/404")
    public String handleError404(HttpServletRequest request, Exception e)   {
        return "error/404";
    }
    
    @ExceptionHandler(AccessDeniedException.class)
    @RequestMapping("/error/403")
    public String handleError403(HttpServletRequest request, Exception e)   {
        return "error/403";
    }
    
}