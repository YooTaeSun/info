//********************************************************************************
// Class 명 : clsAdmsIntermediateAmt
// 역    할 : 입원중간금입금관리 
// 작 성 자 : PGH
// 작 성 일 : 2018-01-18
//********************************************************************************
// 수정내역 : 
//********************************************************************************                                                             
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public class clsAdmsIntermediateAmt
    {
        #region Define : Member

        private string m_PID = string.Empty;    // 환자등록번호                     VARCHAR2(10)
        private int m_PT_CMHS_NO = 0;               // 환자내원번호                     NUMBER(10, 0)
        private int m_SQNO = 0;               // 일련번호                         NUMBER(5, 0)
        private string m_DPST_DD = string.Empty;    // 입금일자                         VARCHAR2(8)
        private string m_BILL_NO = string.Empty;    // 영수증번호                       VARCHAR2(13)
        private string m_RCPT_OCRR_UNIQ_NO = string.Empty;    // 수납발생고유번호                 VARCHAR2(13)
        private string m_MDCR_DEPT_CD = string.Empty;    // 진료부서코드                     VARCHAR2(10)
        private string m_MDCR_DR_CD = string.Empty;    // 진료의사코드                     VARCHAR2(10)
        private string m_INSN_TYCD = string.Empty;    // 보험유형코드                     VARCHAR2(2)
        private string m_ASST_TYCD = string.Empty;    // 보조유형코드                     VARCHAR2(2)
        private string m_DPST_DVCD = string.Empty;    // 입금구분코드                     VARCHAR2(2)
        private int m_CARD_AMT = 0;               // 카드금액                         NUMBER(10, 0)
        private string m_BANO = string.Empty;    // 계좌번호                         VARCHAR2(20)
        private string m_BNAC_DPPR_NM = string.Empty;    // 계좌입금자명                     VARCHAR2(50)
        private string m_BNAC_DPST_DD = string.Empty;    // 계좌입금일자                     VARCHAR2(8)
        private int m_BNAC_DPST_AMT = 0;               // 계좌입금금액                     NUMBER(10, 0)
        private int m_CASH_DPST_AMT = 0;               // 현금입금금액                     NUMBER(10, 0)
        private string m_CMPY_APLY_YN = string.Empty;    // 정산적용여부                     VARCHAR2(1)
        private string m_PCLR_MATR = string.Empty;    // 특이사항                         VARCHAR2(200)
        private string m_ROW_STAT_DVCD = string.Empty;    // 행상태구분코드                   VARCHAR2(2)
        private string m_RGST_DT = string.Empty;    // 등록일시                         VARCHAR2(14)
        private string m_RGSTR_ID = string.Empty;    // 등록자ID                         VARCHAR2(10)

        private string m_ADMS_DD = string.Empty;    // 입원일자
        private string m_DSCH_DD = string.Empty;    // 퇴원일자

        #endregion Define : Member

        #region Define : Member Property

        public string PID { get { return m_PID; } set { m_PID = value; } }    // 환자등록번호                     VARCHAR2(10)
        public int PT_CMHS_NO { get { return m_PT_CMHS_NO; } set { m_PT_CMHS_NO = value; } }    // 환자내원번호                     NUMBER(10, 0)
        public int SQNO { get { return m_SQNO; } set { m_SQNO = value; } }    // 일련번호                         NUMBER(5, 0)
        public string DPST_DD { get { return m_DPST_DD; } set { m_DPST_DD = value; } }    // 입금일자                         VARCHAR2(8)
        public string BILL_NO { get { return m_BILL_NO; } set { m_BILL_NO = value; } }    // 영수증번호                       VARCHAR2(13)
        public string RCPT_OCRR_UNIQ_NO { get { return m_RCPT_OCRR_UNIQ_NO; } set { m_RCPT_OCRR_UNIQ_NO = value; } }    // 수납발생고유번호                 VARCHAR2(13)
        public string MDCR_DEPT_CD { get { return m_MDCR_DEPT_CD; } set { m_MDCR_DEPT_CD = value; } }    // 진료부서코드                     VARCHAR2(10)
        public string MDCR_DR_CD { get { return m_MDCR_DR_CD; } set { m_MDCR_DR_CD = value; } }    // 진료의사코드                     VARCHAR2(10)
        public string INSN_TYCD { get { return m_INSN_TYCD; } set { m_INSN_TYCD = value; } }    // 보험유형코드                     VARCHAR2(2)
        public string ASST_TYCD { get { return m_ASST_TYCD; } set { m_ASST_TYCD = value; } }    // 보조유형코드                     VARCHAR2(2)
        public string DPST_DVCD { get { return m_DPST_DVCD; } set { m_DPST_DVCD = value; } }    // 입금구분코드                     VARCHAR2(2)
        public int CARD_AMT { get { return m_CARD_AMT; } set { m_CARD_AMT = value; } }    // 카드금액                         NUMBER(10, 0)
        public string BANO { get { return m_BANO; } set { m_BANO = value; } }    // 계좌번호                         VARCHAR2(20)
        public string BNAC_DPPR_NM { get { return m_BNAC_DPPR_NM; } set { m_BNAC_DPPR_NM = value; } }    // 계좌입금자명                     VARCHAR2(50)
        public string BNAC_DPST_DD { get { return m_BNAC_DPST_DD; } set { m_BNAC_DPST_DD = value; } }    // 계좌입금일자                     VARCHAR2(8)
        public int BNAC_DPST_AMT { get { return m_BNAC_DPST_AMT; } set { m_BNAC_DPST_AMT = value; } }    // 계좌입금금액                     NUMBER(10, 0)
        public int CASH_DPST_AMT { get { return m_CASH_DPST_AMT; } set { m_CASH_DPST_AMT = value; } }    // 현금입금금액                     NUMBER(10, 0)
        public string CMPY_APLY_YN { get { return m_CMPY_APLY_YN; } set { m_CMPY_APLY_YN = value; } }    // 정산적용여부                     VARCHAR2(1)
        public string PCLR_MATR { get { return m_PCLR_MATR; } set { m_PCLR_MATR = value; } }    // 특이사항                         VARCHAR2(200)
        public string ROW_STAT_DVCD { get { return m_ROW_STAT_DVCD; } set { m_ROW_STAT_DVCD = value; } }    // 행상태구분코드                   VARCHAR2(2)
        public string RGST_DT { get { return m_RGST_DT; } set { m_RGST_DT = value; } }    // 등록일시                         VARCHAR2(14)
        public string RGSTR_ID { get { return m_RGSTR_ID; } set { m_RGSTR_ID = value; } }    // 등록자ID   

        public string ADMS_DD { get { return m_ADMS_DD; } set { m_ADMS_DD = value; } }    // 입원일자
        public string DSCH_DD { get { return m_DSCH_DD; } set { m_DSCH_DD = value; } }    // 퇴원일자                      VARCHAR2(10)

        #endregion Define : Member Property

        #region Construction

        public clsAdmsIntermediateAmt()
        {
            Clear();
        }

        #endregion Construction

        #region Method : Initialize

        public void Clear()
        {
            m_PID = string.Empty;
            m_PT_CMHS_NO = 0;
            m_SQNO = 0;
            m_DPST_DD = string.Empty;
            m_BILL_NO = string.Empty;
            m_RCPT_OCRR_UNIQ_NO = string.Empty;
            m_MDCR_DEPT_CD = string.Empty;
            m_MDCR_DR_CD = string.Empty;
            m_INSN_TYCD = string.Empty;
            m_ASST_TYCD = string.Empty;
            m_DPST_DVCD = string.Empty;
            m_CARD_AMT = 0;
            m_BANO = string.Empty;
            m_BNAC_DPPR_NM = string.Empty;
            m_BNAC_DPST_DD = string.Empty;
            m_BNAC_DPST_AMT = 0;
            m_CASH_DPST_AMT = 0;
            m_CMPY_APLY_YN = string.Empty;
            m_PCLR_MATR = string.Empty;
            m_ROW_STAT_DVCD = string.Empty;
            m_RGST_DT = string.Empty;
            m_RGSTR_ID = string.Empty;

            m_ADMS_DD = string.Empty;
            m_DSCH_DD = string.Empty;
        }
        #endregion

        #region Method : Public Method

        public bool SavePAIMDMMA(ref string msg)
        {

            try
            {
                int sqno = 0;
                // 일련번호 MAX값을 가져온다.
                sqno = DBService.ExecuteInteger(SQL.PA.Sql.SelectMaxSqnoPAIMDMMA(), m_PID
                                                                                  , m_PT_CMHS_NO.ToString());
                if (sqno < 0)
                {
                    msg = "일련번호 MAX 값을 조회하는 중 오류를 발생헀습니다. \r\n " +
                          "Method : [SavePAIMDMMA -> SelectMaxSqnoPAIMDMMA] \r\n  " +
                          "오류메시지 : " + DBService.ErrorMessage;
                    DBService.RollbackTransaction();
                    return false;
                }

                sqno++;
                this.m_SQNO = sqno;

                if (!InsertPAIMDMMA(ref msg))
                {
                    return false;
                }

            }
            catch (Exception ex)
            {
                msg = "입원중간금 생성 중 오류를 발생했습니다.\r\n " +
                      "Method :  SavePAIMDMMA  \r\n " +
                      "오류 메시지[ex] : " + ex.Message;
                DBService.RollbackTransaction();
                return false;
            }
            return true;
        }

        #endregion

        #region Method : Private Method

        /// <summary>
        /// 입원 중간금 입금 정보를 생성한다.
        /// </summary>
        /// <param name="msg">오류메시지</param>
        /// <returns></returns>
        private bool InsertPAIMDMMA(ref string msg)
        {
            try
            {

                if (!DBService.ExecuteNonQuery(SQL.PA.Sql.InsertPAIMDMMA(), m_PID
                                                                          , m_PT_CMHS_NO.ToString()
                                                                          , m_SQNO.ToString()
                                                                          , m_DPST_DD
                                                                          , m_BILL_NO
                                                                          , m_RCPT_OCRR_UNIQ_NO
                                                                          , m_MDCR_DEPT_CD
                                                                          , m_MDCR_DR_CD
                                                                          , m_INSN_TYCD
                                                                          , m_ASST_TYCD
                                                                          , m_DPST_DVCD
                                                                          , m_CARD_AMT.ToString()
                                                                          , m_BANO
                                                                          , m_BNAC_DPPR_NM
                                                                          , m_BNAC_DPST_DD
                                                                          , m_BNAC_DPST_AMT.ToString()
                                                                          , m_CASH_DPST_AMT.ToString()
                                                                          , m_CMPY_APLY_YN
                                                                          , m_PCLR_MATR
                                                                          , m_ROW_STAT_DVCD
                                                                          , m_RGST_DT
                                                                          , DOPack.UserInfo.USER_CD))
                {
                    msg = "입원중간금 정보를 저장하는 중 오류를 발생헀습니다. \r\n " +
                          "Method : InsertPAIMDMMA \r\n  " +
                          "오류메시지[db] : " + DBService.ErrorMessage;
                    DBService.RollbackTransaction();
                    return false;
                }

            }
            catch (Exception ex)
            {
                msg = "입원중간금 생성 중 오류를 발생했습니다.\r\n " +
                      "Method :  InsertPAIMDMMA  \r\n " +
                      "오류 메시지[ex] : " + ex.Message;
                DBService.RollbackTransaction();
                return false;
            }
            return true;
        }

        #endregion 
    }
}
