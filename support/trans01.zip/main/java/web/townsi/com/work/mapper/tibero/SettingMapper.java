//package web.townsi.com.work.mapper.tibero;
//
//
//import java.lang.invoke.MethodHandles;
//import java.util.HashMap;
//import java.util.List;
//
//import org.apache.commons.lang3.StringUtils;
//import org.mybatis.spring.SqlSessionTemplate;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public class SettingMapper {
//	
//	@Autowired
//	@Qualifier("sqlSessionTibero01")
//	protected SqlSessionTemplate sqlSessionTibero01;
//	
//	@Autowired
//	@Qualifier("sqlSessionPostgresql01")
//	protected SqlSessionTemplate sqlSessionPostgresql01;
//	
//	private Logger logger = LoggerFactory.getLogger(this.getClass());
//
//	private final static String NAMESPACE = MethodHandles.lookup().lookupClass().getCanonicalName() + ".";
//	
//	private SqlSessionTemplate getSqlSession(HashMap params) {
//		String dbName = StringUtils.defaultString((String)params.get("dbName"), "MYSQL");
//		SqlSessionTemplate sqlSession = null;
//		if (dbName.equals("MYSQL")) {
//			sqlSession = this.sqlSessionTibero01;
//		} else if (dbName.equals("POSTGRESQL")) {
//			sqlSession = this.sqlSessionPostgresql01;
//		}
//		return sqlSession;
//	}	
//
////    public Object insert(String queryId, Object params) {
////    	return sqlSession.insert(NAMESPACE + queryId, params);
////    }
////    public Object update(String queryId, Object params) {
////    	SqlSessionTemplate sqlSession = getSqlSession(params);
////    	return sqlSession.update(NAMESPACE + queryId, params);
////    }
////    public Object delete(String queryId, Object params) {
////    	SqlSessionTemplate sqlSession = getSqlSession(params);
////    	return sqlSession.delete(NAMESPACE + queryId, params);
////    }
////	public List selectList(String queryId, Object params) {
////		return sqlSession.selectList(NAMESPACE + queryId, params);
////	}
////	public Object selectOne(String queryId, Object params) {
////		return sqlSession.selectOne(NAMESPACE + queryId, params);
////	}
//
//	public List<HashMap> selectTableInfo(HashMap params){
//		SqlSessionTemplate sqlSession = getSqlSession(params);
//		return sqlSession.selectList(NAMESPACE + "selectTableInfo", params);
//	}
//
//	public List<HashMap> selectTableList(HashMap params){
//		SqlSessionTemplate sqlSession = getSqlSession(params);
//		return sqlSession.selectList(NAMESPACE + "selectTableList", params);
//	}
//
//	public HashMap selectSqlInfo(HashMap params){
//		SqlSessionTemplate sqlSession = getSqlSession(params);
//		return sqlSession.selectOne(NAMESPACE + "selectSqlInfo", params);
//	}
//
//	public String selectTableComment(HashMap params){
//		SqlSessionTemplate sqlSession = getSqlSession(params);
//		return sqlSession.selectOne(NAMESPACE + "selectTableComment", params);
//	}
//	
//	public int selectTableAutoIncrement(HashMap params){
//		SqlSessionTemplate sqlSession = getSqlSession(params);
//		return sqlSession.selectOne(NAMESPACE + "selectTableAutoIncrement", params);
//	}
//}