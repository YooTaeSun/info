//********************************************************************
// Class 명 : ucObillInf1
// 역    할 : 영수증정보을 보여주고 영수처리하는 UserControl
// 작 성 자 : PGH
// 작 성 일 : 2017-09-27
//********************************************************************
// 수정내역 : 
//********************************************************************

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lime.BusinessControls;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public partial class ucObillInf1 : BaseUserControl
    {
        #region Delegate & RaiseEvent

        public delegate void TotlMdcrAmt(int totlmdcramt);
        public event TotlMdcrAmt OnTotlMdcrAmt;

        #endregion

        #region Member

        clsOutBillBreakdown m_BillBd = new clsOutBillBreakdown();
        clsOutBillTemp m_BillTp = new clsOutBillTemp();
        clsCardCashPermitInfo m_PermitInfo = new clsCardCashPermitInfo();
        clsTraiLimitInfo m_LimitInfo = new clsTraiLimitInfo();
        clsOutReceiptBreakDown m_OutRecBd = new clsOutReceiptBreakDown();

        private string m_CashBillYn = String.Empty;
        private string m_TextChangedYn = String.Empty;
        private string m_old_billno = string.Empty;
        private bool m_Locked = false;

        public StringCollection m_StrCol = new StringCollection();

        private Dictionary<string, Control> m_AllControls = new Dictionary<string, Control>();
        private Lime.BusinessControls.clsPAReceiptInfo m_ReceiptPrint = new Lime.BusinessControls.clsPAReceiptInfo();
        private popImageViewer m_viewer = null;

        #endregion

        #region Property

        public clsCardCashPermitInfo PermitInfo
        {
            get { return m_PermitInfo; }
            set { m_PermitInfo = value; }
        }

        public clsOutBillTemp BillTp
        {
            get { return m_BillTp; }
            set { m_BillTp = value; }
        }

        public clsOutBillBreakdown BillBd
        {
            get { return m_BillBd; }
            set { m_BillBd = value; }
        }

        public clsTraiLimitInfo LimitInfo
        {
            get { return m_LimitInfo; }
            set { m_LimitInfo = value; }
        }

        public clsOutReceiptBreakDown OutRecBd
        {
            get { return m_OutRecBd; }
            set { m_OutRecBd = value; }
        }

        public string Old_BillNo
        {
            set { m_old_billno = value; }
        }

        public bool SystemLocked
        {
            get
            {
                return this.m_Locked;
            }
            set
            {
                this.m_Locked = value;
                SetButtonLocked();
            }
        }

        private void SetButtonLocked()
        {
            btnPermitCancel.Enabled = !m_Locked;
            txtCashRcptAmt.Enabled = !m_Locked;
            txtCardRcptAmt.Enabled = !m_Locked;
            txtBnacRcptAmt.Enabled = !m_Locked;
        }

        #endregion

        #region Constructor

        public ucObillInf1()
        {
            InitializeComponent();
        }

        #endregion

        #region Screen Load

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode) return;

            Initialize();
            InitializeEvent();
            ClearControlData();
        }

        #endregion Screen Load

        #region Method : Initialize Method

        private void Initialize()
        {
            //m_AllControls = new Dictionary<string, Control>();

            m_AllControls.Clear();

            clsPACommon.GetAllControlsTextBoxComboBox(m_AllControls, this.Controls);

            lxTitlePanel1.TitleText = "영수정보";
            m_TextChangedYn = "N";

            if (this.DesignMode) return;

            lblCashRcpt.Appearance.BackColor = Color.FromArgb(242, 244, 247);

            clsPACommon.SetComboPA(cboDcntRdiaCd, "DCNT_CD", "DCNT_CDNM", "1", DateTimeService.NowDateNoneSeperatorString(), "NO");
            cboSpclDcntDvcd.SetComboItems(OverallCodeList.GetDataList("SPCL_DCNT_DVCD"), COMBO_ADD_ITEM_TYPE.None, "NO");

            DataView uncl_cd = OverallCodeList.GetDataList("UNCL_CD").DefaultView;
            uncl_cd.RowFilter = "ISNULL(ETC_USE_CNTS_1, 'Y') <> 'N'";
            cboUnclCd.SetComboItems(uncl_cd.ToTable(), COMBO_ADD_ITEM_TYPE.AddNone, "NO");

            if (ConfigService.GetConfigValueString("PA", "TABLET_RECEIPT", "PREVIEW", "N") != "Y")
                btnTabletReceipt.Visible = false;
        }

        private void InitializeEvent()
        {
            txtCashRcptAmt.TextChanged += Control_TextChanged;
            txtCardRcptAmt.TextChanged += Control_TextChanged;
            txtBnacRcptAmt.TextChanged += Control_TextChanged;
            txtSpclDcntAmt.TextChanged += Control_TextChanged;
            txtDcntRdiaAmt.TextChanged += Control_TextChanged;
            txtUnclAmt.TextChanged += Control_TextChanged;   //미수금액

            txtSuptAmt.TextChanged += Control_TextChanged;   //공단지원금
            txtTbrcCtctSuptAmt.TextChanged += Control_TextChanged;   //결핵접촉지원
            txtVcntClamAmt.TextChanged += Control_TextChanged;   //예방접종지원금액
            txtEmrgSuptAmt.TextChanged += Control_TextChanged;   //긴급지원금
            //txtVtrnAmt.TextChanged         += Control_TextChanged;   //수직감액금액
            txtCttrUnclAplyAmt.TextChanged += Control_TextChanged;   // 협력지원금액

            txtDcntRdiaEmnm.KeyDown += txtDcntRdiaEmnm_KeyDown;

            cboBldnYn.SelectionChangeCommitted += cboBldnYn_SelectionChangeCommitted;
            txtBlodRdiaAmt.Leave += TxtControl_Leave;
            txtCashRcptAmt.Leave += TxtControl_Leave;
            txtCardRcptAmt.Leave += TxtControl_Leave;
            txtBnacRcptAmt.Leave += TxtControl_Leave;
            txtDcntRdiaAmt.Leave += TxtControl_Leave;
            txtSpclDcntAmt.Leave += TxtControl_Leave;
            txtUnclAmt.Leave += TxtControl_Leave;
            txtEmrgSuptAmt.Leave += TxtControl_Leave;
            //txtVtrnAmt.Leave     += TxtControl_Leave;
            txtCttrUnclAplyAmt.Leave += TxtControl_Leave;
            txtTbrcCtctSuptAmt.Leave += TxtControl_Leave;

            txtCashRcptAmt.EditorButtonClick += txtCashRcptAmt_EditorButtonClick;
            txtCardRcptAmt.EditorButtonClick += txtCashRcptAmt_EditorButtonClick;
            txtBnacRcptAmt.EditorButtonClick += txtCashRcptAmt_EditorButtonClick;
            txtDcntRdiaEmnm.EditorButtonClick += txtDcntRdiaEmnm_EditorButtonClick;
            txtBlodRdiaAmt.EditorButtonClick += txtBlodRdiaAmt_EditorButtonClick;
            txtFrtmCashRcptAmt.EditorButtonClick += txtFrtmCashRcptAmt_EditorButtonClick;
            txtFrtmBnacAmt.EditorButtonClick += txtFrtmCashRcptAmt_EditorButtonClick;
            txtCttrUnclAplyAmt.EditorButtonClick += txtCttrUnclAplyAmt_EditorButtonClick;

            cboDcntRdiaCd.ValueChanged += Combo_ValueChanged;
            cboSpclDcntDvcd.ValueChanged += Combo_ValueChanged;
            cboUnclCd.ValueChanged += Combo_ValueChanged;

            btnBillNoApply.Click += btnBillNoApply_Click;
            btnTabletReceipt.Click += btnTabletReceipt_Click;
            Disposed += ucObillInf1_Disposed;
        }

        #endregion

        #region Method : Public Method

        public void Clear()
        {
            PermitInfo.Clear();
            BillBd.Clear();
            BillTp.Clear();
            LimitInfo.Clear();
            lblCashRcpt.Visible = false;
            OutRecBd.Clear();
            ClearControlData();
            m_StrCol.Clear();
            m_CashBillYn = String.Empty;
            Initialize();
        }

        public void LeaveFocus()
        {
            // 2020-08-27 SJH
            // 현금에 마이너스 금액이 떠있고 그 칸에 0입력후에 F2 눌러서 수납하면 Leave이벤트 발생하지 않아 수납 가능해져 버리는 문제가 있어,
            // 강제로 leave이벤트 태움
            txtFocus.Focus();
        }

        public void DisplayBillInfo(string pid, int ptcmhsno, clsOutRegistrationInfo outreginfo)
        {
            if (BillTp.Load(pid, ptcmhsno))
            {
                ClearControlData();
                m_StrCol.Clear();

                if (outreginfo.DY_WARD_YN.Equals("Y"))
                {
                    m_StrCol.Add("OTPT_ADMS_DVCD", "D");
                }
                else
                {
                    m_StrCol.Add("OTPT_ADMS_DVCD", "O");
                }
                m_StrCol.Add("PID", outreginfo.PID);                         // 환자번호
                m_StrCol.Add("PT_CMHS_NO", outreginfo.PT_CMHS_NO.ToString());       // 환자내원번호
                m_StrCol.Add("MDCR_DD", outreginfo.MDCR_DD);                     // 진료일자(정산종료일자)
                m_StrCol.Add("CMPY_STRT_DD", outreginfo.MDCR_DD);                     // 정산시작일자
                m_StrCol.Add("CMPY_END_DD", outreginfo.MDCR_DD);                     // 정산종료일자
                m_StrCol.Add("INSN_TYCD", outreginfo.INSN_TYCD);                   // 보험유형코드
                m_StrCol.Add("ASST_TYCD", outreginfo.ASST_TYCD);                   // 보조유형코드
                m_StrCol.Add("DCNT_RDIA_CD", outreginfo.DCNT_RDIA_CD);                // 할인감액코드
                m_StrCol.Add("DCNT_RDIA_EMNO", outreginfo.DCNT_RDIA_EMNO);              // 할인감액사번
                m_StrCol.Add("CFSC_RGNO_CD", outreginfo.CFSC_RGNO_CD);                // 산정특례기호코드
                m_StrCol.Add("USCH_APLY_CD", outreginfo.USCH_APLY_CD);                // 본인부담코드
                m_StrCol.Add("DY_WARD_YN", outreginfo.DY_WARD_YN);                  // 낮병동여부
                m_StrCol.Add("OTPT_DRG_YN", outreginfo.OTPT_DRG_YN);                 // 외래DRG여부
                m_StrCol.Add("VTRN_PT_YN", outreginfo.VTRN_PT_YN);                  // 보훈환자여부
                m_StrCol.Add("MOMR_AGE_DVCD", outreginfo.MOMR_AGE_DVCD);               // 유공자연령구분코드
                m_StrCol.Add("INDP_MOMR_YN", outreginfo.INDP_MOMR_YN);                // 독립유공자여부
                m_StrCol.Add("LOAD_YN", "Y");                                    // 영수정보가 로드된 경우 "Y"

                SetDcntAmt();
                SetBillInfo();
            }

        }

        /// <summary>
        /// 영수할 카드 현금 금액과 카드/현금 승인금액을 비교하여 수납진행여부를 판단한다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public int CheckCardCashPermitAmt(ref string msg)
        {
            int cashamt = 0;
            int bnacamt = 0;
            int cardamt = 0;

            DataTable dt = new DataTable();
            if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectPermitAmt(), ref dt, BillTp.PID
                                                                              , BillTp.MDCR_DD
                                                                              , BillTp.PT_CMHS_NO.ToString()))
            {
                cashamt = int.Parse(txtCashRcptAmt.Text.Replace(",", ""));
                bnacamt = int.Parse(txtBnacRcptAmt.Text.Replace(",", ""));
                cardamt = int.Parse(txtCardRcptAmt.Text.Replace(",", ""));

                if (dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];

                    if (!row["CARD_PRMT_AMT"].ToString().Equals(cardamt.ToString()) && cardamt > 0)
                    {
                        msg = "카드수납금액이랑 카드승인금액이 동일하지 않습니다.";
                        return 0;
                    }
                    if (!row["CASH_PRMT_AMT"].ToString().Equals(cashamt.ToString()) && chkCashPrmtYn.Checked && cashamt > 0)
                    {
                        msg = "현금수납금액이랑 현금승인금액이 동일하지 않습니다.";
                        return 0;
                    }
                    if (!row["BNAC_PRMT_AMT"].ToString().Equals(bnacamt.ToString()) && chkCashPrmtYn.Checked && bnacamt > 0)
                    {
                        msg = "통장수납금액이랑 통장승인금액이 동일하지 않습니다.";
                        return 0;
                    }
                }
                else
                {
                    if (cardamt > 0)
                    {
                        msg = "카드수납이 있습니다. 카드 승인처리후 수납하세요.";
                        return 0;
                    }
                    else
                    {
                        if (chkCashPrmtYn.Checked)
                        {
                            if (cashamt > 0)
                            {
                                msg = "현금수납이 있습니다. 현금영수증 승인처리후 수납처리하세요";
                                return 0;
                            }

                            if (bnacamt > 0)
                            {
                                msg = "통장수납이 있습니다. 현금영수증(통장) 승인처리후 수납처리하세요";
                                return 0;
                            }
                        }
                    }
                }
            }
            else
            {
                return -1;
            }
            return 1;
        }

        /// <summary>
        /// 신용카드/현금영수증 승인 프로그램 실행.
        /// </summary>
        /// <param name="permitrqstdvcd">신용요청구분코드</param>
        /// <param name="otptadmsdvcd">외래입원구분코드</param>
        /// <param name="cardcashdvcd">카드현금구분코드 01:카드, 02:현금, 03:취소 A:저장시, 취소시</param>
        /// <param name="pid">환자등록번호</param>
        /// <param name="ptcmhsno">환자내원번호</param>
        /// <param name="cmpydd">정산일자</param>
        public void PopUpCardCashPermit(string permitrqstdvcd, string otptadmsdvcd, string cardcashdvcd, string pid, string ptcmhsno, string cmpydd)
        {
            //Leave 이벤트에 안탄다.
            SetAmountOfBillInfo(txtCardRcptAmt);

            Application.DoEvents();

            frmCardCashPermitP popPermit = null;

            try
            {
                int ptsharamt = 0;          // 본인총액
                int dcntrdiaamt = 0;        // 할인금액
                int blodrdiaamt = 0;        // 현혈감액
                int spcldcntamt = 0;        // 추가할인
                int cardamt = 0;            // 카드금액
                int cashamt = 0;            // 현금금액
                int bnacamt = 0;            // 통장금액
                int unclamt = 0;            // 미수금액

                int frtmcardamt = 0;        // 기카드금액
                int frtmcashamt = 0;        // 기현금금액
                int frtmbnacamt = 0;        // 기통장금액
                int totlfrtmamt = 0;        // 기총금액

                int cardamt_ing = 0;        // 수납전카드승인금액 
                int cashamt_ing = 0;        // 수납전현금승인금액
                int bnacamt_ing = 0;        // 수납전통장승인금액

                int cardprmtamt = 0;
                int cashprmtamt = 0;
                int bnacprmtamt = 0;
                int oldcardamt = 0;

                int emrgsuptamt = 0;
                int suptamt = 0;
                int cttrunclaplyamt = 0;

                string msg = String.Empty;

                // 수납이 반영되지 않은 신용 승인 여부를 리턴한다.
                if (!clsPACommon.CheckCreditPermit(otptadmsdvcd, pid, ptcmhsno, ref msg))
                {
                    DialogResult dr = LxMessage.Show("수납되지 않은 승인 내역이 존재합니다.\r\n" +
                                                     "먼저 승인 취소하고 승인 작업을 하시기 바랍니다.\r\n\r\n" +
                                                     "예        : 승인 취소로 이동\r\n" +
                                                     "아니오  : 재승인으로 이동\r\n" +
                                                     "취소     : 작업 취소"
                                                   , "확인", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    if (dr.Equals(DialogResult.No))
                    {
                        permitrqstdvcd = "P";
                    }
                    else if (dr.Equals(DialogResult.Yes))
                    {
                        permitrqstdvcd = "C";
                    }
                    else
                    {
                        return;
                    }
                }

                PermitInfo.Clear();

                PermitInfo.PRMT_RQST_DVCD = permitrqstdvcd;                                  // 승인요청구분코드
                PermitInfo.PID = pid;                                             // 환자등록번호
                PermitInfo.RQST_DD = DateTimeService.NowDateNoneSeperatorString();    // 요청일자
                PermitInfo.RCPT_OCRR_UNIQ_NO = "NO";                                            // 수납발생고유번호
                PermitInfo.CCCS_OCRR_DVCD = "O";                                             // 발생구분코드 : 외래
                PermitInfo.PT_CMHS_NO = int.Parse(ptcmhsno);                             // 환자내원번호
                PermitInfo.BILL_NO = "NO";                                            // 영수증번호
                PermitInfo.CMPY_DD = cmpydd;                                          // 정산일자 : 외래수납 = 진료일자
                PermitInfo.CASH_CARD_DVCD = cardcashdvcd;                                    // 현금카드구분코드
                PermitInfo.OLD_BILL_NO = m_old_billno;

                int.TryParse(txtPtSharAmt.Text.Replace(",", ""), out ptsharamt);                // 본인총액
                int.TryParse(txtDcntRdiaAmt.Text.Replace(",", ""), out dcntrdiaamt);            // 할인금액
                int.TryParse(txtBlodRdiaAmt.Text.Replace(",", ""), out blodrdiaamt);            // 현혈감액
                int.TryParse(txtSpclDcntAmt.Text.Replace(",", ""), out spcldcntamt);            // 추가할인

                int.TryParse(txtCardRcptAmt.Text.Replace(",", ""), out cardamt);                // 카드영수금액
                int.TryParse(txtCashRcptAmt.Text.Replace(",", ""), out cashamt);                // 현금영수금액
                int.TryParse(txtBnacRcptAmt.Text.Replace(",", ""), out bnacamt);                // 통장영수금액
                int.TryParse(txtUnclAmt.Text.Replace(",", ""), out unclamt);                    // 미수금액

                int.TryParse(txtFrtmCardRcptAmt.Text.Replace(",", ""), out frtmcardamt);        // 기카드영수금액
                int.TryParse(txtFrtmCashRcptAmt.Text.Replace(",", ""), out frtmcashamt);        // 기현금영수금액
                int.TryParse(txtFrtmBnacAmt.Text.Replace(",", ""), out frtmbnacamt);            // 기통장영수금액

                int.TryParse(txtCardRcptAmt_ing.Text.Replace(",", ""), out cardamt_ing);        // 수납전카드승인금액
                int.TryParse(txtCashRcptAmt_ing.Text.Replace(",", ""), out cashamt_ing);        // 수납전현금승인금액
                int.TryParse(txtBnacRcptAmt_ing.Text.Replace(",", ""), out bnacamt_ing);        // 수납전통장승인금액

                int.TryParse(txtEmrgSuptAmt.Text.Replace(",", ""), out emrgsuptamt);            // 의료비지원
                int.TryParse(txtSuptAmt.Text.Replace(",", ""), out suptamt);                    // 공단지원금
                int.TryParse(txtCttrUnclAplyAmt.Text.Replace(",", ""), out cttrunclaplyamt);    // 협력지원금액

                totlfrtmamt = frtmcardamt + frtmcashamt + frtmbnacamt;                          // 기수납총금액

                // 카드의 경우 ("01")
                int totalAmt = 0;

                if (cardcashdvcd.Equals("01"))
                {
                    oldcardamt = cardamt;

                    if (permitrqstdvcd.Equals("P") && cardamt <= 0)
                    {
                        PermitInfo.TOTAL_AMT = cardamt + cashamt + bnacamt + unclamt;
                        PermitInfo.CARD_AMT = cardamt + cashamt + bnacamt + unclamt;
                        PermitInfo.CASH_AMT = 0;
                        PermitInfo.BNAC_AMT = 0;
                    }
                    else
                    {
                        PermitInfo.TOTAL_AMT = cardamt + cashamt + bnacamt + unclamt;
                        PermitInfo.CARD_AMT = cardamt;
                        PermitInfo.CASH_AMT = 0;
                        PermitInfo.BNAC_AMT = 0;
                    }
                }
                // 현금의 경우 ("02")
                else if (cardcashdvcd.Equals("02"))
                {
                    PermitInfo.TOTAL_AMT = cardamt + cashamt + bnacamt + unclamt;
                    PermitInfo.CARD_AMT = 0;
                    PermitInfo.CASH_AMT = cashamt + bnacamt + unclamt;
                    PermitInfo.BNAC_AMT = 0;
                }
                else if (cardcashdvcd.Equals("03"))
                {
                    PermitInfo.TOTAL_AMT = cardamt + cashamt + bnacamt + unclamt;
                    PermitInfo.CARD_AMT = 0;
                    PermitInfo.CASH_AMT = 0;
                    PermitInfo.BNAC_AMT = cashamt + bnacamt + unclamt;
                }
                // 저장시, 취소시 ("A")
                else
                {
                    PermitInfo.TOTAL_AMT = cardamt + cashamt + bnacamt;
                    PermitInfo.CARD_AMT = 0;
                    PermitInfo.CASH_AMT = 0;
                    PermitInfo.BNAC_AMT = 0;
                }

                totalAmt = PermitInfo.TOTAL_AMT;

                if ((PermitInfo.TOTAL_AMT + totlfrtmamt) <= 0 && permitrqstdvcd.Equals("P"))
                {
                    LxMessage.Show("승인할 금액이 없습니다. 승인요청할 수 없습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // VAN사 무승인 수기승인처리여부
                popPermit = new frmCardCashPermitP(PermitInfo);
                popPermit.BaseMDI = this.BaseMDI;
                popPermit.ShowDialog(this);

                if (popPermit.DialogResult == DialogResult.OK)
                {
                    // PACAPEMA테이블에서 카드, 현금 승인 금액을 읽는다.
                    int cardtemp = 0;
                    int cashtemp = 0;
                    int bnactemp = 0;

                    DataTable dt = new DataTable();

                    string sqltext = SQL.PA.Sql.SelectPACAPEMA_CardCashAmount_Change(pid, ptcmhsno, cmpydd);

                    DBService.ExecuteDataTable(sqltext, ref dt);

                    // 존재하는 경우, 값을 변경한다.
                    if (!dt.Rows.Count.Equals(0) && (StringService.IsNotNull(dt.Rows[0]["CARD_AMT"].ToString()) || StringService.IsNotNull(dt.Rows[0]["CASH_AMT"].ToString()) || StringService.IsNotNull(dt.Rows[0]["BNAC_AMT"].ToString())))
                    {
                        txtUnclAmt.Text = "0";
                        unclamt = 0;

                        int cardtemp_c = 0;
                        int cashtemp_c = 0;
                        int bnactemp_c = 0;
                        int cardtemp_ing = 0;
                        int cashtemp_ing = 0;
                        int bnactemp_ing = 0;

                        // 현금에 세팅할 값 : 본인총액 - 할인금액 - 현혈감액 - 추가할인 - 기현금금액
                        //              - 기카드금액 - 기통장금액 - 미수금액 - 의료비지원 - 공단지원금 - 협력지원금액
                        int setcashtemp = ptsharamt - dcntrdiaamt - blodrdiaamt - spcldcntamt - frtmcashamt
                                        - frtmcardamt - frtmbnacamt - unclamt - emrgsuptamt - suptamt - cttrunclaplyamt;

                        foreach (DataRow dr in dt.Rows)
                        {
                            int.TryParse(dr["CARD_AMT"].ToString(), out cardtemp);
                            int.TryParse(dr["CASH_AMT"].ToString(), out cashtemp);
                            int.TryParse(dr["BNAC_AMT"].ToString(), out bnactemp);

                            if (dr["PRMT_RQST_DVCD"].ToString() == "P")
                            {
                                cardtemp_ing += cardtemp;   //수납전까지 카드승인금액
                                bnactemp_ing += bnactemp;   //수납전까지 카드승인금액
                                cashtemp_ing += cashtemp;   //수납전까지 현금승인금액                               
                            }
                            else if (dr["PRMT_RQST_DVCD"].ToString() == "C")
                            {
                                if (dr["CNCL_YN"].ToString() == "Y")
                                {
                                    cardtemp_c += cardtemp;     //수납전까지 기카드승인취소금액
                                    bnactemp_c += bnactemp;     //수납전까지 기카드승인취소금액
                                    cashtemp_c += cashtemp;     //수납전까지 기현금승인취소금액
                                }
                                else
                                {
                                    cardtemp_ing += cardtemp;   //수납전까지 카드승인금액
                                    bnactemp_ing += bnactemp;   //수납전까지 카드승인금액
                                    cashtemp_ing += cashtemp;   //수납전까지 현금승인금액 
                                }
                            }

                            setcashtemp -= (cardtemp + bnactemp + cashtemp);
                        }

                        txtCardRcptAmt_ing.Text = cardtemp_ing.ToString("#,##0");
                        txtBnacRcptAmt_ing.Text = bnactemp_ing.ToString("#,##0");
                        txtCashRcptAmt_ing.Text = cashtemp_ing.ToString("#,##0");
                        txtFrtmCardRcptAmt_C.Text = cardtemp_c.ToString("#,##0");
                        txtFrtmBnacAmt_C.Text = bnactemp_c.ToString("#,##0");
                        txtFrtmCashRcptAmt_C.Text = cashtemp_c.ToString("#,##0");

                        txtCardRcptAmt.Text = "0";                              //승인할 금액이므로 0원으로 세팅
                        txtBnacRcptAmt.Text = "0";                              //승인할 금액이므로 0원으로 세팅

                        if (ConfigService.GetConfigValueBool("PA", "RECEIPT", "TRNC_YN", true))
                            setcashtemp = Convert.ToInt32(Math.Truncate(Convert.ToDouble(setcashtemp) / 10)) * 10;
                        txtCashRcptAmt.Text = setcashtemp.ToString("#,##0");
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                LxMessage.Show("오류내용 : " + ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (popPermit != null)
                {
                    popPermit.Dispose();
                    popPermit = null;
                }
            }
        }

        /// <summary>
        /// 미수사유, 환불사유, 할인사유를 체크한다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public int CheckReasonIsOrNot(ref string msg)
        {
            string unclcd = (cboUnclCd.Value == null ? "" : cboUnclCd.Value.ToString());
            int unclamt = int.Parse(txtUnclAmt.Text.Replace(",", ""));
            string unclresn = txtUnclResn.Text;
            string rfndresn = txtRfndResn.Text;
            string dcntresn = txtDcntResn.Text;
            int rcptamt = int.Parse(txtCashRcptAmt.Text.Replace(",", "")) + int.Parse(txtCardRcptAmt.Text.Replace(",", "")) + int.Parse(txtBnacRcptAmt.Text.Replace(",", ""))
                        + int.Parse(txtFrtmCashRcptAmt.Text.Replace(",", "")) + int.Parse(txtFrtmCardRcptAmt.Text.Replace(",", "")) + int.Parse(txtFrtmBnacAmt.Text.Replace(",", ""))
                        + int.Parse(txtCashRcptAmt_ing.Text.Replace(",", "")) + int.Parse(txtCardRcptAmt_ing.Text.Replace(",", "")) + int.Parse(txtBnacRcptAmt_ing.Text.Replace(",", ""))
                        + int.Parse(txtFrtmCashRcptAmt_C.Text.Replace(",", "")) + int.Parse(txtFrtmCardRcptAmt_C.Text.Replace(",", "")) + int.Parse(txtFrtmBnacAmt_C.Text.Replace(",", ""));
            int dcntamt = int.Parse(txtDcntRdiaAmt.Text.Replace(",", ""));

            if (unclamt < 0)
            {
                msg = "미수금액이 0원보다 작을 수 없습니다.";
                txtUnclAmt.Focus();
                return 0;
            }

            if (unclamt > 0 && unclcd == "NO")
            {
                msg = "미수금액이 존재합니다. 미수코드를 입력해 주세요.";
                cboUnclCd.Focus();
                return 0;
            }

            if (unclamt == 0 && unclcd != "NO")
            {
                msg = "미수코드가 입력되었습니다. 미수금액을 입력하세요.";
                txtUnclAmt.Focus();
                return 0;
            }

            // 2018-07-23 SEO 미수코드가 '기타'인 경우에만 미수사유를 입력하게 한다.
            if (unclamt > 0 && unclcd.Equals("99") && StringService.IsNull(unclresn))
            {
                msg = "미수금액이 존재합니다.\r\n미수코드가 기타일 경우, 미수사유를 입력해야 합니다.";
                txtUnclResn.Focus();
                return 0;
            }

            if (rcptamt < 0 && StringService.IsNull(rfndresn))
            {
                msg = "환불금액이 존재합니다. 환불사유를 입력해 주세요.";
                txtRfndResn.Focus();
                return 0;
            }


            // 2018-07-23 SEO 할인코드에 대한 할인사유를 작성하지 않도록 설정한다.
            /*
            if (dcntamt > 0 && StringService.IsNull(dcntresn))
            {
                msg = "할인감액금액이 존재합니다. 할인감액사유를 입력해 주세요.";
                txtDcntResn.Focus();
                return 0;
            }
             * */
            return 1;
        }

        /// <summary>
        /// 영수증내역을 저장한다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public int SavePaObilBd(string cfsc_rgno_cd, ref string msg)
        {
            BillBd.PID = BillTp.PID;    //환자등록번호            
            BillBd.PT_CMHS_NO = BillTp.PT_CMHS_NO;               //환자내원번호            
            //BillBd.RCPT_SQNO                     = BillTp.RCPT_SQNO             ;               //수납일련번호            
            BillBd.MDCR_DD = BillTp.MDCR_DD;    //진료일자                
            //BillBd.BILL_NO                       = BillTp.BILL_NO               ;    //영수증번호              
            //BillBd.RCPT_OCRR_UNIQ_NO             = "0"                          ;    //수납발생고유번호        
            //BillBd.INSN_TYCD                     = BillTp.INSN_TYCD             ;    //보험유형코드            
            //BillBd.ASST_TYCD                     = BillTp.ASST_TYCD             ;    //보조유형코드            
            //BillBd.ASCT_RGNO_CD                  = BillTp.ASCT_RGNO_CD          ;    //조합기호코드            
            //BillBd.MDCR_DEPT_CD                  = BillTp.MDCR_DEPT_CD          ;    //진료부서코드            
            //BillBd.MDCR_DR_CD                    = BillTp.MDCR_DR_CD            ;    //진료의사코드            
            BillBd.TOTL_MDCR_AMT = BillTp.TOTL_MDCR_AMT;               //총진료금액              
            BillBd.PAY_TAMT = BillTp.PAY_TAMT;               //급여총금액              
            BillBd.INSN_100_TAMT = BillTp.INSN_100_TAMT;               //보험100총금액           
            BillBd.SCNG_PAY_TAMT = BillTp.SCNG_PAY_TAMT;               //선별급여총금액          
            BillBd.NOPY_TAMT = BillTp.NOPY_TAMT;               //비급여총금액            
            BillBd.CLAM_NOPY_TAMT = BillTp.CLAM_NOPY_TAMT;               //청구비급여총금액        
            BillBd.ADED_VALU_TAX_TAMT = BillTp.ADED_VALU_TAX_TAMT;               //부가가치세총금액        
            BillBd.VTRN_TAMT = BillTp.VTRN_TAMT;               //보훈총금액              
            BillBd.BYKN_ADTN_AMT = BillTp.BYKN_ADTN_AMT;               //종별가산금액            
            BillBd.SMCR_AMT = BillTp.SMCR_AMT;               //선택진료금액            
            BillBd.PAY_USCH_AMT = BillTp.PAY_USCH_AMT;               //급여본인부담금액        
            BillBd.SCNG_PAY_USCH_AMT = BillTp.SCNG_PAY_USCH_AMT;               //선별급여본인부담금액    
            BillBd.PAY_CLAM_AMT = BillTp.PAY_CLAM_AMT;               //급여청구금액            
            BillBd.SCNG_PAY_CLAM_AMT = BillTp.SCNG_PAY_CLAM_AMT;               //선별급여청구금액        
            BillBd.MDCN_UPLM_DIAM = BillTp.MDCN_UPLM_DIAM;               //약제상한차액            
            BillBd.HMPT_PAY_TAMT = BillTp.HMPT_PAY_TAMT;               //수진자급여총금액        
            BillBd.DSBL_FUND_AMT = BillTp.DSBL_FUND_AMT;               //장애기금금액            
            BillBd.PFAN_AMT = BillTp.PFAN_AMT;               //대불금액                
            BillBd.USCH_UPLM_AMT = BillTp.USCH_UPLM_AMT;               //본인부담상한금액        
            BillBd.SUPT_AMT = int.Parse(txtSuptAmt.Text.Replace(",", ""));             //지원금액                
            BillBd.EMRG_SUPT_AMT = int.Parse(txtEmrgSuptAmt.Text.Replace(",", ""));              //긴급지원금액            

            BillBd.TBRC_CTCT_SUPT_AMT = BillTp.TBRC_CTCT_SUPT_AMT;  //결핵접촉지원금액  

            /*
            BillBd.TBRC_CTCT_SUPT_AMT = int.Parse(txtTbrcCtctSuptAmt.Text.Replace(",", ""));                   //결핵접촉지원금액     

            // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
            DataTable dt = new DataTable();
            string sqltext = string.Format(@"
    SELECT * 
      FROM PAOPATRT 
     WHERE PID = '{0}' 
       AND PT_CMHS_NO = {1} 
       AND ROW_STAT_DVCD IN ('A', 'I') 
       AND (CFSC_RGNO_CD LIKE '%F010%' OR TBRC_DVCD LIKE '%F010%')", BillTp.PID, BillTp.PT_CMHS_NO);
            if (!DBService.ExecuteDataTable(sqltext, ref dt))
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                msg = "결핵접촉지원금액을 조회하는 중 에러가 발생했습니다." + error;
                return -1;
            }

            if (dt.Rows.Count > 0)
            {
                BillBd.TBRC_CTCT_SUPT_AMT = BillTp.SUPT_AMT;
                BillBd.SUPT_AMT = 0;
            }
            // ++++++++++++++++++++++++++++++++++++++++++++++++++++++
             * */

            BillBd.MTWM_CLAM_AMT = BillTp.MTWM_CLAM_AMT;               //산모청구금액            
            BillBd.MTWM_BLCE = BillTp.MTWM_BLCE;               //산모잔액                
            BillBd.MTWM_PAY_CLAM_AMT = BillTp.MTWM_PAY_CLAM_AMT;               //산모급여청구금액        
            BillBd.MTWM_I100_CLAM_AMT = BillTp.MTWM_I100_CLAM_AMT;               //산모보험100청구금액     
            BillBd.MTWM_NOPY_CLAM_AMT = BillTp.MTWM_NOPY_CLAM_AMT;               //산모비급여청구금액      
            BillBd.MTWM_SCPY_CLAM_AMT = BillTp.MTWM_SCPY_CLAM_AMT;               //산모선별급여청구금액    
            BillBd.INDP_MOMR_CLAM_AMT = BillTp.INDP_MOMR_CLAM_AMT;               //독립유공자청구금액      
            BillBd.VCNT_CLAM_AMT = int.Parse(txtVcntClamAmt.Text.Replace(",", ""));               //예방접종청구금액        
            BillBd.CT_USCH_AMT = BillTp.CT_USCH_AMT;               //CT본인부담금액          
            BillBd.MRI_USCH_AMT = BillTp.MRI_USCH_AMT;               //MRI본인부담금액         
            BillBd.PET_USCH_AMT = BillTp.PET_USCH_AMT;               //PET본인부담금액         
            BillBd.FRTM_CARD_RCPT_AMT = int.Parse(txtFrtmCardRcptAmt.Text.Replace(",", ""));               //이전카드수납금액    
            BillBd.FRTM_CASH_RCPT_AMT = int.Parse(txtFrtmCashRcptAmt.Text.Replace(",", ""));               //이전현금수납금액    
            BillBd.FRTM_BNAC_AMT = int.Parse(txtFrtmBnacAmt.Text.Replace(",", ""));                       //이전계좌금액        
            //BillBd.VTRN_RNE_AMT                  = 0;               //보훈감면금액        
            BillBd.DCNT_RDIA_CD = (cboDcntRdiaCd.Value == null ? "NO" : cboDcntRdiaCd.Value.ToString());    //할인감액코드        
            BillBd.DCNT_RDIA_EMNO = txtDcntRdiaEmno.Text;                        //할인감액직원번호    
            BillBd.DCNT_RDIA_AMT = int.Parse(txtDcntRdiaAmt.Text.Replace(",", ""));                   //할인감액금액        
            BillBd.FRTM_DCNT_RDIA_AMT = int.Parse(txtFrtmDcntRdiaAmt.Text.Replace(",", ""));               //이전할인감액금액  
            BillBd.SPCL_DCNT_DVCD = (cboSpclDcntDvcd.Value == null ? "NO" : cboSpclDcntDvcd.Value.ToString());    //특별할인코드     
            BillBd.SPCL_DCNT_AMT = int.Parse(txtSpclDcntAmt.Text.Replace(",", ""));               //특별할인금액        
            BillBd.BLDN_YN = cboBldnYn.Value == null ? "N" : cboBldnYn.Value.ToString();     //헌혈여부            
            BillBd.BLOD_RDIA_AMT = int.Parse(txtBlodRdiaAmt.Text.Replace(",", ""));               //혈액감액금액        
            //BillBd.VTRD_APLY_DVCD                = String.Empty;    //수직감액적용구분코드
            //BillBd.VTRD_AMT                      = int.Parse(txtVtrnAmt.Text.Replace(",", ""));                  //수직감액금액        
            BillBd.VTRD_AMT = BillTp.VTRD_AMT;                  //수직감액금액        2019-03-19 SJH 수직감액금액대신 협력지원금액으로 변경
                                                                //BillBd.CTTR_NO_CD                    = String.Empty;    //계약처번호코드      
                                                                //BillBd.CTTR_UNCL_APLY_AMT            = 0;               //계약처미수적용금액  

            BillBd.GVRN_CLAM_AMT = BillTp.GVRN_CLAM_AMT;

            // +++++++++++++++++++++++++++++++++++++++++++++
            // 2019-03-19 SJH 수직감액금액대신 협력지원금액으로 변경
            // +++++++++++++++++++++++++++++++++++++++++++++
            BillBd.CTTR_NO_CD = string.Empty;    //계약처번호코드      
            BillBd.CTTR_UNCL_APLY_AMT = 0;               //계약처미수적용금액
            if (!string.IsNullOrWhiteSpace(txtCttrUnclAplyAmt.Text.Replace(",", "")) && txtCttrUnclAplyAmt.Tag != null && !string.IsNullOrWhiteSpace(txtCttrUnclAplyAmt.Tag.ToString()))
            {
                BillBd.CTTR_NO_CD = txtCttrUnclAplyAmt.Tag.ToString();             //계약처번호코드      
                BillBd.CTTR_UNCL_APLY_AMT = int.Parse(txtCttrUnclAplyAmt.Text.Replace(",", ""));       //계약처미수적용금액
            }
            //BillBd.CLNC_UNCL_APLY_AMT            = 0;               //임상미수적용금액    
            //BillBd.GURN_CARD_AMT                 = 0;               //보증카드금액        
            //BillBd.GURN_CASH_AMT                 = 0;               //보증현금금액        
            //BillBd.GURN_BNAC_AMT                 = 0;               //보증계좌금액        
            BillBd.HLLF_MNCS_CLAM_AMT = BillTp.HLLF_MNCS_CLAM_AMT;           //건강생활유지비청구금
            BillBd.HLLF_MNCS_BLCE = BillTp.HLLF_MNCS_BLCE;               //건강생활유지비잔액         
            BillBd.PT_SHAR_AMT = BillTp.PT_SHAR_AMT; // 환자부담금액 
            BillBd.TRNC_AMT = BillTp.TRNC_AMT;    // 절사금액
            BillBd.CARD_RCPT_AMT = int.Parse(txtFrtmCardRcptAmt_C.Text.Replace(",", "")) + int.Parse(txtCardRcptAmt.Text.Replace(",", "")) + int.Parse(txtCardRcptAmt_ing.Text.Replace(",", ""));              //카드수납금액        
            //BillBd.BANO                          = String.Empty;    //계좌번호            
            //BillBd.BNAC_DPPR_NM                  = String.Empty;    //계좌입금자명        
            //BillBd.BNAC_DPST_DD                  = String.Empty;    //계좌입금일자        
            BillBd.BNAC_RCPT_AMT = int.Parse(txtFrtmBnacAmt_C.Text.Replace(",", "")) + int.Parse(txtBnacRcptAmt.Text.Replace(",", "")) + int.Parse(txtBnacRcptAmt_ing.Text.Replace(",", ""));                  //계좌수납금액        
            BillBd.CASH_RCPT_AMT = int.Parse(txtFrtmCashRcptAmt_C.Text.Replace(",", "")) + int.Parse(txtCashRcptAmt.Text.Replace(",", "")) + int.Parse(txtCashRcptAmt_ing.Text.Replace(",", ""));              //현금수납금액        
            BillBd.RFND_RESN = txtRfndResn.Text;    //환불사유            
            BillBd.DCNT_RESN = txtDcntResn.Text;    //할인사유            
            BillBd.UNCL_RESN = txtUnclResn.Text;    //미수사유            
            BillBd.CASH_PRMT_YN = String.Empty;    //현금승인여부        
            BillBd.MDAD_PRMT_NO = String.Empty;    //의료급여승인번호    -
            BillBd.FXAM_MCCS = BillTp.FXAM_MCCS;               //정액진료비          
            BillBd.FXAM_MCCS_REAL_AMT = BillTp.FXAM_MCCS_REAL_AMT;               //정액진료비 실금액   
            BillBd.UNCL_CD = (cboUnclCd.Value == null ? "" : cboUnclCd.Value.ToString());    //미수코드            
            BillBd.UNCL_AMT = int.Parse(txtUnclAmt.Text.Replace(",", ""));               //미수금액            
            BillBd.RCPT_DD = DateTimeService.NowDateNoneSeperatorString();    //수납일자            
            BillBd.RCPT_TIME = DateTimeService.ConvertDateTimeStringToFormatString(DateTimeService.NowDateTimeNoneSeperatorString(), "HHmm");    //수납시간            
            BillBd.AFRS_STAT_DVCD = "5";    //업무상태구분코드    
            BillBd.ROW_STAT_DVCD = "A";    //행상태구분코드      
            BillBd.DLWT_IP_ADDR = ClientEnvironment.IP.Replace(".", "");    //처리IP주소          
            //BillBd.RGST_DT                       = DateTimeService.NowDateTimeNoneSeperatorString();    //등록일시            
            BillBd.RGSTR_ID = DOPack.UserInfo.USER_CD;    //등록자ID            
                                                          //BillBd.NEW_RCPT_RQNO                 = 0;               //새로운 수납일련번호
                                                          //BillBd.NEW_ROW_STAT_DVCD             = "5";

            //원래는 마이너스 금액이 되었다. 허나, 회계연동시 문제가 되어 이로직을 추가함(2019.01.16 박민규) -> 현금수납 통장환불일때 문제가 되어 일단 풀자
            //if (int.Parse(txtCardRcptAmt.Text.Replace(",", "")) < 0 || int.Parse(txtBnacRcptAmt.Text.Replace(",", "")) < 0 || int.Parse(txtCashRcptAmt.Text.Replace(",", "")) < 0)
            //{
            //    msg = "\r\n\r\n카드/현금/통장 수납금액이 0원보다 작을 수 없습니다.\r\n카드/현금영수증을 먼저 취소 후 수납하세요.";
            //    return -1;
            //}

            if (!BillBd.InsertPaObilBd(ref msg))
            {
                return -1;
            }

            // 미수를 발생시킨다.
            if (!BillBd.CreateUnclOcrrInfo(cfsc_rgno_cd, ref msg))
                return -1;

            int cach_rcpt_amt = int.Parse(string.IsNullOrEmpty(txtCashRcptAmt.Text.Replace(",", string.Empty)) ? "0" : txtCashRcptAmt.Text.Replace(",", string.Empty));
            int bnac_rcpt_amt = int.Parse(string.IsNullOrEmpty(txtBnacRcptAmt.Text.Replace(",", string.Empty)) ? "0" : txtBnacRcptAmt.Text.Replace(",", string.Empty));

            //현금영수증도 없고, 카드도 아닐때에는 임시로 카드테이블에 데이터를 발생시킨다.-취소할때 없으면 취소할 방법이 없다.
            if (cach_rcpt_amt > 0)

            {
                if (!SaveNotCashReceipt("02", cach_rcpt_amt, ref msg))
                    return -1;
            }

            if (bnac_rcpt_amt > 0)
            {
                if (!SaveNotCashReceipt("03", bnac_rcpt_amt, ref msg))
                    return -1;
            }

            // 의료급여승인처리
            //clsPACommon.PermitAndCancelMedicalAid(BillBd.PID, BillBd.PT_CMHS_NO, BillBd.RCPT_SQNO, BillBd.RCPT_OCRR_UNIQ_NO, 0, "O", )
            return 1;
        }

        /// <summary>
        /// 영수증내역을 저장한다. - 미수자동
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool SavePaObilBd_Uncl(string pid, int pt_cmhs_no, string cfsc_rgno_cd, int cash_rcpt_amt, int bnac_rcpt_amt, int card_rcpt_amt, int uncl_amt, ref string msg)
        {
            DataTable dtPaObilBd = new DataTable();

            if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOBILBD(), ref dtPaObilBd, pid, pt_cmhs_no.ToString(), "C"))
                return false;

            BillBd.PID = dtPaObilBd.Rows[0]["PID"].ToString();                                              //환자등록번호            
            BillBd.PT_CMHS_NO = int.Parse(dtPaObilBd.Rows[0]["PT_CMHS_NO"].ToString());                     //환자내원번호                               
            BillBd.MDCR_DD = dtPaObilBd.Rows[0]["MDCR_DD"].ToString();                                      //진료일자                         
            BillBd.TOTL_MDCR_AMT = int.Parse(dtPaObilBd.Rows[0]["TOTL_MDCR_AMT"].ToString());               //총진료금액              
            BillBd.PAY_TAMT = int.Parse(dtPaObilBd.Rows[0]["PAY_TAMT"].ToString());                         //급여총금액              
            BillBd.INSN_100_TAMT = int.Parse(dtPaObilBd.Rows[0]["INSN_100_TAMT"].ToString());               //보험100총금액           
            BillBd.SCNG_PAY_TAMT = int.Parse(dtPaObilBd.Rows[0]["SCNG_PAY_TAMT"].ToString());               //선별급여총금액          
            BillBd.NOPY_TAMT = int.Parse(dtPaObilBd.Rows[0]["NOPY_TAMT"].ToString());                       //비급여총금액            
            BillBd.CLAM_NOPY_TAMT = int.Parse(dtPaObilBd.Rows[0]["CLAM_NOPY_TAMT"].ToString());             //청구비급여총금액        
            BillBd.ADED_VALU_TAX_TAMT = int.Parse(dtPaObilBd.Rows[0]["ADED_VALU_TAX_TAMT"].ToString());     //부가가치세총금액        
            BillBd.VTRN_TAMT = int.Parse(dtPaObilBd.Rows[0]["VTRN_TAMT"].ToString());                       //보훈총금액              
            BillBd.BYKN_ADTN_AMT = int.Parse(dtPaObilBd.Rows[0]["BYKN_ADTN_AMT"].ToString());               //종별가산금액            
            BillBd.SMCR_AMT = int.Parse(dtPaObilBd.Rows[0]["SMCR_AMT"].ToString());                         //선택진료금액            
            BillBd.PAY_USCH_AMT = int.Parse(dtPaObilBd.Rows[0]["PAY_USCH_AMT"].ToString());                 //급여본인부담금액        
            BillBd.SCNG_PAY_USCH_AMT = int.Parse(dtPaObilBd.Rows[0]["SCNG_PAY_USCH_AMT"].ToString());       //선별급여본인부담금액    
            BillBd.PAY_CLAM_AMT = int.Parse(dtPaObilBd.Rows[0]["PAY_CLAM_AMT"].ToString());                 //급여청구금액            
            BillBd.SCNG_PAY_CLAM_AMT = int.Parse(dtPaObilBd.Rows[0]["SCNG_PAY_CLAM_AMT"].ToString());       //선별급여청구금액        
            BillBd.MDCN_UPLM_DIAM = int.Parse(dtPaObilBd.Rows[0]["MDCN_UPLM_DIAM"].ToString());             //약제상한차액            
            BillBd.HMPT_PAY_TAMT = int.Parse(dtPaObilBd.Rows[0]["HMPT_PAY_TAMT"].ToString());               //수진자급여총금액        
            BillBd.DSBL_FUND_AMT = int.Parse(dtPaObilBd.Rows[0]["DSBL_FUND_AMT"].ToString());               //장애기금금액            
            BillBd.PFAN_AMT = int.Parse(dtPaObilBd.Rows[0]["PFAN_AMT"].ToString());                         //대불금액                
            BillBd.USCH_UPLM_AMT = int.Parse(dtPaObilBd.Rows[0]["USCH_UPLM_AMT"].ToString());               //본인부담상한금액      
            BillBd.SUPT_AMT = int.Parse(dtPaObilBd.Rows[0]["SUPT_AMT"].ToString());                         //지원금액                
            BillBd.EMRG_SUPT_AMT = int.Parse(dtPaObilBd.Rows[0]["EMRG_SUPT_AMT"].ToString());               //긴급지원금액            
            BillBd.TBRC_CTCT_SUPT_AMT = int.Parse(dtPaObilBd.Rows[0]["TBRC_CTCT_SUPT_AMT"].ToString());     //결핵접촉지원금액        
            BillBd.MTWM_CLAM_AMT = int.Parse(dtPaObilBd.Rows[0]["MTWM_CLAM_AMT"].ToString()); ;             //산모청구금액            
            BillBd.MTWM_BLCE = int.Parse(dtPaObilBd.Rows[0]["MTWM_BLCE"].ToString());                       //산모잔액                
            BillBd.MTWM_PAY_CLAM_AMT = int.Parse(dtPaObilBd.Rows[0]["MTWM_PAY_CLAM_AMT"].ToString());       //산모급여청구금액        
            BillBd.MTWM_I100_CLAM_AMT = int.Parse(dtPaObilBd.Rows[0]["MTWM_I100_CLAM_AMT"].ToString());     //산모보험100청구금액     
            BillBd.MTWM_NOPY_CLAM_AMT = int.Parse(dtPaObilBd.Rows[0]["MTWM_NOPY_CLAM_AMT"].ToString());     //산모비급여청구금액      
            BillBd.MTWM_SCPY_CLAM_AMT = int.Parse(dtPaObilBd.Rows[0]["MTWM_SCPY_CLAM_AMT"].ToString());     //산모선별급여청구금액    
            BillBd.INDP_MOMR_CLAM_AMT = int.Parse(dtPaObilBd.Rows[0]["INDP_MOMR_CLAM_AMT"].ToString());     //독립유공자청구금액      
            BillBd.VCNT_CLAM_AMT = int.Parse(dtPaObilBd.Rows[0]["VCNT_CLAM_AMT"].ToString());               //예방접종청구금액        
            BillBd.CT_USCH_AMT = int.Parse(dtPaObilBd.Rows[0]["CT_USCH_AMT"].ToString());                   //CT본인부담금액          
            BillBd.MRI_USCH_AMT = int.Parse(dtPaObilBd.Rows[0]["MRI_USCH_AMT"].ToString());                 //MRI본인부담금액         
            BillBd.PET_USCH_AMT = int.Parse(dtPaObilBd.Rows[0]["PET_USCH_AMT"].ToString());                 //PET본인부담금액  
            BillBd.FRTM_CARD_RCPT_AMT = int.Parse(dtPaObilBd.Rows[0]["FRTM_CARD_RCPT_AMT"].ToString()) + int.Parse(dtPaObilBd.Rows[0]["CARD_RCPT_AMT"].ToString());     //이전카드수납금액    
            BillBd.FRTM_CASH_RCPT_AMT = int.Parse(dtPaObilBd.Rows[0]["FRTM_CASH_RCPT_AMT"].ToString()) + int.Parse(dtPaObilBd.Rows[0]["CASH_RCPT_AMT"].ToString());     //이전현금수납금액    
            BillBd.FRTM_BNAC_AMT = int.Parse(dtPaObilBd.Rows[0]["FRTM_BNAC_AMT"].ToString()) + int.Parse(dtPaObilBd.Rows[0]["BNAC_RCPT_AMT"].ToString());               //이전계좌금액     
            BillBd.DCNT_RDIA_CD = dtPaObilBd.Rows[0]["DCNT_RDIA_CD"].ToString();    //할인감액코드        
            BillBd.DCNT_RDIA_EMNO = dtPaObilBd.Rows[0]["DCNT_RDIA_EMNO"].ToString();                        //할인감액직원번호    
            BillBd.DCNT_RDIA_AMT = int.Parse(dtPaObilBd.Rows[0]["DCNT_RDIA_AMT"].ToString());               //할인감액금액        
            BillBd.FRTM_DCNT_RDIA_AMT = int.Parse(dtPaObilBd.Rows[0]["FRTM_DCNT_RDIA_AMT"].ToString());     //이전할인감액금액  
            BillBd.SPCL_DCNT_DVCD = dtPaObilBd.Rows[0]["SPCL_DCNT_DVCD"].ToString();    //특별할인코드     
            BillBd.SPCL_DCNT_AMT = int.Parse(dtPaObilBd.Rows[0]["SPCL_DCNT_AMT"].ToString());               //특별할인금액        
            BillBd.BLDN_YN = dtPaObilBd.Rows[0]["BLDN_YN"].ToString();                                      //헌혈여부            
            BillBd.BLOD_RDIA_AMT = int.Parse(dtPaObilBd.Rows[0]["BLOD_RDIA_AMT"].ToString());               //혈액감액금액        
            BillBd.VTRD_AMT = int.Parse(dtPaObilBd.Rows[0]["VTRD_AMT"].ToString());                         //수직감액금액        
            BillBd.HLLF_MNCS_CLAM_AMT = int.Parse(dtPaObilBd.Rows[0]["HLLF_MNCS_CLAM_AMT"].ToString());     //건강생활유지비청구금
            BillBd.HLLF_MNCS_BLCE = int.Parse(dtPaObilBd.Rows[0]["HLLF_MNCS_BLCE"].ToString());             //건강생활유지비잔액         
            BillBd.PT_SHAR_AMT = int.Parse(dtPaObilBd.Rows[0]["PT_SHAR_AMT"].ToString());                   //환자부담금액 
            BillBd.TRNC_AMT = int.Parse(dtPaObilBd.Rows[0]["TRNC_AMT"].ToString());                         //절사금액

            BillBd.CTTR_NO_CD = dtPaObilBd.Rows[0]["CTTR_NO_CD"].ToString();    //계약처번호코드      
            BillBd.CTTR_UNCL_APLY_AMT = int.Parse(dtPaObilBd.Rows[0]["CTTR_UNCL_APLY_AMT"].ToString()); ;               //계약처미수적용금액

            BillBd.CARD_RCPT_AMT = card_rcpt_amt;                                                           //카드수납금액            
            BillBd.BNAC_RCPT_AMT = bnac_rcpt_amt;                                                           //계좌수납금액        
            BillBd.CASH_RCPT_AMT = cash_rcpt_amt;                                                           //현금수납금액   

            BillBd.RFND_RESN = dtPaObilBd.Rows[0]["RFND_RESN"].ToString();                                  //환불사유            
            BillBd.DCNT_RESN = dtPaObilBd.Rows[0]["DCNT_RESN"].ToString();                                  //할인사유            
            BillBd.UNCL_RESN = uncl_amt == 0 ? string.Empty : dtPaObilBd.Rows[0]["UNCL_RESN"].ToString();   //미수사유            
            BillBd.CASH_PRMT_YN = dtPaObilBd.Rows[0]["CASH_PRMT_YN"].ToString();                            //현금승인여부        
            BillBd.MDAD_PRMT_NO = dtPaObilBd.Rows[0]["MDAD_PRMT_NO"].ToString();                            //의료급여승인번호
            BillBd.FXAM_MCCS = int.Parse(dtPaObilBd.Rows[0]["FXAM_MCCS"].ToString());                       //정액진료비          
            BillBd.FXAM_MCCS_REAL_AMT = int.Parse(dtPaObilBd.Rows[0]["FXAM_MCCS_REAL_AMT"].ToString());     //정액진료비 실금액   
            BillBd.UNCL_CD = uncl_amt == 0 ? "NO" : dtPaObilBd.Rows[0]["UNCL_CD"].ToString();               //미수코드            
            BillBd.UNCL_AMT = uncl_amt;                                                                     //미수금액            
            BillBd.RCPT_DD = DateTimeService.TodayDateNoneSeperatorString();                                //수납일자            
            BillBd.RCPT_TIME = DateTimeService.ConvertDateTimeStringToFormatString(DateTimeService.NowDateTimeNoneSeperatorString(), "HHmm");   //수납시간            
            BillBd.AFRS_STAT_DVCD = "5";                                                                    //업무상태구분코드    
            BillBd.ROW_STAT_DVCD = "A";                                                                     //행상태구분코드      
            BillBd.DLWT_IP_ADDR = ClientEnvironment.IP;                                    //처리IP주소                   
            BillBd.RGSTR_ID = DOPack.UserInfo.USER_CD;                                                      //등록자ID            

            BillBd.GVRN_CLAM_AMT = int.Parse(dtPaObilBd.Rows[0]["GVRN_CLAM_AMT"].ToString());

            if (!BillBd.InsertPaObilBd(ref msg))
                return false;

            // 미수를 발생시킨다.
            if (!BillBd.CreateUnclOcrrInfo(cfsc_rgno_cd, ref msg))
                return false;

            return true;
        }

        /// <summary>
        /// 혈액감액정보의 수납여부를 Update
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool SaveRcptYnOfPaBredMa(ref string msg)
        {
            //혈액감액구분이 "Y"
            if (!BillBd.BLDN_YN.Equals("Y"))
                return true;

            string sqltext = string.Format(@" UPDATE PABREDMA
                                                     SET RCPT_YN           = 'Y'
                                                       , RCPT_DD           = '{4}'
                                                       , RCPT_TIME         = '{5}'
                                                       , RCPT_OCRR_UNIQ_NO = '{6}'
                                                   WHERE PID            = '{0}'
                                                     AND PT_CMHS_NO     = '{1}'
                                                     AND OTPT_ADMS_DVCD = '{2}'
                                                     AND CMPY_END_DD    = '{3}' ", BillBd.PID
                                                                             , BillBd.PT_CMHS_NO.ToString()
                                                                             , "O"
                                                                             , BillBd.MDCR_DD
                                                                             , BillBd.RCPT_DD
                                                                             , BillBd.RCPT_TIME
                                                                             , BillBd.RCPT_OCRR_UNIQ_NO);

            if (!DBService.ExecuteNonQuery(sqltext))
            {
                msg = "혈액감액정보의 수납여부 변경중 오류 발생 \r\n Error Message : " + DBService.ErrorMessage;
                return false;
            }

            return true;
        }

        /// <summary>
        /// 환자의 자보한도액을 발생시킨다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool SavePaTlimMa(ref string msg)
        {
            LimitInfo.PID = BillBd.PID;
            //LimitInfo.TRAI_LIMT_SQNO                = 0;           
            LimitInfo.OTPT_ADMS_DVCD = "O";
            LimitInfo.PT_CMHS_NO = BillBd.PT_CMHS_NO;
            LimitInfo.RCPT_OCRR_UNIQ_NO = BillBd.RCPT_OCRR_UNIQ_NO;
            LimitInfo.CMPY_DD = BillBd.MDCR_DD;
            LimitInfo.ASCT_SHAR_AMT = BillBd.PAY_CLAM_AMT;
            LimitInfo.RCPT_DD = BillBd.RCPT_DD;
            LimitInfo.RCPT_TIME = BillBd.RCPT_TIME;
            LimitInfo.RGST_DT = DateTimeService.NowDateTimeNoneSeperatorString();
            LimitInfo.RGSTR_ID = DOPack.UserInfo.USER_CD;

            if (BillBd.INSN_TYCD.Equals("41") && !BillBd.ASST_TYCD.Equals("99"))        //자보인 경우 발생
            {
                if (LimitInfo.SelectCountOfPaTlimMa() == 0)
                {
                    if (!LimitInfo.InsertPaTlimMa(ref msg))
                    {
                        return false;
                    }
                }
                else
                {
                    if (!LimitInfo.UpdatePaTlimMa(ref msg))
                    {
                        return false;
                    }
                }
            }
            else

            {
                if (LimitInfo.SelectCountOfPaTlimMa() >= 1)
                {
                    if (!LimitInfo.DeletePaTlimMa(ref msg))                             //자보가 아닌경우 발생된 자보한도액이 있으면 삭제
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        /// <summary>
        /// 카드/현금 승인내역이 있으면 승인내역의 영수정보를 변경한다.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool SavePaCapeMa(ref string msg)
        {
            PermitInfo.PID = BillBd.PID;
            PermitInfo.PT_CMHS_NO = BillBd.PT_CMHS_NO;
            //PermitInfo.RQST_DD               = BillBd.MDCR_DD;
            PermitInfo.CMPY_DD = BillBd.MDCR_DD;
            PermitInfo.CCCS_OCRR_DVCD = "O";
            PermitInfo.CASH_CARD_DVCD = string.Empty;
            PermitInfo.RCPT_OCRR_UNIQ_NO = BillBd.RCPT_OCRR_UNIQ_NO;
            PermitInfo.RCPT_SQNO = BillBd.RCPT_SQNO;
            PermitInfo.BILL_NO = BillBd.BILL_NO;
            PermitInfo.RCPT_DD = BillBd.RCPT_DD;
            PermitInfo.RCPT_TIME = BillBd.RCPT_TIME;
            PermitInfo.RGST_DT = BillBd.RGST_DT;

            if (!PermitInfo.UpdatePACAPEMA(ref msg))
            {
                return false;
            }

            return true;
        }

        public bool SavePACOBSMA(ref string msg)
        {
            if (!clsPACommon.ValidationPACOBSMA(BillTp.PID, BillTp.PT_CMHS_NO.ToString(), "O", BillTp.MDCR_DD, BillTp.MDCR_DD, txtCttrUnclAplyAmt.Text.Replace(",", ""), txtCttrUnclAplyAmt.Tag, ref msg))
                return false;

            if (BillBd.CTTR_UNCL_APLY_AMT == 0)
                return true;

            // 협력업체 수납내역(PACOBSMA)에 RCPT_OCRR_UNIQ_NO를 저장한다.
            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePACOBSMA_RcptOcrrUniqNo(BillBd.RCPT_OCRR_UNIQ_NO, BillBd.CTTR_NO_CD, BillBd.PID, BillBd.PT_CMHS_NO.ToString(), BillBd.MDCR_DD, BillBd.MDCR_DD)))
            {
                msg = string.Format("협력업체 지원금액을 저장하는 중 에러가 발생했습니다.{0}", DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "");
                return false;
            }

            return true;
        }

        public void BillNoApply()
        {
            decimal card_amt = 0;
            decimal cash_amt = 0;
            decimal bank_amt = 0;

            clsPACommon.GetBillNoAmt(BillTp.PID, "O", BillTp.PT_CMHS_NO.ToString(), BillTp.MDCR_DD, out card_amt, out cash_amt, out bank_amt);

            txtCashRcptAmt_ing.Text = cash_amt.ToString("#,###,###,##0");
            txtCardRcptAmt_ing.Text = card_amt.ToString("#,###,###,##0");
            txtBnacRcptAmt_ing.Text = bank_amt.ToString("#,###,###,##0");

            //Leave 이벤트에 안탄다.
            SetAmountOfBillInfo(txtCardRcptAmt);
        }

        #endregion

        #region Method : Private Method

        private void ClearControlData()
        {
            //this.FindChildControls(this.Controls);
            ClearControl(this.Controls);

            txtCttrUnclAplyAmt.Tag = string.Empty;

            //Tablet Preview 종료
            this.DisposeViewer();
        }

        private void ClearControl(Control.ControlCollection controls)
        {
            foreach (Control ctl in controls)
            {
                if (ctl.HasChildren)
                {
                    this.ClearChildControl(ctl);
                    this.ClearControl(ctl.Controls);
                }
                else
                {
                    this.ClearChildControl(ctl);
                }

            }

        }

        private void ClearChildControl(Control controls)
        {
            if (controls is LxTextBox)
            {
                LxTextBox txtBox = controls as LxTextBox;
                txtBox.Text = String.Empty;

                if (txtBox.Name == "txtDcntRdiaAmt")
                {
                    txtBox.ReadOnly = true;
                }

                if (txtBox.ReadOnly)
                {
                    txtBox.Appearance.BackColor = Color.FromArgb(250, 252, 252);
                    txtBox.NullTextAppearance.BackColor = Color.FromArgb(250, 252, 252);
                }
                else
                {

                    if (txtBox.Name == "txtCashRcptAmt" || txtBox.Name == "txtCardRcptAmt" || txtBox.Name == "txtBnacRcptAmt")
                    {
                        txtBox.Appearance.BackColor = Color.FromArgb(235, 245, 255);
                        txtBox.NullTextAppearance.BackColor = Color.FromArgb(235, 245, 255);
                        txtBox.Appearance.ForeColor = Color.FromArgb(0, 34, 134);
                        txtBox.NullTextAppearance.ForeColor = Color.FromArgb(0, 34, 134);
                        System.Drawing.Font font = new System.Drawing.Font("맑은 고딕", 10, FontStyle.Bold);
                        txtBox.Font = font;
                    }
                    else
                    {
                        txtBox.Appearance.BackColor = Color.White;
                        txtBox.NullTextAppearance.BackColor = Color.White;
                        txtBox.Appearance.ForeColor = Color.FromArgb(30, 30, 30);
                        txtBox.NullTextAppearance.ForeColor = Color.FromArgb(200, 200, 200);
                        System.Drawing.Font font = new System.Drawing.Font("맑은 고딕", 10, FontStyle.Regular);
                        txtBox.Font = font;
                    }

                }

                if (txtBox.Name == "txtRfndResn")
                    txtBox.Hint = "환불사유를 입력해주세요!!";

                if (txtBox.Name == "txtDcntResn")
                    txtBox.Hint = "할인사유를 입력해주세요!!";

                if (txtBox.Name == "txtUnclResn")
                    txtBox.Hint = "미수사유를 입력해주세요!!";
            }
            else if (controls is LxComboBox)
            {
                LxComboBox cboBox = controls as LxComboBox;

                if (cboBox.ReadOnly)
                {
                    cboBox.Appearance.BackColor = Color.FromArgb(250, 252, 252);
                    cboBox.NullTextAppearance.BackColor = Color.FromArgb(250, 252, 252);
                }
                else
                {
                    cboBox.Appearance.BackColor = Color.White;
                    cboBox.NullTextAppearance.BackColor = Color.White;
                }
                cboBox.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;

                if (cboBox.Name == "cboDcntRdiaCd" || cboBox.Name == "cboSpclDcntDvcd")
                {
                    cboBox.SelectedValue = "NO";
                }
                else if (cboBox.Name == "cboBldnYn" || cboBox.Name == "cboUnclCd")
                {
                    txtUnclAmt.Text = string.Empty;
                    cboBox.SelectedValue = "N";
                }
            }
            else if (controls is LxMaskedEdit)
            {
                LxMaskedEdit mskEdit = controls as LxMaskedEdit;
                mskEdit.Text = String.Empty;
            }
        }

        private void FindChildControls(Control.ControlCollection controls)
        {
            foreach (Control Ctl in controls)
            {
                if (Ctl.HasChildren)
                    this.FindChildControls(Ctl.Controls);
                else
                    this.ClearChildControl(Ctl);
            }
        }

        private void InitializeReadOnlyColor(Control controls)
        {

            LxTextBox txtBox = new LxTextBox();
            if (controls is LxTextBox)
            {
                txtBox = controls as LxTextBox;
                if (txtBox.ReadOnly = true)
                {
                    txtBox.Appearance.BackColor = Color.FromArgb(250, 250, 255);
                    txtBox.NullTextAppearance.BackColor = Color.FromArgb(250, 250, 255);
                }
                else
                {
                    txtBox.Appearance.BackColor = Color.White;
                    txtBox.NullTextAppearance.BackColor = Color.White;
                }
            }

        }

        private void PopUpBloodRdiaInfo()
        {
            // 2019-06-20 SJH PAOBILTP 만들어지는게 이상해서 일단 리턴함.
            return;

            int unclamt = 0; //미수금액
            int cardrcptamt = 0; //카드금액
            int bloodcount = 0; // 혈액처방횟수
            int ptsharamt = 0; // 환자부담금액( 영수금액)
            int dcntrdiaamt = 0;
            int frtmblodrdiaamt = 0;  // 기 혈액감액금액
            int bnacrcptamt = 0;
            int frtmrcptamt = 0;
            int etcamt = 0;
            string bldnyn = "N";

            try
            {
                int.TryParse(txtUnclAmt.Text.Replace(",", ""), out unclamt);

                if (unclamt > 0)
                {
                    LxMessage.ShowInformation("미수금액이 존재합니다. 금액 초기화한 후 혈액감액 처리해 주세요.");
                    cboUnclCd.SelectValue("N");
                    return;
                }

                /*
                if (OutRecBd.DtPrsc.Rows.Count < 1)
                    return;

                foreach (DataRow row in OutRecBd.DtPrsc.Select("PRSC_LCLS_CD = '41'"))
                {
                    bloodcount++;
                }

                if (bloodcount > 0)
                {
                 * */
                frmBloodRdiaInfoP popBlood = new frmBloodRdiaInfoP("O", BillTp.PID, BillTp.PT_CMHS_NO.ToString(), BillTp.MDCR_DD, BillTp.MDCR_DD, BillTp.INSN_TYCD, BillTp.ASST_TYCD, "U");
                popBlood.ShowDialog();

                if (popBlood.DialogResult == DialogResult.OK)
                {
                    if (popBlood.TotalRdiaAmt > 0)
                    {
                        bldnyn = "Y";
                    }

                    txtBlodRdiaAmt.Text = string.Format("{0:#,##0}", popBlood.TotalRdiaAmt);
                }

                popBlood.Dispose();

                cboBldnYn.SelectedValue = bldnyn;
                if (bldnyn.Equals("N"))
                    txtBlodRdiaAmt.Text = "0";

                TxtControl_Leave(txtBlodRdiaAmt, new EventArgs());
                txtCashRcptAmt.Focus();
            }
            catch (Exception ex)
            {
                LxMessage.Show(ex.Message, "혈액감액프로그램 실행중 오류발생", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 영수증정보란을 셋팅한다.
        /// </summary>
        private void SetBillInfo()
        {
            int ptshartamt = 0; // 본인부담총금액
            string spcl_dcnt_dvcd = string.Empty;
            decimal spcl_dcnt_amt = 0;

            txtTotlMdcrAmt.Text = string.Format("{0:#,##0}", BillTp.TOTL_MDCR_AMT);                     // 총진료비
            txtPayTamt.Text = string.Format("{0:#,##0}", BillTp.PAY_TAMT);                          // 급여총액
            txtInsn100Tamt.Text = string.Format("{0:#,##0}", BillTp.INSN_100_TAMT);                     // 보험100총액
            txtScngPayUschAmt.Text = string.Format("{0:#,##0}", BillTp.SCNG_PAY_USCH_AMT);                 // 선별급여본인부담액
            txtScngPayClamAmt.Text = string.Format("{0:#,##0}", BillTp.SCNG_PAY_CLAM_AMT);                 // 선별급여청구금액
            txtClamNopyTamt.Text = string.Format("{0:#,##0}", BillTp.CLAM_NOPY_TAMT);                    // 청구비급여총액
            txtNopyTamt.Text = string.Format("{0:#,##0}", BillTp.NOPY_TAMT);                         // 비급여총액     
            txtAdedValuTaxTamt.Text = string.Format("{0:#,##0}", BillTp.ADED_VALU_TAX_TAMT);                // 부가가치세금액
            txtSmcrAmt.Text = string.Format("{0:#,##0}", BillTp.SMCR_AMT);                          // 선택진료금액
            txtPayUschAmt.Text = string.Format("{0:#,##0}", BillTp.PAY_USCH_AMT);                      // 급여본인부담금액
            txtPayClamAmt.Text = string.Format("{0:#,##0}", BillTp.PAY_CLAM_AMT);                      // 급여청구금액
            txtDsblFundAmt.Text = string.Format("{0:#,##0}", BillTp.DSBL_FUND_AMT);                     // 장애인기금
            txtHmptPayTamt.Text = string.Format("{0:#,##0}", BillTp.HMPT_PAY_TAMT);                     // 수진자급여총액
            txtGvrnClamAmt.Text = string.Format("{0:#,##0}", BillTp.GVRN_CLAM_AMT);                     // 공무원공상청구
            txtSuptAmt.Text = string.Format("{0:#,##0}", BillTp.SUPT_AMT);                          // 공단지원금
            txtHllfMncsClamAmt.Text = string.Format("{0:#,##0}", BillTp.HLLF_MNCS_CLAM_AMT);                // 건강생활유지비청구액
            txtTbrcCtctSuptAmt.Text = string.Format("{0:#,##0}", BillTp.TBRC_CTCT_SUPT_AMT);                // 결핵접촉청구
            txtVcntClamAmt.Text = string.Format("{0:#,##0}", BillTp.VCNT_CLAM_AMT);                     // 예방접종청구
            txtEmrgSuptAmt.Text = string.Format("{0:#,##0}", BillTp.EMRG_SUPT_AMT);                     // 긴급지원금액
            //txtVtrnAmt.Text         = string.Format("{0:#,##0}", BillTp.VTRD_AMT);                          // 수직감액금액
            txtCttrUnclAplyAmt.Text = string.Format("{0:#,##0}", BillTp.CTTR_UNCL_APLY_AMT);                // 협력지원금액
            // 부가가치세총금액 + 보험100총금액 + 비급여총금액 + 선택진료금액 + 급여본인부담금액 + 선별급여본인부담금액 +
            // - 혈액감액금액 - 지원금액 - 산모보험100청구금액 - 산모비급여청구금액 - 보훈총금액 - 보훈감면금액 - 독립유공자청구금액 
            ptshartamt = BillTp.ADED_VALU_TAX_TAMT + BillTp.INSN_100_TAMT + BillTp.NOPY_TAMT + BillTp.SMCR_AMT + BillTp.PAY_USCH_AMT + BillTp.SCNG_PAY_USCH_AMT -
                         BillTp.BLOD_RDIA_AMT - BillTp.SUPT_AMT - BillTp.MTWM_I100_CLAM_AMT - BillTp.MTWM_NOPY_CLAM_AMT - BillTp.VTRN_TAMT - BillTp.VTRN_RNE_AMT - BillTp.INDP_MOMR_CLAM_AMT;
            txtPtSharAmt.Text = string.Format("{0:#,##0}", BillTp.PT_SHAR_AMT);                       //환자부담금액
            txtTotalPtSharAmt.Text = string.Format("{0:#,##0}", ptshartamt);                           //환자부담총금액
            txtFrtmRcptTotlAmt.Text = string.Format("{0:#,##0}", BillTp.FRTM_CASH_RCPT_AMT + BillTp.FRTM_CARD_RCPT_AMT + BillTp.FRTM_BNAC_AMT);  //기영수합계

            cboBldnYn.SelectedValue = StringService.IsNvl(BillTp.BLDN_YN, "N");
            if (BillTp.BLOD_RDIA_AMT != null && BillTp.BLOD_RDIA_AMT > 0)
                cboBldnYn.SelectedValue = "Y";

            txtBlodRdiaAmt.Text = string.Format("{0:#,##0}", BillTp.BLOD_RDIA_AMT);                     //혈액감액금액
            cboDcntRdiaCd.SelectValue(StringService.IsNvl(BillTp.DCNT_RDIA_CD, "NO"));                      // 할인코드
            txtDcntRdiaEmno.Text = BillTp.DCNT_RDIA_EMNO;
            txtFrtmDcntRdiaAmt.Text = string.Format("{0:#,##0}", BillTp.FRTM_DCNT_RDIA_AMT);                 //기할인감액금액
            txtDcntRdiaAmt.Text = string.Format("{0:#,##0}", BillTp.DCNT_RDIA_AMT);                      //할인감액금액
            txtDcntRdiaEmno.Text = BillTp.DCNT_RDIA_EMNO;
            txtSpclDcntAmt.Text = string.Format("{0:#,##0}", BillTp.SPCL_DCNT_AMT);                      // 특별할인금액
            txtCashRcptAmt.Text = string.Format("{0:#,##0}", BillTp.CASH_RCPT_AMT);                      // 현금영수금액
            txtCashRcptAmt_ing.Text = "0";
            txtFrtmCashRcptAmt.Text = string.Format("{0:#,##0}", BillTp.FRTM_CASH_RCPT_AMT);                 // 기현금영수금액
            txtFrtmCashRcptAmt_C.Text = "0";
            txtCardRcptAmt.Text = string.Format("{0:#,##0}", BillTp.CARD_RCPT_AMT);                      // 카드영수금액
            txtCardRcptAmt_ing.Text = "0";
            txtFrtmCardRcptAmt_C.Text = "0";
            txtFrtmCardRcptAmt.Text = string.Format("{0:#,##0}", BillTp.FRTM_CARD_RCPT_AMT);                 // 기카드영수금액
            txtBnacRcptAmt.Text = string.Format("{0:#,##0}", BillTp.BNAC_RCPT_AMT);                      // 계좌영수금액
            txtBnacRcptAmt_ing.Text = "0";
            txtFrtmBnacAmt_C.Text = "0";
            txtFrtmBnacAmt.Text = string.Format("{0:#,##0}", BillTp.FRTM_BNAC_AMT);                      // 기계좌영수금액
            txtUnclAmt.Text = string.Format("{0:#,##0}", BillTp.UNCL_AMT);                           // 미수금액

            //할인금액 추가
            clsPACommon.GetSpclDcnt("O", BillTp.PID, BillTp.PT_CMHS_NO.ToString(), out spcl_dcnt_dvcd, out spcl_dcnt_amt);

            cboSpclDcntDvcd.SelectValue(spcl_dcnt_dvcd);
            txtSpclDcntAmt.Text = string.Format("{0:#,##0}", spcl_dcnt_amt);
            SetCashBillIssueYn();

            if (BillTp.ADED_VALU_TAX_TAMT > 0)
            {
                LxMessage.Show("부가가치세 대상환자입니다.", "확인");
            }

            // 건보인 경우에만 메시지 띄우자.
            if (BillTp.INSN_TYCD.Equals("11"))
            {
                string a = DBService.ExecuteScalar(SQL.Function.FN_PA_READ_GVRNCLAMAMT(BillTp.PID, BillTp.MDCR_DD)).ToString();
                if (a.Equals("Y"))
                {
                    string message = "공무원연금공단 적용 대상자 입니다.\r\n확인 바랍니다.";

                    if (BillTp.GVRN_CLAM_AMT > 0)
                        message += "\r\n\r\n공무원 공상 청구금액이 존재합니다!!!";

                    LxMessage.ShowInformation(message);
                }
            }

            // 총진료비를 전달한다. 
            // DRG환자 확인하기 위해서...
            if (OnTotlMdcrAmt != null)
            {
                OnTotlMdcrAmt(BillTp.TOTL_MDCR_AMT);
            }
        }

        /// <summary>
        /// 할인금액을 설정한다.
        /// </summary>
        private void SetDcntAmt()
        {
            try
            {
                string pid = String.Empty;
                string ptcmhsno = String.Empty;
                string insntycd = String.Empty;
                string assttycd = String.Empty;
                string mdcrdd = String.Empty;
                string cmpystrtdd = String.Empty;
                string cmpyenddd = String.Empty;


                string otptamdsdvcd = "O";
                string refdcntamt = "0";
                string msg = String.Empty;
                string dcntrdiacd = String.Empty;
                string dcntrdiaemno = String.Empty;
                int dcntamt = 0;
                int dcntrdiaamt = 0;
                int vcntclamamt = 0;
                int emrgsuptamt = 0;
                int payclamamt = 0;


                pid = BillTp.PID;
                ptcmhsno = BillTp.PT_CMHS_NO.ToString();
                insntycd = BillTp.INSN_TYCD;
                assttycd = BillTp.ASST_TYCD;
                mdcrdd = BillTp.MDCR_DD;
                cmpystrtdd = BillTp.MDCR_DD;
                cmpyenddd = BillTp.MDCR_DD;

                DataTable dtpaobilbd = new DataTable();
                if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOBILBDforDcntAmt(), ref dtpaobilbd, m_StrCol.GetValue("PID")
                                                                                                    , m_StrCol.GetValue("PT_CMHS_NO")))
                {
                    if (dtpaobilbd.Rows.Count > 0)
                    {
                        DataRow row = dtpaobilbd.Rows[0];
                        dcntrdiacd = row["DCNT_RDIA_CD"].ToString();
                        dcntrdiaemno = row["DCNT_RDIA_EMNO"].ToString();
                        int.TryParse(row["DCNT_RDIA_AMT"].ToString(), out dcntrdiaamt);
                        int.TryParse(row["VCNT_CLAM_AMT"].ToString(), out vcntclamamt);
                        int.TryParse(row["EMRG_SUPT_AMT"].ToString(), out emrgsuptamt);
                        int.TryParse(row["PAY_CLAM_AMT"].ToString(), out payclamamt);

                    }
                    else
                    {
                        dcntrdiacd = m_StrCol.GetValue("DCNT_RDIA_CD");
                        dcntrdiaemno = m_StrCol.GetValue("DCNT_RDIA_EMNO");
                        if (StringService.IsNvl(dcntrdiacd, "NO").Equals("NO"))
                        {
                            DataTable dtFam = new DataTable();
                            if (DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAFAMYMA(), ref dtFam, m_StrCol.GetValue("PID")
                                                                                                 , m_StrCol.GetValue("PT_CMHS_NO")))
                            {
                                if (dtFam.Rows.Count > 0)
                                {
                                    DataRow row = dtFam.Rows[0];
                                    dcntrdiacd = row["DCNT_CD"].ToString();
                                    dcntrdiaemno = row["USER_ID"].ToString();
                                }
                                else
                                {
                                    dcntrdiacd = "NO";
                                    dcntrdiaemno = "";
                                }
                            }
                        }
                    }
                }
                if (BillTp.DY_WARD_YN.Equals("Y"))
                {
                    otptamdsdvcd = "D";
                }
                if (!SqlPack.Procedure.PR_PA_COM_PRSCDCNTAMT(otptamdsdvcd
                                                          , pid
                                                          , ptcmhsno
                                                          , insntycd
                                                          , assttycd
                                                          , m_StrCol.GetValue("USCH_APLY_CD")
                                                          , dcntrdiacd
                                                          , mdcrdd
                                                          , cmpystrtdd
                                                          , cmpyenddd
                                                          , m_StrCol.GetValue("CFSC_RGNO_CD")
                                                          , m_StrCol.GetValue("OTPT_DRG_YN")
                                                          , m_StrCol.GetValue("VTRN_PT_YN")
                                                          , m_StrCol.GetValue("MOMR_AGE_DVCD")
                                                          , m_StrCol.GetValue("INDP_MOMR_YN")
                                                          , ref refdcntamt
                                                          , ref msg))
                {
                    LxMessage.Show(DBService.ErrorMessage);
                    return;
                }

                BillTp.DCNT_RDIA_CD = dcntrdiacd;
                BillTp.DCNT_RDIA_EMNO = dcntrdiaemno;
                // BillTp.DCNT_RDIA_AMT  = int.Parse(StringService.IsNvl(dcntamt, "0"));
                BillTp.FRTM_DCNT_RDIA_AMT = dcntrdiaamt;
                //LxMessage.Show(int.MaxValue.ToString());

            }
            catch (Exception ex)
            {
                LxMessage.Show("할인금액 설정하는 중 오류를 발생했습니다.\r\n" +
                               "Method : [SetDcntAmt] \r\n" +
                               "오류 메시지 : " + ex.Message,
                               "입원취소",
                               MessageBoxButtons.OK,
                               MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 현금영수증의무발행 문구를 표시한다.
        /// </summary>
        private void SetCashBillIssueYn()
        {
            int rcptamt = BillTp.CASH_RCPT_AMT + BillTp.FRTM_BNAC_AMT + BillTp.FRTM_CARD_RCPT_AMT + BillTp.FRTM_CASH_RCPT_AMT;

            if (rcptamt >= 100000)
            {
                m_CashBillYn = "Y";
                lblCashRcpt.Visible = true;
            }
            else
            {
                m_CashBillYn = "N";
                lblCashRcpt.Visible = false;
            }
        }

        private void PopUpUser(string userdvcd)
        {
            if (cboDcntRdiaCd.Value != null && StringService.IsNvl(cboDcntRdiaCd.SelectedItem.DataValue.ToString(), "NO").Equals("NO"))
                return;
            popSearchUser popUser = null;

            if (userdvcd.Equals("USER"))
                popUser = new popSearchUser();
            else
                popUser = new popSearchUser("USER_NM", txtDcntRdiaEmnm.Text.Trim(), true);

            popUser.BaseMDI = this.BaseMDI;
            popUser.ShowDialog(this);

            if (popUser.DialogResult == DialogResult.OK)
            {
                txtDcntRdiaEmno.Text = popUser.USER_CD;
                txtDcntRdiaEmnm.Text = popUser.USER_NM;
                txtDcntResn.Focus();
            }
            popUser.Dispose();
        }

        private bool GetUser()
        {
            bool result = true;
            try
            {
                string dcntrdiaemnm = String.Empty;
                string inputvalue = txtDcntRdiaEmnm.Text.Trim();
                if (StringService.IsNull(inputvalue)) return false;

                dcntrdiaemnm = UserList.GetColumnValue(inputvalue, "USER_NM").ToString();
                if (StringService.IsNotNull(dcntrdiaemnm))
                {
                    txtDcntRdiaEmno.Text = inputvalue;
                    txtDcntRdiaEmnm.Text = dcntrdiaemnm;
                }
                else
                {
                    DataTable dt = new DataTable();
                    if (DBService.ExecuteDataTable(SQL.BI.Sql.SelectUserORSEDSDT(), ref dt, "USER_NM", inputvalue))
                    {
                        if (dt.Rows.Count == 1)
                        {
                            txtDcntRdiaEmno.Text = dt.Rows[0]["USER_CD"].ToString();
                            txtDcntRdiaEmnm.Text = dt.Rows[0]["USER_NM"].ToString();
                        }
                        else if (dt.Rows.Count > 1)
                        {
                            PopUpUser("USER_NM");
                        }
                        else
                        {
                            result = false;
                        }
                    }
                    else
                    {
                        result = false;
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
                result = false;
            }
            return result;
        }

        private bool SaveNotCashReceipt(string cash_card_dvcd, int cash_prmt_amt, ref string msg)
        {
            try
            {
                int prmtsqno = DBService.ExecuteInteger(SQL.PA.Sql.SelectPACAPEMA_MaxPrmtSqno()
                                                      , BillBd.PID
                                                      , DateTimeService.TodayDateNoneSeperatorString());

                clsCardCashPermitInfo PermitInfo = new clsCardCashPermitInfo();

                PermitInfo.PID = BillBd.PID;
                PermitInfo.RQST_DD = DateTimeService.TodayDateNoneSeperatorString();
                PermitInfo.PRMT_SQNO = prmtsqno + 1;
                PermitInfo.RCPT_OCRR_UNIQ_NO = "NO";
                PermitInfo.CCCS_OCRR_DVCD = "O";
                PermitInfo.PT_CMHS_NO = BillBd.PT_CMHS_NO;
                PermitInfo.CMPY_DD = BillBd.MDCR_DD;
                PermitInfo.RCPT_SQNO = 0;
                PermitInfo.BILL_NO = "NO";
                PermitInfo.CASH_CARD_DVCD = cash_card_dvcd;
                PermitInfo.PRMT_RQST_DVCD = "P";
                PermitInfo.DEAL_DVCD = "01";
                PermitInfo.INTM_CNTS_CD = "00";
                PermitInfo.CASH_PRMT_AMT = (cash_card_dvcd == "02" ? cash_prmt_amt : 0);
                PermitInfo.CARD_PRMT_AMT = 0;
                PermitInfo.BNAC_PRMT_AMT = (cash_card_dvcd == "03" ? cash_prmt_amt : 0);
                PermitInfo.CARD_CASH_NO = string.Empty;
                PermitInfo.CARD_VALD_DD = string.Empty;
                PermitInfo.CARD_CASH_PRMT_NO = (prmtsqno + 1).ToString();
                PermitInfo.PRMT_DT = DateTimeService.TodayDateTimeNoneSeperatorString();
                PermitInfo.CARD_CO_CD = string.Empty;
                PermitInfo.CNCL_YN = "N";
                PermitInfo.CNCL_ORIG_DEAL_DD = string.Empty;
                PermitInfo.CNCL_ORIG_PRMT_NO = string.Empty;
                PermitInfo.PRCH_CO_CD = string.Empty;
                PermitInfo.PRCH_CO_NM = string.Empty;
                PermitInfo.ISUE_CO_CD = string.Empty;
                PermitInfo.ISUE_CO_NM = string.Empty;
                PermitInfo.MSG_1 = string.Empty;
                PermitInfo.MSG_2 = string.Empty;
                PermitInfo.APP_CARD_BRCD_NO = string.Empty;
                PermitInfo.ETC_USE_CNTS_1 = string.Empty;
                PermitInfo.ETC_USE_CNTS_2 = "Y";
                PermitInfo.ETC_USE_CNTS_3 = string.Empty;
                PermitInfo.ETC_USE_CNTS_4 = string.Empty;
                PermitInfo.ETC_USE_CNTS_5 = string.Empty;
                PermitInfo.RCPT_DD = string.Empty;
                PermitInfo.RCPT_TIME = string.Empty;

                PermitInfo.InsertPACAPEMA();

                return true;
            }
            catch (Exception ex)
            {
                DBService.RollbackTransaction();
                msg = ex.Message;
                return false;
            }
        }

        private void PopUpCardCashPermit(string permitrqstdvcd, string prmtdvcd, string pid, string ptcmhsno, string rcpt_sqno, string rcptocrruniqno, string billno, string cmpydd, int cashamt, int bnacamt)
        {
            frmCardCashPermitP popPermit = null;

            try
            {
                clsCardCashPermitInfo permitinfo = new clsCardCashPermitInfo();

                int cash_amt = 0;
                int bnac_amt = 0;

                permitinfo.PRMT_RQST_DVCD = permitrqstdvcd;
                permitinfo.PID = pid;
                permitinfo.RQST_DD = DateTimeService.NowDateNoneSeperatorString();
                permitinfo.CMPY_DD = cmpydd;
                permitinfo.RCPT_OCRR_UNIQ_NO = rcptocrruniqno;
                permitinfo.CCCS_OCRR_DVCD = "O";                //발생구분코드 : 외래수납
                permitinfo.PT_CMHS_NO = int.Parse(ptcmhsno);
                permitinfo.BILL_NO = billno;
                permitinfo.RCPT_SQNO = int.Parse(rcpt_sqno);
                permitinfo.TOTAL_AMT = cashamt + bnacamt;
                permitinfo.CARD_AMT = 0;
                permitinfo.CASH_AMT = cashamt;
                permitinfo.BNAC_AMT = bnacamt;

                //일단 기본값 세팅한다. 둘다 있을경우도 있음
                if (cashamt > 0)
                    permitinfo.CASH_CARD_DVCD = "02";
                else if (bnacamt > 0)
                    permitinfo.CASH_CARD_DVCD = "03";

                // VAN사 무승인 수기승인처리여부
                popPermit = new frmCardCashPermitP(permitinfo, prmtdvcd);

                if (popPermit.SelectExistCashReceipt(permitinfo.PID, permitinfo.PT_CMHS_NO.ToString(), permitinfo.RCPT_SQNO.ToString(), permitinfo.CMPY_DD, permitinfo.BILL_NO))
                {
                    LxMessage.Show("이미 현금영수증이 승인된 내역입니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    popPermit.Dispose();
                    return;
                }

                popPermit.BaseMDI = this.BaseMDI;
                popPermit.ShowDialog(this);

                if (popPermit.DialogResult == DialogResult.OK)
                {
                    //방식이 바뀜 -> 원래는 현금영수증 재승인하면 카드테이블에 쌓고, 밑에 로직을 타서 수납고유번호를 Update하는 방식이었다가
                    //현금영수안해도 카드테이블에 쌓이는 걸로 바뀌어서 재승인하면 카드창 PopUp에서 Update한다.                    
                    if (prmtdvcd.Equals("R"))
                    {
                        //바뀌기전에 발생된 데이터면, 기존 원칙대로 간다.
                        if (popPermit.Permitinfo.AFFECTEDROWS == 0)
                        {
                            if (!DBService.ExecuteNonQuery(SQL.PA.Sql.UpdatePACAPEMAafterRcpt(permitinfo.PID, permitinfo.PT_CMHS_NO.ToString(), permitinfo.CMPY_DD, permitinfo.CCCS_OCRR_DVCD, permitinfo.CASH_CARD_DVCD
                                                                                            , permitinfo.RCPT_OCRR_UNIQ_NO, rcpt_sqno, permitinfo.BILL_NO
                                                                                            , DateTimeService.ConvertDateTimeStringToFormatString(DateTimeService.NowDateTimeNoneSeperatorString(), "yyyyMMdd")
                                                                                            , DateTimeService.ConvertDateTimeStringToFormatString(DateTimeService.NowDateTimeNoneSeperatorString(), "HHmm")
                                                                                            , DateTimeService.NowDateTimeNoneSeperatorString())))
                                throw new Exception("카드/현금 승인내역 변경 저장 중 오류가 발생했습니다. 확인하세요. \r\n [" + DBService.ErrorMessage + "]");
                        }
                    }
                }
                else
                {
                    LxMessage.Show("신용카드/현금영수증 승인을 취소하였습니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                popPermit.Dispose();
            }
            catch (Exception ex)
            {
                popPermit.Dispose();
                throw new Exception("카드/현금 승인내역 변경 저장 중 오류가 발생했습니다. 확인하세요. \r\n [" + DBService.ErrorMessage + "]");
            }
        }

        /// <summary>
        /// Tablet 임시영수증 Call
        /// </summary>
        public void TempTabletBill()
        {
            if (string.IsNullOrEmpty(BillTp.PID))
            {
                //LxMessage.Show("환자를 선택하세요.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            m_ReceiptPrint.PrintReceiptOut(BillTp.PID, BillTp.PT_CMHS_NO.ToString(), "A", false, true, true, string.Empty, string.Empty, false, true);

            this.DisposeViewer();

            m_viewer = new popImageViewer(string.Format(clsReceiptPreview.m_ReceiptTempPath + @"\{0}.jpg", BillTp.PID), true);
            m_viewer.FormClosed += m_viewer_FormClosed;
            m_viewer.Show();
        }

        public void DisposeViewer()
        {
            if (m_viewer != null)
            {
                m_viewer.FormClosed -= m_viewer_FormClosed;
                m_viewer.Close();
                m_viewer.Dispose();
            }
        }

        #endregion Method : Private Method

        #region Event : Control

        private void txtCashRcptAmt_EditorButtonClick(object sender, Infragistics.Win.UltraWinEditors.EditorButtonEventArgs e)
        {
            if (String.IsNullOrWhiteSpace(BillTp.PID))
                return;

            string cash_card_dvcd = string.Empty;

            if (sender == txtCardRcptAmt)
                cash_card_dvcd = "01";
            else if (sender == txtCashRcptAmt)
                cash_card_dvcd = "02";
            else if (sender == txtBnacRcptAmt)
                cash_card_dvcd = "03";

            PopUpCardCashPermit("P", "O", cash_card_dvcd, BillTp.PID, BillTp.PT_CMHS_NO.ToString(), BillTp.MDCR_DD);
        }

        private void txtCttrUnclAplyAmt_EditorButtonClick(object sender, Infragistics.Win.UltraWinEditors.EditorButtonEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(BillTp.PID) || string.IsNullOrWhiteSpace(BillTp.PT_CMHS_NO.ToString()))
                    return;

                decimal originSpclDcntAmt = 0;
                decimal.TryParse(txtSpclDcntAmt.Text, out originSpclDcntAmt);
                if (txtCttrUnclAplyAmt.Tag != null && txtCttrUnclAplyAmt.Tag.ToString() == string.Empty && !originSpclDcntAmt.Equals(0))
                {
                    if (!LxMessage.ShowQuestion("할인금액이 존재하는 상태로 협력지원금액/할인금액을 입력하면 기존의 할인금액이 사라집니다. 계속 진행하시겠습니까?").Equals(DialogResult.Yes))
                        return;
                }

                if (txtCttrUnclAplyAmt.Tag == null)
                    txtCttrUnclAplyAmt.Tag = string.Empty;

                // 급여
                int pay = BillTp.PAY_USCH_AMT + BillTp.SCNG_PAY_USCH_AMT;
                // 비급여
                int nopy = BillTp.INSN_100_TAMT + BillTp.NOPY_TAMT;

                popCooperatorList popup = new popCooperatorList(BillTp.PID, BillTp.PT_CMHS_NO.ToString(), "O", BillTp.MDCR_DD, BillTp.MDCR_DD, pay, nopy, txtCttrUnclAplyAmt.Tag.ToString());
                DialogResult dr = popup.ShowDialog(this);

                if (dr.Equals(DialogResult.OK))
                {
                    if (string.IsNullOrWhiteSpace(popup.AplyUniqSqno))
                    {
                        txtCttrUnclAplyAmt.Text = string.Format("{0:#,##0}", popup.SupportAmtP + popup.SupportAmtN);
                        txtCttrUnclAplyAmt.Tag = popup.AplyUniqSqno;

                        if (cboSpclDcntDvcd.SelectedValue == "D09")
                        {
                            cboSpclDcntDvcd.SelectedValue = "NO";
                            txtSpclDcntAmt.Text = string.Format("{0:#,##0}", popup.DisCount);
                        }
                    }
                    else
                    {
                        txtCttrUnclAplyAmt.Text = string.Format("{0:#,##0}", popup.SupportAmtP + popup.SupportAmtN);
                        txtCttrUnclAplyAmt.Tag = popup.AplyUniqSqno;

                        // 할인금액 세팅하자
                        string originText = cboSpclDcntDvcd.Text;

                        if (!popup.DisCount.Equals(0))
                        {
                            // 할인금액이 있는 경우
                            decimal.TryParse(txtSpclDcntAmt.Text, out originSpclDcntAmt);

                            cboSpclDcntDvcd.SelectedValue = "D09";
                            txtSpclDcntAmt.Text = string.Format("{0:#,##0}", popup.DisCount);
                        }

                        if (!originSpclDcntAmt.Equals(0))
                            LxMessage.ShowInformation(string.Format("기존에 있던 아래의 할인금액이 없어지고 선택한 할인금액이 세팅됩니다.\r\n  할인코드/금액 : {0}/{1}", originText, string.Format("{0:#,##0}", originSpclDcntAmt)));
                    }

                    txtCashRcptAmt.Focus();
                }

                popup.Dispose();
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";

                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);

                LxMessage.ShowError(ex.Message + error);
            }
        }

        private void btnPermitCancel_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(BillTp.PID))
                return;

            PopUpCardCashPermit("C", "O", "A", BillTp.PID, BillTp.PT_CMHS_NO.ToString(), BillTp.MDCR_DD);
        }

        private void txtBlodRdiaAmt_EditorButtonClick(object sender, Infragistics.Win.UltraWinEditors.EditorButtonEventArgs e)
        {
            PopUpBloodRdiaInfo();
        }

        private void txtDcntRdiaEmnm_EditorButtonClick(object sender, Infragistics.Win.UltraWinEditors.EditorButtonEventArgs e)
        {
            if (!txtDcntRdiaEmnm.ReadOnly)
                PopUpUser("USER");
        }

        private void txtDcntRdiaEmnm_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                // 직원번호 확인
                if (txtDcntRdiaEmnm.ReadOnly) return;

                if (!GetUser())
                {
                    LxMessage.Show("사원ID가 존재하지 않습니다. 확인하세요.!!", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtDcntRdiaEmnm.Text = String.Empty;
                }
            }
        }

        private void SetAmountOfBillInfo(Control ctrl)
        {
            // 영수 금액 셋팅
            clsPACommon.SetAmountOfBillInfo_NotFocus(ctrl, m_StrCol, m_AllControls);
        }

        private void Combo_ValueChanged(object sender, EventArgs e)
        {
            SetAmountOfBillInfo((Control)sender);
        }

        private void TxtControl_Leave(object sender, EventArgs e)
        {
            SetAmountOfBillInfo((Control)sender);
        }

        private void Control_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (sender is LxTextBox)
                {
                    LxTextBox tb = (LxTextBox)sender;

                    if (string.IsNullOrWhiteSpace(tb.Text) || !StringService.IsNumeric(tb.Text.Replace(",", "")) || tb.Text.Equals("-"))
                        return;

                    tb.Text = String.Format("{0:#,##0}", Convert.ToDouble(tb.Text));
                    tb.Select(tb.Text.Length, tb.Text.Length);
                }
            }
            catch (Exception ex)
            {
                LogService.ErrorLog(ex);
            }
        }

        private void txtFrtmCashRcptAmt_EditorButtonClick(object sender, Infragistics.Win.UltraWinEditors.EditorButtonEventArgs e)
        {
            try
            {
                int cashamt = 0;
                int bnacamt = 0;
                int amt = 0;

                if (!int.TryParse(((LxTextBox)sender).Text.Replace(",", string.Empty), out amt))
                    throw new Exception("금액 오류 - 형변환 오류");

                if (amt == 0)
                {
                    LxMessage.Show("현금영수증 재승인할 금액이 0원입니다.", "확인", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (sender == txtFrtmCashRcptAmt)
                    cashamt = amt;
                else if (sender == txtFrtmBnacAmt)
                    bnacamt = amt;

                BillBd.Load(BillTp.PID, BillTp.PT_CMHS_NO);

                PopUpCardCashPermit("P", "R", BillBd.PID, BillBd.PT_CMHS_NO.ToString(), BillBd.RCPT_SQNO.ToString()
                                  , BillBd.RCPT_OCRR_UNIQ_NO, BillBd.BILL_NO, BillBd.MDCR_DD, cashamt, bnacamt);
            }
            catch (Exception ex)
            {
                LxMessage.Show(ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBillNoApply_Click(object sender, EventArgs e)
        {
            try
            {
                BillNoApply();
            }
            catch (Exception ex)
            {
                LxMessage.Show(ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTabletReceipt_Click(object sender, EventArgs e)
        {
            this.TempTabletBill();
        }

        private void ucObillInf1_Disposed(object sender, EventArgs e)
        {
            this.DisposeViewer();
        }

        private void m_viewer_FormClosed(object sender, FormClosedEventArgs e)
        {
            DirectoryInfo di = new DirectoryInfo(clsReceiptPreview.m_ReceiptTempPath);

            foreach (FileInfo file in di.GetFiles())
            {
                file.Delete();
            }
        }

        #endregion

        /*
        void cboBldnYn_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (cboBldnYn.SelectedValue == "N")
                txtBlodRdiaAmt.Text = "0";
            else if (cboBldnYn.SelectedValue == "Y")
                PopUpBloodRdiaInfo();
        }
         * */

        private void cboBldnYn_SelectionChangeCommitted(object sender, EventArgs e)
        {
            // 2019-06-20 SJH 일단 막아놓자.
            return;

            if (cboBldnYn.SelectedValue == "N")
            {
                txtBlodRdiaAmt.Text = "0";
                TxtControl_Leave(txtBlodRdiaAmt, new EventArgs());
                txtCashRcptAmt.Focus();
            }
            else if (cboBldnYn.SelectedValue == "Y")
            {
                PopUpBloodRdiaInfo();
            }
        }
    }
}
