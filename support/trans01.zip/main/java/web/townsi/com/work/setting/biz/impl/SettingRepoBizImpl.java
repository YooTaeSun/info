package web.townsi.com.work.setting.biz.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;
import web.townsi.com.utils.ListUtil;
import web.townsi.com.work.mapper.SettingMapper;
import web.townsi.com.work.setting.biz.SettingBiz;
import web.townsi.com.work.setting.biz.SettingRepoBiz;

/**
* SettingServiceImpl
* @author 유태선
* @since 2020.08.31
* @version 1.0
* @see
* </pre>
*/
@SuppressWarnings({"rawtypes","unchecked","unused"})
@Service
public class SettingRepoBizImpl implements SettingRepoBiz {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private SettingBiz settingBiz;

	@Autowired
	private SettingMapper settingMapper;


	public static String LINE = "\n";
	public static String SPACE_CNT = "    ";
	public static String SLASH = File.separator;// lastIndexOf("/")


	public static String rTxt  = "#{txt}";

	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();
	public static String READ_LINE = "\n";


	public HashMap makeRepo(HashMap params) throws Exception {
		HashMap dataMap = new HashMap();
		HashMap replaceMap = new HashMap();
		StringBuilder dtoMemer = new StringBuilder(500);
		StringBuilder dtoSearcgMemer = new StringBuilder(500);
		StringBuilder dtoMethod = new StringBuilder(500);
		StringBuilder conParam = new StringBuilder(500);
		StringBuilder conParamBody = new StringBuilder(500);

		String column_name = "";
		String mem_vari = "";
		String column_comment = "";
		String camel_column_name = "";
		String camelColumnNameFirstUpper = "";
		String set_get_column_name = "";
		String w_type = "";
		String pk = "";
		String is_nullable = "";

		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String upperTableName = StringUtils.defaultString((String) params.get("upperTableName"));
		String lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		String camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		String tableSchema = StringUtils.defaultString((String) params.get("tableSchema"));
		String camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String group1 = StringUtils.defaultString((String) params.get("group1"));
		String author = StringUtils.defaultString((String) params.get("author"));
		String desc = StringUtils.defaultString((String) params.get("desc"));
		String today = StringUtils.defaultString((String) params.get("today"));
		String current = StringUtils.defaultString((String) params.get("current"));
		String voComment = StringUtils.defaultString((String) params.get("voComment"),"Y_NEXT");
		String sort = StringUtils.defaultString((String) params.get("sort"));
		String taskName = StringUtils.defaultString((String) params.get("taskName"));
		String taskNameFirstUpperName = StringUtils.defaultString((String) params.get("taskNameFirstUpperName"));
		String packageNm = StringUtils.defaultString((String) params.get("packageNm"));
		String tableNewName = StringUtils.defaultString((String) params.get("tableNewName"));
		String tableNewFirstUpperName = StringUtils.defaultString((String) params.get("tableNewFirstUpperName"));
		
		HashMap entityObj = (HashMap) params.get("entityObj");
		String objName = tableName;
		if(entityObj != null && !entityObj.isEmpty()) {
			String tableName2 = StringUtils.defaultString((String) entityObj.get(tableName),"");
			if(!tableName2.isEmpty()) {
				objName = tableName2;
			}
		}
		
		List<HashMap> list = settingBiz.selectTableInfo(params,
				  StringUtils.defaultString((String)params.get("dbName"))
				, StringUtils.defaultString((String)params.get("tableSchema"))
			    , StringUtils.defaultString((String)params.get("tableName"))
				);
		
		
		String columns = "";
		String orderByPK = "";
		String pkStr = "";
		String comments = "";
		String dataType = "";
		StringBuilder whereSql = new StringBuilder(500);
		StringBuilder deleteSql = new StringBuilder(500);
		String pkType =  "";
		
		if(ListUtil.isNotEmpty(list)) {
			
			int cnt = 0; 
			int whereSqlCnt = 0;
			for (int i = 0; i < list.size(); i++) {
				HashMap rs = list.get(i);
				column_name = (String) rs.get("columnName");
				column_comment = (String) rs.get("columnComment");
				camel_column_name = (String) rs.get("camelColumnName");
				camelColumnNameFirstUpper = camel_column_name.substring(0,1).toUpperCase() + camel_column_name.substring(1);
				columns = (String) rs.get("columns");
				comments = (String) rs.get("comments");
				w_type = (String) rs.get("wType");
				dataType = (String) rs.get("dataType");
				pk = StringUtils.defaultString((String) rs.get("pk")).toLowerCase();
				
				comments = comments.trim();
				if(comments.length() > 30) {
					if(comments.indexOf(" ") != -1) {
						comments = comments.substring(0, comments.indexOf(" "));
					}
				}
				
				String name = "";
				String getNameFirstUpper = "";
				String type = "";
				if(entityObj != null && !entityObj.isEmpty()) {
					HashMap<String, String> map = (HashMap<String, String>) entityObj.get(column_name);
					if(map != null && !map.isEmpty()) {
						name = map.get("name");
						if(name.isEmpty()) {
							continue;
						}
						try {
							getNameFirstUpper = name.substring(0,1).toUpperCase() + name.substring(1);	
						} catch (Exception e) {
						}
						
						type = map.get("type");
					}
				}
				
				if("pk".equals(pk)) {
					pkType = w_type;
				}
				
				if(!(camel_column_name.equals("prgmId") 
					|| camel_column_name.equals("frstRegrId")
					|| camel_column_name.equals("frstRgstDt")
					|| camel_column_name.equals("lastUpdrId")
					|| camel_column_name.equals("lastUpdtDt")
					|| camel_column_name.equals("lastIfDttm")
					) ) {
					
					
					if(!comments.isEmpty()) {
						whereSql.append("\t/* " + comments+ " */" + READ_LINE);
						if(i == 0) {
							deleteSql.append("\t/* " + comments+ " */" + READ_LINE);
						}
					}
					if(!name.isEmpty()) {
						whereSql.append("\tList<"+tableNewFirstUpperName+"> findBy"+getNameFirstUpper+"("+w_type+" "+name+");" + READ_LINE);
						if(i == 0) {
							deleteSql.append("\tList<"+tableNewFirstUpperName+"> deleteBy"+getNameFirstUpper+"("+w_type+" "+name+");" + READ_LINE);
						}
					}else {
						whereSql.append("\tList<"+tableNewFirstUpperName+"> findBy"+camelColumnNameFirstUpper+"("+w_type+" "+camel_column_name+");" + READ_LINE);
						if(i == 0) {
							deleteSql.append("\tList<"+tableNewFirstUpperName+"> deleteBy"+camelColumnNameFirstUpper+"("+w_type+" "+camel_column_name+");" + READ_LINE);
						}						
						
					}
					whereSqlCnt++;
				}
				
			}
		}

		if(!taskName.isEmpty()) {
		}
		replaceMap.put("#camelTableFirstUpperName#",taskNameFirstUpperName);
		
		replaceMap.put("#camelTableName#",camelTableName);
		replaceMap.put("#dtoContent#", dtoMemer.toString());
		replaceMap.put("#searchDtoContent#", dtoSearcgMemer.toString());
		replaceMap.put("#lowerTableName#", lowerTableName.replaceAll("_", ""));
		replaceMap.put("#desc#", desc);
		replaceMap.put("#author#", author);
		replaceMap.put("#today#", today);
		replaceMap.put("#current#",current);
		replaceMap.put("#dtoMethod#",dtoMethod.toString());
		replaceMap.put("#upperTableName#",upperTableName);
		replaceMap.put("#pkType#",pkType);
		replaceMap.put("#objNameFirstUpper#", objName.substring(0,1).toUpperCase() + objName.substring(1));
		replaceMap.put("#where#", whereSql.toString().replace("\t", SPACE_CNT));
		replaceMap.put("#delete#", deleteSql.toString().replace("\t", SPACE_CNT));
		replaceMap.put("#packageNm#", packageNm);
		replaceMap.put("#tableNewName#", tableNewName);
		replaceMap.put("#tableNewFirstUpperName#", tableNewFirstUpperName);
		
		 
		String rfullPath = SITE_WEB_ROOT + "/copy/SampleRepo.java";

		String wfullPath = "";
		wfullPath = SITE_WEB_ROOT + "/new/" + tableSchema + "/" + tableName+"/"+tableNewFirstUpperName+"Repo.java";

		String str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);

		dataMap.put("str", str);
		dataMap.put("fullPath", wfullPath);
		list = null;
		return dataMap;
	}
	
	public HashMap searchEntity(HashMap params) throws Exception {
		
		String upperTableName = StringUtils.defaultString((String) params.get("upperTableName"));
		
		String entityFileRoot = SITE_WEB_ROOT + "/copy/entity";
		HashMap<String, Object> colMap = new HashMap<String, Object>();
		
		String filePath = showFilesInDIr(entityFileRoot, upperTableName);
		
		if(!filePath.isEmpty()) {
			BufferedReader br = null;
			br = new BufferedReader(new FileReader(filePath));
			String line = "";
			StringBuilder sb = new StringBuilder(1000);
			StringBuilder sqlSb = null;
			String lineKey = "";
			String colNm2 = "";
			String colVal = "";
			
			LinkedHashMap<String, String> colMap2 = null; 
			int  lineCnt = 0;
			String table2 = "";
			while ((line = br.readLine()) != null) {
				
				if(line.contains(" class ")) {
					table2= line.replace(" class ", "").replace("public", "").replace("{", "").trim();
					colMap.put(upperTableName, table2);
				}
				
				if(line.contains("@Column(name")) {
					colNm2= line.replace("@Column(name", "").replace("\"", "").replace("=", "").replace(")", "").trim();
					if(colNm2.indexOf(",") > -1) {
						colNm2 = colNm2.substring(0, colNm2.indexOf(","));
//						colMap.put(colNm2, null);
						lineCnt = 0; 
					}
					//System.out.println(colNm);
				}else {
					
					if(!line.trim().equals("") && line.contains("private ")) {
						colVal= line.replace("private ", "").replace(";", "").trim();
						String[] sss = colVal.split(" ");
						colMap2 = new LinkedHashMap<String, String>(); 
						colMap2.put("type", sss[0]);
						colMap2.put("name", sss[1]);
						colMap.put(colNm2, colMap2);	
					}
					lineCnt++;					
				}				
			}
			
			System.out.println("----------------------------------------");
			System.out.println(colMap.toString());
			System.out.println("----------------------------------------");
		}
		return colMap;
	}
	
	public static String showFilesInDIr(String dirPath, String upperTableName) throws FileNotFoundException {
	    File dir = new File(dirPath);
	    File files[] = dir.listFiles();
	    String val = "";

	    for (int i = 0; i < files.length; i++) {
	        File file = files[i];
	        if (file.isDirectory()) {
	        	val =  showFilesInDIr(file.getPath(), upperTableName);
	    	    if(!val.isEmpty()) {
	    	    	return file.getPath();
	    	    }
	        } else {
	            System.out.println("file: " + file);
	            String content = FileUtil.readFile(file);

	            if(content.contains(upperTableName)) {
	            	return file.getPath();
	            }
	        }
	    }
	    return val;
	    
	}
	
}