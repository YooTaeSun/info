//********************************************************************
// Class 명 : frmOutReceiptWatingP
// 역    할 : 수납대기자조회 PopUp
// 작 성 자 : PGH
// 작 성 일 : 2017-09-22
//********************************************************************
// 수정내역 : 
//********************************************************************

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public partial class frmOutReceiptWatingP : BasePopUp
    {
    
    	private DOPatientInfo m_PatientInfo = new DOPatientInfo();
        public DOPatientInfo PatientInfo
        {
            get
            {
                return m_PatientInfo;
            }
            set
            {
                m_PatientInfo = value;
            }
        }    
    
        #region Enum : Private Enum
        #endregion Enum : Private Enum

        #region Define : Event
        #endregion Define : Event

        #region Define : Member
        private string m_Pid = String.Empty;   // 환자등록번호
        private int m_PtCmhsNo = 0;              // 환자내원번호
        private string m_MdcrDd = String.Empty;   // 진료일자

        #endregion  Define : Member

        #region Define : Member Property

        public string Pid
        {
            get { return m_Pid; }
        }

        public int PtCmhsNo
        {
            get { return m_PtCmhsNo; }
        }

        public string MdcrDd
        {
            get { return m_MdcrDd; }
        }
        #endregion Define : Member Property

        #region Construction
        public frmOutReceiptWatingP()
        {
            InitializeComponent();
        }
        public frmOutReceiptWatingP(string mdcrdd)
        {
            InitializeComponent();
            if (this.DesignMode) return;

            ucOutRecWatingList1.SetDate(mdcrdd);
        }
        #endregion

        #region Screen Load
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            InitializeEvent();
        }
        #endregion Screen Load

        #region Method : Initialize

        private void InitializeEvent()
        {
            ucOutRecWatingList1.PatientSelected += ucOutRecWatingList1_PatientSelected;
        }

        #endregion  Method : Initialize

        #region Method : Public Method
        #endregion Method : Public Method

        #region Method : Private Method
        #endregion Method : Private Method

        #region Event : Event Process

        void ucOutRecWatingList1_PatientSelected(object sender, ucOutRecWatingList.clsPatientSelected patientinfo)
        {
            if (StringService.IsNull(patientinfo.pid))
            {
                this.DialogResult = DialogResult.Cancel;
                this.Close();
            }

            this.m_Pid = patientinfo.pid;
            this.m_PtCmhsNo = int.Parse(patientinfo.pt_cmhs_no);
            this.m_MdcrDd = patientinfo.mdcr_dd;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        #endregion Event : Event Process

        #region Event : Raise Event
        #endregion Event : Raise Event
    }
}
