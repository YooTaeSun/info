namespace Lime.PA
{
    partial class ucOutRecWatingList
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            FarPoint.Win.Spread.EnhancedScrollBarRenderer enhancedScrollBarRenderer1 = new FarPoint.Win.Spread.EnhancedScrollBarRenderer();
            FarPoint.Win.Spread.EnhancedScrollBarRenderer enhancedScrollBarRenderer2 = new FarPoint.Win.Spread.EnhancedScrollBarRenderer();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucOutRecWatingList));
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab1 = new Infragistics.Win.UltraWinTabControl.UltraTab(true);
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab2 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab3 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab4 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.UltraWinTabControl.UltraTab ultraTab5 = new Infragistics.Win.UltraWinTabControl.UltraTab();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance24 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance23 = new Infragistics.Win.Appearance();
            this.sprWatingList = new Lime.Framework.Controls.LxSpread();
            this.sprWatingList_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.sprWatingList_Sheet2 = new FarPoint.Win.Spread.SheetView();
            this.pnlTop = new Lime.Framework.Controls.LxPanel();
            this.ucMultiDeptCheck1 = new Lime.BusinessControls.ucMultiDeptCheck();
            this.chk70017002 = new Lime.Framework.Controls.LxCheckBox();
            this.dteStrtDd = new Lime.Framework.Controls.LxDateTimeEditor();
            this.cboMdcrDeptCd = new Lime.Framework.Controls.LxComboBox();
            this.lblMdcrDept = new Lime.Framework.Controls.LxLabel();
            this.btnButtonList = new Lime.Framework.Controls.LxButtonList();
            this.lblSearch = new Lime.Framework.Controls.LxTitleLabel();
            this.txtSearch = new Lime.Framework.Controls.LxTextBox();
            this.cboSelName = new Lime.Framework.Controls.LxComboBox();
            this.dteEndDd = new Lime.Framework.Controls.LxDateTimeEditor();
            this.tbsWatingList = new Lime.Framework.Controls.LxTabStripControl();
            this.ultraTabSharedControlsPage1 = new Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage();
            this.lxTitlePanel1 = new Lime.Framework.Controls.LxTitlePanel();
            this.lxPanel2 = new Lime.Framework.Controls.LxPanel();
            this.lxTitlePanel2 = new Lime.Framework.Controls.LxTitlePanel();
            this.lxPanel1 = new Lime.Framework.Controls.LxPanel();
            this.lxPanel3 = new Lime.Framework.Controls.LxPanel();
            this.lxLabel3 = new Lime.Framework.Controls.LxLabel();
            this.lxLabel1 = new Lime.Framework.Controls.LxLabel();
            this.lxLabel2 = new Lime.Framework.Controls.LxLabel();
            this.lblJ = new Lime.Framework.Controls.LxLabel();
            this.lxLabel4 = new Lime.Framework.Controls.LxLabel();
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprWatingList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprWatingList_Sheet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprWatingList_Sheet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlTop)).BeginInit();
            this.pnlTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chk70017002)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteStrtDd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboMdcrDeptCd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblMdcrDept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnButtonList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSearch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSearch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboSelName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteEndDd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbsWatingList)).BeginInit();
            this.tbsWatingList.SuspendLayout();
            this.ultraTabSharedControlsPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitlePanel1)).BeginInit();
            this.lxTitlePanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel2)).BeginInit();
            this.lxPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxTitlePanel2)).BeginInit();
            this.lxTitlePanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel1)).BeginInit();
            this.lxPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel3)).BeginInit();
            this.lxPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblJ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBase
            // 
            this.pnlBase.Size = new System.Drawing.Size(1200, 800);
            // 
            // sprWatingList
            // 
            this.sprWatingList.AccessibleDescription = "";
            this.sprWatingList.AllowUserZoom = false;
            this.sprWatingList.AutoFirstAppendRow = false;
            this.sprWatingList.BackColor = System.Drawing.Color.White;
            this.sprWatingList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.sprWatingList.ButtonDrawMode = FarPoint.Win.Spread.ButtonDrawModes.CurrentCell;
            this.sprWatingList.ColumnSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never;
            this.sprWatingList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sprWatingList.EditModePermanent = true;
            this.sprWatingList.EditModeReplace = true;
            this.sprWatingList.FocusRenderer = new FarPoint.Win.Spread.EnhancedFocusIndicatorRenderer(1);
            this.sprWatingList.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.sprWatingList.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.sprWatingList.HorizontalScrollBar.Name = "";
            enhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            enhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(190)))), ((int)(((byte)(190)))));
            this.sprWatingList.HorizontalScrollBar.Renderer = enhancedScrollBarRenderer1;
            this.sprWatingList.HorizontalScrollBar.TabIndex = 0;
            this.sprWatingList.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.sprWatingList.Location = new System.Drawing.Point(0, 0);
            this.sprWatingList.Name = "sprWatingList";
            this.sprWatingList.RowSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never;
            this.sprWatingList.ScrollBarTrackPolicy = FarPoint.Win.Spread.ScrollBarTrackPolicy.Both;
            this.sprWatingList.ScrollTipPolicy = FarPoint.Win.Spread.ScrollTipPolicy.Both;
            this.sprWatingList.SelectionBlockOptions = FarPoint.Win.Spread.SelectionBlockOptions.Rows;
            this.sprWatingList.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.sprWatingList_Sheet1,
            this.sprWatingList_Sheet2});
            this.sprWatingList.Size = new System.Drawing.Size(1186, 721);
            this.sprWatingList.TabIndex = 0;
            this.sprWatingList.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.sprWatingList.VerticalScrollBar.Name = "";
            enhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            enhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            enhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            enhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            enhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            enhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(190)))), ((int)(((byte)(190)))));
            this.sprWatingList.VerticalScrollBar.Renderer = enhancedScrollBarRenderer2;
            this.sprWatingList.VerticalScrollBar.TabIndex = 1;
            this.sprWatingList.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            // 
            // sprWatingList_Sheet1
            // 
            this.sprWatingList_Sheet1.Reset();
            this.sprWatingList_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.sprWatingList_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.sprWatingList_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.sprWatingList_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // sprWatingList_Sheet2
            // 
            this.sprWatingList_Sheet2.Reset();
            this.sprWatingList_Sheet2.SheetName = "Sheet2";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.sprWatingList_Sheet2.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.sprWatingList_Sheet2.RowHeader.Columns.Default.Resizable = false;
            this.sprWatingList_Sheet2.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.Controls.Add(this.ucMultiDeptCheck1);
            this.pnlTop.Controls.Add(this.chk70017002);
            this.pnlTop.Controls.Add(this.dteStrtDd);
            this.pnlTop.Controls.Add(this.cboMdcrDeptCd);
            this.pnlTop.Controls.Add(this.lblMdcrDept);
            this.pnlTop.Controls.Add(this.btnButtonList);
            this.pnlTop.Controls.Add(this.lblSearch);
            this.pnlTop.Controls.Add(this.txtSearch);
            this.pnlTop.Controls.Add(this.cboSelName);
            this.pnlTop.Controls.Add(this.dteEndDd);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.pnlTop.Location = new System.Drawing.Point(3, 3);
            this.pnlTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Padding = new System.Windows.Forms.Padding(0, 4, 0, 0);
            this.pnlTop.Size = new System.Drawing.Size(1194, 37);
            this.pnlTop.TabIndex = 1;
            // 
            // ucMultiDeptCheck1
            // 
            this.ucMultiDeptCheck1.Location = new System.Drawing.Point(236, 8);
            this.ucMultiDeptCheck1.MaximumSize = new System.Drawing.Size(232, 21);
            this.ucMultiDeptCheck1.Name = "ucMultiDeptCheck1";
            this.ucMultiDeptCheck1.Size = new System.Drawing.Size(124, 21);
            this.ucMultiDeptCheck1.TabIndex = 15;
            // 
            // chk70017002
            // 
            appearance1.BackColor = System.Drawing.Color.White;
            appearance1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.chk70017002.Appearance = appearance1;
            this.chk70017002.BackColor = System.Drawing.Color.White;
            this.chk70017002.BackColorInternal = System.Drawing.Color.White;
            this.chk70017002.Checked = true;
            this.chk70017002.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chk70017002.Location = new System.Drawing.Point(550, 9);
            this.chk70017002.Name = "chk70017002";
            this.chk70017002.Size = new System.Drawing.Size(125, 20);
            this.chk70017002.TabIndex = 14;
            this.chk70017002.Text = "검진접수환자 제외";
            this.chk70017002.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.chk70017002.UseLimeStyle = false;
            this.chk70017002.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // dteStrtDd
            // 
            appearance2.BackColor = System.Drawing.Color.White;
            appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance2.TextHAlignAsString = "Center";
            appearance2.TextVAlignAsString = "Middle";
            this.dteStrtDd.Appearance = appearance2;
            this.dteStrtDd.BackColor = System.Drawing.Color.White;
            this.dteStrtDd.DateTime = new System.DateTime(2018, 2, 21, 0, 0, 0, 0);
            this.dteStrtDd.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.dteStrtDd.Location = new System.Drawing.Point(69, 7);
            this.dteStrtDd.Name = "dteStrtDd";
            this.dteStrtDd.Size = new System.Drawing.Size(101, 23);
            this.dteStrtDd.TabIndex = 12;
            this.dteStrtDd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.dteStrtDd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.dteStrtDd.Value = new System.DateTime(2018, 2, 21, 0, 0, 0, 0);
            // 
            // cboMdcrDeptCd
            // 
            appearance3.BackColor = System.Drawing.Color.White;
            appearance3.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance3.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboMdcrDeptCd.Appearance = appearance3;
            this.cboMdcrDeptCd.AutoSize = false;
            this.cboMdcrDeptCd.BackColor = System.Drawing.Color.White;
            this.cboMdcrDeptCd.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance4.BackColor = System.Drawing.Color.Transparent;
            appearance4.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance4.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance4.BorderColor = System.Drawing.Color.Transparent;
            appearance4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance4.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboMdcrDeptCd.ButtonAppearance = appearance4;
            this.cboMdcrDeptCd.Location = new System.Drawing.Point(236, 7);
            this.cboMdcrDeptCd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cboMdcrDeptCd.Name = "cboMdcrDeptCd";
            appearance5.BackColor = System.Drawing.Color.White;
            appearance5.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance5.ForeColor = System.Drawing.Color.DarkGray;
            appearance5.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboMdcrDeptCd.NullTextAppearance = appearance5;
            this.cboMdcrDeptCd.SelectedValue = "";
            this.cboMdcrDeptCd.Size = new System.Drawing.Size(124, 23);
            this.cboMdcrDeptCd.TabIndex = 3;
            this.cboMdcrDeptCd.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboMdcrDeptCd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboMdcrDeptCd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblMdcrDept
            // 
            appearance6.BackColor = System.Drawing.Color.Transparent;
            appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance6.FontData.Name = "맑은 고딕";
            appearance6.FontData.SizeInPoints = 9F;
            appearance6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance6.TextHAlignAsString = "Left";
            appearance6.TextVAlignAsString = "Middle";
            this.lblMdcrDept.Appearance = appearance6;
            this.lblMdcrDept.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.None;
            this.lblMdcrDept.Location = new System.Drawing.Point(181, 8);
            this.lblMdcrDept.Name = "lblMdcrDept";
            this.lblMdcrDept.Size = new System.Drawing.Size(54, 21);
            this.lblMdcrDept.TabIndex = 8;
            this.lblMdcrDept.Text = "진료부서";
            this.lblMdcrDept.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblMdcrDept.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // btnButtonList
            // 
            this.btnButtonList.BackColor = System.Drawing.Color.White;
            this.btnButtonList.ButtonItems.AddRange(new Lime.Framework.Controls.ButtonItem[] {
            new Lime.Framework.Controls.ButtonItem(Lime.Framework.Controls.ButtonType.Select, "조 회", "Select", System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50))))), System.Drawing.Color.White, true),
            new Lime.Framework.Controls.ButtonItem(Lime.Framework.Controls.ButtonType.Close, "닫 기", "Close", System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(85)))), ((int)(((byte)(100))))), System.Drawing.Color.White, true)});
            
            this.btnButtonList.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnButtonList.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.btnButtonList.Location = new System.Drawing.Point(1064, 4);
            this.btnButtonList.MaximumSize = new System.Drawing.Size(1920, 28);
            this.btnButtonList.Name = "btnButtonList";
            this.btnButtonList.Size = new System.Drawing.Size(130, 28);
            this.btnButtonList.TabIndex = 4;
            // 
            // lblSearch
            // 
            appearance7.BackColor = System.Drawing.Color.Transparent;
            appearance7.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance7.FontData.Name = "맑은 고딕";
            appearance7.FontData.SizeInPoints = 9F;
            appearance7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance7.TextHAlignAsString = "Right";
            appearance7.TextVAlignAsString = "Middle";
            this.lblSearch.Appearance = appearance7;
            this.lblSearch.Location = new System.Drawing.Point(363, 7);
            this.lblSearch.Margin = new System.Windows.Forms.Padding(0);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(34, 23);
            this.lblSearch.TabIndex = 7;
            this.lblSearch.Text = "검색";
            this.lblSearch.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblSearch.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // txtSearch
            // 
            appearance8.BackColor = System.Drawing.Color.White;
            appearance8.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance8.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtSearch.Appearance = appearance8;
            this.txtSearch.AutoSize = false;
            this.txtSearch.BackColor = System.Drawing.Color.White;
            this.txtSearch.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.txtSearch.Location = new System.Drawing.Point(400, 7);
            this.txtSearch.Name = "txtSearch";
            appearance9.BackColor = System.Drawing.Color.White;
            appearance9.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            appearance9.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance9.ForeColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.txtSearch.NullTextAppearance = appearance9;
            this.txtSearch.Size = new System.Drawing.Size(142, 23);
            this.txtSearch.TabIndex = 0;
            this.txtSearch.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.txtSearch.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // cboSelName
            // 
            appearance10.BackColor = System.Drawing.Color.White;
            appearance10.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance10.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance10.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboSelName.Appearance = appearance10;
            this.cboSelName.AutoSize = false;
            this.cboSelName.BackColor = System.Drawing.Color.White;
            this.cboSelName.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            appearance11.BackColor = System.Drawing.Color.Transparent;
            appearance11.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance11.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance11.BorderColor = System.Drawing.Color.Transparent;
            appearance11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance11.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboSelName.ButtonAppearance = appearance11;
            this.cboSelName.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList;
            this.cboSelName.Location = new System.Drawing.Point(3, 7);
            this.cboSelName.Name = "cboSelName";
            appearance12.BackColor = System.Drawing.Color.White;
            appearance12.BackColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            appearance12.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            appearance12.ForeColor = System.Drawing.Color.DarkGray;
            appearance12.ForeColorDisabled = System.Drawing.Color.DarkGray;
            this.cboSelName.NullTextAppearance = appearance12;
            this.cboSelName.SelectedValue = "";
            this.cboSelName.Size = new System.Drawing.Size(63, 23);
            this.cboSelName.TabIndex = 4;
            this.cboSelName.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.cboSelName.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.cboSelName.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // dteEndDd
            // 
            appearance13.BackColor = System.Drawing.Color.White;
            appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance13.TextHAlignAsString = "Center";
            appearance13.TextVAlignAsString = "Middle";
            this.dteEndDd.Appearance = appearance13;
            this.dteEndDd.BackColor = System.Drawing.Color.White;
            this.dteEndDd.Location = new System.Drawing.Point(181, 7);
            this.dteEndDd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dteEndDd.Name = "dteEndDd";
            this.dteEndDd.Size = new System.Drawing.Size(123, 23);
            this.dteEndDd.TabIndex = 1;
            this.dteEndDd.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.dteEndDd.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.dteEndDd.Visible = false;
            // 
            // tbsWatingList
            // 
            appearance14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            appearance14.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            appearance14.BorderColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            appearance14.BorderColor3DBase = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance14.FontData.BoldAsString = "True";
            appearance14.FontData.Name = "맑은 고딕";
            appearance14.FontData.SizeInPoints = 9F;
            appearance14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(34)))), ((int)(((byte)(184)))));
            appearance14.ImageBackground = ((System.Drawing.Image)(resources.GetObject("appearance14.ImageBackground")));
            appearance14.ImageBackgroundStyle = Infragistics.Win.ImageBackgroundStyle.Stretched;
            appearance14.TextHAlignAsString = "Center";
            appearance14.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance14.TextVAlignAsString = "Middle";
            this.tbsWatingList.ActiveTabAppearance = appearance14;
            this.tbsWatingList.AlphaBlendMode = Infragistics.Win.AlphaBlendMode.Disabled;
            appearance15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            appearance15.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            appearance15.BorderColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            appearance15.BorderColor3DBase = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance15.FontData.BoldAsString = "False";
            appearance15.FontData.Name = "맑은 고딕";
            appearance15.FontData.SizeInPoints = 9F;
            appearance15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            appearance15.TextHAlignAsString = "Center";
            appearance15.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance15.TextVAlignAsString = "Middle";
            this.tbsWatingList.Appearance = appearance15;
            appearance16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            appearance16.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance16.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance16.BorderColor3DBase = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(157)))));
            this.tbsWatingList.ClientAreaAppearance = appearance16;
            this.tbsWatingList.Controls.Add(this.ultraTabSharedControlsPage1);
            this.tbsWatingList.Dock = System.Windows.Forms.DockStyle.Fill;
            appearance17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            appearance17.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance17.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            appearance17.BorderColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            appearance17.BorderColor3DBase = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            appearance17.FontData.BoldAsString = "True";
            appearance17.FontData.Name = "맑은 고딕";
            appearance17.FontData.SizeInPoints = 10F;
            appearance17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(34)))), ((int)(((byte)(184)))));
            appearance17.TextHAlignAsString = "Center";
            appearance17.TextTrimming = Infragistics.Win.TextTrimming.None;
            appearance17.TextVAlignAsString = "Middle";
            this.tbsWatingList.HotTrackAppearance = appearance17;
            this.tbsWatingList.Location = new System.Drawing.Point(0, 0);
            this.tbsWatingList.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbsWatingList.MaxVisibleTabRows = 1;
            this.tbsWatingList.MultiRowSelectionStyle = Infragistics.Win.UltraWinTabs.MultiRowSelectionStyle.HighlightTab;
            this.tbsWatingList.Name = "tbsWatingList";
            appearance18.BackColor = System.Drawing.Color.White;
            appearance18.FontData.BoldAsString = "True";
            appearance18.ForeColor = System.Drawing.Color.Black;
            appearance18.TextHAlignAsString = "Center";
            appearance18.TextVAlignAsString = "Middle";
            this.tbsWatingList.SelectedTabAppearance = appearance18;
            this.tbsWatingList.SharedControls.AddRange(new System.Windows.Forms.Control[] {
            this.lxTitlePanel1});
            this.tbsWatingList.SharedControlsPage = this.ultraTabSharedControlsPage1;
            this.tbsWatingList.Size = new System.Drawing.Size(1194, 757);
            this.tbsWatingList.SpaceAfterTabs = new Infragistics.Win.DefaultableInteger(0);
            this.tbsWatingList.SpaceBeforeTabs = new Infragistics.Win.DefaultableInteger(0);
            this.tbsWatingList.Style = Infragistics.Win.UltraWinTabControl.UltraTabControlStyle.VisualStudio;
            appearance19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance19.FontData.BoldAsString = "True";
            appearance19.TextHAlignAsString = "Center";
            appearance19.TextVAlignAsString = "Middle";
            this.tbsWatingList.TabHeaderAreaAppearance = appearance19;
            this.tbsWatingList.TabIndex = 1;
            this.tbsWatingList.TabOrientation = Infragistics.Win.UltraWinTabs.TabOrientation.Default;
            this.tbsWatingList.TabPadding = new System.Drawing.Size(5, 0);
            ultraTab1.Text = "진료대기";
            ultraTab2.Text = "수납대기";
            ultraTab3.Text = "수납완료";
            ultraTab4.Text = "수납대상";
            ultraTab4.Visible = false;
            ultraTab5.Text = "유형변경미수납";
            ultraTab5.Visible = false;
            this.tbsWatingList.Tabs.AddRange(new Infragistics.Win.UltraWinTabControl.UltraTab[] {
            ultraTab1,
            ultraTab2,
            ultraTab3,
            ultraTab4,
            ultraTab5});
            this.tbsWatingList.TabSize = new System.Drawing.Size(0, 28);
            this.tbsWatingList.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.tbsWatingList.UseHotTracking = Infragistics.Win.DefaultableBoolean.True;
            this.tbsWatingList.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.tbsWatingList.ViewStyle = Infragistics.Win.UltraWinTabControl.ViewStyle.Standard;
            // 
            // ultraTabSharedControlsPage1
            // 
            this.ultraTabSharedControlsPage1.Controls.Add(this.lxTitlePanel1);
            this.ultraTabSharedControlsPage1.Location = new System.Drawing.Point(1, 29);
            this.ultraTabSharedControlsPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ultraTabSharedControlsPage1.Name = "ultraTabSharedControlsPage1";
            this.ultraTabSharedControlsPage1.Size = new System.Drawing.Size(1192, 727);
            // 
            // lxTitlePanel1
            // 
            this.lxTitlePanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.lxTitlePanel1.BottomBarVisible = false;
            this.lxTitlePanel1.BottomText = "";
            this.lxTitlePanel1.Controls.Add(this.lxPanel2);
            this.lxTitlePanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lxTitlePanel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxTitlePanel1.Location = new System.Drawing.Point(0, 0);
            this.lxTitlePanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.lxTitlePanel1.Name = "lxTitlePanel1";
            this.lxTitlePanel1.Padding = new System.Windows.Forms.Padding(3);
            this.lxTitlePanel1.Size = new System.Drawing.Size(1192, 727);
            this.lxTitlePanel1.TabIndex = 1;
            this.lxTitlePanel1.TitleBarVisible = false;
            // 
            // lxPanel2
            // 
            this.lxPanel2.BackColor = System.Drawing.Color.White;
            this.lxPanel2.Controls.Add(this.sprWatingList);
            this.lxPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lxPanel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxPanel2.Location = new System.Drawing.Point(3, 3);
            this.lxPanel2.Name = "lxPanel2";
            this.lxPanel2.Size = new System.Drawing.Size(1186, 721);
            this.lxPanel2.TabIndex = 2;
            // 
            // lxTitlePanel2
            // 
            this.lxTitlePanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.lxTitlePanel2.BottomBarVisible = false;
            this.lxTitlePanel2.BottomText = "";
            this.lxTitlePanel2.Controls.Add(this.lxPanel1);
            this.lxTitlePanel2.Controls.Add(this.pnlTop);
            this.lxTitlePanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lxTitlePanel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxTitlePanel2.Location = new System.Drawing.Point(0, 0);
            this.lxTitlePanel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.lxTitlePanel2.Name = "lxTitlePanel2";
            this.lxTitlePanel2.Padding = new System.Windows.Forms.Padding(3);
            this.lxTitlePanel2.Size = new System.Drawing.Size(1200, 800);
            this.lxTitlePanel2.TabIndex = 2;
            this.lxTitlePanel2.TitleBarVisible = false;
            this.lxTitlePanel2.TitleText = "수납대기자";
            // 
            // lxPanel1
            // 
            this.lxPanel1.BackColor = System.Drawing.Color.White;
            this.lxPanel1.Controls.Add(this.lxPanel3);
            this.lxPanel1.Controls.Add(this.tbsWatingList);
            this.lxPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lxPanel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxPanel1.Location = new System.Drawing.Point(3, 40);
            this.lxPanel1.Name = "lxPanel1";
            this.lxPanel1.Size = new System.Drawing.Size(1194, 757);
            this.lxPanel1.TabIndex = 2;
            // 
            // lxPanel3
            // 
            this.lxPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lxPanel3.BackColor = System.Drawing.Color.White;
            this.lxPanel3.Controls.Add(this.lxLabel3);
            this.lxPanel3.Controls.Add(this.lxLabel1);
            this.lxPanel3.Controls.Add(this.lxLabel2);
            this.lxPanel3.Controls.Add(this.lxLabel4);
            this.lxPanel3.Controls.Add(this.lblJ);
            this.lxPanel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lxPanel3.Location = new System.Drawing.Point(838, 2);
            this.lxPanel3.Name = "lxPanel3";
            this.lxPanel3.Size = new System.Drawing.Size(352, 24);
            this.lxPanel3.TabIndex = 2;
            // 
            // lxLabel3
            // 
            this.lxLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            appearance20.BackColor = System.Drawing.Color.Transparent;
            appearance20.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance20.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance20.FontData.Name = "맑은 고딕";
            appearance20.FontData.SizeInPoints = 9F;
            appearance20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            appearance20.TextHAlignAsString = "Left";
            appearance20.TextVAlignAsString = "Middle";
            this.lxLabel3.Appearance = appearance20;
            this.lxLabel3.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.None;
            this.lxLabel3.Location = new System.Drawing.Point(7, 2);
            this.lxLabel3.Name = "lxLabel3";
            this.lxLabel3.Size = new System.Drawing.Size(71, 21);
            this.lxLabel3.TabIndex = 11;
            this.lxLabel3.Text = "■ 진료대기";
            this.lxLabel3.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lxLabel3.UseLimeStyle = false;
            this.lxLabel3.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lxLabel1
            // 
            this.lxLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            appearance21.BackColor = System.Drawing.Color.Transparent;
            appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance21.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance21.FontData.Name = "맑은 고딕";
            appearance21.FontData.SizeInPoints = 9F;
            appearance21.ForeColor = System.Drawing.Color.Blue;
            appearance21.TextHAlignAsString = "Left";
            appearance21.TextVAlignAsString = "Middle";
            this.lxLabel1.Appearance = appearance21;
            this.lxLabel1.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.None;
            this.lxLabel1.Location = new System.Drawing.Point(85, 2);
            this.lxLabel1.Name = "lxLabel1";
            this.lxLabel1.Size = new System.Drawing.Size(61, 21);
            this.lxLabel1.TabIndex = 10;
            this.lxLabel1.Text = "■ 진료중";
            this.lxLabel1.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lxLabel1.UseLimeStyle = false;
            this.lxLabel1.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lxLabel2
            // 
            this.lxLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            appearance22.BackColor = System.Drawing.Color.Transparent;
            appearance22.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance22.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance22.FontData.Name = "맑은 고딕";
            appearance22.FontData.SizeInPoints = 9F;
            appearance22.ForeColor = System.Drawing.Color.Red;
            appearance22.TextHAlignAsString = "Left";
            appearance22.TextVAlignAsString = "Middle";
            this.lxLabel2.Appearance = appearance22;
            this.lxLabel2.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.None;
            this.lxLabel2.Location = new System.Drawing.Point(152, 2);
            this.lxLabel2.Name = "lxLabel2";
            this.lxLabel2.Size = new System.Drawing.Size(71, 21);
            this.lxLabel2.TabIndex = 9;
            this.lxLabel2.Text = "■ 진료완료";
            this.lxLabel2.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lxLabel2.UseLimeStyle = false;
            this.lxLabel2.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lblJ
            // 
            this.lblJ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            appearance24.BackColor = System.Drawing.Color.Transparent;
            appearance24.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance24.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance24.FontData.Name = "맑은 고딕";
            appearance24.FontData.SizeInPoints = 9F;
            appearance24.ForeColor = System.Drawing.Color.Green;
            appearance24.TextHAlignAsString = "Left";
            appearance24.TextVAlignAsString = "Middle";
            this.lblJ.Appearance = appearance24;
            this.lblJ.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.None;
            this.lblJ.Location = new System.Drawing.Point(230, 2);
            this.lblJ.Name = "lblJ";
            this.lblJ.Size = new System.Drawing.Size(51, 21);
            this.lblJ.TabIndex = 8;
            this.lblJ.Text = "■ 귀가";
            this.lblJ.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lblJ.UseLimeStyle = false;
            this.lblJ.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // lxLabel4
            // 
            this.lxLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            appearance23.BackColor = System.Drawing.Color.Transparent;
            appearance23.BackGradientStyle = Infragistics.Win.GradientStyle.None;
            appearance23.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            appearance23.FontData.Name = "맑은 고딕";
            appearance23.FontData.SizeInPoints = 9F;
            appearance23.ForeColor = System.Drawing.Color.Magenta;
            appearance23.TextHAlignAsString = "Left";
            appearance23.TextVAlignAsString = "Middle";
            this.lxLabel4.Appearance = appearance23;
            this.lxLabel4.BorderStyleOuter = Infragistics.Win.UIElementBorderStyle.None;
            this.lxLabel4.Location = new System.Drawing.Point(287, 2);
            this.lxLabel4.Name = "lxLabel4";
            this.lxLabel4.Size = new System.Drawing.Size(62, 21);
            this.lxLabel4.TabIndex = 8;
            this.lxLabel4.Text = "■ 과취소";
            this.lxLabel4.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.lxLabel4.UseLimeStyle = false;
            this.lxLabel4.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // ucOutRecWatingList
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.lxTitlePanel2);
            this.Name = "ucOutRecWatingList";
            this.Size = new System.Drawing.Size(1200, 800);
            this.Controls.SetChildIndex(this.pnlBase, 0);
            this.Controls.SetChildIndex(this.lxTitlePanel2, 0);
            ((System.ComponentModel.ISupportInitialize)(this.pnlBase)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprWatingList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprWatingList_Sheet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprWatingList_Sheet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlTop)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chk70017002)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteStrtDd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboMdcrDeptCd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblMdcrDept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnButtonList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSearch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSearch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboSelName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dteEndDd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbsWatingList)).EndInit();
            this.tbsWatingList.ResumeLayout(false);
            this.ultraTabSharedControlsPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lxTitlePanel1)).EndInit();
            this.lxTitlePanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel2)).EndInit();
            this.lxPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lxTitlePanel2)).EndInit();
            this.lxTitlePanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel1)).EndInit();
            this.lxPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lxPanel3)).EndInit();
            this.lxPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lxLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblJ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Framework.Controls.LxSpread sprWatingList;
        private FarPoint.Win.Spread.SheetView sprWatingList_Sheet1;
        private Framework.Controls.LxPanel pnlTop;
        private Framework.Controls.LxTabStripControl tbsWatingList;
        private Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage ultraTabSharedControlsPage1;
        private Framework.Controls.LxComboBox cboMdcrDeptCd;
        private Framework.Controls.LxTitlePanel lxTitlePanel1;
        private Framework.Controls.LxTitlePanel lxTitlePanel2;
        private Framework.Controls.LxComboBox cboSelName;
        private Framework.Controls.LxTextBox txtSearch;
        private FarPoint.Win.Spread.SheetView sprWatingList_Sheet2;
        private Framework.Controls.LxTitleLabel lblSearch;
        private Framework.Controls.LxPanel lxPanel1;
        private Framework.Controls.LxPanel lxPanel2;
        private Framework.Controls.LxButtonList btnButtonList;
        private Framework.Controls.LxDateTimeEditor dteEndDd;
        private Framework.Controls.LxLabel lblMdcrDept;
        private Framework.Controls.LxDateTimeEditor dteStrtDd;
        private Framework.Controls.LxPanel lxPanel3;
        private Framework.Controls.LxLabel lxLabel2;
        private Framework.Controls.LxLabel lblJ;
        private Framework.Controls.LxLabel lxLabel3;
        private Framework.Controls.LxLabel lxLabel1;
        private Framework.Controls.LxCheckBox chk70017002;
        private BusinessControls.ucMultiDeptCheck ucMultiDeptCheck1;
        private Framework.Controls.LxLabel lxLabel4;
    }
}
