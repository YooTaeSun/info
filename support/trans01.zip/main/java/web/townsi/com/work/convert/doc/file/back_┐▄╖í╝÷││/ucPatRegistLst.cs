//********************************************************************************
// Class 명 : ucIOSpread
// 역    할 : 환자의 외래내원 이력을 가져온다.
// 작 성 자 : PGH
// 작 성 일 : 2017-08-24
//********************************************************************************
// 수정내역 : 
//********************************************************************************
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lime.Framework;
using Lime.Framework.Controls;
using SQL = Lime.SqlPack;

namespace Lime.PA
{
    public partial class ucPatRegistLst : BaseUserControl
    {
        private enum COL
        {
            PRSC_YN,
            RCPT_YN,

            DRUG_IN_OUT,
            DRUG_NODY,

            MDCR_DD,
            MDCR_DEPT_CD,
            MDCR_DR_NM,
            REAL_MDCR_DR_NM,
            PT_MDCR_STAT_DVNM,
            MDCR_TIME,
            RGST_TIME,
            INSN_TYCD,
            ASST_TYCD,
            ASST_TYNM,
            ETC_USE_CNTS_1,
            ETC_USE_CNTS_1_NM,
            FRVS_RVST_DVCD,
            CMHS_DVCD,
            MCCH_CMPT_DVCD,

            EMRM_MMCD_CD,
            FCLT_APLY_YN,
            APNT_YN,
            APNT_PATH_DVCD,
            EXCP_RESN_CD,
            USCH_APLY_CD,
            DCNT_RDIA_CD,
            DCNT_RDIA_EMNO,
            CFSC_RGNO_CD,
            DY_WARD_YN,
            PT_MDCR_STAT_DVCD,
            APNT_TIME,
            RGSTR_ID,
            PT_CMHS_NO,
            MDCR_DR_CD,
            ROW_STAT_DVCD,
            RCPN_SQNO,
            ASCT_RGNO_CD,
            PID,
        }


        #region Define Event

        public delegate void NewPatientSelected(string pid, int pt_cmhs_no);
        public event NewPatientSelected OnNewPatientSelect;

        public delegate void ScreenSelect(string key, string pid, string ptcmhsno, string mdcrdeptcd, string mdcrdrcd, string mdcrdd);
        public event ScreenSelect ScreenSelected;

        public delegate void PatRegSelected(string pid, string ptcmhsno, string mdcrdd);
        public event PatRegSelected OnPatRegSelected;

        #endregion

        #region Define Variable Member
        DOPatientInfo m_PatientInfo = new DOPatientInfo();
        private clsPastRegistrationInfo m_PastRegInfo = new clsPastRegistrationInfo();

        private bool m_isREGCHNG = false; //YJS추가, 외래접수 변경 화면에서 '접수변경' ContextMenu와 취소내역이 나오지 않게 하기 위해 사용. 

        private bool m_ReadOnly = false;

        private Font m_BoldFont = new Font("맑은 고딕", 9, FontStyle.Bold);
        #endregion

        #region Member Property

        /// <summary>
        /// '접수변경' ContextMenu를 표시하는지 여부.
        /// </summary>
        [Browsable(true)]
        [Category("Lime Custom")]
        [Description("ContextMenu를 표시하는지 여부.")]
        [DefaultValue(true)]
        [MergableProperty(true)]
        public bool isREGCHNG
        {
            get
            {
                return m_isREGCHNG;
            }
            set
            {
                m_isREGCHNG = value;
            }
        }

        public DOPatientInfo PatientInfo
        {
            get
            {
                return m_PatientInfo;
            }
            set
            {
                m_PatientInfo = value;
            }
        }

        public clsPastRegistrationInfo PastRegInfo
        {
            get { return m_PastRegInfo; }
            set { m_PastRegInfo = value; }
        }

        public bool ReadOnly
        {
            set { m_ReadOnly = value; }
        }
        #endregion

        #region Contstruction
        public ucPatRegistLst()
        {
            InitializeComponent();
        }
        #endregion Construction

        #region Screen Load

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (this.DesignMode)
                return;

            Initialize();
        }

        #endregion Screen Load

        #region Initialize
        private void Initialize()
        {
            sprList.ActiveSheet.Columns[sprList.GetTagToColumnIndex("ASST_TYCD")].Visible = false;

            // 예약구분코드
            sprList.SetComboItems("APNT_PATH_DVCD", clsPACommon.GetDtBICDINDT("APNT_PATH_DVCD", "N", DateTime.Now.ToString("yyyyMMdd")), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            // 진료과목코드
            sprList.SetComboItems("MDCR_DEPT_CD", clsPACommon.GetDtCbo("DEPT_CD", "1", DateTime.Now.ToString("yyyyMMdd")), "DEPT_CD", "DEPT_HNM");
            // 초재구분코드
            sprList.SetComboItems("FRVS_RVST_DVCD", clsPACommon.GetDtBICDINDT("FRVS_RVST_DVCD", "N", DateTime.Now.ToString("yyyyMMdd")), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            // 보험유형코드
            sprList.SetComboItems("INSN_TYCD", clsPACommon.GetDtBICDINDT("INSN_TYCD", "N", DateTime.Now.ToString("yyyyMMdd")), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            // 보조유형코드
            sprList.SetComboItems("ASST_TYCD", clsPACommon.GetDtBICDINDT("ASST_TYCD", "N", DateTime.Now.ToString("yyyyMMdd")), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            // 진찰료산정구분코드
            sprList.SetComboItems("MCCH_CMPT_DVCD", clsPACommon.GetDtBICDINDT("MCCH_CMPT_DVCD", "N", DateTime.Now.ToString("yyyyMMdd")), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            // 내원구분코드
            sprList.SetComboItems("CMHS_DVCD", clsPACommon.GetDtBICDINDT("CMHS_DVCD", "N", DateTime.Now.ToString("yyyyMMdd")), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            //진료상태구분코드
            sprList.SetComboItems("PT_MDCR_STAT_DVCD", OverallCodeList.GetDataList("PT_MDCR_STAT_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            //응급실주과
            sprList.SetComboItems("EMRM_MMCD_CD", DeptList.LoadList(), "DEPT_CD", "DEPT_HNM");
            // 예약경로구분코드
            sprList.SetComboItems("APNT_PATH_DVCD", OverallCodeList.GetDataList("APNT_PATH_DVCD"), "LWRN_OVRL_CD", "LWRN_OVRL_CDNM");
            // 응급실내원 빨간색 표시할지 여부
            lblER.Visible = ConfigService.GetConfigValueBool("PA", "OUT_REG", "LIST_ER_CHEK_YN", false);

            sprList.EditModePermanent = false;
            dteFrom.DateTime = DateTime.Today.AddYears(-1).AddDays(1);
            dteTo.DateTime = DateTime.Today;

            sprList.CellClick += spdPatRegLst_CellClick;
            this.ContextMenuClick += ucPatRegistLst_ContextMenuClick;
            sprList.CellDoubleClick += spdPatRegLst_CellDoubleClick;
            sprList.KeyDown += spdPatRegLst_KeyDown;
            chkCancelAppoint.CheckedChanged += chkCancelAppoint_CheckedChanged;
            dteFrom.ValueChanged += dteFrom_ValueChanged;
            dteTo.ValueChanged += dteTo_ValueChanged;
        }

        #endregion Initialize

        #region Method : Public Method

        public void SelectData()
        {
            try
            {
                string strtDd = dteFrom.DateTime.ToString("yyyyMMdd");
                string endDd = dteTo.DateTime.ToString("yyyyMMdd");

                sprList.ActiveSheet.Rows.Count = 0;

                DataTable dt = new DataTable();
                if (!DBService.ExecuteDataTable(SQL.PA.Sql.SelectPAOPATRT_PatRegistLst(PatientInfo.PID, strtDd, endDd, chkCancelAppoint.Checked), ref dt))
                    throw new Exception("리스트 조회 중 에러가 발생했습니다.");

                dt.Columns["PRSC_YN"].ReadOnly = false;
                dt.Columns["RCPT_YN"].ReadOnly = false;

                if (dt.Rows.Count.Equals(0))
                    return;

                int rowcnt = 0;
                int prsc_cnt = 0;
                int rcpt_cnt = 0;

                foreach (DataRow row in dt.Rows)
                {
                    rowcnt++;

                    if (rowcnt == 1)
                    {
                        PastRegInfo.OTPT_ADMS_DVCD = "O";
                        PastRegInfo.PID = row["PID"].ToString();
                        PastRegInfo.PT_CMHS_NO = int.Parse(row["PT_CMHS_NO"].ToString());
                        PastRegInfo.RCPN_SQNO = int.Parse(row["RCPN_SQNO"].ToString());
                        PastRegInfo.MDCR_DD = row["MDCR_DD"].ToString();
                        PastRegInfo.MDCR_DEPT_CD = row["MDCR_DEPT_CD"].ToString();
                        PastRegInfo.MDCR_DR_CD = row["MDCR_DR_CD"].ToString();
                        PastRegInfo.INSN_TYCD = row["INSN_TYCD"].ToString();
                        PastRegInfo.ASST_TYCD = row["ASST_TYCD"].ToString();
                        PastRegInfo.ASCT_RGNO_CD = row["ASCT_RGNO_CD"].ToString();
                        PastRegInfo.SMCR_YN = row["SMCR_YN"].ToString(); //선택진료
                        PastRegInfo.EXCP_RESN_CD = row["EXCP_RESN_CD"].ToString();
                        PastRegInfo.VTRN_FALU_YN = row["VTRN_FALU_YN"].ToString(); //보훈등외여부
                        PastRegInfo.FCLT_APLY_YN = row["FCLT_APLY_YN"].ToString(); //시설적용여부
                    }

                    int.TryParse(row["PRSC_CNT"].ToString(), out prsc_cnt);
                    int.TryParse(row["RCPT_CNT"].ToString(), out rcpt_cnt);

                    if (prsc_cnt >= 1)
                    {
                        row["PRSC_YN"] = "Y";
                    }
                    else
                    {
                        row["PRSC_YN"] = "N";
                    }

                    if (prsc_cnt.Equals(rcpt_cnt))
                    {
                        if (rcpt_cnt > 0)
                            row["RCPT_YN"] = "Y";
                        else
                            row["RCPT_YN"] = "N";
                    }
                    else
                    {
                        row["RCPT_YN"] = "N";
                    }
                }

                if (isREGCHNG)
                {
                    // 취소 제외
                    if (dt.AsEnumerable().Where(r => !r["ROW_STAT_DVCD"].ToString().Equals("F")).Any())
                    {
                        var temp = dt.AsEnumerable().Where(r => !r["ROW_STAT_DVCD"].ToString().Equals("F")).CopyToDataTable();
                        sprList.FillDataTag(temp);
                    }
                }
                else
                {
                    sprList.FillDataTag(dt);
                }

                SetSpreadColor();
            }
            catch (Exception ex)
            {
                string error = DBService.HasError ? string.Format("\r\n[{0}] {1}", DBService.ErrorCode, DBService.ErrorMessage) : "";
                LogService.ErrorLog(ex);
                LogService.ErrorLog(error);
                LxMessage.ShowError(ex.Message + error);
            }
        }

        public void Clear()
        {
            sprList.Clear();
            PastRegInfo.Clear();
            PatientInfo.Clear();
        }

        public void SetSelectRow(string ptcmhsno)
        {
            string selptcmhsno = String.Empty;

            for (int i = 0; i < sprList.ActiveSheet.RowCount; i++)
            {
                selptcmhsno = sprList.GetValue(i, (int)COL.PT_CMHS_NO).ToString();
                if (!ptcmhsno.Equals(selptcmhsno))
                    continue;

                sprList.ActiveSheet.ActiveRowIndex = i;
                sprList.SetViewportTopRow(0, i);

                string pid = sprList.GetValue(i, (int)COL.PID).ToString();
                int pt_cmhs_no = 0;
                int.TryParse(selptcmhsno, out pt_cmhs_no);

                if (this.OnNewPatientSelect != null)
                    this.OnNewPatientSelect(pid, pt_cmhs_no);
                break;
            }
        }

        #endregion

        #region Method : Private Method

        private void SetSpreadColor()
        {
            string pt_mdcr_stat_dvnm = string.Empty;
            string etc_use_cnts_1 = string.Empty;
            string mdcr_dd = string.Empty;
            string today = DateTime.Today.ToString("yyyyMMdd");

            for (int i = 0; i < sprList.ActiveSheet.RowCount; i++)
            {
                mdcr_dd = sprList.GetValue(i, (int)COL.MDCR_DD).ToString();
                pt_mdcr_stat_dvnm = sprList.GetValue(i, (int)COL.PT_MDCR_STAT_DVNM).ToString();
                etc_use_cnts_1 = sprList.GetValue(i, (int)COL.ETC_USE_CNTS_1).ToString();

                // 오늘 날짜의 경우 파란색
                if (mdcr_dd.Equals(today))
                    sprList.ActiveSheet.Rows[i].ForeColor = Color.Blue;

                // ROW_STAT_DVCD
                if (pt_mdcr_stat_dvnm.Equals("입원"))
                {
                    sprList.ActiveSheet.Cells[i, (int)COL.PT_MDCR_STAT_DVNM].ForeColor = Color.FromArgb(15, 195, 110);
                    sprList.ActiveSheet.Cells[i, (int)COL.PT_MDCR_STAT_DVNM].Font = m_BoldFont;
                }
                else if (pt_mdcr_stat_dvnm.Equals("과취소") || pt_mdcr_stat_dvnm.Equals("접수취소") || pt_mdcr_stat_dvnm.Equals("예약취소"))
                {
                    sprList.ActiveSheet.Cells[i, (int)COL.PT_MDCR_STAT_DVNM].ForeColor = Color.Red;
                    sprList.ActiveSheet.Cells[i, (int)COL.PT_MDCR_STAT_DVNM].Font = m_BoldFont;
                }

                // 응급의학과 빨간색으로 표시
                if (lblER.Visible && sprList.GetValue(i, (int)COL.MDCR_DEPT_CD).ToString().Equals("2400"))
                    sprList.ActiveSheet.Cells[i, (int)COL.MDCR_DEPT_CD].ForeColor = Color.Red;

                // 주야구분
                if (etc_use_cnts_1 != "D")
                {
                    sprList.ActiveSheet.Cells[i, (int)COL.ETC_USE_CNTS_1_NM].ForeColor = Color.Red;
                    sprList.ActiveSheet.Cells[i, (int)COL.ETC_USE_CNTS_1_NM].Font = m_BoldFont;
                }
                else
                {
                    sprList.ActiveSheet.Cells[i, (int)COL.ETC_USE_CNTS_1_NM].ForeColor = Color.Black;
                }

                // [ 진료과목이 응급의학과일 때에만, 응급실주과를 보여준다. ]
                if (!sprList.GetValue(i, (int)COL.MDCR_DEPT_CD).ToString().Equals("2400"))
                    sprList.SetText(i, (int)COL.EMRM_MMCD_CD, "");
            }
        }

        private void OnScreenSelected(string key)
        {
            int currentrow = 0;
            currentrow = sprList.ActiveSheet.ActiveRowIndex;

            string pid = sprList.GetValue(currentrow, (int)COL.PID).ToString();
            string ptcmhsno = sprList.GetValue(currentrow, (int)COL.PT_CMHS_NO).ToString();
            string mdcrdeptcd = sprList.GetValue(currentrow, (int)COL.MDCR_DEPT_CD).ToString();
            string mdcrdrcd = sprList.GetValue(currentrow, (int)COL.MDCR_DR_CD).ToString();
            string mdcrdd = sprList.GetValue(currentrow, (int)COL.MDCR_DD).ToString();

            if (ScreenSelected != null)
                ScreenSelected(key, pid, ptcmhsno, mdcrdeptcd, mdcrdrcd, mdcrdd);
        }

        #endregion

        #region Event : Event Process

        private void ucPatRegistLst_ContextMenuClick(ContextMenuClickEventArgs e)
        {
            switch (e.MenuCode)
            {
                // 접수변경
                case "REGCHNG":
                    OnScreenSelected(e.MenuCode);
                    break;

                // 외래내원 수납 정보
                case "OUTRECINFO":
                    OnScreenSelected(e.MenuCode);
                    break;

                // 접수증 재출력
                case "REGREPRINT":
                    PrintMedicalReceipt();
                    break;

                // 진료의뢰서 ------- 현재 쓰지 않으므로 컨텍스트 메뉴 없앰, 2018-02-22, YJS
                case "MDCRREFER":
                    //this.CallPopUp()
                    //OnScreenSelected(e.MenuCode);
                    break;

                // 환자외/입정보조회
                case "OUTININFO":
                    OnScreenSelected(e.MenuCode);
                    break;
            }
        }

        private void PrintMedicalReceipt()
        {
            string pid = sprList.GetValue(sprList.ActiveSheet.ActiveRowIndex, (int)COL.PID).ToString();
            string ptcmhsno = sprList.GetValue(sprList.ActiveSheet.ActiveRowIndex, (int)COL.PT_CMHS_NO).ToString();

            Lime.BusinessControls.clsPACommon.PrintMedicalReceipt(pid, ptcmhsno);
        }

        private void spdPatRegLst_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader) return;
            if (e.RowHeader) return;

            ((LxSpread)sender).MultiCellSelectRowBackColor(e.Row);

            if (e.Button != System.Windows.Forms.MouseButtons.Right) return;

            sprList.ActiveSheet.ActiveRowIndex = e.Row;

            if (m_isREGCHNG)
            {
                this.ShowContextMenu("OUTREGHIS");
                this.GetContextMenu("OUTREGHIS").Tools["REGCHNG"].SharedProps.Visible = false;
                this.ContextMenuToolBar.ShowPopup("OUTREGHIS", this, new Point(-1, -1));
            }
            else
                this.ShowContextMenu("OUTREGHIS");
        }

        private void spdPatRegLst_CellDoubleClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (!m_ReadOnly) return;

            if (e.RowHeader) return;

            if (e.ColumnHeader) return;

            if (OnPatRegSelected != null)
            {
                OnPatRegSelected(sprList.GetValue(e.Row, (int)COL.PID).ToString(), sprList.GetValue(e.Row, (int)COL.PT_CMHS_NO).ToString(), sprList.GetValue(e.Row, (int)COL.MDCR_DD).ToString());
            }
        }

        private void spdPatRegLst_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                if (!m_ReadOnly) return;

                int activerow = 0;

                activerow = sprList.ActiveSheet.ActiveRowIndex;

                if (OnPatRegSelected != null)
                {
                    OnPatRegSelected(sprList.GetValue(activerow, (int)COL.PID).ToString(), sprList.GetValue(activerow, (int)COL.PT_CMHS_NO).ToString(), sprList.GetValue(activerow, (int)COL.MDCR_DD).ToString());
                }
            }
        }
        /// <summary>
        /// 접수변경에서 row change될 때 접수정보와 보험정보를 조회한다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void spdPatRegLst_RowChanged(object sender, LxSpread.RowChangedEventArgs e)
        {
            if (e.CurrentRowIndex.Equals(-1))
                return;

            string pid = sprList.GetValue(e.CurrentRowIndex, (int)COL.PID).ToString();
            int pt_cmhs_no = 0;
            int.TryParse(sprList.GetValue(e.CurrentRowIndex, (int)COL.PT_CMHS_NO).ToString(), out pt_cmhs_no);

            if (this.OnNewPatientSelect != null)
                this.OnNewPatientSelect(pid, pt_cmhs_no);
        }

        void dteTo_ValueChanged(object sender, EventArgs e)
        {
            SelectData();
        }

        void dteFrom_ValueChanged(object sender, EventArgs e)
        {
            SelectData();
        }

        void chkCancelAppoint_CheckedChanged(object sender, EventArgs e)
        {
            SelectData();
        }

        #endregion
    }
}
