package web.townsi.com.work.setting.biz.impl;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;
import web.townsi.com.utils.ListUtil;
import web.townsi.com.work.mapper.SettingMapper;
import web.townsi.com.work.setting.biz.SettingBiz;
import web.townsi.com.work.setting.biz.SettingGraphqlBiz;
import web.townsi.com.work.setting.biz.SqlByMybaitisBiz;
import web.townsi.com.work.setting.biz.SqlByMybaitisSamsBiz;

@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
@Service
public class SettingGraphqlBizImpl implements SettingGraphqlBiz {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private SettingBiz settingBiz;

	public static String READ_LINE = "\r\n";
	public static String LINE = "\n";
	public static String TAB = "\t";
	public static String SLASH = File.separator;// lastIndexOf("/")
	public static String rTxt = "#{txt}";
	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();
	public static String SPACE_CNT = "    ";
	public static  String WHERE_PARAM_PREFIX = "search";

	
	static String getGraphQlType(String type){
		String returnVal = "";
		if(type.equals("Integer") || type.equals("Long")) {
			returnVal = "Int";
		}else if(type.equals("Float")) {
			returnVal = "Float";
		}else if(type.equals("String")) {
			returnVal = "String";
		}else if(type.equals("Boolean")) {
			returnVal = "Boolean";
		}else if(type.equals("Date")) {
			returnVal = "Date";
		}else {
			System.out.println("============================================");
			System.out.println("NO TYPE >> " + type);
			returnVal = type;
			System.out.println("============================================");
		}
		return returnVal;
	}
	
	@Override
	public HashMap<String, Object> makeGraphql(HashMap params) throws Exception {
		
		HashMap dataMap = new HashMap();

		HashMap entityObj = (HashMap) params.get("entityObj");
		
		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String tableSchema = StringUtils.defaultString((String) params.get("tableSchema"));
		String upperTableName = tableName.toUpperCase();
		String lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		String camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		String camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String modelComment = StringUtils.defaultString((String) params.get("modelComment"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String group1 = StringUtils.defaultString((String) params.get("group1"));
		String author = StringUtils.defaultString((String) params.get("author"));
		String desc = StringUtils.defaultString((String) params.get("desc"));
		String today = StringUtils.defaultString((String) params.get("today"));
		String current = StringUtils.defaultString((String) params.get("current"));
		String menu = StringUtils.defaultString((String) params.get("menu"));
		String programId = StringUtils.defaultString((String) params.get("programId"));

		String ifcase = StringUtils.defaultString((String) params.get("ifcase"),"if_package");
		String whereParamPrefix = StringUtils.defaultString((String) params.get("whereParamPrefix"),"");
		String sqlComment = StringUtils.defaultString((String) params.get("sqlComment"),"N");
		String sort = StringUtils.defaultString((String) params.get("sort"));
		String taskName = StringUtils.defaultString((String) params.get("taskName"));
		String taskNameFirstUpperName = StringUtils.defaultString((String) params.get("taskNameFirstUpperName"));
		String tableNewName = StringUtils.defaultString((String) params.get("tableNewName"));
		String tableNewFirstUpperName = StringUtils.defaultString((String) params.get("tableNewFirstUpperName"));


		StringBuilder typeSql = new StringBuilder(500);
		

		String column_name = "";
		String column_comment = "";
		String camel_column_name = "";
		String columns = "";
		String pk = "";
		String orderByPK = "";
		String w_type = "";
		String pkStr = "";
		String comments = "";
		String dataType = "";

		boolean isRegId = false;
    	boolean isModId = false;
    	
		HashMap replaceMap = new HashMap();
		replaceMap.put("#tableName#",camelTableFirstUpperName);
		
		List<HashMap> list = settingBiz.selectTableInfo(params,
				  StringUtils.defaultString((String)params.get("dbName"))
				, StringUtils.defaultString((String)params.get("tableSchema"))
			    , StringUtils.defaultString((String)params.get("tableName"))
				);
		
		String name = "";
		String getNameFirstUpper = "";
		String type = "";		

		if(!ListUtil.isEmpty(list)) {
			int cnt = 0; 
			for (int i = 0; i < list.size(); i++) {
				HashMap rs = list.get(i);
				column_name = (String) rs.get("columnName");
				column_comment = (String) rs.get("columnComment");
				camel_column_name = (String) rs.get("camelColumnName");
				columns = (String) rs.get("columns");
				comments = (String) rs.get("comments");
				
				comments = comments.trim();
				if(comments.length() > 30) {
					if(comments.indexOf(" ") != -1) {
						comments = comments.substring(0, comments.indexOf(" "));
					}
				}
				
				w_type = (String) rs.get("wType");
				dataType = (String) rs.get("dataType");
				pk = StringUtils.defaultString((String) rs.get("pk")).toLowerCase();

				
				
//				if(!(camel_column_name.equals("prgmId") 
//						|| camel_column_name.equals("frstRegrId")
//						|| camel_column_name.equals("frstRgstDt")
//						|| camel_column_name.equals("lastUpdrId")
//						|| camel_column_name.equals("lastUpdtDt")
//						|| camel_column_name.equals("lastIfDttm")
//						) ) {
//					continue;
//				}
					
					if(entityObj != null && !entityObj.isEmpty()) {
						HashMap<String, String> map = (HashMap<String, String>) entityObj.get(column_name);
						if(map != null && !map.isEmpty()) {
							name = map.get("name");
							type = map.get("type");
						}					
					}
					
					if(!name.isEmpty()) {
						if(!comments.trim().isEmpty()) {
							typeSql.append("\t# "+comments.trim() + READ_LINE);
						}
						typeSql.append("\t"+name+": "+ this.getGraphQlType(type) +"" + READ_LINE);
					}else {
						if(!comments.trim().isEmpty()) {
							typeSql.append("\t# "+comments.trim() + READ_LINE);
						}
						typeSql.append("\t"+camel_column_name+": "+this.getGraphQlType(w_type)+"" + READ_LINE);
					}
				
			}
		}
		
		String typeSql1 = typeSql.toString().replace("\t", SPACE_CNT);
		
		if(!typeSql.toString().isEmpty()) {
			typeSql.append("\t# 페이징 filter" + READ_LINE);
			typeSql.append("\tpageFilter: PageFilter" + READ_LINE);
			typeSql.toString().replace("\t", SPACE_CNT);
		}
		
		String typeSql2 = typeSql.toString().replace("\t", SPACE_CNT);
		
		
		replaceMap.put("#taskNameFirstUpperName#", taskNameFirstUpperName);
		replaceMap.put("#taskName#", taskName);
		replaceMap.put("#type#", typeSql1);
		replaceMap.put("#input#", typeSql2);
		replaceMap.put("#tableNewName#", tableNewName);
		replaceMap.put("#tableNewName#", tableNewName);
		replaceMap.put("#tableNewFirstUpperName#", tableNewFirstUpperName);
		replaceMap.put("#desc#", desc);
		
		String str =  "";
		String wfullPath =  "";
		String rfullPath = "";
		
//		rfullPath = SITE_WEB_ROOT + "/copy/SampleGraphql_only_type.graphqls";
//		wfullPath = SITE_WEB_ROOT + "/new/" + tableSchema + "/" + tableName+"/"+tableNewFirstUpperName+".graphqls";
//		str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);			
		
		
//		rfullPath = SITE_WEB_ROOT + "/copy/SampleGraphql_only_method.graphqls";
//		wfullPath = SITE_WEB_ROOT + "/new/" + tableSchema + "/" + tableName+"/"+taskNameFirstUpperName+".graphqls";
//		str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);
		
		if(taskNameFirstUpperName.equals(tableNewFirstUpperName)) {
			
			rfullPath = SITE_WEB_ROOT + "/copy/SampleGraphql_all.graphqls";
			wfullPath = SITE_WEB_ROOT + "/new/" + tableSchema + "/" + tableName+"/"+taskNameFirstUpperName+".graphqls";
			str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);
			
		}else {
			
			rfullPath = SITE_WEB_ROOT + "/copy/SampleGraphql_only_type.graphqls";
			wfullPath = SITE_WEB_ROOT + "/new/" + tableSchema + "/" + tableName+"/"+tableNewFirstUpperName+".graphqls";
			str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);			
			
			rfullPath = SITE_WEB_ROOT + "/copy/SampleGraphql_only_method.graphqls";
			wfullPath = SITE_WEB_ROOT + "/new/" + tableSchema + "/" + tableName+"/"+taskNameFirstUpperName+".graphqls";
			str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);
		}
		
		

		dataMap.put("str", str);
		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}
	
	
	@Override
	public HashMap<String, Object> makeGraphqlService(HashMap params) throws Exception {
		
		HashMap dataMap = new HashMap();
		
		HashMap entityObj = (HashMap) params.get("entityObj");
		
		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String tableSchema = StringUtils.defaultString((String) params.get("tableSchema"));
		String upperTableName = tableName.toUpperCase();
		String lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		String camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		String camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String modelComment = StringUtils.defaultString((String) params.get("modelComment"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String group1 = StringUtils.defaultString((String) params.get("group1"));
		String author = StringUtils.defaultString((String) params.get("author"));
		String desc = StringUtils.defaultString((String) params.get("desc"));
		String today = StringUtils.defaultString((String) params.get("today"));
		String current = StringUtils.defaultString((String) params.get("current"));
		String menu = StringUtils.defaultString((String) params.get("menu"));
		String programId = StringUtils.defaultString((String) params.get("programId"));
		
		String ifcase = StringUtils.defaultString((String) params.get("ifcase"),"if_package");
		String whereParamPrefix = StringUtils.defaultString((String) params.get("whereParamPrefix"),"");
		String sqlComment = StringUtils.defaultString((String) params.get("sqlComment"),"N");
		String sort = StringUtils.defaultString((String) params.get("sort"));
		String taskName = StringUtils.defaultString((String) params.get("taskName"));
		String taskNameFirstUpperName = StringUtils.defaultString((String) params.get("taskNameFirstUpperName"));
		String packageNm = StringUtils.defaultString((String) params.get("packageNm"));
		String tableNewName = StringUtils.defaultString((String) params.get("tableNewName"));
		String tableNewFirstUpperName = StringUtils.defaultString((String) params.get("tableNewFirstUpperName"));
		
		StringBuilder typeSql = new StringBuilder(500);
		StringBuilder typeSql2 = new StringBuilder(500);
		StringBuilder pkStrSql = new StringBuilder(500);
		
		String column_name = "";
		String column_comment = "";
		String camel_column_name = "";
		String columns = "";
		String pk = "";
		String orderByPK = "";
		String w_type = "";
		String pkStr = "";
		String comments = "";
		String dataType = "";
		
		boolean isRegId = false;
		boolean isModId = false;
		
		HashMap replaceMap = new HashMap();
		replaceMap.put("#tableName#",camelTableFirstUpperName);
		
		List<HashMap> list = settingBiz.selectTableInfo(params,
				StringUtils.defaultString((String)params.get("dbName"))
				, StringUtils.defaultString((String)params.get("tableSchema"))
				, StringUtils.defaultString((String)params.get("tableName"))
				);
		
		if(!ListUtil.isEmpty(list)) {
			int cnt = 0; 
			for (int i = 0; i < list.size(); i++) {
				HashMap rs = list.get(i);
				column_name = (String) rs.get("columnName");
				column_comment = (String) rs.get("columnComment");
				camel_column_name = (String) rs.get("camelColumnName");
				columns = (String) rs.get("columns");
				comments = (String) rs.get("comments");
				w_type = (String) rs.get("wType");
				dataType = (String) rs.get("dataType");
				pk = StringUtils.defaultString((String) rs.get("pk"));
				
				String name = "";
				String getNameFirstUpper = "";
				String type = "";
				
				
//				if((camel_column_name.equals("prgmId") 
//						|| camel_column_name.equals("frstRegrId")
//						|| camel_column_name.equals("frstRgstDt")
//						|| camel_column_name.equals("lastUpdrId")
//						|| camel_column_name.equals("lastUpdtDt")
//						|| camel_column_name.equals("lastIfDttm")
//						) ) {
//					continue;
//				}
				
				
				
				if(entityObj != null && !entityObj.isEmpty()) {
					HashMap<String, String> map = (HashMap<String, String>) entityObj.get(column_name);
					if(map != null && !map.isEmpty()) {
						name = map.get("name");
						type = map.get("type");
					}					
				}
				
				if(!name.isEmpty()) {
					
					if(pk.equals("pk")) {
						pkStrSql.append("," + name + " : ''\n");
					}
					
					if(!column_comment.trim().isEmpty()) {
						typeSql2.append("\t\t\t"+name + READ_LINE);
						
						typeSql.append("\t\t\t,"+name + ": ''");
						typeSql.append("\t// "+column_comment.trim() + READ_LINE);
						
					}else {
						typeSql2.append("\t\t\t,"+name+ READ_LINE);
						typeSql.append("\t\t\t"+name + ": ''"+ READ_LINE);
					}
				}else {
					
					if(pk.equals("pk")) {
						pkStrSql.append("," + camel_column_name + " : ''\n");
					}					
					
					if(!column_comment.trim().isEmpty()) {
						typeSql2.append("\t\t\t"+camel_column_name + READ_LINE);
						typeSql.append("\t\t\t,"+camel_column_name + ": ''");
						typeSql.append("\t// "+column_comment.trim() + READ_LINE);
					}else{
						typeSql2.append("\t\t\t"+camel_column_name + READ_LINE);
						typeSql.append("\t\t\t,"+camel_column_name + ": ''" + READ_LINE);
					}
				}
			}
		}
		
		pkStr = pkStrSql.toString();
		if(!pkStr.isEmpty()) {
			pkStr  = pkStr.substring(1);
		}
		
		replaceMap.put("#taskNameFirstUpperName#", taskNameFirstUpperName);
		replaceMap.put("#taskName#", taskName);
		replaceMap.put("#typeSql#", typeSql.toString().replaceFirst(",", " ").replace("\t", SPACE_CNT));
		replaceMap.put("#typeSql2#", typeSql2.toString());//주석 없다
		replaceMap.put("#pkStr#", pkStr);
		replaceMap.put("#packageNm#", packageNm);
		replaceMap.put("#tableNewName#", tableNewName);
		replaceMap.put("#tableNewFirstUpperName#", tableNewFirstUpperName);
		
		String rfullPath = SITE_WEB_ROOT + "/copy/SampleGraphqlService.js";
		String wfullPath = "";
		wfullPath = SITE_WEB_ROOT + "/new/" + tableSchema + "/" + tableName+"/"+taskNameFirstUpperName+".graphql.service.js";
		String str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);
		
		dataMap.put("str", str);
		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}
}