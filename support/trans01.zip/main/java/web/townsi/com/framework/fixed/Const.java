package web.townsi.com.framework.fixed;

public class Const {
	public enum Path {

		SITE_WEB_ROOT(AppConst.siteWebRoot),
		PROP(AppConst.settingProp);

		private final String value;

		private Path(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}
	}
}

