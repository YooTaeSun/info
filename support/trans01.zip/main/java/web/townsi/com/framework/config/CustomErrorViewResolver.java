package web.townsi.com.framework.config;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorViewResolver;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.ModelAndView;

@Configuration
public class CustomErrorViewResolver implements ErrorViewResolver {

	private Logger logger = LoggerFactory.getLogger(CustomErrorViewResolver.class);

	@Override
	public ModelAndView resolveErrorView(HttpServletRequest request, HttpStatus status, Map<String, Object> model) {

		String error=  StringUtils.defaultString((String) model.get("error"));
		
		logger.error("error {}", error);
		logger.error("error model {}", model);
		
		return new ModelAndView("error/" + model.get("status"));
	}

}