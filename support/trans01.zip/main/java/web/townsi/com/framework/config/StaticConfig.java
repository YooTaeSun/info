package web.townsi.com.framework.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class StaticConfig implements WebMvcConfigurer{

	private Logger logger = LoggerFactory.getLogger(StaticConfig.class);

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		
//		registry
//		.addResourceHandler("/webjars/**")
//		.addResourceLocations("/webjars/")
//		.setCachePeriod(60*1)//초
//		;

		registry
		.addResourceHandler("/static/**")
		.addResourceLocations("classpath:/static/")
		.setCachePeriod(60*1)//초
		;
		
		logger.debug("{} {}","StaticConfig","addResourceHandlers");
	}

}


