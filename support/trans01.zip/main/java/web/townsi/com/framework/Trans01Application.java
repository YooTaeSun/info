package web.townsi.com.framework;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;

import web.townsi.com.framework.listener.AppStartingEvent;

@EnableCaching
@SpringBootApplication(scanBasePackages = { "web.townsi.com" })
public class Trans01Application extends SpringBootServletInitializer {

	private Logger logger = LoggerFactory.getLogger(Trans01Application.class);

	public static void main(String[] args) {
		SpringApplication app = new SpringApplication(Trans01Application.class);
		app.addListeners(new AppStartingEvent());
		app.run(args);
	}
}
