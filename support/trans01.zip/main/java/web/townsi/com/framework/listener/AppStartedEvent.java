package web.townsi.com.framework.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class AppStartedEvent implements ApplicationListener<ApplicationStartedEvent> {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Override
	public void onApplicationEvent(ApplicationStartedEvent event) {
//		logger.debug("[LOADING_CHECK]  ApplicationStartedEvent ");
	}




}
