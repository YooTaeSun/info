package web.townsi.com.framework.config.database;

import java.util.Properties;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.aop.framework.autoproxy.BeanNameAutoProxyCreator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.interceptor.TransactionInterceptor;

import com.zaxxer.hikari.HikariDataSource;

@Configuration
@Lazy
@EnableTransactionManagement
//@MapperScan(basePackages = {"web.townsi.com.work.mapper.oracle"})
@Order(1)
public class DbConfigByPostgreSql {
  @Autowired
  private ApplicationContext applicationContext;

//  @Autowired
//  private Environment environment;

  @Value("${spring.datasource.postgres.jdbc-url}")
  private String jdbcUrl;

  @Value("${spring.datasource.postgres.username}")
  private String username;

  @Value("${spring.datasource.postgres.password}")
  private String password;

  @Value("${spring.datasource.postgres.driver-class-name}")
  private String driverClassName;

  @Bean(name="dataSourcePostgresql01", destroyMethod = "close")
  @ConfigurationProperties("spring.datasource.postgres")
  public DataSource dataSourcePostgresql01() {
	  return DataSourceBuilder.create().type(HikariDataSource.class).build();
  }

  @Bean(name= "transactionManagerPostgresql01")
  public PlatformTransactionManager transactionManagerPostgresql01() {
    DataSourceTransactionManager transactionManager = new DataSourceTransactionManager(dataSourcePostgresql01());
    transactionManager.setGlobalRollbackOnParticipationFailure(false);
    return transactionManager;
  }

  @Bean(name= "sqlSessionFactoryPostgresql01")
  public SqlSessionFactory sqlSessionFactoryPostgresql01() throws Exception {
    SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
    sqlSessionFactoryBean.setDataSource(dataSourcePostgresql01());
    sqlSessionFactoryBean.setConfigLocation(applicationContext.getResource("classpath:config/mybatis-config.xml"));
//    sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath:mapper/oracle/**/*.xml"));
    sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath:mapper/*.xml"));// xml파일의
    return sqlSessionFactoryBean.getObject();
  }

  @Bean(name= "sqlSessionPostgresql01")
  public SqlSessionTemplate sqlSession() throws Exception {
    return new SqlSessionTemplate(sqlSessionFactoryPostgresql01());
  }

//  @Bean(name = "transactionInterceptorPostgresql01")
//  public TransactionInterceptor transactionInterceptor(@Qualifier("transactionManagerPostgresql01") PlatformTransactionManager platformTransactionManager) {
//      TransactionInterceptor transactionInterceptor = new TransactionInterceptor();
//      transactionInterceptor.setTransactionManager(platformTransactionManager);
//      Properties transactionAttributes = new Properties();
//      transactionAttributes.setProperty("*", "PROPAGATION_REQUIRED,-Throwable");
//      transactionInterceptor.setTransactionAttributes(transactionAttributes);
//      return transactionInterceptor;
//  }
//
//  @Bean(name = "transactionAutoProxyPostgresql01")
//  public BeanNameAutoProxyCreator transactionAutoProxy() {
//      BeanNameAutoProxyCreator transactionAutoProxy = new BeanNameAutoProxyCreator();
//      transactionAutoProxy.setProxyTargetClass(true);
//      transactionAutoProxy.setBeanNames("*BizImpl");
//      transactionAutoProxy.setInterceptorNames("transactionInterceptorPostgresql01");
//      return transactionAutoProxy;
//  }

}