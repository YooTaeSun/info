package web.townsi.com.framework.config.database;

import java.util.Properties;

import javax.sql.DataSource;

import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.boot.autoconfigure.SpringBootVFS;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.annotation.Order;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@Lazy
@EnableTransactionManagement
@Order(200)
public class DbConfigByTiberoBatch {

	@Value("${spring.datasource.tibero01.url}")
	private String url;

	@Value("${spring.datasource.tibero01.username}")
	private String username;

	@Value("${spring.datasource.tibero01.password}")
	private String password;

	@Value("${spring.datasource.tibero01.driver-class-name}")
	private String dataSourceClassName;

	@Autowired
	private ApplicationContext applicationContext;

	@Bean(name = "dataSourceTiberoBatch", destroyMethod = "close")
	@ConfigurationProperties("spring.datasource.tibero01")
	public DataSource dataSourceTiberoBatch() {
		DataSourceBuilder dsb = DataSourceBuilder.create();
		dsb.url(url);
		dsb.password(password);
		dsb.username(username);
		dsb.driverClassName(dataSourceClassName);
		return dsb.build();
	}

	@Bean(name = "sqlSessionFactoryTiberoBatch")
//  public SqlSessionFactory firstSqlSessionFactory(@Qualifier("dataSourceTiberoBatch") DataSource firstDataSource, ApplicationContext applicationContext) throws Exception {
	public SqlSessionFactory sqlSessionFactoryTiberoBatch() throws Exception {
		SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
		sqlSessionFactoryBean.setDataSource(dataSourceTiberoBatch());
		sqlSessionFactoryBean.setVfs(SpringBootVFS.class);
		sqlSessionFactoryBean.setConfigLocation(applicationContext.getResource("classpath:config/mybatis-config.xml"));
		sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath:mapper/tibero*/**/*.xml"));// xml파일의
		sqlSessionFactoryBean.setConfigurationProperties(getMyBatisProperties());

		return sqlSessionFactoryBean.getObject();
	}

	@Bean(name = "sqlSessionTiberoBatch", destroyMethod = "clearCache")
	public SqlSessionTemplate sqlSession() throws Exception {
		return new SqlSessionTemplate(sqlSessionFactoryTiberoBatch(), ExecutorType.BATCH);
	}

	private Properties getMyBatisProperties() {
		Properties properties = new Properties();
		properties.put("cacheEnabled", false);
		properties.put("lazyLoadingEnabled", true);
		properties.put("localCacheScope", "STATEMENT");
		properties.put("defaultExecutorType", "BATCH");
		return properties;
	}



}