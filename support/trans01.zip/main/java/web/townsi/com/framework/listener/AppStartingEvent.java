package web.townsi.com.framework.listener;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationStartingEvent;
import org.springframework.context.ApplicationListener;

import web.townsi.com.framework.fixed.AppConst;
import web.townsi.com.utils.FileUtil;

public class AppStartingEvent implements ApplicationListener<ApplicationStartingEvent> {

	final private static Logger logger = LoggerFactory.getLogger(AppStartingEvent.class);

	final static private String copyArray[]  = {
//			 "ex_01.cs",
//			 "ex_02.cs"
//			,"SampleAPI2.java"
//			,"SampleAPI3.java"
//			,"SampleMapper.java"
//			,"SampleMapper3.java"
//			,"SampleService.java"
//			,"SampleService3.java"
//			,"SampleService4.java"
//			,"SampleServiceImpl3.java"
//			,"SampleServiceImpl4.java"
//			,"SampleSql3.xml"
//			,"SampleSql4.xml"
//			,"SampleVO3.java"
//			,"SampleEntity.java"
//			,"SampleRepo.java"
//			,"SampleTo.java"
//			,"SamplePred.java"
//			,"SampleQuery.java"
//			,"SampleMutation.java"
//			,"SampleDslService.java"
//			,"SampleDslServiceImpl.java"
//			,"SampleGraphql_all.graphqls"
//			,"SampleGraphql_only_type.graphqls"
//			,"SampleGraphql_only_method.graphqls"
//			,"SampleGraphqlService.js"
//			,"SampleFilter.java"
////			,"SampleDTO.java"
//			,"SampleMapper3.java"
//			,"SampleMapper4.java"
	};

	@Override
	public void onApplicationEvent(ApplicationStartingEvent event) {
//		logger.debug("[LOADING_CHECK]  ApplicationStartingEvent ");
//		System.out.println("[LOADING_CHECK]  ApplicationStartingEvent ");
        try {
			regiConstCopyPath();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void regiConstCopyPath() throws IOException, URISyntaxException {

        URL classPathUrl = AppStartingEvent.class.getResource("/");
        String classPathStr = classPathUrl.getPath();
//        logger.debug("[LOADING_CHECK]  regiConstCopyPath classPathStr >> " + classPathStr);
//        System.out.println("[LOADING_CHECK]  regiConstCopyPath classPathStr >> " + classPathStr);

//        logger.debug("[LOADING_CHECK]  regiConstCopyPath webappPathStr before >> " + classPathStr);
//        System.out.println("[LOADING_CHECK]  regiConstCopyPath webappPathStr before >> " + classPathStr);

        String webappPathStr = classPathStr.replace("/target/classes/", "/src/main/webapp").replace("/target/test-classes/", "/src/main/webapp");
//        logger.debug("[LOADING_CHECK]  regiConstCopyPath webappPathStr after >> " + webappPathStr);

//        System.out.println("[LOADING_CHECK]  regiConstCopyPath webappPathStr after >> " + webappPathStr);
		AppConst.setSiteSamplePath(webappPathStr);


		File projectFile = new File(".");
		String projectPath = projectFile.getAbsolutePath();
//		String projectRoot = projectPath.replace("/trans01/.", "/trans01");
		String cpoyRoot = "";

		if(System.getProperty("os.name").toLowerCase().startsWith("window")) {
			cpoyRoot = projectPath.replace("\\trans01\\.", "\\trans01_t_root");
		}else {
			cpoyRoot = projectPath.replace("/trans01/.", "/trans01_t_root");
		}

//		logger.debug("[LOADING_CHECK]  cpoyRoot  >> " + cpoyRoot);
//		System.out.println("[LOADING_CHECK]  cpoyRoot  >> " + cpoyRoot);

		AppConst.setSiteWebRoot(cpoyRoot);

		String settingPropPathUrl = cpoyRoot + File.separator +"setting.properties";
		File settingPropPathUrlFile = new File(settingPropPathUrl);
//		logger.debug("[LOADING_CHECK]  outFilePath  >> " + settingPropPathUrl);
//		System.out.println("[LOADING_CHECK]  outFilePath  >> " + settingPropPathUrl);

		if(!settingPropPathUrlFile.exists()) {
			FileUtil.copyURLToFile("/config/setting.properties", settingPropPathUrl);
		}
		AppConst.setSettingProp(settingPropPathUrl);

		String newPathUrl = cpoyRoot + File.separator + "copy";
		File newPathUrlFile = new File(newPathUrl);
//		logger.debug("[LOADING_CHECK]  newPathUrlFile  >> " + newPathUrlFile);
//		System.out.println("[LOADING_CHECK]  newPathUrlFile  >> " + newPathUrlFile);

		File sampleFile = null;
		for (String fileNm : copyArray) {
			sampleFile = new File(newPathUrl + File.separator + fileNm);
			if(!sampleFile.exists()) {
				FileUtil.copyURLToFile("/copy/" + fileNm, newPathUrl + File.separator + fileNm);
			}
		}
		
//		URL inputUrl = FileUtil.class.getResource("/copy/entity");
//		
//		File inDir = Paths.get(inputUrl.toURI()).toFile();
//		File outDir = new File(newPathUrl +  File.separator + "entity");
//
//		org.apache.commons.io.FileUtils.copyDirectory(inDir, outDir);

	}

}
