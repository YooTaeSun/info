package web.townsi.com.framework.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationPreparedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class AppPreparedEvent implements ApplicationListener<ApplicationPreparedEvent> {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Override
	public void onApplicationEvent(ApplicationPreparedEvent event) {
//		logger.debug("[LOADING_CHECK]  ApplicationPreparedEvent ");
	}


}
