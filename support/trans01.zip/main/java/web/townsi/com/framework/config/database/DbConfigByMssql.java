package web.townsi.com.framework.config.database;

import java.util.Iterator;
import java.util.LinkedHashMap;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.annotation.Order;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
@Lazy
@EnableTransactionManagement
//@MapperScan(basePackages = { "web.townsi.com.work.mapper.Tibero" })
@Order(100)
public class DbConfigByMssql {

	@Autowired
	private ApplicationContext applicationContext;
	
	@Autowired
	private LinkedHashMap<String, String> propMap;

	
	@Bean
	@ConfigurationProperties(prefix = "spring.datasource.mssql")
	public HikariConfig hikariConfig() {

		HikariConfig hikariConfig = new HikariConfig();
		return hikariConfig;
	}
	
	@Bean(name = "dataSourceMssql", destroyMethod = "close")
	public DataSource dataSourceMssql() {
		HikariConfig h = hikariConfig();
		
		String jdbcUrl = "";
		String username = "";
		String password = "";
		
		Iterator it = this.propMap.keySet().iterator();
		while (it.hasNext()) {
			String key = (String) it.next();
			System.out.println(key + " : " + this.propMap.get(key));
			if(key.contains("spring.datasource.mssql.jdbc-url")) {
				jdbcUrl = this.propMap.get(key);
			}else if(key.contains("spring.datasource.mssql.username")) {
				username = this.propMap.get(key);
			}else if(key.contains("spring.datasource.mssql.password")) {
				password = this.propMap.get(key);
			}
		}
		
		if(!jdbcUrl.isEmpty() && !username.isEmpty() && !password.isEmpty()) {
			h.setJdbcUrl(jdbcUrl);
			h.setUsername(username);
			h.setPassword(password);
		}else {
			jdbcUrl = h.getJdbcUrl();
			username = h.getUsername();
			password = h.getPassword();	
		}
		
		this.propMap.put("connectInfo", String.format("%s", jdbcUrl));
		DataSource dataSource = new HikariDataSource(h);
		return dataSource;		
	}

	@Bean(name = "sqlSessionFactoryMssql")
//  public SqlSessionFactory firstSqlSessionFactory(@Qualifier("dataSourceMssql") DataSource firstDataSource, ApplicationContext applicationContext) throws Exception {
	public SqlSessionFactory sqlSessionFactoryMssql() throws Exception {
		SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
		sqlSessionFactoryBean.setDataSource(dataSourceMssql());
		sqlSessionFactoryBean.setConfigLocation(applicationContext.getResource("classpath:config/mybatis-config.xml"));
		sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath:mapper/mssql/*.xml"));// xml파일의
		
		return sqlSessionFactoryBean.getObject();
	}

	@Bean(name = "sqlSessionMssql")
	public SqlSessionTemplate sqlSession() throws Exception {
		return new SqlSessionTemplate(sqlSessionFactoryMssql());
	}


}