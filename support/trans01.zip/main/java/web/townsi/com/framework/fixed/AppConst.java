package web.townsi.com.framework.fixed;

public class AppConst {

	public static String siteSamplePath;

    public static String siteWebRoot;

    public static String settingProp;


	public static void setSiteSamplePath(String n) {
		AppConst.siteSamplePath = n;
	}

	public static void setSiteWebRoot(String n) {
		AppConst.siteWebRoot = n;
	}

	public static void setSettingProp(String n) {
		AppConst.settingProp = n;
	}

}


