//package web.townsi.com.framework.config.database;
//
//import java.util.Iterator;
//import java.util.LinkedHashMap;
//
//import javax.sql.DataSource;
//
//import org.apache.ibatis.session.SqlSessionFactory;
//import org.mybatis.spring.SqlSessionFactoryBean;
//import org.mybatis.spring.SqlSessionTemplate;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Lazy;
//import org.springframework.core.annotation.Order;
//import org.springframework.transaction.annotation.EnableTransactionManagement;
//
//import com.zaxxer.hikari.HikariConfig;
//import com.zaxxer.hikari.HikariDataSource;
//
//@Configuration
//@Lazy
//@EnableTransactionManagement
////@MapperScan(basePackages = { "web.townsi.com.work.mapper.Tibero" })
//@Order(100)
//public class DbConfigByTibero01 {
//
//	@Autowired
//	private ApplicationContext applicationContext;
//	
//	@Autowired
//	private LinkedHashMap<String, String> propMap;
//
//	
//	@Bean
//	@ConfigurationProperties(prefix = "spring.datasource.mysql")
//	public HikariConfig hikariConfig() {
//
//		HikariConfig hikariConfig = new HikariConfig();
//		return hikariConfig;
//	}
//	
//	@Bean(name = "dataSourceTibero01", destroyMethod = "close")
////  @ConfigurationProperties("spring.datasource.tibero")
//	public DataSource dataSourceTibero01() {
////		DataSourceBuilder dsb = DataSourceBuilder.create();
////		dsb.url(url);
////		dsb.password(password);
////		dsb.username(username);
////		dsb.driverClassName(dataSourceClassName);
////		return dsb.build();
//		
//		HikariConfig h = hikariConfig();
//		
//		String jdbcUrl = "";
//		String username = "";
//		String password = "";
//		
//		Iterator it = this.propMap.keySet().iterator();
//		while (it.hasNext()) {
//			String key = (String) it.next();
////			resultMap.put(key, this.propMap.get(key));
//			System.out.println(key + " : " + this.propMap.get(key));
//			if(key.contains("spring.datasource.mysql.jdbc-url")) {
//				jdbcUrl = this.propMap.get(key);
//			}else if(key.contains("spring.datasource.mysql.username")) {
//				username = this.propMap.get(key);
//			}else if(key.contains("spring.datasource.mysql.password")) {
//				password = this.propMap.get(key);
//			}
//		}
//		
//		if(!jdbcUrl.isEmpty() && !username.isEmpty() && !password.isEmpty()) {
//			h.setJdbcUrl(jdbcUrl);
//			h.setUsername(username);
//			h.setPassword(password);
//		}else {
//			jdbcUrl = h.getJdbcUrl();
//			username = h.getUsername();
//			password = h.getPassword();	
//		}
//		 
//		if(!jdbcUrl.isEmpty()) {
//			jdbcUrl = jdbcUrl.replace("jdbc:mysql://","").replace("characterEncoding=UTF-8&serverTimezone=Asia/Seoul","");
//		}
//		
//		this.propMap.put("connectInfo", String.format("%s", jdbcUrl));
//		DataSource dataSource = new HikariDataSource(h);
//		return dataSource;		
//	}
//
//	@Bean(name = "sqlSessionFactoryTibero01")
//	public SqlSessionFactory sqlSessionFactoryTibero01() throws Exception {
//		SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
//		sqlSessionFactoryBean.setDataSource(dataSourceTibero01());
//		sqlSessionFactoryBean.setConfigLocation(applicationContext.getResource("classpath:config/mybatis-config.xml"));
//		sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath:mapper/*.xml"));// xml파일의
//		
//		return sqlSessionFactoryBean.getObject();
//	}
//
//	@Bean(name = "sqlSessionMysql01")
//	public SqlSessionTemplate sqlSession() throws Exception {
//		return new SqlSessionTemplate(sqlSessionFactoryTibero01());
//	}
//
//
//}