/Users/p147723/project01/workspace/sh
- # support
    - generate source
    - ## 배포 jar 파일 만들기
        - mvn clean package -Dmaven.test.skip=true
    - ## 서버 run
        - java -jar -Dspring.profiles.active=local target/support-0.0.1-SNAPSHOT.jar

- # Markdown을 HTML로 변환하는 방법
    - VScode 에서 Copy Markdown as HTML 라는 플러그인을 설치 -> F1누르고 markdown 선택 하면 html 클립보드에 복사



- # 구성
    - 1) docker 이미지 안 만들고 jenkins 에서 clone git해서 jar파일로 만들어서, server01_ubuntu로 전송, docker-compose 로
    - 2) jenkins 에서 clone git해서 jar파일로 만들어서, docker image