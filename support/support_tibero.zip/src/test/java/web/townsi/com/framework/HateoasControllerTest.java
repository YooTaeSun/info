package web.townsi.com.framework;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import web.townsi.com.work.test.controller.HateoasController;

@RunWith(SpringRunner.class)
@WebMvcTest(HateoasController.class)
public class HateoasControllerTest {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	MockMvc mockMvc;
	
	@Autowired
	ObjectMapper objectMapper;
	
	@Test
	public void test01() throws Exception{
		mockMvc.perform(get("/hateoas/test"))
		.andDo(print())
		.andExpect(status().isOk())
		.andExpect(jsonPath("$._links.self").exists())
		;
	}
	
}