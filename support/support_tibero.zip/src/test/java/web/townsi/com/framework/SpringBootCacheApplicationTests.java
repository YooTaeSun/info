package web.townsi.com.framework;


import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;

import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.hamcrest.CoreMatchers;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import web.townsi.com.work.setting.biz.SettingBiz;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class SpringBootCacheApplicationTests {

	@Autowired
	private SettingBiz settingBiz;

	private long startTime;
	private long endTime;

	private static final Logger logger = LoggerFactory.getLogger(SpringBootCacheApplicationTests.class);

	@Before
	public void onBefore() {
		startTime = System.currentTimeMillis();
	}

	@After
	public void onAfter() {
		endTime = System.currentTimeMillis();
		logger.info("소요시간 : {}ms", endTime - startTime);
	}

	@Test
	public void test1() {
		HashMap<String, Object> params = new HashMap<String, Object>();

		params.put("tableName","com_class_code");
		params.put("dbName","MY_SQL");

		List<HashMap> list = settingBiz.selectTableInfo(params,
				  StringUtils.defaultString((String)params.get("dbName"))
				, StringUtils.defaultString((String)params.get("tableSchema"))
			    , StringUtils.defaultString((String)params.get("tableName"))
				);
		System.out.println("-------------------------------------------");
		logger.debug("debug list >> {}", list);
		logger.info("info list >> {}", list);
		logger.warn("warn list >> {}", list);
		logger.error("error list >> {}", list);

		Assert.assertThat(settingBiz, CoreMatchers.is(notNullValue()));
		System.out.println("-------------------------------------------");
	}


	// null 을 기대하는데 null 이므로 성공
//	@Test
	public void nullTest() {
	    String str = null;

	    assertThat(str,  org.hamcrest.Matchers.is(nullValue()));
//	    assertThat(str,  org.hamcrest.Matchers.is(notNullValue()));
	}

}
