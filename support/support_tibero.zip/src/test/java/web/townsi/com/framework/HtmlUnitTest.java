package web.townsi.com.framework;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlHeading1;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

import web.townsi.com.work.test.controller.LangController;

@RunWith(SpringRunner.class)
@WebMvcTest(LangController.class)
public class HtmlUnitTest {

	@Autowired
	WebClient webClient;
	
	@Autowired
	MockMvc mockMvc;
	
	@Test
	public void hello() throws Exception{
		HtmlPage page = webClient.getPage("/lang/jsp");
		HtmlHeading1 h1 = page.getFirstByXPath("//h1");
		assertThat(h1.getTextContent()).isEqualToIgnoringCase("test");
	}
	
}
