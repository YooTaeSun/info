package idstrust.lsp.#group#.#group1#.mapper;

/**
 * <pre>
 * 1. PROJECT   		: Lab Solution Project
 * 2. CREATE USER       : #author#
 * 3. CREATE_DATE       : #current#
 * 4. MENU				: LIMS > #menu#
 * 5. PROGRAM ID		: #programId#
 * 6. PROGRAM EXPLAIN	: #desc# Mapper
 * </pre>
 *
 *  MO_DATE       MO_USER          MO_EXPLAIN
 *  ----------    --------    ---------------------------
 *  #today#    #author#                  최초 생성
 *  ----------    --------    ---------------------------
*/

import java.util.HashMap;
import java.util.List;

import egovframework.rte.psl.dataaccess.mapper.Mapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import idstrust.lsp.#group#.#group1#.vo.#camelTableFirstUpperName#VO;

@Mapper("#camelTableName#Mapper")
public interface #camelTableFirstUpperName#Mapper {

	public Integer selectCount#camelTableFirstUpperName#(HashMap<String, Object> map);

    public List<EgovMap> selectList#camelTableFirstUpperName#(HashMap<String, Object> map);

    public EgovMap select#camelTableFirstUpperName#(HashMap<String, Object> map);

    public Integer insert#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO);

    public Integer update#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO);

    public Integer delete#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO);

    public void merge#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO);

}
