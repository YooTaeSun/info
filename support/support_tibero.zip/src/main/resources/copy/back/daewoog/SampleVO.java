package idstrust.lsp.#group#.#group1#.vo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.skt.poc.common.base.BaseVO;

import idstrust.lsp.config.common.vo.CommonVO;
import idstrust.lsp.config.sys.vo.InternationalVO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
public class #camelTableFirstUpperName#VO extends CommonVO implements Serializable {

	private static final long serialVersionUID = ;

#dtoContent#

	public #camelTableFirstUpperName#VO(#conParam#) {
#conParamBody#
	}
}
