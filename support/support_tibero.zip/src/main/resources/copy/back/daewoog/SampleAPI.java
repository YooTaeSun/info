package idstrust.lsp.#group#.#group1#.controller;

/**
 * <pre>
 * 1. PROJECT   		: Lab Solution Project
 * 2. CREATE USER       : #author#
 * 3. CREATE_DATE       : #current#
 * 4. MENU				: LIMS > #menu#
 * 5. PROGRAM ID		: #programId#
 * 6. PROGRAM EXPLAIN	: #desc# Controller
 * </pre>
 *
 *  MO_DATE       MO_USER          MO_EXPLAIN
 *  ----------    --------    ---------------------------
 *  #today#    #author#                  최초 생성
 *  ----------    --------    ---------------------------
*/

import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import idstrust.lsp.config.auth.vo.UserInfoVO;
import idstrust.lsp.config.base.constant.WebConstants;
import idstrust.lsp.lims.bslang.service.BsLangService;

@Controller
@RequestMapping("/#group#/#group1#/")
public class #camelTableFirstUpperName#Controller {

	private static final Logger log = Logger.getLogger(#camelTableFirstUpperName#Controller.class.getClass());

	@Autowired
	private MappingJackson2JsonView ajaxMainView;

    @Autowired
    private #camelTableFirstUpperName#Service #camelTableName#Service;

	@GetMapping("/#camelTableName#.do")
	public String #camelTableName#(HttpSession ses, @RequestParam HashMap<String, Object> map, ModelMap model) {
		log.debug(":: #camelTableFirstUpperName#Controller.#camelTableName#() ::");
		return "/#group#/#group1#/#camelTableName#";
	}

	@GetMapping("/getList#camelTableFirstUpperName#.do")
	public ModelAndView getList#camelTableFirstUpperName#(HttpSession ses, @RequestParam HashMap<String, Object> map, ModelMap model) {
		log.debug(":: #camelTableFirstUpperName#Controller.getList#camelTableFirstUpperName#() ::");
		#camelTableName#Service.getList#camelTableFirstUpperName#(map, model);
		return new ModelAndView(ajaxMainView, model);
	}

	@GetMapping("/get#camelTableFirstUpperName#.do")
	public ModelAndView getOne(HttpSession ses, @RequestParam HashMap<String, Object> map, ModelMap model) {
		log.debug(":: #camelTableFirstUpperName#Controller.get#camelTableFirstUpperName#() ::");
		#camelTableName#Service.get#camelTableFirstUpperName#(map, model);
		return new ModelAndView(ajaxMainView, model);
	}

	@PostMapping("/post#camelTableFirstUpperName#.do")
	public ModelAndView insert#camelTableFirstUpperName#(HttpSession ses, @RequestParam HashMap<String, Object> map, ModelMap model) {
		log.debug(":: #camelTableFirstUpperName#Controller.post#camelTableFirstUpperName#() ::");

		UserInfoVO sesUserInfo = (UserInfoVO) ses.getAttribute(WebConstants.USER_KEY);
		String userId = sesUserInfo.getUserId();
		map.put("regId", userId);

		#camelTableName#Service.post#camelTableFirstUpperName#(map, model);
		return new ModelAndView(ajaxMainView, model);
	}


	@PostMapping("/put#camelTableFirstUpperName#.do")
	public ModelAndView update#camelTableFirstUpperName#(HttpSession ses, @RequestParam HashMap<String, Object> map, ModelMap model) {
		log.debug(":: #camelTableFirstUpperName#Controller.update#camelTableFirstUpperName#() ::");

		UserInfoVO sesUserInfo = (UserInfoVO) ses.getAttribute(WebConstants.USER_KEY);
		String userId = sesUserInfo.getUserId();
		map.put("modId", userId);

		#camelTableName#Service.put#camelTableFirstUpperName#(map, model);
		return new ModelAndView(ajaxMainView, model);
	}

	@PostMapping("/delete#camelTableFirstUpperName#.do")
	public ModelAndView delete#camelTableFirstUpperName#(HttpSession ses, @RequestParam HashMap<String, Object> map, ModelMap model) {
		log.debug(":: #camelTableFirstUpperName#Controller.delete#camelTableFirstUpperName#() ::");
		#camelTableName#Service.delete#camelTableFirstUpperName#(map, model);
		return new ModelAndView(ajaxMainView, model);
	}
}
