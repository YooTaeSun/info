package idstrust.lsp.#group#.#group1#.service;

/**
 * <pre>
 * 1. PROJECT   		: Lab Solution Project
 * 2. CREATE USER       : #author#
 * 3. CREATE_DATE       : #current#
 * 4. MENU				: LIMS > #menu#
 * 5. PROGRAM ID		: #programId#
 * 6. PROGRAM EXPLAIN	: #desc# Service
 * </pre>
 *
 *  MO_DATE       MO_USER          MO_EXPLAIN
 *  ----------    --------    ---------------------------
 *  #today#    #author#                  최초 생성
 *  ----------    --------    ---------------------------
*/

import java.util.HashMap;

import org.springframework.ui.ModelMap;
import idstrust.lsp.#group#.#group1#.vo.#camelTableFirstUpperName#VO;

public interface #camelTableFirstUpperName#Service {

	public ModelMap getCount#camelTableFirstUpperName#(HashMap<String, Object> map, ModelMap model);

	public ModelMap getList#camelTableFirstUpperName#(HashMap<String, Object> map, ModelMap model);

	public ModelMap get#camelTableFirstUpperName#(HashMap<String, Object> map, ModelMap model);

	public ModelMap post#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO, ModelMap model);

	public ModelMap put#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO, ModelMap model);

	public ModelMap delete#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO, ModelMap model);
}
