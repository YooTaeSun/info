package com.skt.poc.biz.component.#group#.model.vo;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;

@Component
public class #camelTableFirstUpperName#Validator {

    public void validate(#camelTableFirstUpperName#VO #camelTableName#VO, Errors errors) {
        if (null != #camelTableName#VO && null != errors) {
//            if (#camelTableName#VO.getAge() > 19) {
//                errors.rejectValue("age", "NotAvailableAge", "이용할 수 없는 나이입니다.");
//            }
        }
    }
}
