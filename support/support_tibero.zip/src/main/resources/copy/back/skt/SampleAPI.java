package com.skt.poc.biz.component.#group#.api;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.skt.poc.biz.component.#group#.model.dto.#camelTableFirstUpperName#DTO;
import com.skt.poc.biz.component.#group#.model.vo.#camelTableFirstUpperName#VO;
import com.skt.poc.biz.component.#group#.model.vo.#camelTableFirstUpperName#Validator;
import com.skt.poc.biz.component.#group#.service.#camelTableFirstUpperName#Service;
import com.skt.poc.common.annotation.LoginUser;
import com.skt.poc.common.errors.ErrorsSerializer;
import com.skt.poc.common.model.LoginUserVO;
import com.skt.poc.common.model.ResponseBase;
import com.skt.poc.config.session.ModelAttributeForBaseInfo;
import com.sun.istack.NotNull;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("#path1#")
public class #camelTableFirstUpperName#API {

    @Autowired
    ErrorsSerializer errorsSerializer;

    @Autowired
    private #camelTableFirstUpperName#Service #camelTableName#Service;

    @Autowired
    private #camelTableFirstUpperName#Validator #camelTableName#Validator;

    /**
     * #desc# 목록 조회(paging).
     * http://localhost:8080/boa/api#path2##path3#/list?size=10&page=1&#sortStr#
     * 다중 정렬 : sort=user_id,ASC&sort=age,DESC
     * 파라미터값으로 넘어온 size 가 우선적용됨.
     * default-page-size: 10
     * @param pageable
     * @return Page
     * @throws Exception
     */
    @GetMapping("#path2##path3#/list")
    public ResponseBase<Page<#camelTableFirstUpperName#DTO>> list#camelTableFirstUpperName#Pageable(@ModelAttributeForBaseInfo("#camelTableName#VO") #camelTableFirstUpperName#VO #camelTableName#VO, @PageableDefault(sort = {#pkJoinStr#}) final Pageable pageable) throws Exception {
        final Page<#camelTableFirstUpperName#DTO> result = #camelTableName#Service.list#camelTableFirstUpperName#(pageable, #camelTableName#VO);
        return ResponseBase.of(result);
    }



    /**
     * #desc# 단건 조회.(id)
     * http://localhost:8080/boa/api#path2#/com/#group#/detail
     * @param #camelTableName#VO
     * @return #camelTableFirstUpperName#DTO
     * @throws Exception
     */
    @GetMapping("#path2##path3#/detail")
    public ResponseBase<#camelTableFirstUpperName#DTO> info#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO) throws Exception {
        #camelTableFirstUpperName#DTO #camelTableName#DTO = #camelTableName#Service.info#camelTableFirstUpperName#(#camelTableName#VO);
        return ResponseBase.of(#camelTableName#DTO);
    }

    /**
     * #desc# 추가(insert)
     * @param #camelTableName#VO
     * @param errors
     * @return String
     * @throws Exception
     */
    @PostMapping("#path2##path3#/regist")
    public ResponseBase reg#camelTableFirstUpperName#(@ModelAttribute("#camelTableName#VO") @Valid #camelTableFirstUpperName#VO #camelTableName#VO, @NotNull Errors errors, @LoginUser LoginUserVO loginUserVO) throws Exception {
    	#camelTableName#Validator.validate(#camelTableName#VO, errors);
        if (errors.hasErrors()) {
            return ResponseBase.validError(errorsSerializer.serialize(errors));
        }

        // Base 기본정보 가져오기
        String regId = loginUserVO.getRegId(); // 등록아이디
        String regNm = loginUserVO.getRegNm(); // 등록명
        String regDt = loginUserVO.getRegDt(); // 등록일자

        #camelTableName#VO.setRegId(regId);
        #camelTableName#VO.setRegNm(regNm);
        #camelTableName#VO.setRegDt(regDt);

        #camelTableFirstUpperName#DTO #camelTableName#DTO = #camelTableName#Service.reg#camelTableFirstUpperName#(#camelTableName#VO);
        return ResponseBase.of(#camelTableName#DTO.getClId());
    }

    /**
     * #desc# 수정(update)
     * @param commandMap
     * @param #camelTableName#VO
     * @return #camelTableName#DTO
     * @throws Exception
     */
    @PostMapping("#path2##path3#/modify")
    public ResponseBase<#camelTableFirstUpperName#DTO> upd#camelTableFirstUpperName#(@RequestParam Map<String, Object> commandMap, @ModelAttribute("#camelTableName#VO") #camelTableFirstUpperName#VO #camelTableName#VO, @LoginUser LoginUserVO loginUserVO) throws Exception {

    	// Base 기본정보 가져오기
        String regId = loginUserVO.getRegId(); // 등록아이디
        String regNm = loginUserVO.getRegNm(); // 등록명
        String regDt = loginUserVO.getRegDt(); // 등록일자

        #camelTableName#VO.setRegId(regId);
        #camelTableName#VO.setRegNm(regNm);
        #camelTableName#VO.setRegDt(regDt);

    	#camelTableFirstUpperName#DTO #camelTableName#DTO = #camelTableName#Service.upd#camelTableFirstUpperName#(#camelTableName#VO);
        return ResponseBase.of(#camelTableName#DTO);
    }

    /**
     * #desc# 삭제
     * @param #camelTableName#VO
     * @return
     * @throws Exception
     */
    @PostMapping("#path2##path3#/delete")
    public ResponseBase del#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO) throws Exception {
        #camelTableName#Service.del#camelTableFirstUpperName#(#camelTableName#VO);
        return ResponseBase.success();
    }
}
