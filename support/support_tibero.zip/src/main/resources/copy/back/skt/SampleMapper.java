package com.skt.poc.biz.component.#group#.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.skt.poc.biz.component.#group#.model.dto.#camelTableFirstUpperName#DTO;

@Mapper
@Repository
public interface #camelTableFirstUpperName#Mapper {

    public List<#camelTableFirstUpperName#DTO> list#camelTableFirstUpperName#(Pageable pageable, #camelTableFirstUpperName#DTO #camelTableName#DTO);

    public #camelTableFirstUpperName#DTO info#camelTableFirstUpperName#(#camelTableFirstUpperName#DTO #camelTableName#DTO);

    public void sav#camelTableFirstUpperName#(#camelTableFirstUpperName#DTO #camelTableName#DTO);

    public void reg#camelTableFirstUpperName#(#camelTableFirstUpperName#DTO #camelTableName#DTO);

    public void upd#camelTableFirstUpperName#(#camelTableFirstUpperName#DTO #camelTableName#DTO);

    public void del#camelTableFirstUpperName#(#camelTableFirstUpperName#DTO #camelTableName#DTO);

}
