package com.skt.poc.biz.component.#group#.model.vo;

import javax.validation.constraints.NotNull;

import com.skt.poc.common.base.BaseVO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder @AllArgsConstructor @NoArgsConstructor
public class #camelTableFirstUpperName#VO extends BaseVO {

#dtoContent#
/* 검색 영역( Search AND 조건 ) parameters : search + 컬럼명(Camel) */
#searchDtoContent#
	public #camelTableFirstUpperName#VO(#conParam#) {
#conParamBody#
	}
}
