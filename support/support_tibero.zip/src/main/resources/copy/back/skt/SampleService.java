package com.skt.poc.biz.component.#group#.service;

import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.skt.poc.biz.component.#group#.mapper.#camelTableFirstUpperName#Mapper;
import com.skt.poc.biz.component.#group#.model.dto.#camelTableFirstUpperName#DTO;
import com.skt.poc.biz.component.#group#.model.vo.#camelTableFirstUpperName#VO;

import com.skt.poc.common.exception.BusinessException;
import com.skt.poc.common.mybatis.pageable.PageableHolder;

import egovframework.rte.fdl.idgnr.impl.EgovTableIdGnrServiceImpl;
import lombok.extern.slf4j.Slf4j;

@Transactional(value="chainedTransactionManager" , rollbackFor= BusinessException.class)
@Slf4j
@Service
public class #camelTableFirstUpperName#Service {
#IdGnrServiceStr#

    @Autowired
    private #camelTableFirstUpperName#Mapper #camelTableName#Mapper;

    @Autowired
    private ModelMapper modelMapper;

    @HystrixCommand(commandProperties = {
            @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "500")
    },
            threadPoolProperties = {
                    @HystrixProperty(name = "coreSize", value = "30"),
                    @HystrixProperty(name = "maxQueueSize", value = "101"),
                    @HystrixProperty(name = "keepAliveTimeMinutes", value = "2"),
                    @HystrixProperty(name = "queueSizeRejectionThreshold", value = "15"),
                    @HystrixProperty(name = "metrics.rollingStats.numBuckets", value = "12"),
                    @HystrixProperty(name = "metrics.rollingStats.timeInMilliseconds", value = "1440")})
    public Page<#camelTableFirstUpperName#DTO> list#camelTableFirstUpperName#(Pageable pageable, #camelTableFirstUpperName#VO #camelTableName#VO) throws Exception{
    	#camelTableFirstUpperName#DTO #camelTableName#DTO = modelMapper.map(#camelTableName#VO, #camelTableFirstUpperName#DTO.class);
        return PageableHolder.getPage(pageable, page -> #camelTableName#Mapper.list#camelTableFirstUpperName#(page, #camelTableName#DTO));
    }

    public #camelTableFirstUpperName#DTO info#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO) throws Exception{
        #camelTableFirstUpperName#DTO #camelTableFirstUpperName#DTO = #camelTableName#Mapper.info#camelTableFirstUpperName#(modelMapper.map(#camelTableName#VO, #camelTableFirstUpperName#DTO.class ));
        return #camelTableFirstUpperName#DTO;
    }

    public String sav#camelTableFirstUpperName#(#camelTableFirstUpperName#DTO #camelTableFirstUpperName#DTO) throws Exception{
#takeSavPkIdStr#
        log.debug("#camelTableFirstUpperName#DTO::::" + #camelTableFirstUpperName#DTO.toString());
        #camelTableName#Mapper.sav#camelTableFirstUpperName#(#camelTableFirstUpperName#DTO);
        return #camelTableFirstUpperName#DTO.get#CamelColumnFirstUpperName#();
    }

    public #camelTableFirstUpperName#DTO reg#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO) throws Exception {
        #camelTableFirstUpperName#DTO #camelTableFirstUpperName#DTO = modelMapper.map(#camelTableName#VO, #camelTableFirstUpperName#DTO.class );
#takeRegPkIdStr#
        log.debug("#camelTableName#DTO__::::" + #camelTableFirstUpperName#DTO.toString());
        #camelTableName#Mapper.reg#camelTableFirstUpperName#(#camelTableFirstUpperName#DTO);

        return #camelTableFirstUpperName#DTO;
    }

    public #camelTableFirstUpperName#DTO upd#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO) throws Exception {

        #camelTableFirstUpperName#DTO #camelTableFirstUpperName#DTO = modelMapper.map(#camelTableName#VO, #camelTableFirstUpperName#DTO.class);

        if(StringUtils.isNoneBlank( #camelTableFirstUpperName#DTO.get#CamelColumnFirstUpperName#() )){
            #camelTableName#Mapper.upd#camelTableFirstUpperName#(#camelTableFirstUpperName#DTO);
        }
        return #camelTableFirstUpperName#DTO;
    }

    public void del#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO) throws Exception{
    	#camelTableFirstUpperName#DTO #camelTableName#DTO = modelMapper.map(#camelTableName#VO, #camelTableFirstUpperName#DTO.class);

        // 여러건을 동시에 삭제하는 경우.
        String delDataMngId = #camelTableName#DTO.getDelDataMngId();
        if (null != delDataMngId && 0 < delDataMngId.indexOf(",")) {
        	#camelTableName#DTO.setDelDataMngIdList(delDataMngId.split(","));
        }
        #camelTableName#Mapper.del#camelTableFirstUpperName#(#camelTableName#DTO);
    }

}
