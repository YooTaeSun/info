package idstrust.lsp.#group#.#group1#.vo;

import java.io.Serializable;

import idstrust.lsp.config.common.vo.CommonVO;
import lombok.Data;

@Data
public class #camelTableFirstUpperName#VO extends CommonVO implements Serializable {

#dtoContent#
}
