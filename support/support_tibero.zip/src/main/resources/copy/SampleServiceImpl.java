package idstrust.lsp.#group#.#group1#.service.impl;

/**
 * <pre>
 * 1. PROJECT   		: Lab Solution Project
 * 2. CREATE USER       : #author#
 * 3. CREATE_DATE       : #current#
 * 4. MENU				: #menu#
 * 5. PROGRAM ID		: #programId#
 * 6. PROGRAM EXPLAIN	: #desc# ServiceImpl
 * </pre>
 *
 *  MO_DATE       MO_USER          MO_EXPLAIN
 *  ----------    --------    ---------------------------
 *  #today#    #author#                  최초 생성
 *  ----------    --------    ---------------------------
*/

import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import egovframework.rte.psl.dataaccess.util.EgovMap;
import idstrust.lsp.config.common.vo.PaginationVO;
import idstrust.lsp.config.sys.vo.GridResponseVO;
import idstrust.lsp.#group#.#group1#.vo.#camelTableFirstUpperName#VO;
import idstrust.lsp.#group#.#group1#.mapper.#camelTableFirstUpperName#Mapper;
import idstrust.lsp.#group#.#group1#.service.#camelTableFirstUpperName#Service;
import idstrust.lsp.config.base.service.impl.BaseServiceImpl;

@Service("#camelTableName#Service")
public class #camelTableFirstUpperName#ServiceImpl extends BaseServiceImpl implements #camelTableFirstUpperName#Service {

	private static final Logger log = LoggerFactory.getLogger(#camelTableFirstUpperName#ServiceImpl.class);

	@Autowired
	private #camelTableFirstUpperName#Mapper #camelTableName#Mapper;

	/**
	 * <p>#desc# 리스트를 조회한다.</p>
	 *
	 * @param HashMap &lt;String, Object&gt; map
	 * @param ModelMap model
	 * @return ModelMap
	 */
	@Override
	public ModelMap getList#camelTableFirstUpperName#(HashMap<String, Object> map, ModelMap model) {
		log.debug(":: #camelTableFirstUpperName#ServiceImpl.getList#camelTableFirstUpperName#() ::");

		//param
		assignSessData(map, new String[] {"comCd", "plantCd", "lang", "dateType"});

		List<EgovMap> list = #camelTableName#Mapper.selectList#camelTableFirstUpperName#(map);
		PaginationVO pgVO = setPagination(map);
		model.addAttribute("data", decorateGridList(list, pgVO));

		return model;
	}

	/**
     * <p>#desc#를(을) 조회한다.</p>
	 *
	 * @param HashMap &lt;String, Object&gt; map
	 * @param ModelMap model
	 * @return ModelMap
	 */
	@Override
	public ModelMap get#camelTableFirstUpperName#(HashMap<String, Object> map, ModelMap model) {
		log.debug(":: #camelTableFirstUpperName#ServiceImpl.get#camelTableFirstUpperName#() ::");

		//param
		assignSessData(map, new String[] {"comCd", "plantCd", "lang", "dateType"});

		EgovMap #camelTableName# = #camelTableName#Mapper.select#camelTableFirstUpperName#(map);
		model.addAttribute("data", #camelTableName#);
		return model;
	}

	/**
     * <p>#desc#를(을) 등록한다.</p>
	 *
     * @param #camelTableFirstUpperName#VO #camelTableName#VO
     * @param ModelMap model
     * @return ModelAndView
	 */
	@Override
	public ModelMap post#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO, ModelMap model) {
		log.debug(":: #camelTableFirstUpperName#ServiceImpl.post#camelTableFirstUpperName#() ::");

		//param
		assignSessData(#camelTableName#VO, SESS_COM_REG_COLS);

		#camelTableName#Mapper.insert#camelTableFirstUpperName#(#camelTableName#VO);
		return model;
	}

	/**
     * <p>#desc#를(을) 수정한다.</p>
	 *
     * @param #camelTableFirstUpperName#VO #camelTableName#VO
     * @param ModelMap model
     * @return ModelAndView
	 */
	@Override
	public ModelMap put#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO, ModelMap model) {
		log.debug(":: #camelTableFirstUpperName#ServiceImpl.put#camelTableFirstUpperName#() ::");

		//param
		assignSessData(#camelTableName#VO, SESS_COM_MOD_COLS);
		#camelTableName#Mapper.update#camelTableFirstUpperName#(#camelTableName#VO);
		return model;
	}

	/**
     * <p>#desc#를(을) 삭제한다.</p>
	 *
     * @param #camelTableFirstUpperName#VO #camelTableName#VO
     * @param ModelMap model
     * @return ModelAndView
	 */
	@Override
	public ModelMap delete#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO, ModelMap model) {
		log.debug(":: #camelTableFirstUpperName#ServiceImpl.delete#camelTableFirstUpperName#() ::");

		//param
		assignSessData(#camelTableName#VO, SESS_COM_REG_COLS);

		#camelTableName#Mapper.delete#camelTableFirstUpperName#(#camelTableName#VO);
		return model;
	}
}
