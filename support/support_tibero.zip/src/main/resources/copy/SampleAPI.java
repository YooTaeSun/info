package idstrust.lsp.#group#.#group1#.controller;

/**
 * <pre>
 * 1. PROJECT   		: Lab Solution Project
 * 2. CREATE USER       : #author#
 * 3. CREATE_DATE       : #current#
 * 4. MENU				: #menu#
 * 5. PROGRAM ID		: #programId#
 * 6. PROGRAM EXPLAIN	: #desc# Controller
 * </pre>
 *
 *  MO_DATE       MO_USER          MO_EXPLAIN
 *  ----------    --------    ---------------------------
 *  #today#    #author#                  최초 생성
 *  ----------    --------    ---------------------------
*/

import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;
import idstrust.lsp.#group#.#group1#.service.#camelTableFirstUpperName#Service;
import idstrust.lsp.#group#.#group1#.vo.#camelTableFirstUpperName#VO;

@Controller
@RequestMapping("/#group#/#group1#/#camelTableName#")
public class #camelTableFirstUpperName#Controller {

	private static final Logger log = LoggerFactory.getLogger(#camelTableFirstUpperName#Controller.class);

	@Autowired
	private MappingJackson2JsonView ajaxMainView;

    @Autowired
    private #camelTableFirstUpperName#Service #camelTableName#Service;

    /**
     * <p>#desc# 리스트를 조회한다.</p>
	 *
	 * <p></p>
	 *
	 * <pre>
	 * </pre>
	 *
     * @param HashMap &lt;String, Object&gt; map
     * @param ModelMap model
     * @return ModelAndView
     */
    @GetMapping("/getList#camelTableFirstUpperName#.do")
	public ModelAndView getList#camelTableFirstUpperName#(@RequestParam HashMap<String, Object> map, ModelMap model) {
		log.debug(":: #camelTableFirstUpperName#Controller.getList#camelTableFirstUpperName#() ::");
		#camelTableName#Service.getList#camelTableFirstUpperName#(map, model);
		return new ModelAndView(ajaxMainView, model);
	}

    /**
     * <p>#desc#를(을) 조회한다.</p>
	 *
	 * <p></p>
	 *
	 * <pre>
	 * </pre>
	 *
     * @param HashMap &lt;String, Object&gt; map
     * @param ModelMap model
     * @return ModelAndView
     */
	@GetMapping("/get#camelTableFirstUpperName#.do")
	public ModelAndView get#camelTableFirstUpperName#(@RequestParam HashMap<String, Object> map, ModelMap model) {
		log.debug(":: #camelTableFirstUpperName#Controller.get#camelTableFirstUpperName#() ::");
		#camelTableName#Service.get#camelTableFirstUpperName#(map, model);
		return new ModelAndView(ajaxMainView, model);
	}

    /**
     * <p>#desc#를(을) 등록한다.</p>
     *
	 * <p></p>
	 *
	 * <pre>
	 * </pre>
	 *
     * @param #camelTableFirstUpperName#VO #camelTableName#VO
     * @param ModelMap model
     * @return ModelAndView
     */
	@PostMapping("/post#camelTableFirstUpperName#.do")
	public ModelAndView post#camelTableFirstUpperName#(@RequestBody #camelTableFirstUpperName#VO #camelTableName#VO, ModelMap model) {
		log.debug(":: #camelTableFirstUpperName#Controller.post#camelTableFirstUpperName#() ::");

		try {
			#camelTableName#Service.post#camelTableFirstUpperName#(#camelTableName#VO, model);
		} catch (Exception e) {
			log.error("{}",e);
			model.put("responseCode", "ERR");
			model.put("msg", e.getLocalizedMessage());
		}
		return new ModelAndView(ajaxMainView, model);
	}

    /**
     * <p>#desc#를(을) 수정한다.</p>
     *
	 * <p></p>
	 *
	 * <pre>
	 * </pre>
	 *
     * @param #camelTableFirstUpperName#VO #camelTableName#VO
     * @param ModelMap model
     * @return ModelAndView
     */
	@PostMapping("/put#camelTableFirstUpperName#.do")
	public ModelAndView put#camelTableFirstUpperName#(@RequestBody #camelTableFirstUpperName#VO #camelTableName#VO, ModelMap model) {
		log.debug(":: #camelTableFirstUpperName#Controller.put#camelTableFirstUpperName#() ::");

		try {
			#camelTableName#Service.put#camelTableFirstUpperName#(#camelTableName#VO, model);
		} catch (Exception e) {
			log.error("{}",e);
			model.put("responseCode", "ERR");
			model.put("msg", e.getLocalizedMessage());
		}
		return new ModelAndView(ajaxMainView, model);
	}

    /**
     * <p>#desc#를(을) 삭제한다.</p>
     *
	 * <p></p>
	 *
	 * <pre>
	 * </pre>
	 *
     * @param #camelTableFirstUpperName#VO #camelTableName#VO
     * @param ModelMap model
     * @return ModelAndView
     */
	@PostMapping("/delete#camelTableFirstUpperName#.do")
	public ModelAndView delete#camelTableFirstUpperName#(@RequestBody #camelTableFirstUpperName#VO #camelTableName#VO, ModelMap model) {
		log.debug(":: #camelTableFirstUpperName#Controller.delete#camelTableFirstUpperName#() ::");

		try {
			#camelTableName#Service.delete#camelTableFirstUpperName#(#camelTableName#VO, model);
		} catch (Exception e) {
			log.error("{}",e);
			model.put("responseCode", "ERR");
			model.put("msg", e.getLocalizedMessage());
		}
		return new ModelAndView(ajaxMainView, model);
	}

	/**
     * <p>#desc# 화면 호출</p>
	 *
	 * <p></p>
	 *
	 * <pre>
	 * </pre>
	 *
     * @param map
     * @param ModelMap model
     * @return String
     */
	@RequestMapping("/#camelTableName#.do")
	public String #camelTableName#(@RequestParam HashMap<String, Object> map, ModelMap model) {
		log.debug(":: #camelTableFirstUpperName#Controller.#camelTableName#() ::");
		return "/#group#/#group1#/#camelTableName#";
	}
}
