package idstrust.lsp.#group#.#group1#.service;

/**
 * <pre>
 * 1. PROJECT   		: Lab Solution Project
 * 2. CREATE USER       : #author#
 * 3. CREATE_DATE       : #current#
 * 4. MENU				: #menu#
 * 5. PROGRAM ID		: #programId#
 * 6. PROGRAM EXPLAIN	: #desc# Service
 * </pre>
 *
 *  MO_DATE       MO_USER          MO_EXPLAIN
 *  ----------    --------    ---------------------------
 *  #today#    #author#                  최초 생성
 *  ----------    --------    ---------------------------
*/

import java.util.HashMap;

import org.springframework.ui.ModelMap;
import idstrust.lsp.#group#.#group1#.vo.#camelTableFirstUpperName#VO;

public interface #camelTableFirstUpperName#Service {

	/**
	 * <p>#desc# 리스트를 조회한다.</p>
	 *
	 * @param HashMap &lt;String, Object&gt; map
	 * @param ModelMap model
	 * @return ModelMap
	 */
	public ModelMap getList#camelTableFirstUpperName#(HashMap<String, Object> map, ModelMap model);

	/**
     * <p>#desc#를(을) 조회한다.</p>
	 *
	 * @param HashMap &lt;String, Object&gt; map
	 * @param ModelMap model
	 * @return ModelMap
	 */
	public ModelMap get#camelTableFirstUpperName#(HashMap<String, Object> map, ModelMap model);

	/**
     * <p>#desc#를(을) 등록한다.</p>
	 *
     * @param #camelTableFirstUpperName#VO #camelTableName#VO
     * @param ModelMap model
     * @return ModelAndView
	 */
	public ModelMap post#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO, ModelMap model);

	/**
     * <p>#desc#를(을) 수정한다.</p>
	 *
     * @param #camelTableFirstUpperName#VO #camelTableName#VO
     * @param ModelMap model
     * @return ModelAndView
	 */
	public ModelMap put#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO, ModelMap model);

	/**
     * <p>#desc#를(을) 삭제한다.</p>
	 *
     * @param #camelTableFirstUpperName#VO #camelTableName#VO
     * @param ModelMap model
     * @return ModelAndView
	 */
	public ModelMap delete#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO, ModelMap model);
}
