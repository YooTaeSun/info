package idstrust.lsp.#group#.#group1#.mapper;

/**
 * <pre>
 * 1. PROJECT   		: Lab Solution Project
 * 2. CREATE USER       : #author#
 * 3. CREATE_DATE       : #current#
 * 4. MENU				: #menu#
 * 5. PROGRAM ID		: #programId#
 * 6. PROGRAM EXPLAIN	: #desc# Mapper
 * </pre>
 *
 *  MO_DATE       MO_USER          MO_EXPLAIN
 *  ----------    --------    ---------------------------
 *  #today#    #author#                  최초 생성
 *  ----------    --------    ---------------------------
*/

import java.util.HashMap;
import java.util.List;

import egovframework.rte.psl.dataaccess.mapper.Mapper;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import idstrust.lsp.#group#.#group1#.vo.#camelTableFirstUpperName#VO;

@Mapper("#camelTableName#Mapper")
public interface #camelTableFirstUpperName#Mapper {

	/**
	 * <p>#desc# 리스트를 조회한다.</p>
	 *
	 * @param HashMap &lt;String, Object&gt; map
	 * @return List&lt;EgovMap&gt;
	 */
    public List<EgovMap> selectList#camelTableFirstUpperName#(HashMap<String, Object> map);

	/**
	 * <p>#desc#를(을) 조회한다.</p>
	 *
	 * @param HashMap &lt;String, Object&gt; map
	 * @return EgovMap
	 */
    public EgovMap select#camelTableFirstUpperName#(HashMap<String, Object> map);

	/**
	 * <p>#desc#를(을) 등록한다.</p>
	 *
	 * @param #camelTableFirstUpperName#VO #camelTableName#VO
	 * @return Integer
	 */
    public Integer insert#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO);

	/**
	 * <p>#desc#를(을) 수정한다.</p>
	 *
	 * @param #camelTableFirstUpperName#VO #camelTableName#VO
	 * @return Integer
	 */
    public Integer update#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO);

	/**
	 * <p>#desc#를(을) 삭제한다.</p>
	 *
	 * @param #camelTableFirstUpperName#VO #camelTableName#VO
	 * @return Integer
	 */
    public Integer delete#camelTableFirstUpperName#(#camelTableFirstUpperName#VO #camelTableName#VO);
}
