package web.townsi.com.work.setting.biz.impl;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;
import web.townsi.com.utils.ListUtil;
import web.townsi.com.utils.StrUtil;
import web.townsi.com.work.mapper.mysql.SettingMapperMysql;
import web.townsi.com.work.mapper.postgre.SettingMapperPostgre;
import web.townsi.com.work.setting.biz.SettingBiz;
import web.townsi.com.work.setting.biz.SettingModelBiz;
import web.townsi.com.work.setting.biz.SettingTransBiz;

import java.io.File;
import java.util.HashMap;
import java.util.List;

/**
* SettingTransBizImpl
* @author 유태선
* @since 2016.10.14
* @version 1.0
* @see
* </pre>
*/
@SuppressWarnings({"rawtypes","unchecked","unused"})
@Service
public class SettingTransBizImpl implements SettingTransBiz {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private SettingBiz settingBiz;

	@Autowired
	private SettingMapperMysql settingMapperMysql;
//
//	@Autowired
//	private SettingMapperPostgre settingMapperByPostgre;

	public static String LINE = "\n";
	public static String SPACE_CNT = "    ";
	public static String SLASH = File.separator;// lastIndexOf("/")

	public static String rTxt  = "#{txt}";

	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();

	public HashMap makeTrans(HashMap params) throws Exception {

		String tableName2 = StringUtils.defaultString((String) params.get("tableName"));
		String camelTableFirstUpperName = StrUtil.toCamelCaseFirstUpper(tableName2.toUpperCase());

		List<HashMap> tableList = settingBiz.selectTableInfo(params,
				StringUtils.defaultString((String)params.get("dbName"))
				, StringUtils.defaultString((String)params.get("tableSchema"))
				, StringUtils.defaultString((String)params.get("tableName"))
		);

		String tableName = "BS_LANG";
		String tableSchema = "CM";

		params.put("tableName",tableName);
		params.put("tableSchema",tableSchema);

		String upperTableName = tableName.toUpperCase();
		String lowerTableName = tableName.toLowerCase();
		String camelTableName = StrUtil.toCamelCase(upperTableName);


		params.put("upperTableName", upperTableName);
		params.put("lowerTableName", lowerTableName);
		params.put("camelTableName", camelTableName);
//		params.put("camelTableFirstUpperName", camelTableFirstUpperName);


		HashMap dataMap = new HashMap();

		tableSchema = StringUtils.defaultString((String) params.get("tableSchema"));
		upperTableName = StringUtils.defaultString((String) params.get("upperTableName"));
		lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		 camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String modelComment = StringUtils.defaultString((String) params.get("modelComment"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String group1 = StringUtils.defaultString((String) params.get("group1"));
		String author = StringUtils.defaultString((String) params.get("author"));
		String desc = StringUtils.defaultString((String) params.get("desc"));
		String today = StringUtils.defaultString((String) params.get("today"));
		String current = StringUtils.defaultString((String) params.get("current"));
		String menu = StringUtils.defaultString((String) params.get("menu"));
		String programId = StringUtils.defaultString((String) params.get("programId"));

		HashMap paramMap = new HashMap<>();
		paramMap.put("fromSql", "SELECT BS_PAGE_PK FROM CM.BS_PAGE WHERE PAGE_ID  = '"+programId+"'");
		HashMap resultMap = settingMapperMysql.selectSqlInfo(paramMap);
		int bsPagePk = -1;
		if(resultMap != null && resultMap.get("BS_PAGE_PK") != null) {
			bsPagePk = (Integer) resultMap.get("BS_PAGE_PK");
		}else {
			return dataMap;
		}



		String ifcase = StringUtils.defaultString((String) params.get("ifcase"),"if_package");
		String whereParamPrefix = StringUtils.defaultString((String) params.get("whereParamPrefix"),"");

		StringBuilder insertSql = new StringBuilder(500);
		StringBuilder insertValSql = new StringBuilder(500);
		StringBuilder insertListSStr = new StringBuilder(500);
		StringBuilder insertListEStr = new StringBuilder(500);
		StringBuilder insertListGStr = new StringBuilder(500);
		StringBuilder insertListBtnStr = new StringBuilder(500);
		StringBuilder insertListMsgStr = new StringBuilder(500);


		String column_name = "";
		String column_comment = "";
		String camel_column_name = "";
		String columns = "";
		String pk = "";
		String orderByPK = "";
		String w_type = "";
		String pkStr = "";
		String comments = "";

		HashMap replaceMap = new HashMap();
//		replaceMap.put("#tableName#",camelTableFirstUpperName);

		List<HashMap> list = settingBiz.selectTableInfo(params,
				StringUtils.defaultString((String)params.get("dbName"))
				, StringUtils.defaultString((String)params.get("tableSchema"))
				, StringUtils.defaultString((String)params.get("tableName"))
		);

		if(!ListUtil.isEmpty(list)) {

			String camelColumnFirstUpperName = "";
			String param_column_name = "";

			for (int i = 0; i < list.size(); i++) {
				HashMap rs = list.get(i);
				column_name = (String) rs.get("column_name");
				column_comment = (String) rs.get("column_comment");
				camel_column_name = (String) rs.get("camel_column_name");
				columns = (String) rs.get("columns");
				comments = (String) rs.get("comments");
				w_type = (String) rs.get("w_type");
				camelColumnFirstUpperName = camel_column_name.substring(0,1).toUpperCase() + camel_column_name.substring(1);
				pk = StringUtils.defaultString((String) rs.get("pk")).toLowerCase();

				if(!StringUtils.isEmpty(pk)) {
					continue;
				}

				insertSql.append(", " + column_name);

				if(camel_column_name.toLowerCase().equals("regDt".toLowerCase())
						|| camel_column_name.toLowerCase().equals("modDt".toLowerCase())
				) {
					insertValSql.append(" ,CURRENT_TIMESTAMP()");
				}else {
					insertValSql.append(", " + rTxt.replace("txt", camel_column_name));
				}
			}
		}


		String insert = "INSERT INTO " + tableSchema + "."+ upperTableName + "(" + insertSql.toString().replaceFirst(", ", "") + " ) "
				+ "VALUES (" +insertValSql.toString().replaceFirst(", ", "") + ");\n";

//		insert = insert.replace("\t", " ").replace("\n", " ") + "\n";


		insert = insert.replace("#{comCd}","'"+"0000"+"'")
				.replace("#{plantCd}","'"+"0000"+"'")
				.replace("#{msgTp}","'"+"PAGE"+"'")
				.replace("#{editYn}","'"+"Y"+"'")
				.replace("#{useYn}","'"+"Y"+"'")
				.replace("#{regId}","'"+"0"+"'")
				.replace("#{regIp}","'"+"0.0.0.0"+"'")
				.replace("#{modId}","'"+"0"+"'")
				.replace("#{modIp}","'"+"0.0.0.0"+"'")
				.replace("#{pagePk}","'"+bsPagePk+"'")
				;

		System.out.println("insert >> " + insert);

		String camelColumnFirstUpperName = "";
		String insertResult = "";
		String dataType = "";
		String insertCommet = "";

		if(!ListUtil.isEmpty(tableList)) {
			for (int i = 0; i < tableList.size(); i++) {
				HashMap rs = tableList.get(i);
				column_name = (String) rs.get("column_name");
				column_comment = (String) rs.get("column_comment");
				camel_column_name = (String) rs.get("camel_column_name");
				columns = (String) rs.get("columns");
				comments = (String) rs.get("comments");
				w_type = (String) rs.get("w_type");
				camelColumnFirstUpperName = camel_column_name.substring(0,1).toUpperCase() + camel_column_name.substring(1);
				pk = StringUtils.defaultString((String) rs.get("pk")).toLowerCase();
				dataType = (String) rs.get("data_type");

				if("pk".equals(pk)) {
					continue;
				}

				if(StringUtils.isEmpty(comments)) {
					continue;
				}

//				타입이 date, timestamp 면 continue 추가
//				if(dataType.equals("date") || dataType.equals("datetime")) {
//					continue;
//				}

				if(column_name.equals("COM_CD") ||
				   column_name.equals("PLANT_CD") ||
				   column_name.equals("REG_IP") ||
				   column_name.equals("MOD_IP")
				   ) {
					continue;
				}

				insertCommet = String.format("/* %s ,%s */", column_comment, "S-TXT-" +column_name.toUpperCase());
				insertResult = insertCommet + insert.replace("#{pageId}","'"+programId+"'")
						.replace("#{clsLink}","'"+"S-TXT-" +column_name.toUpperCase() + "'")
						.replace("#{msgDf}", "'" + column_comment + "'")
						.replace("#{msgKr}","'"+column_comment + "'")
						.replace("#{msgEn}","'"+column_comment + "'")
						.replace("#{msgEtc}","'"+column_comment + "'");

				insertListSStr.append(insertResult);


				insertCommet = String.format("/* %s ,%s */", column_comment, "E-TXT-" +column_name.toUpperCase());
				insertResult = insertCommet + insert.replace("#{pageId}","'"+programId+"'")
						.replace("#{clsLink}","'"+"E-TXT-" +column_name.toUpperCase() + "'")
						.replace("#{msgDf}", "'" + column_comment + "'")
						.replace("#{msgKr}","'"+column_comment + "'")
						.replace("#{msgEn}","'"+column_comment + "'")
						.replace("#{msgEtc}","'"+column_comment + "'");

				insertListEStr.append(insertResult);

				insertCommet = String.format("/* %s ,%s */", column_comment, "G-TXT-" +column_name.toUpperCase());
				insertResult = insertCommet + insert.replace("#{pageId}","'"+programId+"'")
						.replace("#{clsLink}","'"+"G-TXT-" +column_name.toUpperCase() + "'")
						.replace("#{msgDf}", "'" + column_comment + "'")
						.replace("#{msgKr}","'"+column_comment + "'")
						.replace("#{msgEn}","'"+column_comment + "'")
						.replace("#{msgEtc}","'"+column_comment + "'");

				insertListGStr.append(insertResult);


			}


			//				------------
			String btnAction =  "";
			String btncls =  "";
			btnAction =  "조회";
			btncls = "S-BTN-SRCH";
			insertCommet = String.format("/* %s ,%s */", btnAction, btncls);
			insertResult = insertCommet + insert.replace("#{pageId}","'"+programId+"'")
					.replace("#{clsLink}","'"+ btncls + "'")
					.replace("#{msgDf}", "'" + btnAction + "'")
					.replace("#{msgKr}","'"+btnAction + "'")
					.replace("#{msgEn}","'"+btnAction + "'")
					.replace("#{msgEtc}","'"+btnAction + "'");
			insertListBtnStr.append(insertResult);

			btnAction =  "초기화";
			btncls = "S-BTN-RESET";
			insertCommet = String.format("/* %s ,%s */", btnAction, btncls);
			insertResult = insertCommet + insert.replace("#{pageId}","'"+programId+"'")
					.replace("#{clsLink}","'"+ btncls + "'")
					.replace("#{msgDf}", "'" + btnAction + "'")
					.replace("#{msgKr}","'"+btnAction + "'")
					.replace("#{msgEn}","'"+btnAction + "'")
					.replace("#{msgEtc}","'"+btnAction + "'");
			insertListBtnStr.append(insertResult);

			btnAction =  "검색어구성";
			btncls = "S-BTN-QUERY_CONSTRUCTION";
			insertCommet = String.format("/* %s ,%s */", btnAction, btncls);
			insertResult = insertCommet + insert.replace("#{pageId}","'"+programId+"'")
					.replace("#{clsLink}","'"+ btncls + "'")
					.replace("#{msgDf}", "'" + btnAction + "'")
					.replace("#{msgKr}","'"+btnAction + "'")
					.replace("#{msgEn}","'"+btnAction + "'")
					.replace("#{msgEtc}","'"+btnAction + "'");
			insertListBtnStr.append(insertResult);

			btnAction =  "검색어저장";
			btncls = "S-BTN-QUERY_SAVE";
			insertCommet = String.format("/* %s ,%s */", btnAction, btncls);
			insertResult = insertCommet + insert.replace("#{pageId}","'"+programId+"'")
					.replace("#{clsLink}","'"+ btncls + "'")
					.replace("#{msgDf}", "'" + btnAction + "'")
					.replace("#{msgKr}","'"+btnAction + "'")
					.replace("#{msgEn}","'"+btnAction + "'")
					.replace("#{msgEtc}","'"+btnAction + "'");
			insertListBtnStr.append(insertResult);

			insertListBtnStr.append("\n-- ----------------- \n\n");

			btnAction =  "신규입력";
			btncls = "S-BTN-INSERT_NEW";
			insertCommet = String.format("/* %s ,%s */", btnAction, btncls);
			insertResult = insertCommet + insert.replace("#{pageId}","'"+programId+"'")
					.replace("#{clsLink}","'"+ btncls + "'")
					.replace("#{msgDf}", "'" + btnAction + "'")
					.replace("#{msgKr}","'"+btnAction + "'")
					.replace("#{msgEn}","'"+btnAction + "'")
					.replace("#{msgEtc}","'"+btnAction + "'");
			insertListBtnStr.append(insertResult);

			btnAction =  "저장";
			btncls = "S-BTN-SAVE";
			insertCommet = String.format("/* %s ,%s */", btnAction, btncls);
			insertResult = insertCommet + insert.replace("#{pageId}","'"+programId+"'")
					.replace("#{clsLink}","'"+ btncls + "'")
					.replace("#{msgDf}", "'" + btnAction + "'")
					.replace("#{msgKr}","'"+btnAction + "'")
					.replace("#{msgEn}","'"+btnAction + "'")
					.replace("#{msgEtc}","'"+btnAction + "'");
			insertListBtnStr.append(insertResult);

			btnAction =  "저장 후 닫기";
			btncls = "S-BTN-SAVE_CLOSE";
			insertCommet = String.format("/* %s ,%s */", btnAction, btncls);
			insertResult = insertCommet + insert.replace("#{pageId}","'"+programId+"'")
					.replace("#{clsLink}","'"+ btncls + "'")
					.replace("#{msgDf}", "'" + btnAction + "'")
					.replace("#{msgKr}","'"+btnAction + "'")
					.replace("#{msgEn}","'"+btnAction + "'")
					.replace("#{msgEtc}","'"+btnAction + "'");
			insertListBtnStr.append(insertResult);

			btnAction =  "닫기";
			btncls = "S-BTN-CLOSE";
			insertCommet = String.format("/* %s ,%s */", btnAction, btncls);
			insertResult = insertCommet + insert.replace("#{pageId}","'"+programId+"'")
					.replace("#{clsLink}","'"+ btncls + "'")
					.replace("#{msgDf}", "'" + btnAction + "'")
					.replace("#{msgKr}","'"+btnAction + "'")
					.replace("#{msgEn}","'"+btnAction + "'")
					.replace("#{msgEtc}","'"+btnAction + "'");
			insertListBtnStr.append(insertResult);

			btnAction =  "수정";
			btncls = "S-BTN-EDIT";
			insertCommet = String.format("/* %s ,%s */", btnAction, btncls);
			insertResult = insertCommet + insert.replace("#{pageId}","'"+programId+"'")
					.replace("#{clsLink}","'"+ btncls + "'")
					.replace("#{msgDf}", "'" + btnAction + "'")
					.replace("#{msgKr}","'"+btnAction + "'")
					.replace("#{msgEn}","'"+btnAction + "'")
					.replace("#{msgEtc}","'"+btnAction + "'");
			insertListBtnStr.append(insertResult);

			btnAction =  "승인요청";
			btncls = "S-BTN_APRV_REQ";
			insertCommet = String.format("/* %s ,%s */", btnAction, btncls);
			insertResult = insertCommet + insert.replace("#{pageId}","'"+programId+"'")
					.replace("#{clsLink}","'"+ btncls + "'")
					.replace("#{msgDf}", "'" + btnAction + "'")
					.replace("#{msgKr}","'"+btnAction + "'")
					.replace("#{msgEn}","'"+btnAction + "'")
					.replace("#{msgEtc}","'"+btnAction + "'");
			insertListBtnStr.append(insertResult);

			btnAction =  "폐기요청";
			btncls = "S-BTN_APRV-DISUSE_REQ";
			insertCommet = String.format("/* %s ,%s */", btnAction, btncls);
			insertResult = insertCommet + insert.replace("#{pageId}","'"+programId+"'")
					.replace("#{clsLink}","'"+ btncls + "'")
					.replace("#{msgDf}", "'" + btnAction + "'")
					.replace("#{msgKr}","'"+btnAction + "'")
					.replace("#{msgEn}","'"+btnAction + "'")
					.replace("#{msgEtc}","'"+btnAction + "'");
			insertListBtnStr.append(insertResult);

		}

//		System.out.println(insertListEStr.toString());

		//버튼

		replaceMap.put("#S_TXT#", insertListSStr.toString());
		replaceMap.put("#E_TXT#", insertListEStr.toString());
		replaceMap.put("#G_TXT#", insertListGStr.toString());
		replaceMap.put("#BTN#", insertListBtnStr.toString());

		//MSG
		String btnAction =  "선택된 데이타가 없습니다.";
		String btncls = "MSG-TXT-NO_SELECTED_DATA";
		insertCommet = String.format("/* %s ,%s */", btnAction, btncls);
		insertResult = insertCommet + insert.replace("#{pageId}","'"+programId+"'")
				.replace("#{clsLink}","'"+ btncls + "'")
				.replace("#{msgDf}", "'" + btnAction + "'")
				.replace("#{msgKr}","'"+btnAction + "'")
				.replace("#{msgEn}","'"+btnAction + "'")
				.replace("#{msgEtc}","'"+btnAction + "'");
		insertListMsgStr.append(insertResult);

		replaceMap.put("#MSG#", insertListMsgStr.toString());

		//AppStartingEvent.java --> copyArray
		String rfullPath = SITE_WEB_ROOT + "/copy/SampleTrans.xml";
		String wfullPath = SITE_WEB_ROOT + "/new/"+camelTableFirstUpperName+"/trans.xml";

		String str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);

		dataMap.put("str", str);
		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}


}