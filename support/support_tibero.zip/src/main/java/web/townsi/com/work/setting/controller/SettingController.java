package web.townsi.com.work.setting.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import web.townsi.com.framework.fixed.AppConst;
import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;
import web.townsi.com.utils.StrUtil;
import web.townsi.com.work.setting.biz.SettingApiBiz;
import web.townsi.com.work.setting.biz.SettingBiz;
import web.townsi.com.work.setting.biz.SettingIdgnBiz;
import web.townsi.com.work.setting.biz.SettingModelBiz;
import web.townsi.com.work.setting.biz.SettingServiceBiz;
import web.townsi.com.work.setting.biz.SettingSqlBiz;
import web.townsi.com.work.setting.biz.SettingTransBiz;

@Controller
@RequestMapping({ "/setting" })
@SuppressWarnings({"rawtypes","unchecked"})
public class SettingController {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private LinkedHashMap<String, String> propMap;

	@Autowired
	private SettingBiz settingBiz;

	@Autowired
	private SettingSqlBiz settingSqlBiz;

	@Autowired
	private SettingModelBiz settingModelBiz;

	@Autowired
	private SettingServiceBiz settingServiceBiz;

	@Autowired
	private SettingIdgnBiz settingIdgnBiz;

	@Autowired
	private SettingApiBiz settingApiBiz;

	@Autowired
	private SettingTransBiz settingTransBiz;

	final static String SITE_WEB_ROOT_PATH = Const.Path.SITE_WEB_ROOT.getValue();


	@RequestMapping({ "/main" })
	public String main(@RequestParam HashMap params, Model model) throws Exception {
		return "setting/main";
	}

	@RequestMapping({ "/main2" })
	public String main2(@RequestParam HashMap params, Model model) throws Exception {
		return "setting/main2";
	}

	@RequestMapping({ "/info" })
	public ResponseEntity<HashMap> info(@RequestParam HashMap params, Model model) throws Exception {
		LinkedHashMap resultMap = new LinkedHashMap();
		ResponseEntity entity = null;
		try {
			Iterator it = this.propMap.keySet().iterator();
			while (it.hasNext()) {
				String key = (String) it.next();
				resultMap.put(key, this.propMap.get(key));
			}

			resultMap.put("param", params);
			entity = new ResponseEntity(resultMap, HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage());
			resultMap.put("error", e.getMessage());
			entity = new ResponseEntity(resultMap, HttpStatus.NOT_ACCEPTABLE);
		}
		return entity;
	}


	@RequestMapping({ "/save" })
	public ResponseEntity<HashMap> save(HttpServletRequest request, @RequestParam HashMap params, Model model) throws Exception {
		HashMap resultMap = new HashMap();
		ResponseEntity entity = null;
		try {

			StrUtil.addMap(this.propMap, params);
			String content = FileUtil.changeContent(AppConst.settingProp, params);
			FileUtil.writeFile(AppConst.settingProp, content);

			resultMap.put("param", params);
			entity = new ResponseEntity(resultMap, HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage());
			resultMap.put("error", e.getMessage());
			entity = new ResponseEntity(resultMap, HttpStatus.NOT_ACCEPTABLE);
		}
		return entity;
	}


	@RequestMapping("/comment")
    public ResponseEntity<HashMap> comment(@RequestParam HashMap params, Model model) throws Exception {
    	HashMap resultMap = new HashMap();
    	ResponseEntity entity = null;
		try {

			HashMap dataMap = new HashMap();
			String tableName = StringUtils.defaultString((String) params.get("tableName"));
			String comment = this.settingBiz.takeComment(params);
			dataMap.put("comment", comment);


			resultMap.put("data", dataMap);
			resultMap.put("param", params);
			entity = new ResponseEntity(resultMap, HttpStatus.OK);
			logger.debug("comment params : " + params);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			resultMap.put("error", e.getMessage());
			entity = new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return entity;
    }

    @RequestMapping("/source")
    public ResponseEntity<HashMap> source(@RequestParam HashMap params, Model model) throws Exception {
    	HashMap resultMap = new HashMap();
    	ResponseEntity entity = null;
		try {

			HashMap dataMap = new HashMap();

			//------------  초기 param 설정 start --------------------------
			String group = StringUtils.defaultString((String) params.get("group")).toLowerCase();
			params.put("group", group);
			String group1 = StringUtils.defaultString((String) params.get("group1")).toLowerCase();
			params.put("group1", group1);

			String tableName = StringUtils.defaultString((String) params.get("tableName"));

			Date today = new Date();
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy.MM.dd");
			SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
			params.put("today", simpleDateFormat.format(today));
			params.put("current", simpleDateFormat1.format(today));

			String upperTableName = "";
			String lowerTableName = "";
			String camelTableName = "";
			String camelTableFirstUpperName = "";
			String pk = "";

			if(!StringUtils.isEmpty(tableName)) {
				upperTableName = tableName.toUpperCase();
				lowerTableName = tableName.toLowerCase();
				camelTableName = StrUtil.toCamelCase(upperTableName);
				camelTableFirstUpperName = StrUtil.toCamelCaseFirstUpper(upperTableName);

				params.put("upperTableName", upperTableName);
				params.put("lowerTableName", lowerTableName);
				params.put("camelTableName", camelTableName);
				params.put("camelTableFirstUpperName", camelTableFirstUpperName);
			}

			String methodName = StringUtils.defaultString((String) params.get("methodName"));
			params.put("methodName", methodName);

			String dbName = StringUtils.defaultString((String) params.get("dbName"));
			params.put("dbName", dbName);

			String desc = StringUtils.defaultString((String) params.get("desc"));
			params.put("desc", desc);

			String modelComment = StringUtils.defaultString((String) params.get("modelComment"));
			params.put("modelComment", modelComment);

			String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
			params.put("makeGetsetMethodYn", makeGetsetMethodYn);



			//------------  초기 param 설정 end --------------------------


			HashMap sqlMap = this.settingSqlBiz.makeSql(params);
			dataMap.put("sqlMap", sqlMap.get("sqlMap"));

//			HashMap dtoMap  = this.settingModelBiz.makeDto(params);
//			dataMap.put("dtoMap", dtoMap);

//			HashMap voMap  = this.settingModelBiz.makeVo(params);
//			dataMap.put("voMap", voMap);
//
//			//@Repository 객체
//			HashMap mapperMap  = this.settingBiz.makeMapper(params);
//			dataMap.put("mapperMap", mapperMap);
//
//			HashMap serviceImplMap  = this.settingServiceBiz.makeServiceImpl(params);
//			dataMap.put("serviceImplMap", serviceImplMap);

//			HashMap serviceMap  = this.settingServiceBiz.makeService(params);
//			dataMap.put("serviceMap", serviceMap);
//
//			HashMap apiMap  = this.settingApiBiz.makeApi(params);
//			dataMap.put("apiMap", apiMap);
//
//			HashMap validatorMap  = this.settingBiz.validator(params);
//			dataMap.put("validatorMap", validatorMap);
//
//			HashMap idgnMap  = this.settingIdgnBiz.makeIdgn(params);
//			dataMap.put("idgnMap", idgnMap);

//			HashMap transMap = this.settingTransBiz.makeTrans(params);
//			dataMap.put("transMap", transMap);

			resultMap.put("data", dataMap);
			resultMap.put("param", params);

			entity = new ResponseEntity(resultMap, HttpStatus.OK);
			logger.debug("source params : {}" , params);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			resultMap.put("error", e.getMessage());
			entity = new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return entity;
    }

//    @RequestMapping("/makeSetGet")
//    public ResponseEntity<HashMap> makeSetGet(@RequestParam HashMap params, Model model) throws Exception {
//    	HashMap resultMap = new HashMap();
//    	ResponseEntity entity = null;
//    	try {
//    		params.put("kind", "1");
//    		resultMap.put("data", this.settingBiz.makeSetGet(params));
//    		resultMap.put("param", params);
//    		entity = new ResponseEntity(resultMap, HttpStatus.OK);
//    		logger.debug("makeSetGet params : " + params);
//    	} catch (Exception e) {
//    		e.printStackTrace();
//    		logger.error(e.getMessage());
//    		resultMap.put("error", e.getMessage());
//    		entity = new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
//    	}
//    	return entity;
//    }

//    @RequestMapping("/makeSetGet2")
//    public ResponseEntity<HashMap> makeSetGet2(@RequestParam HashMap params, Model model) throws Exception {
//    	HashMap resultMap = new HashMap();
//    	ResponseEntity entity = null;
//    	try {
//    		params.put("kind", "2");
//    		resultMap.put("data", this.settingBiz.makeSetGet(params));
//    		resultMap.put("param", params);
//    		entity = new ResponseEntity(resultMap, HttpStatus.OK);
//    		logger.debug("makeSetGet2 params : " + params);
//    	} catch (Exception e) {
//    		e.printStackTrace();
//    		logger.error(e.getMessage());
//    		resultMap.put("error", e.getMessage());
//    		entity = new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
//    	}
//    	return entity;
//    }

}