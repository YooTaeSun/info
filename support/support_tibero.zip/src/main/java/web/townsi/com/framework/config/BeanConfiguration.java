package web.townsi.com.framework.config;

import java.io.IOException;
import java.util.LinkedHashMap;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import web.townsi.com.framework.fixed.AppConst;
import web.townsi.com.framework.listener.AppStartingEvent;
import web.townsi.com.utils.FileUtil;

@Configuration
public class BeanConfiguration {

	private Logger logger = LoggerFactory.getLogger(BeanConfiguration.class);

	@Bean
	public LinkedHashMap<String, String> propMap() throws IOException {

		if(StringUtils.isEmpty(AppConst.settingProp)) {
			AppStartingEvent.regiConstCopyPath();
		}

		LinkedHashMap<String, String> propMap = FileUtil.readFileMap(AppConst.settingProp);
		logger.debug("[LOADING_CHECK]  BeanConfiguration propMap ");
		return propMap;
	}

    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.configure(MapperFeature.DEFAULT_VIEW_INCLUSION, true);

        return mapper;
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}