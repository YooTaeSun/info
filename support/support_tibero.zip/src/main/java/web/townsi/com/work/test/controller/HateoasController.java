package web.townsi.com.work.test.controller;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping({ "/hateoas" })
public class HateoasController {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@GetMapping("/test")
	public Resource<HateoasVo> test() throws Exception {
		HateoasVo hateoasVo = new HateoasVo();
		hateoasVo.setPrefix("prefix,");
		hateoasVo.setName("Hong");
		
		Resource<HateoasVo> hateoasResource = new Resource<>(hateoasVo);
		hateoasResource.add(linkTo(methodOn(HateoasController.class).test()).withSelfRel());
		return hateoasResource;
	}
}