package web.townsi.com.framework.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class AppReadyEvent implements ApplicationListener<ApplicationReadyEvent> {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Override
	public void onApplicationEvent(ApplicationReadyEvent event) {
		logger.debug("[LOADING_CHECK]  ApplicationReadyEvent ");
	}
}
