package web.townsi.com.work.setting.biz.impl;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;
import web.townsi.com.utils.ListUtil;
import web.townsi.com.work.mapper.mysql.SettingMapperMysql;
import web.townsi.com.work.mapper.oracle.SettingMapperOracle;
import web.townsi.com.work.mapper.postgre.SettingMapperPostgre;
import web.townsi.com.work.setting.biz.SettingApiBiz;
import web.townsi.com.work.setting.biz.SettingBiz;

/**
* SettingServiceImpl
* @author 유태선
* @since 2016.10.14
* @version 1.0
* @see
* </pre>
*/
@SuppressWarnings({"rawtypes","unchecked","unused"})
@Service
public class SettingApiBizImpl implements SettingApiBiz {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private SettingBiz settingBiz;

	@Autowired
	private SettingMapperMysql settingMapperMysql;

	private SettingMapperPostgre settingMapperPostgre;

	private SettingMapperOracle settingMapperOracle;

	public static String READ_LINE = "\n";
	public static String TAB = "\t";
	public static String SLASH = File.separator;// lastIndexOf("/")

//	public static String replaceTxt  = "#txt#";
	public static String rTxt  = "#{txt}";

	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();


	public List<HashMap> selectTableList(HashMap params){

		List<HashMap>  list = null;
		String dbName = StringUtils.defaultString((String)params.get("dbName"));

		if("MY_SQL".equals(dbName)) {
		    list = settingMapperMysql.selectTableList(params);
		}else if("POSTGRESQL".equals(dbName)) {
			list = settingMapperPostgre.selectTableList(params);
		}else if("ORACLE".equals(dbName)) {
			list = settingMapperOracle.selectTableList(params);
		}

		return list;
	}

	public HashMap makeApi(HashMap params) throws Exception {

		HashMap dataMap = new HashMap();

		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String upperTableName = StringUtils.defaultString((String) params.get("upperTableName"));
		String lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		String camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		String camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String modelComment = StringUtils.defaultString((String) params.get("modelComment"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String group1 = StringUtils.defaultString((String) params.get("group1"));
		String author = StringUtils.defaultString((String) params.get("author"));
		String today = StringUtils.defaultString((String) params.get("today"));
		String current = StringUtils.defaultString((String) params.get("current"));
		String desc = StringUtils.defaultString((String) params.get("desc"));
		String path1 = StringUtils.defaultString((String) params.get("path1"));
		String path2 = StringUtils.defaultString((String) params.get("path2"));
		String path3 = StringUtils.defaultString("/" + (String) params.get("path3"), "/com/" + group);
		String menu = StringUtils.defaultString((String) params.get("menu"));
		String programId = StringUtils.defaultString((String) params.get("programId"));

		List<HashMap> list = settingBiz.selectTableInfo(params,
				  StringUtils.defaultString((String)params.get("dbName"))
				, StringUtils.defaultString((String)params.get("tableSchema"))
			    , StringUtils.defaultString((String)params.get("tableName"))
				);

		List<HashMap> pkList = list.stream().
				filter(map ->  {
					String pk = StringUtils.defaultString((String) map.get("pk"));
					String columnName = StringUtils.defaultString((String)map.get("column_name"));
					//PK이고 컬럼 이름 _ID 존재
					if(pk.equals("pk")){
						return true;
					}else {
						return false;
					}
				})
				.collect(Collectors.toList());

		HashMap replaceMap = new HashMap();

		if(!ListUtil.isEmpty(pkList)){
			//id 존재
			String pkJoinStr = "\""+ pkList.stream().map(o->o.get("column_name").toString()).collect(Collectors.joining("\",\"")) + "\"";
			String sortStr = "sort="+ pkList.stream().map(o->o.get("column_name").toString()).collect(Collectors.joining(",ASC&sort=")) + ",ASC";
			replaceMap.put("#pkJoinStr#",pkJoinStr);
			replaceMap.put("#sortStr#", sortStr);
		}else {
			replaceMap.put("#pkJoinStr#","");
			replaceMap.put("#sortStr#","");
		}

		replaceMap.put("#mainPath#","");

		//AppStartingEvent.java --> copyArray
		String rfullPath = SITE_WEB_ROOT + "/copy/SampleApi.java";
		String wfullPath = SITE_WEB_ROOT + "/new/"+camelTableFirstUpperName+"/controller/"+camelTableFirstUpperName+"Controller.java";

		replaceMap.put("#group#",group);
		replaceMap.put("#group1#",group1);
		replaceMap.put("#today#",today);
		replaceMap.put("#current#",current);
		replaceMap.put("#author#",author);
		replaceMap.put("#menu#",menu);
		replaceMap.put("#programId#",programId);
		replaceMap.put("#camelTableFirstUpperName#",camelTableFirstUpperName);
		replaceMap.put("#camelTableName#",camelTableName);
		replaceMap.put("#lowerTableName#",camelTableFirstUpperName.toLowerCase());
		replaceMap.put("#desc#",desc);
		replaceMap.put("#path1#",path1);
		replaceMap.put("#path2#",path2);
		replaceMap.put("#path3#",path3);

		String str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);
		dataMap.put("str", str);
		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}
}