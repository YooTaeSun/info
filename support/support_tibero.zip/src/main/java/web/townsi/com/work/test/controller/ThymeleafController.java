package web.townsi.com.work.test.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping({ "/thymeleaf" })
public class ThymeleafController {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());


	@RequestMapping("/hello")
	public String test(Model model) throws Exception {
		model.addAttribute("name", "townsi");
	    return "thymeleaf/hello";
	}

	@RequestMapping("/AdminLTE")
	public String Admin(Model model) throws Exception {
		return "redirect:/static/AdminLTE-3.0.2/index.html";
	}

}