package web.townsi.com.work.setting.biz.impl;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;
import web.townsi.com.work.mapper.mysql.SettingMapperMysql;
import web.townsi.com.work.mapper.postgre.SettingMapperPostgre;
import web.townsi.com.work.setting.biz.SettingBiz;
import web.townsi.com.work.setting.biz.SqlByMybaitisBiz;

/**
* @author 유태선
* @since 2016.10.14
* @version 1.0
* @see
* </pre>
*/
@SuppressWarnings({"rawtypes","unchecked","unused"})
@Service
public class SqlByMybaitisBizImpl implements SqlByMybaitisBiz {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private SettingBiz settingBiz;

	public static String LINE = "\n";
	public static String SPACE_CNT = "    ";
	public static String SLASH = File.separator;// lastIndexOf("/")

//	public static String replaceTxt  = "#txt#";
	public static String rTxt  = "#{txt}";
	public static  String WHERE_PARAM_PREFIX = "search";

	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();


	public HashMap makeSql(HashMap params) throws Exception {

		HashMap dataMap = new HashMap();

		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String tableSchema = StringUtils.defaultString((String) params.get("tableSchema"));
		String upperTableName = StringUtils.defaultString((String) params.get("upperTableName"));
		String lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		String camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		String camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String modelComment = StringUtils.defaultString((String) params.get("modelComment"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String group1 = StringUtils.defaultString((String) params.get("group1"));
		String author = StringUtils.defaultString((String) params.get("author"));
		String desc = StringUtils.defaultString((String) params.get("desc"));
		String today = StringUtils.defaultString((String) params.get("today"));
		String current = StringUtils.defaultString((String) params.get("current"));
		String menu = StringUtils.defaultString((String) params.get("menu"));
		String programId = StringUtils.defaultString((String) params.get("programId"));

		String ifcase = StringUtils.defaultString((String) params.get("ifcase"),"if_package");
		String whereParamPrefix = StringUtils.defaultString((String) params.get("whereParamPrefix"),"");
		String sqlComment = StringUtils.defaultString((String) params.get("sqlComment"),"N");

		StringBuilder whereSql = new StringBuilder(500);
		StringBuilder selectSql = new StringBuilder(500);
		StringBuilder insertSql = new StringBuilder(500);
		StringBuilder insertValSql = new StringBuilder(500);
		StringBuilder updateSql = new StringBuilder(500);
		StringBuilder merge_updateSql = new StringBuilder(500);
		StringBuilder merge_mysql_updateSql = new StringBuilder(500);

		String column_name = "";
		String column_comment = "";
		String camel_column_name = "";
		String columns = "";
		String pk = "";
		String orderByPK = "";
		String w_type = "";
		String pkStr = "";
		String comments = "";
		String dataType = "";

		boolean isRegId = false;
    	boolean isModId = false;

		HashMap replaceMap = new HashMap();
		replaceMap.put("#tableName#",camelTableFirstUpperName);

		List<HashMap> list = settingBiz.selectTableInfo(params,
				  StringUtils.defaultString((String)params.get("dbName"))
				, StringUtils.defaultString((String)params.get("tableSchema"))
			    , StringUtils.defaultString((String)params.get("tableName"))
				);

		if(list !=null && list.size() > 0 ) {

			whereSql.append("\t\t<trim prefix=\"WHERE\" prefixOverrides=\"AND\">" + "\n");
			updateSql.append("\t\t SET \n \t\t<trim  prefixOverrides=\",\">" + "\n");

			merge_updateSql.append("\t\t<trim prefix=\"WHERE\" prefixOverrides=\"AND\">" + "\n");
			String camelColumnFirstUpperName = "";
			String param_column_name = "";



			for (int i = 0; i < list.size(); i++) {
			    HashMap rs = list.get(i);
				column_name = (String) rs.get("column_name");
				column_comment = (String) rs.get("column_comment");
				camel_column_name = (String) rs.get("camel_column_name");
				columns = (String) rs.get("columns");
				comments = (String) rs.get("comments");
				w_type = (String) rs.get("w_type");
				dataType = (String) rs.get("data_type");
				camelColumnFirstUpperName = camel_column_name.substring(0,1).toUpperCase() + camel_column_name.substring(1);

				if(!whereParamPrefix.isEmpty()) {
					param_column_name = whereParamPrefix +  camelColumnFirstUpperName;
				}else {
					param_column_name = whereParamPrefix +  camel_column_name;
				}

				if(StringUtils.isEmpty(comments)) {
					comments = "";
				}else {
					comments = "/* "+comments + " */";
				}


				pk = StringUtils.defaultString((String) rs.get("pk")).toLowerCase();
				orderByPK = "";
				if("pk".equals(pk)) {
					pkStr = pkStr + " AND " + column_name + " = " + rTxt.replace("txt", camel_column_name);
					orderByPK += "," + column_name;
				}else {
					merge_updateSql.append("\t\t\t<isNotEmpty property=\""+camel_column_name+"\" prepend=\",\" removeFirstPrepend=\"true\">"+column_name+"= "+rTxt.replace("txt", camel_column_name)+"</isNotEmpty>"  + "\n");
				}

//				whereSql.append("\t\t\t<isNotEmpty property=\""+camel_column_name+"\" prepend=\"AND\">" + "\n");
//				whereSql.append("\t\t\t\tM1."+column_name+" = "+ rTxt.replace("txt", camel_column_name) + "\n");
//				whereSql.append("\t\t\t</isNotEmpty>" + "\n");

//				whereSql.append("\t\t\t<if property=\""+camel_column_name+"\">");
//				whereSql.append(""+column_name+" = "+ rTxt.replace("txt", camel_column_name));
//				whereSql.append("</if>");

				if(
						   camel_column_name.equals("regId")
						|| camel_column_name.equals("regDt")
						|| camel_column_name.equals("regId")
						|| camel_column_name.equals("regIp")
						|| camel_column_name.equals("modId")
						|| camel_column_name.equals("modDt")
						) {

				}else if(camel_column_name.toLowerCase().contains("Nm".toLowerCase())
						 || camel_column_name.toLowerCase().contains("desc".toLowerCase())) {

					if("if_package".equals(ifcase)) {//if test="@org.apache.commons.lang3

						whereSql.append("\t\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank("+param_column_name+")\">\n"
									  + "\t\t\t<![CDATA[ AND M1."+column_name+" LIKE CONCAT('%' , " + rTxt.replace("txt", param_column_name) +" , '%') ]]>\n"
									  + "\t\t</if>"  + "\n");
					}else if("if_package2".equals(ifcase)) {//if test="@org.apache.commons.lang3

						whereSql.append("\t\t<if test=\"!@idstrust.lsp.config.base.util.StringUtil@isEmpty("+param_column_name+")\">\n"
								+ "\t\t\tAND M1."+column_name+" = " + rTxt.replace("txt", param_column_name) +"\n"
								+ "\t\t</if>"  + "\n");

						whereSql.append("\t\t<if test=\"!@idstrust.lsp.config.base.util.StringUtil@isEmpty(like_"+param_column_name+")\">\n"
									  + "\t\t\tAND ( M1."+column_name+" LIKE CONCAT('%' , LOWER(" + rTxt.replace("txt", "like_"+ param_column_name) +") , '%') OR\n"
									  + "\t\t\t      M1."+column_name+" LIKE CONCAT('%' , UPPER(" + rTxt.replace("txt", "like_"+ param_column_name) +") , '%'))\n"
									  + "\t\t</if>"  + "\n");

					}else if("if".equals(ifcase)) {//if test="str != null and str != ''"

						whereSql.append("\t\t<if test=\""+param_column_name+" != null and "+ param_column_name +" != ''\">\n"
								      + "\t\t\t<![CDATA[ AND M1."+column_name+" LIKE CONCAT('%' , " + rTxt.replace("txt", param_column_name) +" , '%') ]]>\n"
									  + "\t\t</if>"  + "\n");
					}else if("isNotEmpty".equals(ifcase)) {//isNotEmpty
						whereSql.append("\t\t<isNotEmpty property=\""+param_column_name+"\">\n"
									  + "\t\t\t<![CDATA[ AND M1."+column_name+" LIKE CONCAT('%' , " + rTxt.replace("txt", param_column_name) +" , '%') ]]>\n"
									  + "\t\t</isNotEmpty>"  + "\n");
					}

				}else if(camel_column_name.toLowerCase().endsWith("StDt".toLowerCase())) {

					if("if_package".equals(ifcase)) {//if test="@org.apache.commons.lang3
						whereSql.append("\t\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank("+param_column_name+")\">\n"
									  + "\t\t\t<![CDATA[ AND M1."+column_name+" >= DATE_FORMAT( " + rTxt.replace("txt", param_column_name) +" , '%Y-%m-%d %H:%i:%S' )]]>/* yyyy-mm-dd hh:mm:ss(24h) */\n"
									  + "\t\t</if>"  + "\n");
					}else if("if_package2".equals(ifcase)) {//if test="@org.apache.commons.lang3
						whereSql.append("\t\t<if test=\"!@idstrust.lsp.config.base.util.StringUtil@isEmpty("+param_column_name+")\">\n"
								+ "\t\t\t<![CDATA[ AND M1."+column_name+" >= DATE_FORMAT( " + rTxt.replace("txt", param_column_name) +" , '%Y-%m-%d %H:%i:%S' )]]>/* yyyy-mm-dd hh:mm:ss(24h) */\n"
								      + "\t\t</if>"  + "\n");
					}else if("if".equals(ifcase)) {//if test="str != null and str != ''"
						whereSql.append("\t\t<if test=\""+param_column_name+" != null and "+ param_column_name +" != ''\">\n"
									  + "\t\t\t<![CDATA[ AND M1.\"+column_name+\" >= DATE_FORMAT( \" + rTxt.replace(\"txt\", \"search\" + camelColumnFirstUpperName) +\" , '%Y-%m-%d %H:%i:%S' )]]>/* yyyy-mm-dd hh:mm:ss(24h) */\n"
									  + "\t\t</if>"  + "\n");
					}else if("isNotEmpty".equals(ifcase)) {//isNotEmpty
						whereSql.append("\t\t<isNotEmpty property=\""+param_column_name+"\">\n"
									  + "\t\t\t<![CDATA[ AND M1.\"+column_name+\" >= DATE_FORMAT( \" + rTxt.replace(\"txt\", \"search\" + camelColumnFirstUpperName) +\" , '%Y-%m-%d %H:%i:%S' )]]>/* yyyy-mm-dd hh:mm:ss(24h) */\n"
									  + "\t\t</isNotEmpty>"  + "\n");
					}


				}else if(camel_column_name.toLowerCase().endsWith("EndDt".toLowerCase())) {

					if("if_package".equals(ifcase)) {//if test="@org.apache.commons.lang3
						whereSql.append("\t\t\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank("+param_column_name+")\">\n"
									  + "\t\t\t\t<![CDATA[ AND M1."+column_name+" <= DATE_FORMAT( " + rTxt.replace("txt", param_column_name) +" , '%Y-%m-%d %H:%i:%S' )]]>/* yyyy-mm-dd hh:mm:ss(24h) */\n"
									  + "\t\t\t</if>"  + "\n");
					}else if("if_package2".equals(ifcase)) {//if test="@org.apache.commons.lang3
						whereSql.append("\t\t<if test=\"!@idstrust.lsp.config.base.util.StringUtil@isEmpty("+param_column_name+")\">\n"
								      + "\t\t\tAND M1."+column_name+" <= DATE_FORMAT( " + rTxt.replace("txt", param_column_name) +" , '%Y-%m-%d %H:%i:%S' )]]>/* yyyy-mm-dd hh:mm:ss(24h) */\n"
								      + "\t\t</if>"  + "\n");
					}else if("if".equals(ifcase)) {//if test="str != null and str != ''"
						whereSql.append("\t\t<if test=\""+param_column_name+" != null and "+ param_column_name +" != ''\">\n"
									  + "\t\t\t<![CDATA[ AND M1."+column_name+" <= DATE_FORMAT( " + rTxt.replace("txt", param_column_name) +" , '%Y-%m-%d %H:%i:%S' )]]>/* yyyy-mm-dd hh:mm:ss(24h) */\n"
									  + "\t\t</if>"  + "\n");
					}else if("isNotEmpty".equals(ifcase)) {//isNotEmpty
						whereSql.append("\t\t<isNotEmpty property=\""+param_column_name+"\">\n"
									  + "\t\t\t<![CDATA[ AND M1."+column_name+" <= DATE_FORMAT( " + rTxt.replace("txt", param_column_name) +" , '%Y-%m-%d %H:%i:%S' )]]>/* yyyy-mm-dd hh:mm:ss(24h) */\n"
									  + "\t\t</isNotEmpty>"  + "\n");
					}


				}else if(camel_column_name.toLowerCase().equals("RegDt".toLowerCase())) {

//					whereSql.append("\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank(searchRegDt)\">\n\t\t<![CDATA[ AND M1."+column_name+"	LIKE CONCAT('%', #{searchRegDt},'%') ]]>\n\t</if>"  + "\n");
//					whereSql.append("\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank(searchRegDtStart)\">\n\t\t<![CDATA[ AND M1."+column_name+" >= DATE_FORMAT( #{searchRegDtStart}, '%Y-%m-%d %H:%i:%S' ) ]]>/* yyyy-mm-dd hh:mm:ss(24h) */\n\t</if>"  + "\n");
//					whereSql.append("\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank(searchRegDtEnd)\">\n\t\t<![CDATA[ AND M1."+column_name+" <= DATE_FORMAT( #{searchRegDtEnd}, '%Y-%m-%d %H:%i:%S' ) ]]>/* yyyy-mm-dd hh:mm:ss(24h) */\n\t</if>"  + "\n");

				}else {
					if(w_type.equals("Long") || w_type.equals("Integer") || w_type.equals("Float")) {

						if("if_package".equals(ifcase)) {//if test="@org.apache.commons.lang3
								whereSql.append("\t\t<if test=\"@org.apache.commons.lang3.math.NumberUtils@isCreatable("+param_column_name+")\">\n"
										      + "\t\t\t<![CDATA[ AND M1."+column_name+" = " + rTxt.replace("txt", param_column_name) +" ]]>\n"
										      + "\t\t</if>"  + "\n");
						}else if("if_package2".equals(ifcase)) {//if test="@org.apache.commons.lang3
							whereSql.append("\t\t<if test=\"!@idstrust.lsp.config.base.util.StringUtil@isEmpty("+param_column_name+")\">\n"
								          + "\t\t\tAND M1."+column_name+" = " + rTxt.replace("txt", param_column_name) +"\n"
								          + "\t\t</if>"  + "\n");
						}else if("if".equals(ifcase)) {//if test="str != null and str != ''"
							whereSql.append("\t\t<if test=\""+param_column_name+" != null and "+ param_column_name +" != ''\">\n"
										  + "\t\t\t<![CDATA[ AND M1."+column_name+" = " + rTxt.replace("txt", param_column_name) +" ]]>\n"
										  + "\t\t</if>"  + "\n");
						}else if("isNotEmpty".equals(ifcase)) {//isNotEmpty
							whereSql.append("\t\t<isNotEmpty property=\""+param_column_name+"\">\n"
										  + "\t\t\t<![CDATA[ AND M1."+column_name+" = " + rTxt.replace("txt", param_column_name) +" ]]>\n"
										  + "\t\t</isNotEmpty>"  + "\n");
						}



					}else {

						if("if_package".equals(ifcase)) {//if test="@org.apache.commons.lang3
							whereSql.append("\t\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank("+param_column_name+")\">\n"
									      + "\t\t\t<![CDATA[ AND M1."+column_name+" = " + rTxt.replace("txt", param_column_name) +" ]]>\n"
									      + "\t\t</if>"  + "\n");
						}else if("if_package2".equals(ifcase)) {//if test="@org.apache.commons.lang3
							whereSql.append("\t\t<if test=\"!@idstrust.lsp.config.base.util.StringUtil@isEmpty("+param_column_name+")\">\n"
								          + "\t\t\tAND M1."+column_name+" = " + rTxt.replace("txt", param_column_name) +"\n"
								          + "\t\t</if>"  + "\n");
						}else if("if".equals(ifcase)) {//if test="str != null and str != ''"
							whereSql.append("\t\t<if test=\""+param_column_name+" != null and "+ param_column_name +" != ''\">\n"
										  + "\t\t\t<![CDATA[ AND M1."+column_name+" = " + rTxt.replace("txt", param_column_name) +" ]]>\n"
										  + "\t\t</if>"  + "\n");
						}else if("isNotEmpty".equals(ifcase)) {//isNotEmpty
							whereSql.append("\t\t<isNotEmpty property=\""+param_column_name+"\">\n"
								          + "\t\t\t<![CDATA[ AND M1."+column_name+" = " + rTxt.replace("txt", param_column_name) +" ]]>\n"
										  + "\t\t</isNotEmpty>"  + "\n");
						}

					}
				}


				//selectSql
	            if(dataType.equals("date")) {

	            	if(sqlComment.equals("Y")) {
	            		selectSql.append("\t\t,CM.FN_DATE_FORMAT(M1." + column_name + ",#{dateType}) AS " + column_name + "\t/* " + column_comment +" */\n");
	            	}else {
	            		selectSql.append("\t\t,CM.FN_DATE_FORMAT(M1." + column_name + ",#{dateType}) AS " + column_name + "\n");
	            	}
	            }else if(dataType.equals("datetime")) {

	            	if(sqlComment.equals("Y")) {
	            		selectSql.append("\t\t,CM.FN_DATE_FORMAT(M1." + column_name + ",#{dateType}) AS " + column_name + "\t/* " + column_comment +" */\n");
	            	}else {
	            		selectSql.append("\t\t,CM.FN_DATE_FORMAT(M1." + column_name + ",#{dateType}) AS " + column_name + "\n");
	            	}
	            }else {
	            	if(sqlComment.equals("Y")) {
	            		selectSql.append("\t\t,M1." + column_name + "\t/* " + column_comment +" */\n");
	            	}else {
	            		selectSql.append("\t\t,M1." + column_name + "\n");
	            	}

	            	if("REG_ID".equals(column_name)) {
	            		isRegId = true;
	            	}else if("MOD_ID".equals(column_name)) {
	            		isModId = true;
	            	}
	            }


				insertSql.append("\t\t," + column_name + "\n");

				if(camel_column_name.toLowerCase().equals("regDt".toLowerCase())
				|| camel_column_name.toLowerCase().equals("modDt".toLowerCase())) {
					insertValSql.append("\t\t,CURRENT_TIMESTAMP()\n");

		        }else if(dataType.equals("date") && column_name.lastIndexOf("_DT") > -1) {
		        	insertValSql.append("\t\t," + "DATE_FORMAT(" + rTxt.replace("txt", camel_column_name)  + ",'%Y-%m-%d')\n");

		        }else if(dataType.equals("datetime") && column_name.lastIndexOf("_DT") > -1) {
		        	insertValSql.append("\t\t," + "DATE_FORMAT(" + rTxt.replace("txt", camel_column_name)  + ",'%Y-%m-%d %H:%i:%s')\n");

		        }else {
					insertValSql.append("\t\t," + rTxt.replace("txt", camel_column_name)  + "\n");
				}

//				updateSql.append("\t," + column_name + " = #" + camel_column_name + "#\t\t\t" + comments + "\n");
//				updateSql.append("\t\t\t<isNotEmpty property=\""+camel_column_name+"\" prepend=\",\" removeFirstPrepend=\"true\">"+column_name+"= " + rTxt.replace("txt", camel_column_name) +"</isNotEmpty>"  + "\n");

				if(!"pk".equals(pk)) {
					if(camel_column_name.toLowerCase().equals("modDt".toLowerCase()) ) {
						updateSql.append("\t\t\t, "+column_name+" = CURRENT_TIMESTAMP()" + "\n");
					}else if(camel_column_name.toLowerCase().equals("modId".toLowerCase())
							|| camel_column_name.toLowerCase().equals("modIp".toLowerCase())
							) {
						updateSql.append("\t\t\t, "+column_name+" = " + rTxt.replace("txt", camel_column_name) + "\n");
					}else if(camel_column_name.toLowerCase().equals("regId".toLowerCase())
							|| camel_column_name.toLowerCase().equals("regNm".toLowerCase())
							|| camel_column_name.toLowerCase().equals("regDt".toLowerCase())
							|| camel_column_name.toLowerCase().equals("regIp".toLowerCase())
							) {
							// skip column
					}else if(dataType.equals("date") && column_name.lastIndexOf("_DT") > -1) {

						if("if_package2".equals(ifcase)) {//if test="@org.apache.commons.lang3
							updateSql.append("\t\t\t<if test=\"!@idstrust.lsp.config.base.util.StringUtil@isEmpty("+camel_column_name+")\">, "+column_name+"= DATE_FORMAT(" +  rTxt.replace("txt", camel_column_name) + ",'%Y-%m-%d')</if>"  + "\n");
						}

			        }else if(dataType.equals("datetime") && column_name.lastIndexOf("_DT") > -1) {

			        	if("if_package2".equals(ifcase)) {//if test="@org.apache.commons.lang3
							updateSql.append("\t\t\t<if test=\"!@idstrust.lsp.config.base.util.StringUtil@isEmpty("+camel_column_name+")\">, "+column_name+"= DATE_FORMAT(" +  rTxt.replace("txt", camel_column_name) + ",'%Y-%m-%d %H:%i:%s')</if>"  + "\n");
						}

			        }else {

						if("if_package".equals(ifcase)) {//if test="@org.apache.commons.lang3

							updateSql.append("\t\t\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank("+camel_column_name+")\">, "+column_name+"= " + rTxt.replace("txt", camel_column_name) +"</if>"  + "\n");

						}else if("if_package2".equals(ifcase)) {//if test="@org.apache.commons.lang3
							updateSql.append("\t\t\t<if test=\"!@idstrust.lsp.config.base.util.StringUtil@isEmpty("+camel_column_name+")\">, "+column_name+"= " + rTxt.replace("txt", camel_column_name) +"</if>"  + "\n");
						}else if("if".equals(ifcase)) {//if test="str != null and str != ''"

							updateSql.append("\t\t\t<if test=\""+param_column_name+" != null and "+ param_column_name + " != ''\">, "+column_name+"= " + rTxt.replace("txt", camel_column_name) +"</if>"  + "\n");

						}else if("isNotEmpty".equals(ifcase)) {//isNotEmpty
							updateSql.append("\t\t\t<isNotEmpty property=\""+param_column_name+ "\">, "+column_name+"= " + rTxt.replace("txt", camel_column_name) +"</isNotEmpty>"  + "\n");
						}

					}
				}

//				merge_mysql_updateSql.append("\t\t\t<if test=\""+camel_column_name+" != null\">, "+column_name+"= " + rTxt.replace("txt", camel_column_name) +"</if>"  + "\n");

				if(!"pk".equals(pk)) {

					if(camel_column_name.toLowerCase().equals("modDt".toLowerCase()) ) {
						merge_mysql_updateSql.append("\t\t\t, "+column_name+" = CURRENT_TIMESTAMP()" + "\n");
					}else if(camel_column_name.toLowerCase().equals("modId".toLowerCase())
							|| camel_column_name.toLowerCase().equals("modIp".toLowerCase())
							) {
						merge_mysql_updateSql.append("\t\t\t, "+column_name+" = " + rTxt.replace("txt", camel_column_name) + "\n");
					}else if(camel_column_name.toLowerCase().equals("regId".toLowerCase())
							|| camel_column_name.toLowerCase().equals("regNm".toLowerCase())
							|| camel_column_name.toLowerCase().equals("regDt".toLowerCase())
							|| camel_column_name.toLowerCase().equals("regIp".toLowerCase())
							) {
							// skip column
					}else {

						if("if_package".equals(ifcase)) {//if test="@org.apache.commons.lang3

							merge_mysql_updateSql.append("\t\t\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank("+camel_column_name+")\">, "+column_name+"= " + rTxt.replace("txt", camel_column_name) +"</if>"  + "\n");

						}else if("if_package2".equals(ifcase)) {//if test="@org.apache.commons.lang3
							merge_mysql_updateSql.append("\t\t\t<if test=\"!@idstrust.lsp.config.base.util.StringUtil@isEmpty("+camel_column_name+")\">, "+column_name+"= " + rTxt.replace("txt", camel_column_name) +"</if>"  + "\n");
						}else if("if".equals(ifcase)) {//if test="str != null and str != ''"

							merge_mysql_updateSql.append("\t\t\t<if test=\""+param_column_name+" != null and "+ param_column_name + " != ''\">, "+column_name+"= " + rTxt.replace("txt", camel_column_name) +"</if>"  + "\n");

						}else if("isNotEmpty".equals(ifcase)) {//isNotEmpty
							merge_mysql_updateSql.append("\t\t\t<isNotEmpty property=\""+param_column_name+ "\">, "+column_name+"= " + rTxt.replace("txt", camel_column_name) +"</isNotEmpty>"  + "\n");
						}

					}
				}
			}

			whereSql.append("\t</trim>"  + "\n");
			merge_updateSql.append("\t\t</trim>");
		}

		if(pkStr.indexOf(" AND") == 0) {
			pkStr = pkStr.replaceFirst("AND ", "");
		}else{
			pkStr = " DUMMY = \"\"";
		}

		replaceMap.put("#camelTableName#",camelTableName);

		String where = whereSql.toString();
		replaceMap.put("#where#",where.replace("\t", SPACE_CNT).replace("\n", LINE));


		String pks = "";
		if(!StringUtils.isEmpty(orderByPK)) {
			pks = "\n\t\tORDER BY " + orderByPK.replaceFirst(",", "");
		}

		String joinU1 = "";
		String joinU2 = "";
		if(isRegId) {
			joinU1 = "\tLEFT OUTER JOIN CM.BS_USER U1 ON U1.BS_USER_PK  = M1.REG_ID" + "\n";
			selectSql.append("\t\t,U1.USER_ID    /* 등록자 ID */" + "\n");
			selectSql.append("\t\t,U1.USER_NM    /* 등록자 이름  */" + "\n");
		}

		if(isModId) {
			joinU2 = "\tLEFT OUTER JOIN CM.BS_USER U2 ON U2.BS_USER_PK  = M1.MOD_ID" + "\n";
			selectSql.append("\t\t,U2.USER_ID    /* 최종수정자 ID */" + "\n");
			selectSql.append("\t\t,U2.USER_NM    /* 최종수정자 이름  */" + "\n");
		}

		String select = "\tSELECT " + "\n" +
				selectSql.toString().replaceFirst(",", " ") + "\tFROM " + tableSchema + "." + upperTableName + " M1" + "\n" + joinU1 + joinU2 + "\t<include refid=\"where-list\"/>" + pks;
		replaceMap.put("#select#", select.replace("\t", SPACE_CNT));


		String selectCount = "\tSELECT " + "COUNT(*) FROM " + tableSchema + "."+upperTableName + " M1" + "\n" + "\t<include refid=\"where-list\"/>";
		replaceMap.put("#selectCount#", selectCount.replace("\t", SPACE_CNT));

		String infoSelect = "\tSELECT " + "\n" + selectSql.toString().replaceFirst(",", " ") + "\tFROM " + tableSchema + "." + upperTableName + " M1" + "\n" + joinU1 + joinU2 + "\t<include refid=\"where-list\"/>";
		replaceMap.put("#infoSelect#", infoSelect.replace("\t", SPACE_CNT));


		String insert = "\tINSERT INTO " + "\n"
		        + "\t\t" + tableSchema + "."+ upperTableName + " (\n" + insertSql.toString().replaceFirst(",", " ") + "\t\t)\n"
		        + " \t\tVALUES \n"
		        + "\t\t("
				+ "" + "\n" +insertValSql.toString().replaceFirst(",", " ") + "\t\t)";
		replaceMap.put("#insert#", insert.replace("\t", SPACE_CNT));


		String update = "\tUPDATE " + "\n"
				+ "\t\t" + tableSchema + "." + upperTableName + "\n" +updateSql.toString() + "\t\t</trim>\n\t\tWHERE" + pkStr;
		replaceMap.put("#update#", update.replace("\t", SPACE_CNT));

		String oracle_merge =    "\tMERGE INTO " + upperTableName + "\n"
						+ "\t\tUSING DUAL" + "\n"
					    + "\t\t\tON ("+pkStr.replaceFirst("AND ", "")+")" + "\n"
						+ "\t\tWHEN MATCHED THEN" + "\n"
						+ "\t\t\tUPDATE" + "\n"
						+ "" + merge_updateSql.toString() + "\n"
						+ "\t\tWHEN NOT MATCHED THEN" + "\n"
						+ "\t\t\tINSERT ("+ "\n"
						+ insertSql.toString().replaceFirst(",", " ")
						+ "\t\t) VALUES (" + "\n"
						+ insertValSql.toString().replaceFirst(",", " ").replace("\t", "\t\t")
						+ "\t\t)";

		String merge =  "\tINSERT INTO " + "\n"
					  + "\t\t" + tableSchema + "." + upperTableName + "(\n"
				      + insertSql.toString().replaceFirst(",", " ")
				      + "\t) VALUES (" + "\n"
				      + insertValSql.toString().replaceFirst(",", " ")
				      + "\t) ON DUPLICATE KEY UPDATE \n"
				      + "\t<trim  prefixOverrides=\",\"> \n"
				      +  merge_mysql_updateSql.toString().replace("\t\t", "\t")
				      + "\t</trim>";

		replaceMap.put("#merge#", merge.replace("\t", SPACE_CNT));

		replaceMap.put("#camelTableFirstUpperName#", camelTableFirstUpperName);
		replaceMap.put("#tableName#", camelTableFirstUpperName);
		replaceMap.put("#group#", group);
		replaceMap.put("#group#",group);
		replaceMap.put("#group1#", group1);
		replaceMap.put("#author#", author);
		replaceMap.put("#today#", today);
		replaceMap.put("#current#",current);
		replaceMap.put("#menu#",menu);
		replaceMap.put("#programId#",programId);

//		com.skt.poc.biz.component.code.model.dto.ComClassCodeDTO
		String pType = "com.skt.poc.biz.component."+group+".model.dto." + camelTableFirstUpperName + "DTO";
		replaceMap.put("#pType#", pType);

		String delete = "\tDELETE " + "FROM \n"
					  + "\t\t" + tableSchema + "." + upperTableName + "\n"
					  + "\t\tWHERE " + pkStr;

		replaceMap.put("#delete#", delete.replace("\t", SPACE_CNT));

		//AppStartingEvent.java --> copyArray
		String rfullPath = SITE_WEB_ROOT + "/copy/SampleSql.xml";
		String wfullPath = SITE_WEB_ROOT + "/new/"+camelTableFirstUpperName+"/"+camelTableFirstUpperName+"Mapper.xml";

		String str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);

		dataMap.put("str", str);
		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}

}