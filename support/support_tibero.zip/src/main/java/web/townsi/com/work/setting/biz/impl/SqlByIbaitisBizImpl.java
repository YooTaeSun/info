package web.townsi.com.work.setting.biz.impl;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;
import web.townsi.com.work.mapper.mysql.SettingMapperMysql;
import web.townsi.com.work.mapper.postgre.SettingMapperPostgre;
import web.townsi.com.work.setting.biz.SettingBiz;
import web.townsi.com.work.setting.biz.SqlByIbaitisBiz;

/**
* SettingServiceImpl
* @author 유태선
* @since 2016.10.14
* @version 1.0
* @see
* </pre>
*/
@SuppressWarnings({"rawtypes","unchecked","unused"})
@Service
public class SqlByIbaitisBizImpl implements SqlByIbaitisBiz {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private SettingBiz settingBiz;

	@Autowired
	private SettingMapperMysql settingMapperMysql;

	@Autowired
	private SettingMapperPostgre settingMapperByPostgre;

	public static String READ_LINE = "\n";
	public static String TAB = "\t";
	public static String SLASH = File.separator;// lastIndexOf("/")

//	public static String replaceTxt  = "#txt#";
	public static String rTxt  = "#txt#";

	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();


	public HashMap makeSql(HashMap params) throws Exception {

		HashMap dataMap = new HashMap();

		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String upperTableName = StringUtils.defaultString((String) params.get("upperTableName"));
		String lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		String camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		String camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String modelComment = StringUtils.defaultString((String) params.get("modelComment"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String group1 = StringUtils.defaultString((String) params.get("group1"));
		String programId = StringUtils.defaultString((String) params.get("programId"));
		String desc = StringUtils.defaultString((String) params.get("desc"));
		String tableSchema = StringUtils.defaultString((String) params.get("tableSchema"));
		String today = StringUtils.defaultString((String) params.get("today"));
		String current = StringUtils.defaultString((String) params.get("current"));
		String author = StringUtils.defaultString((String) params.get("author"));
		String menu = StringUtils.defaultString((String) params.get("menu"));
		String mapperNm = tableSchema + camelTableFirstUpperName;

		StringBuilder whereSql = new StringBuilder(500);
		StringBuilder selectSql = new StringBuilder(500);
		StringBuilder insertSql = new StringBuilder(500);
		StringBuilder insertValSql = new StringBuilder(500);
		StringBuilder updateSql = new StringBuilder(500);
		StringBuilder merge_updateSql = new StringBuilder(500);
		StringBuilder merge_mysql_updateSql = new StringBuilder(500);

		String column_name = "";
		String column_comment = "";
		String camel_column_name = "";
		String columns = "";
		String pk = "";
		String orderByPK = "";
		String w_type = "";
		String pkStr = "";
		String comments = "";

		HashMap replaceMap = new HashMap();
		replaceMap.put("#tableName#",tableName);
		replaceMap.put("#tableSchema#",tableSchema);
		replaceMap.put("#desc#",desc);
		replaceMap.put("#today#",today);
		replaceMap.put("#current#",current);
		replaceMap.put("#author#",author);
		replaceMap.put("#mapperNm#",mapperNm);

		List<HashMap> list = settingBiz.selectTableInfo(params,
				  StringUtils.defaultString((String)params.get("dbName"))
				, StringUtils.defaultString((String)params.get("tableSchema"))
			    , StringUtils.defaultString((String)params.get("tableName"))
				);

		if(list !=null && list.size() > 0 ) {

			whereSql.append("\tWHERE  1=1" + READ_LINE);
			updateSql.append("\t\t SET" + READ_LINE);

//			merge_updateSql.append("\t\t<trim prefix=\"WHERE\" prefixOverrides=\"AND\">" + READ_LINE);
			String camelColumnFirstUpperName = "";

			for (int i = 0; i < list.size(); i++) {
			    HashMap rs = list.get(i);
				column_name = (String) rs.get("column_name");
				column_comment = (String) rs.get("column_comment");
//				camel_column_name = (String) rs.get("camel_column_name");
				camel_column_name = column_name;
				columns = (String) rs.get("columns");
				comments = (String) rs.get("comments");
				w_type = (String) rs.get("w_type");
				camelColumnFirstUpperName = camel_column_name.substring(0,1).toUpperCase() + camel_column_name.substring(1);

				if(StringUtils.isEmpty(comments)) {
					comments = "";
				}else {
					comments = "/* "+comments + " */";
				}


				pk = StringUtils.defaultString((String) rs.get("pk")).toLowerCase();
				orderByPK = "";
				if("pk".equals(pk)) {
					pkStr = pkStr + " AND " + column_name + " = " + rTxt.replace("txt", camel_column_name);
					orderByPK += "," + column_name;
				}else {
					merge_updateSql.append("\t\t\t<isNotEmpty property=\""+camel_column_name+"\" prepend=\",\" removeFirstPrepend=\"true\">"+column_name+"= "+rTxt.replace("txt", camel_column_name)+"</isNotEmpty>"  + READ_LINE);
				}

//				whereSql.append("\t\t\t<isNotEmpty property=\""+camel_column_name+"\" prepend=\"AND\">" + READ_LINE);
//				whereSql.append("\t\t\t\tm1."+column_name+" = "+ rTxt.replace("txt", camel_column_name) + READ_LINE);
//				whereSql.append("\t\t\t</isNotEmpty>" + READ_LINE);

//				whereSql.append("\t\t\t<if property=\""+camel_column_name+"\">");
//				whereSql.append(""+column_name+" = "+ rTxt.replace("txt", camel_column_name));
//				whereSql.append("</if>");


				if(camel_column_name.toLowerCase().contains("Nm".toLowerCase()) || camel_column_name.toLowerCase().contains("desc".toLowerCase())) {
//					whereSql.append("\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank(search"+camelColumnFirstUpperName+")\">\n\t\t<![CDATA[ AND m1."+column_name+" LIKE CONCAT('%' , " + rTxt.replace("txt", "search" + camel_column_name) +" , '%') ]]>\n\t</if>"  + READ_LINE);
					whereSql.append("\t<isNotEmpty property=\""+column_name+"\" prepend=\"AND\"> m1."+column_name+"= #" + column_name +"# </isNotEmpty>"  + READ_LINE);

				}
//				else if(camel_column_name.toLowerCase().equals("reg_id".toLowerCase())
//						|| camel_column_name.toLowerCase().equals("reg_dati".toLowerCase())
//						|| camel_column_name.toLowerCase().equals("mod_id".toLowerCase())
//						|| camel_column_name.toLowerCase().equals("mod_dati".toLowerCase())
//						) {
//					// skip column
//
//				}
				else if(camel_column_name.toLowerCase().contains("Nm".toLowerCase()) || camel_column_name.toLowerCase().contains("desc".toLowerCase())) {
//					whereSql.append("\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank(search"+camelColumnFirstUpperName+")\">\n\t\t<![CDATA[ AND m1."+column_name+" LIKE CONCAT('%' , " + rTxt.replace("txt", "search" + camel_column_name) +" , '%') ]]>\n\t</if>"  + READ_LINE);
					whereSql.append("\t<isNotEmpty property=\""+column_name+"\" prepend=\"AND\"> tm1."+column_name+"= #" + column_name +"# </isNotEmpty>"  + READ_LINE);

				}else {
					if(w_type.equals("Long") || w_type.equals("Integer") || w_type.equals("Float")) {
//						whereSql.append("\t<if test=\"@org.apache.commons.lang3.math.NumberUtils@isCreatable(search"+camelColumnFirstUpperName+")\">\n\t\t<![CDATA[ AND m1."+column_name+" = " + rTxt.replace("txt", "search" + camelColumnFirstUpperName) +" ]]>\n\t</if>"  + READ_LINE);
						whereSql.append("\t<isNotEmpty property=\""+column_name+"\" prepend=\"AND\"> m1."+column_name+"= #" + column_name +"# </isNotEmpty>"  + READ_LINE);
					}else {
//						whereSql.append("\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank(search"+camelColumnFirstUpperName+")\">\n\t\t<![CDATA[ AND m1."+column_name+" = " + rTxt.replace("txt", "search" + camelColumnFirstUpperName) +" ]]>\n\t</if>"  + READ_LINE);
						whereSql.append("\t<isNotEmpty property=\""+column_name+"\" prepend=\"AND\"> m1."+column_name+"= #" + column_name +"# </isNotEmpty>"  + READ_LINE);
					}
				}

	            if(!w_type.equals("Date")) {
	            	selectSql.append("\t\t,m1." + column_name + READ_LINE);
	            }else {
	            	selectSql.append("\t\t,DATE_FORMAT(m1." + column_name + ",'%Y-%m-%d %H:%i:%s') AS " + column_name + READ_LINE);
	            }

//	            if((
//	                column_name.equals("UPD_SABUN") ||
//                    column_name.equals("UPD_DTM") ||
//                    column_name.equals("REG_SABUN") ||
//                    column_name.equals("REG_DTM") ||
//                    column_name.equals("DEL_YN")
//                    ) == false) {
//	              selectSql.append("\t\t\t," + column_name + READ_LINE);
//	            }


				if(camel_column_name.toLowerCase().equals("UpdId".toLowerCase())
					|| camel_column_name.toLowerCase().equals("UpdNm".toLowerCase())
					|| camel_column_name.toLowerCase().equals("UpdDt".toLowerCase())) {
					// skip column
				}else {
					insertSql.append("\t\t," + column_name + "\n");
				}

				if(camel_column_name.toLowerCase().equals("reg_dati".toLowerCase()) ) {
						insertValSql.append("\t\t,NOW()\n");
		            }else if(camel_column_name.toLowerCase().equals("RegId".toLowerCase())) {
		               insertValSql.append("\t\t,IFNULL( CASE #{sessionUserId} WHEN '' THEN NULL ELSE #{sessionUserId} END , IFNULL( CASE #{regId} WHEN '' THEN NULL ELSE #{regId} END , '__USER__' ) )\n");
				}else if(camel_column_name.toLowerCase().equals("mod_dati".toLowerCase())) {
					// skip column
					insertValSql.append("\t\t,NOW()\n");
				}else {
					insertValSql.append("\t\t," + rTxt.replace("txt", camel_column_name)  + "\n");
				}

//				updateSql.append("\t," + column_name + " = #" + camel_column_name + "#\t\t\t" + comments + READ_LINE);
//				updateSql.append("\t\t\t<isNotEmpty property=\""+camel_column_name+"\" prepend=\",\" removeFirstPrepend=\"true\">"+column_name+"= " + rTxt.replace("txt", camel_column_name) +"</isNotEmpty>"  + READ_LINE);

				if(!"pk".equals(pk)) {
					if(camel_column_name.toLowerCase().equals("mod_dati".toLowerCase()) ) {
						updateSql.append("\t\t\t, "+column_name+" = NOW()" + READ_LINE);
						}else if(camel_column_name.toLowerCase().equals("mod_id".toLowerCase())) {
			               updateSql.append("\t\t\t, "+column_name+" = #" + column_name + "#" + READ_LINE);
	//		            }else if(camel_column_name.toLowerCase().equals("updNm".toLowerCase())) {
	//					 수정해야 할 부분
	//					updateSql.append("\t\t\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank("+camel_column_name+")\">, "+column_name+"= " + rTxt.replace("txt", camel_column_name) +"</if>"  + READ_LINE);
					}else if(camel_column_name.toLowerCase().equals("reg_id".toLowerCase())
							|| camel_column_name.toLowerCase().equals("reg_dati".toLowerCase())) {
							// skip column
					}else {

//						updateSql.append("\t\t\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank("+camel_column_name+")\">, "+column_name+"= " + rTxt.replace("txt", camel_column_name) +"</if>"  + READ_LINE);
						updateSql.append("\t\t\t<isNotEmpty property=\"" +camel_column_name+"\">, "+column_name+"= " + rTxt.replace("txt", camel_column_name) +"</isNotEmpty>"  + READ_LINE);
					}
				}

//				merge_mysql_updateSql.append("\t\t\t<if test=\""+camel_column_name+" != null\">, "+column_name+"= " + rTxt.replace("txt", camel_column_name) +"</if>"  + READ_LINE);

				if(!"pk".equals(pk)) {
					if(camel_column_name.toLowerCase().equals("mod_dati".toLowerCase()) ) {
						merge_mysql_updateSql.append("\t\t\t, "+column_name+ " = NOW()" + READ_LINE);
					}else if(camel_column_name.toLowerCase().equals("UpdId".toLowerCase())) {
						merge_mysql_updateSql.append("\t\t\t, "+column_name+ " = IFNULL( CASE #{sessionUserId} WHEN '' THEN NULL ELSE #{sessionUserId} END , IFNULL( CASE #{updId} WHEN '' THEN NULL ELSE #{updId} END , '__USER__' ) )" + READ_LINE);
	//				}else if(camel_column_name.toLowerCase().equals("updNm".toLowerCase())) {
	//					 수정해야 할 부분
	//					merge_mysql_updateSql.append("\t\t\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank("+camel_column_name+")\">, "+column_name+"= " + rTxt.replace("txt", camel_column_name) +"</if>"  + READ_LINE);

					}else if(camel_column_name.toLowerCase().equals("reg_id".toLowerCase())
								|| camel_column_name.toLowerCase().equals("reg_dati".toLowerCase())) {
								// skip column

					}else {
						merge_mysql_updateSql.append("\t\t\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank("+camel_column_name+")\">, "+column_name+"= " + rTxt.replace("txt", camel_column_name) +"</if>"  + READ_LINE);
					}
				}
			}

//			whereSql.append("\t</trim>"  + READ_LINE);
//			merge_updateSql.append("\t\t</trim>");
		}

		if(pkStr.indexOf(" AND") == 0) {
			pkStr = pkStr.replaceFirst("AND ", "");
		}else{
			pkStr = " DUMMY = \"\"";
		}

		replaceMap.put("#camelTableName#",camelTableName);

		String where = whereSql.toString();
		replaceMap.put("#where#",where);


		String pks = "";
		if(!StringUtils.isEmpty(orderByPK)) {
			pks = "\n\t\tORDER BY " + orderByPK.replaceFirst(",", "");
		}

		String select = "\tSELECT " + READ_LINE + selectSql.toString().replaceFirst(",", " ") + "\tFROM " + tableSchema +"."+ tableName + " m1" + READ_LINE + "\t<include refid=\"where-list-"+mapperNm+"\"/>" + pks;
		replaceMap.put("#select#", select);


		String selectCount = "\tSELECT " + READ_LINE + "\t\tCOUNT(*) FROM " + tableSchema +"."+ tableName + " m1" + READ_LINE + "\t<include refid=\"where-list-"+mapperNm+"\"/>";
		replaceMap.put("#selectCount#", selectCount);

		String infoSelect = "\tSELECT " + READ_LINE + selectSql.toString().replaceFirst(",", " ") + "\tFROM " + tableSchema +"."+ tableName + " m1" + READ_LINE + "\tWHERE" + pkStr;
		replaceMap.put("#infoSelect#", infoSelect);


		String insert = "\tINSERT INTO " + tableSchema +"."+ tableName + " (\n" + insertSql.toString().replaceFirst(",", " ") + "\t) VALUES ("
				+ "" + READ_LINE +insertValSql.toString().replaceFirst(",", " ") + "\t)";
		replaceMap.put("#insert#", insert);


		String update = "\tUPDATE " + tableSchema +"."+ tableName + READ_LINE +updateSql.toString() + "\t\t\n\t\tWHERE" + pkStr;
		replaceMap.put("#update#", update);

		String oracle_merge =    "\tMERGE INTO " + tableSchema +"."+ tableName + READ_LINE
						+ "\t\tUSING DUAL" + READ_LINE
					    + "\t\t\tON ("+pkStr.replaceFirst("AND ", "")+")" + READ_LINE
						+ "\t\tWHEN MATCHED THEN" + READ_LINE
						+ "\t\t\tUPDATE" + READ_LINE
						+ "" + merge_updateSql.toString() + READ_LINE
						+ "\t\tWHEN NOT MATCHED THEN" + READ_LINE
						+ "\t\t\tINSERT ("+ READ_LINE
						+ insertSql.toString().replaceFirst(",", " ")
						+ "\t\t) VALUES (" + READ_LINE
						+ insertValSql.toString().replaceFirst(",", " ").replace("\t", "\t\t")
						+ "\t\t)";

		String merge =  "\tINSERT INTO " + tableSchema +"."+ tableName + "\n"
				+ insertSql.toString().replaceFirst(",", " ")
				+ "\t) VALUES (" + READ_LINE
				+ insertValSql.toString().replaceFirst(",", " ")
				+ "\t) ON DUPLICATE KEY UPDATE \n"
				+ "\t<trim  prefixOverrides=\",\"> \n"
				+  merge_mysql_updateSql.toString().replace("\t\t", "\t")
				+ "\t</trim> \n";
//		System.out.println("");
//		System.out.println(merge);
//		System.out.println("");
		replaceMap.put("#merge#", merge);
		replaceMap.put("#camelTableFirstUpperName#", camelTableFirstUpperName);
		replaceMap.put("#group#", group);
		replaceMap.put("#group1#", group1);
		replaceMap.put("#author#", author);
		replaceMap.put("#today#", today);
		replaceMap.put("#current#",current);
		replaceMap.put("#menu#",menu);
		replaceMap.put("#programId#",programId);

//		com.skt.poc.biz.component.code.model.dto.ComClassCodeDTO
		String pType = "com.skt.poc.biz.component."+group+".model.dto." + camelTableFirstUpperName + "DTO";
		replaceMap.put("#pType#", pType);

		String delete = "\tDELETE FROM " + tableSchema +"."+ tableName + " WHERE" + pkStr;
//					+ "\t<if test=\"@org.apache.commons.lang3.StringUtils@isBlank(delDataMngId)\">\n"
//					+ "\t\t"+pkStr+"\n"
//					+ "\t</if>\n"
//					+ "\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank(delDataMngId)\">\n"
//					+ "\t\t"+pkStr.split("=")[0]+ "\n"
//					+ "\t\t<if test=\"@org.apache.commons.lang3.StringUtils@isBlank(delDataMngIdList)\">\n"
//					+ "\t\t\t = #{delDataMngId}\n"
//					+ "\t\t</if>\n"
//					+ "\t\t<if test=\"@org.apache.commons.lang3.StringUtils@isNotBlank(delDataMngIdList)\">\n"
//					+ "\t\t\tIN\n"
//					+ "\t\t\t<foreach collection=\"delDataMngIdList\" item=\"delDataMngIds\" index=\"index\" open=\"(\" close=\")\" separator=\",\">\n"
//					+ "\t\t\t\t'\\${delDataMngIds}'\n"
//					+ "\t\t\t</foreach>\n"
//					+ "\t\t</if>\n"
//					+ "\t</if>";

		replaceMap.put("#delete#", delete);

		//AppStartingEvent.java --> copyArray
		String rfullPath = SITE_WEB_ROOT + "/copy/SampleSql.xml";
		String wfullPath = SITE_WEB_ROOT + "/new/" + tableSchema+"/"+ tableName +"/sql-"+ mapperNm + ".xml";


//		String wfullPath = SITE_WEB_ROOT + "/new/" + tableSchema + "/" +TableFirstName+"/"+camelTableFirstUpperName+"Mapper.xml";

		String str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);

		dataMap.put("str", str);
		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}


}