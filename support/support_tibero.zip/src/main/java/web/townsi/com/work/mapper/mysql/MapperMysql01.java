package web.townsi.com.work.mapper.mysql;


import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository
public class MapperMysql01 {

	@Autowired
	@Qualifier("sqlSessionMysql01")
	protected SqlSessionTemplate sqlSession;
}