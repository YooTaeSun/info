package web.townsi.com.work.setting.biz.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;
import web.townsi.com.utils.StrUtil;
import web.townsi.com.work.mapper.mysql.SettingMapperMysql;
import web.townsi.com.work.mapper.oracle.SettingMapperOracle;
import web.townsi.com.work.mapper.postgre.SettingMapperPostgre;
import web.townsi.com.work.setting.biz.SettingBiz;

/**
* SettingServiceImpl
* @author 유태선
* @since 2016.10.14
* @version 1.0
* @see
* </pre>
*/
@SuppressWarnings({"rawtypes","unchecked","unused"})
@Service
public class SettingBizImpl implements SettingBiz {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private SettingMapperMysql settingMapperMysql;

	@Autowired
	private SettingMapperPostgre settingMapperPostgre;

	@Autowired
	private SettingMapperOracle settingMapperOracle;

	public static String READ_LINE = "\n";
	public static String TAB = "\t";
	public static String SLASH = File.separator;// lastIndexOf("/")

//	public static String replaceTxt  = "#txt#";
	public static String rTxt  = "#{txt}";

	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();

	public List<HashMap> selectTableList(HashMap params){

		List<HashMap>  list = null;

		String dbName = StringUtils.defaultString((String)params.get("dbName"));

		if("MY_SQL".equals(dbName)) {
			list = settingMapperMysql.selectTableList(params);
		}else if("POSTGRESQL".equals(dbName)) {
			list = settingMapperPostgre.selectTableList(params);
		}else if("ORACLE".equals(dbName)) {
			list = settingMapperOracle.selectTableList(params);
		}

		return list;
	}



	@Override
//	@Cacheable(value="tableInfoCache", key = "{#dbName, #tableSchema, #tableName}")
	public List<HashMap> selectTableInfo(HashMap params, String dbName, String tableSchema, String tableName){

		List<HashMap>  list = null;

		if("MY_SQL".equals(dbName)) {
		    list = settingMapperMysql.selectTableInfo(params);
		}else if("POSTGRESQL".equals(dbName)) {
			list = settingMapperPostgre.selectTableInfo(params);
		}else if("ORACLE".equals(dbName)) {
			list = settingMapperOracle.selectTableInfo(params);
		}

	    String camelColumnName = "";

	    for (HashMap hashMap : list) {
	    	camelColumnName = StrUtil.toCamelCase((String)hashMap.get("camel_column_name"));
	    	hashMap.put("camel_column_name", camelColumnName);
	    	hashMap.put("camelColumnName", camelColumnName);
	    	hashMap.put("camelColumnFirstUpperName", camelColumnName.substring(0,1).toUpperCase() + camelColumnName.substring(1));
	    	hashMap.put("mem_vari", (String)hashMap.get("mem_vari") + " " + camelColumnName + ";");
	    	hashMap.put("set_get_column_name",  camelColumnName.substring(0,1).toUpperCase() + camelColumnName.substring(1));
	    }

		return list;
	}


	@Override
	public String takeComment(HashMap params) throws Exception {
		HashMap dataMap = new HashMap();

		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String dbName = StringUtils.defaultString((String) params.get("dbName"));

		params.put("tableName", tableName);

		String comment = "";

		if("MY_SQL".equals(dbName)) {
			comment = settingMapperMysql.selectTableComment(params);
		}else if("POSTGRESQL".equals(dbName)) {
			comment = settingMapperPostgre.selectTableComment(params);
		}else if("ORACLE".equals(dbName)) {
			comment = settingMapperOracle.selectTableComment(params);
		}


		return comment;
	}


	public HashMap makeMapper(HashMap params) throws Exception {

		HashMap dataMap = new HashMap();

		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String upperTableName = StringUtils.defaultString((String) params.get("upperTableName"));
		String lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		String camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		String camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String modelComment = StringUtils.defaultString((String) params.get("modelComment"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String group1 = StringUtils.defaultString((String) params.get("group1"));
		String today = StringUtils.defaultString((String) params.get("today"));
		String current = StringUtils.defaultString((String) params.get("current"));
		String author = StringUtils.defaultString((String) params.get("author"));
		String menu = StringUtils.defaultString((String) params.get("menu"));
		String programId = StringUtils.defaultString((String) params.get("programId"));
		String desc = StringUtils.defaultString((String) params.get("desc"));

		//AppStartingEvent.java --> copyArray
		String rfullPath = SITE_WEB_ROOT + "/copy/SampleMapper.java";
		String wfullPath = SITE_WEB_ROOT + "/new/"+camelTableFirstUpperName+"/mapper/"+camelTableFirstUpperName+"Mapper.java";

		HashMap replaceMap = new HashMap();
		replaceMap.put("#group#",group);
		replaceMap.put("#group1#",group1);
		replaceMap.put("#today#",today);
		replaceMap.put("#current#",current);
		replaceMap.put("#author#",author);
		replaceMap.put("#menu#",menu);
		replaceMap.put("#programId#",programId);
		replaceMap.put("#desc#",desc);
		replaceMap.put("#camelTableFirstUpperName#",camelTableFirstUpperName);
		replaceMap.put("#camelTableName#",camelTableName);

		String str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);
		dataMap.put("str", str);
		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}


	public HashMap makeApi(HashMap params) throws Exception {

		HashMap dataMap = new HashMap();

		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String upperTableName = StringUtils.defaultString((String) params.get("upperTableName"));
		String lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		String camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		String camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String modelComment = StringUtils.defaultString((String) params.get("modelComment"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String group1 = StringUtils.defaultString((String) params.get("group1"));
		String today = StringUtils.defaultString((String) params.get("today"));
		String current = StringUtils.defaultString((String) params.get("current"));
		String author = StringUtils.defaultString((String) params.get("author"));
		String desc = StringUtils.defaultString((String) params.get("desc"));

		//AppStartingEvent.java --> copyArray
		String rfullPath = SITE_WEB_ROOT + "/copy/SampleApi.java";
		String wfullPath = SITE_WEB_ROOT + "/new/"+camelTableFirstUpperName+"/api/"+camelTableFirstUpperName+"API.java";

		HashMap replaceMap = new HashMap();
		replaceMap.put("#group#",group);
		replaceMap.put("#group1#",group1);
		replaceMap.put("#today#",today);
		replaceMap.put("#current#",current);
		replaceMap.put("#author#",author);
		replaceMap.put("#camelTableFirstUpperName#",camelTableFirstUpperName);
		replaceMap.put("#camelTableName#",camelTableName);
		replaceMap.put("#lowerTableName#",camelTableFirstUpperName.toLowerCase());
		replaceMap.put("#desc#",desc);

		String str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);
		dataMap.put("mapperStr", str);
		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}

	public HashMap validator(HashMap params) throws Exception {

		HashMap dataMap = new HashMap();

		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String upperTableName = StringUtils.defaultString((String) params.get("upperTableName"));
		String lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		String camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		String camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String modelComment = StringUtils.defaultString((String) params.get("modelComment"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String desc = StringUtils.defaultString((String) params.get("desc"));

		HashMap replaceMap = new HashMap();
		replaceMap.put("#group#",group);
		replaceMap.put("#camelTableFirstUpperName#",camelTableFirstUpperName);
		replaceMap.put("#camelTableName#",camelTableName);
		replaceMap.put("#lowerTableName#",camelTableFirstUpperName.toLowerCase());
		replaceMap.put("#desc#",desc);

		//AppStartingEvent.java --> copyArray
		String rfullPath = SITE_WEB_ROOT + "/copy/SampleValidator.java";
		String wfullPath = SITE_WEB_ROOT + "/new/"+camelTableFirstUpperName+"/model/vo/"+camelTableFirstUpperName+"Validator.java";

		String str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);
		dataMap.put("str", str);
		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}


	@Override
	public HashMap<String, Object> makeSetGet(HashMap params) throws Exception {
		HashMap dataMap = new HashMap();

		try {
			HashMap setGetMap = makeSetGetExcute(params);
			dataMap.put("setGetMap", setGetMap);
		} catch (Exception e) {e.printStackTrace();}

		return dataMap;
	}


	public HashMap makeSetGetExcute(HashMap params) throws Exception {
		HashMap dataMap = new HashMap();

		String kind = StringUtils.defaultString((String) params.get("kind"));
		String infoSubKind = StringUtils.defaultString((String) params.get("infoSubKind"));
		String infoSubKind2 = StringUtils.defaultString((String) params.get("infoSubKind2"));
		String onTableName = "";
		String offTableName = "";
		List<HashMap> onlist = null;
		List<HashMap> offlist = null;
		List<HashMap> comlist = new ArrayList<HashMap>();

		String onVoName = "";
		String offVoName = "";

		if(kind.equals("1") && !infoSubKind2.contains(",")) {
			throw new Exception("no table name");
		}else {

			if(kind.equals("1")) {
				String[] tarray = infoSubKind2.split(",");
				onTableName = tarray[0];
				offTableName = tarray[1];
			}else {
				onTableName = StringUtils.defaultString((String) params.get("onTableName"));
				offTableName = StringUtils.defaultString((String) params.get("offTableName"));
			}

			if(onTableName.startsWith("TB_")) {
//				onVoName = StrUtil.toCamelCase(onTableName.replaceFirst("T_", "")) +  "VO";
				onVoName = StrUtil.toCamelCase(onTableName.replaceFirst("TB_", "")) +  "";
			}
//			offVoName = StrUtil.toCamelCase(offTableName) +  "VO";
			offVoName = StrUtil.toCamelCase(offTableName) +  "";





			params.put("tableName",onTableName);
			onlist = this.selectTableInfo(params,
					  StringUtils.defaultString((String)params.get("dbName"))
					, StringUtils.defaultString((String)params.get("tableSchema"))
				    , StringUtils.defaultString((String)params.get("tableName"))
					);

			params.put("tableName",offTableName);
			try {
				offlist = this.selectTableInfo(params,
						  StringUtils.defaultString((String)params.get("dbName"))
							, StringUtils.defaultString((String)params.get("tableSchema"))
						    , StringUtils.defaultString((String)params.get("tableName"))
							);
			} catch (Exception e) {
				// TODO: handle exception
			}


			HashMap replaceMap = new HashMap();
			StringBuilder dtoMemer = new StringBuilder(500);
			StringBuilder dtoMethod = new StringBuilder(500);

			String column_name = "";
			String COMMENTS = "";
			String mem_vari = "";
			String column_comment = "";
			String OFF_COLUMN_NAME = "";
			String camel_column_name = "";
			String set_get_column_name = "";
			String w_type = "";
			String tableName = StringUtils.defaultString((String) params.get("tableName"));
			String upperTableName = "";
			String lowerTableName = "";
			String camelTableName = "";

			if(!StringUtils.isEmpty(tableName)) {
				upperTableName = tableName.toUpperCase();
				lowerTableName = tableName.toLowerCase();
				camelTableName = StrUtil.toCamelCase(upperTableName);
			}


			HashMap onRs = null;
			HashMap offRs = null;
			boolean isPass = Boolean.FALSE;

			for (int i = 0; i < onlist.size(); i++) {
				onRs = onlist.get(i);
				column_name = (String) onRs.get("column_name");

				if(offlist != null && offlist.size() > 0) {
					for (int j = 0; j < offlist.size(); j++) {
						offRs = offlist.get(j);
						OFF_COLUMN_NAME = (String) offRs.get("column_name");
						if(column_name.equals(OFF_COLUMN_NAME)) {

							comlist.add((HashMap)onRs.clone());

							if(offlist.get(j).equals(onlist.get(i))) {
								offlist.remove(j);
							}else {
								offlist.remove(j);
								onlist.remove(i);
							}
							j--;
							i--;
							break;
						}
					}
				}
			}

			HashMap rs = null;

			String onVoNameFirstUpper = "";
			if(!"".equals(onVoName)) {
				onVoNameFirstUpper = onVoName.substring(0,1).toUpperCase() + onVoName.substring(1);
			}
			String offVoNameFirstlower = "";
			String offVoNameFirstUpper = "";
			if(!"".equals(offVoName)) {
				offVoNameFirstlower = offVoName.substring(0,1).toLowerCase() + offVoName.substring(1);
				offVoNameFirstUpper = offVoName.substring(0,1).toUpperCase() + offVoName.substring(1);
			}


			if(onlist != null && onlist.size() > 0) {
				dtoMethod.append(READ_LINE);
				dtoMethod.append("//------------------------" + onTableName + " 에만 존재  ---------------------" + READ_LINE);
				for (int i = 0; i < onlist.size(); i++) {
					rs = onlist.get(i);
					set_get_column_name = (String) rs.get("set_get_column_name");
					column_name = (String) rs.get("column_name");
					COMMENTS = (String) rs.get("COMMENTS");
					if(StringUtils.isEmpty(COMMENTS)) {
						COMMENTS = "";
					}else {
						COMMENTS = "/* "+COMMENTS + " */";
					}

//					System.out.println("onlist column_name >> " + column_name);
					dtoMethod.append("\tvo.set" + set_get_column_name + "(iVo.get" + set_get_column_name + "());\t" + COMMENTS + READ_LINE);
				}
			}

			if(comlist != null && comlist.size() > 0) {
				dtoMethod.append(READ_LINE);
				dtoMethod.append("//------------------------"+onTableName+", "+ offTableName+" 에만 같이  존재  ---------------------" + READ_LINE);
				for (int i = 0; i < comlist.size(); i++) {
					rs = comlist.get(i);
					set_get_column_name = (String) rs.get("set_get_column_name");
					column_name = (String) rs.get("column_name");
					COMMENTS = (String) rs.get("COMMENTS");
					if(StringUtils.isEmpty(COMMENTS)) {
						COMMENTS = "";
					}else {
						COMMENTS = "/* "+COMMENTS + " */";
					}

//					System.out.println("comlist column_name >> " + column_name);
					dtoMethod.append("\t"+offVoNameFirstlower+".set" + set_get_column_name + "(iVo.get" + set_get_column_name + "());\t" + COMMENTS + READ_LINE);
				}
			}

			if(offlist != null && offlist.size() > 0) {
				dtoMethod.append(READ_LINE);
				dtoMethod.append("//------------------------" + offTableName + " 에만 존재  ---------------------" + READ_LINE);
				for (int i = 0; i < offlist.size(); i++) {
					rs = offlist.get(i);
					set_get_column_name = (String) rs.get("set_get_column_name");
					column_name = (String) rs.get("column_name");
					COMMENTS = (String) rs.get("COMMENTS");
					if(StringUtils.isEmpty(COMMENTS)) {
						COMMENTS = "";
					}else {
						COMMENTS = "/* "+COMMENTS + " */";
					}

//					System.out.println("offlist column_name >> " + column_name);
					dtoMethod.append("\t"+offVoNameFirstlower+".set" + set_get_column_name + "(iVo.get" + set_get_column_name + "());\t" + COMMENTS + READ_LINE);
				}
			}

			String dtoContent = dtoMethod.toString();
//			System.out.println(dtoContent);

			String wfullPath = SITE_WEB_ROOT + "/pages/sample/new/SETGET.java";
			FileUtil.writeFile(dtoContent, wfullPath, replaceMap);
			dataMap.put("seM1", dtoContent);
			dataMap.put("fullPath", wfullPath);
		}
		return dataMap;
	}



	public HashMap makeJson(HashMap params) throws Exception {

	  StringBuilder selectSql = new StringBuilder(500);

	  HashMap dataMap = new HashMap();
	  HashMap replaceMap = new HashMap();

	  String column_name = "";
	  String column_comment = "";
	  String camel_column_name = "";
	  String COLUMNS = "";
	  String pk = "";
	  String COMMENTS = "";
	  String tableName = StringUtils.defaultString((String) params.get("tableName"));
	  String upperTableName = "";
	  String lowerTableName = "";
	  String camelTableName = "";
	  String camelTableFirstUpperName = "";
	  if(!StringUtils.isEmpty(tableName)) {
	    upperTableName = tableName.toUpperCase();
	    lowerTableName = tableName.toLowerCase();
	    camelTableName = StrUtil.toCamelCase(upperTableName);
	    if(upperTableName.startsWith("T_")) {
	      camelTableName = StrUtil.toCamelCase(upperTableName.replaceFirst("T_", ""));
	      camelTableFirstUpperName = camelTableName.substring(0,1).toUpperCase() + camelTableName.substring(1);
	    }
	  }

	  HashMap replaceMapperMap = new HashMap();
	  replaceMapperMap.put("#tableName#",camelTableFirstUpperName);

	  List<HashMap> list = this.selectTableInfo(params,
			  StringUtils.defaultString((String)params.get("dbName"))
			, StringUtils.defaultString((String)params.get("tableSchema"))
		    , StringUtils.defaultString((String)params.get("tableName"))
			);

	  String str = "";
	  if(list !=null && list.size() > 0 ) {

	    selectSql.append("{" + READ_LINE);

	    for (HashMap rs : list) {
	      column_name = (String) rs.get("column_name");
	      column_comment = (String) rs.get("column_comment");
	      camel_column_name = (String) rs.get("camel_column_name");
	      COLUMNS = (String) rs.get("COLUMNS");
	      COMMENTS = (String) rs.get("COMMENTS");

	      selectSql.append("\t\"" +camel_column_name+ "\" : \"\"," + READ_LINE);
//	      selectSql.append(",\"" +camel_column_name+ "\" : \"\"" + " /* "+COMMENTS + " */" + READ_LINE);
	    }
	    str = selectSql.toString();
	    str = str.substring(0,str.length()-2) + "\n}";
	  }

	  String wfullPath = SITE_WEB_ROOT + "/pages/sample/source/json/"+upperTableName+".json";

	  String sqlStr = FileUtil.writeFile(wfullPath, str);
	  System.out.println(sqlStr);

	  dataMap.put("str", sqlStr);
	  dataMap.put("fullPath", wfullPath);
	  return dataMap;
	}
}