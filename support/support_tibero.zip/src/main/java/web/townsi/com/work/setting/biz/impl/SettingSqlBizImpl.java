package web.townsi.com.work.setting.biz.impl;

import java.io.File;
import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.work.mapper.mysql.SettingMapperMysql;
import web.townsi.com.work.mapper.postgre.SettingMapperPostgre;
import web.townsi.com.work.setting.biz.SettingBiz;
import web.townsi.com.work.setting.biz.SettingSqlBiz;
import web.townsi.com.work.setting.biz.SqlByIbaitisBiz;
import web.townsi.com.work.setting.biz.SqlByMybaitisBiz;

/**
* SettingServiceImpl
* @author 유태선
* @since 2016.10.14
* @version 1.0
* @see
* </pre>
*/
@SuppressWarnings({"rawtypes","unchecked","unused"})
@Service
public class SettingSqlBizImpl implements SettingSqlBiz {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private SettingBiz settingBiz;

	@Autowired
	private SqlByMybaitisBiz sqlByMybaitisBiz;

	@Autowired
	private SqlByIbaitisBiz sqlByIbaitisBiz;

	@Autowired
	private SettingMapperMysql settingMapperMysql;

	@Autowired
	private SettingMapperPostgre settingMapperByPostgre;

	public static String READ_LINE = "\n";
	public static String TAB = "\t";
	public static String SLASH = File.separator;// lastIndexOf("/")

//	public static String replaceTxt  = "#txt#";
	public static String rTxt  = "#{txt}";

	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();

	@Override
	public HashMap<String, Object> makeSql(HashMap params) throws Exception {
		HashMap dataMap = new HashMap();
		String mapperKind = StringUtils.defaultString((String) params.get("mapperKind"));

		try {
			  HashMap sqlMap = null;
			  if("IBAITIS".equals(mapperKind)) {
				  sqlMap = sqlByIbaitisBiz.makeSql(params);
			  }else if("MYBAITIS".equals(mapperKind)) {
				  sqlMap = sqlByMybaitisBiz.makeSql(params);
			  }

			  dataMap.put("sqlMap", sqlMap);
			} catch (Exception e) {
				e.printStackTrace();
			}

		return dataMap;
	}
}