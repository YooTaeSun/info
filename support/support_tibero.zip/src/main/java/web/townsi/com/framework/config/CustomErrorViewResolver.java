package web.townsi.com.framework.config;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorViewResolver;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.ModelAndView;

@Configuration
public class CustomErrorViewResolver implements ErrorViewResolver {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public ModelAndView resolveErrorView(HttpServletRequest request, HttpStatus status, Map<String, Object> model) {

//		logger.debug("{} request param {}","CustomErrorViewResolver", request);
//		logger.debug("{} status param {}","CustomErrorViewResolver", status);
//		logger.debug("{} model param {}","CustomErrorViewResolver", model);

		logger.debug("{} model error {}","CustomErrorViewResolver", model.get("error"));
		logger.debug("{} model status {}","CustomErrorViewResolver", model.get("status"));
		logger.debug("{} model message {}","CustomErrorViewResolver", model.get("message"));
        return new ModelAndView("/static/AdminLTE-3.0.2/5xx.html");
	}

}