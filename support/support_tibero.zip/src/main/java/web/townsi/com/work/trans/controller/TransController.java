package web.townsi.com.work.trans.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.StrUtil;
import web.townsi.com.work.trans.biz.TransBiz;

@Controller
@RequestMapping({ "/trans" })
@SuppressWarnings({"rawtypes","unchecked"})
public class TransController {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private LinkedHashMap<String, String> propMap;

	@Autowired
	private TransBiz transBiz;

	final static String SITE_WEB_ROOT_PATH = Const.Path.SITE_WEB_ROOT.getValue();


	@RequestMapping({ "/main" })
	public String main(@RequestParam HashMap params, Model model) throws Exception {
		return "trans/main";
	}
	
    @RequestMapping("/make")
    public ResponseEntity<HashMap> source(@RequestParam HashMap params, Model model) throws Exception {
    	HashMap resultMap = new HashMap();
    	ResponseEntity entity = null;
		try {

			HashMap dataMap = new HashMap();

			//------------  초기 param 설정 start --------------------------
			String group = StringUtils.defaultString((String) params.get("group")).toLowerCase();
			params.put("group", group);
			String group1 = StringUtils.defaultString((String) params.get("group1")).toLowerCase();
			params.put("group1", group1);

			String tableName = StringUtils.defaultString((String) params.get("tableName"));

			Date today = new Date();
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy.MM.dd");
			SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
			params.put("today", simpleDateFormat.format(today));
			params.put("current", simpleDateFormat1.format(today));

			String upperTableName = "";
			String lowerTableName = "";
			String camelTableName = "";
			String camelTableFirstUpperName = "";
			String pk = "";

			if(!StringUtils.isEmpty(tableName)) {
				upperTableName = tableName.toUpperCase();
				lowerTableName = tableName.toLowerCase();
				camelTableName = StrUtil.toCamelCase(upperTableName);
				camelTableFirstUpperName = StrUtil.toCamelCaseFirstUpper(upperTableName);

				params.put("upperTableName", upperTableName);
				params.put("lowerTableName", lowerTableName);
				params.put("camelTableName", camelTableName);
				params.put("camelTableFirstUpperName", camelTableFirstUpperName);
			}

			String methodName = StringUtils.defaultString((String) params.get("methodName"));
			params.put("methodName", methodName);

			String dbName = StringUtils.defaultString((String) params.get("dbName"));
			params.put("dbName", dbName);

			String desc = StringUtils.defaultString((String) params.get("desc"));
			params.put("desc", desc);

			//------------  초기 param 설정 end --------------------------


			HashMap sqlMap = this.transBiz.makeTrans(params);
			dataMap.put("sqlMap", sqlMap.get("sqlMap"));


			resultMap.put("data", dataMap);
			resultMap.put("param", params);

			entity = new ResponseEntity(resultMap, HttpStatus.OK);
			logger.debug("source params : {}" , params);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			resultMap.put("error", e.getMessage());
			entity = new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return entity;
    }	
}