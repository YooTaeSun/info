package web.townsi.com.work.test.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping({ "/cors" })
public class CorsController {

	private Logger logger = LoggerFactory.getLogger(CorsController.class);

	@RequestMapping("/test")
	@CrossOrigin(origins = {"http://www.townsi.com"})
	public String test(Model model) throws Exception {
	    return "thymeleaf/hello";
	}

}