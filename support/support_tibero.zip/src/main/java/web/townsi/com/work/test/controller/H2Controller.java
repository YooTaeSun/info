package web.townsi.com.work.test.controller;

import java.sql.Connection;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping({ "/h2" })
public class H2Controller {

	private Logger logger = LoggerFactory.getLogger(H2Controller.class);

	@Autowired
	@Qualifier("dataSourceH2")
	DataSource dataSource;
	
	@RequestMapping("/test")
	public String test(Model model) throws Exception {
		model.addAttribute("name", "townsi");
		
		Connection connetion =  dataSource.getConnection();
		String url = connetion.getMetaData().getURL();
		String userName = connetion.getMetaData().getUserName();
		
		logger.debug("url : {}", url); 
		logger.debug("userName : {}", userName); 
		
	    return "thymeleaf/hello";
	}

}