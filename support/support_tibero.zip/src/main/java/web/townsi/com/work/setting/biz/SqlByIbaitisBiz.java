package web.townsi.com.work.setting.biz;

import java.util.HashMap;

public interface SqlByIbaitisBiz {
	public abstract HashMap makeSql(HashMap params) throws Exception;
}