package web.townsi.com.work.mapper.oracle;


import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public class SettingMapperOracle extends MapperOracle01{

	private final static String NAMESPACE = "web.townsi.com.work.mapper.oracle.SettingMapperOracle.";

    public Object insert(String queryId, Object params) {
    	return sqlSession.insert(NAMESPACE + queryId, params);
    }

    public Object update(String queryId, Object params) {
    	return sqlSession.update(NAMESPACE + queryId, params);
    }

    public Object delete(String queryId, Object params) {
    	return sqlSession.delete(NAMESPACE + queryId, params);
    }

	public List selectList(String queryId, Object params) {
		return sqlSession.selectList(NAMESPACE + queryId, params);
	}

	public Object selectOne(String queryId, Object params) {
		return sqlSession.selectOne(NAMESPACE + queryId, params);
	}

	public List<HashMap> selectTableInfo(HashMap params){

		try {
		Connection con =  sqlSession.getConnection();
			System.out.println(
					" url >> "  + con.getMetaData().getURL() +
					"\n  getUserName >> "  + con.getMetaData().getUserName()
					);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return sqlSession.selectList(NAMESPACE + "selectTableInfo", params);
	}

	public List<HashMap> selectTableList(HashMap params){
		return sqlSession.selectList(NAMESPACE + "selectTableList", params);
	}

	public List<HashMap> selectSqlInfo(HashMap params){
		return sqlSession.selectList(NAMESPACE + "selectSqlInfo", params);
	}

	public String selectTableComment(HashMap params){
		return sqlSession.selectOne(NAMESPACE + "selectTableComment", params);
	}
}