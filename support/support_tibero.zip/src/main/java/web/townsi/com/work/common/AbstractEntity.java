package web.townsi.com.work.common;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import lombok.Data;
import lombok.Setter;

@Data
public class AbstractEntity implements Serializable{

	private static final long serialVersionUID = 5309027994807260147L;

	private String instUsr; //등록ID

	private Date instTime; //등록일시

	private String upUsr; //수정ID

	private Date upTime; //수정일시

	private int page = 1;			//페이지 번호

	private int pageSize = 10;		//페이지 당 게시물 갯수(Default : 10)

	private long total = 0;			//전체건수

	@Setter private int pageStartNum;	//페이지 시작 번호

	public int getPageStartNum() {
		return (this.page - 1) * this.pageSize;
	}

	public int getStartNum() {
		return (int) (total - (this.page - 1) * this.pageSize);
	}


}
