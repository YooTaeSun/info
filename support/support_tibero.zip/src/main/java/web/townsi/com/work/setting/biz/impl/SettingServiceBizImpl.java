package web.townsi.com.work.setting.biz.impl;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;
import web.townsi.com.utils.ListUtil;
import web.townsi.com.work.mapper.mysql.SettingMapperMysql;
import web.townsi.com.work.mapper.postgre.SettingMapperPostgre;
import web.townsi.com.work.setting.biz.SettingBiz;
import web.townsi.com.work.setting.biz.SettingServiceBiz;

/**
* SettingServiceImpl
* @author 유태선
* @since 2016.10.14
* @version 1.0
* @see
* </pre>
*/
@SuppressWarnings({"rawtypes","unchecked","unused"})
@Service
public class SettingServiceBizImpl implements SettingServiceBiz {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private SettingBiz settingBiz;

	@Autowired
	private SettingMapperMysql settingMapperMysql;

	@Autowired
	private SettingMapperPostgre settingMapperByPostgre;

	public static String READ_LINE = "\n";
	public static String TAB = "\t";
	public static String SLASH = File.separator;// lastIndexOf("/")

//	public static String replaceTxt  = "#txt#";
	public static String rTxt  = "#{txt}";

	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();

	public HashMap makeService(HashMap params) throws Exception {

		HashMap dataMap = new HashMap();

		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String upperTableName = StringUtils.defaultString((String) params.get("upperTableName"));
		String lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		String camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		String camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String modelComment = StringUtils.defaultString((String) params.get("modelComment"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String group1 = StringUtils.defaultString((String) params.get("group1"));
		String author = StringUtils.defaultString((String) params.get("author"));
		String today = StringUtils.defaultString((String) params.get("today"));
		String current = StringUtils.defaultString((String) params.get("current"));
		String menu = StringUtils.defaultString((String) params.get("menu"));
		String programId = StringUtils.defaultString((String) params.get("programId"));
		String desc = StringUtils.defaultString((String) params.get("desc"));
		String cipers = "";

		List<HashMap> list = settingBiz.selectTableInfo(params,
				  StringUtils.defaultString((String)params.get("dbName"))
				, StringUtils.defaultString((String)params.get("tableSchema"))
			    , StringUtils.defaultString((String)params.get("tableName"))
				);

		List<HashMap> pklist = list.stream().
				filter(map ->  {
					String pk = StringUtils.defaultString((String) map.get("pk"));
					String columnName = StringUtils.defaultString((String)map.get("column_name"));
					//PK이고 컬럼 이름 _ID 존재
					if(pk.equals("pk")){
						return true;
					}else {
						return false;
					}
				})
				.collect(Collectors.toList());

		List<HashMap> pkIdlist = list.stream().
				filter(map ->  {
					String pk = StringUtils.defaultString((String) map.get("pk"));
					String columnName = StringUtils.defaultString((String)map.get("column_name"));
					//PK이고 컬럼 이름 _ID 존재
					if(pk.equals("pk") && columnName.endsWith("_ID")){
						return true;
					}else {
						return false;
					}
				})
				.collect(Collectors.toList());


		if(!ListUtil.isEmpty(pkIdlist)){
			//id 존재
			String COLUMN_TYPE = (String)pkIdlist.get(0).get("COLUMN_TYPE");
			if(COLUMN_TYPE.startsWith("char(")) {
				Matcher m = Pattern.compile("\\((.*?)\\)").matcher(COLUMN_TYPE);
				while(m.find()) {
					cipers = m.group(1);
				}
			}
		}

		StringBuilder takeSavPkIdStr = new StringBuilder(500);
		StringBuilder takeRegPkIdStr = new StringBuilder(500);
		String savStr = "";
		String IdGnrService = "";
		String pkCamelColumnFirstUpperName = "";

		// pk 이고 _ID 인 리스
		if(!ListUtil.isEmpty(pkIdlist)){
			for (HashMap map : pkIdlist) {

				String wType = StringUtils.defaultString((String)map.get("w_type"));
				String camelColumnName = StringUtils.defaultString((String)map.get("camel_column_name"));
				String columnName = StringUtils.defaultString((String)map.get("column_name"));
				String camelColumnFirstUpperName = StringUtils.defaultString((String)map.get("camelColumnFirstUpperName"));
				pkCamelColumnFirstUpperName = camelColumnFirstUpperName;

				takeSavPkIdStr.append("\t\tif(StringUtils.isBlank("+camelTableFirstUpperName+"DTO.get"+camelColumnFirstUpperName+"())){");
				takeSavPkIdStr.append("\n\t\t\tString genId = " +camelTableName +  "IdGnrService.getNextStringId();");
				takeSavPkIdStr.append("\n\t\t\t" + camelTableFirstUpperName + "DTO.set"+camelColumnFirstUpperName+"(genId);");
				takeSavPkIdStr.append("\n\t\t};");

				takeRegPkIdStr.append("\t\tString genId = " +camelTableName +  "IdGnrService.getNextStringId();");
				takeRegPkIdStr.append("\n\t\t" + camelTableFirstUpperName + "DTO.set"+camelColumnFirstUpperName+"(genId);");
			}

			StringBuilder IdGnrServiceSb = new StringBuilder(500);
			IdGnrServiceSb.append("\t/**");
			IdGnrServiceSb.append("\n\t * ID Generation");
			IdGnrServiceSb.append("\n\t */");
			IdGnrServiceSb.append("\n\t@Autowired");
			IdGnrServiceSb.append("\n\tprivate EgovTableIdGnrServiceImpl "+camelTableName+"IdGnrService;");
			IdGnrService = IdGnrServiceSb.toString();

		}else if(!ListUtil.isEmpty(pklist)){

		}else{

		}


		HashMap replaceMap = new HashMap();
		replaceMap.put("#group#",group);
		replaceMap.put("#group1#", group1);
		replaceMap.put("#author#", author);
		replaceMap.put("#today#", today);
		replaceMap.put("#current#",current);
		replaceMap.put("#menu#",menu);
		replaceMap.put("#programId#",programId);
		replaceMap.put("#desc#", desc);
		replaceMap.put("#camelTableFirstUpperName#",camelTableFirstUpperName);
		replaceMap.put("#camelTableName#",camelTableName);
		replaceMap.put("#takeSavPkIdStr#",takeSavPkIdStr.toString());
		replaceMap.put("#takeRegPkIdStr#",takeRegPkIdStr.toString());
		replaceMap.put("#IdGnrServiceStr#",IdGnrService);
		replaceMap.put("#prefix#","??");
		replaceMap.put("#cipers#",cipers);
		replaceMap.put("#CamelColumnFirstUpperName#",pkCamelColumnFirstUpperName);

		//AppStartingEvent.java --> copyArray
		String rfullPath = SITE_WEB_ROOT + "/copy/SampleService.java";
		String wfullPath = SITE_WEB_ROOT + "/new/"+camelTableFirstUpperName+"/service/"+camelTableFirstUpperName+"Service.java";
		String str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);
		dataMap.put("str", str);

		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}

	public HashMap makeServiceImpl(HashMap params) throws Exception {

		HashMap dataMap = new HashMap();

		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String upperTableName = StringUtils.defaultString((String) params.get("upperTableName"));
		String lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		String camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		String camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String modelComment = StringUtils.defaultString((String) params.get("modelComment"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String group1 = StringUtils.defaultString((String) params.get("group1"));
		String author = StringUtils.defaultString((String) params.get("author"));
		String today = StringUtils.defaultString((String) params.get("today"));
		String current = StringUtils.defaultString((String) params.get("current"));
		String menu = StringUtils.defaultString((String) params.get("menu"));
		String programId = StringUtils.defaultString((String) params.get("programId"));
		String desc = StringUtils.defaultString((String) params.get("desc"));
		String cipers = "";

		List<HashMap> list = settingBiz.selectTableInfo(params,
				StringUtils.defaultString((String)params.get("dbName"))
				, StringUtils.defaultString((String)params.get("tableSchema"))
				, StringUtils.defaultString((String)params.get("tableName"))
				);

		List<HashMap> pklist = list.stream().
				filter(map ->  {
					String pk = StringUtils.defaultString((String) map.get("pk"));
					String columnName = StringUtils.defaultString((String)map.get("column_name"));
					//PK이고 컬럼 이름 _ID 존재
					if(pk.equals("pk")){
						return true;
					}else {
						return false;
					}
				})
				.collect(Collectors.toList());

		List<HashMap> pkIdlist = list.stream().
				filter(map ->  {
					String pk = StringUtils.defaultString((String) map.get("pk"));
					String columnName = StringUtils.defaultString((String)map.get("column_name"));
					//PK이고 컬럼 이름 _ID 존재
					if(pk.equals("pk") && columnName.endsWith("_ID")){
						return true;
					}else {
						return false;
					}
				})
				.collect(Collectors.toList());


		if(!ListUtil.isEmpty(pkIdlist)){
			//id 존재
			String COLUMN_TYPE = (String)pkIdlist.get(0).get("COLUMN_TYPE");
			if(COLUMN_TYPE.startsWith("char(")) {
				Matcher m = Pattern.compile("\\((.*?)\\)").matcher(COLUMN_TYPE);
				while(m.find()) {
					cipers = m.group(1);
				}
			}
		}

		StringBuilder takeSavPkIdStr = new StringBuilder(500);
		StringBuilder takeRegPkIdStr = new StringBuilder(500);
		String savStr = "";
		String IdGnrService = "";
		String pkCamelColumnFirstUpperName = "";

		// pk 이고 _ID 인 리스
		if(!ListUtil.isEmpty(pkIdlist)){
			for (HashMap map : pkIdlist) {

				String wType = StringUtils.defaultString((String)map.get("w_type"));
				String camelColumnName = StringUtils.defaultString((String)map.get("camel_column_name"));
				String columnName = StringUtils.defaultString((String)map.get("column_name"));
				String camelColumnFirstUpperName = StringUtils.defaultString((String)map.get("camelColumnFirstUpperName"));
				pkCamelColumnFirstUpperName = camelColumnFirstUpperName;

				takeSavPkIdStr.append("\t\tif(StringUtils.isBlank("+camelTableFirstUpperName+"DTO.get"+camelColumnFirstUpperName+"())){");
				takeSavPkIdStr.append("\n\t\t\tString genId = " +camelTableName +  "IdGnrService.getNextStringId();");
				takeSavPkIdStr.append("\n\t\t\t" + camelTableFirstUpperName + "DTO.set"+camelColumnFirstUpperName+"(genId);");
				takeSavPkIdStr.append("\n\t\t};");

				takeRegPkIdStr.append("\t\tString genId = " +camelTableName +  "IdGnrService.getNextStringId();");
				takeRegPkIdStr.append("\n\t\t" + camelTableFirstUpperName + "DTO.set"+camelColumnFirstUpperName+"(genId);");
			}

			StringBuilder IdGnrServiceSb = new StringBuilder(500);
			IdGnrServiceSb.append("\t/**");
			IdGnrServiceSb.append("\n\t * ID Generation");
			IdGnrServiceSb.append("\n\t */");
			IdGnrServiceSb.append("\n\t@Autowired");
			IdGnrServiceSb.append("\n\tprivate EgovTableIdGnrServiceImpl "+camelTableName+"IdGnrService;");
			IdGnrService = IdGnrServiceSb.toString();

		}else if(!ListUtil.isEmpty(pklist)){

		}else{

		}


		HashMap replaceMap = new HashMap();
		replaceMap.put("#group#",group);
		replaceMap.put("#group1#", group1);
		replaceMap.put("#author#", author);
		replaceMap.put("#today#", today);
		replaceMap.put("#current#",current);
		replaceMap.put("#menu#",menu);
		replaceMap.put("#programId#",programId);
		replaceMap.put("#desc#",desc);
		replaceMap.put("#camelTableFirstUpperName#",camelTableFirstUpperName);
		replaceMap.put("#camelTableName#",camelTableName);
		replaceMap.put("#takeSavPkIdStr#",takeSavPkIdStr.toString());
		replaceMap.put("#takeRegPkIdStr#",takeRegPkIdStr.toString());
		replaceMap.put("#IdGnrServiceStr#",IdGnrService);
		replaceMap.put("#prefix#","??");
		replaceMap.put("#cipers#",cipers);
		replaceMap.put("#CamelColumnFirstUpperName#",pkCamelColumnFirstUpperName);

		//AppStartingEvent.java --> copyArray
		String rfullPath = SITE_WEB_ROOT + "/copy/SampleServiceImpl.java";
		String wfullPath = SITE_WEB_ROOT + "/new/"+camelTableFirstUpperName+"/service/impl/"+camelTableFirstUpperName+"ServiceImpl.java";

		String str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);
		dataMap.put("str", str);

		dataMap.put("fullPath", wfullPath);
		return dataMap;
	}

}