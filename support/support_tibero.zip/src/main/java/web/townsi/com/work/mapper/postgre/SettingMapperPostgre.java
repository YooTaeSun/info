package web.townsi.com.work.mapper.postgre;

import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository
public class SettingMapperPostgre extends MapperPostgre01{

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	private final static String NAMESPACE = "web.townsi.com.work.mapper.postgre.SettingMapperByPostgre.";

    public Object insert(String queryId, Object params) {
    	return sqlSession.insert(NAMESPACE + queryId, params);
    }
    public Object update(String queryId, Object params) {
    	return sqlSession.update(NAMESPACE + queryId, params);
    }
    public Object delete(String queryId, Object params) {
    	return sqlSession.delete(NAMESPACE + queryId, params);
    }

	public List selectList(String queryId, Object params) {
		return sqlSession.selectList(NAMESPACE + queryId, params);
	}

	public Object selectOne(String queryId, Object params) {
		return sqlSession.selectOne(NAMESPACE + queryId, params);
	}

	public List<HashMap> selectTableInfo(HashMap params){
		return sqlSession.selectList(NAMESPACE + "selectTableInfo", params);
	}

	public List<HashMap> selectTableList(HashMap params){
		return sqlSession.selectList(NAMESPACE + "selectTableList", params);
	}

	public List<HashMap> selectSqlInfo(HashMap params){
		return sqlSession.selectList(NAMESPACE + "selectSqlInfo", params);
	}

	public String selectTableComment(HashMap params){
		return sqlSession.selectOne(NAMESPACE + "selectTableComment", params);
	}
}