package web.townsi.com.framework.listener;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationStartingEvent;
import org.springframework.context.ApplicationListener;

import web.townsi.com.framework.fixed.AppConst;
import web.townsi.com.utils.FileUtil;

public class AppStartingEvent implements ApplicationListener<ApplicationStartingEvent> {

	final private static Logger logger = LoggerFactory.getLogger(AppStartingEvent.class);

	final static private String copyArray[]  = {
			"context-idgn-sample.xml"
			,"SampleAPI.java"
			,"SampleDTO.java"
			,"SampleMapper.java"
			,"SampleService.java"
			,"SampleServiceImpl.java"
			,"SampleSql.xml"
			,"SampleValidator.java"
			,"SampleVO.java"
			,"SampleTrans.xml"

	};

	@Override
	public void onApplicationEvent(ApplicationStartingEvent event) {
		logger.debug("[LOADING_CHECK]  ApplicationStartingEvent ");
		System.out.println("[LOADING_CHECK]  ApplicationStartingEvent ");
        try {
			regiConstCopyPath();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void regiConstCopyPath() throws IOException {

        URL classPathUrl = AppStartingEvent.class.getResource("/");
        String classPathStr = classPathUrl.getPath();
        logger.debug("[LOADING_CHECK]  regiConstCopyPath classPathStr >> " + classPathStr);
        System.out.println("[LOADING_CHECK]  regiConstCopyPath classPathStr >> " + classPathStr);

        logger.debug("[LOADING_CHECK]  regiConstCopyPath webappPathStr before >> " + classPathStr);

        System.out.println("[LOADING_CHECK]  regiConstCopyPath webappPathStr before >> " + classPathStr);

        String webappPathStr = classPathStr.replace("/target/classes/", "/src/main/webapp").replace("/target/test-classes/", "/src/main/webapp");
        logger.debug("[LOADING_CHECK]  regiConstCopyPath webappPathStr after >> " + webappPathStr);

        System.out.println("[LOADING_CHECK]  regiConstCopyPath webappPathStr after >> " + webappPathStr);
		AppConst.setSiteSamplePath(webappPathStr);


		File projectFile = new File(".");
		String projectPath = projectFile.getAbsolutePath();
//		String projectRoot = projectPath.replace("/support/.", "/support");
		String cpoyRoot = "";

		if(System.getProperty("os.name").toLowerCase().startsWith("window")) {
			cpoyRoot = projectPath.replace("\\support\\.", "\\support_t_root");
		}else {
			cpoyRoot = projectPath.replace("/support/.", "/support_t_root");
		}

		logger.debug("[LOADING_CHECK]  cpoyRoot  >> " + cpoyRoot);
		System.out.println("[LOADING_CHECK]  cpoyRoot  >> " + cpoyRoot);

		AppConst.setSiteWebRoot(cpoyRoot);

		String settingPropPathUrl = cpoyRoot + File.separator +"setting.properties";
		File settingPropPathUrlFile = new File(settingPropPathUrl);
		logger.debug("[LOADING_CHECK]  outFilePath  >> " + settingPropPathUrl);
		System.out.println("[LOADING_CHECK]  outFilePath  >> " + settingPropPathUrl);

		if(!settingPropPathUrlFile.exists()) {
			FileUtil.copyURLToFile("/config/setting.properties", settingPropPathUrl);
		}
		AppConst.setSettingProp(settingPropPathUrl);

		String newPathUrl = cpoyRoot + File.separator + "copy";
		File newPathUrlFile = new File(newPathUrl);
		logger.debug("[LOADING_CHECK]  newPathUrlFile  >> " + newPathUrlFile);
		System.out.println("[LOADING_CHECK]  newPathUrlFile  >> " + newPathUrlFile);


		for (String fileNm : copyArray) {
			FileUtil.copyURLToFile("/copy/" + fileNm, newPathUrl + File.separator + fileNm);
		}
		
	}

}
