package web.townsi.com.work.test.controller;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping({ "/lang" })
public class LangController {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	
    @Autowired
    MessageSource messageSource;
    
    @Autowired
    LocaleResolver localeResolver;
    
    @RequestMapping(value = "/jsp", method = RequestMethod.GET)
    public String testJsp(Locale locale, HttpServletRequest request, Model model) throws Exception {

        // RequestMapingHandler로 부터 받은 Locale 객체를 출력해 봅니다.
        model.addAttribute("clientLocale", locale);

        // localeResolver 로부터 Locale 을 출력해 봅니다.
        model.addAttribute("sessionLocale", localeResolver.resolveLocale(request));

        // JSP 페이지에서 EL 을 사용해서 arguments 를 넣을 수 있도록 값을 보낸다.
        model.addAttribute("siteCount", messageSource.getMessage("msg.first", null, locale));

        String lang = locale.getLanguage();
        
        logger.debug("locale : {}", locale);
        logger.debug("jsp lang : {}", lang);
        logger.debug("locale : {}", locale);
        logger.debug("messageSource.getMessage(\"msg.first\", null, locale) : {}", messageSource.getMessage("msg.first", null, locale));

        return "sample/lang";
    }
	
	
	@RequestMapping(value = "/thymeleaf")
	public ModelAndView testThymeleaf(Locale locale) throws Exception {
		ModelAndView mv = new ModelAndView("thymeleaf/lang");
		String lang = locale.getLanguage();
		
		logger.debug("thymeleaf lang=={}", lang);
//		mv.addObject("lang", lang);
		return mv;
	}
}
