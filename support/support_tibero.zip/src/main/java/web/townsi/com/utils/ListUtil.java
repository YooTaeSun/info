package web.townsi.com.utils;

import java.util.List;

public class ListUtil {

  /**
   * java.util.List 를 받아 내용이 비어 있는 지를 확인한다.
   * @param list
   * @return
   *
   */
  public static final boolean isEmpty(List list) {
    return (list==null || list.size() == 0)
        ? true:false;
  }

  /**
   * java.util.List 를 받아 내용이 비어 있지 않은지를 확인한다.
   * @param list
   * @return
   *
   */
  public static final boolean isNotEmpty(List list) {
    return !(isEmpty(list));
  }


//  public static final List<T> setUpperSeq(List<T> list , String lvlAttr, String upperSeqAttr, String seqAttr ) {
//
//    return null;
//  }

}
