package web.townsi.com.utils;

import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;


/**
 * session Util
 * - Spring에서 제공하는 RequestContextHolder 를 이용하여
 * request 객체를 service까지 전달하지 않고 사용할 수 있게 해줌
 *
 */
public class SessionUtil {
    /**
     * attribute 값을 가져 오기 위한 method
     *
     * @param String  attribute key name
     * @return Object attribute obj
     */
    public static Object getAttribute(String name){
        return (Object)RequestContextHolder.getRequestAttributes().getAttribute(name, RequestAttributes.SCOPE_SESSION);
    }

    /**
     * attribute 설정 method
     *
     * @param String  attribute key name
     * @param Object  attribute obj
     * @return void
     */
    public static void setAttribute(String name, Object object){
    	try{
    		RequestContextHolder.getRequestAttributes().setAttribute(name, object, RequestAttributes.SCOPE_SESSION);
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    }

    /**
     * 설정한 attribute 삭제
     *
     * @param String  attribute key name
     * @return void
     */
    public static void removeAttribute(String name){
    	try{
    		RequestContextHolder.getRequestAttributes().removeAttribute(name, RequestAttributes.SCOPE_SESSION);
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    }

    /**
     * session id
     *
     * @param void
     * @return String SessionId 값
     */
    public static String getSessionId(){
    	try{
    		return RequestContextHolder.getRequestAttributes().getSessionId();
    	}catch(Exception e){
    		e.printStackTrace();
    		return "";
    	}
    }

//	public static Authentication getLoginAuth() {
//		SecurityContext sc = (SecurityContext) RequestContextHolder.getRequestAttributes().getAttribute("SPRING_SECURITY_CONTEXT", RequestAttributes.SCOPE_SESSION);
//		return (sc != null)? sc.getAuthentication(): null;
//	}
//
//	public static SecurityMobileVO getLoginSecurityUser() {
//		Authentication auth = getLoginAuth();
//		return (auth != null)? (SecurityMobileVO) auth.getPrincipal(): null;
//
//	}
//
//	/**
//	 * 로그인  사용자 정보
//	 * @return
//	 *
//	 */
//	public static MobileMemberVO getLoginUser() {
//		SecurityMobileVO securityMember =  SessionUtil.getLoginSecurityUser();
//		return (securityMember != null)? securityMember.getMobileMemberVO(): null;
//	}
//
//    /**
//     * 로그인 사용자id 정보
//     * @return
//     *
//     */
//	public static String getLoginMberCd() {
//		MobileMemberVO member = getLoginUser();
//		return (member != null)? member.getMberCd() : "";
//	}
//
//    /**
//     * 로그아웃
//     * @return
//     *
//     */
//	public static void setLogout() {
//		SecurityMobileVO securityMember =  SessionUtil.getLoginSecurityUser();
//		if(securityMember != null) {
//			securityMember.setMobileMemberVO(null);
//		}
//	}
//
//
//	/** attribute 값을 String 타입으로 가져 오기 위한 method
//     *
//     * @param String  attribute key name
//     * @return Object attribute obj
//     */
//    public static String getString(String name){
//        return (String)RequestContextHolder.getRequestAttributes().getAttribute(name, RequestAttributes.SCOPE_SESSION);
//    }

}