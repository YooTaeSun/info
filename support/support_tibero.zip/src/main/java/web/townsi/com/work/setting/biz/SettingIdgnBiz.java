package web.townsi.com.work.setting.biz;

import java.util.HashMap;
import java.util.List;

public interface SettingIdgnBiz {
	public abstract HashMap<String, Object> makeIdgn(HashMap paramHashMap) throws Exception;
}