//package web.townsi.com.framework.config.database;
//
//import java.util.Properties;
//
//import javax.sql.DataSource;
//
//import org.apache.ibatis.session.SqlSessionFactory;
//import org.mybatis.spring.SqlSessionFactoryBean;
//import org.mybatis.spring.SqlSessionTemplate;
//import org.mybatis.spring.annotation.MapperScan;
//import org.springframework.aop.framework.autoproxy.BeanNameAutoProxyCreator;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Lazy;
//import org.springframework.core.annotation.Order;
//import org.springframework.jdbc.datasource.DataSourceTransactionManager;
//import org.springframework.transaction.PlatformTransactionManager;
//import org.springframework.transaction.annotation.EnableTransactionManagement;
//import org.springframework.transaction.interceptor.TransactionInterceptor;
//
//import com.zaxxer.hikari.HikariConfig;
//import com.zaxxer.hikari.HikariDataSource;
//
//@Configuration
//@Lazy
//@EnableTransactionManagement
//@MapperScan(basePackages = {"web.townsi.com.work.mapper.postgre"})
//@Order(1000)
//public class DbConfigByPostgreSql {
//
//  @Autowired
//  private ApplicationContext applicationContext;
//
////  @Autowired
////  private Environment environment;
//
//  @Value("${spring.datasource.postgresql.url}")
//  private String url;
//
//  @Value("${spring.datasource.postgresql.username}")
//  private String username;
//
//  @Value("${spring.datasource.postgresql.password}")
//  private String password;
//
//  @Value("${spring.datasource.postgresql.dataSourceClassName}")
//  private String dataSourceClassName;
//
//
//  @Bean(name="dataSourcePostgre01", destroyMethod = "close")
////  @ConfigurationProperties("spring.datasource.postgresql")
//  public DataSource dataSourcePostgre01() {
//	  Properties props = new Properties();
//	  props.setProperty("dataSourceClassName", dataSourceClassName);
//	  props.setProperty("dataSource.user", username);
//	  props.setProperty("dataSource.password", password);
//	  props.setProperty("dataSource.url", url);
////	  props.put("dataSource.logWriter", new PrintWriter(System.out));
//	  return new HikariDataSource(new HikariConfig(props));
//  }
//
//  @Bean(name= "transactionManagerPostgre01")
//  public PlatformTransactionManager transactionManager() {
//    DataSourceTransactionManager transactionManager = new DataSourceTransactionManager(dataSourcePostgre01());
//    transactionManager.setGlobalRollbackOnParticipationFailure(false);
//    return transactionManager;
//  }
//
//  @Bean(name= "sqlSessionFactoryPostgre01")
//  public SqlSessionFactory sqlSessionFactoryPostgre01() throws Exception {
//    SqlSessionFactoryBean sessionFactoryBean = new SqlSessionFactoryBean();
//    sessionFactoryBean.setDataSource(dataSourcePostgre01());
//    sessionFactoryBean.setConfigLocation(applicationContext.getResource("classpath:config/mybatis-config.xml"));
//    sessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath:mapper/**/*.xml"));
//    return sessionFactoryBean.getObject();
//  }
//
//  @Bean(name= "sqlSessionPostgre01")
//  public SqlSessionTemplate sqlSession() throws Exception {
//    return new SqlSessionTemplate(sqlSessionFactoryPostgre01());
//  }
//
//  @Bean(name= "transactionInterceptorPostgre01")
//  public TransactionInterceptor transactionInterceptor(@Qualifier("transactionManagerPostgre01") PlatformTransactionManager platformTransactionManager) {
//      TransactionInterceptor transactionInterceptor = new TransactionInterceptor();
//      transactionInterceptor.setTransactionManager(platformTransactionManager);
//      Properties transactionAttributes = new Properties();
//      transactionAttributes.setProperty("*", "PROPAGATION_REQUIRED,-Throwable");
//      transactionInterceptor.setTransactionAttributes(transactionAttributes);
//      return transactionInterceptor;
//  }
//
//  @Bean(name= "transactionAutoProxyPostgre01")
//  public BeanNameAutoProxyCreator transactionAutoProxy() {
//      BeanNameAutoProxyCreator transactionAutoProxy = new BeanNameAutoProxyCreator();
//      transactionAutoProxy.setProxyTargetClass(true);
//      transactionAutoProxy.setBeanNames("*BizImpl");
//      transactionAutoProxy.setInterceptorNames("transactionInterceptorPostgre01");
//      return transactionAutoProxy;
//  }
//
//}