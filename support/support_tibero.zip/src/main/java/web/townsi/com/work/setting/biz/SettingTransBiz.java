package web.townsi.com.work.setting.biz;

import java.util.HashMap;

public interface SettingTransBiz {
	public abstract HashMap makeTrans(HashMap params) throws Exception;
}