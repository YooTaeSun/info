package web.townsi.com.work.trans.biz.impl;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.townsi.com.framework.fixed.Const;
import web.townsi.com.utils.FileUtil;
import web.townsi.com.utils.ListUtil;
import web.townsi.com.work.mapper.mysql.SettingMapperMysql;
import web.townsi.com.work.mapper.postgre.SettingMapperPostgre;
import web.townsi.com.work.setting.biz.SettingBiz;
import web.townsi.com.work.setting.biz.SqlByIbaitisBiz;
import web.townsi.com.work.setting.biz.SqlByMybaitisBiz;
import web.townsi.com.work.trans.biz.TransBiz;

/**
* @author 유태선
* @since 2016.10.14
* @version 1.0
* @see
* </pre>
*/
@SuppressWarnings({"rawtypes","unchecked","unused"})
@Service
public class TransBizImpl implements TransBiz {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	@Autowired
	private SettingBiz settingBiz;

	@Autowired
	private SqlByMybaitisBiz sqlByMybaitisBiz;

	@Autowired
	private SqlByIbaitisBiz sqlByIbaitisBiz;

	@Autowired
	private SettingMapperMysql settingMapperMysql;

	@Autowired
	private SettingMapperPostgre settingMapperByPostgre;

	public static String LINE = "\n";
	public static String SPACE_CNT = "    ";
	public static String SLASH = File.separator;// lastIndexOf("/")

//	public static String replaceTxt  = "#txt#";
	public static String rTxt  = "#{txt}";

	final static String SITE_WEB_ROOT = Const.Path.SITE_WEB_ROOT.getValue();

	@Override
	public HashMap<String, Object> makeTrans(HashMap params) throws Exception {
		HashMap dataMap = new HashMap();
		

		HashMap replaceMap = new HashMap();

		String tableName = StringUtils.defaultString((String) params.get("tableName"));
		String upperTableName = StringUtils.defaultString((String) params.get("upperTableName"));
		String lowerTableName = StringUtils.defaultString((String) params.get("lowerTableName"));
		String camelTableName = StringUtils.defaultString((String) params.get("camelTableName"));
		String camelTableFirstUpperName = StringUtils.defaultString((String) params.get("camelTableFirstUpperName"));
		String makeGetsetMethodYn = StringUtils.defaultString((String) params.get("makeGetsetMethodYn"));
		String group = StringUtils.defaultString((String) params.get("group"));
		String group1 = StringUtils.defaultString((String) params.get("group1"));
		String author = StringUtils.defaultString((String) params.get("author"));
		String today = StringUtils.defaultString((String) params.get("today"));
		String current = StringUtils.defaultString((String) params.get("current"));
		String menu = StringUtils.defaultString((String) params.get("menu"));
		String programId = StringUtils.defaultString((String) params.get("programId"));
		String desc = StringUtils.defaultString((String) params.get("desc"));
		String dtoComment = StringUtils.defaultString((String) params.get("dtoComment"));

		StringBuilder dtoMemer = new StringBuilder(500);
		StringBuilder dtoSearcgMemer = new StringBuilder(500);
		StringBuilder dtoMethod = new StringBuilder(500);
		StringBuilder conParam = new StringBuilder(500);
		StringBuilder conParamBody = new StringBuilder(500);

		String column_name = "";
		String mem_vari = "";
		String column_comment = "";
		String camel_column_name = "";
		String set_get_column_name = "";
		String w_type = "";
		String pk = "";
		String is_nullable = "";

		List<HashMap> list = settingBiz.selectTableInfo(params,
				  StringUtils.defaultString((String)params.get("dbName"))
				, StringUtils.defaultString((String)params.get("tableSchema"))
			    , StringUtils.defaultString((String)params.get("tableName"))
				);

		if(ListUtil.isNotEmpty(list)) {

			for (HashMap rs : list) {
				column_name = (String) rs.get("column_name");
				column_comment = (String) rs.get("column_comment");
				camel_column_name = (String) rs.get("camel_column_name");
				mem_vari = (String) rs.get("mem_vari");
				w_type = (String) rs.get("w_type");
				is_nullable = (String) rs.get("is_nullable");

				String camelColumnFirstUpperName = camel_column_name.substring(0,1).toUpperCase() + camel_column_name.substring(1);

				set_get_column_name = (String) rs.get("set_get_column_name");
				pk = StringUtils.defaultString((String) rs.get("pk")).toLowerCase();
				if("pk".equals(pk)) {
					conParam = conParam.append(", "  + mem_vari.replaceAll("private ", "").replaceAll(";", ""));
					conParamBody = conParamBody.append("\n\t\tthis." + camel_column_name  + " = " + camel_column_name + ";");
				}


				if(camel_column_name.equals("regId")
						|| camel_column_name.equals("regNm")
						|| camel_column_name.equals("regDt")
						|| camel_column_name.equals("updId")
						|| camel_column_name.equals("updNm")
						|| camel_column_name.equals("updDt")
						) {
					continue;
				}

				if(!StringUtils.isEmpty(column_comment)) {
					if(dtoComment.equals("Y_NEXT")) {

						dtoMemer.append("\t"+ mem_vari.replace("Date", "String"));
						dtoMemer.append("\t// " +column_comment + "" + LINE);

						dtoSearcgMemer.append("\tprivate "+ w_type + " search" + camelColumnFirstUpperName + ";");
						dtoSearcgMemer.append("\t// search" + column_comment + "" + LINE);

					}else if(dtoComment.equals("Y_UP")) {

						dtoMemer.append("\t/* " +column_comment + " */" + LINE);
						dtoSearcgMemer.append("\t/*  search" +column_comment + " */" + LINE);
//						if("Date".equals(w_type)) {
//							dtoMemer.append("\t@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = \"yyyy-MM-dd HH:mm:ss\")" + LINE);
//						}
						dtoMemer.append("\t"+ mem_vari + LINE);
						dtoSearcgMemer.append("\tprivate "+ w_type + " search" + camelColumnFirstUpperName + ";"+  LINE);

					}else if(dtoComment.equals("Y_BOTTOM")) {

						dtoMemer.append("\t"+ mem_vari + LINE);
						dtoSearcgMemer.append("\tprivate "+ w_type + " search" + camelColumnFirstUpperName + ";"+  LINE);
//						if("Date".equals(w_type)) {
//							dtoMemer.append("\t@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = \"yyyy-MM-dd HH:mm:ss\")" + LINE);
//						}
						dtoMemer.append("\t/* " +column_comment + " */" + LINE);
						dtoSearcgMemer.append("\t/*  search" +column_comment + " */" + LINE);

					}else {
						dtoMemer.append("\t"+ mem_vari + LINE);
						dtoSearcgMemer.append("\tprivate "+ w_type + " search" + camelColumnFirstUpperName + ";"+  LINE);
					}


				}else {
					dtoMemer.append("\t"+ mem_vari + LINE);
					dtoSearcgMemer.append("\tprivate "+ w_type + " search" + camelColumnFirstUpperName + ";"+  LINE);
				}


				if(camel_column_name.endsWith("Cd")) {
					dtoMemer.append("\t"+ mem_vari.replace("Cd", "CdNm"));
					dtoMemer.append("\t// " +column_comment + "명" + LINE);
					dtoSearcgMemer.append("\tprivate "+ w_type + " search" + camelColumnFirstUpperName.replace("Cd", "CdNm") + ";");
					dtoSearcgMemer.append("\t/*  search" +column_comment + "명 */" + LINE);
				}
			}
		}

		String dtoContent = dtoMemer.toString();

		replaceMap.put("#camelTableFirstUpperName#",camelTableFirstUpperName);
		replaceMap.put("#lowerTableName#", lowerTableName.replaceAll("_", ""));
		replaceMap.put("#group#", group);
		replaceMap.put("#group1#", group1);
		replaceMap.put("#author#", author);
		replaceMap.put("#today#", today);
		replaceMap.put("#current#",current);
		replaceMap.put("#menu#",menu);
		replaceMap.put("#programId#",programId);
		
		replaceMap.put("#dtoContent#", dtoMemer.toString().replace("\t", SPACE_CNT).replace("\n", LINE));
		replaceMap.put("#searchDtoContent#", dtoSearcgMemer.toString().replace("\t", SPACE_CNT).replace("\n", LINE));

		if(!conParam.toString().isEmpty()){
			replaceMap.put("#conParam#", conParam.toString().substring(1).toString().replace("\t", SPACE_CNT).replace("\n", LINE));
			replaceMap.put("#conParamBody#", conParamBody.toString().substring(1).toString().replace("\t", SPACE_CNT).replace("\n", LINE));
		}else {
			replaceMap.put("#conParam#", "");
			replaceMap.put("#conParamBody#", "");
		}

		//AppStartingEvent.java --> copyArray
		String rfullPath = SITE_WEB_ROOT + "/copy/SampleDTO.java";
		String wfullPath = SITE_WEB_ROOT + "/new/"+camelTableFirstUpperName+"/model/dto/"+camelTableFirstUpperName+"DTO.java";


		String str = FileUtil.copyFile(rfullPath, wfullPath, replaceMap);

		dataMap.put("str", str);
		dataMap.put("fullPath", wfullPath);
		list = null;
		return dataMap;
	}
}