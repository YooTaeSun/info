package web.townsi.com.work.setting.biz;

import java.util.HashMap;

public interface SqlByMybaitisBiz {
	public abstract HashMap makeSql(HashMap params) throws Exception;
}