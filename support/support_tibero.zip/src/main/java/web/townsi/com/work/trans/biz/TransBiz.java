package web.townsi.com.work.trans.biz;

import java.util.HashMap;
import java.util.List;

public interface TransBiz {
	public abstract HashMap<String, Object> makeTrans(HashMap paramHashMap) throws Exception;
}