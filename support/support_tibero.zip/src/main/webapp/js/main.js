var agent = navigator.userAgent.toLowerCase();
var ie = false;
if ( (navigator.appName == 'Netscape' && navigator.userAgent.search('Trident') != -1) || (agent.indexOf("msie") != -1) ) {
	ie = true;
}

function ajaxSubmit(url, data, success_callback, ar_callbackCode) {
	//var queCode = pageLoadQue();

	if (!ar_callbackCode) {
		ar_callbackCode = ['0000'];
	}

	if (!success_callback) {
		success_callback = function() {};
	}

	var opt = {
		url: url,
		dataType: 'json',
		method: 'POST',
		data: data,
		success: function(data, textStatus, jqXHR) {
			if(data && data.msg){
				alert(data.msg);
				return;
			}
			success_callback(data);
			/*return;
			var resultCode = data.resultCode;

			if ($.inArray(data.resultCode, ar_callbackCode) === -1) {
				var msg = data.msg;
			} else if (data.resultCode == '9999') {
				//alert(messageSource['result.code.' + resultCode]);
				alert(resultCode);
			} else {
				success_callback(data);
			}
			*/
		},
		statusCode: {
			401: function(){
				alert('');
			},
			403: function(){
				alert('');
			},
			400: function(){
				//BAD_REQUEST(400, "Bad Request"),
				alert('Bad Request');
			}
		},
		error: function(xhr, status, err) {
			if (!xhr || !xhr.status || (xhr.status != 403 && xhr.status != 401)) {
				if(xhr || xhr.responseJSON || xhr.responseJSON.error)
					alert(xhr.responseJSON.error);
			}
		},
		complete: function(){
			//pageLoadQue(queCode);
		}
	};

	if(jQuery.type(data) === "string"){
		opt.contentType = "application/json";
	}

	$.ajax(opt);
}


(function ($) {
    $.fn.serializeFormJSON = function () {

        var o = {};
        var a = this.serializeArray();
        $.each(a, function () {
            if (o[this.name]) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };
})(jQuery);
