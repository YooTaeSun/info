/**
 * Created by hyundai on 2017. 7. 18..
 */
//function fn_append(resdata, reqdata, fltCd, length){
function fn_append(resdata, reqdata, fltCd){
	console.log(resdata);
	var appendData = resdata.rows;
	var flag = reqdata.searchKind;
	var returnVal = "";
	
	var page = reqdata.page;
	if (page == 1){
		page = 0;
	} else {
		page = 2*(page-1);
	}
	var count = Number(page)*10;
	 
	//var count = length;
	if (appendData.length > 0){
		if (flag == "1"){
			for(var i in appendData){
				if(count < 999){
//					if(!appendData[i].category || appendData[i].category.products.length == 0){
//						continue;
//					}
					var cntStr = 0;
					count += 1;
					if (count < 10){
						cntStr = "0"+Number(count);
					} else {
						cntStr = count;
					} 
					var reVal = appendVal.set1(appendData[i],cntStr);
//					if(reVal == ""){
//						count -= 1;
//					}
					returnVal += reVal;
				}
			}
		} else if (flag == "2"){
			for(var i in appendData){
//				if(!appendData[i].category || appendData[i].category.products.length == 0){
//					continue;
//				}
				returnVal += appendVal.set2(appendData[i]);
			}
		} else if (flag == "3"){
			for(var i in appendData){
//				if(!appendData[i].category || appendData[i].category.products.length == 0){
//					continue;
//				}
				returnVal += appendVal.set3(appendData[i]);
			}
		}
	} else {
		if(fltCd){
			returnVal += resultNone.set(reqdata, fltCd);
		}else{
			returnVal += resultNone.set(reqdata);
		}
	}
	return returnVal;
}

var appendVal = {
	set1 : function (data, idx) {
		var liTag = "";
		if (data.site_meta_promotion_info == null){
			data.site_meta_promotion_info = "";
		}
		
		if (data.site_meta_promotion_info.length > 0){
			liTag += '<span>'+ data.site_meta_promotion_info +'</span>';
		}
		
		if ( data.site_meta_direct_delivery == "true" ){
			liTag += '<span>';
			liTag += "직배송"+
			'</span>';
		}
		
		if (data.site_meta_free_delivery == "true"){
			var desc = data.site_meta_free_delivery_description;
			liTag += '<span>';
			if (desc){
				liTag += desc;
				if (!desc.indexOf(/무료 배송|무료배송/)){
					liTag += "무료배송";
				}
			} else {
				liTag += "무료배송";
			}
			liTag += '</span>';
		}
		
		if (data.site_meta_checkout_card != null){
			var cardArr = data.site_meta_checkout_card.split(';');
		}
		
		if(cardArr.length > 0){
			//cardInfo Add
			liTag += '<span>';
			for(var i in cardArr){
				liTag += cardArr[i];
				if(i != cardArr.length-1){
					liTag += "/";
				}
			}
			liTag += '</span>';
		}
		
		
		var catUrl = "";
		if(data.category && data.category["ctg_meta_site_cat_url"]){
			catUrl = data.category["ctg_meta_site_cat_url"];
			if(catUrl.length < 1){
				if(data.site_meta_landing_url){
					catUrl = data.site_meta_landing_url;			
				}
			}
		}
		
		var categoryId =  "";
		if(data.category && data.category.id){
			categoryId = data.category.id;
		}else{
		}
		// 100 이상 클래스 정의
		var numClass = "first";
		if(idx >= 100){
			numClass = "hundred";
		}
		
		var setVal = '<div class="result_box new" data-site-id="'+data.id+'" data-category-id="'+categoryId+'">'+
		'<a href="javascript:;" data-url="'+catUrl+'" class="brand_go" onclick="fn_link(this)">'+
			'<div class="list_num '+ numClass +'">'+idx+'</div>'+
			'<h1 class="re_b_tit">'+data.site_meta_eng_nm+'</h1>'+
			'<h2 class="re_s_tit">'+data.site_meta_korean_nm+'</h2>'+
			
			'<span class="result_num" data-catUrl="'+catUrl+'">';
				if(data.category){
					var gender = "";
					if(data.category.ctg_meta_gender_tag){
						gender = data.category.ctg_meta_gender_tag +"\'s > ";
					}
					var catName = "";
					if(data.category.ctg_meta_site_cat_nm){
						catName = data.category.ctg_meta_site_cat_nm +"";
					}

					// 08.30 경우의 수 추가 
					if(!gender && !catName){
						gender = data.site_meta_eng_nm+" > ";
						catName = "Home";
					}else if(gender && !catName){
						gender = data.category.ctg_meta_gender_tag +"\'s ";
					}
					
					var length = "";
					if(data.category.products.length > 0){
						length = "<em>"+fn_overMillionProd(data.category._products_total_count)+'</em>개 상품</span>';
					}
					setVal += '<span class="bu_type">'+ firstUpperCase(gender) +'' + firstUpperCase(catName) + '</span><span class="prod_num">'+length;
				} else {
					var gender = data.site_meta_eng_nm+" > ";
					var catName = "Home";
					setVal += '<span class="bu_type">'+ firstUpperCase(gender) +'' + firstUpperCase(catName) + '</span>';
				}
			setVal += '</span>'+
		'</a>'+
				
		'<div class="result_introduce">'+
			'<p class="introduce">' + fn_removeDoubleMark(data.site_meta_site_desc) + '</p>'+
			'<p class="line_tip">'+liTag+'</p>'+
		'</div>'+
		
		'<div class="thumb_box">';
		if (data.category && data.category.products.length >0){
			setVal += '<ul class="scroll">';
				for(var i in data.category.products){
					if (i > 19){
						break;
					}
					var thisProd = data.category.products[i];
					var thisImg = thisProd.product_item_img;
					//image 경로 시작이 http -> 상대주소입니다. 이미지
					if (thisImg){
						if ($.trim(thisImg).length == 0){
							thisImg = "../resources/images/sub/no_img.png";
							//break;
						}
					} else {
						thisImg = "../resources/images/sub/no_img.png";
						//break;
					}
					
					var price = 0;
					var priceC;
					var parsePrice;
					if (thisProd.product_item_price_original_c){
						if (thisProd.product_item_price_sale_c){
							priceC = thisProd.product_item_price_sale_c.split(',');
						} else {
							priceC = thisProd.product_item_price_original_c.split(',');
						}
					} else {
						if (thisProd.product_item_price_sale_c){
							priceC = thisProd.product_item_price_sale_c.split(',');
						}
					}
					if (priceC){
						var matCountry = matchCountry(priceC[1]);
						var comPrice = fn_addComma(priceC[0]);
						
						var num_check=/^\d+(?:[.]?[\d]?[\d])?$/; 
						if(priceC[0].length<1 || priceC[1].length<1){
							price = "-";
						} else{
							if(num_check.test(priceC[0]) && priceC[0] > 0){
								if(matCountry == ""){
									price = "-";
								} else {
									price = matCountry + comPrice;
								}
							}else {
								price="-";
							}
						}
					} else {
						price = "-";
					}
					var priceLength = price.replace(/[\0-\x7f]|([0-\u07ff]|(.))/g,"$&$1$2").length;
					if(priceLength >= 20){
						price="-";
					}
					
					var productPageUrlFull = thisProd.product_page_url_full;
					setVal += '<li>'+
						'<a href="javascript:;" data-url="'+productPageUrlFull+'" onclick="fn_link(this)" >'+
						//'<img src="'+thisImg+'" onError="this.src=\'../resources/images/@/demo/img_abnormal.png\'" />'+
						'<img src="'+thisImg+'" onError="this.src=\'../resources/images/sub/no_img.png\'" />'+
						'</a>'+
						'<p class="price">'+price+'</p>'+
					'</li>';
					//prodCnt ++;
				}
				/*
				if(prodCnt == 0){
					return "";
				}
				*/
				/**
				 * 08.02 MAX초과시 보여줌
				 */
				if( data.category.products.length >= 20 ){
					setVal += '<li>'+
							'<a href="javascript:;" class="btn_more_product gotoDetail" onclick="fn_link(this)">'+
                        '<span>더보기</span></a>'+
                        '</li>';
				}
				
			setVal += '</ul>';
			} else {
				setVal += '<p class="none_product">이미지 준비 중입니다.</p>';
			}
		
			var category = data.category;
			var likeClassName =  "";
			var ctg_cnt = 0;
			var bookmarkClassName =  "";
			var likeSiteCatSq = "";
			var heartClass = "btn_heart_no";
			if(category){
				if(category.ctg_is_like == "Y"){
					likeClassName = "on";
				}else{
					likeClassName = "";
				}
				
				if(category.ctg_is_bookmark == "Y"){
					bookmarkClassName = "on";
				}else{
					bookmarkClassName = "";
				}
				
				ctg_cnt = fn_overMilion(Number(category.ctg_cnt));
				if(ctg_cnt == 0){
					ctg_cnt = "";
					heartClass = "btn_heart_no";
				}else {
					heartClass = "btn_heart";
				}
				likeSiteCatSq = category.likeSiteCatSq;
			}
			
			setVal += '</div>'+
			' <div class="result_btn_all">'+
			    '<button type="button" class="'+heartClass+' '+likeClassName+'" data-like-site-cat-sq="'+likeSiteCatSq+'"><span>'+ctg_cnt+'</span></button>'+
	            '<button type="button" class="btn_bookmark '+bookmarkClassName+'">bookmark</button>'+
	            '<button type="button" class="btn_share">공유하기</button>'+
	            '<a href="javascript:;" class="btn_detail gotoDetail" onclick="fn_link(this)"><span>상세보기</span></a>'+
	        '</div>'+
		'</div>';
		return setVal;
	},
	set2 : function(data){
		
		var liTag = "";
		if (data.site_meta_promotion_info == null){
			data.site_meta_promotion_info = "";
		}
		if (data.site_meta_promotion_info.length > 0){
			liTag += data.site_meta_promotion_info;
		}
		if ( data.site_meta_direct_delivery == "true" ){
			liTag += "<span>직배송</span>";
		}
		
		if (data.site_meta_free_delivery == "true"){
			liTag += "<span>";
			var desc = data.site_meta_free_delivery_description;
			if (desc){
				liTag += desc;
				if (!desc.indexOf(/무료 배송|무료배송/)){
					liTag += "무료배송";
				}
			} else {
				liTag += "무료배송";
			}
			liTag += "</span>";
		}
		
		if (data.site_meta_checkout_card != null){
			var cardArr = data.site_meta_checkout_card.split(';');
		}
		
		if(cardArr.length >0){
			//cardInfo Add
			liTag += "<span>";
			for(var i in cardArr){
				liTag += cardArr[i];
				if(i != cardArr.length-1){
					liTag += "/";
				}
			}
			liTag += "</span>";
		}
		
		var catUrl = "";
		if(data.category && data.category["ctg_meta_site_cat_url"]){
			catUrl = data.category["ctg_meta_site_cat_url"];
			if(catUrl.length < 1){
				if(data.site_meta_landing_url){
					catUrl = data.site_meta_landing_url;			
				}
			}
		}
		
		var angle;
		if(data.site_region == "domestic"){
			if (data.site_duration == 1){
				angle = data.site_domestic_1m_angle;
			}
			else if (data.site_duration == 3){
				angle = data.site_domestic_3m_angle;
			}
			else if (data.site_duration == 6){
				angle = data.site_domestic_6m_angle;
			}
		}else if (data.site_region == "international"){
			if (data.site_duration == 1){
				angle = data.site_international_1m_angle;
			}
			else if (data.site_duration == 3){
				angle = data.site_international_3m_angle;
			}
			else if (data.site_duration == 6){
				angle = data.site_international_6m_angle;
			}
		}
		var graType = "";
		var angleText = "";
		if ( angle > 80 ){
			angleText = "80˚ ~";
			graType = "01";
		}else if ( angle > 60 ){
			angleText = "60˚~80˚";
			graType = "02";
		}else {
			angleText = "30˚~60˚";
			graType = "03";
		}
		
		var categoryId =  "";
		if(data.category && data.category.id){
			categoryId = data.category.id;
		}else{
		}
		
		var setVal = '<div class="result_box type01 new" data-site-id="'+data.id+'" data-category-id="'+categoryId+'">'+
		'<a href="javascript:;" data-url="'+catUrl+'" class="brand_go" onclick="fn_link(this)">'+
			'<div class="graph_area'+graType+'">'+
				'<div class="line_type_graph'+graType+'">'+
					'<span class="arrow_move'+graType+'"></span>'+
					'<span class="arrow_line'+graType+'" data-angle="'+angle+'"></span>'+
				'</div>'+
				'<p class="line_numerical'+graType+'">'+angleText+'</p>'+
			'</div>'+
			
			'<h1 class="re_b_tit">'+data.site_meta_eng_nm+'</h1>'+
			'<h2 class="re_s_tit">'+data.site_meta_korean_nm+'</h2>'+
		
		'<span class="result_num" data-catUrl="'+catUrl+'">';
		if(data.category){
			var gender = "";
			if(data.category.ctg_meta_gender_tag){
				gender = data.category.ctg_meta_gender_tag +"\'s > ";
			}
			var catName = "";
			if(data.category.ctg_meta_site_cat_nm){
				catName = data.category.ctg_meta_site_cat_nm +"";
			}
			
			// 08.30 경우의 수 추가 
			if(!gender && !catName){
				gender = data.site_meta_eng_nm+" > ";
				catName = "Home";
			}else if(gender && !catName){
				gender = data.category.ctg_meta_gender_tag +"\'s ";
			}
			
			var length = "";
			if(data.category.products.length > 0){
				length = "<em>"+fn_overMillionProd(data.category._products_total_count)+'</em>개 상품</span>';
			}
			setVal += '<span class="bu_type">'+ firstUpperCase(gender) +'' + firstUpperCase(catName) + '</span><span class="prod_num">'+length;
		} else {
			var gender = data.site_meta_eng_nm+" > ";
			var catName = "Home";
			setVal += '<span class="bu_type">'+ firstUpperCase(gender) +'' + firstUpperCase(catName) + '</span>';
		}
		setVal += '</span>'+
		'</a>';
		
		setVal += '<div class="result_introduce">'+
		'<p class="introduce">' + fn_removeDoubleMark(data.site_meta_site_desc) + '</p>'+
		'<p class="line_tip">' + liTag + '</p>'+
		'</div>'+
		'</a>'+
		'<div class="thumb_box">';
		if(data.category && data.category.products.length>0){
			setVal += '<ul class="scroll">';
			for(var i in data.category.products){
				if (i > 19){
					break;
				}
				var thisProd = data.category.products[i];
				var thisImg = thisProd.product_item_img;
				//image 경로 시작이 http -> 상대주소입니다. 이미지
				if (thisImg){
					if ($.trim(thisImg).length == 0){
						thisImg = "../resources/images/sub/no_img.png";
					}
				} else {
					thisImg = "../resources/images/sub/no_img.png";
				}

				var price = 0;
				var priceC;
				var parsePrice;
				if (thisProd.product_item_price_original_c){
					if (thisProd.product_item_price_sale_c){
						priceC = thisProd.product_item_price_sale_c.split(',');
					} else {
						priceC = thisProd.product_item_price_original_c.split(',');
					}
				} else {
					if (thisProd.product_item_price_sale_c){
						priceC = thisProd.product_item_price_sale_c.split(',');
					}
				}
				if (priceC){
					var matCountry = matchCountry(priceC[1]);
					var comPrice = fn_addComma(priceC[0]);
					
					var num_check=/^\d+(?:[.]?[\d]?[\d])?$/; 
					if(priceC[0].length<1 || priceC[1].length<1){
						price = "-";
					} else{
						if(num_check.test(priceC[0]) && priceC[0] > 0){
							if(matCountry == ""){
								price = "-";
							} else {
								price = matCountry + comPrice;
							}
						}else {
							price="-";
						}
					}
				} else {
					price = "-";
				}
				var priceLength = price.replace(/[\0-\x7f]|([0-\u07ff]|(.))/g,"$&$1$2").length;
				if(priceLength > 20){
					price="-";
				}

				var productPageUrlFull = thisProd.product_page_url_full;
				setVal += '<li>'+
					'<a href="javascript:;" data-url="'+productPageUrlFull+'" onclick="fn_link(this)">'+
					//'<img src="'+thisImg+'" onError="this.src = \'../resources/images/@/demo/img_abnormal.png\'" />'+
					'<img src="'+thisImg+'" onError="this.src=\'../resources/images/sub/no_img.png\'" />'+
					'</a>'+
					'<p class="price">'+price+'</p>'+
				'</li>';
			}
			/**
			 * 07.24 15개 이상일경우 보여줌
			 */
			if( data.category.products.length >= 20 ){
				setVal += '<li>'+
				'<a href="javascript:;" class="btn_more_product gotoDetail" onclick="fn_link(this)">'+
                '<span>더보기</span></a>'+
                '</li>';
			}
			
			setVal += '</ul>';
		} else {
			setVal += '<p class="none_product">이미지 준비 중입니다.</p>';
			//return "";
		}
		
		var category = data.category;
		var likeClassName =  "";
		var ctg_cnt = 0;
		var bookmarkClassName =  "";
		var likeSiteCatSq = "";
		var heartClass = "btn_heart_no";
		if(category){
			if(category.ctg_is_like == "Y"){
				likeClassName = "on";
			}else{
				likeClassName = "";
			}
			
			if(category.ctg_is_bookmark == "Y"){
				bookmarkClassName = "on";
			}else{
				bookmarkClassName = "";
			}
			
			ctg_cnt = fn_overMilion(Number(category.ctg_cnt));
			if(ctg_cnt == 0){
				ctg_cnt = "";
				heartClass = "btn_heart_no";
			}else {
				heartClass = "btn_heart";
			}
			likeSiteCatSq = category.likeSiteCatSq;
		}
		
		setVal += '</div>'+
		'<div class="result_btn_all">'+
		'<button type="button" class="'+heartClass+' '+likeClassName+'" data-like-site-cat-sq="'+likeSiteCatSq+'"><span>'+ctg_cnt+'</span></button>'+
		'<button type="button" class="btn_bookmark '+bookmarkClassName+'">bookmark</button>'+
		'<button type="button" class="btn_share">공유하기</button>'+
		'<a href="javascript:;" class="btn_detail gotoDetail" onclick="fn_link(this)"><span>상세보기</span></a>'+
		'</div>'+
		
		'</div>';
		return setVal;
	},
	set3 : function(data){
		
		var liTag = "";
		if (data.site_meta_promotion_info == null){
			data.site_meta_promotion_info = "";
		}
		if (data.site_meta_promotion_info.length > 0){
			liTag += data.site_meta_promotion_info;
		}
		if ( data.site_meta_direct_delivery == "true" ){
			liTag += "<span>직배송</span>";
		}
		
		if (data.site_meta_free_delivery == "true"){
			liTag += "<span>";
			var desc = data.site_meta_free_delivery_description;
			if (desc){
				liTag += desc;
				if (!desc.indexOf(/무료 배송|무료배송/)){
					liTag += "무료배송";
				}
			} else {
				liTag += "무료배송";
			}
			liTag += "</span>";
		}
		
		if (data.site_meta_checkout_card != null){
			var cardArr = data.site_meta_checkout_card.split(';');
		}
		
		if(cardArr.length >0){
			//cardInfo Add
			liTag += "<span>";
			for(var i in cardArr){
				liTag += cardArr[i];
				if(i != cardArr.length-1){
					liTag += "/";
				}
			}
			liTag += "</span>";
		}
		
		var catUrl = "";
		if(data.category && data.category["ctg_meta_site_cat_url"]){
			catUrl = data.category["ctg_meta_site_cat_url"];
			if(catUrl.length < 1){
				if(data.site_meta_landing_url){
					catUrl = data.site_meta_landing_url;			
				}
			}
		}
		
		var categoryId =  "";
		if(data.category && data.category.id){
			categoryId = data.category.id;
		}else{
		}
		
		var setVal = '<div class="result_box type02 new" data-site-id="'+data.id+'" data-category-id="'+categoryId+'">'+
		'<a data-url="'+catUrl+'" class="brand_go" onclick="fn_link(this)">'+
		'<div class="graph_area">'+
			'<div class="circle_type">'+
				'<div class="ani-circle" data-matching="'+(data.site_matching * 100)+'"></div>'+
			'</div>'+
			'<div class="percent">%</div>'+
		'</div>'+
		
		'<h1 class="re_b_tit">'+data.site_meta_eng_nm+'</h1>'+
		'<h2 class="re_s_tit">'+data.site_meta_korean_nm+'</h2>'+
		
		'<span class="result_num" data-catUrl="'+catUrl+'">';
		if(data.category){
			var gender = "";
			if(data.category.ctg_meta_gender_tag){
				gender = data.category.ctg_meta_gender_tag +"\'s > ";
			}
			var catName = "";
			if(data.category.ctg_meta_site_cat_nm){
				catName = data.category.ctg_meta_site_cat_nm +"";
			}
			
			// 08.30 경우의 수 추가 
			if(!gender && !catName){
				gender = data.site_meta_eng_nm+" > ";
				catName = "Home";
			}else if(gender && !catName){
				gender = data.category.ctg_meta_gender_tag +"\'s ";
			}
			
			var length = "";
			if(data.category.products.length > 0){
				length = "<em>"+fn_overMillionProd(data.category._products_total_count)+'</em>개 상품</span>';
			}
			setVal += '<span class="bu_type">'+ firstUpperCase(gender) +'' + firstUpperCase(catName) + '</span><span class="prod_num">'+length;
		} else {
			var gender = data.site_meta_eng_nm+" > ";
			var catName = "Home";
			setVal += '<span class="bu_type">'+ firstUpperCase(gender) +'' + firstUpperCase(catName) + '</span>';
		}
		setVal += '</span> </a>'+
		
		'<div class="result_introduce">'+
		'<p class="introduce">' + fn_removeDoubleMark(data.site_meta_site_desc) + '</p>'+
		'<p class="line_tip">' + liTag + '</p>'+
		'</div>'+
		
		'<div class="thumb_box">';
		if(data.category && data.category.products.length>0){
			setVal += '<ul class="scroll">';
			//var prodCnt = 0;
			for(var i in data.category.products){
				if (i > 19){
					break;
				}
				var thisProd = data.category.products[i];
				var thisImg = thisProd.product_item_img;
				//image 경로 시작이 http -> 상대주소입니다. 이미지
				if (thisImg){
					if ($.trim(thisImg).length == 0){
						thisImg = "../resources/images/sub/no_img.png";
						//break;
					}
				} else {
					thisImg = "../resources/images/sub/no_img.png";
					//break;
				}

				var price = 0;
				var priceC;
				var parsePrice;
				if (thisProd.product_item_price_original_c){
					if (thisProd.product_item_price_sale_c){
						priceC = thisProd.product_item_price_sale_c.split(',');
					} else {
						priceC = thisProd.product_item_price_original_c.split(',');
					}
				} else {
					if (thisProd.product_item_price_sale_c){
						priceC = thisProd.product_item_price_sale_c.split(',');
					}
				}
				if (priceC){
					var matCountry = matchCountry(priceC[1]);
					var comPrice = fn_addComma(priceC[0]);
					
					var num_check=/^\d+(?:[.]?[\d]?[\d])?$/; 
					if(priceC[0].length<1 || priceC[1].length<1){
						price = "-";
					} else{
						if(num_check.test(priceC[0]) && priceC[0] > 0){
							if(matCountry == ""){
								price = "-";
							} else {
								price = matCountry + comPrice;
							}
						}else {
							price="-";
						}
					}
				} else {
					price = "-";
				}
				var priceLength = price.replace(/[\0-\x7f]|([0-\u07ff]|(.))/g,"$&$1$2").length;
				if(priceLength > 20){
					price="-";
				}
				
				var productPageUrlFull = thisProd.product_page_url_full;
				setVal += '<li>'+
					'<a href="javascript:;" data-url="'+productPageUrlFull+'" onclick="fn_link(this)">'+
					//'<img src="'+thisImg+'" onError="this.src=\'../resources/images/@/demo/img_abnormal.png\'" />'+
					'<img src="'+thisImg+'" onError="this.src=\'../resources/images/sub/no_img.png\'" />'+
					'</a>'+
					'<p class="price">'+price+'</p>'+
				'</li>';
				//prodCnt ++;
			}
			/*
			if(prodCnt < 1){
				return "";
			}
			*/
			/**
			 * 07.24 15개 이상일경우 보여줌
			 */
			if( data.category.products.length >= 20 ){
				setVal += '<li>'+
				'<a href="javascript:;" class="btn_more_product gotoDetail" onclick="fn_link(this)">'+
                '<span>더보기</span></a>'+
                '</li>';
			}
			
			setVal += '</ul>';
		} else {
			setVal += '<p class="none_product">이미지 준비 중입니다.</p>';
			//return "";
		}
		
		var category = data.category;
		var likeClassName =  "";
		var ctg_cnt = 0;
		var bookmarkClassName =  "";
		var likeSiteCatSq = "";
		var heartClass = "btn_heart_no";
		if(category){
			if(category.ctg_is_like == "Y"){
				likeClassName = "on";
			}else{
				likeClassName = "";
			}
			
			if(category.ctg_is_bookmark == "Y"){
				bookmarkClassName = "on";
			}else{
				bookmarkClassName = "";
			}
			
			ctg_cnt = fn_overMilion(Number(category.ctg_cnt));
			if(ctg_cnt == 0){
				ctg_cnt = "";
				heartClass = "btn_heart_no";
			} else {
				heartClass = "btn_heart";
			}
			likeSiteCatSq = category.likeSiteCatSq;
		}
		
		setVal += '</div>'+
		'<div class="result_btn_all">'+
		'<button type="button" class="'+heartClass+' '+likeClassName+'" data-like-site-cat-sq="'+likeSiteCatSq+'"><span>'+ctg_cnt+'</span></button>'+
		'<button type="button" class="btn_bookmark '+bookmarkClassName+'">bookmark</button>'+
		'<button type="button" class="btn_share">공유하기</button>'+
		'<a href="javascript:;" class="btn_detail gotoDetail" onclick="fn_link(this)"><span>상세보기</span></a>'+
		'</div>'+
		'</div>';
		return setVal;
	}
}

var resultNone = {
		//filter 검색결과 없을경우
		set : function (reqdata, fltCd){
			var srchTab = "";
			if (reqdata.searchKind == "1"){
				srchTab = "인기있는";
			} else if (reqdata.searchKind == "2") {
				srchTab = "최근뜨는";
			} else if (reqdata.searchKind == "3") {
				srchTab = "내게맞는";
			}
			var setVal = '<div class="keyword_box">'+
	            '<div class="keyword_area">'+
		            '<div class="keyword_search">';
					if(fltCd.length > 0){
						setVal += '<p>'+srchTab+' <strong>"'+ reqdata.query +'"</strong></p>'+
                        '<p>';
						for(var i in fltCd){
							var fltCdVal = fltCd[i];
							//임시
							if(fltCdVal == "W"){
								fltCdVal = "여성";
							} else if(fltCdVal == "M"){
								fltCdVal = "남성";
							} else if(fltCdVal == "K"){
								fltCdVal = "키즈";
							}
							
							//마지막일경우는 , 생략 
							if(i != fltCd.length-1){
								fltCdVal += ", ";
							}
							
							setVal +='<span>'+fltCdVal+' </span>';
						}
                        setVal +='의<br />검색결과가 없습니다.</p>';
					}else {
						setVal +='<p>' + srchTab + '<strong>"'+ reqdata.query +'"</strong>에 대한</p>검색결과가 없습니다.</p>'+
						'<p>- 단어의 철자가 정확한지 확인해보세요.<br />- 패션 관련 검색어를 입력해보세요.</p>';
					}
		                
		            setVal +='</div>'+
		        '</div>'+
		    '</div>';
			
			return setVal;
		}
}

/**
 * 상세화면 Category
 * @param data
 * @returns String
 */
function appendCat(data, siteNm){
	var rdata = data.resultData.data;
	console.log(rdata);
	var reVal = "";
	for(var i in rdata.rows){
		reVal += appendCatVal.set(rdata.rows[i], data.resultData.query, siteNm);
	}
	
	return reVal;
}

var appendCatVal = {
		set : function (data, query, siteNm){
			var catNm = "";
			if (data.ctg_meta_site_cat_nm){
				catNm = data.ctg_meta_site_cat_nm;
			}
			
			var likeClassName =  "";
			var ctg_cnt = 0;
			var bookmarkClassName =  "";
			var likeSiteCatSq = "";
			var heartClass ="";
			if(data.ctg_is_like == "Y"){
				likeClassName = "on";
			}else{
				likeClassName = "";
			}
			
			if(data.ctg_is_bookmark == "Y"){
				bookmarkClassName = "on";
			}else{
				bookmarkClassName = "";
			}
			
			ctg_cnt = fn_overMilion(Number(data.ctg_cnt));
			if(ctg_cnt == 0){
				ctg_cnt = "";
				heartClass = "btn_heart_no";
			} else {
				heartClass = "btn_heart";
			}
			likeSiteCatSq = data.id;
			
			var reVal = '<div class="bridge_num" onclick="hcca_showWebView('+data.ctg_meta_site_cat_url+','+query+')">';
			
            if(data && data.ctg_meta_gender_tag){
            		if(catNm == ""){
            			reVal += '<a href="javascript:;" class="bu_type">'+firstUpperCase(data.ctg_meta_gender_tag)+'\'s </a>'+
            			'<p class="prod_num"><em>'+ fn_overMillionProd(data._products_total_count) +'</em>개 상품</p>';
            		}else{
            			reVal += '<a href="javascript:;" class="bu_type">'+firstUpperCase(data.ctg_meta_gender_tag)+'\'s > '+firstUpperCase(catNm)+'</a>'+
            			'<p class="prod_num"><em>'+ fn_overMillionProd(data._products_total_count) +'</em>개 상품</p>';
            		}
            }else {
	            	if(catNm == ""){
	            		reVal += '<a href="javascript:;" class="bu_type">'+firstUpperCase(siteNm)+' > '+firstUpperCase("Home")+'</a>'+
	            		'<p class="prod_num"><em>'+ fn_overMillionProd(data._products_total_count) +'</em>개 상품</p>';
	            	}else {
	            		reVal += '<a href="javascript:;" class="bu_type">'+firstUpperCase(catNm)+'</a>'+
	            		'<p class="prod_num"><em>'+ fn_overMillionProd(data._products_total_count) +'</em>개 상품</p>';
	            	}
            }
                reVal += '</div>';
            if(data.products.length > 0){
    
            	reVal +='<div class="thumb_box new">'+
                    '<ul class="scroll">';
                	
                //var prodCnt = 0;
	                	for(var i in data.products){
						var thisProd = data.products[i];
						var thisImg = thisProd.product_item_img;
						//image 경로 시작이 http -> 상대주소입니다. 이미지
						if (thisImg){
							if ($.trim(thisImg).length == 0){
								thisImg = "../resources/images/sub/no_img.png";
								//break;
							}
						} else {
							thisImg = "../resources/images/sub/no_img.png";
							//break;
						}
						
						var price = "";
						var salePrice = "";
						var priceC;
						if (thisProd.product_item_price_original_c){
							priceC = thisProd.product_item_price_original_c.split(',');
							if (priceC){
								var matCountry = matchCountry(priceC[1]);
								var comPrice = fn_addComma(priceC[0]);
								
								var num_check=/^\d+(?:[.]?[\d]?[\d])?$/; 
								if(priceC[0].length<1 || priceC[1].length<1){
									price = "-";
								} else{
									if(num_check.test(priceC[0]) && priceC[0] > 0){
										if(matCountry == ""){
											price = "-";
										} else {
											price = matCountry + comPrice;
										}
									}else {
										price="-";
									}
								}
							}
						}
						if (thisProd.product_item_price_sale_c){
							priceC = thisProd.product_item_price_sale_c.split(',');
							if (priceC){
								var matCountry = matchCountry(priceC[1]);
								var comPrice = fn_addComma(priceC[0]);
								
								var num_check=/^\d+(?:[.]?[\d]?[\d])?$/; 
								if(priceC[0].length<1 || priceC[1].length<1){
									salePrice = "-";
								} else{
									if(num_check.test(priceC[0]) && priceC[0] > 0){
										if(matCountry == ""){
											salePrice = "-";
										} else {
											salePrice = matCountry + comPrice;
										}
									}else {
										salePrice="-";
									}
								}
							}
						}
						var appendPriceTag = "";
						var priceLength = price.replace(/[\0-\x7f]|([0-\u07ff]|(.))/g,"$&$1$2").length;
						var salePriceLength = salePrice.replace(/[\0-\x7f]|([0-\u07ff]|(.))/g,"$&$1$2").length;
						if (priceLength > 20) {
							price = null;
						}
						if ( salePriceLength > 20) {
							salePrice = null;
						}
						
						if(price && salePrice && price != '-' && salePrice != '-'){
							appendPriceTag = '<p class="price"><del>'+price+'</del></p>'+
							'<p class="infoPrice">'+salePrice+'</p>';
						} else if(price && !salePrice && price != '-'){
							appendPriceTag = '<p class="price">'+price+'</p>';
						} else if(!price && salePrice && salePrice != '-'){
							appendPriceTag = '<p class="price">'+salePrice+'</p>';
						} else {
							appendPriceTag = '<p class="price">-</p>';
						}
						
						var productPageUrlFull = thisProd.product_page_url_full;
						reVal += '<li><a href="javascript:;" onclick="hcca_showWebView('+productPageUrlFull+','+siteNm+')">'+
							'<img src="'+thisImg+'" onError="this.src=\'../resources/images/sub/no_img.png\'" /></a>'+
							appendPriceTag+
						'</li>';
						//prodCnt ++;
					}
	                	/*
	                	if(prodCnt < 1){
	                		return "";
	                	}
	                	*/
                } else {
                		reVal += '<p class="none_product">이미지 준비 중입니다.</p>';
	        			//return "";
	        		}
            reVal +=   '</ul>'+
                 '</div>';
                	
                	
            reVal += '<div class="bridge_btn_all" data-catSq="'+data.id+'">'+
			    		'<button type="button" class="'+heartClass+' '+likeClassName+'" onclick="btnHeartClick(this)" data-like-site-cat-sq="'+likeSiteCatSq+'"><span>'+ctg_cnt+'</span></button>'+
			    		'<button type="button" class="btn_bookmark '+bookmarkClassName+'">bookmark</button>'+    
                    '<button type="button" class="btn_share">공유하기</button>'+
                '</div>'+
            '</div>';
			
            return reVal;
		}
};

function appendQuestion(data){
	if(!data.resultData){
		return false;
	}
	var returnVal = "<div class='survey_area' data-surveySq="+data.resultData[0].surveySq+">"+
    "<div class='survey_info'>"+
        "<h1>내게맞는 검색 - 일반형</h1>"+
        "<p>쇼핑성향 분석<br/>아래 4가지 설문에 대한 답변을 모두 완료하고<br />맞춤 검색 결과를 받아보세요.</p>"+
    "</div>";
    
	for(var i in data.resultData){
		var answerType = data.resultData[i].answerTypeCd;
		if(answerType == '10'){ //객관식 단일선택 
			returnVal += addQuestion.set1(i, data.resultData[i]);
			
		} else if(answerType == '20'){ // 객관식 복수선택 
			returnVal += addQuestion.set2(i, data.resultData[i]);
			
		} else if(answerType == '30'){ // 주관식 
			returnVal += addQuestion.set3(i, data.resultData[i]);
			
		}
	}
	returnVal += '<button type="button" class="btn_submit" onclick="btnQueSubmit()">설문 완료하기</button>'+
		"</div>";
	return returnVal;
}

var addQuestion = {
	set1 : function (idx, data) {
		idx ++;
		if(idx < 10){
			idx = "0"+idx;
		}
		var addVal = "<dl id='survey"+idx+"' data-que-type='"+data.questionTypeCd+"' data-answer-type='"+data.answerTypeCd+"' data-que-sq='"+data.questionSq+"' >"+
		'<dt><span class="num">'+idx+'</span><span class="title">'+data.questionTitle +'</span></dt>';
		
		for(var i in data.choiceList){
			var choice = data.choiceList[i];
			if (choice.etcFlagYn == 'N'){
				addVal += '<dd data-choice-sq="'+choice.choiceSeq+'">'+
				'<input type="checkbox" id="survey'+idx+'_0'+i+'" name="survey'+idx+'" data-choice-val="'+choice.choiceVal+'" class="check" data-etc-flag="N" onclick="iptChkType10(this)"/><label for="survey'+idx+'_0'+i+'"><span></span>'+choice.choiceText+'</label>'+
				'</dd>';
			} else {
				addVal += '<dd data-choice-sq="'+choice.choiceSeq+'">'+
				'<input type="checkbox" id="survey'+idx+'_0'+i+'" name="survey'+idx+'" data-choice-val="'+choice.choiceVal+'" class="check" data-etc-flag="Y" onclick="iptChkType10(this)"/><label for="survey'+idx+'_0'+i+'"><span></span>'+choice.choiceText+'</label>'+
				'</dd>'+
				'<dd class="etc">'+
					'<input type="text" placeholder="직접 입력해 주세요." class="surveyEtcVal"/>'+
				'</dd>';
			}
		}
		addVal += "</dl>";
		return addVal;
	},
	set2 : function (idx, data) {
		idx ++;
		if(idx < 10){
			idx = "0"+idx;
		}
		var addVal = "<dl id='survey"+idx+"' data-que-type='"+data.questionTypeCd+"' data-answer-type='"+data.answerTypeCd+"' data-que-sq='"+data.questionSq+"'>"+
		'<dt><span class="num">'+idx+'</span><span class="title">'+data.questionTitle +'</span></dt>';
		
		for(var i in data.choiceList){
			var choice = data.choiceList[i];
			if (choice.etcFlagYn == 'N'){
				addVal += '<dd data-choice-sq="'+choice.choiceSeq+'">'+
				'<input type="checkbox" id="survey'+idx+'_0'+i+'" name="survey'+idx+'" data-choice-val="'+choice.choiceVal+'" class="check" data-etc-flag="N"/><label for="survey'+idx+'_0'+i+'"><span></span>'+choice.choiceText+'</label>'+
				'</dd>';
			} else {
				addVal += '<dd data-choice-sq="'+choice.choiceSeq+'">'+
				'<input type="checkbox" id="survey'+idx+'_0'+i+'" name="survey'+idx+'" data-choice-val="'+choice.choiceVal+'" class="check" data-etc-flag="Y"/><label for="survey'+idx+'_0'+i+'"><span></span>'+choice.choiceText+'</label>'+
				'</dd>'+
				'<dd class="etc">'+
					'<input type="text" placeholder="직접 입력해 주세요." class="surveyEtcVal"/>'+
				'</dd>';
			}
		}
		
		addVal += "</dl>";
		
		return addVal;
	},
	set3 : function (idx, data) {
		idx ++;
		if(idx < 10){
			idx = "0"+idx;
		}
		var addVal = "<dl id='"+"survey"+idx+"' data-que-type='"+data.questionTypeCd+"' data-answer-type='"+data.answerTypeCd+"' data-que-sq='"+data.questionSq+"'>"+
        '<dt><span class="num">'+idx+'</span><span class="title">'+data.questionTitle+'</span></dt>'+
        '<dd class="etc">'+
	        '<input type="text" id="brandSearch" name="brandSearch" placeholder="예)망고" />'+
	        '<button type="button" class="btn_brand_delete">삭제</button>'+
	        '<div class="brand_search_down">'+
	            '<div class="brand_search_down_in">'+
			        '<p class="txt">아래 브랜드 중에 선택해 주세요.</span></p>'+
	                '<ul>'+
	                    '<li class="add" onclick="addBrand(this)"><a><em></em> 추가하기</a></li>'+
	                '</ul>'+
	            '</div>'+
	        '</div>'+
	    '</dd>'+
        //<dd class="survey_list" style="display:block;">식스피<button type="button" class="del">삭제</button></dd>
    '</dl>';
		return addVal;
	}
};

function addReview(reviewList){
	var reviewSet = "";
	if (reviewList && reviewList.length>0){
		for(var i in reviewList){
			var thisEntity = reviewList[i];
			reviewSet += '<dl data-uuid="'+thisEntity.uuid+'" data-reviewSq="'+thisEntity.reviewSiteSq+'" class="new">'+
			'<dt><span name="memberIdSq" class="name">'+ thisEntity.userId +'</span>'+
				'<span class="star_s" data-grade="'+thisEntity.grade+'">'+
					'<em>01</em>'+
					'<em>02</em>'+
					'<em>03</em>'+
					'<em>04</em>'+
					'<em>05</em>'+
				'</span>'+
			'</dt>';
			var insertDt = thisEntity.insertDt;
			insertDt = insertDt.substr(0,4)+'.'+insertDt.substr(5,2)+'.'+insertDt.substr(8,2);
			reviewSet += '<dd class="date">'+insertDt+'</dd>';
			var review = thisEntity.review;
			if(review.length < 1){
				review = '<dd class="no">이 글은 주제와 무관한 내용을 포함하였습니다.</dd>';
			}
			if(thisEntity.isMine == "Y"){
				reviewSet += '<dd class="reply"><pre>' + thisEntity.review + '</pre></dd>'+
				'<button type="button" class="del">삭제</button>';
			} else {
				reviewSet += '<dd class="reply"><pre>'+ review + '</pre></dd>';
			}
			reviewSet += '</dl>';
		}
		
    } else {
        //review none
        reviewSet = '<div class="reply_none">현재 작성된 리뷰가 없습니다.<br />가장 처음 리뷰를 작성해 볼까요??</div>';
    }
	
	return reviewSet;
}


function fn_overMilion(score){
	if (score >= 10000){ //10000 이상일경우 ex) 12000 -> 1.2K
		score = (score/10000).toFixed(1)+"K";
	} else {
		score = fn_addComma(score+"");
	}
	return score;
}

function fn_overMillionProd(count){
	if(count > 10000){
		return "9999+";
	} else {
		return count;
	}
}

//3자리마다 , 
function fn_addComma(str) {
    return str.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

//첫번째, 마지막인덱스 쌍따움표 제거 
function fn_removeDoubleMark(str){
	var cnt = str.length;
	if("\"" == str.charAt(0) && "\"" == str.charAt(cnt-1)){
		return str.substring(1,cnt-1);
	}
	return str;
}

//첫번째 대문자로
function firstUpperCase(str){
	if(str && str != ""){
		return str.charAt(0).toUpperCase() + str.substring(1);
	}
	return str;
}

function matchCountry(country){
	var reVal = "";
	if(country){
		if(country == "USD"){
			reVal="$";
		} else if (country == "GBP"){
			reVal = "£";
		} else if (country == "KRW"){
			reVal = "₩";
		} else if (country == "JPY"){
			reVal = "¥";
		} else if (country == "EUR"){
			reVal = "€";
		} else if (country == "CNY"){
			reVal = "¥";
		} else {
			reVal = "";
		}
	}
	return reVal;
}