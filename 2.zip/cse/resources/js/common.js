/**
 * Created by hyundai on 2017. 7. 10..
 */

var APP = {
	isDebugger : true,
	profile : "",
	contextPath : "",
	uuid : "",
	getUuid : function(){
		var uuid = "";
		if(APP.uuid != ""){
			uuid = APP.uuid;
		}else{
			APP.uuid =  "";
			hcca_getDeviceUUID(function(){
			});
			//uuid = APP.uuid;
		}
		return uuid;
	},
	hostUrl : "",
	getContextPath : function(){
		var contextPath = "";
		if(APP.contextPath != ""){
			contextPath = APP.contextPath;
		}else{
			var hostIndex = location.href.indexOf( location.host ) + location.host.length;
			APP.contextPath =  location.href.substring( hostIndex, location.href.indexOf('/', hostIndex + 1) );
			contextPath = APP.contextPath;
		}
		return contextPath;
	},
	getHostUrl : function(){
		var hostUrl = "";
		if(APP.hostUrl != ""){
			hostUrl = APP.hostUrl;
		}else{
			APP.hostUrl =  location.protocol + "//" + location.host;
			hostUrl = APP.hostUrl;
		}
		return hostUrl;
	}
};

/*
 * sleep
 */
function sleep (delay) {
   var start = new Date().getTime();
   while (new Date().getTime() < start + delay);
}

/*
 * 화면이동 
 */
function fn_goUrl(url, p) {
	var stateUrl = fn_getStateUrl();
	//console.log("stateUrl >> " + stateUrl);
	history.replaceState(history.state, stateUrl,"");
	
	if(p){
		if(typeof(p) == 'string' || p instanceof String){
			window.location.href = url + "?" + p;
			return;
		}else if(p instanceof Array){
			
		}
	}
	window.location.href = url;
}

/*
 * location search to Object 
 */
function fn_locParamSearch() {
	return (location.search != "")? JSON.parse('{"' + location.search.substring(1).replace(/&/g, "\",\"").replace(/=/g, "\":\"") + '"}') : {};
}

/*
 * page의 현재 상태를 url에 추가 합니다.  
 *   검색결과,
 *   상세,
 *   북마크
 */
function fn_getStateUrl() {
	
	var searchMap =  fn_locParamSearch();
	var page = fn_getPageName();
	
	//검색결과 페이지 
	if(page.startsWith("/search/search0101")){
		
		//param add
		searchMap["share"] = "Y";
		searchMap["page"] = "1";
		//searchMap["size"] = '<spring:eval expression="@config.getCommon().getString('DEFAULT_PAGE_SIZE')"/>';
		searchMap["size"] = '20';
		
		var id = $(".sub_con div[id]:visible").attr("id");
		
		if(id == "divPupular"){
			searchMap["searchKind"] = "1";
		}else if(id == "divNewPupular"){
			searchMap["searchKind"] = "2";
			searchMap["duration"] = $('.popup_content .w33 a.on').text().replace("개월","");
			
			if($('.popup_content .w50 a.on').text() == "국내"){
				searchMap["region"] = "domestic";
			}else{
				searchMap["region"] = "international";
			}
		}else if(id == "divPersonal"){
			searchMap["searchKind"] = "3";
		}
		
	//상세 페이지 	
	}else if(page.startsWith("/search/search0102")){
	//북마크사이트
	}else if(page.startsWith("/bookmark/bookmark")){
	}else{
	}
	
	var paramStr = "";
	if(Object.keys(searchMap).length > 0){
		for ( var e in searchMap) {
			paramStr += "&"+ e +"=" + searchMap[e];
		}
	}
	var	url = fn_getUrl();
	return  (paramStr != "")? url +  "?" + paramStr.substring(1) : url;
}

/*
 * ajax
 */
function fn_ajaxSubmit(url, data, success_callback, isloadingBar, async) {
	var queCode = "";
	if(isloadingBar){
		if(isPhone.APP()){
			hcca_showLoadingIndicator();
		}else{
			queCode = pageLoadQue();
		}
	}
	if (!success_callback) {
		success_callback = function() {};
	}
	if (!async) {
		async = true;
	} else{
		async = false;
	}

	var opt = {
		url: url,
		dataType: 'json',
		method: 'POST',
		data: data,
		async: async,
		success: function(data, textStatus, jqXHR) {
			if(data && data.resultCode != '0'){
				if(data.resultCode == '204'){
					success_callback(data);
					return;
				}
				if(data.resultMessage){
					if(data.resultCode == '402'){
						var destURL = "";
						var referrer = document.referrer;
						if (referrer && referrer != "") {
							destURL = referrer;
						} else {
							destURL = APP.getContextPath() + '/main/main0101';
						}
						hcca_showLoginView(destURL);
					}
				}else{
					if(data.resultCode == '402'){ 
						var destURL = "";
						var referrer = document.referrer;
						if (referrer && referrer != "") {
							destURL = referrer;
						} else {
							destURL = APP.getContextPath() + '/main/main0101';
						}
						hcca_showLoginView(destURL);
					}
				}
				return;
			}else{
				success_callback(data);
			}
		},
		error: function(xhr, status, err) {
			if(xhr.readyState != 0){
				console.log("xhr >> "+ JSON.stringify(xhr) + "   status >> " + status + " err >> " + err);
			}
			if(isloadingBar){
				if(isPhone.APP()){
					hcca_hideLoadingIndicator();
				}else{
					pageLoadQue(queCode);
				}
			}
		},
		
		complete: function(){
			if(isloadingBar){
				if(isPhone.APP()){
					hcca_hideLoadingIndicator();
				}else{
					pageLoadQue(queCode);
				}
			}
		}
	};

	if(jQuery.type(data) === "string"){
		opt.contentType = "application/json";
	}
	$.ajax(opt);
}

/*
 * ajax 관련 pageLoadQue
 */
function pageLoadQue(queCode) {
	var ques = $(document).data('ques');

	if (!ques) {
		$(document).data('ques', []);
		ques = $(document).data('ques');
	}

	if (queCode) {
		var queIndex = $.inArray(queCode, ques);
		if (queIndex !== -1) {
			ques.splice(queIndex, 1);
		}
	} else {
		var rnd = rand(100000, 999999);
		queCode = new Date().getTime() + '_' + rnd;

		ques.push(queCode);
	}

	if (ques.length) {
		pageLoad();
	} else {
		$.unblockUI();
	}

	return queCode;
}

/*
 * ajax 관련 rand
 */
function rand(min, max){
	var rand = Math.ceil((max - min + 1) * Math.random() + min);
	return rand;
}

/*
 * ajax 관련 pageLoad
 */
function pageLoad() {
	if (!$('.loading').length) {
		$('body').append('<img src="'+APP.getContextPath()+'/resources/images/loading.png" class="loading" style="display:none"/>');
	}

	$.blockUI({
		message: $('.loading'),
		css: {
			backgroundColor: '',
			border: 0
		},
		overlayCSS: {
			opacity: 0.5
		}
	});
}

/*
 * 페이지 네임 
 */
function fn_getPageName() {
	return location.pathname.replace(APP.getContextPath(),"");
}

/*
 * full url
 */
function fn_getUrl() {
	return location.protocol + "//" + location.host + location.pathname;
}

function fn_overMillionProd(count){
	if(count > 10000){
		return "9999+";
	} else {
		return count;
	}
}

/**
 * userAgent
 * */
var userAgent = window.navigator.userAgent;
var isPhone = {
	APP: function(){
		if(userAgent.match(/HCC_WebView/i)){
			return true;
		}
		return false;
	},
	IOS : function(){
		if(userAgent.match(/MAC OS/i)){
			return true;
		}
		return false;
	}
}

/**
 * WebViewJavascriptBridge
 */

//setup
//function setupWebViewJavascriptBridge(callback) {
//    if (window.WebViewJavascriptBridge) { return callback(WebViewJavascriptBridge); }
//    if (window.WVJBCallbacks) { return window.WVJBCallbacks.push(callback); }
//    window.WVJBCallbacks = [callback];
//    var WVJBIframe = document.createElement('iframe');
//    WVJBIframe.style.display = 'none';
//    WVJBIframe.src = 'https://__bridge_loaded__';
//    document.documentElement.appendChild(WVJBIframe);
//    setTimeout(function() { document.documentElement.removeChild(WVJBIframe) }, 0)
//}

function setupWebViewJavascriptBridge(callback) {
    if (window.WebViewJavascriptBridge) { return callback(WebViewJavascriptBridge); }
    if (window.WVJBCallbacks) { return window.WVJBCallbacks.push(callback); }
    window.WVJBCallbacks = [callback];
    var WVJBIframe = document.createElement('iframe');
    WVJBIframe.style.display = 'none';
    WVJBIframe.src = 'wvjbscheme://__BRIDGE_LOADED__';
    document.documentElement.appendChild(WVJBIframe);
    setTimeout(function() { document.documentElement.removeChild(WVJBIframe) }, 0)
}



// bridge handler (native > JS)
//
//setupWebViewJavascriptBridge(function(bridge) {
//                             bridge.registerHandler('hccw_Handler1', hccw_Handler1);
//                             bridge.registerHandler('hccw_Handler2', hccw_Handler2);
//                             });


// sample 
function hccw_Handler1(data, responseCallback) {
    alert('hccw_Handler1 ' + data['param']);
}

function hccw_Handler2(data, responseCallback) {
    alert('hccw_Handler2 ' + data['param']);
}

/**
 * WEB --> APP
 * 네이티브 로그인 보여주기
 * destURL : 로그인 성공 후 이동한 URL
 */
function hcca_showLoginView(destURL) {
	WebViewJavascriptBridge.callHandler('hcca_showLoginView', {destURL: destURL}, function(response) {
        if (response['res'] == 'ok') {
        }else{
        }
     });
}

/**
 * WEB --> APP
 * device UUID 전달
 */
function hcca_getDeviceUUID(callback) {
	WebViewJavascriptBridge.callHandler('hcca_getDeviceUUID', 
										function(response) {
											var uuid = ""; 
									        if (response['res'] == 'ok') {
									        			uuid  = response['UUID'];
									        }
									        callback(uuid);
									     });
}


/**
 * WEB --> APP
 * alert popup
 * 
 * msg : message
 * type : 0 - single / 1 - confirm
 * NcallbackFunc : 취소 누를때 실행할 함수
 * YcallbackFunc : 확인 누를때 실행할 함수 
 * 
 */
function hcca_alert(msg, type, NcallbackFunc, YcallbackFunc, NFuncTitle, YFuncTitle, data) {
	var nTitle = "취소", yTitle = "확인";
	if(NFuncTitle != null){
		nTitle = NFuncTitle;
	}
	if(YFuncTitle != null){
		yTitle = YFuncTitle;
	}
	var buttons = [{ 'index' : 0 , 'title' : yTitle}];
	if(type == 1){
		buttons = [
			{ 'index' : 0 , 'title' : nTitle},
			{ 'index' : 1 , 'title' : yTitle}
		];
	}
    WebViewJavascriptBridge.callHandler('hcca_alert',
                                        {'message' : msg,'buttons' : buttons},
                                        function(response) {
	                                        if (response['res'] == 'ok') {
	                                        //to do something..
	                                        		if (response['index'] == '0'){
	                                        			if(NcallbackFunc == null){
	                                        				return false;
	                                        			}
	                                        			NcallbackFunc(data);
	                                        		}else if (response['index'] == '1'){
	                                        			if(YcallbackFunc == null){
	                                        				return false;
	                                        			}
	                                        			YcallbackFunc(data);
	                                        		}
	                                        }
                                        });
}

/**
 * WEB --> APP
 * 네이티브로 SNS 공유하기 요청. 네이티브에서 요청 정보로 SNS 공유 
 * searchURL  : 검색 공유 URL
 * message  : SNS 메세지 
 */
function hcca_shareForSNS(shareURL, message) {
	WebViewJavascriptBridge.callHandler('hcca_shareForSNS',
										{shareURL : shareURL, message : message},									   
										function(response) {
									        if (response['res'] == 'ok') {
									            }else{
									            }
									     });
}

/**
 * APP --> WEB
 * 웹페이지로 현재 검색 결과 URL을 요청
 * 웹페이지에서 검색 결과 공유 URL및 공유메세지 전달  
 * searchURL  : 검색 공유 URL
 * message  : SNS 메세지 
 */
function hccw_shareURLForSNS(data,responseCallback) {
	
	var shareURL = fn_shareUrl();		//share.jsp 
	
	var param = {
		realUrl : shareURL
	};

	//shareURL
	var url =  APP.getContextPath() + "/share/shareUrl";
	fn_ajaxSubmit(url, param, function(data){
		if(data && data.resultData){
			var message = "현대카드 커머스 검색엔진 공유";
			responseCallback({res : 'ok', shareURL : data.resultData, message : message});
		}
		return false;
		
	}, false);
}

setupWebViewJavascriptBridge(function(bridge) {
	bridge.registerHandler('hccw_shareURLForSNS', hccw_shareURLForSNS);
	bridge.registerHandler('hccw_showSearchFilter', hccw_showSearchFilter);
	bridge.registerHandler('hccw_replaceChangedInfo', hccw_replaceChangedInfo);
});

/**
 * WEB --> APP
 * 요청한 URL을 새로운 네이티브 웹뷰 화면으로 보여주기 
 * destURL : 로그인 성공 후 이동한 URL
 */
function hcca_showWebView(destURL, siteName) {
	WebViewJavascriptBridge.callHandler('hcca_showWebView', {destURL : destURL, siteName : siteName}, function(response) {
        if (response['res'] == 'ok') {
            }else{
            }
     });
}

/**
 * WEB --> APP
 * 현재 네이티브 웹뷰 없애기 
 */
function hcca_dismissWebView() {
	WebViewJavascriptBridge.callHandler('hcca_dismissWebView', {}, function(response) {
		if (response['res'] == 'ok') {
		}else{
		}
	});
}

//
//$(function(){
//	$.unblockUI();
//	//progress bar
//	$( "form,#searchWordEntity").submit(function( event ) {
//		pageLoadQue();
//	});
//	
//});

/**
 * WEB --> APP
 * 토스트 메시지 보여주기
 * message : 토스트 메시지 
 * res : 성공여부  
 */
function hcca_showToast(msg){
	WebViewJavascriptBridge.callHandler('hcca_showToast', { message : msg }, function(response) {
        if (response['res'] == 'ok') {
            }else{
            }
     });
}

/**
 * WEB --> APP
 * 필드 색깔 
 */
function hcca_changeColor(aaa) {
	WebViewJavascriptBridge.callHandler('hcca_changeColor', {}, function(response) {
		if (response['res'] == 'ok') {
		}else{
		}
	});
}

/**
 * WEB --> APP
 * 네이티브 로딩바 show
 * @returns
 */
function hcca_showLoadingIndicator(){
	WebViewJavascriptBridge.callHandler('hcca_showLoadingIndicator', {}, function(response) {
		if (response['res'] == 'ok') {
		}
	});
}

/**
 * WEB --> APP
 * 네이티브 로딩바 hide
 * @returns
 */
function hcca_hideLoadingIndicator(){
	WebViewJavascriptBridge.callHandler('hcca_hideLoadingIndicator', {}, function(response) {
		if (response['res'] == 'ok') {
		}
	});
}

/**
 * WEB --> APP
 * 특정버튼 눌렀을 경우 네이티브 전달 
 * currentURL : 기존 웹뷰 주소
 * res : 성공여부  
 */
function hcca_didTapDoneButton(url){
	WebViewJavascriptBridge.callHandler('hcca_didTapDoneButton', { currentURL : url }, function(response) {
        if (response['res'] == 'ok') {
        }else{
        }
     });
}

/**
 * WEB --> APP
 * 웹뷰 백버튼 눌렀을 경우 네이티브 전달 
 * currentURL : 기존 웹뷰 주소
 * res : 성공여부  
 */
function hcca_didTapBackButton(url){
	WebViewJavascriptBridge.callHandler('hcca_didTapBackButton', { currentURL : url }, function(response) {
		if (response['res'] == 'ok') {
		}else{
		}
	});
}

/**
 * WEB --> APP
 * 네이티브 GNB show
 * @returns
 */
function hcca_slideUpGNB(){
	WebViewJavascriptBridge.callHandler('hcca_slideUpGNB', {}, function(response) {
		if (response['res'] == 'ok') {
		}
	});
}

/**
 * WEB --> APP
 * 네이티브 GNB hide
 * @returns
 */
function hcca_slideDownGNB(){
	WebViewJavascriptBridge.callHandler('hcca_slideDownGNB', {}, function(response) {
		if (response['res'] == 'ok') {
		}
	});
}

/**
 * WEB --> APP
 * 타이틀 변경
 * title : 타이틀
 * res : 성공여부  
 */
function hcca_setWebViewTitle(txt){
	WebViewJavascriptBridge.callHandler('hcca_setWebViewTitle', { title : txt }, function(response) {
        if (response['res'] == 'ok') {
        }else{
        }
     });
}

/**
 * WEB --> APP
 * status bar style 변경
 * style : 
 *         StatusBarStyleDefault : font is black and background is white
 *         StatusBarStyleLightContnt : font is white and background is black
 * res : 성공여부  
 */
function hcca_setStatusBarStyle(flag){
	var setStyle = "";
	if(flag == 1){
		setStyle = "statusBarStyleDefault";
	} else {
		setStyle = "statusBarStyleLightContent";
	}
	WebViewJavascriptBridge.callHandler('hcca_setStatusBarStyle', { style : setStyle }, function(response) {
		if (response['res'] == 'ok') {
		}
	});
}

/**
 * WEB --> APP
 * 네이티브 GNB hide
 * @returns
 */
function hcca_showSearchHistoryView(){
	WebViewJavascriptBridge.callHandler('hcca_showSearchHistoryView', {}, function(response) {
		if (response['res'] == 'ok') {
		}
	});
}

/**
 * WEB --> APP
 * 메인페이지 네이티브 검색창 
 * @returns
 */
function hcca_showSearchView(){
	WebViewJavascriptBridge.callHandler('hcca_showSearchView', {}, function(response) {
		if (response['res'] == 'ok') {
		}
	});
}

/**
 * APP --> WEB
 * 웹페이지 필터버튼 눌림 action
 */

function hccw_showSearchFilter(data, responseCallback) {
	showFilter();
	responseCallback({res : 'ok'});
}

/**
 * WEB --> APP
 * 웹페이지 필터닫힘 전달
 * @returns
 */
function hcca_didCloseSearchFilter(num){
	WebViewJavascriptBridge.callHandler('hcca_didCloseSearchFilter', { numFilterResult : num }, function(response) {
		if (response['res'] == 'ok') {
		}
	});
}

/**
 * WEB --> APP
 * 검색결과 전달
 * tab : 탭위치 ( 1:인기있는, 2:최근뜨는, 3:내게맞는)
 * @returns
 */
function hcca_currentSearchResult(srchKind, total){
	WebViewJavascriptBridge.callHandler('hcca_currentSearchResult', { tab : srchKind, numSearchResult : total }, function(response) {
		if (response['res'] == 'ok') {
		}
	});
}

/**
 * WEB --> APP
 * 검색 History전달 
 * @returns
 */
function hcca_addSearchHistory(query){
	WebViewJavascriptBridge.callHandler('hcca_addSearchHistory', { keyword : query }, function(response) {
		if (response['res'] == 'ok') {
		}
	});
}


/**
 * WEB --> APP
 * 북마크 화면에서 변경된 좋아요와 삭제된 북마크 정보를 네이티브에 전달 
 * @returns
 */
function hcca_storeChangedInfo(){
	WebViewJavascriptBridge.callHandler('hcca_storeChangedInfo', {likeList : [], bookmarkList:[]}, function(response) {
		if (response['res'] == 'ok') {
		}
	});
}


/**
 * APP --> WEB
 * hcca_storeChangedInfo로 전달된 정보를 검색결과 화면에서 갱신 
 */
function hccw_replaceChangedInfo(data, responseCallback) {
	alert("hccw_replaceChangedInfo");
	var data = responseCallback.data;
}

/** 
 * WEB --> APP
 * GA 이벤트 태그 구현
 * @returns
 */
function sendTrackingEvent(screenName, category, action, label, callbackFunc, data){
	console.log("screenName >>" + screenName + " : category >>" + category+ " : action >> " + action + " : label >> " + label);
	msg = "screenName >>" + screenName+  "\n category >>" + category+ "\n action >> " + action + "\n label >> " + label;
	WebViewJavascriptBridge.callHandler('hcca_showToast', { message : msg }, function(response) {
        if (response['res'] == 'ok') {
            }else{
            }
     });	
	return;
	
	WebViewJavascriptBridge.callHandler('sendTrackingEvent', {screenName: screenName, category:category, action:action, label:label}, function(response) {
//		
//		if (response['res'] == 'ok') {
//		}
//		
	});
}
function fn_sendTrackingEvent(category, action, label, callbackFunc, data){
	if(!window.WebViewJavascriptBridge){//없으면 
		setTimeout(function(){
			fn_sendTrackingEvent(category, action, label, callbackFunc, data);
		}, 500); 
	}else{
		sendTrackingEvent(category, action, label, callbackFunc, data)
	}
}

function fn_twofigures(s){
	var n = parseInt(s);
	return (n < 10)? "0"+ n : n;
}