/**
 * Created by hyundai on 2017. 7. 18..
 */
function fn_append(resdata, reqdata){
	console.log(resdata);
	var appendData = resdata.rows;
	var flag = reqdata.searchKind;
	var returnVal = "";
	var page = reqdata.page;
	if (page == 1){
		page = 0;
	} else {
		page = 2*(page-1);
	}
	var count = Number(page)*10;
	if (appendData.length > 0){
		if (flag == "1"){
			for(var i in appendData){
				var cntStr = 0;
				count += 1;
				if (count < 10){
					cntStr = "0"+Number(count);
				} else {
					cntStr = count;
				} 
				returnVal += appendVal.set1(appendData[i],cntStr);
			}
		} else if (flag == "2"){
			for(var i in appendData){
				returnVal += appendVal.set2(appendData[i]);
			}
		} else if (flag == "3"){
			for(var i in appendData){
				returnVal += appendVal.set3(appendData[i]);
			}
		}
	} else {
		returnVal += resultNone.set(reqdata);
	}
	return returnVal;
}

//첫번째, 마지막인덱스 쌍따움표 제거 
function fn_removeDoubleMark(str){
	var cnt = str.length;
	if("\"" == str.charAt(0) && "\"" == str.charAt(cnt-1)){
		return str.substring(1,cnt-1);
	}
	return str;
}


//첫번째 대문자로
function firstUpperCase(str){
	if(str && str != ""){
		return str.charAt(0).toUpperCase() + str.substring(1);
	}
	return str;
}

var appendVal = {
	set1 : function (data, idx) {
		var liTag = "";
		if (data.site_meta_promotion_info == null){
			data.site_meta_promotion_info = "";
		}
		
		if (data.site_meta_promotion_info.length > 0){
			liTag += '<span>'+ data.site_meta_promotion_info +'</span>';
		}
		
		if ( data.site_meta_direct_delivery == "true" ){
			liTag += '<span>';
			liTag += "직배송"+
			'</span>';
		}
		
		if (data.site_meta_free_delivery == "true"){
			var desc = data.site_meta_free_delivery_description;
			liTag += '<span>';
			if (desc){
				liTag += desc;
				if (!desc.indexOf(/무료 배송|무료배송/)){
					liTag += "무료배송";
				}
			} else {
				liTag += "무료배송";
			}
			liTag += '</span>';
		}
		
		if (data.site_meta_checkout_card != null){
			var cardArr = data.site_meta_checkout_card.split(';');
		}
		
		if(cardArr.length >0){
			//cardInfo Add
			liTag += '<span>';
			for(var i in cardArr){
				liTag += cardArr[i];
				if(i != cardArr.length-1){
					liTag += "/";
				}
			}
			liTag += '</span>';
		}
		
		var siteUrl = "";
		if(data.site_meta_landing_url){
			siteUrl = data.site_meta_landing_url;			
		}
		
		var catUrl = "";
		if(data.category && data.category["ctg_meta_site_cat_url"]){
			catUrl = data.category["ctg_meta_site_cat_url"];			
		}
		
		var categoryId =  "";
		if(data.category && data.category.id){
			categoryId = data.category.id;
		}else{
		}
		
		var setVal = '<div class="result_box new" data-site-id="'+data.id+'" data-category-id="'+categoryId+'">'+
		'<div class="list_num">'+idx+'</div>'+
		'<a href="'+catUrl+'" class="brand_go">'+
			'<h1 class="re_b_tit">'+data.site_meta_eng_nm+'</h1>'+
			'<h2 class="re_s_tit">'+data.site_meta_korean_nm+'</h2>'+
			
			'<span class="result_num" data-catUrl="'+catUrl+'">';
				if(data.category){
					var gender = "";
					if(data.category.ctg_meta_gender_tag){
						gender = data.category.ctg_meta_gender_tag +"\'s > ";
					}
					var catName = "";
					if(data.category.ctg_meta_site_cat_nm){
						catName = data.category.ctg_meta_site_cat_nm +"";
					}else{
						catName = '카테고리 이름이 없습니다.';
					}
					var length = "";
					if(data.category.products.length > 0){
						length = "<em>"+fn_overMillionProd(data.category._products_total_count)+'개</em> 상품</span>';
					}
					setVal += '<span class="bu_type">'+ firstUpperCase(gender) +'<em class="ico_arrow">' + firstUpperCase(catName) + '</em></span><span>'+length;
				} else {
					setVal += '카테고리가 없습니다.';
				}
			setVal += '</span>'+
		'</a>'+
				
		'<div class="result_introduce">'+
			'<p>' + fn_removeDoubleMark(data.site_meta_site_desc) + '</p>'+
			'<p class="line_tip">'+liTag+'</p>'+
		'</div>'+
		
		'<div class="thumb_box">';
		if (data.category && data.category.products.length >0){
			setVal += '<div class="scroll">';
				for(var i in data.category.products){
					if (i > 19){
						break;
					}
					var thisProd = data.category.products[i];
					var thisImg = thisProd.product_item_img;
					//image 경로 시작이 http -> 상대주소입니다. 이미지
					if (thisImg){
						if ($.trim(thisImg).length == 0){
							thisImg = "../resources/images/@/demo/img_relativepath.png";
						}
					} else {
						thisImg = "../resources/images/@/demo/img_none.png";
					}
					if (!thisProd.product_item_price_original){
						thisProd.product_item_price_original = "가격정보가 없습니다.";
					}
					
					var productPageUrlFull = thisProd.product_page_url_full;
					setVal += '<a href="'+productPageUrlFull+'">'+
						'<img src="'+thisImg+'" onError="this.src=\'../resources/images/@/demo/img_abnormal.png\'" />'+
						'<p class="price">'+thisProd.product_item_price_original+'</p>'+
					'</a>';
				}
				
				/**
				 * 08.02 MAX초과시 보여줌
				 */
				if( data.category.products.length >= 20 ){
					setVal += '<a class="btn_more_product gotoDetail">'+
                        '<span>더보기</span></a>';
				}
				
			setVal += '</div>';
			} else {
				setVal += '<p class="none_product">등록된 상품이 없습니다.</p>';
			}
		
			var category = data.category;
			var likeClassName =  "";
			var ctg_cnt = 0;
			var bookmarkClassName =  "";
			var likeSiteCatSq = "";
			if(category){
				if(category.ctg_is_like == "Y"){
					likeClassName = "on";
				}else{
					likeClassName = "";
				}
				
				if(category.ctg_is_bookmark == "Y"){
					bookmarkClassName = "on";
				}else{
					bookmarkClassName = "";
				}
				ctg_cnt = Number(category.ctg_cnt);
				likeSiteCatSq = category.likeSiteCatSq;
			}
			
			setVal += '</div>'+
			' <div class="result_btn_all">'+
			    '<button class="btn_heart '+likeClassName+'" data-like-site-cat-sq="'+likeSiteCatSq+'"><span>'+fn_overMilion(ctg_cnt)+'</span></button>'+
	            '<button class="btn_bookmark '+bookmarkClassName+'">bookmark</button>'+
	            '<button class="btn_share">공유하기</button>'+
	            '<a class="btn_detail gotoDetail">상세보기</a>'+
	        '</div>'+
		'</div>';
		return setVal;
	},
	set2 : function(data){
		
		var liTag = "";
		if (data.site_meta_promotion_info == null){
			data.site_meta_promotion_info = "";
		}
		if (data.site_meta_promotion_info.length > 0){
			liTag += data.site_meta_promotion_info;
		}
		if ( data.site_meta_direct_delivery == "true" ){
			liTag += "<span>직배송</span>";
		}
		
		if (data.site_meta_free_delivery == "true"){
			liTag += "<span>";
			var desc = data.site_meta_free_delivery_description;
			if (desc){
				liTag += desc;
				if (!desc.indexOf(/무료 배송|무료배송/)){
					liTag += "무료배송";
				}
			} else {
				liTag += "무료배송";
			}
			liTag += "</span>";
		}
		
		if (data.site_meta_checkout_card != null){
			var cardArr = data.site_meta_checkout_card.split(';');
		}
		
		if(cardArr.length >0){
			//cardInfo Add
			liTag += "<span>";
			for(var i in cardArr){
				liTag += cardArr[i];
				if(i != cardArr.length-1){
					liTag += "/";
				}
			}
			liTag += "</span>";
		}
		
		var siteUrl = "";
		if(data.site_meta_landing_url){
			siteUrl = data.site_meta_landing_url;			
		}
		
		var catUrl = "";
		if(data.category && data.category["ctg_meta_site_cat_url"]){
			catUrl = data.category["ctg_meta_site_cat_url"];			
		}
		
		var angle;
		if(data.site_region == "domestic"){
			if (data.site_duration == 1){
				angle = data.site_domestic_1m_angle;
			}
			else if (data.site_duration == 3){
				angle = data.site_domestic_3m_angle;
			}
			else if (data.site_duration == 6){
				angle = data.site_domestic_6m_angle;
			}
		}else if (data.site_region == "international"){
			if (data.site_duration == 1){
				angle = data.site_international_1m_angle;
			}
			else if (data.site_duration == 3){
				angle = data.site_international_3m_angle;
			}
			else if (data.site_duration == 6){
				angle = data.site_international_6m_angle;
			}
		}
		var angleText = "";
		if ( angle > 80 ){
			angleText = "80˚ ~";
		}else if ( angle > 60 ){
			angleText = "60˚~80˚";
		}else {
			angleText = "30˚~60˚";
		}
		
		var categoryId =  "";
		if(data.category && data.category.id){
			categoryId = data.category.id;
		}else{
		}
		
		var setVal = '<div class="result_box type01 new" data-site-id="'+data.id+'" data-category-id="'+categoryId+'">'+
		'<div class="graph_area">'+
		'<div class="line_type_graph gra_type01">'+
		'<span class="arrow_move">'+
		'<span class="arrow_line" data-angle="'+angle+'"></span>'+
		'</span>'+
		'</div>'+
		'<span class="line_numerical">'+angleText+'</span>'+
		'</div>'+
		
		'<a href="'+catUrl+'" class="brand_go">'+
		'<h1 class="re_b_tit">'+data.site_meta_eng_nm+'</h1>'+
		'<h2 class="re_s_tit">'+data.site_meta_korean_nm+'</h2>'+
		
		'<span class="result_num" data-catUrl="'+catUrl+'">';
		if(data.category){
			var gender = "";
			if(data.category.ctg_meta_gender_tag){
				gender = data.category.ctg_meta_gender_tag +"\'s > ";
			}
			var catName = "";
			if(data.category.ctg_meta_site_cat_nm){
				catName = data.category.ctg_meta_site_cat_nm +"";
			}else{
				catName = '카테고리 이름이 없습니다.';
			}
			var length = "";
			if(data.category.products.length > 0){
				length = "<em>"+fn_overMillionProd(data.category._products_total_count)+'개</em> 상품</span>';
			}
			setVal += '<span class="bu_type">'+ gender +'<em class="ico_arrow">' + catName + '</em></span><span>'+length;
		} else {
			setVal += '카테고리가 없습니다.';
		}
		setVal += '</span>'+
		'</a>';
		
		setVal += '<div class="result_introduce">'+
		'<p>' + fn_removeDoubleMark(data.site_meta_site_desc) + '</p>'+
		'<p class="line_tip">' + liTag + '</p>'+
		'</div>'+
		'</a>'+
		'<div class="thumb_box">';
		if(data.category && data.category.products.length>0){
			setVal += '<div class="scroll">';
			for(var i in data.category.products){
				if (i > 19){
					break;
				}
				var thisProd = data.category.products[i];
				var thisImg = thisProd.product_item_img;
				//image 경로 시작이 http -> 상대주소입니다. 이미지
				if (thisImg){
					if ($.trim(thisImg).length == 0){
						thisImg = "../resources/images/@/demo/img_relativepath.png";
					}
				} else {
					thisImg = "../resources/images/@/demo/img_none.png";
				}
				if (!thisProd.product_item_price_original){
					thisProd.product_item_price_original = "가격정보가 없습니다.";
				}
				var productPageUrlFull = thisProd.product_page_url_full;
				setVal += '<a href="'+productPageUrlFull+'">'+
				'<img src="'+thisImg+'" onError="this.src = \'../resources/images/@/demo/img_abnormal.png\'" />'+
				'<p class="price">'+thisProd.product_item_price_original+'</p>'+
				'</a>';
			}
			
			/**
			 * 07.24 15개 이상일경우 보여줌
			 */
			if( data.category.products.length >= 20 ){
				setVal += '<a class="btn_more_product gotoDetail">'+
				'<span>더보기</span></a>';
			}
			
			setVal += '</div>';
		} else {
			setVal += '<p class="none_product">등록된 상품이 없습니다.</p>';
		}
		
		var category = data.category;
		var likeClassName =  "";
		var ctg_cnt = 0;
		var bookmarkClassName =  "";
		var likeSiteCatSq = "";
		if(category){
			if(category.ctg_is_like == "Y"){
				likeClassName = "on";
			}else{
				likeClassName = "";
			}
			
			if(category.ctg_is_bookmark == "Y"){
				bookmarkClassName = "on";
			}else{
				bookmarkClassName = "";
			}
			ctg_cnt = Number(category.ctg_cnt);
			likeSiteCatSq = category.likeSiteCatSq;
		}
		
		setVal += '</div>'+
		'<div class="result_btn_all">'+
		//'<button class="btn_heart"><span>'+fn_overMilion(data.score)+'</span></button>'+
		'<button class="btn_heart '+likeClassName+'"><span>'+fn_overMilion(ctg_cnt)+'</span></button>'+
		'<button class="btn_bookmark '+bookmarkClassName+'">bookmark</button>'+
		'<button class="btn_share">공유하기</button>'+
		'<a class="btn_detail gotoDetail">상세보기</a>'+
		'</div>'+
		
		'</div>';
		return setVal;
	},
	set3 : function(data){
		
		var liTag = "";
		if (data.site_meta_promotion_info == null){
			data.site_meta_promotion_info = "";
		}
		if (data.site_meta_promotion_info.length > 0){
			liTag += data.site_meta_promotion_info;
		}
		if ( data.site_meta_direct_delivery == "true" ){
			liTag += "<span>직배송</span>";
		}
		
		if (data.site_meta_free_delivery == "true"){
			liTag += "<span>";
			var desc = data.site_meta_free_delivery_description;
			if (desc){
				liTag += desc;
				if (!desc.indexOf(/무료 배송|무료배송/)){
					liTag += "무료배송";
				}
			} else {
				liTag += "무료배송";
			}
			liTag += "</span>";
		}
		
		if (data.site_meta_checkout_card != null){
			var cardArr = data.site_meta_checkout_card.split(';');
		}
		
		if(cardArr.length >0){
			//cardInfo Add
			liTag += "<span>";
			for(var i in cardArr){
				liTag += cardArr[i];
				if(i != cardArr.length-1){
					liTag += "/";
				}
			}
			liTag += "</span>";
		}
		
		var siteUrl = "";
		if(data.site_meta_landing_url){
			siteUrl = data.site_meta_landing_url;			
		}
		
		var catUrl = "";
		if(data.category && data.category["ctg_meta_site_cat_url"]){
			catUrl = data.category["ctg_meta_site_cat_url"];			
		}
		
		var categoryId =  "";
		if(data.category && data.category.id){
			categoryId = data.category.id;
		}else{
		}
		
		var setVal = '<div class="result_box type02 new" data-site-id="'+data.id+'" data-category-id="'+categoryId+'">'+
		'<div class="graph_area">'+
		'<div class="circle_type">'+
		'<div class="ani-circle" data-matching="'+(data.site_matching)+'"></div>'+
		'</div>'+
		'<div class="percent">%</div>'+
		'</div>'+
		
		'<a href="'+catUrl+'" class="brand_go">'+
		'<h1 class="re_b_tit">'+data.site_meta_eng_nm+'</h1>'+
		'<h2 class="re_s_tit">'+data.site_meta_korean_nm+'</h2>'+
		
		'<span class="result_num" data-catUrl="'+catUrl+'">';
		if(data.category){
			var gender = "";
			if(data.category.ctg_meta_gender_tag){
				gender = data.category.ctg_meta_gender_tag +"\'s > ";
			}
			var catName = "";
			if(data.category.ctg_meta_site_cat_nm){
				catName = data.category.ctg_meta_site_cat_nm +"";
			}else{
				catName = '카테고리 이름이 없습니다.';
			}
			var length = "";
			if(data.category.products.length > 0){
				length = "<em>"+fn_overMillionProd(data.category._products_total_count)+'개</em> 상품</span>';
			}
			setVal += '<span class="bu_type">'+ gender +'<em class="ico_arrow">' + catName + '</em></span><span>'+length;
		} else {
			setVal += '카테고리가 없습니다.';
		}
		setVal += '</span> </a>'+
		
		'<div class="result_introduce">'+
		'<p>' + fn_removeDoubleMark(data.site_meta_site_desc) + '</p>'+
		'<p class="line_tip">' + liTag + '</p>'+
		'</div>'+
		
		'<div class="thumb_box">';
		if(data.category && data.category.products.length>0){
			setVal += '<div class="scroll">';
			for(var i in data.category.products){
				if (i > 19){
					break;
				}
				var thisProd = data.category.products[i];
				var thisImg = thisProd.product_item_img;
				//image 경로 시작이 http -> 상대주소입니다. 이미지
				if (thisImg){
					if ($.trim(thisImg).length == 0){
						thisImg = "../resources/images/@/demo/img_relativepath.png";
					}
				} else {
					thisImg = "../resources/images/@/demo/img_none.png";
				}
				if (!thisProd.product_item_price_original){
					thisProd.product_item_price_original = "가격정보가 없습니다.";
				}
				
				var productPageUrlFull = thisProd.product_page_url_full;
				setVal += '<a href="'+productPageUrlFull+'">'+
				'<img src="'+thisImg+'" onError="this.src=\'../resources/images/@/demo/img_abnormal.png\'" />'+
				'<p class="price">'+thisProd.product_item_price_original+'</p>'+
				'</a>';
			}
			/**
			 * 07.24 15개 이상일경우 보여줌
			 */
			if( data.category.products.length >= 20 ){
				setVal += '<a class="btn_more_product gotoDetail">'+
				'<span>더보기</span></a>';
			}
			
			setVal += '</div>';
		} else {
			setVal += '<p class="none_product">상품정보가 없습니다.</p>';
		}
		
		var category = data.category;
		var likeClassName =  "";
		var ctg_cnt = 0;
		var bookmarkClassName =  "";
		var likeSiteCatSq = "";
		if(category){
			if(category.ctg_is_like == "Y"){
				likeClassName = "on";
			}else{
				likeClassName = "";
			}
			
			if(category.ctg_is_bookmark == "Y"){
				bookmarkClassName = "on";
			}else{
				bookmarkClassName = "";
			}
			ctg_cnt = Number(category.ctg_cnt);
			likeSiteCatSq = category.likeSiteCatSq;
		}
		
		setVal += '</div>'+
		'<div class="result_btn_all">'+
		//'<button class="btn_heart"><span>'+fn_overMilion(data.score)+'</span></button>'+
		'<button class="btn_heart '+likeClassName+'" data-like-site-cat-sq="'+likeSiteCatSq+'"><span>'+fn_overMilion(ctg_cnt)+'</span></button>'+
		'<button class="btn_bookmark '+bookmarkClassName+'">bookmark</button>'+
		'<button class="btn_share">공유하기</button>'+
		'<a class="btn_detail gotoDetail">상세보기</a>'+
		'</div>'+
		'</div>';
		return setVal;
	}
}

var resultNone = {
		//filter 검색결과 없을경우
		set : function (reqdata){
			var srchTab = "";
			if (reqdata.searchKind == "1"){
				srchTab = "인기있는";
			} else if (reqdata.searchKind == "2") {
				srchTab = "최근뜨는";
			} else if (reqdata.searchKind == "3") {
				srchTab = "내게맞는";
			}
			var setVal = '<div class="keyword_box">'+
	            '<div class="keyword_area">'+
		            '<div class="keyword_search">'+
		                '<p>' + srchTab + '<strong>"'+ reqdata.query +'"</strong>에 대한</p>검색결과가 없습니다.</p>'+
		                //'<p><span>남성,</span> <span>중가,</span> <span>아울렛</span>의<br />검색결과가 없습니다.</p>'+
		            '</div>'+
		        '</div>'+
		    '</div>';
			
			return setVal;
		}
}

/**
 * 상세화면 Category
 * @param data
 * @returns String
 */
function appendCat(data){
	var rdata = data.resultData.data;
	console.log(rdata);
	var reVal = "";
	for(var i in rdata.rows){
		reVal += appendCatVal.set(rdata.rows[i], data.resultData.query);
	}
	
	return reVal;
}

var appendCatVal = {
		set : function (data, query){
			var catNm = data.ctg_meta_site_cat_nm;
			if (!catNm){
				catNm = '카테고리이름이 없습니다.';
			}

			var likeClassName =  "";
			var ctg_cnt = 0;
			var bookmarkClassName =  "";
			var likeSiteCatSq = "";
			
			if(data.ctg_is_like == "Y"){
				likeClassName = "on";
			}else{
				likeClassName = "";
			}
			
			if(data.ctg_is_bookmark == "Y"){
				bookmarkClassName = "on";
			}else{
				bookmarkClassName = "";
			}
			ctg_cnt = Number(data.ctg_cnt);
			likeSiteCatSq = data.id;
			
			var reVal = '<p class="bridge_num" onclick="hcca_showWebView('+data.ctg_meta_site_cat_url+','+query+')">';
                    if(data.ctg_meta_gender_tag){
                    	reVal += '<span class="bu_type">'+data.ctg_meta_gender_tag+'\'s > <em class="ico_arrow">'+catNm+'</em></span><span><br /><em>'+ fn_overMillionProd(data._products_total_count) +'개</em> 상품</span>';
                    }else {
                    	reVal += '<span class="bu_type">'+catNm+'</span><span><br /><em>'+ fn_overMillionProd(data._products_total_count) +'개</em> 상품</span>';
                    }
                reVal += '</p>'+
    
                '<div class="thumb_box new">'+
                    '<div class="scroll">';
	                	for(var i in data.products){
						var thisProd = data.products[i];
						var thisImg = thisProd.product_item_img;
						//image 경로 시작이 http -> 상대주소입니다. 이미지
						if (thisImg){
							if ($.trim(thisImg).length == 0){
								thisImg = "../resources/images/@/demo/img_relativepath.png";
							}
						} else {
							thisImg = "../resources/images/@/demo/img_none.png";
						}
						
						if (!thisProd.product_item_price_original){
							thisProd.product_item_price_original = "가격정보가 없습니다.";
						}
						
						var productPageUrlFull = thisProd.product_page_url_full;
						reVal += '<a href="'+productPageUrlFull+'">'+
							'<img src="'+thisImg+'" onError="this.src=\'../resources/images/@/demo/img_abnormal.png\'" />'+
							'<p class="price">'+thisProd.product_item_price_original+'</p>'+
						'</a>';
						
					}
	                	/**
	                	 * 08.25 20개 이상일경우 보여줌
	                	 */
	                	if( data._products_total_count > 20 ){
	                		reVal += '<a class="btn_more_product" onclick="">'+
	                		'상세 정보 더보기'+
	                		'</a>';
	                	}
                	reVal +='</div>'+
                '</div>';
                	
                	
                reVal += '<div class="bridge_btn_all" data-catSq="'+data.id+'">'+
			    		'<button class="btn_heart '+likeClassName+'" onclick="btnHeartClick(this)" data-like-site-cat-sq="'+likeSiteCatSq+'"><span>'+fn_overMilion(ctg_cnt)+'</span></button>'+
			    		'<button class="btn_bookmark '+bookmarkClassName+'">bookmark</button>'+    
                    '<button class="btn_share">공유하기</button>'+
                '</div>'+
            '</c:forEach>';
			
            return reVal;
		}
};

function appendQuestion(data){
	if(!data.resultData){
		return false;
	}
	var returnVal = "<div class='survey_area' data-surveySq="+data.resultData[0].surveySq+">"+
    "<div class='survey_info'>"+
        "<h1>내게맞는 검색 - 일반형</h1>"+
        "<p>쇼핑성향 분석<br/>쇼핑에 대한 4가지 질문에 대한 답변을 하신 후<br />제출하기를 누르시면 바로 시작합니다.</p>"+
    "</div>";
    
	for(var i in data.resultData){
		var answerType = data.resultData[i].answerTypeCd;
		if(answerType == '10'){ //객관식 단일선택 
			returnVal += addQuestion.set1(i, data.resultData[i]);
			
		} else if(answerType == '20'){ // 객관식 복수선택 
			returnVal += addQuestion.set2(i, data.resultData[i]);
			
		} else if(answerType == '30'){ // 주관식 
			returnVal += addQuestion.set3(i, data.resultData[i]);
			
		}
	}
	returnVal += "<button class='btn_submit' onclick='btnQueSubmit()'>제출하기</button>"+
		"</div>";
	return returnVal;
}

var addQuestion = {
	set1 : function (idx, data) {
		idx ++;
		if(idx < 10){
			idx = "0"+idx;
		}
		var addVal = "<dl id='"+"survey"+idx+"' data-que-type='"+data.questionTypeCd+"' data-answer-type='"+data.answerTypeCd+"' data-que-sq='"+data.questionSq+"' >"+
		'<dt><span class="num">'+idx+'</span>'+data.questionTitle +'</dt>';
		
		for(var i in data.choiceList){
			var choice = data.choiceList[i];
			if (choice.etcFlagYn == 'N'){
				addVal += '<dd data-choice-sq="'+choice.choiceSeq+'">'+
				'<input type="checkbox" id="survey'+idx+'_0'+i+'" name="survey'+idx+'" data-choice-val="'+choice.choiceVal+'" class="check" data-etc-flag="N" onclick="iptChkType10(this)"/><label for="survey'+idx+'_0'+i+'">'+choice.choiceText+'</label>'+
				'</dd>';
			} else {
				addVal += '<dd data-choice-sq="'+choice.choiceSeq+'">'+
				'<input type="checkbox" id="survey'+idx+'_0'+i+'" name="survey'+idx+'" data-choice-val="'+choice.choiceVal+'" class="check" data-etc-flag="Y" onclick="iptChkType10(this)"/><label for="survey'+idx+'_0'+i+'">'+choice.choiceText+'</label>'+
				'</dd>'+
				'<dd class="etc">'+
					'<input type="text" placeholder="직접 입력해 주세요." class="surveyEtcVal"/>'+
				'</dd>';
			}
		}
		addVal += "</dl>";
		return addVal;
	},
	set2 : function (idx, data) {
		idx ++;
		if(idx < 10){
			idx = "0"+idx;
		}
		var addVal = "<dl id='"+"survey"+idx+"' data-que-type='"+data.questionTypeCd+"' data-answer-type='"+data.answerTypeCd+"' data-que-sq='"+data.questionSq+"'>"+
		'<dt><span class="num">'+idx+'</span>'+data.questionTitle +'</dt>';
		
		for(var i in data.choiceList){
			var choice = data.choiceList[i];
			if (choice.etcFlagYn == 'N'){
				addVal += '<dd data-choice-sq="'+choice.choiceSeq+'">'+
				'<input type="checkbox" id="survey'+idx+'_0'+i+'" name="survey'+idx+'" data-choice-val="'+choice.choiceVal+'" class="check" data-etc-flag="N"/><label for="survey'+idx+'_0'+i+'">'+choice.choiceText+'</label>'+
				'</dd>';
			} else {
				addVal += '<dd data-choice-sq="'+choice.choiceSeq+'">'+
				'<input type="checkbox" id="survey'+idx+'_0'+i+'" name="survey'+idx+'" data-choice-val="'+choice.choiceVal+'" class="check" data-etc-flag="Y"/><label for="survey'+idx+'_0'+i+'">'+choice.choiceText+'</label>'+
				'</dd>'+
				'<dd class="etc">'+
					'<input type="text" placeholder="직접 입력해 주세요." class="surveyEtcVal"/>'+
				'</dd>';
			}
		}
		
		addVal += "</dl>";
		
		return addVal;
	},
	set3 : function (idx, data) {
		idx ++;
		if(idx < 10){
			idx = "0"+idx;
		}
		var addVal = "<dl id='"+"survey"+idx+"' data-que-type='"+data.questionTypeCd+"' data-answer-type='"+data.answerTypeCd+"' data-que-sq='"+data.questionSq+"'>"+
        '<dt><span class="num">'+idx+'</span>'+data.questionTitle+'</dt>'+
        '<dd class="etc">'+
	        '<input type="text" id="brandSearch" name="brandSearch" placeholder="예)망고" /><label for="brandSearch">brand</label>'+
	        '<button class="btn_brand_delete">삭제</button>'+
	        '<div class="brand_search_down">'+
	            '<div class="brand_search_down_in">'+
	                '<ul>'+
	                    '<li class="fix" ><span class="txt">아래 브랜드 중에 선택해 주세요.</span></li>'+
	                    '<li class="add" onclick="addBrand(this)"><a><em></em> 추가하기</a></li>'+
	                '</ul>'+
	            '</div>'+
	        '</div>'+
	    '</dd>'+
        //<dd class="survey_list" style="display:block;">식스피<button class="del">삭제</button></dd>
    '</dl>';
		return addVal;
	}
};

function addReview(reviewList){
	var reviewSet = "";
	if (reviewList && reviewList.length>0){
		for(var i in reviewList){
			var thisEntity = reviewList[i];
			reviewSet += '<dl data-uuid="'+thisEntity.uuid+'" data-reviewSq="'+thisEntity.reviewSiteSq+'">'+
			'<dt><span name="memberIdSq">'+ thisEntity.userId +'</span>'+
				'<span class="star_s" data-grade="'+thisEntity.grade+'">'+
					'<em>01</em>'+
					'<em>02</em>'+
					'<em>03</em>'+
					'<em>04</em>'+
					'<em>05</em>'+
				'</span>'+
			'</dt>';
			var updateDt = thisEntity.updateDt;
			updateDt = updateDt.substr(2,2)+'.'+updateDt.substr(5,2)+'.'+updateDt.substr(8,2);
			reviewSet += '<dd class="date">'+updateDt+'</dd>';
			var review = thisEntity.review;
			if(review.length < 1){
				review = '<dd class="no">이 글은 주제와 무관한 내용을 포함하였습니다.</dd>';
			}
			if(thisEntity.isMine == "Y"){
				reviewSet += '<dd>' + thisEntity.review + '</dd>'+
				'<button class="del">삭제</button>';
			} else {
				reviewSet += '<dd>'+ review + '</dd>';
			}
			reviewSet += '</dl>';
		}
		
    } else {
        //review none
        reviewSet = '<div class="reply_none">현재 작성된 리뷰가 없습니다.<br />가장 처음 리뷰를 작성해 볼까요??</div>';
    }
	
	return reviewSet;
}


function fn_overMilion(score){
	if (score >= 10000){ //10000 이상일경우 ex) 12000 -> 1.2K
		score = (score/10000).toFixed(1)+"K";
	} else {
		score = fn_addComma(score+"");
	}
	return score;
}

function fn_overMillionProd(count){
	if(count > 10000){
		return "9999+";
	} else {
		return count;
	}
}

//3자리마다 , 
function fn_addComma(str) {
    return str.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}