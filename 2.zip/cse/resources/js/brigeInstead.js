/*
  개발 편의를 위한 웹 테스트 Bridge 입니다. 
 어플에서는 적용되지 않습니다.
 */
$(function(){
	
    setTimeout(function(){
    		
    },500);
    
});
webBridge();
 
function webBridge(){
	if(window.WebViewJavascriptBridge == undefined){
		window.isWeb = true;
		WebViewJavascriptBridge = {
				callHandler : function(sort, obj, fn_response){
					
					if(sort == "hcca_alert"){
						var msg = obj.message;
						if ( !msg ) msg = '';
						var buttons = obj.buttons;
						

					    var $dialog = $('<div></div>').html( msg ).dialog({
					        title: "어플팝업대신",
					        resizable: false,
					        modal: true,
					        stack : false,
					        zIndex : 1000 
					    });
					    var buttonsObj = [];
					    for (var i = 0; i < buttons.length; i++) {
						    	if(i == 0) {
							    	buttonsObj.push({
							    		text :buttons[i]['title'],
							    		click: function() {
							    	        $( this ).dialog( "close" );
							    	        var response ={
							    	        		res : "ok",
							    	        		index : "0"
							    	        }
							    	        fn_response.call(null,response);
							    	    }
							    	});
						    	}else if(i == 1) {
							    	buttonsObj.push({
							    		text :buttons[i]['title'],
							    		click: function() {
							    	        $( this ).dialog( "close" );
							    	        var response ={
							    	        		res : "ok",
							    	        		index : "1"
							    	        }
							    	        fn_response.call(null,response);
							    	    }
							    	});
						    	}
						}
					    $dialog.dialog( "option", "buttons", buttonsObj );						
						
					}else if(sort == "hcca_getDeviceUUID"){
						var fn_response = obj;
						var response ={
			    	        		res : "ok",
			    	        		UUID : "testUUID_0001"
		    	        		}
						fn_response.call(null,response);
						return;
					}else if(sort == "hcca_showLoginView"){
						var destURL = obj.destURL;
						var url = APP.getContextPath() + "/login/login0101"
						fn_goUrl(url);
						return;
					}else if(sort == "hcca_ShareSerachResult"){
						var searchUrl = obj.searchUrl;
						var message = obj.message;
						var str =  "searchUrl >> " + searchUrl + " \n message >> " + message;
						alert(str);
						return;
					}else if(sort == "hcca_showWebView"){
						var destURL = obj.destURL;
						fn_goUrl(destURL);
						return;
					}else if(sort == "hcca_showToast"){
						var message = obj.message;
						alert(message);
						return;
					}else if(sort == "hcca_slideUpGNB"){
						return;
					}else if(sort == "hcca_slideDownGNB"){
						return;
					}else if(sort == "hcca_setStatusBarStyle"){
						return;
					}else if(sort == "hcca_showSearchHistoryView"){
						return;
					}else if(sort == "hcca_showSearchView"){
						return;
					}else if(sort == "hcca_didCloseSearchFilter"){
						return;
					}else if(sort == "hcca_currentSearchResultTab"){
						return;
					}else if(sort == "hcca_shareForSNS"){
						var shareURL = obj.shareURL;
						var message = obj.message;
						//window.open('http://www.facebook.com/sharer/sharer.php?u=' + shareURL);
						window.open(shareURL);
						return;
					}else if(sort == "hcca_didTapBackButton"){
						var url = obj;
						history.go(-1);
						return;
					}else if(sort == "hcca_addSearchHistory"){
						return;
					}else if(sort == "hcca_storeChangedInfo"){
						return;
					}else if(sort == "ga_event"){
						//debugger;
						//var category = obj.category;
						//fn_response.call(null,response);
						return;
					}
				}
		}
	}	
}
