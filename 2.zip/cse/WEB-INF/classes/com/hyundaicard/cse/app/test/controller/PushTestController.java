package com.hyundaicard.cse.app.test.controller;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hyundaicard.cse.common.controller.CseAppController;
import com.hyundaicard.cse.common.view.Request;

/**
 * Handles requests for the application home page.
 */
@Controller
public class PushTestController extends CseAppController {

    private static final Logger logger = LoggerFactory.getLogger(PushTestController.class);

    /**
     * PUSH 테스트
     */
    @RequestMapping(value = "/api/test/push0101", method = RequestMethod.POST)
    public ModelAndView push0101(final HttpServletRequest httpServletRequest,
            final HttpServletResponse httpServletResponse, final Request request) throws Exception {

        logger.info(">>>>push0101");

        final String authKey = "AAAAv9HNCV8:APA91bEvzm1b3XY7IcaQTI6h5kwbyXImFBL9O1wEdRNzvkbu8P75dqZzOl7JbMEo0cYmtVRhn6Q4-Wl_LLUrWtvyzUrwkAM3vNx6hqqL9upnGM3DMuHl8ugZNZum9fIbX1x7KZInZiIX ";
        final String FMCurl = "https://fcm.googleapis.com/fcm/send";

        final JSONObject requestJson = request.getRequestBodyJson();
        final JSONObject responseJson = new JSONObject();

        final String appToken = requestJson.optString("appToken", "");

        try {
            final URL url = new URL(FMCurl);
            final HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setUseCaches(false);
            conn.setDoInput(true);
            conn.setDoOutput(true);

            conn.setRequestMethod("POST");
            conn.setRequestProperty("Authorization", "key=" + authKey);
            conn.setRequestProperty("Content-Type", "application/json");

            final JSONObject json = new JSONObject();
            json.put("to", appToken.trim());
            final JSONObject info = new JSONObject();
            info.put("title", "cse 푸시 테스트"); // Notification title
            info.put("body", "cse 푸시 테스트입니다.\n푸시를 잘 받으셨나요?"); // Notification body
            json.put("notification", info);

            final OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(json.toString());

            logger.debug("pushMessage = [" + json.toString() + "]");

            wr.flush();
            conn.getInputStream();

        } catch (final MalformedURLException e) {
            e.printStackTrace();
        } catch (final ProtocolException e) {
            e.printStackTrace();
        } catch (final IOException e) {
            e.printStackTrace();
        }

        logger.info("<<<<push0101");

        return createResponseModelAndView(httpServletRequest, httpServletResponse, request, responseJson);
    }

}
