package com.hyundaicard.cse.app.search.mapper;

import com.hyundaicard.cse.app.search.entity.SearchApiRequestEntity;

/**
 * 검색결과 Mapper
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public interface SearchMapper {

    public Integer chkTerm(SearchApiRequestEntity entity);

}
