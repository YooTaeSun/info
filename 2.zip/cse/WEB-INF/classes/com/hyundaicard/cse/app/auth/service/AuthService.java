package com.hyundaicard.cse.app.auth.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.auth.entity.AuthEntity;
import com.hyundaicard.cse.app.auth.mapper.AuthMapper;
import com.hyundaicard.cse.app.login.entity.UserEntity;

/**
 * Init Service
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
@Service
public class AuthService {

    /** Mapper */
    @Autowired
    private AuthMapper mapper;

    public AuthEntity checkAuthResult(final AuthEntity authEntity) {

        return mapper.checkAuthResult(authEntity);
    }

    /** 기가입 회원 조회 (HCC) */
    public String checkAlreadyJoinHCC(final String customerNo) {
        return mapper.checkAlreadyJoinHCC(customerNo);
    }

    /** 기가입 회원 조회 (SNS) */
    public String checkAlreadyJoinSNS(final String snsUid) {
        return mapper.checkAlreadyJoinSNS(snsUid);
    }

    /** 고객번호 갱신 */
    public void updateCustomerNo(final UserEntity userEntity) {
        mapper.updateCustomerNo(userEntity);
    }

}
