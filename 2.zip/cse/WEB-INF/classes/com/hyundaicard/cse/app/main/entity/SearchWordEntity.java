package com.hyundaicard.cse.app.main.entity;

import com.hyundaicard.cse.common.entity.AbstractPage;

/**
 * SearchWord Entity 검색 Entity
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public class SearchWordEntity extends AbstractPage {

    private String searchWord;
    private String searchWordId;
    private String searchKind;
    private String searchResultYn = "Y";
    private String query;
    private String intro;

    public String getSearchWord() {
        return searchWord;
    }

    public void setSearchWord(final String searchWord) {
        this.searchWord = searchWord;
    }

    public String getSearchWordId() {
        return searchWordId;
    }

    public void setSearchWordId(final String searchWordId) {
        this.searchWordId = searchWordId;
    }

    public String getSearchKind() {
        return searchKind;
    }

    public void setSearchKind(final String searchKind) {
        this.searchKind = searchKind;
    }

    public String getSearchResultYn() {
        return searchResultYn;
    }

    public void setSearchResultYn(final String searchResultYn) {
        this.searchResultYn = searchResultYn;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(final String query) {
        this.query = query;
    }

    public String getIntro() {
        return intro;
    }

    public void setIntro(final String intro) {
        this.intro = intro;
    }

    @Override
    public String toString() {
        return "SearchWordEntity [searchWord=" + searchWord + ", searchWordId=" + searchWordId + ", searchKind=" + searchKind + ", searchResultYn=" + searchResultYn + ", query=" + query + ", intro=" + intro + "]";
    }

}
