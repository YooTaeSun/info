package com.hyundaicard.cse.app.terms.mapper;

import org.springframework.dao.DataAccessException;

import com.hyundaicard.cse.app.terms.entity.TermsEntity;

/**
 * Terms Mapper
 */
public interface TermsMapper {

    /**
     * 코드별 약관 조회
     */
    public TermsEntity getTermsInfo(TermsEntity termsEntity) throws DataAccessException;
}
