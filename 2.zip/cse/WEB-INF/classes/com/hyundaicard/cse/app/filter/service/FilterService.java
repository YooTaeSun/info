package com.hyundaicard.cse.app.filter.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.filter.entity.FilterEntity;
import com.hyundaicard.cse.app.filter.mapper.FilterMapper;

/**
 * search filer Service
 * 
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Service
public class FilterService {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(FilterService.class);

    @Autowired
    private FilterMapper mapper;

    /**
     * 상세
     * 
     * @Mehtod Name : get
     * @param entity
     * @return
     */
    public FilterEntity get(FilterEntity entity) {
        return mapper.get(entity);
    }

    /**
     * 리스트
     * 
     * @Mehtod Name : getList
     * @param entity
     * @return
     */
    public List<FilterEntity> getAllList(FilterEntity entity) {
        return mapper.getAllList(entity);
    }

    /**
     * 전체 리스트
     * 
     * @Mehtod Name : getAllList
     * @param entity
     * @return
     */
    public List<FilterEntity> getList(FilterEntity entity) {
        return mapper.getList(entity);
    }

}