package com.hyundaicard.cse.app.question.mapper;

import java.util.List;

import com.hyundaicard.cse.app.question.entity.AnswerDetailEntity;
import com.hyundaicard.cse.app.question.entity.AnswerEntity;
import com.hyundaicard.cse.app.question.entity.SurveyTagEntity;

/**
 * Question Mapper
 */
public interface AnswerMapper {

    public int getAnswerCnt(AnswerEntity entity);

    public List<AnswerDetailEntity> getAnswerList(AnswerEntity entity);

    public void insert(AnswerEntity entity);

    public int insertDetail(AnswerDetailEntity entity);

    public List<SurveyTagEntity> getTagList(SurveyTagEntity entity);
}
