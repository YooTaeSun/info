package com.hyundaicard.cse.app.mypage.entity;

public class CodeEntity {
    private String code = null;
    private String codeNm = null;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCodeNm() {
        return codeNm;
    }

    public void setCodeNm(String codeNm) {
        this.codeNm = codeNm;
    }

}
