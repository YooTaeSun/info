package com.hyundaicard.cse.app.log.mapper;

import java.util.List;

import com.hyundaicard.cse.app.log.entity.PsnlLogEntity;

/**
 * psnlLog Mapper
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public interface PsnlLogMapper {

    /**
     * 등록
     *
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public void insertFnCall(PsnlLogEntity entity);

    /**
     * 수정
     *
     * @Mehtod Name : update
     * @param entity
     * @return
     */
    public void updateFnCall(PsnlLogEntity entity);

    /**
     * 로고형 list
     *
     * @Mehtod Name : getLankSite
     * @param entity
     * @return
     */
    public List<PsnlLogEntity> getLankSite(PsnlLogEntity entity);

    /**
     * 로고형 점수
     *
     * @Mehtod Name : getTotalFinalScore
     * @param entity
     * @return
     */
    public int getTotalFinalScore(PsnlLogEntity entity);
}
