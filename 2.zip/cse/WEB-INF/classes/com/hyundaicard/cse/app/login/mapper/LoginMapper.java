package com.hyundaicard.cse.app.login.mapper;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.hyundaicard.cse.app.login.entity.AutoLoginEntity;
import com.hyundaicard.cse.app.login.entity.UserEntity;

/**
 * Login Mapper 로그인 Mapper
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public interface LoginMapper {

    /**
     * get list 로그인가능 ID 리스트
     *
     * @method getUserIdList
     * @param Entity
     * @return
     * @throws DataAccessException
     */
    public List<UserEntity> getUserIdList() throws DataAccessException;

    /**
     * get Entity 선택한 ID의 사용자 정보 조회 (로그인처리)
     *
     * @method getUserInfo
     * @param Entity
     * @return
     * @throws DataAccessException
     */
    public UserEntity getUserInfo(UserEntity entity) throws DataAccessException;

    public UserEntity tempGetUserInfo(UserEntity entity) throws DataAccessException;

    /**
     * 회원정보의 UUID 갱신
     */
    public void updateUserUuid(UserEntity entity) throws DataAccessException;

    /**
     * 최종 로그인 시간 업데이트
     */
    public void updateLastLoginDate(UserEntity entity) throws DataAccessException;

    /**
     * 자동 로그인 정보 업데이트
     */
    public void updateAutoLoginInfo(AutoLoginEntity entity) throws DataAccessException;

    /**
     * 자동 로그인 정보 조회
     */
    public AutoLoginEntity getAutoLoginInfo(AutoLoginEntity entity) throws DataAccessException;

}
