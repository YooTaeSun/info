package com.hyundaicard.cse.app.main.mapper;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.hyundaicard.cse.app.main.entity.HotKeywordEntity;

/**
 * MAIN Mapper 메인 Mapper
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public interface MainMapper {

    /**
     * get Date 현재 날짜,시간
     *
     * @method getDate
     * @param String
     * @return
     * @throws DataAccessException
     */
    public String getDate(String format) throws DataAccessException;

    public List<Integer> getHotKeyGrp();

    public List<HotKeywordEntity> getHotKeyList(int hotKeySq);

    public String getLogoImg() throws DataAccessException;
}
