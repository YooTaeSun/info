package com.hyundaicard.cse.app.mypage.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hyundaicard.cse.app.mypage.entity.FaqEntity;
import com.hyundaicard.cse.app.mypage.service.FaqService;

/**
 * 마이페이지 - FAQ
 */

@Controller
public class FaqController {

    private static final Logger logger = LoggerFactory.getLogger(FaqController.class);

    @Autowired
    private FaqService faqService;

    /**
     * FAQ 리스트 조회
     */
    @RequestMapping(value = "/mypage/faq0101", method = RequestMethod.GET)
    public String faq0101(@ModelAttribute FaqEntity entity, Model model) {
        model.addAttribute("faqList", faqService.getFaqList(entity));
        model.addAttribute("paging", entity.getPaging());
        model.addAttribute("catCodeList", faqService.getCatCode(entity));
        return "mypage/faq0101";
    }

    /**
     * FAQ 상세 조회
     */
    // @RequestMapping(value = "/mypage/faq0102", method = RequestMethod.GET)
    // public String faq0102(@ModelAttribute FaqEntity entity, Model model) {
    //
    // model.addAttribute("faqInfo", faqService.getFaqDetail(entity));
    // model.addAttribute("paging", entity.getPaging());
    //
    // return "mypage/faq0101";
    // }

}
