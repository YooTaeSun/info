package com.hyundaicard.cse.app.search.service;

import java.io.IOException;
import java.io.StringReader;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.HtmlUtils;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hyundaicard.cse.app.bookmark.entity.BookmarkEntity;
import com.hyundaicard.cse.app.bookmark.entity.BookmarkQueryEntity;
import com.hyundaicard.cse.app.bookmark.service.BookmarkQueryService;
import com.hyundaicard.cse.app.bookmark.service.BookmarkService;
import com.hyundaicard.cse.app.bookmark.service.SessionService;
import com.hyundaicard.cse.app.filter.entity.FilterEntity;
import com.hyundaicard.cse.app.filter.service.FilterService;
import com.hyundaicard.cse.app.like.entity.LikeCountEntity;
import com.hyundaicard.cse.app.like.entity.LikeEntity;
import com.hyundaicard.cse.app.like.service.LikeCountService;
import com.hyundaicard.cse.app.like.service.LikeService;
import com.hyundaicard.cse.app.log.entity.PersonalTypeEntity;
import com.hyundaicard.cse.app.log.entity.PersonalTypeEntity.LogType;
import com.hyundaicard.cse.app.log.entity.PsnlLogEntity;
import com.hyundaicard.cse.app.log.service.PsnlLogService;
import com.hyundaicard.cse.app.question.entity.AnswerEntity;
import com.hyundaicard.cse.app.question.entity.SurveyTagEntity;
import com.hyundaicard.cse.app.question.service.AnswerService;
import com.hyundaicard.cse.app.search.entity.AutocompleteResultEntity;
import com.hyundaicard.cse.app.search.entity.CategoryResultEntity;
import com.hyundaicard.cse.app.search.entity.CategorySearchResultEntity;
import com.hyundaicard.cse.app.search.entity.NewPopularSiteResultEntity;
import com.hyundaicard.cse.app.search.entity.PersonalSiteResultEntity;
import com.hyundaicard.cse.app.search.entity.PopularSiteResultEntity;
import com.hyundaicard.cse.app.search.entity.SearchApiCotegoryRequestEntity;
import com.hyundaicard.cse.app.search.entity.SearchApiRequestEntity;
import com.hyundaicard.cse.app.search.entity.SearchAutocompleteRequestEntity;
import com.hyundaicard.cse.app.search.mapper.SearchMapper;
import com.hyundaicard.cse.common.code.ResultCode;
import com.hyundaicard.cse.common.entity.RestRespEntity;
import com.hyundaicard.cse.common.util.Config;
import com.hyundaicard.cse.constants.Constants;

/**
 * 검색결과 Service
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Service
public class SearchService {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(SearchService.class);

    @Autowired
    private RestTemplate apiRestTemplate;

    @Autowired
    private BookmarkQueryService bookmarkQueryService;

    @Autowired
    private FilterService filterService;

    @Autowired
    private LikeService likeService;

    @Autowired
    private LikeCountService likeCountService;

    @Autowired
    private BookmarkService bookmarkService;

    @Autowired
    private AnswerService answerService;

    @Autowired
    private PsnlLogService psnlLogService;

    @Autowired
    private SearchMapper searchMapper;

    @Autowired
    private SessionService sessionService;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * Product List
     *
     * @Mehtod Name : productList
     * @param entity
     * @return
     */
    public RestRespEntity cotegoryList(final SearchApiCotegoryRequestEntity entity) {
        final RestRespEntity restRespEntity = new RestRespEntity();
        restRespEntity.setResultCode(ResultCode.C0.getCode());

        try {
            final HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            final HttpEntity<?> requestParamEntity = new HttpEntity(headers);

            final String apiUrl = Config.getCommon().getString("SEARCH_ENGINE_API.SITE_URL") + Config.getCommon().getString("SEARCH_ENGINE_API.SITE_CATEGORY_LIST");

            final HashMap<String, String> param = new HashMap<String, String>();
            param.put("siteCategoryKey", entity.getSiteCategoryKeys());
            param.put("size", Config.getCommon().getString("BOOKMARK.CATEGORY.PRODUCT.SIZE"));//

            final String requestUrl = getSearchRequestParameter(apiUrl, param);

            logger.debug("requestUrl :: {}", requestUrl);

            final ResponseEntity<String> apiResponse = apiRestTemplate.exchange(requestUrl, HttpMethod.GET, requestParamEntity, String.class);

            if (apiResponse.getStatusCode() == HttpStatus.OK) {
                final String body = apiResponse.getBody();
                logger.debug(" body : {} ", body);

                final StringReader reader = new StringReader(body); // Json Response

                final CategoryResultEntity resultEntity = objectMapper.readValue(reader, CategoryResultEntity.class);
                restRespEntity.setResultData(resultEntity);
            }
            return restRespEntity;
        } catch (final HttpStatusCodeException exception) {
            final String body = exception.getResponseBodyAsString();
            logger.error(" body {} ", body);
            restRespEntity.setResultCode(ResultCode.C204.getCode());
            return restRespEntity;
        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            restRespEntity.setResultCode(ResultCode.C9999.getCode());
            return restRespEntity;
        }
    }

    /**
     * autocomplete List
     *
     * @Mehtod Name : autocompleteList
     * @param entity
     * @return
     */
    public RestRespEntity autocomplete(final SearchAutocompleteRequestEntity entity) {
        final RestRespEntity restRespEntity = new RestRespEntity();
        restRespEntity.setResultCode(ResultCode.C0.getCode());

        try {
            final HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            final HttpEntity<?> requestParamEntity = new HttpEntity(headers);

            final String apiUrl = Config.getCommon().getString("SEARCH_ENGINE_API.SITE_URL") + Config.getCommon().getString("SEARCH_ENGINE_API.AUTOCOMPLETE");

            final HashMap<String, String> param = new HashMap<String, String>();
            param.put("query", entity.getQuery());//
            param.put("size", Config.getCommon().getString("AUTOCOMPLETE.SIZE"));//

            final String requestUrl = getSearchRequestParameter(apiUrl, param);

            logger.debug("autocomplete requestUrl :: {}", requestUrl);

            final ResponseEntity<String> apiResponse = apiRestTemplate.exchange(requestUrl, HttpMethod.GET, requestParamEntity, String.class);

            if (apiResponse.getStatusCode() == HttpStatus.OK) {
                final String body = apiResponse.getBody();
                logger.debug(" body : {} ", body);

                final StringReader reader = new StringReader(body); // Json Response

                final AutocompleteResultEntity resultEntity = objectMapper.readValue(reader, AutocompleteResultEntity.class);
                restRespEntity.setResultData(resultEntity);
            }
            return restRespEntity;
        } catch (final HttpStatusCodeException exception) {
            final String body = exception.getResponseBodyAsString();
            logger.error("autocomplete body {} ", body);
            restRespEntity.setResultCode(ResultCode.C204.getCode());
            return restRespEntity;
        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            restRespEntity.setResultCode(ResultCode.C9999.getCode());
            return restRespEntity;
        }
    }

    /**
     * autocomplete List
     *
     * @Mehtod Name : autocompleteList
     * @param entity
     * @return
     */
    public RestRespEntity autocompleteBody(final SearchAutocompleteRequestEntity entity) {
        final RestRespEntity restRespEntity = new RestRespEntity();
        restRespEntity.setResultCode(ResultCode.C0000.getCode());

        try {
            final HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            final HttpEntity<?> requestParamEntity = new HttpEntity(headers);

            final String apiUrl = Config.getCommon().getString("SEARCH_ENGINE_API.SITE_URL") + Config.getCommon().getString("SEARCH_ENGINE_API.AUTOCOMPLETE");

            final HashMap<String, String> param = new HashMap<String, String>();
            param.put("query", entity.getQuery());//
            param.put("size", Config.getCommon().getString("AUTOCOMPLETE.SIZE"));//

            final String requestUrl = getSearchRequestParameter(apiUrl, param);

            logger.debug("autocomplete requestUrl :: {}", requestUrl);

            final ResponseEntity<String> apiResponse = apiRestTemplate.exchange(requestUrl, HttpMethod.GET, requestParamEntity, String.class);

            if (apiResponse.getStatusCode() == HttpStatus.OK) {
                final String body = apiResponse.getBody();
                logger.debug(" body : {} ", body);

                final JSONParser parser = new JSONParser();
                final Object obj = parser.parse(body);
                final JSONObject jsonObj = (JSONObject) obj;
                restRespEntity.setResultData(jsonObj);
            }
            return restRespEntity;
        } catch (final HttpStatusCodeException exception) {
            final String body = exception.getResponseBodyAsString();
            logger.error("autocomplete body {} ", body);
            restRespEntity.setResultCode(ResultCode.C204.getCode());
            return restRespEntity;
        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            restRespEntity.setResultCode(ResultCode.C9999.getCode());
            return restRespEntity;
        }
    }

    /**
     * 등록된 관심이 있는 검색어 insert
     *
     * @Mehtod Name : insertIfFavfavQuery
     * @param entity
     * @return
     */
    public void insertIfFavfavQuery(final List<?> rows, final List<BookmarkEntity> favoriteList, final String query) {
        final List<BookmarkQueryEntity> bookmarkQueryList = new ArrayList<BookmarkQueryEntity>();

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }

        String siteKey = "";
        String catKey = "";
        String _siteKey = "";
        String _catKey = "";

        for (final BookmarkEntity favoriteRow : favoriteList) {
            for (final Object obj : rows) {
                if (obj instanceof PopularSiteResultEntity) {
                    final PopularSiteResultEntity row = (PopularSiteResultEntity) obj;
                    _siteKey = row.getId();
                    if (row.getCategory() != null) {
                        _catKey = row.getCategory().getId();
                    } else {
                        _catKey = "";
                        continue;
                    }
                    logger.debug(" _siteKey : {}, _catKey : {} ", _siteKey, _catKey);

                } else if (obj instanceof NewPopularSiteResultEntity) {
                    final NewPopularSiteResultEntity row = (NewPopularSiteResultEntity) obj;
                    _siteKey = row.getId();
                    _catKey = row.getCategory().getId();
                } else if (obj instanceof PersonalSiteResultEntity) {
                    final PersonalSiteResultEntity row = (PersonalSiteResultEntity) obj;
                    _siteKey = row.getId();
                    if (row.getCategory() == null) {
                        continue;
                    }
                    _catKey = row.getCategory().getId();
                }

                siteKey = favoriteRow.getSiteKey();
                catKey = favoriteRow.getCatKey();

                if (siteKey.equals(_siteKey) && catKey.equals(_catKey)) {
                    // TS_FAV_SITE_CAT_QUERY_INFO(회원관심사이트검색어정보) table insert List
                    final BookmarkQueryEntity bookmarkQueryEntity = new BookmarkQueryEntity();
                    bookmarkQueryEntity.setQuery(query);
                    bookmarkQueryEntity.setMemberIdSq(memberIdSq);
                    bookmarkQueryEntity.setUuid(uuid);
                    bookmarkQueryEntity.setSiteKey(siteKey);
                    bookmarkQueryEntity.setCatKey(catKey);
                    bookmarkQueryList.add(bookmarkQueryEntity);
                }
            }
        }
        if (!favoriteList.isEmpty()) {
            // TS_FAV_SITE_CAT_QUERY_INFO(회원관심사이트검색어정보) table insert
            bookmarkQueryService.insert(bookmarkQueryList);
        }
    }

    /**
     * 필터 정보를 조회한다.
     *
     * @Mehtod Name : filterInfo
     * @param List
     * @param Map
     * @return
     */
    public Map<String, Object> filterInfo(final List<String> fltgrpCdList) {

        // 필터
        final Map<String, Object> filterMap = new LinkedHashMap<String, Object>();
        if (!fltgrpCdList.isEmpty()) {
            for (final String fltgrpCd : fltgrpCdList) {
                final FilterEntity filterParam = new FilterEntity();
                filterParam.setFltgrpCd(fltgrpCd);
                filterMap.put(fltgrpCd, filterService.getAllList(filterParam));
            }
        }
        return filterMap;
    }

    /**
     * detailBackInfo List
     *
     * @Mehtod Name : autocompleteList
     * @param entity
     * @return
     */
    public RestRespEntity detailBackInfo(final LikeEntity entity) {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }

        final RestRespEntity restRespEntity = new RestRespEntity();
        restRespEntity.setResultCode(ResultCode.C0.getCode());

        final CategorySearchResultEntity category = new CategorySearchResultEntity();

        try {
            // 좋아요
            entity.setMemberIdSq(memberIdSq);
            entity.setUuid(uuid);
            category.setCtg_is_like("N");
            if (likeService.get(entity) != null) {
                category.setCtg_is_like("Y");
            }

            // 좋아요 카운트
            final LikeCountEntity likeCountParam = new LikeCountEntity();
            likeCountParam.setSiteKey(entity.getSiteKey());
            likeCountParam.setCatKey(entity.getCatKey());
            final LikeCountEntity likeCount = likeCountService.get(likeCountParam);
            category.setCtg_cnt("0");
            if (likeCount != null) {
                category.setCtg_cnt(likeCount.getLikeCnt());
            }

            // 북마크
            final BookmarkEntity bookmarkParam = new BookmarkEntity();
            bookmarkParam.setSiteKey(entity.getSiteKey());
            bookmarkParam.setCatKey(entity.getCatKey());
            bookmarkParam.setMemberIdSq(memberIdSq);
            bookmarkParam.setUuid(uuid);
            category.setCtg_is_bookmark("N");

            if (bookmarkService.get(bookmarkParam) != null) {
                category.setCtg_is_bookmark("Y");
            }

            restRespEntity.setResultData(category);
            return restRespEntity;

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            restRespEntity.setResultCode(ResultCode.C9999.getCode());
            return restRespEntity;
        }
    }

    public String getSearchRequestParameter(final String url, final Map<String, String> map) throws URISyntaxException {
        UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromHttpUrl(url);
        for (final Iterator<String> iterator = map.keySet().iterator(); iterator.hasNext();) {
            final String key = iterator.next();
            if (key.equalsIgnoreCase("query")) {
                uriComponentsBuilder = uriComponentsBuilder.queryParam(key, HtmlUtils.htmlUnescape(map.get(key)));
            } else {
                uriComponentsBuilder = uriComponentsBuilder.queryParam(key, map.get(key));
            }
        }

        final UriComponents uriComponents = uriComponentsBuilder.build(false);
        // return new URI(uriComponents.toUriString()).toString();
        return uriComponents.toUriString();
    }

    public String genderFilterAppend(String requestUrl, final String filter) throws IOException, JsonParseException, JsonMappingException {
        // 2017.10.09 필터 gender 선택시 검색어에 필터한글명 부쳐주기
        final HashMap map = objectMapper.readValue(filter, HashMap.class);
        if (map.containsKey("gender")) {
            final List<String> genderList = (List<String>) map.get("gender");
            if (!genderList.isEmpty()) {
                final StringBuilder sb = new StringBuilder();

                for (final String genderkey : genderList) {
                    if (genderkey.equals("M")) {
                        sb.append(" 남성");
                    } else if (genderkey.equals("W")) {
                        sb.append(" 여성");
                    } else if (genderkey.equals("K")) {
                        sb.append(" 키즈");
                    }
                }
                if (sb.length() > 0) {
                    String str = requestUrl.substring(requestUrl.indexOf("query="));
                    logger.debug("str : {} ", str);
                    str = str.substring(0, str.indexOf("&"));
                    logger.debug("str : {} ", str);

                    logger.debug("requestUrl : {} ", requestUrl);
                    requestUrl = requestUrl.replaceAll(str, str + sb.toString());
                }
            }
        }
        return requestUrl;
    }

    /**
     * 내게 맞는 유형
     *
     * @Mehtod Name : getPersonalType
     * @return
     */
    public PersonalTypeEntity getPersonalType() {

        final PersonalTypeEntity param = new PersonalTypeEntity();
        param.setLogType(new PersonalTypeEntity.LogType());
        /**
         * 17.08.21 설문 유무 return
         */
        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }

        String questionYn = "N";
        final AnswerEntity answerEntity = new AnswerEntity();
        answerEntity.setLoginIDInSession(memberIdSq);
        answerEntity.setUuid(uuid);
        if (answerService.getAnswerCnt(answerEntity) > 0) {
            questionYn = "Y";
        }
        /**
         * 17.08.21 HCC인증 유무 return
         */
        final String hccAuthYn = sessionService.getAttribute("hccAuthYN");

        String personalType = "";
        // 기본형 1 여기에는 없다.
        if ("N".equals(hccAuthYn) && "N".equals(questionYn)) {
            // getLankSite
            final PsnlLogEntity psnlLogParam = new PsnlLogEntity();
            psnlLogParam.setMemberIdSq(memberIdSq);
            psnlLogParam.setUuid(uuid);

            final int totalFinalScore = psnlLogService.getTotalFinalScore(psnlLogParam);
            final LogType logType = new PersonalTypeEntity.LogType();

            if (totalFinalScore >= 4) {
                personalType = Constants.PERSONAL_TYPE_BAS_3;
                final List<PsnlLogEntity> psnlLogList = psnlLogService.getLankSite(psnlLogParam);
                final StringBuilder siteKeystr = new StringBuilder();
                for (final PsnlLogEntity e : psnlLogList) {
                    siteKeystr.append(",\"" + e.getSiteKey() + "\"");
                }
                logType.setSiteKeys("[" + siteKeystr.toString().substring(1) + "]");

            } else {
                personalType = Constants.PERSONAL_TYPE_BAS_1;

                logType.setPercent(String.valueOf(totalFinalScore * 25));
                logType.setCount(String.valueOf(totalFinalScore));
            }
            param.setLogType(logType);

        } else if ("N".equals(hccAuthYn) && "Y".equals(questionYn)) {
            personalType = Constants.PERSONAL_TYPE_BAS_2;
        } else if ("Y".equals(hccAuthYn) && "Y".equals(questionYn)) {
            personalType = Constants.PERSONAL_TYPE_MEM_1;
        } else if ("Y".equals(hccAuthYn) && "N".equals(questionYn)) {
            personalType = Constants.PERSONAL_TYPE_MEM_2;
        }

        logger.debug("personalType {}", personalType);
        param.setPersonalTyp(personalType);
        return param;
    }

    /**
     * 설문작성 정보
     *
     * @Mehtod Name : getSurveyTags
     * @return
     */
    public String getSurveyTags(final SearchApiRequestEntity entity, final RestRespEntity restRespEntity) throws JsonProcessingException {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }

        final SurveyTagEntity tagEntity = new SurveyTagEntity();
        tagEntity.setLoginIDInSession(memberIdSq);
        tagEntity.setUuid(uuid);
        final List<SurveyTagEntity> surveyTagList = answerService.getTagList(tagEntity);
        final List<String> tagList = new ArrayList<String>();
        String tags = "";
        if (!surveyTagList.isEmpty()) {
            for (final SurveyTagEntity e : surveyTagList) {
                tagList.add(e.getTagVal());
            }

            tags = objectMapper.writeValueAsString(tagList);
            logger.debug(" tags : {}", tags);
        }
        return tags;
    }

    public Integer chkTerm(final SearchApiRequestEntity entity) {
        return searchMapper.chkTerm(entity);
    }

}
