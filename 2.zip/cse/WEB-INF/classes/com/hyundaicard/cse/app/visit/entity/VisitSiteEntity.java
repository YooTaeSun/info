package com.hyundaicard.cse.app.visit.entity;

/**
 * visit site Entity
 * 
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public class VisitSiteEntity {
    private String visitSiteCatSq; // 방문 사이트 순번
    private String memberIdSq; // 회원아이디 일련번호
    private String uuid; // 비회원 단말 식별값
    private String siteKey; // 사이트키
    private String catKey; // 카테고리키
    private String visitType; // 방문유형 10:사이트상세/20:사이트URL/30:상품URL
    private String insertDt; // 등록일시

    public String getVisitSiteCatSq() {
        return visitSiteCatSq;
    }

    public void setVisitSiteCatSq(String visitSiteCatSq) {
        this.visitSiteCatSq = visitSiteCatSq;
    }

    public String getMemberIdSq() {
        return memberIdSq;
    }

    public void setMemberIdSq(String memberIdSq) {
        this.memberIdSq = memberIdSq;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getSiteKey() {
        return siteKey;
    }

    public void setSiteKey(String siteKey) {
        this.siteKey = siteKey;
    }

    public String getCatKey() {
        return catKey;
    }

    public void setCatKey(String catKey) {
        this.catKey = catKey;
    }

    public String getVisitType() {
        return visitType;
    }

    public void setVisitType(String visitType) {
        this.visitType = visitType;
    }

    public String getInsertDt() {
        return insertDt;
    }

    public void setInsertDt(String insertDt) {
        this.insertDt = insertDt;
    }

}
