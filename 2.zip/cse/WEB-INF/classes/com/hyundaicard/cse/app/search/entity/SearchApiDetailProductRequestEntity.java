//package com.hyundaicard.cse.app.search.entity;
//
//import org.hibernate.validator.constraints.NotEmpty;
//
///**
// * 검색 DetailProduct Request Entity
// * 
// * @version : 1.0
// * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
// */
//public class SearchApiDetailProductRequestEntity {
//
//    @NotEmpty
//    private String siteCategoryKey;
//    @NotEmpty
//    private int size;
//    @NotEmpty
//    private int page;
//
//    public String getSiteCategoryKey() {
//        return siteCategoryKey;
//    }
//
//    public void setSiteCategoryKey(String siteCategoryKey) {
//        this.siteCategoryKey = siteCategoryKey;
//    }
//
//    public int getSize() {
//        return size;
//    }
//
//    public void setSize(int size) {
//        this.size = size;
//    }
//
//    public int getPage() {
//        return page;
//    }
//
//    public void setPage(int page) {
//        this.page = page;
//    }
//}
