package com.hyundaicard.cse.app.login.entity;

import com.hyundaicard.cse.common.entity.AbstractPage;

/**
 * AutoLoginEntity.java
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public class AutoLoginEntity extends AbstractPage {

    private String loginId;
    private String uuid;
    private String loginAuthToken;
    private String hc1;
    private String hc2;
    private String memberIdSq;
    private String customerNo;
    private String hccAuthYN;

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(final String loginId) {
        this.loginId = loginId;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    public String getLoginAuthToken() {
        return loginAuthToken;
    }

    public void setLoginAuthToken(final String loginAuthToken) {
        this.loginAuthToken = loginAuthToken;
    }

    public String getHc1() {
        return hc1;
    }

    public void setHc1(final String hc1) {
        this.hc1 = hc1;
    }

    public String getHc2() {
        return hc2;
    }

    public void setHc2(final String hc2) {
        this.hc2 = hc2;
    }

    public String getMemberIdSq() {
        return memberIdSq;
    }

    public void setMemberIdSq(final String memberIdSq) {
        this.memberIdSq = memberIdSq;
    }

    public String getCustomerNo() {
        return customerNo;
    }

    public void setCustomerNo(final String customerNo) {
        this.customerNo = customerNo;
    }

    public String getHccAuthYN() {
        return hccAuthYN;
    }

    public void setHccAuthYN(final String hccAuthYN) {
        this.hccAuthYN = hccAuthYN;
    }

    @Override
    public String toString() {
        return "AutoLoginEntity [loginId=" + loginId + ", uuid=" + uuid + ", loginAuthToken=" + loginAuthToken
                + ", hc1=" + hc1 + ", hc2=" + hc2 + ", memberIdSq=" + memberIdSq + ", customerNo=" + customerNo
                + ", hccAuthYN=" + hccAuthYN + "]";
    }

}
