package com.hyundaicard.cse.app.bookmark.entity;

import java.util.List;

import com.hyundaicard.cse.app.mypage.entity.SaleInfoEntity;
import com.hyundaicard.cse.app.search.entity.CategorySearchResultEntity;

/**
 * bookmark Entity
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */

public class BookmarkEntity {
    private String favSiteCatSq; // 관심 사이트 순번
    private String memberIdSq; // 회원아이디 일련번호
    private String uuid; // 비회원 단말 식별값
    private String siteKey; // 사이트키
    private String catKey; // 카테고리키
    private String siteMatching; // 사이트 매칭율
    private String insertDt;
    private String insertId;

    private List<CategorySearchResultEntity> categoryRows; // custom

    private String query; // custom
    private List<BookmarkQueryEntity> bookmarkQueryList; // custom
    private String delBookmarks; // custom
    private List<BookmarkEntity> delBookmarkList; // custom
    private String catKeys; // custom
    private List<BookmarkSiteEntity> bookmarkSiteList; // custom
    private SaleInfoEntity saleInfo; // custom 세일 정보

    private String queryKeyword; // log custom
    private String queryTypeCd; // log custom
    private String pageInfo; // log custom
    private String itemCount; // log custom
    private String itemPos; // log custom
    private String clickItemType; // log custom

    public String getFavSiteCatSq() {
        return favSiteCatSq;
    }

    public void setFavSiteCatSq(final String favSiteCatSq) {
        this.favSiteCatSq = favSiteCatSq;
    }

    public String getMemberIdSq() {
        return memberIdSq;
    }

    public void setMemberIdSq(final String memberIdSq) {
        this.memberIdSq = memberIdSq;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    public String getSiteKey() {
        return siteKey;
    }

    public void setSiteKey(final String siteKey) {
        this.siteKey = siteKey;
    }

    public String getCatKey() {
        return catKey;
    }

    public void setCatKey(final String catKey) {
        this.catKey = catKey;
    }

    public String getSiteMatching() {
        return siteMatching;
    }

    public void setSiteMatching(final String siteMatching) {
        this.siteMatching = siteMatching;
    }

    public String getInsertDt() {
        return insertDt;
    }

    public void setInsertDt(final String insertDt) {
        this.insertDt = insertDt;
    }

    public String getInsertId() {
        return insertId;
    }

    public void setInsertId(final String insertId) {
        this.insertId = insertId;
    }

    public List<CategorySearchResultEntity> getCategoryRows() {
        return categoryRows;
    }

    public void setCategoryRows(final List<CategorySearchResultEntity> categoryRows) {
        this.categoryRows = categoryRows;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(final String query) {
        this.query = query;
    }

    public List<BookmarkQueryEntity> getBookmarkQueryList() {
        return bookmarkQueryList;
    }

    public void setBookmarkQueryList(final List<BookmarkQueryEntity> bookmarkQueryList) {
        this.bookmarkQueryList = bookmarkQueryList;
    }

    public String getDelBookmarks() {
        return delBookmarks;
    }

    public void setDelBookmarks(final String delBookmarks) {
        this.delBookmarks = delBookmarks;
    }

    public List<BookmarkEntity> getDelBookmarkList() {
        return delBookmarkList;
    }

    public void setDelBookmarkList(final List<BookmarkEntity> delBookmarkList) {
        this.delBookmarkList = delBookmarkList;
    }

    public String getCatKeys() {
        return catKeys;
    }

    public void setCatKeys(final String catKeys) {
        this.catKeys = catKeys;
    }

    public List<BookmarkSiteEntity> getBookmarkSiteList() {
        return bookmarkSiteList;
    }

    public void setBookmarkSiteList(final List<BookmarkSiteEntity> bookmarkSiteList) {
        this.bookmarkSiteList = bookmarkSiteList;
    }

    public SaleInfoEntity getSaleInfo() {
        return saleInfo;
    }

    public void setSaleInfo(final SaleInfoEntity saleInfo) {
        this.saleInfo = saleInfo;
    }

    public String getQueryKeyword() {
        return queryKeyword;
    }

    public void setQueryKeyword(final String queryKeyword) {
        this.queryKeyword = queryKeyword;
    }

    public String getQueryTypeCd() {
        return queryTypeCd;
    }

    public void setQueryTypeCd(final String queryTypeCd) {
        this.queryTypeCd = queryTypeCd;
    }

    public String getPageInfo() {
        return pageInfo;
    }

    public void setPageInfo(final String pageInfo) {
        this.pageInfo = pageInfo;
    }

    public String getItemCount() {
        return itemCount;
    }

    public void setItemCount(final String itemCount) {
        this.itemCount = itemCount;
    }

    public String getItemPos() {
        return itemPos;
    }

    public void setItemPos(final String itemPos) {
        this.itemPos = itemPos;
    }

    public String getClickItemType() {
        return clickItemType;
    }

    public void setClickItemType(final String clickItemType) {
        this.clickItemType = clickItemType;
    }

}
