package com.hyundaicard.cse.app.like.mapper;

import java.util.List;

import com.hyundaicard.cse.app.like.entity.LikeEntity;

/**
 * like Mapper
 * 
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public interface LikeMapper {

    /**
     * 조회
     * 
     * @Mehtod Name : get
     * @param entity
     * @return
     */
    public LikeEntity get(LikeEntity entity);

//    /**
//     * 리스트
//     * 
//     * @Mehtod Name : getList
//     * @param entity
//     * @return
//     */
//    public List<LikeEntity> getList(LikeEntity entity);

    /**
     * 전체 리스트
     * 
     * @Mehtod Name : getAllList
     * @param entity
     * @return
     */
    public List<LikeEntity> getAllList(LikeEntity entity);

//    /**
//     * 전체목록
//     * 
//     * @Mehtod Name : getListTotal
//     * @param entity
//     * @return
//     */
//    public List<LikeEntity> getListTotal(LikeEntity entity);

//    /**
//     * 카운트
//     * 
//     * @Mehtod Name : count
//     * @param entity
//     * @return
//     */
//    public int count(LikeEntity entity);

    /**
     * 등록
     * 
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public void insert(LikeEntity entity);

//    /**
//     * 수정
//     * 
//     * @Mehtod Name : update
//     * @param entity
//     * @return
//     */
//    public void update(LikeEntity entity);

    /**
     * 삭제
     * 
     * @Mehtod Name : delete
     * @param entity
     * @return
     */
    public void delete(LikeEntity entity);
}
