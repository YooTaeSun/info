package com.hyundaicard.cse.app.auth.entity;

import com.hyundaicard.cse.common.entity.AbstractPage;

/**
 * Auth Entity
 *
 * @version : 1.0
 */
public class AuthEntity extends AbstractPage {

    private String successCode; // 통신응답코드
    private String uuid; // UUID
    private String timeStamp;
    private String customerNo; // 고객번호
    private String marketingAgreeYn; // 마케팅동의여부
    private String resultCode; // 결과코드
    private String cancelYn; // 취소여부

    public String getSuccessCode() {
        return successCode;
    }

    public void setSuccessCode(final String successCode) {
        this.successCode = successCode;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(final String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getCustomerNo() {
        return customerNo;
    }

    public void setCustomerNo(final String customerNo) {
        this.customerNo = customerNo;
    }

    public String getMarketingAgreeYn() {
        return marketingAgreeYn;
    }

    public void setMarketingAgreeYn(final String marketingAgreeYn) {
        this.marketingAgreeYn = marketingAgreeYn;
    }

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(final String resultCode) {
        this.resultCode = resultCode;
    }

    public String getCancelYn() {
        return cancelYn;
    }

    public void setCancelYn(final String cancelYn) {
        this.cancelYn = cancelYn;
    }

    @Override
    public String toString() {
        return "AuthEntity [successCode=" + successCode + ", uuid=" + uuid + ", timeStamp=" + timeStamp
                + ", customerNo=" + customerNo + ", marketingAgreeYn=" + marketingAgreeYn + ", resultCode=" + resultCode
                + ", cancelYn=" + cancelYn + "]";
    }

}
