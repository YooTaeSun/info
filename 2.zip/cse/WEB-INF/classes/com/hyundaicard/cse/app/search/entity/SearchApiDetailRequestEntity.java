package com.hyundaicard.cse.app.search.entity;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * 검색 Detail Request Entity
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public class SearchApiDetailRequestEntity {

    @NotEmpty
    private String siteId;
    @NotEmpty
    private String query;

    private Integer size;
    private String searchKind;

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(final String siteId) {
        this.siteId = siteId;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(final String query) {
        this.query = query;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(final Integer size) {
        this.size = size;
    }

    public String getSearchKind() {
        return searchKind;
    }

    public void setSearchKind(final String searchKind) {
        this.searchKind = searchKind;
    }

    @Override
    public String toString() {
        return "SearchApiDetailRequestEntity [siteId=" + siteId + ", query=" + query + "]";
    }

}
