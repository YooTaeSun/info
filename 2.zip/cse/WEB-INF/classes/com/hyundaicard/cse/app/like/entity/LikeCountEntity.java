package com.hyundaicard.cse.app.like.entity;

/**
 * favorite Entity
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public class LikeCountEntity {
    private String siteKey; // 사이트키
    private String catKey; // 카테고리키
    private String likeCnt; // 좋아요수
    private String siteKeys;
    private String catKeys;

    public String getSiteKey() {
        return siteKey;
    }

    public void setSiteKey(final String siteKey) {
        this.siteKey = siteKey;
    }

    public String getCatKey() {
        return catKey;
    }

    public void setCatKey(final String catKey) {
        this.catKey = catKey;
    }

    public String getLikeCnt() {
        return likeCnt;
    }

    public void setLikeCnt(final String likeCnt) {
        this.likeCnt = likeCnt;
    }

    public String getSiteKeys() {
        return siteKeys;
    }

    public void setSiteKeys(final String siteKeys) {
        this.siteKeys = siteKeys;
    }

    public String getCatKeys() {
        return catKeys;
    }

    public void setCatKeys(final String catKeys) {
        this.catKeys = catKeys;
    }

}
