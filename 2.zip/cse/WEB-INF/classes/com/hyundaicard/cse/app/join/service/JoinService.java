package com.hyundaicard.cse.app.join.service;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.join.mapper.JoinMapper;
import com.hyundaicard.cse.app.login.entity.UserEntity;
import com.hyundaicard.cse.common.exception.BizException;

/**
 * Init Service
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
@Service
public class JoinService {

    /** Mapper */
    @Autowired
    private JoinMapper joinMapper;

    @Autowired
    public MessageSource messageSource;

    /** ID 유효성 체크 */
    public void validateUserId(final String userId) throws Exception {

        if (userId == null || userId.length() == 0) {
            throw new BizException(messageSource, "JOIN0004", Locale.getDefault());
        }

        for (int i = 0; i < userId.length(); i++) {
            if (userId.charAt(i) == ' ') {
                throw new BizException(messageSource, "JOIN0005", Locale.getDefault());
            }
        }

        if (userId.length() < 2) {
            throw new BizException(messageSource, "JOIN0006", Locale.getDefault());
        }

        if (userId.length() > 12) {
            throw new BizException(messageSource, "JOIN0007", Locale.getDefault());
        }

        final Pattern p = Pattern.compile(".*[^가-힣ㄱ-ㅎㅏ-ㅣa-zA-Z0-9].*");
        final Matcher m = p.matcher(userId);

        if (m.matches()) {
            throw new BizException(messageSource, "JOIN0008", Locale.getDefault());
        }

    }

    /** ID 중복 체크 */
    public String checkUserIdDuplicate(final String userId) {
        String usePossibleYN = "Y";

        // TODO: ID 중복체크
        usePossibleYN = joinMapper.checkUserIdDuplicate(userId);

        return usePossibleYN;
    }

    /** 회원 가입 */
    public void registUserId(final UserEntity userEntity) {
        joinMapper.registUserId(userEntity);
    }

    /**
     * 기존 HCC 인증 계정 초기화
     */
    public void updateCustomerNoDefault(final UserEntity userEntity) {
        joinMapper.updateCustomerNoDefault(userEntity);
    }

    /**
     * 회원가입된 memberIdSq 조회
     */
    public String selectMemberIdSq(final UserEntity userEntity) {
        return joinMapper.selectMemberIdSq(userEntity);
    }

    /**
     * 비회원 상태로 한 좋아요/북마크/리뷰/설문 정보를 가입한 ID에 맵핑
     */
    public void migrationPersonalInfo(final UserEntity userEntity) {
        // DB 타임아웃으로 인해 각 테이블 별도로 처리
        // 북마크
        joinMapper.migrationBookmarkInfo(userEntity);
        // 좋아요
        joinMapper.migrationLikeInfo(userEntity);
        // 리뷰
        joinMapper.migrationReviewInfo(userEntity);
        // 설문
        joinMapper.migrationSurveyInfo(userEntity);
    }
}
