package com.hyundaicard.cse.app.init.entity;

import com.hyundaicard.cse.common.entity.AbstractPage;

/**
 * UpdateInfo Entity
 * 
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public class UpdateInfoEntity extends AbstractPage {

    private String osType;
    private String appVersion;
    private String appDesc;
    private String forceUpdateYN;

    public String getOsType() {
        return osType;
    }

    public void setOsType(String osType) {
        this.osType = osType;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public String getAppDesc() {
        return appDesc;
    }

    public void setAppDesc(String appDesc) {
        this.appDesc = appDesc;
    }

    public String getForceUpdateYN() {
        return forceUpdateYN;
    }

    public void setForceUpdateYN(String forceUpdateYN) {
        this.forceUpdateYN = forceUpdateYN;
    }

    @Override
    public String toString() {
        return "UpdateInfoEntity [osType=" + osType + ", appVersion=" + appVersion + ", appDesc=" + appDesc
                + ", forceUpdateYN=" + forceUpdateYN + "]";
    }

}
