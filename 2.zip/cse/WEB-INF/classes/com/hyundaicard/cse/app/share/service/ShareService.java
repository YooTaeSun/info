package com.hyundaicard.cse.app.share.service;

import java.io.File;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.bookmark.service.SessionService;
import com.hyundaicard.cse.app.share.entity.ShareEntity;
import com.hyundaicard.cse.app.share.mapper.ShareMapper;
import com.hyundaicard.cse.common.util.Config;

/**
 * share Service
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Service
public class ShareService {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(ShareService.class);

    @Autowired
    private SessionService sessionService;

    @Autowired
    private ShareMapper mapper;

    /**
     * 상세
     *
     * @Mehtod Name : get
     * @param entity
     * @return
     */
    public ShareEntity get(final ShareEntity entity) {
        return mapper.get(entity);
    }

    /**
     * 입력
     *
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public String insert(final ShareEntity entity) {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        final String uuid = sessionService.getAttribute("uuid");

        entity.setMemberIdSq(memberIdSq);
        entity.setUuid(uuid);

        entity.setPath1(generateKey(5) + File.separator);

        mapper.insert(entity);

        final String shortUrl = Config.getCommon().getString("HOST_URL") + File.separator + "share" + File.separator + entity.getShortenUrl();
        logger.debug(" shortUrl : {}", shortUrl);
        logger.debug(" realUrl : {}", entity.getRealUrl());
        return shortUrl;
    }

    static public String generateKey(final int keyLength) {

        String key = "";
        // final boolean flag = true;

        // private final HashMap<String, String> keyMap = new HashMap<String, String>(); // key-url map
        final Random myRand = new Random();
        final char myChars[] = new char[62];
        for (int i = 0; i < 62; i++) {
            int j = 0;
            if (i < 10) {
                j = i + 48;
            } else if (i > 9 && i <= 35) {
                j = i + 55;
            } else {
                j = i + 61;
            }
            myChars[i] = (char) j;
        }

        for (int i = 0; i <= keyLength; i++) {
            key += myChars[myRand.nextInt(62)];
        }
        return key;
    }
}
