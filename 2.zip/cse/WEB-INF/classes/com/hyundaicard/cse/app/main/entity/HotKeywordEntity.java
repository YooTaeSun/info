package com.hyundaicard.cse.app.main.entity;

public class HotKeywordEntity {

    private int keywordGrpSq;
    private int keywordSeq;
    private String keyword;

    public HotKeywordEntity() {
        super();
        // TODO Auto-generated constructor stub
    }

    public HotKeywordEntity(final String keyword) {
        super();
        this.keyword = keyword;
    }

    public int getKeywordGrpSq() {
        return keywordGrpSq;
    }

    public void setKeywordGrpSq(final int keywordGrpSq) {
        this.keywordGrpSq = keywordGrpSq;
    }

    public int getKeywordSeq() {
        return keywordSeq;
    }

    public void setKeywordSeq(final int keywordSeq) {
        this.keywordSeq = keywordSeq;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(final String keyword) {
        this.keyword = keyword;
    }

}
