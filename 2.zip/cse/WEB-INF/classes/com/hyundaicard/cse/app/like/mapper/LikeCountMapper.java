package com.hyundaicard.cse.app.like.mapper;

import java.util.List;

import com.hyundaicard.cse.app.like.entity.LikeCountEntity;

/**
 * favorite Mapper
 * 
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public interface LikeCountMapper {

    /**
     * 조회
     * 
     * @Mehtod Name : get
     * @param entity
     * @return
     */
    public LikeCountEntity get(LikeCountEntity entity);

//    /**
//     * 리스트
//     * 
//     * @Mehtod Name : getList
//     * @param entity
//     * @return
//     */
//    public List<LikeCountEntity> getList(LikeCountEntity entity);

    /**
     * 전체 리스트
     * 
     * @Mehtod Name : getAllList
     * @param entity
     * @return
     */
    public List<LikeCountEntity> getAllList(LikeCountEntity entity);

//    /**
//     * 전체목록
//     * 
//     * @Mehtod Name : getListTotal
//     * @param entity
//     * @return
//     */
//    public List<LikeCountEntity> getListTotal(LikeCountEntity entity);

//    /**
//     * 카운트
//     * 
//     * @Mehtod Name : count
//     * @param entity
//     * @return
//     */
//    public int count(LikeCountEntity entity);

    /**
     * 등록
     * 
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public void insert(LikeCountEntity entity);

    /**
     * 수정
     * 
     * @Mehtod Name : update
     * @param entity
     * @return
     */
    public void update(LikeCountEntity entity);

//    /**
//     * 삭제
//     * 
//     * @Mehtod Name : delete
//     * @param entity
//     * @return
//     */
//    public void delete(LikeCountEntity entity);
}
