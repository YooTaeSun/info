package com.hyundaicard.cse.app.search.entity;

import java.util.List;

/**
 * autocomplete result Entity
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public class AutocompleteResultEntity {
    private Data data;

    public Data getData() {
        return data;
    }

    public void setData(final Data data) {
        this.data = data;
    }

    public static class Data {
        private List<WordResultEntity> rows;
        private RangeResultEntity range;

        public List<WordResultEntity> getRows() {
            return rows;
        }

        public void setRows(final List<WordResultEntity> rows) {
            this.rows = rows;
        }

        public RangeResultEntity getRange() {
            return range;
        }

        public void setRange(final RangeResultEntity range) {
            this.range = range;
        }

        public static class WordResultEntity {
            private String id;
            private String keyword_ngram;
            private String cnt;

            public String getId() {
                return id;
            }

            public void setId(final String id) {
                this.id = id;
            }

            public String getKeyword_ngram() {
                return keyword_ngram;
            }

            public void setKeyword_ngram(final String keyword_ngram) {
                this.keyword_ngram = keyword_ngram;
            }

            public String getCnt() {
                return cnt;
            }

            public void setCnt(final String cnt) {
                this.cnt = cnt;
            }

        }
    }
}
