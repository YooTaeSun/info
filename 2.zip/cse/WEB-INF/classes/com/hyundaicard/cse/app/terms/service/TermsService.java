package com.hyundaicard.cse.app.terms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.terms.entity.TermsEntity;
import com.hyundaicard.cse.app.terms.mapper.TermsMapper;

/**
 * Terms Service
 */
@Service
public class TermsService {

    /** Mapper */
    @Autowired
    private TermsMapper termsMapper;

    public TermsEntity getTermsInfo(TermsEntity termsEntity) {
        return termsMapper.getTermsInfo(termsEntity);
    }
}
