package com.hyundaicard.cse.app.bookmark.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.util.HtmlUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.hyundaicard.cse.app.bookmark.entity.BookmarkEntity;
import com.hyundaicard.cse.app.bookmark.entity.BookmarkSiteEntity;
import com.hyundaicard.cse.app.bookmark.service.BookmarkService;
import com.hyundaicard.cse.app.bookmark.service.SessionService;
import com.hyundaicard.cse.app.like.entity.LikeCountEntity;
import com.hyundaicard.cse.app.like.entity.LikeEntity;
import com.hyundaicard.cse.app.like.service.LikeCountService;
import com.hyundaicard.cse.app.like.service.LikeService;
import com.hyundaicard.cse.app.mypage.entity.SaleInfoEntity;
import com.hyundaicard.cse.app.mypage.service.SaleInfoService;
import com.hyundaicard.cse.app.search.entity.CategoryResultEntity;
import com.hyundaicard.cse.app.search.entity.CategorySearchResultEntity;
import com.hyundaicard.cse.app.search.entity.ProductResultEntity;
import com.hyundaicard.cse.app.search.entity.SearchApiCotegoryRequestEntity;
import com.hyundaicard.cse.app.search.service.SearchService;
import com.hyundaicard.cse.app.visit.entity.VisitPageEntity;
import com.hyundaicard.cse.app.visit.service.VisitPageService;
import com.hyundaicard.cse.common.code.ResultCode;
import com.hyundaicard.cse.common.entity.RestRespEntity;
import com.hyundaicard.cse.common.util.CommonUtil;
import com.hyundaicard.cse.common.util.Config;
import com.hyundaicard.cse.constants.Constants;

/**
 * bookmark Controller
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Controller
@SuppressWarnings("rawtypes")
public class BookmarkController {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(BookmarkController.class);

    @Autowired
    private BookmarkService service;

    @Autowired
    private SearchService searchService;

    @Autowired
    private LikeService likeService;

    @Autowired
    private LikeCountService likeCountService;

    @Autowired
    private VisitPageService visitPageService;

    @Autowired
    private SaleInfoService saleInfoService;

    @Autowired
    private SessionService sessionService;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * bookmark view (관심사이트 화면)
     *
     * @Mehtod Name : view @return String @throws
     */
    @RequestMapping(value = "/bookmark/bookmark", method = RequestMethod.GET)
    public String view(@ModelAttribute final BookmarkEntity entity, final Model model, @RequestParam(value = "debug", required = false) String isDebug) {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String snsLoginYN = "Y";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            snsLoginYN = "N";
        }

        final String hccAuthYN = sessionService.getAttribute("hccAuthYN");

        model.addAttribute("hccAuthYN", hccAuthYN);
        model.addAttribute("snsLoginYN", snsLoginYN);
        model.addAttribute("uuid", sessionService.getAttribute("uuid"));
        model.addAttribute("memberIdSq", memberIdSq);

        if (service.getCount() == 0) {
            model.addAttribute("isExistBookmark", "N");
        } else {
            model.addAttribute("isExistBookmark", "Y");
        }

        String debug = Config.getCommon().getString("DEBUG");
        debug = StringUtils.defaultString(debug, "FALSE");
        isDebug = StringUtils.defaultString(isDebug, "N");
        if ("TRUE".equals(debug) || isDebug.equals("Y")) {
            return "bookmark/bookmarkSite_debug";
        } else {
            return "bookmark/bookmarkSite";
        }

    }

    @RequestMapping(value = "/bookmark/bookmarkNo", method = RequestMethod.GET)
    public String bookmarkNoSite(@ModelAttribute final BookmarkEntity entity, final Model model) {
        return "bookmark/bookmarkNoSite";
    }

    /**
     * bookmark list
     *
     * @Mehtod Name : list @return ResponseEntity @throws
     */
    @RequestMapping(value = "/bookmark/list", method = RequestMethod.POST)
    public ResponseEntity list(@ModelAttribute final BookmarkEntity entity, final Model model) {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        final String insert_uuid = sessionService.getAttribute("uuid");
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }

        RestRespEntity restRespEntity = new RestRespEntity();
        try {
            /** 2. validate check */
            // if (EntityValidator.isValid(entity)) {
            // logger.warn("Validate error!!!!!");
            // return CommonUtil.response(ResultCode.C1001, restRespEntity);
            // }
            final List<BookmarkEntity> siteList = service.getSiteList(entity);

            // 북마크 데이타
            final List<BookmarkSiteEntity> list = service.getSiteAllListForMap(entity);

            if (!list.isEmpty()) {
                final StringBuilder catKeys = new StringBuilder(256);
                final StringBuilder api_catKeys = new StringBuilder(256);
                final StringBuilder siteKeys = new StringBuilder(256);
                String catKey = "";
                String siteKey = "";
                // final Map<String, String> siteKeyMap = new HashMap<String, String>();
                for (final BookmarkSiteEntity e : list) {
                    catKey = e.getCatKey();
                    if (!StringUtils.isBlank(catKey)) {
                        catKeys.append(",'" + catKey + "'");
                        api_catKeys.append("," + catKey);
                    }

                    siteKey = e.getSiteKey();
                    if (!StringUtils.isBlank(siteKey)) {
                        siteKeys.append(",'" + siteKey + "'");
                    }
                }

                // 카테고리 데이타
                final SearchApiCotegoryRequestEntity param = new SearchApiCotegoryRequestEntity();
                param.setSiteCategoryKeys("[" + api_catKeys.toString().substring(1) + "]");
                restRespEntity = searchService.cotegoryList(param);

                final CategoryResultEntity CategoryResultEntity = (CategoryResultEntity) restRespEntity.getResultData();
                final List<CategorySearchResultEntity> apiCategoryRows = CategoryResultEntity.getData().getRows();

                // 좋아요 사이트카테고리
                final LikeEntity LikeParam = new LikeEntity();
                LikeParam.setMemberIdSq(memberIdSq);
                LikeParam.setUuid(uuid);
                LikeParam.setCatKeys("(" + catKeys.toString().substring(1) + ")");
                final List<LikeEntity> likeList = likeService.getAllList(LikeParam);

                // final CollectionType typeReference =
                // TypeFactory.defaultInstance().constructCollectionType(List.class, BookmarkEntity.class);
                // final List<BookmarkEntity> delBookmarkList = objectMapper.readValue(delBookmarks, typeReference);

                // final CollectionType typeReference =
                // TypeFactory.defaultInstance().constructCollectionType(List.class, String.class);
                // final String delBookmarkList2 = objectMapper.readValue(likeList, typeReference);

                // 좋아요 사이트카테고리 갯수
                final LikeCountEntity LikeCountParam = new LikeCountEntity();
                LikeCountParam.setCatKeys("(" + catKeys.toString().substring(1) + ")");
                final List<LikeCountEntity> likeCountList = likeCountService.getAllList(LikeCountParam);

                CategorySearchResultEntity categoryRow = null;

                // bookmark page 접속 페이지
                final VisitPageEntity visitPageMaxParam = new VisitPageEntity();
                visitPageMaxParam.setMemberIdSq(memberIdSq);
                visitPageMaxParam.setUuid(uuid);
                visitPageMaxParam.setPageCd("10");// bookmark
                final String maxPageVisitDtmStr = visitPageService.getMaxPageVisitDtm(visitPageMaxParam);

                double maxPageVisitDtm = -1;
                if (!StringUtils.isBlank(maxPageVisitDtmStr)) {
                    maxPageVisitDtm = Double.parseDouble(maxPageVisitDtmStr);
                }

                LikeEntity like = null;
                LikeCountEntity likeCount = null;
                String categoryId = "";
                String ctgKey = "";
                List<CategorySearchResultEntity> categoryRows = null;

                for (final BookmarkSiteEntity e : list) {
                    ctgKey = e.getCatKey();
                    categoryRows = new ArrayList<CategorySearchResultEntity>();

                    for (int ctgNum = 0; ctgNum < apiCategoryRows.size(); ctgNum++) {
                        categoryRow = apiCategoryRows.get(ctgNum);
                        // 제품
                        final List<ProductResultEntity> products = categoryRow.getProducts();
                        if (!products.isEmpty()) {

                            double productCrawl = 0.0d;
                            String productCrawlstr = "";
                            for (final ProductResultEntity product : products) {
                                final String product_crawl = product.getProduct_crawl();

                                if (maxPageVisitDtm == -1) {
                                    product.setIsNew("Y");
                                } else if (!StringUtils.isBlank(product_crawl)) {

                                    productCrawlstr = product_crawl.replace("-", "").replace(":", "").replace("T", "").replace("Z", "");
                                    productCrawl = Double.parseDouble(productCrawlstr);
                                    logger.debug("maxPageVisitDtmStr {} : productCrawlstr {}", maxPageVisitDtmStr, productCrawlstr);
                                    logger.debug("maxPageVisitDtm {} : productCrawl {}", maxPageVisitDtm, productCrawl);

                                    if (maxPageVisitDtm < productCrawl) {
                                        product.setIsNew("Y");
                                    } else {
                                        product.setIsNew("N");
                                    }
                                } else {
                                    product.setIsNew("N");
                                }
                            }
                        }
                        categoryId = categoryRow.getId();

                        if (ctgKey.equals(categoryId)) {

                            // 좋아요 사이트
                            categoryRow.setCtg_is_like("N");
                            for (int i = 0; i < likeList.size(); i++) {
                                like = likeList.get(i);
                                if (categoryId.equals(like.getCatKey())) {
                                    categoryRow.setCtg_is_like("Y");
                                    categoryRow.setLikeSiteCatSq(like.getLikeSiteCatSq());
                                    likeList.remove(i);
                                    i--;
                                }
                            }
                            // 좋아요 갯수
                            categoryRow.setCtg_cnt("0");
                            for (int i = 0; i < likeCountList.size(); i++) {
                                likeCount = likeCountList.get(i);
                                if (categoryId.equals(likeCount.getCatKey())) {
                                    categoryRow.setCtg_cnt(likeCount.getLikeCnt());
                                    likeCountList.remove(i);
                                    i--;
                                }
                            }

                            categoryRow.setBookmarkQueryList(e.getBookmarkQueryList());
                            e.setBookmarkQueryList(null);

                            categoryRows.add(categoryRow);
                            apiCategoryRows.remove(ctgNum);
                            ctgNum--;
                        }
                        e.setCategoryRows(categoryRows);
                    }
                }

                // 할인정보 리스트 조회
                final SaleInfoEntity saleInfoParam = new SaleInfoEntity();
                saleInfoParam.setMemberIdSq(memberIdSq);
                saleInfoParam.setUuid(uuid);
                saleInfoParam.setSiteKeys("(" + siteKeys.toString().substring(1) + ")");
                final List<SaleInfoEntity> saleInfoList = saleInfoService.getAllList(saleInfoParam);

                // 정렬
                SaleInfoEntity saleInfo = null;
                BookmarkSiteEntity bookmarkSite = null;
                for (final BookmarkEntity site : siteList) {
                    final List<BookmarkSiteEntity> bookmarkSiteList = new ArrayList<BookmarkSiteEntity>();
                    for (int i = 0; i < list.size(); i++) {
                        bookmarkSite = list.get(i);
                        if (site.getSiteKey().equals(list.get(i).getSiteKey())) {

                            for (int saleNum = 0; saleNum < saleInfoList.size(); saleNum++) {
                                saleInfo = saleInfoList.get(saleNum);
                                if (site.getSiteKey().equals(saleInfo.getSiteKey())) {
                                    bookmarkSite.setSaleInfo(saleInfo);
                                    saleInfoList.remove(saleNum);
                                    saleNum--;
                                }
                            }

                            bookmarkSiteList.add(bookmarkSite);
                            list.remove(i);
                            i--;
                        }
                    }
                    site.setBookmarkSiteList(bookmarkSiteList);
                }

                // insert TS_VISIT_PAGE_LOG_INFO(페이지접속로그정보)
                final VisitPageEntity visitPageparam = new VisitPageEntity();
                visitPageparam.setMemberIdSq(memberIdSq);
                visitPageparam.setUuid(insert_uuid);
                visitPageparam.setPageCd("10");// bookmark
                visitPageService.insert(visitPageparam);

                restRespEntity.setResultData(siteList);
            }
            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), restRespEntity.getResultData());

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }

    /**
     * bookmark isExistNewCrawlProduct
     *
     * @Mehtod Name : isExistNewCrawlProduct @return String @throws
     */
    @RequestMapping(value = "/bookmark/isExistNewCrawlProduct")
    public boolean isExistNewCrawlProduct() {
        return service.isExistNewCrawlProduct();
    }

    /**
     * bookmark getNewCrawlProductCnt
     *
     * @Mehtod Name : isExistNewCrawlProduct @return String @throws
     */
    @RequestMapping(value = "/bookmark/getNewProductCnt")
    public int newProductCnt() {
        return service.getNewProductCnt();
    }

    @Autowired
    private MessageSource messageSource;

    /**
     * bookmark insert
     *
     * @Mehtod Name : insert @return ResponseEntity @throws
     */
    @RequestMapping(value = "/bookmark/insert", method = RequestMethod.POST)
    public ResponseEntity insert(@ModelAttribute final BookmarkEntity entity, final Model model) {

        final RestRespEntity restRespEntity = new RestRespEntity();
        try {
            /** 2. validate check */
            // if (EntityValidator.isValid(entity)) {
            // logger.warn("Validate error!!!!!");
            // return CommonUtil.response(ResultCode.C1001, restRespEntity);
            // }

            final String memberIdSq = sessionService.getAttribute("memberIdSq");
            final String uuid = sessionService.getAttribute("uuid");

            // entity.setQuery(HtmlUtils.htmlUnescape(entity.getQuery()));
            entity.setUuid(uuid);
            entity.setMemberIdSq(memberIdSq);

            final String bookmarkInsertCount = Config.getCommon().getString("BOOKMARK.INSERT_COUNT");
            if (service.getCount() < Integer.parseInt(bookmarkInsertCount)) {
                service.insert(entity);
                return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), null);
            } else {
                final Map resultMap = new HashMap();
                resultMap.put("msg", messageSource.getMessage("bookmark.insert.excess", null, Locale.getDefault()));
                return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), resultMap);
            }

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }

    /**
     * bookmark firstDeleteInsert
     *
     * @Mehtod Name : firstDeleteInsert @return ResponseEntity @throws
     */
    @RequestMapping(value = "/bookmark/firstDeleteInsert", method = RequestMethod.POST)

    public ResponseEntity firstDeleteInsert(@ModelAttribute final BookmarkEntity entity, final Model model) {

        final RestRespEntity restRespEntity = new RestRespEntity();
        try {
            /** 2. validate check */
            // if (EntityValidator.isValid(entity)) {
            // logger.warn("Validate error!!!!!");
            // return CommonUtil.response(ResultCode.C1001, restRespEntity);
            // }
            final String bookmarkInsertCount = Config.getCommon().getString("BOOKMARK.INSERT_COUNT");
            final Map resultMap = new HashMap();
            if (service.getCount() >= Integer.parseInt(bookmarkInsertCount)) {
                final BookmarkEntity delBookmark = service.processFirstDeleteInsert(entity);
                resultMap.put("delBookmark", delBookmark);
                return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), resultMap);
            }
            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), null);
        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }

    /**
     * bookmark delete
     *
     * @Mehtod Name : delete @return ResponseEntity @throws
     */
    @RequestMapping(value = "/bookmark/delete", method = RequestMethod.POST)

    public ResponseEntity delete(@ModelAttribute final BookmarkEntity entity, final Model model) {

        final RestRespEntity restRespEntity = new RestRespEntity();
        try {
            /** 2. validate check */
            // if (EntityValidator.isValid(entity)) {
            // logger.warn("Validate error!!!!!");
            // return CommonUtil.response(ResultCode.C1001, restRespEntity);
            // }
            final String delBookmarks = HtmlUtils.htmlUnescape(entity.getDelBookmarks());
            entity.setDelBookmarks(delBookmarks);
            if (!StringUtils.isBlank(delBookmarks)) {
                final CollectionType typeReference = TypeFactory.defaultInstance().constructCollectionType(List.class, BookmarkEntity.class);
                final List<BookmarkEntity> delBookmarkList = objectMapper.readValue(delBookmarks, typeReference);
                service.delete(delBookmarkList);
            }

            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), null);

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }
}
