package com.hyundaicard.cse.app.mypage.mapper;

import org.springframework.dao.DataAccessException;

/**
 * Disjoin Mapper
 */
public interface DisjoinMapper {

    /**
     * 회원탈회시 삭제되는 정보 조회
     */
    public String getDisjoinInfo() throws DataAccessException;

    /**
     * 회원탈회 처리
     */
    public void disjoinMember(String userId) throws DataAccessException;

}
