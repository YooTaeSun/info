package com.hyundaicard.cse.app.main.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.main.entity.HotKeywordEntity;
import com.hyundaicard.cse.app.main.mapper.MainMapper;

/**
 * Main Service 메인 Service
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
@Service
public class MainService {

    /** Mapper */
    @Autowired
    private MainMapper mapper;

    public List<Object> getHotKeyList() {
        final List<Integer> hotKeySq = mapper.getHotKeyGrp();

        final List<Object> returnList = new ArrayList<Object>();
        for (int i = 0; i < hotKeySq.size(); i++) {
            final List<HotKeywordEntity> hotkeyList = mapper.getHotKeyList(hotKeySq.get(i));
            returnList.add(hotkeyList);
        }
        return returnList;
    }

    public String getDate(final String format) {
        return mapper.getDate(format);
    }

    public String getLogoImg() {
        return mapper.getLogoImg();
    }
}
