package com.hyundaicard.cse.app.mypage.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hyundaicard.cse.app.bookmark.service.SessionService;
import com.hyundaicard.cse.app.mypage.entity.SaleInfoEntity;
import com.hyundaicard.cse.app.mypage.service.SaleInfoService;
import com.hyundaicard.cse.app.visit.entity.VisitPageEntity;
import com.hyundaicard.cse.app.visit.service.VisitPageService;
import com.hyundaicard.cse.common.entity.RestRespEntity;
import com.hyundaicard.cse.common.util.CommonUtil;
import com.hyundaicard.cse.constants.Constants;

/**
 * 마이페이지 - 할인정보
 */

@Controller
public class SaleInfoController {
    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(SaleInfoController.class);

    @Autowired
    private SaleInfoService saleInfoService;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private SessionService sessionService;

    @Autowired
    private VisitPageService visitPageService;

    /**
     * 할인정보 리스트 조회
     */
    @RequestMapping(value = "/mypage/saleInfo0101", method = RequestMethod.GET)
    public String notice0101(@ModelAttribute final SaleInfoEntity entity, final Model model) {
        String saleListJson = "";

        try {
            final String memberIdSq = sessionService.getAttribute("memberIdSq");
            String uuid = "";
            final String insert_uuid = sessionService.getAttribute("uuid");
            if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
                uuid = sessionService.getAttribute("uuid");
            }
            entity.setMemberIdSq(memberIdSq);
            entity.setUuid(uuid);
            entity.setPageSize(20);

            final List<SaleInfoEntity> list = saleInfoService.getSaleInfoList(entity);

            saleListJson = objectMapper.writeValueAsString(list);
            saleListJson = saleListJson.replaceAll("\"", "\\\"");

            // 로그 추가
            final VisitPageEntity visitPageEntity = new VisitPageEntity();

            visitPageEntity.setMemberIdSq(memberIdSq);
            visitPageEntity.setUuid(insert_uuid);
            visitPageEntity.setPageCd("30");

            visitPageService.insert(visitPageEntity);
        } catch (final JsonProcessingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        model.addAttribute("saleInfoList", saleListJson);
        model.addAttribute("likeSiteCnt", saleInfoService.getCountLikeSite(entity));
        model.addAttribute("total", saleInfoService.getCount(entity));
        return "mypage/saleInfo0101";
    }

    /**
     * 할인정보 리스트 조회
     */
    @RequestMapping(value = "/mypage/saleInfoMore", method = RequestMethod.POST)
    public ResponseEntity saleInfoMore(@ModelAttribute final SaleInfoEntity entity, final Model model) {
        final RestRespEntity restRespEntity = new RestRespEntity();

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        final String insert_uuid = sessionService.getAttribute("uuid");
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }
        entity.setMemberIdSq(memberIdSq);
        entity.setUuid(uuid);

        final List<SaleInfoEntity> list = saleInfoService.getSaleInfoList(entity);

        return CommonUtil.response(restRespEntity, list);
    }

    // /**
    // * 할인정보 상세 조회
    // */
    // @RequestMapping(value = "/mypage/saleInfo0102", method = RequestMethod.GET)
    // public String saleInfo0102(@ModelAttribute final SaleInfoEntity entity, final Model model) {
    //
    // model.addAttribute("saleInfo", saleInfoService.getSaleInfoDetail(entity));
    //
    // return "mypage/saleInfo0102";
    // }

}
