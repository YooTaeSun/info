package com.hyundaicard.cse.app.log.entity;

/**
 * psnlLog Entity
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public class PsnlLogEntity {
    private String memberIdSq; // 회원아이디 일련번호
    private String uuid; // 단말식별값
    private String siteKey; // 사이트키
    private String likeCount; // 좋아요카운트
    private String favCount; // 북마크카운트
    private String clickCount; // 클릭카운트
    private String finalScore; // 점수
    private String insertDt; // 등록일시
    private String insertId; // 등록자ID
    private String updateDt; // 수정일시
    private String updateId; // 수정자ID

    private String logTypeCd; // custom

    public String getMemberIdSq() {
        return memberIdSq;
    }

    public void setMemberIdSq(final String memberIdSq) {
        this.memberIdSq = memberIdSq;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    public String getSiteKey() {
        return siteKey;
    }

    public void setSiteKey(final String siteKey) {
        this.siteKey = siteKey;
    }

    public String getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(final String likeCount) {
        this.likeCount = likeCount;
    }

    public String getFavCount() {
        return favCount;
    }

    public void setFavCount(final String favCount) {
        this.favCount = favCount;
    }

    public String getClickCount() {
        return clickCount;
    }

    public void setClickCount(final String clickCount) {
        this.clickCount = clickCount;
    }

    public String getFinalScore() {
        return finalScore;
    }

    public void setFinalScore(final String finalScore) {
        this.finalScore = finalScore;
    }

    public String getInsertDt() {
        return insertDt;
    }

    public void setInsertDt(final String insertDt) {
        this.insertDt = insertDt;
    }

    public String getInsertId() {
        return insertId;
    }

    public void setInsertId(final String insertId) {
        this.insertId = insertId;
    }

    public String getUpdateDt() {
        return updateDt;
    }

    public void setUpdateDt(final String updateDt) {
        this.updateDt = updateDt;
    }

    public String getUpdateId() {
        return updateId;
    }

    public void setUpdateId(final String updateId) {
        this.updateId = updateId;
    }

    public String getLogTypeCd() {
        return logTypeCd;
    }

    public void setLogTypeCd(final String logTypeCd) {
        this.logTypeCd = logTypeCd;
    }

}
