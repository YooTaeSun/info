package com.hyundaicard.cse.app.bookmark.controller;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.util.HtmlUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hyundaicard.cse.app.bookmark.entity.BookmarkQueryEntity;
import com.hyundaicard.cse.app.bookmark.service.BookmarkQueryService;
import com.hyundaicard.cse.app.bookmark.service.SessionService;
import com.hyundaicard.cse.common.code.ResultCode;
import com.hyundaicard.cse.common.entity.RestRespEntity;
import com.hyundaicard.cse.common.util.CommonUtil;
import com.hyundaicard.cse.constants.Constants;

/**
 * bookmark query Controller
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Controller
@SuppressWarnings("rawtypes")
public class BookmarkQueryController {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(BookmarkQueryController.class);

    @Autowired
    private BookmarkQueryService service;

    @Autowired
    private SessionService sessionService;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * bookmarkQuery delete
     *
     * @Mehtod Name : delete @return ResponseEntity @throws
     */
    @RequestMapping(value = "/bookmarkQuery/delete", method = RequestMethod.POST)
    public ResponseEntity delete(final BookmarkQueryEntity entity, final Model model) {

        final RestRespEntity restRespEntity = new RestRespEntity();
        try {
            /** 2. validate check */
            // if (EntityValidator.isValid(entity)) {
            // logger.warn("Validate error!!!!!");
            // return CommonUtil.response(ResultCode.C1001, restRespEntity);
            // }

            final String delExcepPks = HtmlUtils.htmlUnescape(entity.getDelExcepPks());
            if (!StringUtils.isBlank(delExcepPks)) {
                entity.setDelExcepPkList(objectMapper.readValue(delExcepPks, List.class));
            }

            final String memberIdSq = sessionService.getAttribute("memberIdSq");
            String uuid = "";
            if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
                uuid = sessionService.getAttribute("uuid");
            }
            entity.setMemberIdSq(memberIdSq);
            entity.setUuid(uuid);

            service.delete(entity);

            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), null);

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }
}
