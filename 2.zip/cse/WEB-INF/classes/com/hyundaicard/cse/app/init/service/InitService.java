package com.hyundaicard.cse.app.init.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.init.entity.AppTokenEntity;
import com.hyundaicard.cse.app.init.entity.EmergencyNoticeEntity;
import com.hyundaicard.cse.app.init.entity.UpdateInfoEntity;
import com.hyundaicard.cse.app.init.mapper.InitMapper;
import com.hyundaicard.cse.common.util.Config;

import net.nshc.ap.AppProtectServer;
import net.nshc.ap.AppProtectVerify;
import net.nshc.ap.common.SessionKey;
import net.nshc.ap.exception.AppProtectException;
import net.nshc.ap.vo.VerifyResult;

/**
 * Init Service
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
@Service
public class InitService {

    /** Mapper */
    @Autowired
    private InitMapper mapper;

    private static final Logger logger = LoggerFactory.getLogger(InitService.class);

    /** 앱 업데이트 정보 조회 */
    public UpdateInfoEntity getUpdateInfo(final UpdateInfoEntity updateInfoEntity) {
        return mapper.getUpdateInfo(updateInfoEntity);
    }

    /** 초기 구동 긴급 공지 조회 */
    public EmergencyNoticeEntity getEmergencyNotice() {
        return mapper.getEmergencyNotice();
    }

    /** 위변조 검증 키 조회 */
    public String getNSHCKey(final HttpServletRequest httpServletRequest, final String osType, final String apLib)
            throws Exception {

        final String serverMode = Config.getCommon().getString("SERVER_MODE");

        if (!serverMode.equals("P")) {
            // TODO:test
            if (true) {
                return "apinit=11,ASDF,ZXCV";
            }
        }

        final AppProtectServer ap = new AppProtectServer();
        ap.setOsType(osType); // os Type : 'A' = android / 'i' = iOS
        ap.setApLib(apLib); // lib version : '0' = client 모듈 1.7 이하, '7' = client 모듈 1.7

        ap.doStart(httpServletRequest.getSession());

        return ap.getInitData();

    }

    /** 위변조 검증 */
    public void checkVerify(final HttpServletRequest httpServletRequest, final String verifyData) throws Exception {

        final String serverMode = Config.getCommon().getString("SERVER_MODE");

        if (!serverMode.equals("P")) {
            // TODO:test
            if (true) {
                return;
            }
        }

        try {
            final HttpSession session = httpServletRequest.getSession();

            final String privateKey = (String) session.getAttribute(SessionKey.privatekey);

            logger.debug("privateKey : " + privateKey);

            final AppProtectVerify apv = new AppProtectVerify();
            apv.setVerifyData(session, verifyData, privateKey);

            final VerifyResult vData = apv.getInitVerifyData();
            final VerifyResult vResult = apv.doVerify(vData);

            /*
             * 검증 결과코드 |##############################################| |### Method ###|## 코드##|##### 설명 #########| |
             * getResultCode() | 0 | 검증 성공 | | getResultCode() | 음수 | 시스템 장애 |
             * |----------------------------------------------| | getResultCode1()| 0 | 앱 정상 | | getResultCode1()| 1 | 앱
             * 미등록 | | getResultCode1()| 2 | 앱 변조 | | getResultCode1()| 3 | 앱 검증제외 | | getResultCode1()| 6 | 해시 미등록 | |
             * getResultCode1()| 9 | 예외 해시 | |----------------------------------------------| | getResultCode2()| 0 |
             * 시스템 정상 | | getResultCode2()| 4 | 탈옥 혹은 루팅 | | getResultCode2()| 5 | 시스템 검증제외|
             * |##############################################|
             */

            logger.debug("PKAGE_NM   : " + vResult.getPackageNm());
            logger.debug("APP_VER    : " + vResult.getVersion());
            logger.debug("OPT_CD     : " + vResult.getOptCode());
            logger.debug("OS         : " + vResult.getDeviceOs());
            logger.debug("ORGL_HASH  : " + vResult.getOriginalHashdata());
            logger.debug("DYNM_HASH  : " + vResult.getHashData());
            logger.debug("RESULT_CD  : " + vResult.getResultCode());
            logger.debug("RESULT_CD1 : " + vResult.getResultCode1());
            logger.debug("RESULT_CD2 : " + vResult.getResultCode2());
            logger.debug("TO_STRING  : " + vResult.toString());

            /** NSHC Guide */
            if (vResult.getResultCode() < 0 // 검증실패일 경우를 말하며 일종의 시스템 장애입니다.
                    || vResult.getResultCode1() == 0 // 앱 정상
                    || vResult.getResultCode1() == 3 // 앱 검증 제외
                    || vResult.getResultCode1() == 6 // 해시 미등록
                    || vResult.getResultCode1() == 9 // 예외 해시
            ) {
                if (vResult.getResultCode1() == -5) {
                    /**
                     * 앱 검증시 필요한 최소한의 데이터가 클라이언트에게서 오지 않았을때 VSN으로 리턴하는 코드입니다. 동시에 서버측에서도 계속적으로 서비스가 불가하도록 조치를 해야합니다.
                     */

                    logger.debug("VSN : " + vResult.getResultSummary());
                    throw new Exception("NSHC0002");

                } else if (vResult.getResultCode() < 0 // 검증실패일 경우를 말하며 일종의 시스템 장애입니다.
                        || vResult.getResultCode2() == 0 // 시스템 정상
                        || vResult.getResultCode2() == 5 // 시스템 검증 제외
                ) {
                    logger.debug("VSY : " + vResult.getResultSummary());
                } else { // 시스템 변조
                    /**
                     * 시스템 변조로 확인되었을 경우 클라이언트에 결과를 응답하며, 동시에 서버측에서도 계속적으로 서비스가 불가하도록 조치해야 합니다.
                     */
                    logger.debug("VSN : " + vResult.getResultSummary());

                    throw new Exception("NSHC0003");
                }
            } else { // 앱 변조
                /**
                 * 앱 변조로 확인되었을 경우 클라이언트에 결과를 응답하며, 동시에 서버측에서도 계속적으로 서비스가 불가하도록 조치해야 합니다.
                 */

                logger.debug("VSN : " + vResult.getResultSummary());

                throw new Exception("NSHC0004");
            }

        } catch (final AppProtectException e) {
            e.printStackTrace();
            throw new AppProtectException(e);
        } catch (final Exception e) {
            e.printStackTrace();
            throw new Exception("NSHC0001");
        }
    }

    /** 앱 토큰 업데이트 */
    public void updateAppToken(final AppTokenEntity appTokenEntity) {
        mapper.updateAppToken(appTokenEntity);
    }

    /** 북마크 카테고리 새상품 crawl 여부 조회 */
    public void checkUpdateCrawlDate(final String userId, final String uuid) {

    }

    /** 푸시 수신여부 업데이트 */
    public void updatePushReceiveInfo(final AppTokenEntity appTokenEntity) {
        mapper.updatePushReceiveInfo(appTokenEntity);
    }
}
