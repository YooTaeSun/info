package com.hyundaicard.cse.app.log.entity;

/**
 * click event log Entity
 * 
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public class ClickEventLogEntity {
    private String clickLogSq; // 검색키워드 로그 순번
    private String queryKeyword; // 검색키워드
    private String queryTypeCd; // 검색구분코드
    private String pageInfo; // 호출페이지정보
    private String itemCount; // 결과아이템갯수
    private String itemPos; // 아이템위치
    private String siteKey; // 사이트키
    private String clickItemType; // 클릭아이템유형
    private String memberIdSq; // 회원아이디 일련번호
    private String uuid; // 단말식별값
    private String sessionId; // 세션아이디
    private String insertDt; // 등록일시

    private String isLogSave = "Y"; // log custom

    public String getClickLogSq() {
        return clickLogSq;
    }

    public void setClickLogSq(final String clickLogSq) {
        this.clickLogSq = clickLogSq;
    }

    public String getQueryKeyword() {
        return queryKeyword;
    }

    public void setQueryKeyword(final String queryKeyword) {
        this.queryKeyword = queryKeyword;
    }

    public String getQueryTypeCd() {
        return queryTypeCd;
    }

    public void setQueryTypeCd(final String queryTypeCd) {
        this.queryTypeCd = queryTypeCd;
    }

    public String getPageInfo() {
        return pageInfo;
    }

    public void setPageInfo(final String pageInfo) {
        this.pageInfo = pageInfo;
    }

    public String getItemCount() {
        return itemCount;
    }

    public void setItemCount(final String itemCount) {
        this.itemCount = itemCount;
    }

    public String getItemPos() {
        return itemPos;
    }

    public void setItemPos(final String itemPos) {
        this.itemPos = itemPos;
    }

    public String getSiteKey() {
        return siteKey;
    }

    public void setSiteKey(final String siteKey) {
        this.siteKey = siteKey;
    }

    public String getClickItemType() {
        return clickItemType;
    }

    public void setClickItemType(final String clickItemType) {
        this.clickItemType = clickItemType;
    }

    public String getMemberIdSq() {
        return memberIdSq;
    }

    public void setMemberIdSq(final String memberIdSq) {
        this.memberIdSq = memberIdSq;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(final String sessionId) {
        this.sessionId = sessionId;
    }

    public String getInsertDt() {
        return insertDt;
    }

    public void setInsertDt(final String insertDt) {
        this.insertDt = insertDt;
    }

    public String getIsLogSave() {
        return isLogSave;
    }

    public void setIsLogSave(final String isLogSave) {
        this.isLogSave = isLogSave;
    }

}
