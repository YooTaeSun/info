package com.hyundaicard.cse.app.init.entity;

import com.hyundaicard.cse.common.entity.AbstractPage;

/**
 * EmergencyNoticeEntity
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public class EmergencyNoticeEntity extends AbstractPage {

    private String noticeSq;
    private String title;
    private String content;

    public String getNoticeSq() {
        return noticeSq;
    }

    public void setNoticeSq(final String noticeSq) {
        this.noticeSq = noticeSq;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(final String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(final String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "EmergencyNoticeEntity [noticeSq=" + noticeSq + ", title=" + title + ", content=" + content + "]";
    }

}
