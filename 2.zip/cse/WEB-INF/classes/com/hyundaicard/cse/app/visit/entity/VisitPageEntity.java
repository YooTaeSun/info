package com.hyundaicard.cse.app.visit.entity;

/**
 * visit page Entity
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public class VisitPageEntity {
    private String visitPageSq; // 페이지 접속 순번
    private String memberIdSq; // 회원아이디 일련번호
    private String uuid; // 비회원 단말 식별값
    private String pageCd; // 페이지코드
    private String pageVisitDtm; // 페이지접속일시
    private String insertDt; // 등록일시

    public String getVisitPageSq() {
        return visitPageSq;
    }

    public void setVisitPageSq(final String visitPageSq) {
        this.visitPageSq = visitPageSq;
    }

    public String getMemberIdSq() {
        return memberIdSq;
    }

    public void setMemberIdSq(final String memberIdSq) {
        this.memberIdSq = memberIdSq;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    public String getPageCd() {
        return pageCd;
    }

    public void setPageCd(final String pageCd) {
        this.pageCd = pageCd;
    }

    public String getPageVisitDtm() {
        return pageVisitDtm;
    }

    public void setPageVisitDtm(final String pageVisitDtm) {
        this.pageVisitDtm = pageVisitDtm;
    }

    public String getInsertDt() {
        return insertDt;
    }

    public void setInsertDt(final String insertDt) {
        this.insertDt = insertDt;
    }

}
