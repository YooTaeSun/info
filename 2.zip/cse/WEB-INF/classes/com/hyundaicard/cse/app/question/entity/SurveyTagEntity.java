package com.hyundaicard.cse.app.question.entity;

import com.hyundaicard.cse.common.entity.AbstractPage;

public class SurveyTagEntity extends AbstractPage {

    private String questionTypeCd;
    private String answerVal;
    private String tagVal;
    private String uuid;

    public String getQuestionTypeCd() {
        return questionTypeCd;
    }

    public void setQuestionTypeCd(final String questionTypeCd) {
        this.questionTypeCd = questionTypeCd;
    }

    public String getAnswerVal() {
        return answerVal;
    }

    public void setAnswerVal(final String answerVal) {
        this.answerVal = answerVal;
    }

    public String getTagVal() {
        return tagVal;
    }

    public void setTagVal(final String tagVal) {
        this.tagVal = tagVal;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

}
