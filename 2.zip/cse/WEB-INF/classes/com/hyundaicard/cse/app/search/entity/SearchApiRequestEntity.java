package com.hyundaicard.cse.app.search.entity;

import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;

public class SearchApiRequestEntity {

    private String searchKind;
    private Integer page;
    private Integer size;// pageSize
    private String nickname;
    @NotEmpty
    private String query;

    private String duration;
    private String region;

    private String tags;

    List<String> fltgrpCdList = null;

    private String debug;

    private String filter;
    private String hccAuthYn; // custom
    private String questionYn; // custom
    private String personalType; // custom
    private String siteKeys; // custom

    public String getSearchKind() {
        return searchKind;
    }

    public void setSearchKind(final String searchKind) {
        this.searchKind = searchKind;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(final Integer page) {
        this.page = page;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(final Integer size) {
        this.size = size;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(final String query) {
        this.query = query;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(final String nickname) {
        this.nickname = nickname;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(final String duration) {
        this.duration = duration;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(final String region) {
        this.region = region;
    }

    public List<String> getFltgrpCdList() {
        return fltgrpCdList;
    }

    public void setFltgrpCdList(final List<String> fltgrpCdList) {
        this.fltgrpCdList = fltgrpCdList;
    }

    public String getFilter() {
        return filter;
    }

    public void setFilter(final String filter) {
        this.filter = filter;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(final String tags) {
        this.tags = tags;
    }

    public String getDebug() {
        return debug;
    }

    public void setDebug(final String debug) {
        this.debug = debug;
    }

    public String getHccAuthYn() {
        return hccAuthYn;
    }

    public void setHccAuthYn(final String hccAuthYn) {
        this.hccAuthYn = hccAuthYn;
    }

    public String getQuestionYn() {
        return questionYn;
    }

    public void setQuestionYn(final String questionYn) {
        this.questionYn = questionYn;
    }

    public String getPersonalType() {
        return personalType;
    }

    public void setPersonalType(final String personalType) {
        this.personalType = personalType;
    }

    public String getSiteKeys() {
        return siteKeys;
    }

    public void setSiteKeys(final String siteKeys) {
        this.siteKeys = siteKeys;
    }

}
