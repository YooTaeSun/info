package com.hyundaicard.cse.app.mypage.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hyundaicard.cse.app.bookmark.service.SessionService;
import com.hyundaicard.cse.app.init.entity.AppTokenEntity;
import com.hyundaicard.cse.app.init.service.InitService;
import com.hyundaicard.cse.app.question.entity.AnswerEntity;
import com.hyundaicard.cse.app.question.service.AnswerService;
import com.hyundaicard.cse.common.controller.CseAppController;
import com.hyundaicard.cse.common.view.Request;
import com.hyundaicard.cse.constants.Constants;

/**
 * 마이페이지 정보
 *
 */

@Controller
public class MypageInfoController extends CseAppController {

    @Autowired
    private SessionService sessionService;

    @Autowired
    private AnswerService answerService;

    @Autowired
    private InitService initService;

    /**
     * 설문응답 여부
     */
    @RequestMapping(value = "/api/mypage/surveyInfo", method = RequestMethod.POST)
    public ModelAndView surveyInfo(final HttpServletRequest httpServletRequest,
            final HttpServletResponse httpServletResponse, final Request request) throws Exception {

        final JSONObject responseJson = new JSONObject();

        // 설문 작성 여부
        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String tmpUuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            tmpUuid = sessionService.getAttribute("uuid");
        }
        String personalSurveyYN = "N";
        final AnswerEntity answerEntity = new AnswerEntity();
        answerEntity.setLoginIDInSession(memberIdSq);
        answerEntity.setUuid(tmpUuid);
        final int answerCnt = answerService.getAnswerCnt(answerEntity);
        if (answerCnt > 0) {
            personalSurveyYN = "Y";
        }

        responseJson.put("personalSurveyYN", personalSurveyYN);

        return createResponseModelAndView(httpServletRequest, httpServletResponse, request, responseJson);
    }

    /**
     * 푸시 수신 여부
     */
    @RequestMapping(value = "/api/mypage/updatePushInfo", method = RequestMethod.POST)
    public ModelAndView updatePushInfo(final HttpServletRequest httpServletRequest,
            final HttpServletResponse httpServletResponse, final Request request) throws Exception {

        final JSONObject requestJson = request.getRequestBodyJson();
        final JSONObject responseJson = new JSONObject();

        final String pushReceiveYN = requestJson.optString("pushReceiveYN", "N");
        final String uuid = sessionService.getAttribute("uuid");

        final AppTokenEntity appTokenEntity = new AppTokenEntity();
        appTokenEntity.setUuid(uuid);
        appTokenEntity.setReceiveYN(pushReceiveYN);

        initService.updatePushReceiveInfo(appTokenEntity);

        return createResponseModelAndView(httpServletRequest, httpServletResponse, request, responseJson);
    }

}
