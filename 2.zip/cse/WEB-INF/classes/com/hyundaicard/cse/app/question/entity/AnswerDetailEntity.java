package com.hyundaicard.cse.app.question.entity;

import java.math.BigInteger;

import com.hyundaicard.cse.common.entity.AbstractPage;

public class AnswerDetailEntity extends AbstractPage {

    private BigInteger surveyAnswerDetSq;

    private BigInteger surveyAnswerSq;

    private BigInteger surveyQuestionSq;

    private String questionTypeCd;

    private String answerVal;

    private String etcFlagYn;

    public BigInteger getSurveyAnswerSq() {
        return surveyAnswerSq;
    }

    public void setSurveyAnswerSq(final BigInteger surveyAnswerSq) {
        this.surveyAnswerSq = surveyAnswerSq;
    }

    public BigInteger getSurveyAnswerDetSq() {
        return surveyAnswerDetSq;
    }

    public void setSurveyAnswerDetSq(final BigInteger surveyAnswerDetSq) {
        this.surveyAnswerDetSq = surveyAnswerDetSq;
    }

    public BigInteger getSurveyQuestionSq() {
        return surveyQuestionSq;
    }

    public void setSurveyQuestionSq(final BigInteger surveyQuestionSq) {
        this.surveyQuestionSq = surveyQuestionSq;
    }

    public String getAnswerVal() {
        return answerVal;
    }

    public void setAnswerVal(final String answerVal) {
        this.answerVal = answerVal;
    }

    public String getEtcFlagYn() {
        return etcFlagYn;
    }

    public void setEtcFlagYn(final String etcFlagYn) {
        this.etcFlagYn = etcFlagYn;
    }

    public String getQuestionTypeCd() {
        return questionTypeCd;
    }

    public void setQuestionTypeCd(final String questionTypeCd) {
        this.questionTypeCd = questionTypeCd;
    }

    @Override
    public String toString() {
        return "AnswerDetailEntity [surveyAnswerDetSq=" + surveyAnswerDetSq + ", surveyAnswerSq=" + surveyAnswerSq + ", surveyQuestionSq=" + surveyQuestionSq + ", questionTypeCd=" + questionTypeCd + ", answerVal=" + answerVal + ", etcFlagYn=" + etcFlagYn + "]";
    }

}
