package com.hyundaicard.cse.app.log.entity;

/**
 * no result log Entity
 * 
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public class SearchNoResultLogEntity {
    private String noResultLogSq; // 검색키워드 로그 순번
    private String queryKeyword; // 검색키워드
    private String queryTypeCd; // 검색구분코드
    private String memberIdSq; // 회원아이디 일련번호
    private String uuid; // 단말식별값
    private String sessionId; // 세션아이디
    private String insertDt; // 등록일시

    public String getNoResultLogSq() {
        return noResultLogSq;
    }

    public void setNoResultLogSq(final String noResultLogSq) {
        this.noResultLogSq = noResultLogSq;
    }

    public String getQueryKeyword() {
        return queryKeyword;
    }

    public void setQueryKeyword(final String queryKeyword) {
        this.queryKeyword = queryKeyword;
    }

    public String getQueryTypeCd() {
        return queryTypeCd;
    }

    public void setQueryTypeCd(final String queryTypeCd) {
        this.queryTypeCd = queryTypeCd;
    }

    public String getMemberIdSq() {
        return memberIdSq;
    }

    public void setMemberIdSq(final String memberIdSq) {
        this.memberIdSq = memberIdSq;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(final String sessionId) {
        this.sessionId = sessionId;
    }

    public String getInsertDt() {
        return insertDt;
    }

    public void setInsertDt(final String insertDt) {
        this.insertDt = insertDt;
    }

}
