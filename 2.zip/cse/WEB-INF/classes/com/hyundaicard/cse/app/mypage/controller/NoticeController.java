package com.hyundaicard.cse.app.mypage.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hyundaicard.cse.app.bookmark.service.SessionService;
import com.hyundaicard.cse.app.mypage.entity.NoticeEntity;
import com.hyundaicard.cse.app.mypage.entity.PopupNoticeEntity;
import com.hyundaicard.cse.app.mypage.service.NoticeService;
import com.hyundaicard.cse.app.visit.entity.VisitPageEntity;
import com.hyundaicard.cse.app.visit.service.VisitPageService;
import com.hyundaicard.cse.common.entity.RestRespEntity;
import com.hyundaicard.cse.common.util.CommonUtil;
import com.hyundaicard.cse.constants.Constants;

/**
 * 마이페이지 - 공지사항
 */

@Controller
public class NoticeController {

    private static final Logger logger = LoggerFactory.getLogger(NoticeController.class);

    @Autowired
    private NoticeService noticeService;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private SessionService sessionService;

    @Autowired
    private VisitPageService visitPageService;

    /**
     * 공지사항 리스트 조회
     */
    @RequestMapping(value = "/mypage/notice0101", method = RequestMethod.GET)
    public String notice0101(@ModelAttribute final NoticeEntity entity, final Model model) {

        String reviewListJson = "";
        try {
            final String memberIdSq = sessionService.getAttribute("memberIdSq");
            String uuid = "";
            final String insert_uuid = sessionService.getAttribute("uuid");
            if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
                uuid = sessionService.getAttribute("uuid");
            }
            entity.setMemberIdSq(memberIdSq);
            entity.setUuid(uuid);
            entity.setPageSize(20);
            final List<NoticeEntity> list = noticeService.getNoticeList(entity);

            reviewListJson = objectMapper.writeValueAsString(list);
            reviewListJson = reviewListJson.replaceAll("\"", "\\\"");

            // 로그 추가
            final VisitPageEntity visitPageEntity = new VisitPageEntity();

            visitPageEntity.setMemberIdSq(memberIdSq);
            visitPageEntity.setUuid(insert_uuid);
            visitPageEntity.setPageCd("20");

            visitPageService.insert(visitPageEntity);
        } catch (final JsonProcessingException e) {
            logger.debug("notice0101 Error" + e.getMessage());
        }

        model.addAttribute("noticeList", reviewListJson);
        model.addAttribute("total", noticeService.getCount(entity));
        return "mypage/notice0101";
    }

    /**
     * 공지사항 리스트 조회
     */
    @RequestMapping(value = "/mypage/noticeMore", method = RequestMethod.POST)
    public ResponseEntity noticeMore(@ModelAttribute final NoticeEntity entity, final Model model) {
        final RestRespEntity restRespEntity = new RestRespEntity();

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }
        entity.setMemberIdSq(memberIdSq);
        entity.setUuid(uuid);

        final List<NoticeEntity> list = noticeService.getNoticeList(entity);

        return CommonUtil.response(restRespEntity, list);
    }

    /**
     * 공지사항 상세 조회
     */
    @RequestMapping(value = "/mypage/notice0102", method = RequestMethod.GET)
    public String notice0102(@ModelAttribute final NoticeEntity entity, final Model model) {

        /** 조회수 증가 */
        noticeService.updateHitCount(entity);

        model.addAttribute("noticeInfo", noticeService.getNoticeDetail(entity));

        return "mypage/notice0102";
    }

    @RequestMapping(value = "/notice/popup", method = RequestMethod.GET)
    public String popupNotice(@ModelAttribute final PopupNoticeEntity entity, final Model model) {
        final PopupNoticeEntity popupNoticeEntity = noticeService.getPopupNotice(entity);
        model.addAttribute("popupNotice", popupNoticeEntity);
        return "mypage/popup0101";
    }

    @RequestMapping(value = "/notice/popup/skip", method = RequestMethod.POST)
    public ResponseEntity popupNoticeSkip(@ModelAttribute final PopupNoticeEntity entity, final Model model) {
        final RestRespEntity restRespEntity = new RestRespEntity();
        final String uuid = sessionService.getAttribute("uuid");
        entity.setUuid(uuid);

        noticeService.setPopupSkip(entity);

        return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), null);
    }

}
