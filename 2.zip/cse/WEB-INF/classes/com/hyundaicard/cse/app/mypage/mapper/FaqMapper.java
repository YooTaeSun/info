package com.hyundaicard.cse.app.mypage.mapper;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.hyundaicard.cse.app.mypage.entity.CodeEntity;
import com.hyundaicard.cse.app.mypage.entity.FaqEntity;

/**
 * Faq Mapper
 */
public interface FaqMapper {

    /**
     * FAQ 리스트조회
     */
    public List<FaqEntity> getFaqList(FaqEntity faqEntity) throws DataAccessException;

    /**
     * FAQ 상세조회
     */
    public FaqEntity getFaqDetail(FaqEntity faqEntity) throws DataAccessException;

    /**
     * 조회수 증가
     */
    public void updateHitCount(String seqNo) throws DataAccessException;

    public int getCount(FaqEntity faqEntity) throws DataAccessException;

    public List<CodeEntity> getCatCode(FaqEntity faqEntity) throws DataAccessException;
}
