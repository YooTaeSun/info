package com.hyundaicard.cse.app.terms.entity;

import com.hyundaicard.cse.common.entity.AbstractPage;

/**
 * Terms Entity
 */
public class TermsEntity extends AbstractPage {

    private String termsCode;
    private String title;
    private String content;

    public String getTermsCode() {
        return termsCode;
    }

    public void setTermsCode(final String termsCode) {
        this.termsCode = termsCode;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(final String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(final String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "TermsEntity [termsCode=" + termsCode + ", title=" + title + ", content=" + content + "]";
    }

}
