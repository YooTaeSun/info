package com.hyundaicard.cse.app.question.entity;

import java.math.BigInteger;
import java.util.List;

import com.hyundaicard.cse.app.main.entity.SearchWordEntity;

/**
 * Question Entity
 */
public class QuestionEntity extends SearchWordEntity {

    private BigInteger surveySq;

    private BigInteger questionSq;

    private String questionTypeCd;

    private String answerTypeCd;

    private String questionTitle;

    private String questionDesc;

    private String orgQuestionSq;

    private List<ChoiceEntity> choiceList;

    private String callBackIdx;

    public String getCallBackIdx() {
        return callBackIdx;
    }

    public void setCallBackIdx(final String callBackIdx) {
        this.callBackIdx = callBackIdx;
    }

    public BigInteger getSurveySq() {
        return surveySq;
    }

    public void setSurveySq(final BigInteger surveySq) {
        this.surveySq = surveySq;
    }

    public BigInteger getQuestionSq() {
        return questionSq;
    }

    public void setQuestionSq(final BigInteger questionSq) {
        this.questionSq = questionSq;
    }

    public String getQuestionTypeCd() {
        return questionTypeCd;
    }

    public void setQuestionTypeCd(final String questionTypeCd) {
        this.questionTypeCd = questionTypeCd;
    }

    public String getAnswerTypeCd() {
        return answerTypeCd;
    }

    public void setAnswerTypeCd(final String answerTypeCd) {
        this.answerTypeCd = answerTypeCd;
    }

    public String getQuestionTitle() {
        return questionTitle;
    }

    public void setQuestionTitle(final String questionTitle) {
        this.questionTitle = questionTitle;
    }

    public String getQuestionDesc() {
        return questionDesc;
    }

    public void setQuestionDesc(final String questionDesc) {
        this.questionDesc = questionDesc;
    }

    public String getOrgQuestionSq() {
        return orgQuestionSq;
    }

    public void setOrgQuestionSq(final String orgQuestionSq) {
        this.orgQuestionSq = orgQuestionSq;
    }

    public List<ChoiceEntity> getChoiceList() {
        return choiceList;
    }

    public void setChoiceList(final List<ChoiceEntity> choiceList) {
        this.choiceList = choiceList;
    }

    @Override
    public String toString() {
        return "QuestionEntity [questionSq=" + questionSq + ", questionTypeCd=" + questionTypeCd + ", answerTypeCd=" + answerTypeCd + ", questionTitle=" + questionTitle + ", questionDesc=" + questionDesc + ", orgQuestionSq=" + orgQuestionSq + "]";
    }

}
