package com.hyundaicard.cse.app.search.entity;

import org.hibernate.validator.constraints.NotEmpty;

import com.google.firebase.database.annotations.NotNull;

/**
 * 검색 DetailCategory Request Entity
 * 
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public class SearchApiDetailCategoryRequestEntity {

    @NotEmpty
    private String siteId;
    @NotEmpty
    private String query;
    @NotNull
    private Integer size;
    @NotNull
    private Integer page;
    
    private String searchKind;
    
    public String getSiteId() {
        return siteId;
    }
    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }
    public String getQuery() {
        return query;
    }
    public void setQuery(String query) {
        this.query = query;
    }
    public Integer getSize() {
        return size;
    }
    public void setSize(Integer size) {
        this.size = size;
    }
    public Integer getPage() {
        return page;
    }
    public void setPage(Integer page) {
        this.page = page;
    }
    public String getSearchKind() {
        return searchKind;
    }
    public void setSearchKind(String searchKind) {
        this.searchKind = searchKind;
    }
    

}
