package com.hyundaicard.cse.app.log.mapper;

import com.hyundaicard.cse.app.log.entity.SearchNoResultLogEntity;

/**
 * no result log Mapper
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public interface SearchNoResultLogMapper {

    /**
     * 등록
     *
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public void insert(SearchNoResultLogEntity entity);
}
