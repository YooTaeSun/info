package com.hyundaicard.cse.app.mypage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.mypage.entity.CodeEntity;
import com.hyundaicard.cse.app.mypage.entity.FaqEntity;
import com.hyundaicard.cse.app.mypage.mapper.FaqMapper;
import com.hyundaicard.cse.common.entity.PagingValue;

/**
 * FAQ Service
 */
@Service
public class FaqService {

    /** Mapper */
    @Autowired
    private FaqMapper faqMapper;

    public List<FaqEntity> getFaqList(FaqEntity faqEntity) {
        int count = this.getCount(faqEntity);

        PagingValue paging = faqEntity.getPagingValue(count);

        faqEntity.setPaging(paging);

        List<FaqEntity> faqList = faqMapper.getFaqList(faqEntity);

        return faqList;
    }

    public FaqEntity getFaqDetail(FaqEntity faqEntity) {

        FaqEntity faqDetail = faqMapper.getFaqDetail(null);

        return faqDetail;
    }

    public void updateHitCount(String seqNo) {

        faqMapper.updateHitCount(seqNo);
    }

    public int getCount(FaqEntity faqEntity) {
        return faqMapper.getCount(faqEntity);
    }

    public List<CodeEntity> getCatCode(FaqEntity faqEntity) {
        List<CodeEntity> catCodeList = faqMapper.getCatCode(faqEntity);

        return catCodeList;
    }
}
