package com.hyundaicard.cse.app.log.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.log.entity.SearchNoResultLogEntity;
import com.hyundaicard.cse.app.log.mapper.SearchNoResultLogMapper;

/**
 * search No Result Log Service
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Service
public class SearchNoResultLogService {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(SearchNoResultLogService.class);

    @Autowired
    private SearchNoResultLogMapper mapper;

    /**
     * 입력
     *
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public void insert(final SearchNoResultLogEntity entity) {
        mapper.insert(entity);
    }

}
