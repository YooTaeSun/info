package com.hyundaicard.cse.app.bookmark.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.bookmark.entity.BookmarkEntity;
import com.hyundaicard.cse.app.bookmark.entity.BookmarkQueryEntity;
import com.hyundaicard.cse.app.bookmark.entity.BookmarkSiteEntity;
import com.hyundaicard.cse.app.bookmark.mapper.BookmarkMapper;
import com.hyundaicard.cse.app.bookmark.mapper.BookmarkQueryMapper;
import com.hyundaicard.cse.app.log.entity.ClickEventLogEntity;
import com.hyundaicard.cse.app.log.entity.PsnlLogEntity;
import com.hyundaicard.cse.app.log.service.ClickEventLogService;
import com.hyundaicard.cse.app.log.service.PsnlLogService;
import com.hyundaicard.cse.app.search.entity.CategoryResultEntity;
import com.hyundaicard.cse.app.search.entity.CategorySearchResultEntity;
import com.hyundaicard.cse.app.search.entity.ProductResultEntity;
import com.hyundaicard.cse.app.search.entity.SearchApiCotegoryRequestEntity;
import com.hyundaicard.cse.app.search.service.SearchService;
import com.hyundaicard.cse.app.visit.entity.VisitPageEntity;
import com.hyundaicard.cse.app.visit.service.VisitPageService;
import com.hyundaicard.cse.common.entity.RestRespEntity;
import com.hyundaicard.cse.constants.Constants;

/**
 * bookmark Service
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Service
public class BookmarkService {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(BookmarkService.class);

    @Autowired
    private BookmarkMapper mapper;

    @Autowired
    private BookmarkQueryMapper bookmarkQueryMapper;

    @Autowired
    private SearchService searchService;

    @Autowired
    private VisitPageService visitPageService;

    @Autowired
    private PsnlLogService psnlLogService;

    @Autowired
    private ClickEventLogService clickEventLogService;

    @Autowired
    private SessionService sessionService;

    /**
     * 상세
     *
     * @Mehtod Name : get
     * @param entity
     * @return
     */
    public BookmarkEntity get(final BookmarkEntity entity) {
        return mapper.get(entity);
    }

    /**
     * 리스트
     *
     * @Mehtod Name : getAllList
     * @param entity
     * @return
     */
    public List<BookmarkEntity> getAllList(final BookmarkEntity entity) {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }
        entity.setMemberIdSq(memberIdSq);
        entity.setUuid(uuid);
        return mapper.getAllList(entity);
    }

    public List<BookmarkEntity> getAllListForMap(final BookmarkEntity entity) {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }
        entity.setMemberIdSq(memberIdSq);
        entity.setUuid(uuid);
        return mapper.getAllListForMap(entity);
    }

    public List<BookmarkSiteEntity> getSiteAllListForMap(final BookmarkEntity entity) {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }

        entity.setMemberIdSq(memberIdSq);
        entity.setUuid(uuid);
        return mapper.getSiteAllListForMap(entity);
    }

    public List<BookmarkSiteEntity> getSiteAllList() {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }
        final BookmarkEntity entity = new BookmarkEntity();
        entity.setMemberIdSq(memberIdSq);
        entity.setUuid(uuid);
        return mapper.getSiteAllList(entity);
    }

    public List<BookmarkEntity> getSiteList(final BookmarkEntity entity) {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }
        entity.setMemberIdSq(memberIdSq);
        entity.setUuid(uuid);
        return mapper.getSiteList(entity);
    }

    /**
     * 갯수
     *
     * @Mehtod Name : getCount
     * @param entity
     * @return
     */
    public Integer getCount() {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }
        final BookmarkEntity entity = new BookmarkEntity();
        entity.setMemberIdSq(memberIdSq);
        entity.setUuid(uuid);
        return mapper.count(entity);
    }

    /**
     * 입력
     *
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public void insert(final BookmarkEntity entity) {
        mapper.insert(entity);

        // 개인화 이용 팬턴 로그 정보
        final PsnlLogEntity psnlLogParam = new PsnlLogEntity();
        psnlLogParam.setSiteKey(entity.getSiteKey());
        psnlLogParam.setLogTypeCd(Constants.TO_BOOKMARK);
        psnlLogService.insert(psnlLogParam);

        // 사이트 방문 클릭 이벤트 로그 정보
        final ClickEventLogEntity clickEventLogParam = new ClickEventLogEntity();
        clickEventLogParam.setQueryKeyword(entity.getQueryKeyword());
        clickEventLogParam.setQueryTypeCd(entity.getQueryTypeCd());
        clickEventLogParam.setPageInfo(entity.getPageInfo());
        clickEventLogParam.setItemCount(entity.getItemCount());
        clickEventLogParam.setItemPos(entity.getItemPos());
        clickEventLogParam.setClickItemType(entity.getClickItemType());
        clickEventLogParam.setSiteKey(entity.getSiteKey());
        clickEventLogService.insert(clickEventLogParam);

        // TS_FAV_SITE_CAT_QUERY_INFO(회원관심사이트검색어정보) insert
        final BookmarkQueryEntity param = new BookmarkQueryEntity();

        param.setMemberIdSq(entity.getMemberIdSq());
        param.setUuid(entity.getUuid());
        param.setSiteKey(entity.getSiteKey());
        param.setCatKey(entity.getCatKey());
        param.setQuery(entity.getQuery());
        bookmarkQueryMapper.insert(param);
    }

    /**
     * 입력
     *
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public BookmarkEntity processFirstDeleteInsert(final BookmarkEntity entity) {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        final String uuid = sessionService.getAttribute("uuid");
        entity.setUuid(uuid);
        entity.setMemberIdSq(memberIdSq);

        final BookmarkEntity delBookmark = this.firstDelete();
        this.insert(entity);
        return delBookmark;
    }

    /**
     * 삭제
     *
     * @Mehtod Name : delete
     * @param entity
     * @return
     */
    public void delete(final BookmarkEntity entity) {

        // 개인화 이용 팬턴 로그 정보
        final PsnlLogEntity psnlLogParam = new PsnlLogEntity();
        psnlLogParam.setSiteKey(entity.getSiteKey());
        psnlLogParam.setLogTypeCd(Constants.TO_BOOKMARK);
        psnlLogService.update(psnlLogParam);

        mapper.delete(entity);
    }

    public void delete(final List<BookmarkEntity> list) {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }

        // 과거검색어 삭제
        BookmarkQueryEntity param = null;
        PsnlLogEntity psnlLogParam = null;
        for (final BookmarkEntity entity : list) {
            param = new BookmarkQueryEntity();
            param.setMemberIdSq(memberIdSq);
            param.setUuid(uuid);
            param.setSiteKey(entity.getSiteKey());
            param.setCatKey(entity.getCatKey());
            bookmarkQueryMapper.delete(param);

            // 개인화 이용 팬턴 로그 정보
            psnlLogParam = new PsnlLogEntity();
            psnlLogParam.setSiteKey(entity.getSiteKey());
            psnlLogParam.setLogTypeCd(Constants.TO_BOOKMARK);
            psnlLogService.update(psnlLogParam);

            entity.setMemberIdSq(memberIdSq);
            entity.setUuid(uuid);
            mapper.delete(entity);
        }
    }

    public BookmarkEntity firstDelete() {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }

        final BookmarkEntity bookmarkParam = new BookmarkEntity();
        bookmarkParam.setMemberIdSq(memberIdSq);
        bookmarkParam.setUuid(uuid);

        // 첫번째 북마크 가져오기
        final BookmarkEntity fristBookmark = mapper.getFirst(bookmarkParam);
        final String siteKey = fristBookmark.getSiteKey();
        final String catKey = fristBookmark.getCatKey();
        final String favSiteCatSq = fristBookmark.getFavSiteCatSq();

        // 첫번째 북마크 과거검색어 삭제
        final BookmarkQueryEntity param = new BookmarkQueryEntity();
        param.setMemberIdSq(memberIdSq);
        param.setUuid(uuid);
        param.setSiteKey(siteKey);
        param.setCatKey(catKey);
        bookmarkQueryMapper.delete(param);

        // 첫번째 북마크 삭제
        final BookmarkEntity param2 = new BookmarkEntity();
        param2.setMemberIdSq(memberIdSq);
        param2.setUuid(uuid);
        param2.setFavSiteCatSq(favSiteCatSq);
        mapper.delete(param2);

        param2.setCatKey(catKey);
        param2.setSiteKey(siteKey);
        return param2;
    }

    /**
     * bookmark isExistNewCrawlProduct
     *
     * @Mehtod Name : isExistNewCrawlProduct @return String @throws
     */
    public boolean isExistNewCrawlProduct() {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }

        RestRespEntity restRespEntity = new RestRespEntity();
        boolean isExistNewCrawlProduct = Boolean.FALSE;
        try {
            /** 2. validate check */
            // if (EntityValidator.isValid(entity)) {
            // logger.warn("Validate error!!!!!");
            // return CommonUtil.response(ResultCode.C1001, restRespEntity);
            // }
            // 북마크 데이타
            final List<BookmarkSiteEntity> list = this.getSiteAllList();

            if (!list.isEmpty()) {
                final StringBuilder catKeys = new StringBuilder(256);
                for (final BookmarkSiteEntity e : list) {
                    catKeys.append("," + e.getCatKey());
                }

                // 카테고리 데이타
                final SearchApiCotegoryRequestEntity param = new SearchApiCotegoryRequestEntity();
                param.setSiteCategoryKeys("[" + catKeys.toString().substring(1) + "]");
                restRespEntity = searchService.cotegoryList(param);

                final CategoryResultEntity CategoryResultEntity = (CategoryResultEntity) restRespEntity.getResultData();
                final List<CategorySearchResultEntity> apiCategoryRows = CategoryResultEntity.getData().getRows();

                // bookmark page 접속 페이지
                final VisitPageEntity visitPageMaxParam = new VisitPageEntity();
                visitPageMaxParam.setMemberIdSq(memberIdSq);
                visitPageMaxParam.setUuid(uuid);
                visitPageMaxParam.setPageCd("10");// bookmark
                final String maxPageVisitDtmStr = visitPageService.getMaxPageVisitDtm(visitPageMaxParam);

                double maxPageVisitDtm = -1;
                if (!StringUtils.isBlank(maxPageVisitDtmStr)) {
                    maxPageVisitDtm = Double.parseDouble(maxPageVisitDtmStr);

                    CategorySearchResultEntity categoryRow = null;
                    double productCrawl = 0.0d;
                    String productCrawlstr = "";
                    for (int ctgNum = 0; ctgNum < apiCategoryRows.size(); ctgNum++) {
                        categoryRow = apiCategoryRows.get(ctgNum);
                        // 제품
                        final List<ProductResultEntity> products = categoryRow.getProducts();
                        if (!products.isEmpty()) {
                            for (final ProductResultEntity product : products) {
                                final String product_crawl = product.getProduct_crawl();

                                if (maxPageVisitDtm == -1) {
                                    isExistNewCrawlProduct = Boolean.TRUE;
                                } else if (!StringUtils.isBlank(product_crawl)) {

                                    productCrawlstr = product_crawl.replace("-", "").replace(":", "").replace("T", "").replace("Z", "");
                                    productCrawl = Double.parseDouble(productCrawlstr);
                                    logger.debug("maxPageVisitDtmStr {} : productCrawlstr {}", maxPageVisitDtmStr, productCrawlstr);

                                    if (maxPageVisitDtm < productCrawl) {
                                        isExistNewCrawlProduct = Boolean.TRUE;
                                    }
                                }
                                if (isExistNewCrawlProduct) {
                                    break;
                                }
                            }
                        }
                        if (isExistNewCrawlProduct) {
                            break;
                        }
                    }
                } else {
                    isExistNewCrawlProduct = Boolean.TRUE;
                }
            }
        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
        }
        return isExistNewCrawlProduct;
    }

    /**
     * int getNewProductCnt
     *
     * @Mehtod Name : getNewProductCnt @return int @throws
     */
    public int getNewProductCnt() {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }

        int cnt = 0;
        RestRespEntity restRespEntity = new RestRespEntity();
        // 북마크 데이타
        final List<BookmarkSiteEntity> list = this.getSiteAllList();

        if (!list.isEmpty()) {
            final StringBuilder catKeys = new StringBuilder(256);
            for (final BookmarkSiteEntity e : list) {
                catKeys.append("," + e.getCatKey());
            }

            // 카테고리 데이타
            final SearchApiCotegoryRequestEntity param = new SearchApiCotegoryRequestEntity();
            param.setSiteCategoryKeys("[" + catKeys.toString().substring(1) + "]");
            restRespEntity = searchService.cotegoryList(param);

            final CategoryResultEntity CategoryResultEntity = (CategoryResultEntity) restRespEntity.getResultData();
            final List<CategorySearchResultEntity> apiCategoryRows = CategoryResultEntity.getData().getRows();

            // bookmark page 접속 페이지
            final VisitPageEntity visitPageMaxParam = new VisitPageEntity();
            visitPageMaxParam.setMemberIdSq(memberIdSq);
            visitPageMaxParam.setUuid(uuid);
            visitPageMaxParam.setPageCd("10");// bookmark
            final String maxPageVisitDtmStr = visitPageService.getMaxPageVisitDtm(visitPageMaxParam);

            double maxPageVisitDtm = -1;
            CategorySearchResultEntity categoryRow = null;
            double productCrawl = 0.0d;
            String productCrawlstr = "";

            if (!StringUtils.isBlank(maxPageVisitDtmStr)) {
                maxPageVisitDtm = Double.parseDouble(maxPageVisitDtmStr);

                for (int ctgNum = 0; ctgNum < apiCategoryRows.size(); ctgNum++) {
                    categoryRow = apiCategoryRows.get(ctgNum);
                    // 제품
                    final List<ProductResultEntity> products = categoryRow.getProducts();
                    if (!products.isEmpty()) {
                        for (final ProductResultEntity product : products) {
                            final String product_crawl = product.getProduct_crawl();

                            if (!StringUtils.isBlank(product_crawl)) {

                                productCrawlstr = product_crawl.replace("-", "").replace(":", "").replace("T", "").replace("Z", "");
                                productCrawl = Double.parseDouble(productCrawlstr);
                                logger.debug("maxPageVisitDtmStr {} : productCrawlstr {}", maxPageVisitDtmStr, productCrawlstr);

                                if (maxPageVisitDtm < productCrawl) {
                                    cnt++;
                                }
                            }
                        }
                    }
                }
            } else {
                for (int ctgNum = 0; ctgNum < apiCategoryRows.size(); ctgNum++) {
                    categoryRow = apiCategoryRows.get(ctgNum);
                    // 제품
                    final List<ProductResultEntity> products = categoryRow.getProducts();
                    if (!products.isEmpty()) {
                        cnt += products.size();
                    }
                }
            }
        }
        return cnt;
    }
}
