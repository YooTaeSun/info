package com.hyundaicard.cse.app.share.entity;

/**
 * share Entity
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public class ShareEntity {
    private String shortenUrl; // 그룹코드명
    private String realUrl; // 실제 url
    private String memberIdSq; // 회원아이디 일련번호
    private String uuid; // 비회원 단말 식별값
    private String insertDt; // 등록일시

    private String path1; // custom

    public String getShortenUrl() {
        return shortenUrl;
    }

    public void setShortenUrl(final String shortenUrl) {
        this.shortenUrl = shortenUrl;
    }

    public String getRealUrl() {
        return realUrl;
    }

    public void setRealUrl(final String realUrl) {
        this.realUrl = realUrl;
    }

    public String getMemberIdSq() {
        return memberIdSq;
    }

    public void setMemberIdSq(final String memberIdSq) {
        this.memberIdSq = memberIdSq;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    public String getInsertDt() {
        return insertDt;
    }

    public void setInsertDt(final String insertDt) {
        this.insertDt = insertDt;
    }

    public String getPath1() {
        return path1;
    }

    public void setPath1(final String path1) {
        this.path1 = path1;
    }

}
