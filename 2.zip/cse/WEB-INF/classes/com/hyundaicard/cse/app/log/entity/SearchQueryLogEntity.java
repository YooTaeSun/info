package com.hyundaicard.cse.app.log.entity;

/**
 * search query  Entity
 * @version : 1.0
 * @author :  Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public class SearchQueryLogEntity {
	private String queryLogSq;	//검색키워드 로그 순번
	private String queryKeyword;	//검색키워드
	private String queryTypeCd;	//검색구분코드
	private String itemCount;	//결과아이템갯수
	private String memberIdSq;	//회원아이디 일련번호
	private String uuid;	  //단말식별값
	private String sessionId;	//세션아이디
	private String insertDt;	//등록일시

	public String getQueryLogSq() {
 		 return queryLogSq; 
 	}
	public void setQueryLogSq(String queryLogSq) {
 		 this.queryLogSq=queryLogSq; 
 	}
	public String getQueryKeyword() {
 		 return queryKeyword; 
 	}
	public void setQueryKeyword(String queryKeyword) {
 		 this.queryKeyword=queryKeyword; 
 	}
	public String getQueryTypeCd() {
 		 return queryTypeCd; 
 	}
	public void setQueryTypeCd(String queryTypeCd) {
 		 this.queryTypeCd=queryTypeCd; 
 	}
	public String getItemCount() {
 		 return itemCount; 
 	}
	public void setItemCount(String itemCount) {
 		 this.itemCount=itemCount; 
 	}
	public String getMemberIdSq() {
 		 return memberIdSq; 
 	}
	public void setMemberIdSq(String memberIdSq) {
 		 this.memberIdSq=memberIdSq; 
 	}
	public String getUuid() {
 		 return uuid; 
 	}
	public void setUuid(String uuid) {
 		 this.uuid=uuid; 
 	}
	public String getSessionId() {
 		 return sessionId; 
 	}
	public void setSessionId(String sessionId) {
 		 this.sessionId=sessionId; 
 	}
	public String getInsertDt() {
 		 return insertDt; 
 	}
	public void setInsertDt(String insertDt) {
 		 this.insertDt=insertDt; 
 	}

}
