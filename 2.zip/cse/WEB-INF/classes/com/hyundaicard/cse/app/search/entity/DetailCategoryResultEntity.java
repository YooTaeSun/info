package com.hyundaicard.cse.app.search.entity;

import java.util.List;

/**
 * Detail Category List Info
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public class DetailCategoryResultEntity {

    private Data data;

    public Data getData() {
        return data;
    }

    public void setData(final Data data) {
        this.data = data;
    }

    public static class Data {
        private List<CategorySearchResultEntity> rows;
        private RangeResultEntity range;
        private String query;

        private QkaResultEntity qka;

        public List<CategorySearchResultEntity> getRows() {
            return rows;
        }

        public void setRows(final List<CategorySearchResultEntity> rows) {
            this.rows = rows;
        }

        public RangeResultEntity getRange() {
            return range;
        }

        public void setRange(final RangeResultEntity range) {
            this.range = range;
        }

        public String getQuery() {
            return query;
        }

        public void setQuery(final String query) {
            this.query = query;
        }

        public QkaResultEntity getQka() {
            return qka;
        }

        public void setQka(final QkaResultEntity qka) {
            this.qka = qka;
        }

    }
}
