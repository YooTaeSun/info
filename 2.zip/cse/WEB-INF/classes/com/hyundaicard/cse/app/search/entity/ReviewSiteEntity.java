package com.hyundaicard.cse.app.search.entity;

import java.math.BigInteger;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import com.hyundaicard.cse.common.entity.AbstractPage;

public class ReviewSiteEntity extends AbstractPage {

    @NotEmpty
    @Size(max = 20)
    private BigInteger reviewSiteSq = null;

    @NotEmpty
    @Size(max = 20)
    private String memberIdSq = null;

    private String userId = null;

    @Size(max = 20)
    private String uuid = null;

    @Size(max = 128)
    private String passwd = null;

    @NotEmpty
    @Size(max = 10)
    private String siteKey = null;

    @NotEmpty
    @Size(max = 5)
    private Integer grade = null;

    @Size(max = 4096)
    private String review = null;

    private String isMine = null;

    private Integer startNum = null;

    public BigInteger getReviewSiteSq() {
        return reviewSiteSq;
    }

    public void setReviewSiteSq(final BigInteger reviewSiteSq) {
        this.reviewSiteSq = reviewSiteSq;
    }

    public String getMemberIdSq() {
        return memberIdSq;
    }

    public void setMemberIdSq(final String memberIdSq) {
        this.memberIdSq = memberIdSq;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(final String passwd) {
        this.passwd = passwd;
    }

    public String getSiteKey() {
        return siteKey;
    }

    public void setSiteKey(final String siteKey) {
        this.siteKey = siteKey;
    }

    public Integer getGrade() {
        return grade;
    }

    public void setGrade(final Integer grade) {
        this.grade = grade;
    }

    public String getReview() {
        return review;
    }

    public void setReview(final String review) {
        this.review = review;
    }

    public String getIsMine() {
        return isMine;
    }

    public void setIsMine(final String isMine) {
        this.isMine = isMine;
    }

    public Integer getStartNum() {
        return startNum;
    }

    public void setStartNum(final Integer startNum) {
        this.startNum = startNum;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(final String userId) {
        this.userId = userId;
    }

}
