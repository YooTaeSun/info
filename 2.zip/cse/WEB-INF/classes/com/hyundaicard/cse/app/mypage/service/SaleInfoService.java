package com.hyundaicard.cse.app.mypage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.mypage.entity.SaleInfoEntity;
import com.hyundaicard.cse.app.mypage.mapper.SaleInfoMapper;
import com.hyundaicard.cse.common.entity.PagingValue;

/**
 * SaleInfo Service
 */
@Service
public class SaleInfoService {

    /** Mapper */
    @Autowired
    private SaleInfoMapper saleInfoMapper;

    /**
     * 할인정보 리스트 조회
     */
    public List<SaleInfoEntity> getSaleInfoList(final SaleInfoEntity saleInfoEntity) {
        final int count = this.getCount(saleInfoEntity);

        final PagingValue paging = saleInfoEntity.getPagingValue(count);

        saleInfoEntity.setPaging(paging);

        final List<SaleInfoEntity> saleInfoList = saleInfoMapper.getSaleInfoList(saleInfoEntity);

        return saleInfoList;
    }

    /**
     * 총갯수 조회
     */
    public int getCount(final SaleInfoEntity saleInfoEntity) {
        return saleInfoMapper.getCount(saleInfoEntity);
    }

    public int getCountLikeSite(final SaleInfoEntity saleInfoEntity) {
        return saleInfoMapper.getCountLikeSite(saleInfoEntity);
    }

    /**
     * 할인정보 리스트 조회
     */
    public List<SaleInfoEntity> getAllList(final SaleInfoEntity saleInfoEntity) {
        return saleInfoMapper.getAllList(saleInfoEntity);
    }

    public Integer getCntInitSaleInfo(final SaleInfoEntity saleInfoEntity) {
        return saleInfoMapper.getCntInitSaleInfo(saleInfoEntity);
    }

}
