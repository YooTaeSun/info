package com.hyundaicard.cse.app.question.entity;

public class ChoiceEntity {

    private int choiceSeq;
    private String choiceText;
    private String choiceVal;
    private String etcFlagYn;

    public int getChoiceSeq() {
        return choiceSeq;
    }

    public void setChoiceSeq(final int choiceSeq) {
        this.choiceSeq = choiceSeq;
    }

    public String getChoiceText() {
        return choiceText;
    }

    public void setChoiceText(final String choiceText) {
        this.choiceText = choiceText;
    }

    public String getChoiceVal() {
        return choiceVal;
    }

    public void setChoiceVal(final String choiceVal) {
        this.choiceVal = choiceVal;
    }

    public String getEtcFlagYn() {
        return etcFlagYn;
    }

    public void setEtcFlagYn(final String etcFlagYn) {
        this.etcFlagYn = etcFlagYn;
    }

}
