package com.hyundaicard.cse.app.visit.mapper;

import com.hyundaicard.cse.app.visit.entity.VisitPageEntity;

/**
 * visit page Mapper
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public interface VisitPageMapper {

    /**
     * 조회
     *
     * @Mehtod Name : get
     * @param entity
     * @return
     */
    public VisitPageEntity get(VisitPageEntity entity);

    public String getMaxPageVisitDtm(VisitPageEntity entity);

    //
    // /**
    // * 리스트
    // *
    // * @Mehtod Name : getList
    // * @param entity
    // * @return
    // */
    // public List<VisitPageEntity> getList(VisitPageEntity entity);
    //
    // /**
    // * 전체 리스트
    // *
    // * @Mehtod Name : getAllList
    // * @param entity
    // * @return
    // */
    // public List<VisitPageEntity> getAllList(VisitPageEntity entity);
    //
    // /**
    // * 전체목록
    // *
    // * @Mehtod Name : getListTotal
    // * @param entity
    // * @return
    // */
    // public List<VisitPageEntity> getListTotal(VisitPageEntity entity);
    //
    /**
     * 카운트
     *
     * @Mehtod Name : count
     * @param entity
     * @return
     */
    public int count(VisitPageEntity entity);

    /**
     * 등록
     *
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public void insert(VisitPageEntity entity);

    // /**
    // * 수정
    // *
    // * @Mehtod Name : update
    // * @param entity
    // * @return
    // */
    // public void update(VisitPageEntity entity);
    //
    // /**
    // * 삭제
    // *
    // * @Mehtod Name : delete
    // * @param entity
    // * @return
    // */
    // public void delete(VisitPageEntity entity);
}
