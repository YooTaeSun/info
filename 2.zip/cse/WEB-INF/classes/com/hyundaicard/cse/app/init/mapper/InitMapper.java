package com.hyundaicard.cse.app.init.mapper;

import org.springframework.dao.DataAccessException;

import com.hyundaicard.cse.app.init.entity.AppTokenEntity;
import com.hyundaicard.cse.app.init.entity.EmergencyNoticeEntity;
import com.hyundaicard.cse.app.init.entity.UpdateInfoEntity;

/**
 * Init Mapper
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public interface InitMapper {

    /**
     * app 정보 조회
     *
     * @method getAppInfo
     * @param appInfoEntity
     * @return
     * @throws DataAccessException
     */
    public UpdateInfoEntity getUpdateInfo(UpdateInfoEntity updateInfoEntity) throws DataAccessException;

    /**
     * 긴급 공지 조회
     */
    public EmergencyNoticeEntity getEmergencyNotice() throws DataAccessException;

    /**
     * 앱 토큰 업데이트
     */
    public void updateAppToken(AppTokenEntity appTokenEntity) throws DataAccessException;

    /**
     * 푸시 수신여부 업데이트
     */
    public void updatePushReceiveInfo(AppTokenEntity appTokenEntity) throws DataAccessException;
}
