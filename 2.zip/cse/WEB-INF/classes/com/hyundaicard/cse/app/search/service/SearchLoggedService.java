package com.hyundaicard.cse.app.search.service;

import java.io.StringReader;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.HtmlUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hyundaicard.cse.app.bookmark.entity.BookmarkEntity;
import com.hyundaicard.cse.app.bookmark.service.BookmarkService;
import com.hyundaicard.cse.app.bookmark.service.SessionService;
import com.hyundaicard.cse.app.like.entity.LikeCountEntity;
import com.hyundaicard.cse.app.like.entity.LikeEntity;
import com.hyundaicard.cse.app.like.service.LikeCountService;
import com.hyundaicard.cse.app.like.service.LikeService;
import com.hyundaicard.cse.app.log.service.LogService;
import com.hyundaicard.cse.app.search.entity.CategorySearchResultEntity;
import com.hyundaicard.cse.app.search.entity.DetailCategoryResultEntity;
import com.hyundaicard.cse.app.search.entity.PersonalResultEntity;
import com.hyundaicard.cse.app.search.entity.PersonalSiteResultEntity;
import com.hyundaicard.cse.app.search.entity.QkaResultEntity;
import com.hyundaicard.cse.app.search.entity.QkaResultEntity.NamedResultEntity;
import com.hyundaicard.cse.app.search.entity.SearchApiDetailCategoryRequestEntity;
import com.hyundaicard.cse.app.search.entity.SearchApiRequestEntity;
import com.hyundaicard.cse.common.code.ResultCode;
import com.hyundaicard.cse.common.entity.RestRespEntity;
import com.hyundaicard.cse.common.util.Config;
import com.hyundaicard.cse.constants.Constants;

/**
 * 검색결과 Service
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Service
@SuppressWarnings({ "rawtypes", "unchecked" })
public class SearchLoggedService {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(SearchLoggedService.class);

    @Autowired
    private RestTemplate apiRestTemplate;

    @Autowired
    private SearchService searchService;

    @Autowired
    private LikeService likeService;

    @Autowired
    private LikeCountService likeCountService;

    @Autowired
    private BookmarkService bookmarkService;

    @Autowired
    private LogService logService;

    @Autowired
    private SessionService sessionService;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * 나에게 맞는 logged
     *
     * @Mehtod Name : search0103
     * @param entity
     * @return
     */
    public RestRespEntity processSearch0301Logged(final SearchApiRequestEntity entity) {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }

        final RestRespEntity restRespEntity = new RestRespEntity();
        restRespEntity.setResultCode(ResultCode.C0.getCode());

        try {
            final HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            final HttpEntity<?> requestParamEntity = new HttpEntity(headers);

            final String apiUrl = Config.getCommon().getString("SEARCH_ENGINE_API.SITE_URL") + Config.getCommon().getString("SEARCH_ENGINE_API.LOGGER_API.URL.LIST");

            final HashMap<String, String> param = new HashMap<String, String>();
            param.put("page", String.valueOf(entity.getPage()));
            param.put("size", String.valueOf(entity.getSize()));
            param.put("query", entity.getQuery());
            param.put("svcwt", Config.getCommon().getString("SEARCH_ENGINE_API.LOGGER_API.SVCWT"));
            param.put("catsize", "1");
            param.put("prdsize", "20");
            param.put("siteKeys", entity.getSiteKeys());

            String requestUrl = searchService.getSearchRequestParameter(apiUrl, param);
            boolean isOneWord = true;

            if (entity.getQuery().trim().indexOf(" ") > -1) {
                isOneWord = false;
            }

            final HashMap<String, String> paramMap = new HashMap<String, String>();
            if (entity.getFilter() != null) {
                final String filter = HtmlUtils.htmlUnescape(entity.getFilter());
                logger.debug("filter :: {}", filter);
                paramMap.put("filter", filter);
                requestUrl += "&filter={filter}";

                // 2017.10.09 필터 gender 선택시 검색어에 필터한글명 부쳐주기
                requestUrl = searchService.genderFilterAppend(requestUrl, filter);
                logger.debug("requestUrl : {} ", requestUrl.replaceAll("\\{filter\\}", filter));
            }

            logger.debug("logged requestUrl :: {}", requestUrl);

            final ResponseEntity<String> apiResponse = apiRestTemplate.exchange(requestUrl, HttpMethod.GET, requestParamEntity, String.class, paramMap);
            if (apiResponse.getStatusCode() == HttpStatus.OK) {
                final String body = apiResponse.getBody();
                logger.debug(" body : {} ", body);

                final StringReader reader = new StringReader(body); // Json Response

                final PersonalResultEntity resultEntity = objectMapper.readValue(reader, PersonalResultEntity.class);
                final com.hyundaicard.cse.app.search.entity.PersonalResultEntity.Data data = resultEntity.getData();
                final QkaResultEntity qka = data.getQka();
                final List<NamedResultEntity> namedEntities = qka.getNamedEntities();
                String filterType = "";
                if (namedEntities.size() >= 1 && isOneWord) {
                    String tempfilterType = "";
                    final List<String> types = namedEntities.get(0).getTypes();
                    for (final String type : types) {
                        if (Constants.FILTER_TYPE_CATEGORY.equals(type)) {
                            filterType = Constants.FILTER_TYPE_CATEGORY;
                            break;
                        }

                        if (Constants.FILTER_TYPE_BRAND.equals(type)) {
                            tempfilterType = Constants.FILTER_TYPE_BRAND;
                            break;
                        }
                    }

                    if ("".equals(filterType) && !"".equals(tempfilterType)) {
                        filterType = tempfilterType;
                    }
                }
                data.setFilterType(filterType);
                final List<PersonalSiteResultEntity> rows = data.getRows();

                if (!rows.isEmpty()) {
                    final StringBuilder catKeys = new StringBuilder(256);
                    CategorySearchResultEntity category = null;

                    for (final PersonalSiteResultEntity row : rows) {

                        final List<CategorySearchResultEntity> categoryList = row.getCategories();
                        if (!categoryList.isEmpty()) {
                            category = categoryList.get(0);
                            catKeys.append(",'" + category.getId() + "'");
                            row.setCategory(category);
                            row.setCategories(null);
                            logger.debug("catKey :: {} ", category.getId());
                        }
                    }

                    // 좋아요 사이트
                    final LikeEntity LikeParam = new LikeEntity();
                    LikeParam.setMemberIdSq(memberIdSq);
                    LikeParam.setUuid(uuid);
                    LikeParam.setCatKeys("(" + catKeys.toString().substring(1) + ")");
                    final List<LikeEntity> likeList = likeService.getAllList(LikeParam);

                    // 좋아요 갯수
                    final LikeCountEntity LikeCountParam = new LikeCountEntity();
                    LikeCountParam.setCatKeys("(" + catKeys.toString().substring(1) + ")");
                    final List<LikeCountEntity> likeCountList = likeCountService.getAllList(LikeCountParam);

                    // bookmark(관심)
                    final BookmarkEntity bookmarkParam = new BookmarkEntity();
                    bookmarkParam.setCatKeys("(" + catKeys.toString().substring(1) + ")");
                    bookmarkParam.setMemberIdSq(memberIdSq);
                    bookmarkParam.setUuid(uuid);
                    final List<BookmarkEntity> bookmarkList = bookmarkService.getAllListForMap(bookmarkParam);

                    // 관심사이트 검색어 저장
                    if (!bookmarkList.isEmpty()) {
                        searchService.insertIfFavfavQuery(rows, bookmarkList, entity.getQuery());
                    }

                    String categoryId = "";
                    LikeEntity like = null;
                    LikeCountEntity likeCount = null;
                    BookmarkEntity bookmarkEntity = null;

                    for (final PersonalSiteResultEntity row : rows) {
                        category = row.getCategory();

                        if (category != null) {
                            categoryId = category.getId();

                            // 좋아요 사이트
                            category.setCtg_is_like("N");
                            for (int i = 0; i < likeList.size(); i++) {
                                like = likeList.get(i);
                                if (categoryId.equals(like.getCatKey())) {
                                    category.setCtg_is_like("Y");
                                    category.setLikeSiteCatSq(like.getLikeSiteCatSq());
                                    likeList.remove(i);
                                    i--;
                                }
                            }
                            // 좋아요 갯수
                            category.setCtg_cnt("0");
                            for (int i = 0; i < likeCountList.size(); i++) {
                                likeCount = likeCountList.get(i);
                                if (categoryId.equals(likeCount.getCatKey())) {
                                    category.setCtg_cnt(likeCount.getLikeCnt());
                                    likeCountList.remove(i);
                                    i--;
                                }
                            }
                            // bookmark(관심)
                            category.setCtg_is_bookmark("N");
                            for (int i = 0; i < bookmarkList.size(); i++) {
                                bookmarkEntity = bookmarkList.get(i);
                                if (categoryId.equals(bookmarkEntity.getCatKey())) {
                                    category.setCtg_is_bookmark("Y");
                                    bookmarkList.remove(i);
                                    i--;
                                }
                            }
                        }
                    }
                }
                restRespEntity.setResultData(resultEntity);
                // 2017.09.15 검색어 로그정보 저장
                logService.insertSearchQuery(Constants.QUERY_TYPE_3_3, entity.getQuery(), resultEntity);
            }
            return restRespEntity;
        } catch (final HttpStatusCodeException exception) {
            final String body = exception.getResponseBodyAsString();
            logger.error(" body {} ", body);
            restRespEntity.setResultCode(ResultCode.C204.getCode());
            return restRespEntity;
        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            restRespEntity.setResultCode(ResultCode.C9999.getCode());
            return restRespEntity;
        }
    }

    public RestRespEntity processSearch0301LoggedFilter(final SearchApiRequestEntity entity) {

        final RestRespEntity restRespEntity = new RestRespEntity();
        restRespEntity.setResultCode(ResultCode.C0.getCode());

        try {
            final HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            final HttpEntity<?> requestParamEntity = new HttpEntity(headers);

            final String apiUrl = Config.getCommon().getString("SEARCH_ENGINE_API.SITE_URL") + Config.getCommon().getString("SEARCH_ENGINE_API.LOGGER_API.URL.LIST");

            final HashMap<String, String> param = new HashMap<String, String>();
            param.put("page", "1");
            param.put("size", "0");
            param.put("query", entity.getQuery());
            param.put("svcwt", Config.getCommon().getString("SEARCH_ENGINE_API.LOGGER_API.SVCWT"));
            param.put("catsize", "0");
            param.put("prdsize", "0");
            param.put("siteKeys", entity.getSiteKeys());

            String requestUrl = searchService.getSearchRequestParameter(apiUrl, param);
            final HashMap<String, String> paramMap = new HashMap<String, String>();
            if (entity.getFilter() != null) {
                final String filter = HtmlUtils.htmlUnescape(entity.getFilter());
                logger.debug("filter :: {}", filter);
                paramMap.put("filter", filter);
                requestUrl += "&filter={filter}";

                // 2017.10.09 필터 gender 선택시 검색어에 필터한글명 부쳐주기
                requestUrl = searchService.genderFilterAppend(requestUrl, filter);
                logger.debug("requestUrl : {} ", requestUrl.replaceAll("\\{filter\\}", filter));
            }

            logger.debug("loggedFilter requestUrl :: {}", requestUrl);

            final ResponseEntity<String> apiResponse = apiRestTemplate.exchange(requestUrl, HttpMethod.GET, requestParamEntity, String.class, paramMap);
            if (apiResponse.getStatusCode() == HttpStatus.OK) {
                final String body = apiResponse.getBody();
                logger.debug(" body : {} ", body);

                final StringReader reader = new StringReader(body); // Json Response
                final PersonalResultEntity resultEntity = objectMapper.readValue(reader, PersonalResultEntity.class);
                restRespEntity.setResultData(resultEntity);
            }
            return restRespEntity;
        } catch (final HttpStatusCodeException exception) {
            final String body = exception.getResponseBodyAsString();
            logger.error(" body {} ", body);
            restRespEntity.setResultCode(ResultCode.C204.getCode());
            return restRespEntity;
        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            restRespEntity.setResultCode(ResultCode.C9999.getCode());
            return restRespEntity;
        }
    }

    /**
     * 내게맞는 Site Category List
     *
     * @Mehtod Name : searchDetailCategory
     * @param entity
     * @return
     */
    public RestRespEntity searchDetailCategory(final SearchApiDetailCategoryRequestEntity entity) {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }

        final RestRespEntity restRespEntity = new RestRespEntity();
        restRespEntity.setResultCode(ResultCode.C0.getCode());

        try {
            final HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            final HttpEntity<?> requestParamEntity = new HttpEntity(headers);

            String apiUrl = Config.getCommon().getString("SEARCH_ENGINE_API.SITE_URL") + Config.getCommon().getString("SEARCH_ENGINE_API.LOGGER_API.URL.SITE_CATEGORY_LIST");
            apiUrl = apiUrl.replaceAll(":siteId", entity.getSiteId());

            final HashMap<String, String> param = new HashMap<String, String>();
            param.put("query", entity.getQuery());
            param.put("page", String.valueOf(entity.getPage()));
            param.put("size", String.valueOf(entity.getSize()));
            param.put("prdsize", "20");

            final String requestUrl = searchService.getSearchRequestParameter(apiUrl, param);

            logger.debug("searchDetailCategory requestUrl :: {}", requestUrl);

            final ResponseEntity<String> apiResponse = apiRestTemplate.exchange(requestUrl, HttpMethod.GET, requestParamEntity, String.class);
            if (apiResponse.getStatusCode() == HttpStatus.OK) {
                final String body = apiResponse.getBody();
                logger.debug(" body : {} ", body);

                final StringReader reader = new StringReader(body); // Json Response

                final DetailCategoryResultEntity resultEntity = objectMapper.readValue(reader, DetailCategoryResultEntity.class);

                final StringBuilder catKeys = new StringBuilder(256);
                final List<CategorySearchResultEntity> categories = resultEntity.getData().getRows();
                if (!categories.isEmpty()) {
                    for (final CategorySearchResultEntity e : categories) {
                        catKeys.append(",'" + e.getId() + "'");
                    }
                }

                // 좋아요 사이트카테고리
                final LikeEntity LikeParam = new LikeEntity();
                LikeParam.setMemberIdSq(memberIdSq);
                LikeParam.setUuid(uuid);
                LikeParam.setCatKeys("(" + catKeys.toString().substring(1) + ")");
                final List<LikeEntity> likeList = likeService.getAllList(LikeParam);

                // 좋아요 사이트카테고리 갯수
                final LikeCountEntity LikeCountParam = new LikeCountEntity();
                LikeCountParam.setCatKeys("(" + catKeys.toString().substring(1) + ")");
                final List<LikeCountEntity> likeCountList = likeCountService.getAllList(LikeCountParam);

                // bookmark(관심)
                final BookmarkEntity bookmarkParam = new BookmarkEntity();
                bookmarkParam.setCatKeys("(" + catKeys.toString().substring(1) + ")");
                bookmarkParam.setMemberIdSq(memberIdSq);
                bookmarkParam.setUuid(uuid);
                final List<BookmarkEntity> bookmarkList = bookmarkService.getAllListForMap(bookmarkParam);

                String categoryId = "";
                LikeEntity like = null;
                LikeCountEntity likeCount = null;
                BookmarkEntity bookmarkEntity = null;

                if (!categories.isEmpty()) {
                    for (final CategorySearchResultEntity category : categories) {
                        categoryId = category.getId();

                        // 좋아요 사이트
                        category.setCtg_is_like("N");
                        for (int i = 0; i < likeList.size(); i++) {
                            like = likeList.get(i);
                            if (categoryId.equals(like.getCatKey())) {
                                category.setCtg_is_like("Y");
                                category.setLikeSiteCatSq(like.getLikeSiteCatSq());
                                likeList.remove(i);
                                i--;
                            }
                        }
                        // 좋아요 갯수
                        category.setCtg_cnt("0");
                        for (int i = 0; i < likeCountList.size(); i++) {
                            likeCount = likeCountList.get(i);
                            if (categoryId.equals(likeCount.getCatKey())) {
                                category.setCtg_cnt(likeCount.getLikeCnt());
                                likeCountList.remove(i);
                                i--;
                            }
                        }
                        // bookmark(관심)
                        category.setCtg_is_bookmark("N");
                        for (int i = 0; i < bookmarkList.size(); i++) {
                            bookmarkEntity = bookmarkList.get(i);
                            if (categoryId.equals(bookmarkEntity.getCatKey())) {
                                category.setCtg_is_bookmark("Y");
                                bookmarkList.remove(i);
                                i--;
                            }
                        }
                    }
                }
                restRespEntity.setResultData(resultEntity);
            }
            return restRespEntity;
        } catch (final HttpStatusCodeException exception) {
            final String body = exception.getResponseBodyAsString();
            logger.error(" body {} ", body);
            restRespEntity.setResultCode(ResultCode.C204.getCode());
            return restRespEntity;
        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            restRespEntity.setResultCode(ResultCode.C9999.getCode());
            return restRespEntity;
        }
    }
}