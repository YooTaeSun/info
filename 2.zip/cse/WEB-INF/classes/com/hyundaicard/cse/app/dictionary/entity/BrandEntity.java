package com.hyundaicard.cse.app.dictionary.entity;

public class BrandEntity {

    private String dicType;
    private String dicKey;
    private String dicEng;
    private String dicKor;

    private String srchVal;

    public String getDicType() {
        return dicType;
    }

    public void setDicType(final String dicType) {
        this.dicType = dicType;
    }

    public String getDicKey() {
        return dicKey;
    }

    public void setDicKey(final String dicKey) {
        this.dicKey = dicKey;
    }

    public String getDicEng() {
        return dicEng;
    }

    public void setDicEng(final String dicEng) {
        this.dicEng = dicEng;
    }

    public String getDicKor() {
        return dicKor;
    }

    public void setDicKor(final String dicKor) {
        this.dicKor = dicKor;
    }

    public String getSrchVal() {
        return srchVal;
    }

    public void setSrchVal(final String srchVal) {
        this.srchVal = srchVal;
    }

}
