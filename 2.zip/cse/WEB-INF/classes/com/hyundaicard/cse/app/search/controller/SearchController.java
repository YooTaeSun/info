package com.hyundaicard.cse.app.search.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.util.HtmlUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hyundaicard.cse.app.bookmark.service.SessionService;
import com.hyundaicard.cse.app.like.entity.LikeEntity;
import com.hyundaicard.cse.app.log.entity.PersonalTypeEntity;
import com.hyundaicard.cse.app.question.entity.AnswerEntity;
import com.hyundaicard.cse.app.question.service.AnswerService;
import com.hyundaicard.cse.app.search.entity.ReviewSiteEntity;
import com.hyundaicard.cse.app.search.entity.SearchApiDetailCategoryRequestEntity;
import com.hyundaicard.cse.app.search.entity.SearchApiDetailRequestEntity;
import com.hyundaicard.cse.app.search.entity.SearchApiRequestEntity;
import com.hyundaicard.cse.app.search.entity.SearchAutocompleteRequestEntity;
import com.hyundaicard.cse.app.search.service.ReviewSiteService;
import com.hyundaicard.cse.app.search.service.SearchLoggedService;
import com.hyundaicard.cse.app.search.service.SearchNewPopularService;
import com.hyundaicard.cse.app.search.service.SearchPersonalService;
import com.hyundaicard.cse.app.search.service.SearchPopularService;
import com.hyundaicard.cse.app.search.service.SearchQuestionService;
import com.hyundaicard.cse.app.search.service.SearchService;
import com.hyundaicard.cse.common.code.ResultCode;
import com.hyundaicard.cse.common.entity.RestRespEntity;
import com.hyundaicard.cse.common.util.CommonUtil;
import com.hyundaicard.cse.common.util.Config;
import com.hyundaicard.cse.constants.Constants;
import com.hyundaicard.cse.framework.validate.EntityValidator;

/**
 * 인기있는 Controller
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Controller
@SuppressWarnings("rawtypes")
public class SearchController {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(SearchController.class);

    @Autowired
    private SearchPopularService searchPopularService;

    @Autowired
    private SearchNewPopularService searchNewPopularService;

    @Autowired
    private SearchPersonalService searchPersonalService;

    @Autowired
    private SearchQuestionService searchQuestionService;

    @Autowired
    private SearchLoggedService searchLoggedService;

    @Autowired
    private SearchService searchService;

    @Autowired
    private SessionService sessionService;

    @Autowired
    private ReviewSiteService reviewSiteService;

    @Autowired
    private AnswerService answerService;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * 검색결과 화면
     *
     * @Mehtod Name : search0101
     * @return
     * @throws JsonProcessingException
     */
    @RequestMapping(value = "/search/search0101", method = RequestMethod.GET)
    public String search0101View(@ModelAttribute final SearchApiRequestEntity entity, final Model model, @RequestParam(value = "debug", required = false) String isDebug) {

        String requestData = "";

        try {

            final String memberIdSq = sessionService.getAttribute("memberIdSq");
            String uuid = "";
            if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
                uuid = sessionService.getAttribute("uuid");
            }

            /**
             * 17.08.21 설문 유무 return
             */

            String questionYn = "N";
            final AnswerEntity answerEntity = new AnswerEntity();
            answerEntity.setLoginIDInSession(memberIdSq);
            answerEntity.setUuid(uuid);
            if (answerService.getAnswerCnt(answerEntity) > 0) {
                questionYn = "Y";
            }
            /**
             * 17.08.21 HCC인증 유무 return
             */
            final String hccAuthYn = sessionService.getAttribute("hccAuthYN");
            final PersonalTypeEntity personalTypeEntity = searchService.getPersonalType();
            final String personalType = personalTypeEntity.getPersonalTyp();

            model.addAttribute("questionYn", questionYn);
            model.addAttribute("hccAuthYn", hccAuthYn);
            model.addAttribute("memberIdSq", memberIdSq);
            model.addAttribute("uuid", sessionService.getAttribute("uuid"));
            model.addAttribute("personalType", personalType);

            if (entity.getSearchKind() == null) {
                entity.setSearchKind("1");
            }

            final List<String> fltgrpCdList = new ArrayList<String>();
            fltgrpCdList.add("gender");
            fltgrpCdList.add("style");

            final Map<String, Object> filterMap = searchService.filterInfo(fltgrpCdList);
            final String filterData = objectMapper.writeValueAsString(filterMap);
            model.addAttribute("filterDataJson", filterData.replaceAll("\"", "\\\""));

            // requestData
            requestData = objectMapper.writeValueAsString(entity);

            final String query = entity.getQuery();
            final String queryList = objectMapper.writeValueAsString(Arrays.asList(query.split(" ")));
            model.addAttribute("queryList", queryList);
            model.addAttribute("srchEntity", entity);
            model.addAttribute("userId", sessionService.getAttribute("userId"));
            model.addAttribute("SearchApiRequestEntity", new SearchApiRequestEntity());
            model.addAttribute("requestData", requestData.replaceAll("\"", "\\\""));

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            model.addAttribute("errorMsg", e.getMessage());
        } finally {
            model.addAttribute("srchEntity", entity);
            model.addAttribute("userId", sessionService.getAttribute("userId"));
            model.addAttribute("queryList", "");
            model.addAttribute("SearchApiRequestEntity", new SearchApiRequestEntity());
            model.addAttribute("requestData", "");
        }

        String debug = Config.getCommon().getString("DEBUG");
        debug = StringUtils.defaultString(debug, "FALSE");
        isDebug = StringUtils.defaultString(isDebug, "N");

        if ("TRUE".equals(debug) || isDebug.equals("Y")) {
            // return "search/search0101?debug=Y";
            entity.setDebug("Y");
        } else {
            // return "search/search0101";
            entity.setDebug("N");
        }
        return "search/search0101";
    }

    /**
     * 인기있는 검색결과 조회한다.
     *
     * @Mehtod Name : search0101
     * @param entity
     * @param model
     * @return
     */
    @RequestMapping(value = "/search/search0101", method = RequestMethod.POST)
    public ResponseEntity search0101(@ModelAttribute final SearchApiRequestEntity entity, final Model model) {
        entity.setQuery(HtmlUtils.htmlUnescape(entity.getQuery()));
        RestRespEntity restRespEntity = new RestRespEntity();
        try {
            /** 2. validate check */
            // if (EntityValidator.isValid(entity)) {
            // logger.warn("Validate error!!!!!");
            // return CommonUtil.response(ResultCode.C1001, restRespEntity);
            // }
            if (!termCheck(entity)) {
                restRespEntity = searchPopularService.processSearch0101(entity);
            }
            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), restRespEntity.getResultData());

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }

    /**
     * 인기있는 검색결과 조회한다.
     *
     * @Mehtod Name : search0101
     * @param entity
     * @param model
     * @return
     */
    @RequestMapping(value = "/search/search0101Filter", method = RequestMethod.POST)
    public ResponseEntity searchFilter0101(@ModelAttribute final SearchApiRequestEntity entity, final Model model) {
        entity.setQuery(HtmlUtils.htmlUnescape(entity.getQuery()));
        RestRespEntity restRespEntity = new RestRespEntity();
        try {
            /** 2. validate check */
            // if (EntityValidator.isValid(entity)) {
            // logger.warn("Validate error!!!!!");
            // return CommonUtil.response(ResultCode.C1001, restRespEntity);
            // }
            restRespEntity = searchPopularService.processSearch0101Filter(entity);
            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), restRespEntity.getResultData());

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }

    /**
     * 인기있는 상세 조회한다.
     *
     * @Mehtod Name : search0102
     * @param entity
     * @param model
     * @return
     */
    @RequestMapping(value = "/search/search0102", method = RequestMethod.POST)
    public ResponseEntity search0102(@ModelAttribute final SearchApiDetailRequestEntity entity, final Model model) {
        RestRespEntity restRespEntity = new RestRespEntity();
        try {
            /** 2. validate check */
            if (EntityValidator.isValid(entity)) {
                logger.warn("Validate error!!!!!");
                return CommonUtil.response(ResultCode.C1001, restRespEntity);
            }
            restRespEntity = searchPopularService.processSearch0102(entity);

            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), restRespEntity.getResultData());

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }

    /**
     * 상세화면에서 검색결과 화면으로 이동시 좋아요,북마크 정보를 가져온다.
     *
     * @Mehtod Name : detailBackInfo
     * @param entity
     * @param model
     * @return
     */
    @RequestMapping(value = "/search/detailBackInfo", method = RequestMethod.POST)
    public ResponseEntity detailBackInfo(@ModelAttribute final LikeEntity entity, final Model model) {

        RestRespEntity restRespEntity = new RestRespEntity();
        try {
            /** 2. validate check */
            if (EntityValidator.isValid(entity)) {
                logger.warn("Validate error!!!!!");
                return CommonUtil.response(ResultCode.C1001, restRespEntity);
            }

            restRespEntity = searchService.detailBackInfo(entity);

            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), restRespEntity.getResultData());

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }

    /**
     * 인기있는 상세 조회한다.
     *
     * @Mehtod Name : search0102
     * @param entity
     * @param model
     * @return
     */
    @RequestMapping(value = "/search/search0102", method = RequestMethod.GET)
    public String search0102View(@ModelAttribute final SearchApiDetailRequestEntity entity, final Model model, @RequestParam(value = "debug", required = false) String isDebug) {
        entity.setQuery(HtmlUtils.htmlUnescape(entity.getQuery()));
        final ReviewSiteEntity reviewEntity = new ReviewSiteEntity();
        reviewEntity.setSiteKey(entity.getSiteId());
        reviewEntity.setMemberIdSq(sessionService.getAttribute("memberIdSq"));

        final Map<String, Object> result = new HashMap<String, Object>();

        result.put("reviewCnt", reviewSiteService.getCount(reviewEntity));
        result.put("reviewGrade", reviewSiteService.getGrade(reviewEntity));
        String reviewListJson;
        try {
            reviewEntity.setPageSize(3);
            final List<ReviewSiteEntity> list = reviewSiteService.getList(reviewEntity);

            for (int i = 0; i < list.size(); i++) {
                final ReviewSiteEntity revEntity = list.get(i);
                if (list.get(i).getMemberIdSq().equals(sessionService.getAttribute("memberIdSq"))) {
                    revEntity.setIsMine("Y");
                } else {
                    revEntity.setIsMine("N");
                }
            }

            reviewListJson = objectMapper.writeValueAsString(list);
            result.put("reviewList", reviewListJson.replaceAll("\"", "\\\""));

            final RestRespEntity restRespEntity = searchPopularService.processSearch0102(entity);
            result.put("detail", restRespEntity.getResultData());

        } catch (final JsonProcessingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }

        model.addAttribute("chkLoginUser", Constants.NO_MEMBER_ID_SQ);
        model.addAttribute("uuid", uuid);
        model.addAttribute("memberIdSq", memberIdSq);
        model.addAllAttributes(result);
        model.addAttribute("entity", entity);

        String debug = Config.getCommon().getString("DEBUG");
        debug = StringUtils.defaultString(debug, "FALSE");
        isDebug = StringUtils.defaultString(isDebug, "N");
        if ("TRUE".equals(debug) || isDebug.equals("Y")) {
            return "search/search0102_debug";
        } else {
            return "search/search0102";
        }
    }

    /**
     * 상세 카테고리 더 보기 조회한다.
     *
     * @Mehtod Name : search0103
     * @param entity
     * @param model
     * @return
     */
    @RequestMapping(value = "/search/detail/category", method = RequestMethod.POST)
    public ResponseEntity searchDetailCategory(@ModelAttribute final SearchApiDetailCategoryRequestEntity entity, final Model model) {

        RestRespEntity restRespEntity = new RestRespEntity();
        try {
            /** 2. validate check */
            // if (EntityValidator.isValid(entity)) {
            // logger.warn("Validate error!!!!!");
            // return CommonUtil.response(ResultCode.C1001, restRespEntity);
            // }

            if ("1".equals(entity.getSearchKind())) {// 인기있
                restRespEntity = searchPopularService.searchDetailCategory(entity);
            } else if ("2".equals(entity.getSearchKind())) {// 요즘뜨
                restRespEntity = searchNewPopularService.searchDetailCategory(entity);
            } else if ("3".equals(entity.getSearchKind())) {// 내게맞는

                final PersonalTypeEntity personalTypeEntity = searchService.getPersonalType();
                final String personalType = personalTypeEntity.getPersonalTyp();

                if (personalType.equals(Constants.PERSONAL_TYPE_BAS_1)) {// 기본형 1

                } else if (personalType.equals(Constants.PERSONAL_TYPE_BAS_2)) {// 기본형 2
                    restRespEntity = searchQuestionService.searchDetailCategory(entity);
                } else if (personalType.equals(Constants.PERSONAL_TYPE_BAS_3)) {// 기본형 3
                    restRespEntity = searchLoggedService.searchDetailCategory(entity);
                } else if (personalType.equals(Constants.PERSONAL_TYPE_MEM_1)) {// 회원형 1
                    restRespEntity = searchNewPopularService.searchDetailCategory(entity);
                } else if (personalType.equals(Constants.PERSONAL_TYPE_MEM_2)) {// 회원형 2
                    restRespEntity = searchNewPopularService.searchDetailCategory(entity);
                }

            }

            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), restRespEntity.getResultData());

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }

    /**
     * 요즘뜨는 검색결과 조회한다.
     *
     * @Mehtod Name : search0101
     * @param entity
     * @param model
     * @return
     */
    @RequestMapping(value = "/search/search0201", method = RequestMethod.POST)
    public ResponseEntity search0201(@ModelAttribute final SearchApiRequestEntity entity, final Model model) {

        RestRespEntity restRespEntity = new RestRespEntity();
        try {
            /** 2. validate check */
            if (EntityValidator.isValid(entity)) {
                logger.warn("Validate error!!!!!");
                return CommonUtil.response(ResultCode.C1001, restRespEntity);
            }

            final String duration = entity.getDuration();
            if (StringUtils.isBlank(duration)) {
                entity.setDuration("3");
            }
            final String region = entity.getRegion();
            if (StringUtils.isBlank(region)) {
                entity.setRegion("domestic");
            }

            if (!termCheck(entity)) {
                restRespEntity = searchNewPopularService.processSearch0201(entity);
            }

            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), restRespEntity.getResultData());

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }

    @RequestMapping(value = "/search/search0201Filter", method = RequestMethod.POST)
    public ResponseEntity search0201Filter(@ModelAttribute final SearchApiRequestEntity entity, final Model model) {

        RestRespEntity restRespEntity = new RestRespEntity();
        try {
            /** 2. validate check */
            if (EntityValidator.isValid(entity)) {
                logger.warn("Validate error!!!!!");
                return CommonUtil.response(ResultCode.C1001, restRespEntity);
            }

            final String duration = entity.getDuration();
            if (StringUtils.isBlank(duration)) {
                entity.setDuration("3");
            }
            final String region = entity.getRegion();
            if (StringUtils.isBlank(region)) {
                entity.setRegion("domestic");
            }

            restRespEntity = searchNewPopularService.processSearch0201Filter(entity);

            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), restRespEntity.getResultData());

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }

    /**
     * 내게 맞게 검색결과 조회한다.
     *
     * @Mehtod Name : search0101
     * @param entity
     * @param model
     * @return
     */
    @RequestMapping(value = "/search/search0301", method = RequestMethod.POST)
    public ResponseEntity search0301(@ModelAttribute final SearchApiRequestEntity entity, final Model model) {

        RestRespEntity restRespEntity = new RestRespEntity();
        try {

            final PersonalTypeEntity personalTypeEntity = searchService.getPersonalType();
            final String personalType = personalTypeEntity.getPersonalTyp();

            entity.setPersonalType(personalType);

            if (!termCheck(entity)) {
                if (personalType.equals(Constants.PERSONAL_TYPE_BAS_1)) {// 기본형 1

                    entity.setHccAuthYn("N");
                    entity.setQuestionYn("N");
                    restRespEntity.setResultData(personalTypeEntity.getLogType());

                } else if (personalType.equals(Constants.PERSONAL_TYPE_BAS_2)) {// 기본형 2
                    entity.setHccAuthYn("N");
                    entity.setQuestionYn("Y");
                    entity.setTags(searchService.getSurveyTags(entity, restRespEntity));
                    restRespEntity = searchQuestionService.processSearch0301Question(entity);
                } else if (personalType.equals(Constants.PERSONAL_TYPE_BAS_3)) {// 기본형 3
                    entity.setSiteKeys(personalTypeEntity.getLogType().getSiteKeys());// 개인화이용로그패턴로그정보 사이트
                    restRespEntity = searchLoggedService.processSearch0301Logged(entity);
                    entity.setHccAuthYn("N");
                    entity.setQuestionYn("N");

                } else if (personalType.equals(Constants.PERSONAL_TYPE_MEM_1)) {// 회원형 1
                    entity.setHccAuthYn("Y");
                    entity.setQuestionYn("Y");
                    final String customerNo = sessionService.getAttribute("customerNo");
                    entity.setNickname(customerNo);
                    restRespEntity = searchPersonalService.processSearch0301(entity);
                } else if (personalType.equals(Constants.PERSONAL_TYPE_MEM_2)) {// 회원형 2
                    entity.setHccAuthYn("Y");
                    entity.setQuestionYn("N");
                    final String customerNo = sessionService.getAttribute("customerNo");
                    entity.setNickname(customerNo);
                    restRespEntity = searchPersonalService.processSearch0301(entity);
                }
            }
            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), restRespEntity.getResultData());
        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }

    @RequestMapping(value = "/search/search0301Filter", method = RequestMethod.POST)
    public ResponseEntity search0301Filter(@ModelAttribute final SearchApiRequestEntity entity, final Model model) {

        RestRespEntity restRespEntity = new RestRespEntity();
        try {
            /** 2. validate check */
            if (EntityValidator.isValid(entity)) {
                logger.warn("Validate error!!!!!");
                return CommonUtil.response(ResultCode.C1001, restRespEntity);
            }

            final PersonalTypeEntity personalTypeEntity = searchService.getPersonalType();
            final String personalType = personalTypeEntity.getPersonalTyp();

            if (personalType.equals(Constants.PERSONAL_TYPE_BAS_2)) {// 기본형 2
                entity.setTags(searchService.getSurveyTags(entity, restRespEntity));
                restRespEntity = searchQuestionService.processSearch0301QuestionFilter(entity);

            } else if (personalType.equals(Constants.PERSONAL_TYPE_BAS_3)) {// 기본형 3
                entity.setSiteKeys(personalTypeEntity.getLogType().getSiteKeys());// 개인화이용로그패턴로그정보 사이트
                restRespEntity = searchLoggedService.processSearch0301LoggedFilter(entity);

            } else if (personalType.equals(Constants.PERSONAL_TYPE_MEM_1)) {// 회원형 1
                final String customerNo = sessionService.getAttribute("customerNo");
                entity.setNickname(customerNo);
                restRespEntity = searchPersonalService.processSearch0301Filter(entity);
            } else if (personalType.equals(Constants.PERSONAL_TYPE_MEM_2)) {// 회원형 2
                final String customerNo = sessionService.getAttribute("customerNo");
                entity.setNickname(customerNo);
                restRespEntity = searchPersonalService.processSearch0301Filter(entity);
            }
            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), restRespEntity.getResultData());

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }

    /**
     * 내게 맞게 검색결과 조회한다.
     *
     * @Mehtod Name : search0101
     * @param entity
     * @param model
     * @return
     */
    @RequestMapping(value = "/search/autocomplete")
    public ResponseEntity autocomplete(@ModelAttribute final SearchAutocompleteRequestEntity entity, final Model model) {

        RestRespEntity restRespEntity = new RestRespEntity();
        try {
            /** 2. validate check */
            // if (EntityValidator.isValid(entity)) {
            // logger.warn("Validate error!!!!!");
            // return CommonUtil.response(ResultCode.C1001, restRespEntity);
            // }
            restRespEntity = searchService.autocomplete(entity);

            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), restRespEntity.getResultData());

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }

    /**
     * 금지어 체크
     *
     * @return
     */
    private boolean termCheck(final SearchApiRequestEntity entity) {
        final Integer flag = searchService.chkTerm(entity);
        if (flag != null && flag > 0) {
            return true;
        }
        return false;
    }
}
