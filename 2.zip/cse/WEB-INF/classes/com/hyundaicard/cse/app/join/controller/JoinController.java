package com.hyundaicard.cse.app.join.controller;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hyundaicard.cse.app.join.service.JoinService;
import com.hyundaicard.cse.app.login.entity.UserEntity;
import com.hyundaicard.cse.common.constants.SessionConstants;
import com.hyundaicard.cse.common.controller.CseAppController;
import com.hyundaicard.cse.common.exception.BizException;
import com.hyundaicard.cse.common.view.Request;

/**
 * 회원가입 (아이디 입력)
 *
 */

@Controller
public class JoinController extends CseAppController {

    private static final Logger logger = LoggerFactory.getLogger(JoinController.class);

    @Autowired
    private JoinService joinService;

    /**
     * 회원가입할 닉네임 체크 (닉네임 입력)
     */
    @RequestMapping(value = "/api/join/join0101", method = RequestMethod.POST)
    public ModelAndView join0101(final HttpServletRequest httpServletRequest,
            final HttpServletResponse httpServletResponse, final Request request) throws Exception {
        logger.info(">>>>join0101");

        final JSONObject requestJson = request.getRequestBodyJson();
        final JSONObject responseJson = new JSONObject();

        final String userId = requestJson.optString("userId", "");

        // 닉네임 유효성 체크
        joinService.validateUserId(userId);

        // 닉네임 중복체크
        final String usePossibleYN = joinService.checkUserIdDuplicate(userId);

        if (usePossibleYN.equals("N")) {
            // 중복된 닉네임입니다.
            throw new BizException(messageSource, "JOIN0001", Locale.getDefault());
        }

        responseJson.put("usePossibleYN", usePossibleYN);

        logger.info("<<<<join0101");

        return createResponseModelAndView(httpServletRequest, httpServletResponse, request, responseJson);
    }

    /**
     * 회원가입 (아이디 등록)
     */
    @RequestMapping(value = "/api/join/join0102", method = RequestMethod.POST)
    public ModelAndView join0102(final HttpServletRequest httpServletRequest,
            final HttpServletResponse httpServletResponse, final Request request) throws Exception {
        logger.info(">>>>join0102");

        final JSONObject requestJson = request.getRequestBodyJson();
        final JSONObject responseJson = new JSONObject();

        final String userId = requestJson.optString("userId", "");
        final String customerNo = StringUtils
                .defaultIfEmpty((String) httpServletRequest.getSession().getAttribute("authCustomerNo"), "");
        final String uuid = requestJson.optString("uuid", "");
        final String osType = (String) httpServletRequest.getSession().getAttribute(SessionConstants.OS_TYPE);
        final String hccAuthYN = StringUtils
                .defaultIfEmpty((String) httpServletRequest.getSession().getAttribute("hccAuthYN"), "N");
        final String marketingAgreeYN = StringUtils
                .defaultIfEmpty((String) httpServletRequest.getSession().getAttribute("marketingAgreeYN"), "");
        final String joinChannel = requestJson.optString("joinChannel", "HCC");
        final String snsUid = requestJson.optString("snsUid", "");

        final UserEntity userEntity = new UserEntity();
        userEntity.setUserId(userId);
        userEntity.setUuid(uuid);
        userEntity.setOsType(osType);
        userEntity.setHccAuthYN(hccAuthYN);
        userEntity.setJoinChannel(joinChannel);
        userEntity.setCustomerNo(customerNo);
        userEntity.setSnsUid(snsUid);
        userEntity.setMarketingAgreeYN(marketingAgreeYN);

        /**
         * HCC 인증을 하고 회원가입을 요청했을 경우 customerNo를 이용하여 기존에 가입되어있는 계정이 있는지 조회 후 조회된 항목이 있으면 해당 계정의 customerNo 삭제
         */

        if (hccAuthYN.equals("Y")) {
            joinService.updateCustomerNoDefault(userEntity);
        }

        // 회원 등록
        joinService.registUserId(userEntity);

        // 등록된 회원 memberIdSq 조회
        final String memberIdSq = joinService.selectMemberIdSq(userEntity);

        if (memberIdSq != null && memberIdSq.length() > 0) {
            userEntity.setMemberIdSq(memberIdSq);
            // 비회원 상태로 한 좋아요/북마크/리뷰/설문 정보를 가입한 ID에 맵핑
            joinService.migrationPersonalInfo(userEntity);
        }

        // 회원 등록에 사용한 고객번호 세션에서 삭제
        httpServletRequest.getSession().setAttribute("authCustomerNo", null);
        httpServletRequest.getSession().setAttribute("hccAuthYN", null);
        httpServletRequest.getSession().setAttribute("marketingAgreeYN", null);

        logger.info("<<<<join0102");

        return createResponseModelAndView(httpServletRequest, httpServletResponse, request, responseJson);
    }

}
