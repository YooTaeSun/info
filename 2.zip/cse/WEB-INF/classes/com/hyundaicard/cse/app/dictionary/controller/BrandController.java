package com.hyundaicard.cse.app.dictionary.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hyundaicard.cse.app.dictionary.entity.BrandEntity;
import com.hyundaicard.cse.app.dictionary.service.BrandService;
import com.hyundaicard.cse.common.controller.CseAppController;
import com.hyundaicard.cse.common.entity.RestRespEntity;
import com.hyundaicard.cse.common.util.CommonUtil;

@Controller
public class BrandController extends CseAppController {

    @Autowired
    private BrandService brandService;

    @RequestMapping(value = "/dictionary/brand", method = RequestMethod.POST)
    public ResponseEntity getBrandList(@ModelAttribute final BrandEntity entity) {
        final RestRespEntity restRespEntity = new RestRespEntity();

        final String srchVal = entity.getSrchVal();
        entity.setSrchVal('%' + srchVal + '%');

        final List<BrandEntity> list = brandService.getBrandList(entity);

        return CommonUtil.response(restRespEntity, list);
    }

}
