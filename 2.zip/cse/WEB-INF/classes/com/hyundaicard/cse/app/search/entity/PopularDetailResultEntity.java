package com.hyundaicard.cse.app.search.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 인기있는 Site Detail Info
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public class PopularDetailResultEntity {

    private Data data;

    public Data getData() {
        return data;
    }

    public void setData(final Data data) {
        this.data = data;
    }

    public static class Data {
        private PopularSiteResultEntity row;
        private String query;

        private QkaResultEntity qka;

        public PopularSiteResultEntity getRow() {
            return row;
        }

        public void setRow(final PopularSiteResultEntity row) {
            this.row = row;
        }

        public String getQuery() {
            return query;
        }

        public void setQuery(final String query) {
            this.query = query;
        }

        public QkaResultEntity getQka() {
            return qka;
        }

        public void setQka(final QkaResultEntity qka) {
            this.qka = qka;
        }
    }
}
