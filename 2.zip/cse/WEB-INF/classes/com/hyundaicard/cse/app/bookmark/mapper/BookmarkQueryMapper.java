package com.hyundaicard.cse.app.bookmark.mapper;

import java.util.List;

import com.hyundaicard.cse.app.bookmark.entity.BookmarkQueryEntity;

/**
 * bookmark query Mapper
 * 
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public interface BookmarkQueryMapper {

    /**
     * 조회
     * 
     * @Mehtod Name : get
     * @param entity
     * @return
     */
    public BookmarkQueryEntity get(BookmarkQueryEntity entity);


    /**
     * 전체 리스트
     * 
     * @Mehtod Name : getAllList
     * @param entity
     * @return
     */
    public List<BookmarkQueryEntity> getAllList(BookmarkQueryEntity entity);


    /**
     * 카운트
     * 
     * @Mehtod Name : count
     * @param entity
     * @return
     */
    public int count(BookmarkQueryEntity entity);

    /**
     * 등록
     * 
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public void insert(BookmarkQueryEntity entity);

    /**
     * 수정
     * 
     * @Mehtod Name : update
     * @param entity
     * @return
     */
    public void update(BookmarkQueryEntity entity);

    /**
     * 삭제
     * 
     * @Mehtod Name : delete
     * @param entity
     * @return
     */
    public void delete(BookmarkQueryEntity entity);
}
