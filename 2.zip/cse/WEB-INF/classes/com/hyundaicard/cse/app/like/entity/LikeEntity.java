package com.hyundaicard.cse.app.like.entity;

/**
 * like Entity
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public class LikeEntity {
    private String likeSiteCatSq; // 좋아요 사이트 순번
    private String memberIdSq; // 회원아이디 일련번호
    private String uuid; // 비회원 단말 식별값
    private String siteKey; // 사이트키
    private String catKey; // 카테고리키
    private String siteKeys;

    private String queryKeyword; // log custom
    private String queryTypeCd; // log custom
    private String pageInfo; // log custom
    private String itemCount; // log custom
    private String itemPos; // log custom
    private String clickItemType; // log custom
    private String isLogSave = "Y"; // log custom

    private String catKeys;

    public String getLikeSiteCatSq() {
        return likeSiteCatSq;
    }

    public void setLikeSiteCatSq(final String likeSiteCatSq) {
        this.likeSiteCatSq = likeSiteCatSq;
    }

    public String getMemberIdSq() {
        return memberIdSq;
    }

    public void setMemberIdSq(final String memberIdSq) {
        this.memberIdSq = memberIdSq;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    public String getSiteKey() {
        return siteKey;
    }

    public void setSiteKey(final String siteKey) {
        this.siteKey = siteKey;
    }

    public String getCatKey() {
        return catKey;
    }

    public void setCatKey(final String catKey) {
        this.catKey = catKey;
    }

    public String getSiteKeys() {
        return siteKeys;
    }

    public void setSiteKeys(final String siteKeys) {
        this.siteKeys = siteKeys;
    }

    public String getCatKeys() {
        return catKeys;
    }

    public void setCatKeys(final String catKeys) {
        this.catKeys = catKeys;
    }

    public String getQueryKeyword() {
        return queryKeyword;
    }

    public void setQueryKeyword(final String queryKeyword) {
        this.queryKeyword = queryKeyword;
    }

    public String getQueryTypeCd() {
        return queryTypeCd;
    }

    public void setQueryTypeCd(final String queryTypeCd) {
        this.queryTypeCd = queryTypeCd;
    }

    public String getPageInfo() {
        return pageInfo;
    }

    public void setPageInfo(final String pageInfo) {
        this.pageInfo = pageInfo;
    }

    public String getItemCount() {
        return itemCount;
    }

    public void setItemCount(final String itemCount) {
        this.itemCount = itemCount;
    }

    public String getItemPos() {
        return itemPos;
    }

    public void setItemPos(final String itemPos) {
        this.itemPos = itemPos;
    }

    public String getClickItemType() {
        return clickItemType;
    }

    public void setClickItemType(final String clickItemType) {
        this.clickItemType = clickItemType;
    }

    public String getIsLogSave() {
        return isLogSave;
    }

    public void setIsLogSave(final String isLogSave) {
        this.isLogSave = isLogSave;
    }

}
