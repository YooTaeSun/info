package com.hyundaicard.cse.app.visit.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.visit.entity.VisitSiteEntity;
import com.hyundaicard.cse.app.visit.mapper.VisitSiteMapper;

/**
 * visit site Service
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Service
public class VisitSiteService {

    /** Logger */
    // private static final Logger logger = LoggerFactory.getLogger(VisitSiteService.class);

    @Autowired
    private VisitSiteMapper mapper;

    // /**
    // * 상세
    // * @Mehtod Name : get
    // * @param entity
    // * @return
    // */
    // public VisitSiteEntity get(VisitSiteEntity entity) {
    // return mapper.get(entity);
    // }
    //
    // /**
    // * 리스트
    // * @Mehtod Name : getList
    // * @param entity
    // * @return
    // */
    // public List<VisitSiteEntity> getAllList(VisitSiteEntity entity) {
    // return mapper.getAllList(entity);
    // }
    //
    // /**
    // * 전체 리스트
    // * @Mehtod Name : getAllList
    // * @param entity
    // * @return
    // */
    // public List<VisitSiteEntity> getList(VisitSiteEntity entity) {
    // return mapper.getList(entity);
    // }
    //
    // /**
    // * 갯수
    // * @Mehtod Name : getCount
    // * @param entity
    // * @return
    // */
    // public Integer getCount(VisitSiteEntity entity) {
    // return mapper.count(entity);
    // }

    /**
     * 입력
     *
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public void insert(final VisitSiteEntity entity) {
        mapper.insert(entity);
    }

    // /**
    // * 수정
    // * @Mehtod Name : insert
    // * @param entity
    // * @return
    // */
    // public void update(VisitSiteEntity entity) {
    // mapper.update(entity);
    // }
    //
    // /**
    // * 삭제
    // * @Mehtod Name : delete
    // * @param entity
    // * @return
    // */
    // public void delete(VisitSiteEntity entity) {
    // mapper.delete(entity);
    // }
}
