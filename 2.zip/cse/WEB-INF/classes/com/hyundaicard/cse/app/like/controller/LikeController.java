package com.hyundaicard.cse.app.like.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hyundaicard.cse.app.bookmark.service.SessionService;
import com.hyundaicard.cse.app.like.entity.LikeCountEntity;
import com.hyundaicard.cse.app.like.entity.LikeEntity;
import com.hyundaicard.cse.app.like.service.LikeService;
import com.hyundaicard.cse.common.code.ResultCode;
import com.hyundaicard.cse.common.entity.RestRespEntity;
import com.hyundaicard.cse.common.util.CommonUtil;
import com.hyundaicard.cse.constants.Constants;

/**
 * like Controller
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@SuppressWarnings("rawtypes")
@Controller
public class LikeController {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(LikeController.class);

    @Autowired
    private LikeService service;

    @Autowired
    private SessionService sessionService;

    /**
     * like site insert
     *
     * @Mehtod Name : insert @return ResponseEntity @throws
     */
    @RequestMapping(value = "/like/site/insert", method = RequestMethod.POST)
    public ResponseEntity insertSite(@ModelAttribute final LikeEntity entity, final Model model) {

        final RestRespEntity restRespEntity = new RestRespEntity();

        try {
            /** 2. validate check */
            // if (EntityValidator.isValid(entity)) {
            // logger.warn("Validate error!!!!!");
            // return CommonUtil.response(ResultCode.C1001, restRespEntity);
            // }
            final String memberIdSq = sessionService.getAttribute("memberIdSq");
            final String uuid = sessionService.getAttribute("uuid");
            entity.setUuid(uuid);
            entity.setMemberIdSq(memberIdSq);

            entity.setCatKey(Constants.LIKE_SITE_CTG_KET);
            final LikeCountEntity likeCountEntity = service.insert(entity);

            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), likeCountEntity);

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }

    /**
     * like category insert
     *
     * @Mehtod Name : insert @return ResponseEntity @throws
     */
    @RequestMapping(value = "/like/category/insert", method = RequestMethod.POST)
    public ResponseEntity insertCategory(@ModelAttribute final LikeEntity entity, final Model model) {

        final RestRespEntity restRespEntity = new RestRespEntity();

        try {
            /** 2. validate check */
            // if (EntityValidator.isValid(entity)) {
            // logger.warn("Validate error!!!!!");
            // return CommonUtil.response(ResultCode.C1001, restRespEntity);
            // }

            final String memberIdSq = sessionService.getAttribute("memberIdSq");
            final String uuid = sessionService.getAttribute("uuid");

            entity.setMemberIdSq(memberIdSq);
            entity.setUuid(uuid);

            final LikeCountEntity likeCountEntity = service.insert(entity);

            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), likeCountEntity);

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }

    /**
     * like delete
     *
     * @Mehtod Name : delete @return ResponseEntity @throws
     */
    @RequestMapping(value = "/like/category/delete", method = RequestMethod.POST)
    public ResponseEntity delete(@ModelAttribute final LikeEntity entity, final Model model) {

        final RestRespEntity restRespEntity = new RestRespEntity();
        try {
            /** 2. validate check */
            // if (EntityValidator.isValid(entity)) {
            // logger.warn("Validate error!!!!!");
            // return CommonUtil.response(ResultCode.C1001, restRespEntity);
            // }

            final String memberIdSq = sessionService.getAttribute("memberIdSq");
            String uuid = "";
            if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
                uuid = sessionService.getAttribute("uuid");
            }
            entity.setMemberIdSq(memberIdSq);
            entity.setUuid(uuid);

            final LikeCountEntity likeCountEntity = service.delete(entity);

            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), likeCountEntity);

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }

    /**
     * like delete
     *
     * @Mehtod Name : delete @return ResponseEntity @throws
     */
    @RequestMapping(value = "/like/site/delete", method = RequestMethod.POST)
    public ResponseEntity siteDelete(@ModelAttribute final LikeEntity entity, final Model model) {

        final RestRespEntity restRespEntity = new RestRespEntity();
        try {

            final String memberIdSq = sessionService.getAttribute("memberIdSq");
            String uuid = "";
            if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
                uuid = sessionService.getAttribute("uuid");
            }
            entity.setMemberIdSq(memberIdSq);
            entity.setUuid(uuid);

            entity.setCatKey(Constants.LIKE_SITE_CTG_KET);
            final LikeCountEntity likeCountEntity = service.delete(entity);

            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), likeCountEntity);

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }
}