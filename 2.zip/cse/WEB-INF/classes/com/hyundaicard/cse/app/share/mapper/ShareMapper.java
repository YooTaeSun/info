package com.hyundaicard.cse.app.share.mapper;

import com.hyundaicard.cse.app.share.entity.ShareEntity;

/**
 * share Mapper
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public interface ShareMapper {

    /**
     * 조회
     *
     * @Mehtod Name : get
     * @param entity
     * @return
     */
    public ShareEntity get(ShareEntity entity);

    /**
     * 등록
     *
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public void insert(ShareEntity entity);
}
