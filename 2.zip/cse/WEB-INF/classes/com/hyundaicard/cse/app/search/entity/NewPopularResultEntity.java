package com.hyundaicard.cse.app.search.entity;

import java.util.List;

/**
 * 요즘뜨는 Site List Entity
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
@SuppressWarnings("rawtypes")
public class NewPopularResultEntity {

    private Data data;

    public Data getData() {
        return data;
    }

    public void setData(final Data data) {
        this.data = data;
    }

    public static class Data {
        private String type;
        private String query;
        private List<NewPopularSiteResultEntity> rows;
        private RangeResultEntity range;

        private QkaResultEntity qka;

        private String filterType; // custom

        public String getType() {
            return type;
        }

        public void setType(final String type) {
            this.type = type;
        }

        public String getQuery() {
            return query;
        }

        public void setQuery(final String query) {
            this.query = query;
        }

        public List<NewPopularSiteResultEntity> getRows() {
            return rows;
        }

        public void setRows(final List<NewPopularSiteResultEntity> rows) {
            this.rows = rows;
        }

        public RangeResultEntity getRange() {
            return range;
        }

        public void setRange(final RangeResultEntity range) {
            this.range = range;
        }

        public QkaResultEntity getQka() {
            return qka;
        }

        public void setQka(final QkaResultEntity qka) {
            this.qka = qka;
        }

        public String getFilterType() {
            return filterType;
        }

        public void setFilterType(final String filterType) {
            this.filterType = filterType;
        }
    }
}
