package com.hyundaicard.cse.app.mypage.entity;

import com.hyundaicard.cse.common.entity.AbstractPage;

/**
 * Faq Entity
 */
public class FaqEntity extends AbstractPage {

    private String faqNo;
    private String title;
    private String content;
    private String categoryCode;
    private String registDate;
    private String updateDate;

    public String getFaqNo() {
        return faqNo;
    }

    public void setFaqNo(String faqNo) {
        this.faqNo = faqNo;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCategoryCode() {
        return categoryCode;
    }

    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }

    public String getRegistDate() {
        return registDate;
    }

    public void setRegistDate(String registDate) {
        this.registDate = registDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    @Override
    public String toString() {
        return "FaqEntity [faqNo=" + faqNo + ", title=" + title + ", content=" + content + ", categoryCode="
                + categoryCode + ", registDate=" + registDate + ", updateDate=" + updateDate + "]";
    }

}
