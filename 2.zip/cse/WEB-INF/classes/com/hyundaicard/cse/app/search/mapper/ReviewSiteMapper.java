package com.hyundaicard.cse.app.search.mapper;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.hyundaicard.cse.app.search.entity.ReviewSiteEntity;

/**
 * search ReviewSiteMapper Mapper
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public interface ReviewSiteMapper {

    /**
     * 조회
     *
     * @Mehtod Name : get
     * @param entity
     * @return
     * @throws DataAccessException
     */
    public ReviewSiteEntity get(ReviewSiteEntity entity) throws DataAccessException;

    /**
     * 목록조회
     *
     * @Mehtod Name : getList
     * @param entity
     * @return
     * @throws DataAccessException
     */
    public List<ReviewSiteEntity> getList(ReviewSiteEntity entity) throws DataAccessException;

    /**
     * 전체 갯수
     *
     * @param entity
     * @return
     * @throws DataAccessException
     */
    public Integer getCount(ReviewSiteEntity entity) throws DataAccessException;

    /**
     * 평점조회
     *
     * @Method Name : getGrade
     * @param entity
     * @return
     * @throws DataAccessException
     */
    public float getGrade(ReviewSiteEntity entity) throws DataAccessException;

    /**
     * 등록
     *
     * @Mehtod Name : insert
     * @param Entity
     * @return
     */
    public int insert(ReviewSiteEntity Entity) throws DataAccessException;

    /**
     * 수정
     *
     * @Mehtod Name : update
     * @param Entity
     * @return
     */
    public int update(ReviewSiteEntity Entity) throws DataAccessException;

    /**
     * 삭제
     *
     * @Mehtod Name : delete
     * @param Entity
     * @return
     */
    public int delete(ReviewSiteEntity Entity) throws DataAccessException;
}
