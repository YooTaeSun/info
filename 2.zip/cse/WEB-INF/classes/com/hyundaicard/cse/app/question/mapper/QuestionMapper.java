package com.hyundaicard.cse.app.question.mapper;

import java.util.List;

import com.hyundaicard.cse.app.question.entity.ChoiceEntity;
import com.hyundaicard.cse.app.question.entity.QuestionEntity;

/**
 * Question Mapper
 */
public interface QuestionMapper {

    public List<QuestionEntity> getQueList();

    public List<ChoiceEntity> getChoiceList(QuestionEntity entity);
}
