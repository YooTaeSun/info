package com.hyundaicard.cse.app.dictionary.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.dictionary.entity.BrandEntity;
import com.hyundaicard.cse.app.dictionary.mapper.BrandMapper;

/**
 * Terms Service
 */
@Service
public class BrandService {

    /** Mapper */
    @Autowired
    private BrandMapper brandMapper;

    public List<BrandEntity> getBrandList(final BrandEntity entity) {

        return brandMapper.getBrandList(entity);
    }

}
