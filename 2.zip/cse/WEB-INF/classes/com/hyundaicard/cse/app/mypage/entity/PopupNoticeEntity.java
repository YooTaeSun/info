package com.hyundaicard.cse.app.mypage.entity;

public class PopupNoticeEntity extends NoticeEntity {

    private String popupMainImgAnd;
    private String popupMainImgIos;
    private String popupLinkUrl;

    public String getPopupMainImgAnd() {
        return popupMainImgAnd;
    }

    public void setPopupMainImgAnd(final String popupMainImgAnd) {
        this.popupMainImgAnd = popupMainImgAnd;
    }

    public String getPopupMainImgIos() {
        return popupMainImgIos;
    }

    public void setPopupMainImgIos(final String popupMainImgIos) {
        this.popupMainImgIos = popupMainImgIos;
    }

    public String getPopupLinkUrl() {
        return popupLinkUrl;
    }

    public void setPopupLinkUrl(final String popupLinkUrl) {
        this.popupLinkUrl = popupLinkUrl;
    }

}
