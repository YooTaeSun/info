package com.hyundaicard.cse.app.filter.mapper;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.hyundaicard.cse.app.filter.entity.FilterEntity;

/**
 * search Filter Mapper
 * 
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public interface FilterMapper {

    /**
     * 조회
     * 
     * @Mehtod Name : get
     * @param entity
     * @return
     */
    public FilterEntity get(FilterEntity entity) throws DataAccessException;

    /**
     * 리스트
     * 
     * @Mehtod Name : getList
     * @param entity
     * @return
     */
    public List<FilterEntity> getList(FilterEntity entity) throws DataAccessException;

    /**
     * 전체 리스트
     * 
     * @Mehtod Name : getAllList
     * @param entity
     * @return
     */
    public List<FilterEntity> getAllList(FilterEntity entity) throws DataAccessException;

}
