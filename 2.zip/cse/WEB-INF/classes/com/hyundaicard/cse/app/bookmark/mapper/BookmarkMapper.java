package com.hyundaicard.cse.app.bookmark.mapper;

import java.util.List;

import com.hyundaicard.cse.app.bookmark.entity.BookmarkEntity;
import com.hyundaicard.cse.app.bookmark.entity.BookmarkSiteEntity;

/**
 * bookmark Mapper
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public interface BookmarkMapper {

    /**
     * 조회
     *
     * @Mehtod Name : get
     * @param entity
     * @return
     */
    public BookmarkEntity get(BookmarkEntity entity);

    public BookmarkEntity getFirst(BookmarkEntity entity);

    /**
     * 전체 리스트
     *
     * @Mehtod Name : getAllList
     * @param entity
     * @return
     */
    public List<BookmarkEntity> getAllList(BookmarkEntity entity);

    public List<BookmarkEntity> getAllListForMap(BookmarkEntity entity);

    public List<BookmarkSiteEntity> getSiteAllListForMap(BookmarkEntity entity);

    public List<BookmarkSiteEntity> getSiteAllList(BookmarkEntity entity);

    public List<BookmarkEntity> getSiteList(BookmarkEntity entity);

    /**
     * 카운트
     *
     * @Mehtod Name : count
     * @param entity
     * @return
     */
    public int count(BookmarkEntity entity);

    /**
     * 등록
     *
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public void insert(BookmarkEntity entity);

    /**
     * 수정
     *
     * @Mehtod Name : update
     * @param entity
     * @return
     */
    public void update(BookmarkEntity entity);

    /**
     * 삭제
     *
     * @Mehtod Name : delte
     * @param entity
     * @return
     */
    public void delete(BookmarkEntity entity);
}
