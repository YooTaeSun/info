package com.hyundaicard.cse.app.log.mapper;

import com.hyundaicard.cse.app.log.entity.SearchQueryLogEntity;

/**
 * search query Mapper
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public interface SearchQueryLogMapper {

    /**
     * 등록
     *
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public void insert(SearchQueryLogEntity entity);
}
