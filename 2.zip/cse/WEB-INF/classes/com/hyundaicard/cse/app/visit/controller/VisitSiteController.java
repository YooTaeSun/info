package com.hyundaicard.cse.app.visit.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hyundaicard.cse.app.bookmark.service.SessionService;
import com.hyundaicard.cse.app.visit.entity.VisitSiteEntity;
import com.hyundaicard.cse.app.visit.service.VisitSiteService;
import com.hyundaicard.cse.common.code.ResultCode;
import com.hyundaicard.cse.common.entity.RestRespEntity;
import com.hyundaicard.cse.common.util.CommonUtil;

/**
 * visit site Controller
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Controller
@SuppressWarnings("rawtypes")
public class VisitSiteController {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(VisitSiteController.class);

    @Autowired
    private VisitSiteService service;

    @Autowired
    private SessionService sessionService;

    /**
     * favorite insert
     *
     * @Mehtod Name : insert @return ResponseEntity @throws
     */
    @RequestMapping(value = "/visitSite/insert", method = RequestMethod.POST)
    public ResponseEntity insert(@ModelAttribute final VisitSiteEntity entity, final Model model) {

        final RestRespEntity restRespEntity = new RestRespEntity();
        try {
            /** 2. validate check */
            // if (EntityValidator.isValid(entity)) {
            // logger.warn("Validate error!!!!!");
            // return CommonUtil.response(ResultCode.C1001, restRespEntity);
            // }
            final String memberIdSq = sessionService.getAttribute("memberIdSq");
            final String uuid = sessionService.getAttribute("uuid");
            entity.setUuid(uuid);
            entity.setMemberIdSq(memberIdSq);
            service.insert(entity);

            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), null);

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }
}
