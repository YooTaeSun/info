package com.hyundaicard.cse.app.bookmark.service;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.constants.Constants;

/**
 * bookmark Service
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Service
public class SessionService {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(SessionService.class);

    @Autowired
    private HttpSession httpSession;

    /**
     * 상세
     *
     * @Mehtod Name : get
     * @param entity
     * @return
     */
    public String getAttribute(final String attributName) {

        if (attributName.equals("uuid")) {
            final String uuid = (String) httpSession.getAttribute(attributName);
            if (StringUtils.isBlank(uuid)) {
                return "testUuid";
            }
            return uuid;
        } /**/else if (attributName.equals("userId")) {
            final String userId = (String) httpSession.getAttribute(attributName);
            if (StringUtils.isBlank(userId)) {
                return Constants.NO_USER_ID_SQ;
            }
            return userId;
        } else if (attributName.equals("memberIdSq")) {
            final String memberIdSq = (String) httpSession.getAttribute(attributName);
            if (StringUtils.isBlank(memberIdSq)) {
                return Constants.NO_MEMBER_ID_SQ;
            }
            return memberIdSq;
        } else if (attributName.equals("hccAuthYN")) {
            final String hccAuthYN = (String) httpSession.getAttribute(attributName);
            if (StringUtils.isBlank(hccAuthYN)) {
                return Constants.HCC_AUTH_N;
            }
            return hccAuthYN;
        } else if (attributName.equals("customerNo")) {
            final String customerNo = (String) httpSession.getAttribute(attributName);
            if (StringUtils.isBlank(customerNo)) {
                return "1";
            }
            return customerNo;
        } else if (attributName.equals("sessionId")) {
            return httpSession.getId();
        }

        return (String) httpSession.getAttribute(attributName);
    }

    /**
     *
     * @Mehtod Name : getLoginUser
     * @param
     * @return
     */
    // public TempUserEntity getLoginUser() {
    // return (TempUserEntity)httpSession.getAttribute("loginUser");
    // }

}
