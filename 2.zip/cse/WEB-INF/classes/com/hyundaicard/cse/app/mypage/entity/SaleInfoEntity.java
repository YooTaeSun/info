package com.hyundaicard.cse.app.mypage.entity;

import com.hyundaicard.cse.common.entity.AbstractPage;

/**
 * SaleInfo Entity
 */
public class SaleInfoEntity extends AbstractPage {

    private String saleSq;
    private String siteKey;
    private String saleSiteNm;
    private Integer salePercent;
    private String saleNm;
    private String saleDs;
    private String saleLandingUrl;
    private String displayStrDt;
    private String displayEndDt;

    /** 새 정보 유무 */
    private String newYn;

    private String memberIdSq;
    private String uuid;

    private String siteKeys;

    public String getSaleSq() {
        return saleSq;
    }

    public void setSaleSq(final String saleSq) {
        this.saleSq = saleSq;
    }

    public String getSiteKey() {
        return siteKey;
    }

    public void setSiteKey(final String siteKey) {
        this.siteKey = siteKey;
    }

    public String getSaleSiteNm() {
        return saleSiteNm;
    }

    public void setSaleSiteNm(final String saleSiteNm) {
        this.saleSiteNm = saleSiteNm;
    }

    public Integer getSalePercent() {
        return salePercent;
    }

    public void setSalePercent(final Integer salePercent) {
        this.salePercent = salePercent;
    }

    public String getSaleNm() {
        return saleNm;
    }

    public void setSaleNm(final String saleNm) {
        this.saleNm = saleNm;
    }

    public String getSaleDs() {
        return saleDs;
    }

    public void setSaleDs(final String saleDs) {
        this.saleDs = saleDs;
    }

    public String getSaleLandingUrl() {
        return saleLandingUrl;
    }

    public void setSaleLandingUrl(final String saleLandingUrl) {
        this.saleLandingUrl = saleLandingUrl;
    }

    public String getDisplayStrDt() {
        return displayStrDt;
    }

    public void setDisplayStrDt(final String displayStrDt) {
        this.displayStrDt = displayStrDt;
    }

    public String getDisplayEndDt() {
        return displayEndDt;
    }

    public void setDisplayEndDt(final String displayEndDt) {
        this.displayEndDt = displayEndDt;
    }

    public String getNewYn() {
        return newYn;
    }

    public void setNewYn(final String newYn) {
        this.newYn = newYn;
    }

    public String getMemberIdSq() {
        return memberIdSq;
    }

    public void setMemberIdSq(final String memberIdSq) {
        this.memberIdSq = memberIdSq;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    public String getSiteKeys() {
        return siteKeys;
    }

    public void setSiteKeys(final String siteKeys) {
        this.siteKeys = siteKeys;
    }

}
