package com.hyundaicard.cse.app.bookmark.entity;

import java.util.List;

/**
 * bookmark query Entity
 * 
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public class BookmarkQueryEntity {
    private String favSiteCatQuerySq; // 관심 사이트 검색어 순번
    private String memberIdSq; // 회원아이디 일련번호
    private String uuid; // 비회원 단말 식별값
    private String siteKey; // 사이트키
    private String catKey; // 카테고리키
    private String query; // 검색어

    private String delExcepPks; // custom
    List<String> delExcepPkList; // custom
    private String selFavSiteCatQuerySq;// custom

    public String getFavSiteCatQuerySq() {
        return favSiteCatQuerySq;
    }

    public void setFavSiteCatQuerySq(String favSiteCatQuerySq) {
        this.favSiteCatQuerySq = favSiteCatQuerySq;
    }

    public String getMemberIdSq() {
        return memberIdSq;
    }

    public void setMemberIdSq(String memberIdSq) {
        this.memberIdSq = memberIdSq;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getSiteKey() {
        return siteKey;
    }

    public void setSiteKey(String siteKey) {
        this.siteKey = siteKey;
    }

    public String getCatKey() {
        return catKey;
    }

    public void setCatKey(String catKey) {
        this.catKey = catKey;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getDelExcepPks() {
        return delExcepPks;
    }

    public void setDelExcepPks(String delExcepPks) {
        this.delExcepPks = delExcepPks;
    }

    public List<String> getDelExcepPkList() {
        return delExcepPkList;
    }

    public void setDelExcepPkList(List<String> delExcepPkList) {
        this.delExcepPkList = delExcepPkList;
    }

    public String getSelFavSiteCatQuerySq() {
        return selFavSiteCatQuerySq;
    }

    public void setSelFavSiteCatQuerySq(String selFavSiteCatQuerySq) {
        this.selFavSiteCatQuerySq = selFavSiteCatQuerySq;
    }
}
