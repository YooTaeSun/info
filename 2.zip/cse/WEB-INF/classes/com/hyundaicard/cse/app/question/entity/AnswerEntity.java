package com.hyundaicard.cse.app.question.entity;

import java.math.BigInteger;
import java.util.List;

import com.hyundaicard.cse.common.entity.AbstractPage;

public class AnswerEntity extends AbstractPage {

    private BigInteger surveyAnswerSq;

    private BigInteger surveySq;

    private String uuid;

    private List<AnswerDetailEntity> answerValueList;
    private String answerValues;

    public BigInteger getSurveyAnswerSq() {
        return surveyAnswerSq;
    }

    public void setSurveyAnswerSq(final BigInteger surveyAnswerSq) {
        this.surveyAnswerSq = surveyAnswerSq;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    public BigInteger getSurveySq() {
        return surveySq;
    }

    public void setSurveySq(final BigInteger surveySq) {
        this.surveySq = surveySq;
    }

    public List<AnswerDetailEntity> getAnswerValueList() {
        return answerValueList;
    }

    public void setAnswerValueList(final List<AnswerDetailEntity> answerValueList) {
        this.answerValueList = answerValueList;
    }

    public String getAnswerValues() {
        return answerValues;
    }

    public void setAnswerValues(final String answerValues) {
        this.answerValues = answerValues;
    }

    @Override
    public String toString() {
        return "AnswerEntity [surveyAnswerSq=" + surveyAnswerSq + ", surveySq=" + surveySq + ", uuid=" + uuid + ", answerValueList=" + answerValueList + ", answerValues=" + answerValues + "]";
    }

}
