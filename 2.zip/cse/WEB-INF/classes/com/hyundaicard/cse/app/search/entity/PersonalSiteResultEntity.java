package com.hyundaicard.cse.app.search.entity;

import java.util.List;

public class PersonalSiteResultEntity {

    private String id;
    private String site_meta_eng_nm;
    private String site_meta_korean_nm;
    private String site_meta_site_url;
    private String site_meta_landing_url;
    private String site_meta_direct_delivery;
    private String site_meta_free_delivery;
    private String site_meta_use_won_currency;
    private String site_meta_flagship;
    private String site_meta_free_delivery_description;
    private String site_meta_site_desc;
    private String site_meta_checkout_card;
    private String _categories_total_count;
    private String site_meta_promotion_info;
    private String site_meta_sex;
    private String site_meta_gender;
    private float site_matching;
    private CategorySearchResultEntity category;
    private List<CategorySearchResultEntity> categories;
    private List docs;
    private float _score;
    private String site_meta_korean_support;
    private String site_meta_country;
    private String site_meta_shop_type;
    private String site_meta_genre;

    // ------------------ custom add --------------------------
    private String cus_site_is_like;
    private String likeSiteCatSq;
    private String cus_site_cnt;
    private String cus_site_is_bookmark;

    // ------------------------------------------------------------
    public String getId() {
        return id;
    }

    public void setId(final String id) {
        this.id = id;
    }

    public String getSite_meta_eng_nm() {
        return site_meta_eng_nm;
    }

    public void setSite_meta_eng_nm(final String site_meta_eng_nm) {
        this.site_meta_eng_nm = site_meta_eng_nm;
    }

    public String getSite_meta_korean_nm() {
        return site_meta_korean_nm;
    }

    public void setSite_meta_korean_nm(final String site_meta_korean_nm) {
        this.site_meta_korean_nm = site_meta_korean_nm;
    }

    public String getSite_meta_site_url() {
        return site_meta_site_url;
    }

    public void setSite_meta_site_url(final String site_meta_site_url) {
        this.site_meta_site_url = site_meta_site_url;
    }

    public String getSite_meta_landing_url() {
        return site_meta_landing_url;
    }

    public void setSite_meta_landing_url(final String site_meta_landing_url) {
        this.site_meta_landing_url = site_meta_landing_url;
    }

    public String getSite_meta_direct_delivery() {
        return site_meta_direct_delivery;
    }

    public void setSite_meta_direct_delivery(final String site_meta_direct_delivery) {
        this.site_meta_direct_delivery = site_meta_direct_delivery;
    }

    public String getSite_meta_free_delivery() {
        return site_meta_free_delivery;
    }

    public void setSite_meta_free_delivery(final String site_meta_free_delivery) {
        this.site_meta_free_delivery = site_meta_free_delivery;
    }

    public String getSite_meta_use_won_currency() {
        return site_meta_use_won_currency;
    }

    public void setSite_meta_use_won_currency(final String site_meta_use_won_currency) {
        this.site_meta_use_won_currency = site_meta_use_won_currency;
    }

    public String getSite_meta_flagship() {
        return site_meta_flagship;
    }

    public void setSite_meta_flagship(final String site_meta_flagship) {
        this.site_meta_flagship = site_meta_flagship;
    }

    public String getSite_meta_free_delivery_description() {
        return site_meta_free_delivery_description;
    }

    public void setSite_meta_free_delivery_description(final String site_meta_free_delivery_description) {
        this.site_meta_free_delivery_description = site_meta_free_delivery_description;
    }

    public String getSite_meta_site_desc() {
        return site_meta_site_desc;
    }

    public void setSite_meta_site_desc(final String site_meta_site_desc) {
        this.site_meta_site_desc = site_meta_site_desc;
    }

    public String getSite_meta_checkout_card() {
        return site_meta_checkout_card;
    }

    public void setSite_meta_checkout_card(final String site_meta_checkout_card) {
        this.site_meta_checkout_card = site_meta_checkout_card;
    }

    public String get_categories_total_count() {
        return _categories_total_count;
    }

    public void set_categories_total_count(final String _categories_total_count) {
        this._categories_total_count = _categories_total_count;
    }

    public String getSite_meta_promotion_info() {
        return site_meta_promotion_info;
    }

    public void setSite_meta_promotion_info(final String site_meta_promotion_info) {
        this.site_meta_promotion_info = site_meta_promotion_info;
    }

    public String getSite_meta_sex() {
        return site_meta_sex;
    }

    public void setSite_meta_sex(final String site_meta_sex) {
        this.site_meta_sex = site_meta_sex;
    }

    public String getSite_meta_gender() {
        return site_meta_gender;
    }

    public void setSite_meta_gender(final String site_meta_gender) {
        this.site_meta_gender = site_meta_gender;
    }

    public float getSite_matching() {
        return site_matching;
    }

    public void setSite_matching(final float site_matching) {
        this.site_matching = site_matching;
    }

    public CategorySearchResultEntity getCategory() {
        return category;
    }

    public void setCategory(final CategorySearchResultEntity category) {
        this.category = category;
    }

    public List<CategorySearchResultEntity> getCategories() {
        return categories;
    }

    public void setCategories(final List<CategorySearchResultEntity> categories) {
        this.categories = categories;
    }

    public List getDocs() {
        return docs;
    }

    public void setDocs(final List docs) {
        this.docs = docs;
    }

    public float get_score() {
        return _score;
    }

    public void set_score(final float _score) {
        this._score = _score;
    }

    public String getCus_site_is_like() {
        return cus_site_is_like;
    }

    public void setCus_site_is_like(final String cus_site_is_like) {
        this.cus_site_is_like = cus_site_is_like;
    }

    public String getLikeSiteCatSq() {
        return likeSiteCatSq;
    }

    public void setLikeSiteCatSq(final String likeSiteCatSq) {
        this.likeSiteCatSq = likeSiteCatSq;
    }

    public String getCus_site_cnt() {
        return cus_site_cnt;
    }

    public void setCus_site_cnt(final String cus_site_cnt) {
        this.cus_site_cnt = cus_site_cnt;
    }

    public String getCus_site_is_bookmark() {
        return cus_site_is_bookmark;
    }

    public void setCus_site_is_bookmark(final String cus_site_is_bookmark) {
        this.cus_site_is_bookmark = cus_site_is_bookmark;
    }

    public String getSite_meta_korean_support() {
        return site_meta_korean_support;
    }

    public void setSite_meta_korean_support(final String site_meta_korean_support) {
        this.site_meta_korean_support = site_meta_korean_support;
    }

    public String getSite_meta_country() {
        return site_meta_country;
    }

    public void setSite_meta_country(final String site_meta_country) {
        this.site_meta_country = site_meta_country;
    }

    public String getSite_meta_shop_type() {
        return site_meta_shop_type;
    }

    public void setSite_meta_shop_type(final String site_meta_shop_type) {
        this.site_meta_shop_type = site_meta_shop_type;
    }

    public String getSite_meta_genre() {
        return site_meta_genre;
    }

    public void setSite_meta_genre(final String site_meta_genre) {
        this.site_meta_genre = site_meta_genre;
    }
}
