package com.hyundaicard.cse.app.search.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hyundaicard.cse.app.search.entity.SearchAutocompleteRequestEntity;
import com.hyundaicard.cse.app.search.service.SearchService;
import com.hyundaicard.cse.common.controller.CseAppController;
import com.hyundaicard.cse.common.entity.RestRespEntity;
import com.hyundaicard.cse.common.view.Request;

/**
 * 인기있는 Controller
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Controller
@SuppressWarnings("rawtypes")
public class SearchAppController extends CseAppController {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(SearchAppController.class);

    @Autowired
    private SearchService searchService;

    @RequestMapping(value = "/api/search/autocompleteBody", method = RequestMethod.POST)
    public ModelAndView autocompleteBody(final HttpServletRequest httpServletRequest, final HttpServletResponse httpServletResponse, final Request request) throws Exception {

        final JSONObject responseJson = new JSONObject();
        final JSONObject requestJson = request.getRequestBodyJson();
        final String query = requestJson.optString("query", "");

        logger.debug("===================autocomplete===============================");
        logger.debug(" autocomplete query {} :", query);
        logger.debug("==============================================================");

        final SearchAutocompleteRequestEntity entity = new SearchAutocompleteRequestEntity();
        entity.setQuery(query);
        final RestRespEntity restRespEntity = searchService.autocompleteBody(entity);
        responseJson.put("resultCode", restRespEntity.getResultCode());
        responseJson.put("requestData", entity);
        responseJson.put("resultData", restRespEntity.getResultData());
        return createResponseModelAndView(httpServletRequest, httpServletResponse, request, responseJson);
    }
}
