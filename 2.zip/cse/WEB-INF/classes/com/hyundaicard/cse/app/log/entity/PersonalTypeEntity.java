package com.hyundaicard.cse.app.log.entity;

/**
 * PersonalType Entity
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public class PersonalTypeEntity {

    private String personalTyp;
    private LogType logType;

    public String getPersonalTyp() {
        return personalTyp;
    }

    public void setPersonalTyp(final String personalTyp) {
        this.personalTyp = personalTyp;
    }

    public LogType getLogType() {
        return logType;
    }

    public void setLogType(final LogType logType) {
        this.logType = logType;
    }

    public static class LogType {
        private String percent;
        private String count;
        private String siteKeys; // Constants.PERSONAL_TYPE_BAS_3 일때만 존재

        public String getPercent() {
            return percent;
        }

        public void setPercent(final String percent) {
            this.percent = percent;
        }

        public String getCount() {
            return count;
        }

        public void setCount(final String count) {
            this.count = count;
        }

        public String getSiteKeys() {
            return siteKeys;
        }

        public void setSiteKeys(final String siteKeys) {
            this.siteKeys = siteKeys;
        }

    }

}
