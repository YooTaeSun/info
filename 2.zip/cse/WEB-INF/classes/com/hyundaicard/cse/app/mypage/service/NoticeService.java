package com.hyundaicard.cse.app.mypage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.mypage.entity.NoticeEntity;
import com.hyundaicard.cse.app.mypage.entity.PopupNoticeEntity;
import com.hyundaicard.cse.app.mypage.mapper.NoticeMapper;
import com.hyundaicard.cse.common.entity.PagingValue;

/**
 * Notice Service
 */
@Service
public class NoticeService {

    /** Mapper */
    @Autowired
    private NoticeMapper noticeMapper;

    /**
     * 공지사항 리스트 조회
     */
    public List<NoticeEntity> getNoticeList(final NoticeEntity noticeEntity) {
        final int count = this.getCount(noticeEntity);

        final PagingValue paging = noticeEntity.getPagingValue(count);

        noticeEntity.setPaging(paging);

        final List<NoticeEntity> noticeList = noticeMapper.getNoticeList(noticeEntity);

        return noticeList;
    }

    /**
     * 공지사항 상세 조회
     */
    public NoticeEntity getNoticeDetail(final NoticeEntity noticeEntity) {

        final NoticeEntity noticeDetail = noticeMapper.getNoticeDetail(noticeEntity);

        return noticeDetail;
    }

    /**
     * 조회 카운트 업데이트
     */
    public void updateHitCount(final NoticeEntity noticeEntity) {

        noticeMapper.updateHitCount(noticeEntity);
    }

    /**
     * 총갯수 조회
     */
    public int getCount(final NoticeEntity noticeEntity) {
        return noticeMapper.getCount(noticeEntity);
    }

    /**
     * 팝업공지 가져오기
     *
     * @param entity
     * @return
     */
    public PopupNoticeEntity getPopupNotice(final PopupNoticeEntity entity) {
        return noticeMapper.getPopupNotice(entity);
    }

    /**
     * 팝업 스킵 유무
     *
     * @param entity
     * @return
     */
    public Integer getPopupSkip(final PopupNoticeEntity entity) {
        final Integer noticeSq = noticeMapper.getPopupNoticeSq(entity);
        if (noticeSq != null) {
            entity.setNoticeSq(noticeSq);
            final Integer noticeChk = noticeMapper.getPopupSkip(entity);

            if (noticeChk == null || noticeChk == 0) {
                return noticeSq;
            }
        }
        return null;
    }

    /**
     * 다시보지 않기 등록
     *
     * @param entity
     * @return
     */
    public void setPopupSkip(final PopupNoticeEntity entity) {
        noticeMapper.setPopupSkip(entity);
    }

    /**
     * 최근등록된 이벤트 및 공지 개수
     *
     * @param entity
     * @return
     */
    public Integer getCntInitNotice(final NoticeEntity entity) {
        return noticeMapper.getCntInitNotice(entity);
    }
}
