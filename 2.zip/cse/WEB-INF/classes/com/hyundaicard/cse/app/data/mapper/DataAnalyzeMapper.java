package com.hyundaicard.cse.app.data.mapper;

import org.springframework.dao.DataAccessException;

/**
 * DataAnalyze Mapper
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public interface DataAnalyzeMapper {

    /**
     * 데이터 분석카운트 조회
     */
    public String getAnalyzeDataCount() throws DataAccessException;

    /**
     * 데이터 분석카운트 업데이트
     */
    public void updateAnalyzeDataCount(String dataCount) throws DataAccessException;

}
