package com.hyundaicard.cse.app.mypage.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hyundaicard.cse.app.mypage.service.DisjoinService;
import com.hyundaicard.cse.common.controller.CseAppController;
import com.hyundaicard.cse.common.view.Request;

/**
 * 회원탈퇴
 *
 */

@Controller
public class DisjoinController extends CseAppController {

    private static final Logger logger = LoggerFactory.getLogger(DisjoinController.class);

    @Autowired
    private DisjoinService disjoinService;

    /**
     * 회원탈퇴시 삭제되는 정보 조회
     */
    @RequestMapping(value = "/api/mypage/disjoin0101", method = RequestMethod.POST)
    public ModelAndView disjoin0101(final HttpServletRequest httpServletRequest,
            final HttpServletResponse httpServletResponse, final Request request) throws Exception {
        logger.info(">>>>disjoin0101");

        final JSONObject responseJson = new JSONObject();

        final String disjoinInfo = disjoinService.getDisjoinInfo();

        responseJson.put("disjoinInfo", disjoinInfo);

        logger.info("<<<<disjoin0101");

        return createResponseModelAndView(httpServletRequest, httpServletResponse, request, responseJson);
    }

    /**
     * 회원탈퇴
     */
    @RequestMapping(value = "/api/mypage/disjoin0102", method = RequestMethod.POST)
    public ModelAndView disjoin0102(final HttpServletRequest httpServletRequest,
            final HttpServletResponse httpServletResponse, final Request request) throws Exception {
        logger.info(">>>>disjoin0102");

        final JSONObject responseJson = new JSONObject();
        final String userId = (String) httpServletRequest.getSession().getAttribute("userId");

        disjoinService.disjoinMember(userId);

        /** 세션정보 삭제 */
        httpServletRequest.getSession().setAttribute("memberIdSq", null);
        httpServletRequest.getSession().setAttribute("userId", null);
        httpServletRequest.getSession().setAttribute("customerNo", null);
        httpServletRequest.getSession().setAttribute("hccAuthYN", null);

        /** 쿠키의 자동로그인 정보 삭제 */
        final Cookie cookie = new Cookie("HC3", null);
        cookie.setPath("/");
        cookie.setMaxAge(0);
        httpServletResponse.addCookie(cookie);

        logger.info("<<<<disjoin0102");

        return createResponseModelAndView(httpServletRequest, httpServletResponse, request, responseJson);
    }
}
