package com.hyundaicard.cse.app.test.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page.
 */
@Controller
public class TestController {

    private static final Logger logger = LoggerFactory.getLogger(TestController.class);

    /**
     * 테스트 페이지
     */
    @RequestMapping(value = "/test/test0101", method = RequestMethod.GET)
    public String login0101(final Model model) {

        logger.info(">>>test0101");
        return "test/test0101";

    }

    @RequestMapping(value = { "/test/testLink", "/test/testLink2" }, method = RequestMethod.GET)
    public void testLink(final Model model) {
    }

    public static void main(final String[] args) {
        Connection connection = null;
        Statement st = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:log4jdbc:mysql://172.19.32.205:3306/csedb?characterEncoding=UTF-8", "myadm", "myadm@#$%2345p");
            st = connection.createStatement();

            String sql;
            sql = "select 1 AS AAA FROM dual";

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                String sqlRecipeProcess = rs.getString("AAA");
            }

            rs.close();
            st.close();
            connection.close();
        } catch (SQLException se1) {
            se1.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (st != null) {
                    st.close();
                }
            } catch (SQLException se2) {
            }
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
    }

}
