package com.hyundaicard.cse.app.init.controller;

import java.util.Locale;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hyundaicard.cse.app.bookmark.service.BookmarkService;
import com.hyundaicard.cse.app.bookmark.service.SessionService;
import com.hyundaicard.cse.app.init.entity.AppTokenEntity;
import com.hyundaicard.cse.app.init.entity.EmergencyNoticeEntity;
import com.hyundaicard.cse.app.init.entity.UpdateInfoEntity;
import com.hyundaicard.cse.app.init.service.InitService;
import com.hyundaicard.cse.app.mypage.entity.NoticeEntity;
import com.hyundaicard.cse.app.mypage.entity.PopupNoticeEntity;
import com.hyundaicard.cse.app.mypage.entity.SaleInfoEntity;
import com.hyundaicard.cse.app.mypage.service.NoticeService;
import com.hyundaicard.cse.app.mypage.service.SaleInfoService;
import com.hyundaicard.cse.common.annotation.CheckAutoLogin;
import com.hyundaicard.cse.common.annotation.CheckSession;
import com.hyundaicard.cse.common.annotation.UseRSA;
import com.hyundaicard.cse.common.annotation.UseSEED;
import com.hyundaicard.cse.common.constants.ProtocolConstants;
import com.hyundaicard.cse.common.constants.SessionConstants;
import com.hyundaicard.cse.common.controller.CseAppController;
import com.hyundaicard.cse.common.exception.BizException;
import com.hyundaicard.cse.common.util.GenerateKeyUtil;
import com.hyundaicard.cse.common.view.Request;

@Controller
public class InitController extends CseAppController {

    private static final Logger logger = LoggerFactory.getLogger(InitController.class);

    @Autowired
    private MessageSource messageSource;

    @Autowired
    private InitService initService;

    @Autowired
    private BookmarkService bookmarkService;

    @Autowired
    private NoticeService noticeService;

    @Autowired
    private SaleInfoService saleInfoService;

    @Autowired
    private SessionService sessionService;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * 앱 초기구동 initialize 키 교환 step1
     */

    @RequestMapping(value = "/api/init/init0101", method = { RequestMethod.POST, RequestMethod.GET })
    @UseRSA(useRSA = true)
    @UseSEED(useSEED = false)
    @CheckSession(isCheck = false)
    @CheckAutoLogin(isCheck = false)
    public ModelAndView init0101(final HttpServletRequest httpServletRequest,
            final HttpServletResponse httpServletResponse, final Request request) throws Exception {
        logger.info(">>>>init0101");

        final JSONObject requestJson = request.getRequestBodyJson();
        final JSONObject responseJson = new JSONObject();

        final String apLib = requestJson.optString("NSHCLib", "0");
        final String osType = requestJson.optString(ProtocolConstants.HEAD_OS_TYPE, SessionConstants.OS_TYPE_IPHONE);
        final String osVersion = requestJson.optString(ProtocolConstants.HEAD_OS_VERSION,
                SessionConstants.OS_VERSION_DEFAULT);
        final String appVersion = requestJson.optString(ProtocolConstants.HEAD_APP_VERSION,
                SessionConstants.APP_VERSION_DEFAULT);
        final String model = requestJson.optString(ProtocolConstants.HEAD_MODEL, SessionConstants.MODEL_DEFAULT);
        final String deviceId = requestJson.optString(ProtocolConstants.HEAD_DEVICE_ID,
                SessionConstants.DEVICE_ID_DEFAULT);
        final String deviceMac = requestJson.optString(ProtocolConstants.HEAD_MAC, SessionConstants.DEVICE_MAC_DEFAULT);
        final String uuid = requestJson.optString("uuid", null);

        // response default
        responseJson.put(ProtocolConstants.SERVER_SEED_KEY, "");
        responseJson.put(ProtocolConstants.SERVER_SEED_IV, "");
        responseJson.put("serverNSHC", "");
        responseJson.put("needUpdateYN", "N");
        responseJson.put("updateInfo", new JSONObject());

        HttpSession httpSession = httpServletRequest.getSession(false);

        if (httpSession == null) {
            httpSession = httpServletRequest.getSession(true);
        }

        httpSession.setAttribute(SessionConstants.OS_TYPE, osType);
        httpSession.setAttribute(SessionConstants.OS_VERSION, osVersion);
        httpSession.setAttribute(SessionConstants.APP_VERSION, appVersion);
        httpSession.setAttribute(SessionConstants.MODEL, model);
        httpSession.setAttribute(SessionConstants.DEVICE_ID, deviceId);
        httpSession.setAttribute(SessionConstants.DEVICE_MAC, deviceMac);

        /** 강제 업데이트 여부 체크 */
        final UpdateInfoEntity appInfo = new UpdateInfoEntity();
        appInfo.setOsType(osType);
        appInfo.setAppVersion(appVersion);

        logger.info("osType = " + osType + " / " + "appVersion : " + appVersion);
        logger.debug("uuid : " + uuid);

        final UpdateInfoEntity updateInfo = initService.getUpdateInfo(appInfo);

        if (updateInfo != null) {
            responseJson.put("needUpdateYN", "Y");
            responseJson.put("updateAppVersion", updateInfo.getAppVersion());
            responseJson.put("updateForceYN", updateInfo.getForceUpdateYN());
        }

        /** 긴급 공지 조회 */
        final EmergencyNoticeEntity emergencyNotice = initService.getEmergencyNotice();
        if (emergencyNotice != null) {
            responseJson.put("emergencyNoticeSq", emergencyNotice.getNoticeSq());
            responseJson.put("emergencyNoticeTitle", emergencyNotice.getTitle());
            responseJson.put("emergencyNoticeContent", emergencyNotice.getContent());

        }

        /** 위변조 검증 키 획득 */
        final String serverNSHC = initService.getNSHCKey(httpServletRequest, osType, apLib);

        /** SERVER SEED */
        final String serverSeedKey = GenerateKeyUtil.getSeedKey();
        final String serverSeedIV = GenerateKeyUtil.getSeedIV();

        responseJson.put("serverNSHC", serverNSHC);
        responseJson.put(ProtocolConstants.SERVER_SEED_KEY, serverSeedKey);
        responseJson.put(ProtocolConstants.SERVER_SEED_IV, serverSeedIV);

        httpSession.setAttribute(SessionConstants.SERVER_SEED_KEY, serverSeedKey);
        httpSession.setAttribute(SessionConstants.SERVER_SEED_IV, serverSeedIV);
        httpSession.setAttribute("uuid", uuid);

        logger.info("httpSession ID : " + httpSession.getId());

        logger.info("<<<<init0101");

        return createResponseModelAndView(httpServletRequest, httpServletResponse, request, responseJson);
    }

    /**
     * 앱 초기구동 initialize 키 교환 step2
     */

    @RequestMapping(value = "/api/init/init0102", method = { RequestMethod.POST, RequestMethod.GET })
    @CheckAutoLogin(isCheck = false)
    public ModelAndView init0102(final HttpServletRequest httpServletRequest,
            final HttpServletResponse httpServletResponse, final Request request) throws Exception {
        logger.info(">>>>init0102");

        final JSONObject requestJson = request.getRequestBodyJson();
        final JSONObject responseJson = new JSONObject();

        responseJson.put("popupNoticeList", new JSONArray());

        final String clientNSHC = requestJson.optString("clientNSHC", null);
        final String uuid = requestJson.optString("uuid", null);
        final String appToken = requestJson.optString("appToken", null);
        final String receiveYN = requestJson.optString("pushReceiveYN", "N");
        final String osType = (String) httpServletRequest.getSession().getAttribute(SessionConstants.OS_TYPE);

        if (clientNSHC == null) {
            throw new BizException(messageSource, "INIT0001", Locale.getDefault());
        }

        /** 위변조 검증 */
        try {
            initService.checkVerify(httpServletRequest, clientNSHC);
        } catch (final Exception e) {
            throw new BizException(messageSource, e.getMessage(), Locale.getDefault());
        }

        /** 팝업 공지 조회 */
        final PopupNoticeEntity popupNoticeEntity = new PopupNoticeEntity();
        popupNoticeEntity.setUuid(uuid);
        final Integer noticeSq = noticeService.getPopupSkip(popupNoticeEntity);

        if (noticeSq != null) {
            final String noticeUrl = "/notice/popup?noticeSq=" + noticeSq;
            responseJson.put("popupNoticeUrl", noticeUrl);
        }

        /** 앱 푸시를 위한 토큰 등록 */
        if (appToken != null) {
            final AppTokenEntity appTokenEntity = new AppTokenEntity();
            appTokenEntity.setUuid(uuid);
            appTokenEntity.setOsType(osType);
            appTokenEntity.setAppToken(appToken);
            appTokenEntity.setReceiveYN(receiveYN);

            initService.updateAppToken(appTokenEntity);
        }

        if (uuid != null) {
            httpServletRequest.getSession().setAttribute("uuid", uuid);
        }

        /** 북마크 사이트 새상품 존재 여부 조회 (뱃지 노출) */
        // final boolean newProductYN = bookmarkService.isExistNewCrawlProduct();
        // responseJson.put("newProductYN", newProductYN == true ? "Y" : "N");

        /** 북마크 사이트 새상품 갯수 (뱃지 노출) */
        int newProductCount = 0;
        newProductCount = bookmarkService.getNewProductCnt();
        responseJson.put("newProductCount", newProductCount);
        responseJson.put("newProductYN", newProductCount == 0 ? "N" : "Y");

        /** 공지사항 새로운 공지 여부 조회 (뱃지 노출) */
        final NoticeEntity nEntity = new NoticeEntity();
        nEntity.setUuid(uuid);
        final int nCount = noticeService.getCntInitNotice(nEntity);
        responseJson.put("newNoticeYN", nCount == 0 ? "N" : "Y");
        responseJson.put("newNoticeCount", nCount);

        /** 할인정보 새로운 정보 여부 조회 (뱃지 노출) */
        final SaleInfoEntity sEntity = new SaleInfoEntity();
        sEntity.setUuid(uuid);
        final int sCount = saleInfoService.getCntInitSaleInfo(sEntity);
        responseJson.put("newSaleInfoCount", sCount);

        // 자동로그인 처리 및 구분을 위해 Cookie에 uuid setting
        final Cookie cookie = new Cookie("uuid", uuid);
        cookie.setPath("/");
        httpServletResponse.addCookie(cookie);

        logger.info("<<<<init0102");

        return createResponseModelAndView(httpServletRequest, httpServletResponse, request, responseJson);
    }

    @RequestMapping(value = "/api/init/noticeSkip", method = { RequestMethod.POST, RequestMethod.GET })
    public ModelAndView noticeSkip(final HttpServletRequest httpServletRequest,
            final HttpServletResponse httpServletResponse, final Request request) throws Exception {

        final JSONObject requestJson = request.getRequestBodyJson();
        final JSONObject responseJson = new JSONObject();

        final int noticeSq = Integer.parseInt(requestJson.optString("noticeSq", "0"));

        final PopupNoticeEntity entity = new PopupNoticeEntity();

        final String uuid = sessionService.getAttribute("uuid");
        entity.setUuid(uuid);
        entity.setNoticeSq(noticeSq);

        noticeService.setPopupSkip(entity);

        return createResponseModelAndView(httpServletRequest, httpServletResponse, request, responseJson);
    }
}
