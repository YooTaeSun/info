package com.hyundaicard.cse.app.auth.mapper;

import org.springframework.dao.DataAccessException;

import com.hyundaicard.cse.app.auth.entity.AuthEntity;
import com.hyundaicard.cse.app.login.entity.UserEntity;

/**
 * Auth Mapper
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public interface AuthMapper {

    /**
     * 인증 결과 조회
     */
    public AuthEntity checkAuthResult(AuthEntity authEntity) throws DataAccessException;

    /**
     * 기가입 회원 조회 (HCC)
     */
    public String checkAlreadyJoinHCC(String customerNo) throws DataAccessException;

    /**
     * 기가입 회원 조회 (SNS)
     */
    public String checkAlreadyJoinSNS(String snsUid) throws DataAccessException;

    /**
     * 고객번호 갱신
     */
    public void updateCustomerNo(UserEntity userEntity) throws DataAccessException;

}
