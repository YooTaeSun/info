package com.hyundaicard.cse.app.search.entity;

/**
 * 인기있는 Site List Entity
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public class ProductResultEntity {
    private String id;
    private String product_item_title;
    private String product_item_price_original;
    private String product_item_img;
    private String product_page_url_full;
    private String product_landing_url;
    private String product_site_key;
    private String product_cat_key;
    private String product_crawl;
    private String product_item_price_original_c;
    private String product_item_price_sale;
    private String product_item_price_sale_c;

    private String isNew; // custom

    public String getId() {
        return id;
    }

    public void setId(final String id) {
        this.id = id;
    }

    public String getProduct_item_title() {
        return product_item_title;
    }

    public void setProduct_item_title(final String product_item_title) {
        this.product_item_title = product_item_title;
    }

    public String getProduct_item_price_original() {
        return product_item_price_original;
    }

    public void setProduct_item_price_original(final String product_item_price_original) {
        this.product_item_price_original = product_item_price_original;
    }

    public String getProduct_item_img() {
        return product_item_img;
    }

    public void setProduct_item_img(final String product_item_img) {
        this.product_item_img = product_item_img;
    }

    public String getProduct_page_url_full() {
        return product_page_url_full;
    }

    public void setProduct_page_url_full(final String product_page_url_full) {
        this.product_page_url_full = product_page_url_full;
    }

    public String getProduct_landing_url() {
        return product_landing_url;
    }

    public void setProduct_landing_url(final String product_landing_url) {
        this.product_landing_url = product_landing_url;
    }

    public String getProduct_site_key() {
        return product_site_key;
    }

    public void setProduct_site_key(final String product_site_key) {
        this.product_site_key = product_site_key;
    }

    public String getProduct_cat_key() {
        return product_cat_key;
    }

    public void setProduct_cat_key(final String product_cat_key) {
        this.product_cat_key = product_cat_key;
    }

    public String getProduct_crawl() {
        return product_crawl;
    }

    public void setProduct_crawl(final String product_crawl) {
        this.product_crawl = product_crawl;
    }

    public String getIsNew() {
        return isNew;
    }

    public void setIsNew(final String isNew) {
        this.isNew = isNew;
    }

    public String getProduct_item_price_original_c() {
        return product_item_price_original_c;
    }

    public void setProduct_item_price_original_c(final String product_item_price_original_c) {
        this.product_item_price_original_c = product_item_price_original_c;
    }

    public String getProduct_item_price_sale() {
        return product_item_price_sale;
    }

    public void setProduct_item_price_sale(final String product_item_price_sale) {
        this.product_item_price_sale = product_item_price_sale;
    }

    public String getProduct_item_price_sale_c() {
        return product_item_price_sale_c;
    }

    public void setProduct_item_price_sale_c(final String product_item_price_sale_c) {
        this.product_item_price_sale_c = product_item_price_sale_c;
    }

}
