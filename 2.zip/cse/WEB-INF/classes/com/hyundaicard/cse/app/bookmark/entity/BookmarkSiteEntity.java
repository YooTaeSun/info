package com.hyundaicard.cse.app.bookmark.entity;

import java.util.List;

import com.hyundaicard.cse.app.mypage.entity.SaleInfoEntity;
import com.hyundaicard.cse.app.search.entity.CategorySearchResultEntity;

/**
 * site Entity
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public class BookmarkSiteEntity {
    private String favSiteCatSq; // 관심 사이트 순번
    private String memberIdSq; // 회원아이디 일련번호
    private String uuid; // 비회원 단말 식별값
    private String siteKey; // 사이트키
    private String catKey; // 카테고리키
    private String query; // 검색어
    private String siteMatching; // 사이트 매칭율
    private String oldSiteKey; // 기존사이트키
    private String siteArea; // 사이트영역
    private String siteUrl; // 사이트URL
    private String koreanNm; // 사이트한글명
    private String engNm; // 사이트 영문명
    private String synNm; // 유사명
    private String country; // 국가
    private String shopType; // 상점유형
    private String priceLvl; // 가격 수준
    private String siteDesc; // 사이트 설명
    private String style; // 스타일
    private String sex; // 성별
    private String productCategory; // 상품카테고리
    private String officialSiteYn; // 브랜드공식사이트여부
    private String koreanSupportYn; // 한글지원여부
    private String koreanHomepageYn; // 한국공식사이트존재여부
    private String useWonCurrencyYn; // 원화 사용여부
    private String directDeliveryYn; // 직배송여부
    private String freeDeliveryYn; // 무료배송여부
    private String freeDeliveryDescription; // 무료배송 설명
    private String reliability; // 신뢰도
    private String relationKeyword; // 관련 키워드
    private String landingUrl; // 랭딩URL
    private String memo; // 비고
    private String useYn; // 사용여부
    private String siteImage; // 사이트이미지
    private String duplicateSiteYn; // 사이트 중복여부
    private String brandGenre;
    private String checkoutCard;
    private String promotionInfo;
    private String promotionInfoSale;
    private String note;

    private List<CategorySearchResultEntity> categoryRows; // custom
    private List<BookmarkQueryEntity> bookmarkQueryList; // custom
    private SaleInfoEntity saleInfo; // 세일 정보 custom

    public String getFavSiteCatSq() {
        return favSiteCatSq;
    }

    public void setFavSiteCatSq(final String favSiteCatSq) {
        this.favSiteCatSq = favSiteCatSq;
    }

    public String getMemberIdSq() {
        return memberIdSq;
    }

    public void setMemberIdSq(final String memberIdSq) {
        this.memberIdSq = memberIdSq;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    public String getSiteKey() {
        return siteKey;
    }

    public void setSiteKey(final String siteKey) {
        this.siteKey = siteKey;
    }

    public String getCatKey() {
        return catKey;
    }

    public void setCatKey(final String catKey) {
        this.catKey = catKey;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(final String query) {
        this.query = query;
    }

    public String getSiteMatching() {
        return siteMatching;
    }

    public void setSiteMatching(final String siteMatching) {
        this.siteMatching = siteMatching;
    }

    public String getOldSiteKey() {
        return oldSiteKey;
    }

    public void setOldSiteKey(final String oldSiteKey) {
        this.oldSiteKey = oldSiteKey;
    }

    public String getSiteArea() {
        return siteArea;
    }

    public void setSiteArea(final String siteArea) {
        this.siteArea = siteArea;
    }

    public String getSiteUrl() {
        return siteUrl;
    }

    public void setSiteUrl(final String siteUrl) {
        this.siteUrl = siteUrl;
    }

    public String getKoreanNm() {
        return koreanNm;
    }

    public void setKoreanNm(final String koreanNm) {
        this.koreanNm = koreanNm;
    }

    public String getEngNm() {
        return engNm;
    }

    public void setEngNm(final String engNm) {
        this.engNm = engNm;
    }

    public String getSynNm() {
        return synNm;
    }

    public void setSynNm(final String synNm) {
        this.synNm = synNm;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(final String country) {
        this.country = country;
    }

    public String getShopType() {
        return shopType;
    }

    public void setShopType(final String shopType) {
        this.shopType = shopType;
    }

    public String getPriceLvl() {
        return priceLvl;
    }

    public void setPriceLvl(final String priceLvl) {
        this.priceLvl = priceLvl;
    }

    public String getSiteDesc() {
        return siteDesc;
    }

    public void setSiteDesc(final String siteDesc) {
        this.siteDesc = siteDesc;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(final String style) {
        this.style = style;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(final String sex) {
        this.sex = sex;
    }

    public String getProductCategory() {
        return productCategory;
    }

    public void setProductCategory(final String productCategory) {
        this.productCategory = productCategory;
    }

    public String getOfficialSiteYn() {
        return officialSiteYn;
    }

    public void setOfficialSiteYn(final String officialSiteYn) {
        this.officialSiteYn = officialSiteYn;
    }

    public String getKoreanSupportYn() {
        return koreanSupportYn;
    }

    public void setKoreanSupportYn(final String koreanSupportYn) {
        this.koreanSupportYn = koreanSupportYn;
    }

    public String getKoreanHomepageYn() {
        return koreanHomepageYn;
    }

    public void setKoreanHomepageYn(final String koreanHomepageYn) {
        this.koreanHomepageYn = koreanHomepageYn;
    }

    public String getUseWonCurrencyYn() {
        return useWonCurrencyYn;
    }

    public void setUseWonCurrencyYn(final String useWonCurrencyYn) {
        this.useWonCurrencyYn = useWonCurrencyYn;
    }

    public String getDirectDeliveryYn() {
        return directDeliveryYn;
    }

    public void setDirectDeliveryYn(final String directDeliveryYn) {
        this.directDeliveryYn = directDeliveryYn;
    }

    public String getFreeDeliveryYn() {
        return freeDeliveryYn;
    }

    public void setFreeDeliveryYn(final String freeDeliveryYn) {
        this.freeDeliveryYn = freeDeliveryYn;
    }

    public String getFreeDeliveryDescription() {
        return freeDeliveryDescription;
    }

    public void setFreeDeliveryDescription(final String freeDeliveryDescription) {
        this.freeDeliveryDescription = freeDeliveryDescription;
    }

    public String getReliability() {
        return reliability;
    }

    public void setReliability(final String reliability) {
        this.reliability = reliability;
    }

    public String getRelationKeyword() {
        return relationKeyword;
    }

    public void setRelationKeyword(final String relationKeyword) {
        this.relationKeyword = relationKeyword;
    }

    public String getLandingUrl() {
        return landingUrl;
    }

    public void setLandingUrl(final String landingUrl) {
        this.landingUrl = landingUrl;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(final String memo) {
        this.memo = memo;
    }

    public String getUseYn() {
        return useYn;
    }

    public void setUseYn(final String useYn) {
        this.useYn = useYn;
    }

    public String getSiteImage() {
        return siteImage;
    }

    public void setSiteImage(final String siteImage) {
        this.siteImage = siteImage;
    }

    public String getDuplicateSiteYn() {
        return duplicateSiteYn;
    }

    public void setDuplicateSiteYn(final String duplicateSiteYn) {
        this.duplicateSiteYn = duplicateSiteYn;
    }

    public String getBrandGenre() {
        return brandGenre;
    }

    public void setBrandGenre(final String brandGenre) {
        this.brandGenre = brandGenre;
    }

    public String getCheckoutCard() {
        return checkoutCard;
    }

    public void setCheckoutCard(final String checkoutCard) {
        this.checkoutCard = checkoutCard;
    }

    public String getPromotionInfo() {
        return promotionInfo;
    }

    public void setPromotionInfo(final String promotionInfo) {
        this.promotionInfo = promotionInfo;
    }

    public String getPromotionInfoSale() {
        return promotionInfoSale;
    }

    public void setPromotionInfoSale(final String promotionInfoSale) {
        this.promotionInfoSale = promotionInfoSale;
    }

    public String getNote() {
        return note;
    }

    public void setNote(final String note) {
        this.note = note;
    }

    public List<CategorySearchResultEntity> getCategoryRows() {
        return categoryRows;
    }

    public void setCategoryRows(final List<CategorySearchResultEntity> categoryRows) {
        this.categoryRows = categoryRows;
    }

    public List<BookmarkQueryEntity> getBookmarkQueryList() {
        return bookmarkQueryList;
    }

    public void setBookmarkQueryList(final List<BookmarkQueryEntity> bookmarkQueryList) {
        this.bookmarkQueryList = bookmarkQueryList;
    }

    public SaleInfoEntity getSaleInfo() {
        return saleInfo;
    }

    public void setSaleInfo(final SaleInfoEntity saleInfo) {
        this.saleInfo = saleInfo;
    }

}
