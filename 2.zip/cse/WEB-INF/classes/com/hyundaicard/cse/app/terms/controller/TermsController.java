package com.hyundaicard.cse.app.terms.controller;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hyundaicard.cse.app.terms.entity.TermsEntity;
import com.hyundaicard.cse.app.terms.service.TermsService;
import com.hyundaicard.cse.common.controller.CseAppController;
import com.hyundaicard.cse.common.exception.BizException;
import com.hyundaicard.cse.common.view.Request;

/**
 * 약관 정보 조회
 */

@Controller
public class TermsController extends CseAppController {

    private static final Logger logger = LoggerFactory.getLogger(TermsController.class);

    @Autowired
    private TermsService termsService;

    /**
     * 약관 조회
     */
    @RequestMapping(value = "/api/terms/terms0101", method = RequestMethod.POST)
    public ModelAndView terms0101(final HttpServletRequest httpServletRequest, final HttpServletResponse httpServletResponse, final Request request) throws Exception {
        logger.info(">>>>terms0101");

        final JSONObject requestJson = request.getRequestBodyJson();
        final JSONObject responseJson = new JSONObject();

        final String termsCode = requestJson.optString("termsCode", "");
        logger.info("termsCode : " + termsCode);
        TermsEntity termsEntity = new TermsEntity();
        termsEntity.setTermsCode(termsCode);

        termsEntity = termsService.getTermsInfo(termsEntity);

        if (termsEntity == null) {
            throw new BizException(messageSource, "TERMS0001", null, Locale.getDefault());
        }

        responseJson.put("title", termsEntity.getTitle());
        responseJson.put("content", termsEntity.getContent().replaceAll("\n", "<br />"));

        logger.info("<<<<terms0101");

        return createResponseModelAndView(httpServletRequest, httpServletResponse, request, responseJson);
    }

    @RequestMapping(value = "/terms/terms0101")
    public String terms0101View() {
        return "/terms/terms0101";
    }

    @RequestMapping(value = "/terms/terms0102")
    public String terms0102View() {
        return "/terms/terms0102";
    }

    @RequestMapping(value = "/terms/terms0103")
    public String terms0103View() {
        return "/terms/terms0103";
    }

    @RequestMapping(value = "/terms/terms0104")
    public String terms0104View() {
        return "/terms/terms0104";
    }

}
