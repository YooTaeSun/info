// package com.hyundaicard.cse.app.bookmark.service;
//
// public class TempUserEntity {
//
// private String userId;
// private String uuid;
//
// public String getUserId() {
// return userId;
// }
// public void setUserId(String userId) {
// this.userId = userId;
// }
// public String getUuid() {
// return uuid;
// }
// public void setUuid(String uuid) {
// this.uuid = uuid;
// }
//
//
// }
