package com.hyundaicard.cse.app.search.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.search.entity.ReviewSiteEntity;
import com.hyundaicard.cse.app.search.mapper.ReviewSiteMapper;
import com.hyundaicard.cse.common.entity.PagingValue;

@Service("reviewSiteService")
public class ReviewSiteService {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(ReviewSiteService.class);

    @Autowired
    private ReviewSiteMapper mapper;

    public ReviewSiteEntity get(final ReviewSiteEntity entity) {
        return mapper.get(entity);
    }

    // 리스트 3개 가져오기
    // 더보기 10개
    public List<ReviewSiteEntity> getList(final ReviewSiteEntity entity) {
        final int count = this.getCount(entity);

        final PagingValue paging = entity.getPagingValue(count);

        entity.setPaging(paging);

        if (entity.getPageSize() > 3) {
            entity.setStartNum(paging.getStartRow() + 3);
        }

        return mapper.getList(entity);
    }

    public Integer getCount(final ReviewSiteEntity entity) {
        return mapper.getCount(entity);
    }

    /**
     * 별점
     *
     * @param entity
     * @return
     */
    public float getGrade(final ReviewSiteEntity entity) {
        return mapper.getGrade(entity);
    }

    /**
     * 저장
     *
     * @param entity
     * @return
     */
    public int insert(final ReviewSiteEntity entity) {
        return mapper.insert(entity);
    }

    /**
     * 수정
     *
     * @param entity
     * @return
     */
    public int update(final ReviewSiteEntity entity) {
        return mapper.update(entity);
    }

    /**
     * 삭제
     *
     * @param entity
     * @return
     */
    public int delete(final ReviewSiteEntity entity) {
        return mapper.delete(entity);
    }
}
