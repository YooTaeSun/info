package com.hyundaicard.cse.app.mypage.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.mypage.mapper.DisjoinMapper;

/**
 * Disjoin Service
 */
@Service
public class DisjoinService {

    /** Mapper */
    @Autowired
    private DisjoinMapper disjoinMapper;

    /**
     * 회원탈회시 삭제되는 정보 조회
     */
    public String getDisjoinInfo() {
        return "회원탈회시 삭제되는 정보입니다.<br/>북마크 정보, 회원아이디 등..";
    }

    /**
     * 회원탈회
     */
    public void disjoinMember(String userId) {
        disjoinMapper.disjoinMember(userId);
    }
}
