package com.hyundaicard.cse.app.auth.controller;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hyundaicard.cse.app.auth.entity.AuthEntity;
import com.hyundaicard.cse.app.auth.service.AuthService;
import com.hyundaicard.cse.app.bookmark.service.SessionService;
import com.hyundaicard.cse.app.join.service.JoinService;
import com.hyundaicard.cse.app.login.entity.UserEntity;
import com.hyundaicard.cse.app.question.entity.AnswerEntity;
import com.hyundaicard.cse.app.question.service.AnswerService;
import com.hyundaicard.cse.common.controller.CseAppController;
import com.hyundaicard.cse.common.exception.BizException;
import com.hyundaicard.cse.common.util.DateUtil;
import com.hyundaicard.cse.common.util.SeedUtil;
import com.hyundaicard.cse.common.view.Request;
import com.hyundaicard.cse.constants.Constants;

/**
 * 휴대폰 인증
 *
 */

@Controller
public class AuthController extends CseAppController {

    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

    @Autowired
    private AuthService authService;

    @Autowired
    private AnswerService answerService;

    @Autowired
    private JoinService joinService;

    @Autowired
    private SessionService sessionService;

    @Autowired
    private MessageSource messageSource;

    /**
     * 휴대폰 인증 결과 조회
     */

    @RequestMapping(value = "/api/auth/auth0101", method = RequestMethod.POST)
    public ModelAndView auth0101(final HttpServletRequest httpServletRequest,
            final HttpServletResponse httpServletResponse, final Request request) throws Exception {
        logger.info(">>>>auth0101");

        final JSONObject requestJson = request.getRequestBodyJson();
        final JSONObject responseJson = new JSONObject();

        final String encData = requestJson.optString("encData", "");
        final String[] decData = SeedUtil.getSeedDecryptECB(encData).split("\\|");
        final String uuid = decData[0];
        final String timeStamp = decData[1];

        final String currentTime = DateUtil.getCurrentDate() + DateUtil.getCurrentTime();

        if (timeStamp != null && (DateUtil.getTimeDiff(timeStamp, currentTime) > 180)) {
            // 인증 진행시간이 3분이 넘은 경우 유효하지 않은것으로 판단
            throw new BizException(messageSource, "AUTH0004", Locale.getDefault());
        }

        AuthEntity authEntity = new AuthEntity();

        authEntity.setTimeStamp(timeStamp);
        authEntity.setUuid(uuid);

        authEntity = authService.checkAuthResult(authEntity);

        if (authEntity != null) {

            if (authEntity.getCancelYn() == null || authEntity.getCancelYn().equals("Y")) {
                // 사용자가 취소했을 경우
                // 휴대폰 인증을 취소하였습니다.
                throw new BizException(messageSource, "AUTH0001", Locale.getDefault());
            }

            if (authEntity.getSuccessCode() == null || !(authEntity.getSuccessCode().equals("000"))) {
                // 인증전문 오류
                // 인증에 실패하였습니다. 잠시후 다시 시도해 주세요.
                throw new BizException(messageSource, "AUTH0002", Locale.getDefault());
            }

            if (authEntity.getResultCode() == null || !(authEntity.getResultCode().equals("000"))) {

                if (authEntity.getResultCode().equals("200")) {
                    // 고객번호 없음.
                    // 현대카드 회원이 아닙니다. 현대카드 홈페이지에 가입해 주세요.
                    throw new BizException(messageSource, "AUTH0003", Locale.getDefault());
                } else {
                    // 결과코드 오류
                    // 인증에 실패하였습니다. 잠시후 다시 시도해 주세요.
                    throw new BizException(messageSource, "AUTH0002", Locale.getDefault());
                }
            }

            if (authEntity.getCustomerNo() == null) {
                // 고객번호 없음.
                // 현대카드 회원이 아닙니다. 현대카드 홈페이지에 가입해 주세요.
                throw new BizException(messageSource, "AUTH0003", Locale.getDefault());
            }

        } else {
            // 인증 결과 없음
            // 인증에 실패하였습니다. 잠시후 다시 시도해 주세요.
            throw new BizException(messageSource, "AUTH0002", Locale.getDefault());
        }

        // 인증시 응답으로 온 고객번호로 기존 가입여부 체크
        final String userId = StringUtils.defaultIfEmpty(authService.checkAlreadyJoinHCC(authEntity.getCustomerNo()),
                "");

        final String sessionUserId = (String) httpServletRequest.getSession().getAttribute("userId");
        if (sessionUserId != null && sessionUserId.length() > 0) {
            // SNS 로그인 사용자인 경우 고객번호를 로그인한 ID에 mapping

            final UserEntity userEntity = new UserEntity();
            userEntity.setCustomerNo(authEntity.getCustomerNo());

            joinService.updateCustomerNoDefault(userEntity);

            userEntity.setCustomerNo(authEntity.getCustomerNo());
            userEntity.setMarketingAgreeYN(StringUtils.defaultIfEmpty(authEntity.getMarketingAgreeYn(), "N"));
            userEntity.setUserId(sessionUserId);

            authService.updateCustomerNo(userEntity);

            // 현재 로그인된 세션에 인증정보 추가
            httpServletRequest.getSession().setAttribute("customerNo", authEntity.getCustomerNo());
            httpServletRequest.getSession().setAttribute("hccAuthYN", "Y");

            // 로그인된 사용자ID 응답
            responseJson.put("userId", sessionUserId);
            responseJson.put("loginState", "Y");

        } else {
            // 인증을 진행한 사용자가 회원가입이 필요할 경우 사용할 고객번호를 세션에 저장
            httpServletRequest.getSession().setAttribute("authCustomerNo", authEntity.getCustomerNo());
            httpServletRequest.getSession().setAttribute("hccAuthYN", "Y");
            httpServletRequest.getSession().setAttribute("marketingAgreeYN", authEntity.getMarketingAgreeYn());

            responseJson.put("userId", userId);
            responseJson.put("loginState", "N");
        }

        responseJson.put("marketingAgreeYN", authEntity.getMarketingAgreeYn());

        // 설문 작성 여부
        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String tmpUuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            tmpUuid = sessionService.getAttribute("uuid");
        }
        String personalSurveyYN = "N";
        final AnswerEntity answerEntity = new AnswerEntity();
        answerEntity.setLoginIDInSession(memberIdSq);
        answerEntity.setUuid(tmpUuid);
        final int answerCnt = answerService.getAnswerCnt(answerEntity);
        if (answerCnt > 0) {
            personalSurveyYN = "Y";
        }

        responseJson.put("personalSurveyYN", personalSurveyYN);

        logger.info("<<<<auth0101");

        // 인증 성공
        return createResponseModelAndView(httpServletRequest, httpServletResponse, request, responseJson);
    }

    @RequestMapping(value = "/api/auth/encParameter", method = RequestMethod.POST)
    public ModelAndView encParameter(final HttpServletRequest httpServletRequest,
            final HttpServletResponse httpServletResponse, final Request request) throws Exception {

        logger.info("<<<<encParameter");

        final JSONObject responseJson = new JSONObject();

        final String uuid = (String) httpServletRequest.getSession().getAttribute("uuid");
        final String timeStamp = DateUtil.getCurrentDate() + DateUtil.getCurrentTime();

        logger.debug("uuid : " + uuid);

        final String encData = SeedUtil.getSeedEncryptECB(uuid + "|" + timeStamp);

        responseJson.put("encData", encData);

        logger.info(">>>>encParameter");

        return createResponseModelAndView(httpServletRequest, httpServletResponse, request, responseJson);
    }

    @RequestMapping(value = "/api/auth/auth0201", method = RequestMethod.POST)
    public ModelAndView auth0201(final HttpServletRequest httpServletRequest,
            final HttpServletResponse httpServletResponse, final Request request) throws Exception {

        logger.info("<<<<auth0201");

        final JSONObject requestJson = request.getRequestBodyJson();
        final JSONObject responseJson = new JSONObject();

        final String snsUid = requestJson.optString("snsUid", "");

        logger.debug("snsUid : " + snsUid);

        final String userId = StringUtils.defaultIfEmpty(authService.checkAlreadyJoinSNS(snsUid), "");

        responseJson.put("userId", userId);

        logger.info(">>>>auth0201");

        return createResponseModelAndView(httpServletRequest, httpServletResponse, request, responseJson);
    }

}
