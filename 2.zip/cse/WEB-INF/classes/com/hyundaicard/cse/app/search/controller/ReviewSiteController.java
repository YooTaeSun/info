package com.hyundaicard.cse.app.search.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hyundaicard.cse.app.bookmark.service.SessionService;
import com.hyundaicard.cse.app.search.entity.ReviewSiteEntity;
import com.hyundaicard.cse.app.search.service.ReviewSiteService;
import com.hyundaicard.cse.common.entity.RestRespEntity;
import com.hyundaicard.cse.common.util.CommonUtil;
import com.hyundaicard.cse.constants.Constants;

/**
 * like Controller
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@SuppressWarnings("rawtypes")
@Controller
public class ReviewSiteController {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(ReviewSiteController.class);

    @Autowired
    private ReviewSiteService service;

    @Autowired
    private SessionService sessionService;

    /**
     * review save
     *
     * @Mehtod Name : view @return String @throws
     */
    @RequestMapping(value = "/review/save", method = RequestMethod.POST)
    public ResponseEntity insert(@ModelAttribute final ReviewSiteEntity entity, final Model model) {
        final RestRespEntity restRespEntity = new RestRespEntity();

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        final String uuid = sessionService.getAttribute("uuid");

        entity.setMemberIdSq(memberIdSq);
        entity.setUuid(uuid);
        entity.setLoginIDInSession(memberIdSq);

        service.insert(entity);

        return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), null);
    }

    @RequestMapping(value = "/review/more", method = RequestMethod.POST)
    public ResponseEntity reviewMore(@ModelAttribute final ReviewSiteEntity entity, final Model model) {
        final RestRespEntity restRespEntity = new RestRespEntity();

        final List<ReviewSiteEntity> list = service.getList(entity);

        for (int i = 0; i < list.size(); i++) {
            final ReviewSiteEntity revEntity = list.get(i);
            if (list.get(i).getMemberIdSq().equals(sessionService.getAttribute("memberIdSq"))) {
                revEntity.setIsMine("Y");
            } else {
                revEntity.setIsMine("N");
            }
        }
        final int count = service.getCount(entity);

        final Map<String, Object> resultData = new HashMap<String, Object>();
        resultData.put("list", list);
        resultData.put("total", count);
        resultData.put("grade", service.getGrade(entity));
        resultData.put("page", entity.getPage());

        return CommonUtil.response(restRespEntity, resultData);
    }

    @RequestMapping(value = "/review/delete", method = RequestMethod.POST)
    public ResponseEntity delete(@ModelAttribute final ReviewSiteEntity entity, final Model model) {
        final RestRespEntity restRespEntity = new RestRespEntity();

        // passwordcheck
        final int count = service.getCount(entity);
        if (count > 0) {
            service.delete(entity);
        } else {
            return CommonUtil.response(restRespEntity, null);
        }

        return CommonUtil.response(restRespEntity, entity, null);
    }

    @RequestMapping(value = "/review/passwdChk", method = RequestMethod.POST)
    public ResponseEntity passwdChk(@ModelAttribute final ReviewSiteEntity entity, final Model model) {
        final RestRespEntity restRespEntity = new RestRespEntity();

        final int count = service.getCount(entity);

        return CommonUtil.response(restRespEntity, count);
    }

    @RequestMapping(value = "/review/update", method = RequestMethod.POST)
    public ResponseEntity update(@ModelAttribute final ReviewSiteEntity entity, final Model model) {
        final RestRespEntity restRespEntity = new RestRespEntity();

        if (!sessionService.equals(null)) {

            final String memberIdSq = sessionService.getAttribute("memberIdSq");
            String uuid = "";
            if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
                uuid = sessionService.getAttribute("uuid");
            }

            entity.setMemberIdSq(memberIdSq);
            entity.setUuid(uuid);
            entity.setLoginIDInSession(memberIdSq);
        }

        // passwordcheck
        final int count = service.getCount(entity);
        if (count > 0) {
            service.update(entity);
        } else {
            return CommonUtil.response(restRespEntity, null);
        }

        return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), null);
    }
}
