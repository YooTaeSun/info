package com.hyundaicard.cse.app.search.entity;

import java.util.List;

/**
 * Range Entity
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public class QkaResultEntity {

    private List<NamedResultEntity> namedEntities;

    public List<NamedResultEntity> getNamedEntities() {
        return namedEntities;
    }

    public void setNamedEntities(final List<NamedResultEntity> namedEntities) {
        this.namedEntities = namedEntities;
    }

    public static class NamedResultEntity {
        private List<String> types;

        private List<String> translation;

        public List<String> getTypes() {
            return types;
        }

        public void setTypes(final List<String> types) {
            this.types = types;
        }

        public List<String> getTranslation() {
            return translation;
        }

        public void setTranslation(final List<String> translation) {
            this.translation = translation;
        }

    }
}
