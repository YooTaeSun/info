package com.hyundaicard.cse.app.like.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hyundaicard.cse.app.like.entity.LikeCountEntity;
import com.hyundaicard.cse.app.like.entity.LikeEntity;
import com.hyundaicard.cse.app.like.mapper.LikeCountMapper;
import com.hyundaicard.cse.app.like.mapper.LikeMapper;
import com.hyundaicard.cse.app.log.entity.ClickEventLogEntity;
import com.hyundaicard.cse.app.log.entity.PsnlLogEntity;
import com.hyundaicard.cse.app.log.service.ClickEventLogService;
import com.hyundaicard.cse.app.log.service.PsnlLogService;
import com.hyundaicard.cse.constants.Constants;

/**
 * like Service
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Service
@Transactional
public class LikeService {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(LikeService.class);

    @Autowired
    private LikeMapper mapper;

    @Autowired
    private LikeCountMapper likeCountMapper;

    @Autowired
    private PsnlLogService psnlLogService;

    @Autowired
    private ClickEventLogService clickEventLogService;

    /**
     * 상세
     *
     * @Mehtod Name : get
     * @param entity
     * @return
     */
    public LikeEntity get(final LikeEntity entity) {
        return mapper.get(entity);
    }

    /**
     * 리스트
     *
     * @Mehtod Name : getList
     * @param entity
     * @return
     */
    public List<LikeEntity> getAllList(final LikeEntity entity) {
        return mapper.getAllList(entity);
    }

    /**
     * 입력
     *
     * @Mehtod Name : insert
     * @param entity
     * @return
     * @throws Exception
     */
    public LikeCountEntity insert(final LikeEntity entity) {
        mapper.insert(entity);

        // 개인화 이용 팬턴 로그 정보
        final PsnlLogEntity psnlLogParam = new PsnlLogEntity();
        psnlLogParam.setSiteKey(entity.getSiteKey());
        psnlLogParam.setLogTypeCd(Constants.TO_LIKE);
        psnlLogService.insert(psnlLogParam);

        final String isLogSave = entity.getIsLogSave();

        if (!isLogSave.equals("N")) {
            // 사이트 방문 클릭 이벤트 로그 정보
            final ClickEventLogEntity clickEventLogParam = new ClickEventLogEntity();
            clickEventLogParam.setQueryKeyword(entity.getQueryKeyword());
            clickEventLogParam.setQueryTypeCd(entity.getQueryTypeCd());
            clickEventLogParam.setPageInfo(entity.getPageInfo());
            clickEventLogParam.setItemCount(entity.getItemCount());
            clickEventLogParam.setItemPos(entity.getItemPos());
            clickEventLogParam.setClickItemType(entity.getClickItemType());
            clickEventLogParam.setSiteKey(entity.getSiteKey());
            clickEventLogService.insert(clickEventLogParam);
        }

        // TS_LIKE_SITE_CAT_COUNT_INFO 사이트회원좋아요카운트정보
        final LikeCountEntity param = new LikeCountEntity();
        param.setSiteKey(entity.getSiteKey());
        param.setCatKey(entity.getCatKey());
        likeCountMapper.insert(param);

        // if (true) {
        // throw new Exception();
        // }
        return likeCountMapper.get(param);
    }

    // /**
    // * 수정
    // *
    // * @Mehtod Name : insert
    // * @param entity
    // * @return
    // */
    // public void update(LikeEntity entity) {
    // mapper.update(entity);
    // }

    /**
     * 삭제
     *
     * @Mehtod Name : delete
     * @param entity
     * @return
     */
    public LikeCountEntity delete(final LikeEntity entity) {
        mapper.delete(entity);

        // 개인화 이용 팬턴 로그 정보
        final PsnlLogEntity psnlLogParam = new PsnlLogEntity();
        psnlLogParam.setSiteKey(entity.getSiteKey());
        psnlLogParam.setLogTypeCd(Constants.TO_LIKE);
        psnlLogService.update(psnlLogParam);

        final LikeCountEntity param = new LikeCountEntity();
        param.setSiteKey(entity.getSiteKey());
        param.setCatKey(entity.getCatKey());
        likeCountMapper.update(param);
        return likeCountMapper.get(param);
    }
}
