package com.hyundaicard.cse.app.mypage.mapper;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.hyundaicard.cse.app.mypage.entity.SaleInfoEntity;

/**
 * SaleInfo Mapper
 */
public interface SaleInfoMapper {

    /**
     * 할인정보 리스트조회
     */
    public List<SaleInfoEntity> getSaleInfoList(SaleInfoEntity saleInfoEntity) throws DataAccessException;

    public List<SaleInfoEntity> getAllList(SaleInfoEntity saleInfoEntity) throws DataAccessException;

    /**
     * 총갯수 조회
     */
    public int getCount(SaleInfoEntity saleInfoEntity) throws DataAccessException;

    public int getCountLikeSite(SaleInfoEntity saleInfoEntity) throws DataAccessException;

    /**
     * 최신등록된 세일정보
     * 
     * @param saleInfoEntity
     * @return
     * @throws DataAccessException
     */
    public Integer getCntInitSaleInfo(SaleInfoEntity saleInfoEntity) throws DataAccessException;
}
