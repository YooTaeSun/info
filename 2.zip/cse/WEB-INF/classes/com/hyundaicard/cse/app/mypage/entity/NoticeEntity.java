package com.hyundaicard.cse.app.mypage.entity;

import com.hyundaicard.cse.common.entity.AbstractPage;

/**
 * Notice Entity
 */
public class NoticeEntity extends AbstractPage {

    private int noticeSq;
    private String noticeCd;
    private String noticeNm;
    private String noticeDs;
    private String noticeMainImg;
    private String noticeDescImg;
    private String useButtonYn;
    private String buttonText;
    private String buttonLinkUrl;
    private int hitCnt;
    private String displayStrDt;
    private String displayEndDt;

    /** 새상품 유무 */
    private String newYn;

    private String memberIdSq;
    private String uuid;

    public int getNoticeSq() {
        return noticeSq;
    }

    public void setNoticeSq(final int noticeSq) {
        this.noticeSq = noticeSq;
    }

    public String getNoticeCd() {
        return noticeCd;
    }

    public void setNoticeCd(final String noticeCd) {
        this.noticeCd = noticeCd;
    }

    public String getNoticeNm() {
        return noticeNm;
    }

    public void setNoticeNm(final String noticeNm) {
        this.noticeNm = noticeNm;
    }

    public String getNoticeDs() {
        return noticeDs;
    }

    public void setNoticeDs(final String noticeDs) {
        this.noticeDs = noticeDs;
    }

    public String getNoticeMainImg() {
        return noticeMainImg;
    }

    public void setNoticeMainImg(final String noticeMainImg) {
        this.noticeMainImg = noticeMainImg;
    }

    public String getNoticeDescImg() {
        return noticeDescImg;
    }

    public void setNoticeDescImg(final String noticeDescImg) {
        this.noticeDescImg = noticeDescImg;
    }

    public String getUseButtonYn() {
        return useButtonYn;
    }

    public void setUseButtonYn(final String useButtonYn) {
        this.useButtonYn = useButtonYn;
    }

    public String getButtonText() {
        return buttonText;
    }

    public void setButtonText(final String buttonText) {
        this.buttonText = buttonText;
    }

    public String getButtonLinkUrl() {
        return buttonLinkUrl;
    }

    public void setButtonLinkUrl(final String buttonLinkUrl) {
        this.buttonLinkUrl = buttonLinkUrl;
    }

    public int getHitCnt() {
        return hitCnt;
    }

    public void setHitCnt(final int hitCnt) {
        this.hitCnt = hitCnt;
    }

    public String getDisplayStrDt() {
        return displayStrDt;
    }

    public void setDisplayStrDt(final String displayStrDt) {
        this.displayStrDt = displayStrDt;
    }

    public String getDisplayEndDt() {
        return displayEndDt;
    }

    public void setDisplayEndDt(final String displayEndDt) {
        this.displayEndDt = displayEndDt;
    }

    public String getNewYn() {
        return newYn;
    }

    public void setNewYn(final String newYn) {
        this.newYn = newYn;
    }

    public String getMemberIdSq() {
        return memberIdSq;
    }

    public void setMemberIdSq(final String memberIdSq) {
        this.memberIdSq = memberIdSq;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

}
