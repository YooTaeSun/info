package com.hyundaicard.cse.app.search.entity;

import java.util.List;

import com.hyundaicard.cse.app.bookmark.entity.BookmarkQueryEntity;

/**
 * Category List Entity
 * 
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public class CategorySearchResultEntity {

    private String id;
    private String ctg_meta_site_key;
    private String ctg_meta_site_cat_nm;
    private String ctg_meta_site_cat_url;
    private String ctg_meta_gender_tag;
    private String ctg_meta_brand_tag;
    private String ctg_meta_mood_tag;
    private int ctg_meta_prod_cnt;
    private int ctg_rank_score;
    private List<ProductResultEntity> products;
    private int _products_total_count;
    
    private List<BookmarkQueryEntity> bookmarkQueryList;    //custom
    
    // ------------------ custom add --------------------------
    private String ctg_is_like;
    private String likeSiteCatSq;
    private String ctg_cnt;
    private String ctg_is_bookmark;
    // ------------------------------------------------------------
    

    private boolean is_favorite;// custom 추가

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCtg_meta_site_key() {
        return ctg_meta_site_key;
    }

    public void setCtg_meta_site_key(String ctg_meta_site_key) {
        this.ctg_meta_site_key = ctg_meta_site_key;
    }

    public String getCtg_meta_site_cat_nm() {
        return ctg_meta_site_cat_nm;
    }

    public void setCtg_meta_site_cat_nm(String ctg_meta_site_cat_nm) {
        this.ctg_meta_site_cat_nm = ctg_meta_site_cat_nm;
    }

    public String getCtg_meta_site_cat_url() {
        return ctg_meta_site_cat_url;
    }

    public void setCtg_meta_site_cat_url(String ctg_meta_site_cat_url) {
        this.ctg_meta_site_cat_url = ctg_meta_site_cat_url;
    }

    public String getCtg_meta_gender_tag() {
        return ctg_meta_gender_tag;
    }

    public void setCtg_meta_gender_tag(String ctg_meta_gender_tag) {
        this.ctg_meta_gender_tag = ctg_meta_gender_tag;
    }

    public String getCtg_meta_brand_tag() {
        return ctg_meta_brand_tag;
    }

    public void setCtg_meta_brand_tag(String ctg_meta_brand_tag) {
        this.ctg_meta_brand_tag = ctg_meta_brand_tag;
    }

    public String getCtg_meta_mood_tag() {
        return ctg_meta_mood_tag;
    }

    public void setCtg_meta_mood_tag(String ctg_meta_mood_tag) {
        this.ctg_meta_mood_tag = ctg_meta_mood_tag;
    }

    public int getCtg_meta_prod_cnt() {
        return ctg_meta_prod_cnt;
    }

    public void setCtg_meta_prod_cnt(int ctg_meta_prod_cnt) {
        this.ctg_meta_prod_cnt = ctg_meta_prod_cnt;
    }

    public int getCtg_rank_score() {
        return ctg_rank_score;
    }

    public void setCtg_rank_score(int ctg_rank_score) {
        this.ctg_rank_score = ctg_rank_score;
    }

    public List<ProductResultEntity> getProducts() {
        return products;
    }

    public void setProducts(List<ProductResultEntity> products) {
        this.products = products;
    }

    public boolean isIs_favorite() {
        return is_favorite;
    }

    public void setIs_favorite(boolean is_favorite) {
        this.is_favorite = is_favorite;
    }

    public int get_products_total_count() {
        return _products_total_count;
    }

    public void set_products_total_count(int _products_total_count) {
        this._products_total_count = _products_total_count;
    }

    public List<BookmarkQueryEntity> getBookmarkQueryList() {
        return bookmarkQueryList;
    }

    public void setBookmarkQueryList(List<BookmarkQueryEntity> bookmarkQueryList) {
        this.bookmarkQueryList = bookmarkQueryList;
    }

    public String getCtg_is_like() {
        return ctg_is_like;
    }

    public void setCtg_is_like(String ctg_is_like) {
        this.ctg_is_like = ctg_is_like;
    }

    public String getLikeSiteCatSq() {
        return likeSiteCatSq;
    }

    public void setLikeSiteCatSq(String likeSiteCatSq) {
        this.likeSiteCatSq = likeSiteCatSq;
    }

    public String getCtg_cnt() {
        return ctg_cnt;
    }

    public void setCtg_cnt(String ctg_cnt) {
        this.ctg_cnt = ctg_cnt;
    }

    public String getCtg_is_bookmark() {
        return ctg_is_bookmark;
    }

    public void setCtg_is_bookmark(String ctg_is_bookmark) {
        this.ctg_is_bookmark = ctg_is_bookmark;
    }

}
