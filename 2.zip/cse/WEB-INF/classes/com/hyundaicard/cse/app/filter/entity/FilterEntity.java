package com.hyundaicard.cse.app.filter.entity;

import java.util.List;

/**
 * 검색필터 Entity
 * 
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public class FilterEntity {

    private String fltgrpCd; // 검색필터 그룹코드
    private String fltgrpNm; // 검색필터 그룹명
    private String fltgrpDs; // 검색필터 그룹설명

    private String fltcodeCd; // 검색필터 코드
    private String fltcodeNm; // 검색필터 코드명
    private String fltcodeDs; // 검색필터 코드설명
    private String useYn; // 사용여부
    private String orderNo; // 정렬순서

    private List<String> fltgrpCdList;

    public String getFltgrpCd() {
        return fltgrpCd;
    }

    public void setFltgrpCd(String fltgrpCd) {
        this.fltgrpCd = fltgrpCd;
    }

    public String getFltgrpNm() {
        return fltgrpNm;
    }

    public void setFltgrpNm(String fltgrpNm) {
        this.fltgrpNm = fltgrpNm;
    }

    public String getFltgrpDs() {
        return fltgrpDs;
    }

    public void setFltgrpDs(String fltgrpDs) {
        this.fltgrpDs = fltgrpDs;
    }

    public String getFltcodeCd() {
        return fltcodeCd;
    }

    public void setFltcodeCd(String fltcodeCd) {
        this.fltcodeCd = fltcodeCd;
    }

    public String getFltcodeNm() {
        return fltcodeNm;
    }

    public void setFltcodeNm(String fltcodeNm) {
        this.fltcodeNm = fltcodeNm;
    }

    public String getFltcodeDs() {
        return fltcodeDs;
    }

    public void setFltcodeDs(String fltcodeDs) {
        this.fltcodeDs = fltcodeDs;
    }

    public String getUseYn() {
        return useYn;
    }

    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public List<String> getFltgrpCdList() {
        return fltgrpCdList;
    }

    public void setFltgrpCdList(List<String> fltgrpCdList) {
        this.fltgrpCdList = fltgrpCdList;
    }
}
