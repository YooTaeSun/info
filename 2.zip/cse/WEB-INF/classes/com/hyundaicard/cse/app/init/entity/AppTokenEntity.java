package com.hyundaicard.cse.app.init.entity;

import com.hyundaicard.cse.common.entity.AbstractPage;

/**
 * UpdateInfo Entity
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public class AppTokenEntity extends AbstractPage {

    private String osType;
    private String uuid;
    private String appToken;
    private String receiveYN;

    public String getOsType() {
        return osType;
    }

    public void setOsType(final String osType) {
        this.osType = osType;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    public String getAppToken() {
        return appToken;
    }

    public void setAppToken(final String appToken) {
        this.appToken = appToken;
    }

    public String getReceiveYN() {
        return receiveYN;
    }

    public void setReceiveYN(final String receiveYN) {
        this.receiveYN = receiveYN;
    }

    @Override
    public String toString() {
        return "AppTokenEntity [osType=" + osType + ", uuid=" + uuid + ", appToken=" + appToken + ", receiveYN="
                + receiveYN + "]";
    }

}
