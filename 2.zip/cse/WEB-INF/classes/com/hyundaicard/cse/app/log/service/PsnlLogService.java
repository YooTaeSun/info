package com.hyundaicard.cse.app.log.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.bookmark.service.SessionService;
import com.hyundaicard.cse.app.log.entity.PsnlLogEntity;
import com.hyundaicard.cse.app.log.mapper.PsnlLogMapper;

/**
 * psnlLog Service
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Service
public class PsnlLogService {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(PsnlLogService.class);

    @Autowired
    private PsnlLogMapper mapper;

    @Autowired
    private SessionService sessionService;

    /**
     * 입력
     *
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public void insert(final PsnlLogEntity entity) {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        final String uuid = sessionService.getAttribute("uuid");
        entity.setMemberIdSq(memberIdSq);
        entity.setUuid(uuid);

        mapper.insertFnCall(entity);
    }

    /**
     * 수정
     *
     * @Mehtod Name : update
     * @param entity
     * @return
     */
    public void update(final PsnlLogEntity entity) {
        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        final String uuid = sessionService.getAttribute("uuid");
        entity.setMemberIdSq(memberIdSq);
        entity.setUuid(uuid);
        mapper.updateFnCall(entity);
    }

    /**
     * 로고형 list
     *
     * @Mehtod Name : getLankSite
     * @param entity
     * @return
     */
    public List<PsnlLogEntity> getLankSite(final PsnlLogEntity entity) {
        return mapper.getLankSite(entity);
    }

    /**
     * 로고형 점수
     *
     * @Mehtod Name : getLankSite
     * @param entity
     * @return
     */
    public int getTotalFinalScore(final PsnlLogEntity entity) {
        return mapper.getTotalFinalScore(entity);
    }

}
