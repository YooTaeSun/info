package com.hyundaicard.cse.app.main.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hyundaicard.cse.app.like.entity.LikeEntity;
import com.hyundaicard.cse.app.main.entity.HotKeywordEntity;
import com.hyundaicard.cse.app.main.entity.SearchWordEntity;
import com.hyundaicard.cse.app.main.service.MainService;
import com.hyundaicard.cse.common.annotation.CheckAutoLogin;
import com.hyundaicard.cse.common.code.ResultCode;
import com.hyundaicard.cse.common.entity.RestRespEntity;
import com.hyundaicard.cse.common.util.CommonUtil;
import com.hyundaicard.cse.common.util.Config;
import com.hyundaicard.cse.common.util.StringUtil;

/**
 * Handles requests for the application home page.
 */
@Controller
public class MainController {

    private static final Logger logger = LoggerFactory.getLogger(MainController.class);

    @Autowired
    private MainService service;

    /**
     * Simply selects the home view to render by returning its name.
     */
    @RequestMapping(value = "/main/main0101", method = RequestMethod.GET)
    @CheckAutoLogin(isCheck = false)
    public String main0101(@ModelAttribute final SearchWordEntity entity, final Locale locale, final Model model) {
        logger.info(">>>main0101");

        final List<Object> hotKeyList = service.getHotKeyList();
        if (hotKeyList.isEmpty()) {
            hotKeyList.clear();
            hotKeyList.add(this.getHotKeyDefault("가죽자켓", "레이스원피스", "버버리트렌치코트", "맨투맨", "슬립온"));
            hotKeyList.add(this.getHotKeyDefault("백팩", "후드집업", "찢어진청바지", "입생로랑클러치", "노스페이스등산화"));
            hotKeyList.add(this.getHotKeyDefault("니트가디건", "구찌로퍼", "체크셔츠", "캡모자", "프린트스카프"));
        }
        // 인기검색어 리스트
        model.addAttribute("hotKeywordList", hotKeyList);
        // logo Img
        final String logoImg = service.getLogoImg();
        model.addAttribute("logoImg", logoImg);
        // 현재 날째 시간
        model.addAttribute("curDate", service.getDate("%y.%m.%d"));

        // 검색form modelAttribute
        model.addAttribute("searchWordEntity", new SearchWordEntity());

        FileInputStream fis = null;

        try {
            final String dataCountPath = Config.getCommon().getString("DATA_COUNT_LOCATION");
            final Properties props = new Properties();

            fis = new FileInputStream(dataCountPath);

            props.load(new java.io.BufferedInputStream(fis));

            final String dataCount = props.getProperty("DATA_COUNT");

            model.addAttribute("dataCount", StringUtil.makeNumberFormat(dataCount));

        } catch (final Exception e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (final IOException e) {
                    e.printStackTrace();
                }
            }
        }

        logger.info("<<<main0101");

        return "main/main0101";

    }

    @RequestMapping(value = "/main/dataCount", method = RequestMethod.POST)
    @CheckAutoLogin(isCheck = false)
    public ResponseEntity dataCount(@ModelAttribute final LikeEntity entity, final Model model) {

        final RestRespEntity restRespEntity = new RestRespEntity();
        FileInputStream fis = null;
        try {
            final String dataCountPath = Config.getCommon().getString("DATA_COUNT_LOCATION");
            final Properties props = new Properties();
            fis = new FileInputStream(dataCountPath);
            props.load(new java.io.BufferedInputStream(fis));
            final String dataCount = props.getProperty("DATA_COUNT");
            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity),
                    StringUtil.makeNumberFormat(dataCount));
        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (final IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private List<HotKeywordEntity> getHotKeyDefault(final String val1, final String val2, final String val3,
            final String val4, final String val5) {
        final List<HotKeywordEntity> returnList = new ArrayList<HotKeywordEntity>();

        returnList.add(new HotKeywordEntity(val1));
        returnList.add(new HotKeywordEntity(val2));
        returnList.add(new HotKeywordEntity(val3));
        returnList.add(new HotKeywordEntity(val4));
        returnList.add(new HotKeywordEntity(val5));

        return returnList;
    }
}
