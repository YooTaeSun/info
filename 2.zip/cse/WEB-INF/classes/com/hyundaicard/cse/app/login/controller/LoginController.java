package com.hyundaicard.cse.app.login.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hyundaicard.cse.app.bookmark.service.BookmarkService;
import com.hyundaicard.cse.app.login.entity.AutoLoginEntity;
import com.hyundaicard.cse.app.login.entity.UserEntity;
import com.hyundaicard.cse.app.login.service.LoginService;
import com.hyundaicard.cse.app.mypage.entity.SaleInfoEntity;
import com.hyundaicard.cse.app.mypage.service.SaleInfoService;
import com.hyundaicard.cse.common.constants.SessionConstants;
import com.hyundaicard.cse.common.controller.CseAppController;
import com.hyundaicard.cse.common.exception.BizException;
import com.hyundaicard.cse.common.util.DateUtil;
import com.hyundaicard.cse.common.util.GenerateKeyUtil;
import com.hyundaicard.cse.common.view.Request;

/**
 * 로그인
 */
@Controller
public class LoginController extends CseAppController {

    private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

    @Autowired
    private LoginService loginService;

    @Autowired
    private BookmarkService bookmarkService;

    @Autowired
    private SaleInfoService saleInfoService;

    /******** 시연용 API **********/
    /**
     * 로그인 페이지 진입
     */
    @RequestMapping(value = "/login/login0101", method = RequestMethod.GET)
    public String login0101(final Model model) {
        logger.info(">>>login0101");

        // 사용 가능한 ID 리스트 조회
        // List<UserEntity> userIdList = service.getUserIdList();

        // logger.debug(userIdList.toString());

        /** 시연 대상 ID list - start */
        final List<UserEntity> userIdList = new ArrayList<UserEntity>();

        for (int i = 1; i < 6; i++) {
            final UserEntity userEntity = new UserEntity();
            userEntity.setUserId(i + "");
            userIdList.add(userEntity);
        }

        /** 시연 대상 ID list - end */

        model.addAttribute("userIdList", userIdList);
        // 로그인form modelAttribute
        model.addAttribute("userEntity", new UserEntity());

        logger.info("<<<login0101");

        return "login/login0101";

    }

    /**
     * 로그인 처리
     */
    @RequestMapping(value = "/login/login0102", method = RequestMethod.GET)
    public String login0102(@ModelAttribute final UserEntity userEntity, final HttpSession session, final Model model) {
        logger.info(">>>login0102");
        // 입력받은 ID로 회원정보 조회
        // UserEntity userInfo = service.getUserInfo(userEntity);
        /** 시연 대상 ID 로그인 처리 */
        final UserEntity userInfo = userEntity;

        logger.debug(userInfo.toString());

        session.setAttribute("userId", userInfo.getUserId());

        logger.info("<<<login0102");

        return "redirect:/main/main0101";

    }

    /**
     * 로그인 처리
     */
    @RequestMapping(value = "/api/login/tempLogin", method = RequestMethod.POST)
    public ModelAndView tempLogin(final HttpServletRequest httpServletRequest,
            final HttpServletResponse httpServletResponse, final Request request) throws Exception {
        logger.info(">>>>login0101");

        final JSONObject requestJson = request.getRequestBodyJson();
        final JSONObject responseJson = new JSONObject();

        final String userId = requestJson.optString("userId", "");
        final String uuid = requestJson.optString("uuid", "");

        UserEntity userEntity = new UserEntity();
        userEntity.setUserId(userId);
        // userEntity.setUuid(uuid);

        userEntity = loginService.tempGetUserInfo(userEntity);

        /**
         * 1. userId에 해당하는 회원 없을경우 -> error
         *
         * 2. userId는 동일하고 UUID 다른경우 -> UUID 갱신
         *
         * 3. userId일치하고 UUID 일치하는 경우 -> 정상 로그인
         */

        /** userId가 일치하는 고객이 없을경우 */
        if (userEntity == null) {
            // 오류상황
            throw new BizException(messageSource, "LOGIN0003", Locale.getDefault());
        }

        /** userId에 해당하는 UUID가 입력받은 값과 일치하지 않을 경우 */
        if (!userEntity.getUuid().equals(uuid)) {
            /** UUID로 갱신하고 로그인 처리 */
            userEntity.setUuid(uuid);
            loginService.updateUserUuid(userEntity);
        } else {
            /** 정상 로그인 */
        }

        /** 로그인 처리 */
        httpServletRequest.getSession().setAttribute("memberIdSq", userEntity.getMemberIdSq());
        httpServletRequest.getSession().setAttribute("userId", userEntity.getUserId());
        // TODO:임시 회원고객번호 반영 (memberIdSq % 200)

        int customerNo = Integer.parseInt(userEntity.getCustomerNo().substring(userEntity.getCustomerNo().length() - 3,
                userEntity.getCustomerNo().length())) % 200;

        if (userId.length() > 2) {
            final String tempNo = userId.substring(userId.length() - 3, userId.length());

            final Pattern p = Pattern.compile(".*[^0-9].*");
            final Matcher m = p.matcher(tempNo);

            if (!m.matches()) {
                customerNo = Integer.parseInt(tempNo) % 200;
            }
        }
        //

        httpServletRequest.getSession().setAttribute("customerNo", customerNo + "");
        httpServletRequest.getSession().setAttribute("uuid", userEntity.getUuid());
        httpServletRequest.getSession().setAttribute("hccAuthYN", userEntity.getHccAuthYN());

        /**
         * 자동로그인 처리 및 구분
         *
         * Cookie에 인증토큰 생성하여 setting
         *
         * 로그인 인증 테이블에 로그인 정보 insert / update
         */
        final String loginAuthToken = GenerateKeyUtil.getRandomString(6) + DateUtil.getCurrentDate()
                + DateUtil.getCurrentTime();
        final Cookie cookie = new Cookie("HC3", loginAuthToken);
        cookie.setPath("/");
        httpServletResponse.addCookie(cookie);

        final AutoLoginEntity autoLoginEntity = new AutoLoginEntity();
        final String serverSeedKey = (String) httpServletRequest.getSession()
                .getAttribute(SessionConstants.SERVER_SEED_KEY);
        final String serverSeedIV = (String) httpServletRequest.getSession()
                .getAttribute(SessionConstants.SERVER_SEED_IV);
        autoLoginEntity.setLoginId(userEntity.getUserId());
        autoLoginEntity.setUuid(userEntity.getUuid());
        autoLoginEntity.setLoginAuthToken(loginAuthToken);
        autoLoginEntity.setHc1(serverSeedKey);
        autoLoginEntity.setHc2(serverSeedIV);

        loginService.updateAutoLoginInfo(autoLoginEntity);

        responseJson.put("hccAuthYN", userEntity.getHccAuthYN());

        logger.info("<<<<login0101");

        return createResponseModelAndView(httpServletRequest, httpServletResponse, request, responseJson);
    }

    /******** 시연용 API **********/

    /**
     * 로그인 처리
     */
    @RequestMapping(value = "/api/login/login0101", method = RequestMethod.POST)
    public ModelAndView login0101(final HttpServletRequest httpServletRequest,
            final HttpServletResponse httpServletResponse, final Request request) throws Exception {
        logger.info(">>>>login0101");

        // 인증시 획득한 고객번호 세션에서 삭제
        httpServletRequest.getSession().setAttribute("authCustomerNo", null);

        final JSONObject requestJson = request.getRequestBodyJson();
        final JSONObject responseJson = new JSONObject();

        final String userId = requestJson.optString("userId", "");
        final String uuid = requestJson.optString("uuid", "");

        UserEntity userEntity = new UserEntity();
        userEntity.setUserId(userId);
        // userEntity.setUuid(uuid);

        userEntity = loginService.getUserInfo(userEntity);

        /**
         * 1. userId에 해당하는 회원 없을경우 -> error
         *
         * 2. userId는 동일하고 UUID 다른경우 -> UUID 갱신
         *
         * 3. userId일치하고 UUID 일치하는 경우 -> 정상 로그인
         */

        /** userId가 일치하는 고객이 없을경우 */
        if (userEntity == null) {
            // 오류상황
            throw new BizException(messageSource, "LOGIN0003", Locale.getDefault());
        }

        /** userId에 해당하는 UUID가 입력받은 값과 일치하지 않을 경우 */
        if (!userEntity.getUuid().equals(uuid)) {
            /** UUID로 갱신하고 로그인 처리 */
            userEntity.setUuid(uuid);
            loginService.updateUserUuid(userEntity);
        } else {
            /** 정상 로그인 */
        }

        /** 로그인 시간 업데이트 */
        loginService.updateLastLoginDate(userEntity);

        /** 로그인 처리 */
        httpServletRequest.getSession().setAttribute("memberIdSq", userEntity.getMemberIdSq());
        httpServletRequest.getSession().setAttribute("userId", userEntity.getUserId());
        if (userEntity.getCustomerNo() != null && userEntity.getCustomerNo().length() > 0) {
            httpServletRequest.getSession().setAttribute("customerNo", userEntity.getCustomerNo());
        }
        httpServletRequest.getSession().setAttribute("uuid", userEntity.getUuid());
        httpServletRequest.getSession().setAttribute("hccAuthYN", userEntity.getHccAuthYN());

        /**
         * 자동로그인 처리 및 구분
         *
         * Cookie에 인증토큰 생성하여 setting
         *
         * 로그인 인증 테이블에 로그인 정보 insert / update
         */
        final String loginAuthToken = GenerateKeyUtil.getRandomString(6) + DateUtil.getCurrentDate()
                + DateUtil.getCurrentTime();
        final Cookie cookie = new Cookie("HC3", loginAuthToken);
        cookie.setPath("/");
        httpServletResponse.addCookie(cookie);

        final AutoLoginEntity autoLoginEntity = new AutoLoginEntity();
        final String serverSeedKey = (String) httpServletRequest.getSession()
                .getAttribute(SessionConstants.SERVER_SEED_KEY);
        final String serverSeedIV = (String) httpServletRequest.getSession()
                .getAttribute(SessionConstants.SERVER_SEED_IV);
        autoLoginEntity.setLoginId(userEntity.getUserId());
        autoLoginEntity.setUuid(userEntity.getUuid());
        autoLoginEntity.setLoginAuthToken(loginAuthToken);
        autoLoginEntity.setHc1(serverSeedKey);
        autoLoginEntity.setHc2(serverSeedIV);

        loginService.updateAutoLoginInfo(autoLoginEntity);

        /** 북마크 사이트 새상품 갯수 (뱃지 노출) */
        int newProductCount = 0;
        newProductCount = bookmarkService.getNewProductCnt();
        responseJson.put("newProductCount", newProductCount);
        responseJson.put("newProductYN", newProductCount == 0 ? "N" : "Y");

        /** 할인정보 새로운 정보 여부 조회 (뱃지 노출) */
        final SaleInfoEntity sEntity = new SaleInfoEntity();
        sEntity.setUuid(uuid);
        final int sCount = saleInfoService.getCntInitSaleInfo(sEntity);
        responseJson.put("newSaleInfoCount", sCount);

        responseJson.put("hccAuthYN", userEntity.getHccAuthYN());

        logger.info("<<<<login0101");

        return createResponseModelAndView(httpServletRequest, httpServletResponse, request, responseJson);
    }

}
