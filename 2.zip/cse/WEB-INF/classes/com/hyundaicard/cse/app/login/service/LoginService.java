package com.hyundaicard.cse.app.login.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.login.entity.AutoLoginEntity;
import com.hyundaicard.cse.app.login.entity.UserEntity;
import com.hyundaicard.cse.app.login.mapper.LoginMapper;

/**
 * Login Service 로그인 Service
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
@Service
public class LoginService {

    /** Mapper */
    @Autowired
    private LoginMapper mapper;

    public List<UserEntity> getUserIdList() {
        return mapper.getUserIdList();
    }

    public UserEntity getUserInfo(final UserEntity entity) {
        return mapper.getUserInfo(entity);
    }

    public UserEntity tempGetUserInfo(final UserEntity entity) {
        return mapper.tempGetUserInfo(entity);
    }

    public void updateUserUuid(final UserEntity entity) {
        mapper.updateUserUuid(entity);
    }

    public void updateLastLoginDate(final UserEntity entity) {
        mapper.updateLastLoginDate(entity);
    }

    public void updateAutoLoginInfo(final AutoLoginEntity entity) {
        mapper.updateAutoLoginInfo(entity);
    }

    public AutoLoginEntity getAutoLoginInfo(final AutoLoginEntity entity) {
        return mapper.getAutoLoginInfo(entity);
    }
}
