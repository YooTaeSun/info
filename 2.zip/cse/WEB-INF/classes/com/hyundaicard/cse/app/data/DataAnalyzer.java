package com.hyundaicard.cse.app.data;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Properties;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hyundaicard.cse.common.util.Config;
import com.hyundaicard.cse.common.util.DateUtil;

@Component
public class DataAnalyzer {

    // private static final Logger logger = LoggerFactory.getLogger(DataAnalyzer.class);

    @Scheduled(fixedDelay = 1000 * 3) // 3초
    public void dataAnalyzer() {

        final String dataCountPath = Config.getCommon().getString("DATA_COUNT_LOCATION");
        FileInputStream fis = null;
        FileOutputStream out = null;

        try {
            final Properties props = new Properties();
            fis = new FileInputStream(dataCountPath);

            props.load(new java.io.BufferedInputStream(fis));

            double dataCount = Double.parseDouble(props.getProperty("DATA_COUNT"));

            final NumberFormat formatter = new DecimalFormat("#");

            // logger.debug("current Count : " + formatter.format(dataCount));

            final int currentTime = Integer.parseInt(DateUtil.getCurrentTime());

            if (currentTime < 65959) { // 현재 시간이 오전 7시 이전일 경우
                dataCount += (int) ((Math.random() * 18) + 45); // 45 ~ 63 중 랜덤한 수
            } else {
                dataCount += (int) ((Math.random() * 30) + 99); // 99 ~ 129 중 랜덤한 수
            }

            // logger.debug("update Count : " + formatter.format(dataCount));

            props.put("DATA_COUNT", formatter.format(dataCount));

            out = new FileOutputStream(dataCountPath);
            props.store(out, "update Data Count");
            out.close();

        } catch (final Exception e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (final IOException e) {
                    e.printStackTrace();
                }
            }

            if (out != null) {
                try {
                    out.close();
                } catch (final IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // @Scheduled(fixedDelay = 1000 * 3) // 3초
    // public void dataAnalyzer() {
    //
    // try {
    //
    // double dataCount = Double
    // .parseDouble(StringUtils.defaultIfEmpty(dataAnalyzeService.getAnalyzeDataCount(), "2001072356"));
    //
    // final NumberFormat formatter = new DecimalFormat("#");
    //
    // // logger.debug("current Count : " + formatter.format(dataCount));
    //
    // final int currentTime = Integer.parseInt(DateUtil.getCurrentTime());
    //
    // if (currentTime < 65959) { // 현재 시간이 오전 7시 이전일 경우
    // dataCount += (int) ((Math.random() * 18) + 45); // 45 ~ 63 중 랜덤한 수
    // } else {
    // dataCount += (int) ((Math.random() * 30) + 99); // 99 ~ 129 중 랜덤한 수
    // }
    //
    // // logger.debug("update Count : " + formatter.format(dataCount));
    //
    // dataAnalyzeService.updateAnalyzeDataCount(String.valueOf(formatter.format(dataCount)));
    //
    // } catch (final Exception e) {
    // e.printStackTrace();
    // }
    // }
}
