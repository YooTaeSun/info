package com.hyundaicard.cse.app.question.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.question.entity.QuestionEntity;
import com.hyundaicard.cse.app.question.mapper.AnswerMapper;
import com.hyundaicard.cse.app.question.mapper.QuestionMapper;

/**
 * Terms Service
 */
@Service
public class QuestionService {

    /** Mapper */
    @Autowired
    private QuestionMapper questionMapper;

    @Autowired
    private AnswerMapper answerMapper;

    public List<QuestionEntity> getQueList() {
        final List<QuestionEntity> queList = questionMapper.getQueList();

        for (int i = 0; i < queList.size(); i++) {
            final QuestionEntity inEntity = queList.get(i);
            if (!inEntity.getAnswerTypeCd().equals("30")) { // 주관식이 아닐
                inEntity.setChoiceList(questionMapper.getChoiceList(inEntity));
                queList.set(i, inEntity);
            }
        }

        return queList;
    }

}
