package com.hyundaicard.cse.app.search.entity;

import java.util.List;

/**
 * 인기있는 Site List Entity
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
@SuppressWarnings("rawtypes")
public class CategoryResultEntity {

    private Data data;

    public Data getData() {
        return data;
    }

    public void setData(final Data data) {
        this.data = data;
    }

    public static class Data {
        private List<CategorySearchResultEntity> rows;
        private RangeResultEntity range;

        public List<CategorySearchResultEntity> getRows() {
            return rows;
        }

        public void setRows(final List<CategorySearchResultEntity> rows) {
            this.rows = rows;
        }

        public RangeResultEntity getRange() {
            return range;
        }

        public void setRange(final RangeResultEntity range) {
            this.range = range;
        }

    }
}
