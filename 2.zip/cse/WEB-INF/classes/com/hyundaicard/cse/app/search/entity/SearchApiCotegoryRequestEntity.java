package com.hyundaicard.cse.app.search.entity;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * 검색 DetailProduct Request Entity
 * 
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public class SearchApiCotegoryRequestEntity {

    @NotEmpty
    private String siteCategoryKey;
    @NotEmpty
    private int size;
    
    private String siteCategoryKeys; //custom

    public String getSiteCategoryKey() {
        return siteCategoryKey;
    }

    public void setSiteCategoryKey(String siteCategoryKey) {
        this.siteCategoryKey = siteCategoryKey;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getSiteCategoryKeys() {
        return siteCategoryKeys;
    }

    public void setSiteCategoryKeys(String siteCategoryKeys) {
        this.siteCategoryKeys = siteCategoryKeys;
    }
}
