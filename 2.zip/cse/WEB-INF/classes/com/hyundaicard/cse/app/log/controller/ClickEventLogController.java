package com.hyundaicard.cse.app.log.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;

/**
 * click event log Controller
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Controller
@SuppressWarnings("rawtypes")
public class ClickEventLogController {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(ClickEventLogController.class);

}
