package com.hyundaicard.cse.app.question.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.question.entity.AnswerDetailEntity;
import com.hyundaicard.cse.app.question.entity.AnswerEntity;
import com.hyundaicard.cse.app.question.entity.SurveyTagEntity;
import com.hyundaicard.cse.app.question.mapper.AnswerMapper;

/**
 * Terms Service
 */
@Service
public class AnswerService {

    @Autowired
    private AnswerMapper answerMapper;

    public int getAnswerCnt(final AnswerEntity entity) {
        return answerMapper.getAnswerCnt(entity);
    }

    public List<AnswerDetailEntity> getAnswerList(final AnswerEntity entity) {
        return answerMapper.getAnswerList(entity);
    }

    public void insert(final AnswerEntity entity) {
        answerMapper.insert(entity);
    }

    public int insertDetail(final AnswerDetailEntity entity) {
        return answerMapper.insertDetail(entity);
    }

    public List<SurveyTagEntity> getTagList(final SurveyTagEntity entity) {
        return answerMapper.getTagList(entity);
    }
}
