package com.hyundaicard.cse.app.log.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.bookmark.service.SessionService;
import com.hyundaicard.cse.app.log.entity.ClickEventLogEntity;
import com.hyundaicard.cse.app.log.entity.PsnlLogEntity;
import com.hyundaicard.cse.app.log.entity.SearchNoResultLogEntity;
import com.hyundaicard.cse.app.log.entity.SearchQueryLogEntity;
import com.hyundaicard.cse.app.search.entity.NewPopularResultEntity;
import com.hyundaicard.cse.app.search.entity.PersonalResultEntity;
import com.hyundaicard.cse.app.search.entity.PopularResultEntity;
import com.hyundaicard.cse.app.search.entity.RangeResultEntity;
import com.hyundaicard.cse.constants.Constants;

/**
 * Log Service
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Service
public class LogService {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(LogService.class);

    @Autowired
    private PsnlLogService psnlLogService;

    @Autowired
    private ClickEventLogService clickEventLogService;

    @Autowired
    private SearchNoResultLogService searchNoResultLogService;

    @Autowired
    private SearchQueryLogService searchQueryLogService;

    @Autowired
    private SessionService sessionService;

    /**
     * 입력
     *
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public void insertClickEvent(final ClickEventLogEntity entity) {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        final String uuid = sessionService.getAttribute("uuid");
        entity.setMemberIdSq(memberIdSq);
        entity.setUuid(uuid);

        // 개인화 이용 팬턴 로그 정보
        final PsnlLogEntity psnlLogParam = new PsnlLogEntity();
        psnlLogParam.setSiteKey(entity.getSiteKey());
        psnlLogParam.setLogTypeCd(Constants.TO_CLICK);
        psnlLogService.insert(psnlLogParam);

        final String isLogSave = entity.getIsLogSave();

        if (!isLogSave.equals("N")) {
            // 사이트 방문 클릭 이벤트 로그 정보
            final ClickEventLogEntity clickEventLogParam = new ClickEventLogEntity();
            clickEventLogParam.setQueryKeyword(entity.getQueryKeyword());
            clickEventLogParam.setQueryTypeCd(entity.getQueryTypeCd());
            clickEventLogParam.setPageInfo(entity.getPageInfo());
            clickEventLogParam.setItemCount(entity.getItemCount());
            clickEventLogParam.setItemPos(entity.getItemPos());
            clickEventLogParam.setClickItemType(entity.getClickItemType());
            clickEventLogParam.setSiteKey(entity.getSiteKey());
            clickEventLogService.insert(clickEventLogParam);
        }
    }

    /**
     * 입력
     *
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public void insertSearchQuery(final String queryTypeCd, final String query, final Object obj) {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        final String uuid = sessionService.getAttribute("uuid");
        RangeResultEntity range = null;

        if (obj instanceof PopularResultEntity) {
            final PopularResultEntity result = (PopularResultEntity) obj;
            final com.hyundaicard.cse.app.search.entity.PopularResultEntity.Data data = result.getData();
            range = data.getRange();
        } else if (obj instanceof NewPopularResultEntity) {
            final NewPopularResultEntity result = (NewPopularResultEntity) obj;
            final com.hyundaicard.cse.app.search.entity.NewPopularResultEntity.Data data = result.getData();
            range = data.getRange();
        } else if (obj instanceof PersonalResultEntity) {
            final PersonalResultEntity result = (PersonalResultEntity) obj;
            final com.hyundaicard.cse.app.search.entity.PersonalResultEntity.Data data = result.getData();
            range = data.getRange();
        }

        final int total = range.getTotal();

        // 검색어 결과 없음 로그 정보 (TS_LOG_SEARCH_QUERY_INFO)
        if (total == 0) {
            final SearchNoResultLogEntity param = new SearchNoResultLogEntity();
            param.setQueryKeyword(query);
            param.setQueryTypeCd(queryTypeCd);
            param.setMemberIdSq(memberIdSq);
            param.setUuid(uuid);
            param.setSessionId(sessionService.getAttribute("sessionId"));
            searchNoResultLogService.insert(param);

            // 검색어 로그 정보 (TS_LOG_SEARCH_QUERY_INFO)
        } else {
            final SearchQueryLogEntity param = new SearchQueryLogEntity();
            param.setQueryKeyword(query);
            param.setQueryTypeCd(queryTypeCd);
            param.setItemCount(String.valueOf(total));
            param.setMemberIdSq(memberIdSq);
            param.setUuid(uuid);
            param.setSessionId(sessionService.getAttribute("sessionId"));
            searchQueryLogService.insert(param);
        }
    }

    /**
     * 입력
     *
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public void insertSearchNoQuery(final String query, final String queryTypeCd) {
        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        final String uuid = sessionService.getAttribute("uuid");

        // logger.debug(" queryTypeCd : {} ", queryTypeCd);
        // logger.debug(" insertSearchNoQuery sessionId : {} ", sessionService.getAttribute("sessionId"));

        final SearchNoResultLogEntity param = new SearchNoResultLogEntity();
        param.setQueryKeyword(query);
        param.setQueryTypeCd(queryTypeCd);
        param.setMemberIdSq(memberIdSq);
        param.setUuid(uuid);
        param.setSessionId(sessionService.getAttribute("sessionId"));
        searchNoResultLogService.insert(param);
    }

}
