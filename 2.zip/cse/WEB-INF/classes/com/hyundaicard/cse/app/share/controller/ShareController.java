package com.hyundaicard.cse.app.share.controller;

import java.io.File;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hyundaicard.cse.app.share.entity.ShareEntity;
import com.hyundaicard.cse.app.share.service.ShareService;
import com.hyundaicard.cse.common.code.ResultCode;
import com.hyundaicard.cse.common.entity.RestRespEntity;
import com.hyundaicard.cse.common.util.CommonUtil;

/**
 * share Controller
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
@Controller
@SuppressWarnings("rawtypes")
public class ShareController {

    /** Logger */
    private static final Logger logger = LoggerFactory.getLogger(ShareController.class);

    @Autowired
    private ShareService shareService;

    @Autowired
    private ShareService service;

    /**
     * share query view move
     *
     * @Mehtod Name : view @return String @throws
     */
    @RequestMapping(value = "/share/{path1}/{path2}", method = RequestMethod.GET)
    public String share(@PathVariable("path1") final String path1, @PathVariable("path2") final String path2, @ModelAttribute final ShareEntity entity, final Model model) {

        if (!StringUtils.isBlank(path1) && !StringUtils.isBlank(path2)) {
            final ShareEntity param = new ShareEntity();
            param.setShortenUrl(path1 + File.separator + path2);
            final ShareEntity share = shareService.get(param);
            model.addAttribute("url", share.getRealUrl());
        }
        return "share/landing";
    }

    /**
     * share insert
     *
     * @Mehtod Name : insert @return ResponseEntity @throws
     */
    @RequestMapping(value = "/share/shareUrl", method = RequestMethod.POST)
    public ResponseEntity shareUrl(@ModelAttribute final ShareEntity entity, final Model model) {

        final RestRespEntity restRespEntity = new RestRespEntity();
        try {
            /** 2. validate check */
            // if (EntityValidator.isValid(entity)) {
            // logger.warn("Validate error!!!!!");
            // return CommonUtil.response(ResultCode.C1001, restRespEntity);
            // }
            final String shareUrl = service.insert(entity);

            return CommonUtil.response(restRespEntity, CommonUtil.delInfo(entity), shareUrl);

        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            return CommonUtil.response(ResultCode.C9999, restRespEntity);
        }
    }

}
