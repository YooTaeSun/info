package com.hyundaicard.cse.app.dictionary.mapper;

import java.util.List;

import com.hyundaicard.cse.app.dictionary.entity.BrandEntity;

/**
 * Question Mapper
 */
public interface BrandMapper {

    public List<BrandEntity> getBrandList(BrandEntity entity);
}
