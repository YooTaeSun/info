package com.hyundaicard.cse.app.search.entity;

public class ProductSearchResult {
    private String id;
    private String product_item_title;
    private String product_item_price_original;
    private String product_item_img;
    private String product_page_url_full;
    private String product_landing_url;
    private String product_site_key;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProduct_item_title() {
        return product_item_title;
    }

    public void setProduct_item_title(String product_item_title) {
        this.product_item_title = product_item_title;
    }

    public String getProduct_item_price_original() {
        return product_item_price_original;
    }

    public void setProduct_item_price_original(String product_item_price_original) {
        this.product_item_price_original = product_item_price_original;
    }

    public String getProduct_item_img() {
        return product_item_img;
    }

    public void setProduct_item_img(String product_item_img) {
        this.product_item_img = product_item_img;
    }

    public String getProduct_page_url_full() {
        return product_page_url_full;
    }

    public void setProduct_page_url_full(String product_page_url_full) {
        this.product_page_url_full = product_page_url_full;
    }

    public String getProduct_landing_url() {
        return product_landing_url;
    }

    public void setProduct_landing_url(String product_landing_url) {
        this.product_landing_url = product_landing_url;
    }

    public String getProduct_site_key() {
        return product_site_key;
    }

    public void setProduct_site_key(String product_site_key) {
        this.product_site_key = product_site_key;
    }

}
