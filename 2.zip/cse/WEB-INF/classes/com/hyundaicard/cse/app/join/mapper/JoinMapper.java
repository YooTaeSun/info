package com.hyundaicard.cse.app.join.mapper;

import org.springframework.dao.DataAccessException;

import com.hyundaicard.cse.app.login.entity.UserEntity;

/**
 * Join Mapper
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public interface JoinMapper {

    /**
     * ID 중복 체크
     */
    public String checkUserIdDuplicate(String userId) throws DataAccessException;

    /**
     * 회원정보 등록
     */
    public void registUserId(UserEntity userEntity) throws DataAccessException;

    /**
     * 기존 HCC 인증 계정 초기화
     */
    public void updateCustomerNoDefault(UserEntity userEntity) throws DataAccessException;

    /**
     * 회원가입된 memberIdSq 조회
     */
    public String selectMemberIdSq(UserEntity userEntity) throws DataAccessException;

    /**
     * 비회원 상태로 북마크한 정보 가입한 ID에 맵핑
     */
    public void migrationBookmarkInfo(UserEntity userEntity) throws DataAccessException;

    /**
     * 비회원 상태로 좋아요한 정보 가입한 ID에 맵핑
     */
    public void migrationLikeInfo(UserEntity userEntity) throws DataAccessException;

    /**
     * 비회원 상태로 작성한 리뷰 정보 가입한 ID에 맵핑
     */
    public void migrationReviewInfo(UserEntity userEntity) throws DataAccessException;

    /**
     * 비회원 상태로 작성한 설문 정보 가입한 ID에 맵핑
     */
    public void migrationSurveyInfo(UserEntity userEntity) throws DataAccessException;

}
