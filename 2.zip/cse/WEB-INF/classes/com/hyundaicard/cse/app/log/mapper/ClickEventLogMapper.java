package com.hyundaicard.cse.app.log.mapper;

import com.hyundaicard.cse.app.log.entity.ClickEventLogEntity;

/**
 * click event log Mapper
 *
 * @version : 1.0
 * @author : Copyright (c) HYUNDAI CARD Corp.. All Rights Reserved.
 */
public interface ClickEventLogMapper {

    /**
     * 등록
     *
     * @Mehtod Name : insert
     * @param entity
     * @return
     */
    public void insert(ClickEventLogEntity entity);
}
