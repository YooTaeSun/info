package com.hyundaicard.cse.app.login.entity;

import com.hyundaicard.cse.common.entity.AbstractPage;

/**
 * SearchWord Entity 검색 Entity
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public class UserEntity extends AbstractPage {

    private String memberIdSq;
    private String userId;
    private String customerNo;
    private String uuid;
    private String snsUid;
    private String osType;
    private String hccAuthYN;
    private String marketingAgreeYN;
    private String joinChannel;

    public String getMemberIdSq() {
        return memberIdSq;
    }

    public void setMemberIdSq(final String memberIdSq) {
        this.memberIdSq = memberIdSq;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(final String userId) {
        this.userId = userId;
    }

    public String getCustomerNo() {
        return customerNo;
    }

    public void setCustomerNo(final String customerNo) {
        this.customerNo = customerNo;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    public String getSnsUid() {
        return snsUid;
    }

    public void setSnsUid(final String snsUid) {
        this.snsUid = snsUid;
    }

    public String getOsType() {
        return osType;
    }

    public void setOsType(final String osType) {
        this.osType = osType;
    }

    public String getHccAuthYN() {
        return hccAuthYN;
    }

    public void setHccAuthYN(final String hccAuthYN) {
        this.hccAuthYN = hccAuthYN;
    }

    public String getMarketingAgreeYN() {
        return marketingAgreeYN;
    }

    public void setMarketingAgreeYN(final String marketingAgreeYN) {
        this.marketingAgreeYN = marketingAgreeYN;
    }

    public String getJoinChannel() {
        return joinChannel;
    }

    public void setJoinChannel(final String joinChannel) {
        this.joinChannel = joinChannel;
    }

    @Override
    public String toString() {
        return "UserEntity [memberIdSq=" + memberIdSq + ", userId=" + userId + ", customerNo=" + customerNo + ", uuid="
                + uuid + ", snsUid=" + snsUid + ", osType=" + osType + ", hccAuthYN=" + hccAuthYN
                + ", marketingAgreeYN=" + marketingAgreeYN + ", joinChannel=" + joinChannel + "]";
    }

}
