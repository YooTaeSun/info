package com.hyundaicard.cse.app.search.entity;

/**
 * search autocomplete Entity
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
public class SearchAutocompleteRequestEntity {
    private String query;
    private Integer size;

    public String getQuery() {
        return query;
    }

    public void setQuery(final String query) {
        this.query = query;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(final Integer size) {
        this.size = size;
    }

}
