package com.hyundaicard.cse.app.mypage.mapper;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.hyundaicard.cse.app.mypage.entity.NoticeEntity;
import com.hyundaicard.cse.app.mypage.entity.PopupNoticeEntity;

/**
 * Notice Mapper
 */
public interface NoticeMapper {

    /**
     * 공지사항 리스트조회
     */
    public List<NoticeEntity> getNoticeList(NoticeEntity noticeEntity) throws DataAccessException;

    /**
     * 공지사항 상세조회
     */
    public NoticeEntity getNoticeDetail(NoticeEntity noticeEntity) throws DataAccessException;

    /**
     * 조회수 증가
     */
    public void updateHitCount(NoticeEntity noticeEntity) throws DataAccessException;

    /**
     * 총갯수 조회
     */
    public int getCount(NoticeEntity noticeEntity) throws DataAccessException;

    /**
     * 팝업공지
     *
     * @return
     * @throws DataAccessException
     */
    public PopupNoticeEntity getPopupNotice(PopupNoticeEntity entity) throws DataAccessException;

    /**
     * 다시보지 않기 체크
     *
     * @param entity
     * @return
     * @throws DataAccessException
     */
    public Integer getPopupSkip(PopupNoticeEntity entity) throws DataAccessException;

    /**
     * 다시보지 않기 체크
     *
     * @param entity
     * @return
     * @throws DataAccessException
     */
    public Integer getPopupNoticeSq(PopupNoticeEntity entity) throws DataAccessException;

    /**
     * 다시보지 않기 등록
     *
     * @param entity
     * @throws DataAccessException
     */
    public void setPopupSkip(PopupNoticeEntity entity) throws DataAccessException;

    /**
     * 새로등록된 이벤트 및 공지갯수
     *
     * @param entity
     * @throws DataAccessException
     */
    public Integer getCntInitNotice(NoticeEntity entity) throws DataAccessException;
}
