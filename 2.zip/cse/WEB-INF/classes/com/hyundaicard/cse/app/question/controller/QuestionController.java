package com.hyundaicard.cse.app.question.controller;

import java.io.IOException;
import java.math.BigInteger;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.util.HtmlUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.hyundaicard.cse.app.bookmark.service.SessionService;
import com.hyundaicard.cse.app.question.entity.AnswerDetailEntity;
import com.hyundaicard.cse.app.question.entity.AnswerEntity;
import com.hyundaicard.cse.app.question.entity.QuestionEntity;
import com.hyundaicard.cse.app.question.service.AnswerService;
import com.hyundaicard.cse.app.question.service.QuestionService;
import com.hyundaicard.cse.common.controller.CseAppController;
import com.hyundaicard.cse.common.entity.RestRespEntity;
import com.hyundaicard.cse.common.util.CommonUtil;
import com.hyundaicard.cse.constants.Constants;

/**
 * 설문 정보 조회
 */

@Controller
public class QuestionController extends CseAppController {

    private static final Logger logger = LoggerFactory.getLogger(QuestionController.class);

    @Autowired
    private QuestionService questionService;

    @Autowired
    private AnswerService answerService;

    @Autowired
    private SessionService sessionService;

    @Autowired
    private ObjectMapper objectMapper;

    @RequestMapping(value = "/mypage/question0101", method = RequestMethod.GET)
    public String myPagequestionView(@ModelAttribute final QuestionEntity entity, final Model model) {

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        String uuid = "";
        if (Constants.NO_MEMBER_ID_SQ.equals(memberIdSq)) {// 로그인 안 되어 있으면
            uuid = sessionService.getAttribute("uuid");
        }

        model.addAttribute("hccAuthYn", sessionService.getAttribute("hccAuthYN"));
        model.addAttribute("list", questionService.getQueList());

        // 질문 유무 및 질문사항
        String questionYn = "N";
        final AnswerEntity answerEntity = new AnswerEntity();
        answerEntity.setLoginIDInSession(memberIdSq);
        answerEntity.setUuid(uuid);
        final int answerCnt = answerService.getAnswerCnt(answerEntity);
        if (answerCnt > 0) {
            questionYn = "Y";
            final List<AnswerDetailEntity> answerList = answerService.getAnswerList(answerEntity);

            model.addAttribute("answerList", answerList);
        }

        model.addAttribute("questionYn", questionYn);
        model.addAttribute("entity", entity);
        return "/mypage/question0101";
    }

    /**
     * 설문 조회
     */
    @RequestMapping(value = "/question/question0102", method = RequestMethod.POST)
    public ResponseEntity questionList(@ModelAttribute final QuestionEntity entity, final Model model) {
        final RestRespEntity restRespEntity = new RestRespEntity();

        final List<QuestionEntity> list = questionService.getQueList();

        return CommonUtil.response(restRespEntity, list);
    }

    /**
     * 설문 INSERT
     *
     * @param entity
     * @param model
     * @return
     */
    @RequestMapping(value = "/answer/insert", method = RequestMethod.POST)
    public ResponseEntity answerInsert(@ModelAttribute final AnswerEntity entity, final Model model) {
        final RestRespEntity restRespEntity = new RestRespEntity();

        final String memberIdSq = sessionService.getAttribute("memberIdSq");
        final String uuid = sessionService.getAttribute("uuid");
        entity.setLoginIDInSession(memberIdSq);
        entity.setUuid(uuid);
        int reVal = 0;
        try {

            if (!(memberIdSq == null || "".equals(memberIdSq))) {
                entity.setLoginIDInSession(memberIdSq);
            }
            answerService.insert(entity);
            final BigInteger insertReSq = entity.getSurveyAnswerSq();
            entity.setSurveyAnswerSq(insertReSq);

            final String answerValue = HtmlUtils.htmlUnescape(entity.getAnswerValues());
            entity.setAnswerValues(answerValue);
            if (!StringUtils.isBlank(answerValue)) {
                final CollectionType typeReference = TypeFactory.defaultInstance().constructCollectionType(List.class, AnswerDetailEntity.class);
                final List<AnswerDetailEntity> answerList = objectMapper.readValue(answerValue, typeReference);

                entity.setAnswerValueList(answerList);

                for (int i = 0; i < answerList.size(); i++) {
                    final AnswerDetailEntity forinDetailEntity = answerList.get(i);
                    forinDetailEntity.setSurveyAnswerSq(entity.getSurveyAnswerSq());
                    forinDetailEntity.setLoginIDInSession(memberIdSq);
                    reVal = answerService.insertDetail(forinDetailEntity);
                }
            }

        } catch (final IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return CommonUtil.response(restRespEntity, reVal);
    }

}