package com.hyundaicard.cse.app.data.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hyundaicard.cse.app.data.mapper.DataAnalyzeMapper;

/**
 * Init Service
 *
 * @version : 1.0
 * @author : Copyright (c) 2015 by <<Company Name>>. All Rights Reserved.
 */
@Service
public class DataAnalyzeService {

    /** Mapper */
    @Autowired
    private DataAnalyzeMapper mapper;

    public String getAnalyzeDataCount() {

        return mapper.getAnalyzeDataCount();
    }

    public void updateAnalyzeDataCount(final String dataCount) {

        mapper.updateAnalyzeDataCount(dataCount);
    }

}
