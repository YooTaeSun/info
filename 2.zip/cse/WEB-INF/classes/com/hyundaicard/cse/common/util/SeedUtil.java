package com.hyundaicard.cse.common.util;

import org.apache.commons.codec.binary.Base64;
import org.json.JSONObject;

import com.hyundaicard.cse.common.crypto.KISA_SEED_CBC;
import com.hyundaicard.cse.common.ecb.KISA_SEED_ECB;

import net.sf.json.JSONException;

public class SeedUtil {
    private static final int SEED_OFFSET = 0;
    private static final String ECB_KEY = "HYUNDAICARD_2017";

    /** SEED_CBC 복호화 */
    public static String getSeedDecrypt(final String userKey, final String iv, final String msg) {
        if (userKey == null || iv == null || msg == null) {
            return null;
        }

        final byte[] pbszUserKey = userKey.getBytes();
        final byte[] pbszIV = iv.getBytes();
        final byte[] message = Base64.decodeBase64(msg);

        if (pbszUserKey.length != 16 || pbszIV.length != 16) {
            return null;
        }

        final byte[] pbszPlainText = KISA_SEED_CBC.SEED_CBC_Decrypt(pbszUserKey, pbszIV, message, SEED_OFFSET,
                message.length);

        return new String(pbszPlainText);

    }

    /** SEED_CBC 복호화 */
    public static JSONObject getSeedDecryptJson(final String userKey, final String iv, final String msg)
            throws JSONException {
        return new JSONObject(getSeedDecrypt(userKey, iv, msg.toString()));
    }

    /** SEED_CBC 암호화 */
    public static String getSeedEnecrypt(final String userKey, final String iv, final String msg) {
        if (userKey == null || iv == null || msg == null) {
            return null;
        }

        final byte[] pbszUserKey = userKey.getBytes();
        final byte[] pbszIV = iv.getBytes();
        final byte[] message = msg.getBytes();

        if (pbszUserKey.length != 16 || pbszIV.length != 16) {
            return null;
        }

        final String encString = new String(Base64.encodeBase64(
                KISA_SEED_CBC.SEED_CBC_Encrypt(pbszUserKey, pbszIV, message, SEED_OFFSET, message.length)));

        return encString;
    }

    /** SEED_CBC 암호화 */
    public static String getSeedEnecrypt(final String userKey, final String iv, final JSONObject msg)
            throws JSONException {
        return new String(getSeedEnecrypt(userKey, iv, msg.toString()));
    }

    /** SEED_ECB 복호화 */
    public static String getSeedDecryptECB(final String msg) {
        if (msg == null) {
            return null;
        }

        final byte[] pbszUserKey = ECB_KEY.getBytes();
        final byte[] message = StringUtil.hexToByteArray(msg);

        final byte[] pbszPlainText = KISA_SEED_ECB.SEED_ECB_Decrypt(pbszUserKey, message, SEED_OFFSET, message.length);

        return new String(pbszPlainText);

    }

    /** SEED_ECB 암호화 */
    public static String getSeedEncryptECB(final String msg) {
        if (msg == null) {
            return null;
        }

        final byte[] pbszUserKey = ECB_KEY.getBytes();
        final byte[] message = msg.getBytes();

        final String encString = new String(StringUtil
                .toHexString(KISA_SEED_ECB.SEED_ECB_Encrypt(pbszUserKey, message, SEED_OFFSET, message.length)));

        return encString;

    }
}
