package com.hyundaicard.cse.common.interceptor;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hyundaicard.cse.common.annotation.CheckSession;
import com.hyundaicard.cse.common.exception.SessionException;

public class SessionInterceptor extends AbstractInterceptor {

    @Autowired
    private MessageSource messageSource;

    private static final Logger logger = LoggerFactory.getLogger(SessionInterceptor.class);

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        logger.debug("SessionInterceptor preHandle");

        CheckSession checkSession = ((HandlerMethod) handler).getMethodAnnotation(CheckSession.class);

        if (checkSession != null && !checkSession.isCheck()) {
            return true;
        }

        HttpSession httpSession = request.getSession(false);

        if (httpSession == null) {
            throw new SessionException(messageSource, "SESSION0001", Locale.getDefault());
        }

        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
            ModelAndView modelAndView) throws Exception {
        logger.debug("SessionInterceptor postHandle");
        super.postHandle(request, response, handler, modelAndView);
    }
}
