package com.hyundaicard.cse.common.constants;

public class SessionConstants {

    public static final String SESSION_STORAGE = "CSE_SESSION_STORAGE";

    /** RSA 사용여부 */
    public static final String USE_RSA_ENCRYPTION_YN = "USE_RSA_ENCRYPTION";

    /** SEED 사용여부 */
    public static final String USE_SEED_ENCRYPTION_YN = "USE_SEED_ENCRYPTION";

    /** client seed key, iv */
    public static final String CLIENT_SEED_KEY = "CLIENT_SEED_KEY";
    public static final String CLIENT_SEED_IV = "CLIENT_SEED_IV";

    /** server seed key, iv */
    public static final String SERVER_SEED_KEY = "SERVER_SEED_KEY";
    public static final String SERVER_SEED_IV = "SERVER_SEED_IV";

    /** HTTP HEADER */
    public static final String ENCRYPTION_YN = "Encryption";
    public static final String TRANSFER = "Transfer";

    /** OSTYPE Type */
    public static final String OS_TYPE = "USE_OS_TYPE";
    public static final String OS_TYPE_ANDROID = "A";
    public static final String OS_TYPE_IPHONE = "I";
    public static final String OS_TYPE_ETC = "E";

    /** OS Version */
    public static final String OS_VERSION = "USE_OS_VERSION";
    public static final String OS_VERSION_DEFAULT = "0.0.0";

    /** App Version */
    public static final String APP_VERSION = "USE_APP_VERSION";
    public static final String APP_VERSION_DEFAULT = "0.0.0";

    /** Model */
    public static final String MODEL = "USE_MODEL";
    public static final String MODEL_DEFAULT = "DEFAULT";

    /** Device UUID */
    public static final String DEVICE_ID = "USE_DEVICE_ID";
    public static final String DEVICE_ID_DEFAULT = "";

    /** Device MAC */
    public static final String DEVICE_MAC = "USE_DEVICE_MAC";
    public static final String DEVICE_MAC_DEFAULT = "";
}
