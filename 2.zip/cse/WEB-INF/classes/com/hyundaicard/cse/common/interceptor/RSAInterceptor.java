package com.hyundaicard.cse.common.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hyundaicard.cse.common.annotation.UseRSA;
import com.hyundaicard.cse.common.constants.SessionConstants;

public class RSAInterceptor extends AbstractInterceptor {

    private static final Logger logger = LoggerFactory.getLogger(RSAInterceptor.class);

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        logger.debug("RSAInterceptor preHandle");

        UseRSA useRSA = ((HandlerMethod) handler).getMethodAnnotation(UseRSA.class);

        if (useRSA != null && useRSA.useRSA()) {
            request.setAttribute(SessionConstants.USE_RSA_ENCRYPTION_YN, "Y");
            request.setAttribute(SessionConstants.USE_SEED_ENCRYPTION_YN, "N");
            logger.debug("RSA ON");
            return true;
        }

        request.setAttribute(SessionConstants.USE_RSA_ENCRYPTION_YN, "N");

        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
            ModelAndView modelAndView) throws Exception {
        logger.debug("RSAInterceptor postHandle");
        super.postHandle(request, response, handler, modelAndView);
    }
}
