package com.hyundaicard.cse.common.constants;

public class ExceptionConstants {

    /** SERVER Exception */
    public static final String FRAME_EXCEPTION = "SERVER0000";
    public static final String BIZ_EXCEPTION = "SERVER0001";
    public static final String FAIL_MAKE_RESPONSE_MESSAGE = "SERVER0002";
    public static final String FAIL_MAKE_REQUEST_EXCEPTION = "SERVER0003";
    public static final String FAIL_MAKE_REQUEST_BODY_IS_NULL = "SERVER0004";
    public static final String FAIL_MAKE_REQUEST_FAIL_BODY_JSON = "SERVER0005";

    /** JSONOBJECT Exception */
    public static final String FAIL_MAKE_JSONOBJECT_REQUEST_MESSAGE = "JSON0000";
    public static final String FAIL_MAKE_JSONOBJECT_RESPONSE_MESSAGE = "JSON0001";
    public static final String FAIL_JSONOBJECT_PARSING_EXCEPTION = "JSON0002";
    public static final String FAIL_JSONOBJECT_CASTING_EXCEPTION = "JSON0003";
    public static final String FAIL_JSONOBJECT_NULLPOINT_EXCEPTION = "JSON0004";

    /** RSA CERTIFICATION */
    public static final String RSA_NOT_FOUND_EXCEPTION = "RSA0000";
    public static final String RSA_NOT_FAIL_EXCEPTION = "RSA0001";

    /** DB processing Exception */
    public static final String DB_INSERT_EXCEPTION = "DB0000";
    public static final String DB_UPDATE_EXCEPTION = "DB0001";
    public static final String DB_DELETE_EXCEPTION = "DB0002";
    public static final String DB_SELECT_EXCEPTION = "DB0003";

    /** ENCRYPTION / DECRYPTION Exception */
    public static final String RSA_DECRYPTION_EXCEPTION = "CRYPTO0000";
    public static final String CLIENT_SEED_DECRYPTION_EXCEPTION = "CRYPTO0001";
    public static final String SERVER_SEED_DECRYPTION_EXCEPTION = "CRYPTO0002";
    public static final String CLIENT_SEED_ENCRYPTION_EXCEPTION = "CRYPTO0003";
    public static final String SERVER_SEED_ENCRYPTION_EXCEPTION = "CRYPTO0004";

}
