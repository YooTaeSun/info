package com.hyundaicard.cse.common.util;

import java.text.DecimalFormat;

public class StringUtil {

    public static String getConvertFullToHalf(final String str) {
        char c = 0;
        final StringBuffer strBuf = new StringBuffer();

        if (str != null && !str.equals("")) {
            for (int i = 0; i < str.length(); i++) {
                c = str.charAt(i);

                // 특수문자일경우
                if (c >= 65281 && c <= 65374) {
                    c -= 0xfee0;
                } else if (c == ' ') {
                    c = 0x20;
                }
                strBuf.append(c);
            }
        }
        return strBuf.toString();
    }

    public static String makeNumberFormat(final String str) {
        final StringBuffer format = new StringBuffer();

        for (int i = 0; i < 20; i++) {
            if (i != 0 && i % 3 == 0) {
                format.append(",#");
            } else {
                format.append("#");
            }
        }

        format.reverse();

        final double change = Double.valueOf(str).doubleValue();
        final DecimalFormat decimal = new DecimalFormat(format.toString());

        return decimal.format(change);
    }

    public static byte[] hexToByteArray(final String hex) {
        if (hex == null || hex.length() == 0) {
            return null;
        }

        final byte[] ba = new byte[hex.length() / 2];
        for (int i = 0; i < ba.length; i++) {
            ba[i] = (byte) Integer.parseInt(hex.substring(2 * i, 2 * i + 2), 16);
        }

        return ba;

    }

    public static String toHexString(final byte[] bytes) {
        if (bytes == null) {
            return null;
        }

        final StringBuffer result = new StringBuffer();
        for (final byte b : bytes) {
            result.append(Integer.toString((b & 0xF0) >> 4, 16));
            result.append(Integer.toString(b & 0x0F, 16));
        }

        return result.toString();
    }

}
