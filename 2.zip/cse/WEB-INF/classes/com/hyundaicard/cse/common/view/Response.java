package com.hyundaicard.cse.common.view;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hyundaicard.cse.common.constants.ProtocolConstants;
import com.hyundaicard.cse.common.util.DateUtil;
import com.hyundaicard.cse.common.util.StringUtil;

public class Response {

    private static final Logger logger = LoggerFactory.getLogger(Response.class);

    private JSONObject responseJson = new JSONObject();

    private JSONObject responseHeadJson = new JSONObject();

    private JSONObject responseBodyJson = new JSONObject();

    public Response(String resultCode, String resultMessage) throws Exception {
        responseHeadJson = this.getDefaultHeader();

        this.setBody(new JSONObject());

        this.setResponseJson();

        this.setResult(resultCode, resultMessage);
    }

    public Response(JSONObject bodyJson, String resultCode, String resultMessage) throws Exception {
        responseHeadJson = this.getDefaultHeader();

        this.setBody(bodyJson);

        this.setResponseJson();

        this.setResult(resultCode, resultMessage);
    }

    private void setResult(String resultCode, String resultMessage) throws Exception {
        responseJson.put(ProtocolConstants.RESULT_CODE, resultCode);
        responseJson.put(ProtocolConstants.RESULT_MESSAGE, resultMessage);
    }

    private JSONObject getDefaultHeader() throws Exception {
        JSONObject header = new JSONObject();

        header.put(ProtocolConstants.SERVER_DATE, DateUtil.getCurrentDate());
        header.put(ProtocolConstants.SERVER_TIME, DateUtil.getCurrentTime());

        return header;
    }

    private void setBody(JSONObject bodyJson) throws Exception {
        logger.debug("bodyJson : " + bodyJson.toString());
        if (bodyJson != null) {
            JSONObject body = new JSONObject(StringUtil.getConvertFullToHalf(bodyJson.toString()));
            responseBodyJson = body;
        }
    }

    public JSONObject getResponseJson() {
        return responseJson;
    }

    public void setResponseJson() throws Exception {
        JSONObject json = new JSONObject();

        json.put(ProtocolConstants.HEAD_NAME, responseHeadJson);
        json.put(ProtocolConstants.BODY_NAME, responseBodyJson);

        responseJson.put(ProtocolConstants.PARAMETER_NAME, json);
    }

    public JSONObject getResponseHeadJson() {
        return responseHeadJson;
    }

    public void setResponseHeadJson(JSONObject responseHeadJson) {
        this.responseHeadJson = responseHeadJson;
    }

    public JSONObject getResponseBodyJson() {
        return responseBodyJson;
    }

    public void setResponseBodyJson(JSONObject responseBodyJson) {
        this.responseBodyJson = responseBodyJson;
    }

}
