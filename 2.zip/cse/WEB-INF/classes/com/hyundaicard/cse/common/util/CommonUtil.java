package com.hyundaicard.cse.common.util;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.google.gson.Gson;
import com.hyundaicard.cse.common.code.ResultCode;
import com.hyundaicard.cse.common.entity.RestRespEntity;

public class CommonUtil {
    /**
     * 응답코드의 메시지를 가져온다.
     * 
     * @Mehtod Name : getResultMessage
     * @param code
     * @return
     */
    public static String getResultMessage(ResultCode code) {
        return CommonUtil.getResultMessage(code.getCode());
    }

    /**
     * 응답코드의 메시지를 가져온다.
     * 
     * @Mehtod Name : getResultMessage
     * @param code
     * @return
     */
    public static String getResultMessage(String code) {
        return MessageManage.getMessage("resultcode." + code);
    }

    public static ResponseEntity<String> response(ResultCode code, RestRespEntity restRespEntity) {
        restRespEntity.setResultCode(code.getCode());
        return response(restRespEntity, null);
    }

    public static ResponseEntity<String> response(RestRespEntity restRespEntity, Object requestData,
            Object resultData) {
        restRespEntity.setResultMessage(getResultMessage(restRespEntity.getResultCode()));
        restRespEntity.setResultData(restRespEntity);

        Map<String, Object> responseMap = addCommonResData(restRespEntity);
        responseMap.put("requestData", requestData);
        responseMap.put("resultData", resultData);
        // Reponse Json String
        Gson gson = new Gson();
        String responseStr = gson.toJson(responseMap);
        return new ResponseEntity<String>(responseStr, HttpStatus.OK);
    }

    public static ResponseEntity<String> response(RestRespEntity restRespEntity, Object resultData) {
        restRespEntity.setResultMessage(getResultMessage(restRespEntity.getResultCode()));
        restRespEntity.setResultData(restRespEntity);

        Map<String, Object> responseMap = addCommonResData(restRespEntity);
        responseMap.put("resultData", resultData);
        // Reponse Json String
        Gson gson = new Gson();
        String responseStr = gson.toJson(responseMap);
        return new ResponseEntity<String>(responseStr, HttpStatus.OK);
    }

    /**
     * 응답코드 데이터값을 설정한다.
     * 
     * @Mehtod Name : addCommonResData
     * @param apiCommonResDomain
     * @return
     */
    private static Map<String, Object> addCommonResData(RestRespEntity restRespEntity) {
        Map<String, Object> responseMap = new LinkedHashMap<String, Object>();
        responseMap.put("resultCode", restRespEntity.getResultCode());
        responseMap.put("resultMessage", getResultMessage(restRespEntity.getResultCode()));
        return responseMap;
    }

    public static Object delInfo(Object entity) {
        try {
            Class cls = entity.getClass();
            cls.getMethod("setMemberIdSq", String.class).invoke(entity, "");
            cls.getMethod("setUuid", String.class).invoke(entity, "");
        } catch (Exception e) {
        }
        return entity;
    }

}
