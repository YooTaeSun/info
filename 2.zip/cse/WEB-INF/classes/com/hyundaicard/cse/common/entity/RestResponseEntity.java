package com.hyundaicard.cse.common.entity;

public class RestResponseEntity<H, B> {

    private int code;
    private String msg;
    private H head;
    private B body;

    public RestResponseEntity(int code, String msg) {
        this.code = code;
        this.msg = msg;
        this.head = null;
        this.body = null;
    }

    public RestResponseEntity(int code, String msg, B body) {
        this.code = code;
        this.msg = msg;
        this.head = null;
        this.body = body;
    }

    public RestResponseEntity(int code, String msg, H head, B body) {
        this.code = code;
        this.msg = msg;
        this.head = head;
        this.body = body;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public H getHead() {
        return head;
    }

    public void setHead(H head) {
        this.head = head;
    }

    public B getBody() {
        return body;
    }

    public void setBody(B body) {
        this.body = body;
    }
}
