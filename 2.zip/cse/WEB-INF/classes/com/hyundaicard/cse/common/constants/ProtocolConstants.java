package com.hyundaicard.cse.common.constants;

public class ProtocolConstants {

    /** PARENT KEY NAME */
    public static final String PARAMETER_NAME = "MESSAGE";

    /** PART KEY NAME */
    public static final String HEAD_NAME = "HEAD";
    public static final String BODY_NAME = "BODY";

    /** client seed key, iv */
    public static final String CLIENT_SEED_KEY = "HC1";
    public static final String CLIENT_SEED_IV = "HC2";

    /** server seed key, iv */
    public static final String SERVER_SEED_KEY = "HC1";
    public static final String SERVER_SEED_IV = "HC2";

    public static final String HEAD_OS_TYPE = "osType";
    public static final String HEAD_OS_VERSION = "osVersion";
    public static final String HEAD_APP_VERSION = "appVersion";
    public static final String HEAD_MODEL = "model";
    public static final String HEAD_DEVICE_ID = "deviceId";
    public static final String HEAD_MAC = "mac";

    /** HTTP HEADER */
    public static final String ENCRYPTION_YN = "Encryption";
    public static final String TRANSFER = "Transfer";

    /** HTTP SESSION Cookie */
    public static final String HTTP_REQUEST_SESSION_HEADER_KEY = "Cookie";
    public static final String HTTP_RESPONSE_SESSION_HEADER_KEY = "Set-Cookie";

    /** HTTP RESPONSE HEADER */
    public static final String RESULT_CODE = "resultCode";
    public static final String RESULT_MESSAGE = "resultMessage";

    public static final String SERVER_DATE = "serverDate";
    public static final String SERVER_TIME = "serverTime";

    /** TRANSFER RESPONSE CODE */
    public static final String RESULT_CODE_SUCSESS = "0000";

}
