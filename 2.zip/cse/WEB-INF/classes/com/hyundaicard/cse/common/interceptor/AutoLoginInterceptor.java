package com.hyundaicard.cse.common.interceptor;

import java.util.Locale;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import com.hyundaicard.cse.app.login.entity.AutoLoginEntity;
import com.hyundaicard.cse.app.login.service.LoginService;
import com.hyundaicard.cse.common.constants.SessionConstants;
import com.hyundaicard.cse.common.exception.SessionException;

public class AutoLoginInterceptor extends AbstractInterceptor {

    @Autowired
    private MessageSource messageSource;

    @Autowired
    private LoginService loginService;

    private static final Logger logger = LoggerFactory.getLogger(AutoLoginInterceptor.class);

    @Override
    public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler)
            throws Exception {

        // final CheckAutoLogin checkAutoLogin = ((HandlerMethod) handler).getMethodAnnotation(CheckAutoLogin.class);
        //
        // if (checkAutoLogin != null && !checkAutoLogin.isCheck()) {
        // return true;
        // }

        HttpSession httpSession = request.getSession(false);

        if (httpSession == null) {
            final Cookie cookieUuid = WebUtils.getCookie(request, "uuid");
            if (cookieUuid != null) {
                logger.debug("cookieUUID : " + cookieUuid.getValue());
                httpSession = request.getSession(true);
                httpSession.setAttribute("uuid", cookieUuid.getValue());

                final Cookie cookieHC3 = WebUtils.getCookie(request, "HC3");

                if (cookieHC3 != null) {
                    logger.debug("cookieHC3 : " + cookieHC3.getValue());
                    // uuid와 인증토큰이 있는경우 (로그인o)
                    // 세션 생성하고 인증토큰값으로 인증정보테이블 조회하여 해당 userId 찾아서
                    // 거기에 해당하는 사용자정보 조회 후 세션에 저장

                    AutoLoginEntity autoLoginEntity = new AutoLoginEntity();
                    autoLoginEntity.setUuid(cookieUuid.getValue());
                    autoLoginEntity.setLoginAuthToken(cookieHC3.getValue());

                    autoLoginEntity = loginService.getAutoLoginInfo(autoLoginEntity);

                    if (autoLoginEntity != null) {
                        httpSession.setAttribute(SessionConstants.SERVER_SEED_KEY, autoLoginEntity.getHc1());
                        httpSession.setAttribute(SessionConstants.SERVER_SEED_IV, autoLoginEntity.getHc2());

                        httpSession.setAttribute("memberIdSq", autoLoginEntity.getMemberIdSq());
                        httpSession.setAttribute("userId", autoLoginEntity.getLoginId());
                        httpSession.setAttribute("customerNo", autoLoginEntity.getCustomerNo());
                        httpSession.setAttribute("uuid", autoLoginEntity.getUuid());
                        httpSession.setAttribute("hccAuthYN", autoLoginEntity.getHccAuthYN());
                    } else {
                        throw new SessionException(messageSource, "SESSION0001", Locale.getDefault());
                    }
                }
            }

        }

        return true;
    }

    @Override
    public void postHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler,
            final ModelAndView modelAndView) throws Exception {
        super.postHandle(request, response, handler, modelAndView);
    }
}
