package com.hyundaicard.cse.common.support;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import com.hyundaicard.cse.common.view.Request;

public class RequestHandlerMethodArgumentResolver implements HandlerMethodArgumentResolver {

    private static final Logger logger = LoggerFactory.getLogger(RequestHandlerMethodArgumentResolver.class);

    @Override
    public boolean supportsParameter(final MethodParameter parameter) {
        return Request.class.isAssignableFrom(parameter.getParameterType());
    }

    @Override
    public Object resolveArgument(final MethodParameter parameter, final ModelAndViewContainer mavContainer,
            final NativeWebRequest webRequest, final WebDataBinderFactory binderFactory) throws Exception {

        final HttpServletRequest request = (HttpServletRequest) webRequest.getNativeRequest();

        final Enumeration<?> headerElements = request.getHeaderNames();

        while (headerElements.hasMoreElements()) {
            final String key = (String) headerElements.nextElement();
            final String value = request.getHeader(key);
            logger.debug("Header [" + key + "] : [" + value + "]");
        }

        return new Request(request);
    }

}
