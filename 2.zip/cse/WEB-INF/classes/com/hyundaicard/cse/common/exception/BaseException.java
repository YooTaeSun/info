package com.hyundaicard.cse.common.exception;

import java.text.MessageFormat;
import java.util.Locale;

import org.springframework.context.MessageSource;

public class BaseException extends Exception {

    private static final long serialVersionUID = 1L;
    protected String message = null;
    protected String messageKey = null;
    protected Object[] messageParameters = null;
    protected Exception wrappedException = null;

    @Override
    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessageKey() {
        return this.messageKey;
    }

    public void setMessageKey(String messageKey) {
        this.messageKey = messageKey;
    }

    public Object[] getMessageParameters() {
        return this.messageParameters;
    }

    public void setMessageParameters(Object[] messageParameters) {
        this.messageParameters = messageParameters;
    }

    public Throwable getWrappedException() {
        return this.wrappedException;
    }

    public void setWrappedException(Exception wrappedException) {
        this.wrappedException = wrappedException;
    }

    public BaseException() {
        super();
    }

    public BaseException(String defaultMessage) {
        super(defaultMessage);
    }

    // public BaseException(MessageSource messageSource, String messageKey) {
    // super(messageSource, messageKey);
    // }

    public BaseException(MessageSource messageSource, String messageKey, Object[] messageParameters) {
        super(messageSource.getMessage(messageKey, messageParameters, Locale.getDefault()));
    }

    public BaseException(Throwable wrappedException) {
        super(wrappedException);
    }

    public BaseException(String defaultMessage, Object[] messageParameters, Throwable wrappedException) {
        String userMessage = defaultMessage;
        if (messageParameters != null) {
            userMessage = MessageFormat.format(defaultMessage, messageParameters);
        }
        this.message = userMessage;
    }
}
