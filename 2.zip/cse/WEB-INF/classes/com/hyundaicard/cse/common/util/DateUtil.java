package com.hyundaicard.cse.common.util;

import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.SimpleTimeZone;
import java.util.TimeZone;

public class DateUtil {

    public static String getTime() {
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy 년 MM월 dd일 HH시 mm분 ss초");

        return sdf.format(d);
    }

    public static String getTime(String format) {
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat(format);

        return sdf.format(d);
    }

    public static String getCurrentDate() {
        return getCurrentDate("yyyyMMdd");
    }

    public static String getCurrentDate(String format) {
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat(format);

        return sdf.format(d);
    }

    public static String getThisMonthy() {
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");

        return sdf.format(d);
    }

    public static String getThisYear() {
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy");

        return sdf.format(d);
    }

    public static String getCurrentTime() {
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("HHmmss");

        return sdf.format(d);
    }

    public static String getDayInterval(String format, int distance) {
        Calendar cal = getCalendar();
        cal.roll(Calendar.DATE, distance);
        Date d = cal.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat(format);

        return sdf.format(d);
    }

    public static String getDayInterval(String dateString, String format, int distance) {
        Calendar cal = getCalendar(dateString);
        cal.roll(Calendar.DATE, distance);
        Date d = cal.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat(format);

        return sdf.format(d);
    }

    public static String getYesterday() {
        Calendar cal = getCalendar();
        cal.roll(Calendar.DATE, -1);
        Date d = cal.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

        return sdf.format(d);
    }

    public static String getLastMonth() {
        Calendar cal = getCalendar();
        cal.roll(Calendar.MONTH, -1);
        Date d = cal.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM");

        return sdf.format(d);
    }

    public static Calendar getCalendar() {
        Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT+09:00"), Locale.KOREA);
        cal.setTime(new Date());

        return cal;
    }

    public static Calendar getCalendar(String date) {
        Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT+09:00"), Locale.KOREA);
        cal.setTime(string2Date(date, "yyyyMMdd"));

        return cal;
    }

    public static Calendar getCalendar(Date date) {
        Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT+09:00"), Locale.KOREA);
        cal.setTime(date);

        return cal;
    }

    public static String date2String(Date d) {
        return date2String(d, "yyyyMMdd");
    }

    public static String date2String(Date d, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.format(d);
    }

    public static Date string2Date(String s) {
        return string2Date(s, "yyyy/MM/dd");
    }

    public static Date string2Date(String s, String format) {
        Date date = null;
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        date = sdf.parse(s, new ParsePosition(0));

        return date;
    }

    public static long getDayDistance(String startDate, String endDate) {
        return getDayDistance(startDate, endDate, null);
    }

    public static long getDayDistance(String startDate, String endDate, String format) {
        if (format == null)
            format = "yyyyMMdd";

        SimpleDateFormat sdf = new SimpleDateFormat(format);
        Date sDate = null;
        Date eDate = null;
        long day2day = 0;

        try {
            sDate = sdf.parse(startDate);
            eDate = sdf.parse(endDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        day2day = (eDate.getTime() - sDate.getTime()) / (1000 * 60 * 60 * 24);
        return Math.abs(day2day);
    }

    public static String getUSTime() {
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss z", Locale.US);
        sdf.setTimeZone(new SimpleTimeZone(0, "GMT"));

        return sdf.format(d);
    }

    public static String convertFormat(String date, String oldFormat, String newFormat) {
        Date cDate = string2Date(date, oldFormat);
        SimpleDateFormat sdf = new SimpleDateFormat(newFormat);

        return sdf.format(cDate);
    }

    public static long getTimeDiff(Date dt1, Date dt2) {
        long dtCnt1 = 0;
        long dtCnt2 = 0;
        
        Calendar cal = Calendar.getInstance();
        cal.setTime(dt1);
        dtCnt1 = cal.getTime().getTime();
        
        cal.setTime(dt2);
        dtCnt2 = cal.getTime().getTime();
        
        return (long)((dtCnt2 - dtCnt1) / (1000));
    }
    
    public static long getTimeDiff(String sDt1, String sDt2) {
        Date dt1 = new Date();
        Date dt2 = new Date();
        
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            
            if (sDt1.trim().length() > 0) {
                dt1 = sdf.parse(sDt1);
            }
            
            if (sDt2.trim().length() > 0) {
                dt2 = sdf.parse(sDt2);
            }
        } catch (Exception e) {}
        
        return getTimeDiff(dt1, dt2);
    }
    
}
