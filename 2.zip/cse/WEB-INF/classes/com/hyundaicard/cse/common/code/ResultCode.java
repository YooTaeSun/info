package com.hyundaicard.cse.common.code;

public enum ResultCode {
    /**
     * 0 : SUCCESS
     */
    C0("0"), C0000("0000"),

    /**
     * 1001 : 파라메터 오류
     */
    C1001("1001"),

    /**
     * 3001 : 파라메터 오류
     */
    C3001("3001"),

    /**
     * 50001 : 서비스 오류
     */
    C5001("50001"),

    /**
     * 9999 : 시스템 오류
     */
    C9999("9999"),

    /**
     * 401 : 접근 권힌이 없음
     */
    C401("401"),

    /**
     * C402 : 접근 권힌이 없음(로그인 필요)
     */
    C402("402"),

    /**
     * C402 : 결과 없음
     */
    C204("204");

    private String code;

    /**
     * 생성자
     *
     * @param code
     * @param message
     */
    private ResultCode(final String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}