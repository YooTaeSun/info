package com.hyundaicard.cse.common.entity;

import com.hyundaicard.cse.common.code.ResultCode;

public class RestRespEntity {

    /**
     * 응답코드
     */
    private String resultCode = ResultCode.C0.getCode();

    /**
     * 응답메세지
     */
    private String resultMessage;

    /**
     * 응답결과
     */
    private Object resultData;

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public String getResultMessage() {
        return resultMessage;
    }

    public void setResultMessage(String resultMessage) {
        this.resultMessage = resultMessage;
    }

    public Object getResultData() {
        return resultData;
    }

    public void setResultData(Object resultData) {
        this.resultData = resultData;
    }
}
