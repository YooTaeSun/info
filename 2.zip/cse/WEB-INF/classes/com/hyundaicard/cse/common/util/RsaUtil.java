package com.hyundaicard.cse.common.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.Security;

import javax.crypto.Cipher;

import org.apache.commons.codec.binary.Base64;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import com.hyundaicard.cse.common.exception.FrameException;

public class RsaUtil {
    private static RsaUtil rsaManager = null;
    private PrivateKey privateKey = null;

    static {
        if (Security.getProvider("BC") != null) {
            Security.removeProvider("BC");
        }
        Security.addProvider(new BouncyCastleProvider());
    }

    public static RsaUtil getInstance() {
        if (rsaManager == null) {
            rsaManager = new RsaUtil();
        }

        return rsaManager;
    }

    public String decryptRsaData(String encryptData) throws FrameException {
        String certPath = Config.getCommon().getString("RSA_KEY_LOCATION");

        if (privateKey == null) {
            ObjectInputStream ois = null;
            KeyPair mkeyPair = null;

            try {
                ois = new ObjectInputStream(new FileInputStream(certPath));
                mkeyPair = (KeyPair) ois.readObject();
                privateKey = mkeyPair.getPrivate();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (ois != null) {
                    try {
                        ois.close();
                    } catch (IOException e) {
                    }
                }
            }
        }

        Cipher cipher = null;

        try {
            cipher = Cipher.getInstance("RSA", "BC");
            cipher.init(Cipher.DECRYPT_MODE, privateKey);
        } catch (Exception e) {
            e.printStackTrace();
        }

        byte[] decryptData = null;

        try {
            decryptData = cipher.doFinal(Base64.decodeBase64(encryptData));
        } catch (Exception e) {
        }

        String decryptText = new String(decryptData);

        return decryptText;
    }

}
