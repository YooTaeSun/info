package com.hyundaicard.cse.common.view;

import java.io.BufferedReader;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;

import com.hyundaicard.cse.common.constants.ExceptionConstants;
import com.hyundaicard.cse.common.constants.ProtocolConstants;
import com.hyundaicard.cse.common.constants.ServerConstants;
import com.hyundaicard.cse.common.constants.SessionConstants;
import com.hyundaicard.cse.common.exception.FrameException;
import com.hyundaicard.cse.common.util.RsaUtil;
import com.hyundaicard.cse.common.util.SeedUtil;

import net.sf.json.JSONException;

public class Request {

    @Autowired
    private MessageSource messageSource;

    private static final Logger logger = LoggerFactory.getLogger(Request.class);

    private JSONObject requestJson = null;

    private JSONObject requestHeadJson = null;

    private JSONObject requestBodyJson = null;

    private String osType = null;
    private String osVersion = SessionConstants.OS_VERSION_DEFAULT;
    private String appVersion = SessionConstants.APP_VERSION_DEFAULT;
    private String model = SessionConstants.MODEL_DEFAULT;
    private String deviceId = SessionConstants.DEVICE_ID_DEFAULT;
    private String deviceMac = SessionConstants.DEVICE_MAC_DEFAULT;

    public Request(HttpServletRequest httpServletRequest) throws FrameException {

        try {
            logger.debug("create request.");
            int encType = getEncType(httpServletRequest);

            JSONObject bodyJson = getBodyJson(encType, httpServletRequest);

            if (bodyJson == null) {
                throw new FrameException(messageSource, ExceptionConstants.FAIL_MAKE_REQUEST_BODY_IS_NULL);
            }

            logger.debug("bodyJson : " + bodyJson.toString());

            requestJson = new JSONObject(bodyJson.optString(ProtocolConstants.PARAMETER_NAME));
            logger.debug("requestJson : " + requestJson.toString());

            requestHeadJson = (JSONObject) requestJson.opt(ProtocolConstants.HEAD_NAME);
            requestBodyJson = (JSONObject) requestJson.opt(ProtocolConstants.BODY_NAME);

            logger.debug("======================");
            logger.debug("requestHeadJson : " + requestHeadJson.toString());
            logger.debug("======================");
            logger.debug("requestBodyJson : " + requestBodyJson.toString());
            logger.debug("======================");

        } catch (JSONException e) {
            logger.debug(e.getMessage());
            throw new FrameException(messageSource, ExceptionConstants.FAIL_MAKE_REQUEST_EXCEPTION);
        }

    }

    /**
     * encryption type을 획득한다.
     */
    private int getEncType(HttpServletRequest httpServletRequest) {
        String encryptionYN = httpServletRequest.getHeader(ProtocolConstants.ENCRYPTION_YN);

        logger.debug("encryptionYN : " + encryptionYN);

        if (encryptionYN != null && encryptionYN.equals("N")) {
            return ServerConstants.ENC_TYPE_TEXT;
        }

        String useRsa = (String) httpServletRequest.getAttribute(SessionConstants.USE_RSA_ENCRYPTION_YN);
        String useSeed = (String) httpServletRequest.getAttribute(SessionConstants.USE_SEED_ENCRYPTION_YN);
        logger.debug("useRsa : " + useRsa + " / useSeed : " + useSeed);
        if (useRsa != null && useRsa.equals("Y")) {
            return ServerConstants.ENC_TYPE_RSA;
        } else if (useSeed != null && useSeed.equals("Y")) {
            return ServerConstants.ENC_TYPE_SEED;
        } else {
            return ServerConstants.ENC_TYPE_TEXT;
        }
    }

    /**
     * 단말에서 올린 MESSAGE를 복호화한다.
     */
    private JSONObject getBodyJson(int encType, HttpServletRequest httpServletRequest) throws FrameException {
        JSONObject bodyJson = null;
        logger.debug("getBodyJson encType : " + encType);
        switch (encType) {
        case ServerConstants.ENC_TYPE_TEXT:
            bodyJson = getBodyJsonByMessage(httpServletRequest);
            break;
        case ServerConstants.ENC_TYPE_RSA:
            bodyJson = getBodyJsonForRSADecryption(httpServletRequest);
            break;
        case ServerConstants.ENC_TYPE_SEED:
            bodyJson = getBodyJsonForSeedDycryption(httpServletRequest);
            break;
        }

        return bodyJson;
    }

    /**
     * 키 교환시 - RSA 복호화
     */
    private JSONObject getBodyJsonForRSADecryption(HttpServletRequest httpServletRequest) throws FrameException {
        JSONObject bodyJson = getBodyJsonByMessage(httpServletRequest);

        String clientSeedKey = RsaUtil.getInstance()
                .decryptRsaData(bodyJson.optString(ProtocolConstants.CLIENT_SEED_KEY));
        String clientSeedIV = RsaUtil.getInstance()
                .decryptRsaData(bodyJson.optString(ProtocolConstants.CLIENT_SEED_IV));

        logger.debug("clientSeedKey : " + clientSeedKey);
        logger.debug("clientSeedIV : " + clientSeedIV);

        String message = SeedUtil.getSeedDecrypt(clientSeedKey, clientSeedIV,
                bodyJson.optString(ProtocolConstants.PARAMETER_NAME));

        if (message == null) {
            throw new FrameException(messageSource, ExceptionConstants.RSA_DECRYPTION_EXCEPTION);
        }

        try {
            bodyJson.put(ProtocolConstants.PARAMETER_NAME, message);
        } catch (Exception e) {
            throw new FrameException(messageSource, ExceptionConstants.FAIL_MAKE_REQUEST_FAIL_BODY_JSON);
        }

        httpServletRequest.getSession().setAttribute(SessionConstants.CLIENT_SEED_KEY, clientSeedKey);
        httpServletRequest.getSession().setAttribute(SessionConstants.CLIENT_SEED_IV, clientSeedIV);

        return bodyJson;
    }

    /**
     * 일반 - SEED 복호화
     */
    private JSONObject getBodyJsonForSeedDycryption(HttpServletRequest httpServletRequest) throws FrameException {
        JSONObject bodyJson = getBodyJsonByMessage(httpServletRequest);

        String serverSeedKey = (String) httpServletRequest.getSession().getAttribute(SessionConstants.SERVER_SEED_KEY);
        String serverSeedIV = (String) httpServletRequest.getSession().getAttribute(SessionConstants.SERVER_SEED_IV);

        String message = SeedUtil.getSeedDecrypt(serverSeedKey, serverSeedIV,
                bodyJson.optString(ProtocolConstants.PARAMETER_NAME));

        if (message == null) {
            throw new FrameException(messageSource, ExceptionConstants.SERVER_SEED_DECRYPTION_EXCEPTION);
        }

        try {
            bodyJson.put(ProtocolConstants.PARAMETER_NAME, message);
        } catch (Exception e) {
            throw new FrameException(messageSource, ExceptionConstants.FAIL_MAKE_JSONOBJECT_REQUEST_MESSAGE);
        }

        logger.debug("getBodyJsonForSeedDycryption decryption : " + bodyJson.toString());

        return bodyJson;
    }

    /**
     * application/json
     */
    private JSONObject getBodyJsonByMessage(HttpServletRequest httpServletRequest) throws FrameException {
        StringBuffer stringBuffer = new StringBuffer();
        BufferedReader reader = null;
        String line = null;
        JSONObject bodyJson = null;

        try {
            reader = httpServletRequest.getReader();
            while ((line = reader.readLine()) != null) {
                stringBuffer.append(line);
            }

            logger.debug("getBodyJsonByMessage : " + stringBuffer.toString());

            bodyJson = new JSONObject(stringBuffer.toString());

        } catch (Exception e) {
            logger.debug("exception getBodyJsonByMessage");
            logger.debug(e.getMessage());
            // TODO: handle exception
        }

        return bodyJson;
    }

    public JSONObject getRequestJson() {
        return requestJson;
    }

    public void setRequestJson(JSONObject requestJson) {
        this.requestJson = requestJson;
    }

    public JSONObject getRequestHeadJson() {
        return requestHeadJson;
    }

    public void setRequestHeadJson(JSONObject requestHeadJson) {
        this.requestHeadJson = requestHeadJson;
    }

    public JSONObject getRequestBodyJson() {
        return requestBodyJson;
    }

    public void setRequestBodyJson(JSONObject requestBodyJson) {
        this.requestBodyJson = requestBodyJson;
    }

    public String getOsType() {
        return osType;
    }

    public void setOsType(String osType) {
        this.osType = osType;
    }

    public String getOsVersion() {
        return osVersion;
    }

    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceMac() {
        return deviceMac;
    }

    public void setDeviceMac(String deviceMac) {
        this.deviceMac = deviceMac;
    }

}
