package com.hyundaicard.cse.common.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class RemoveDoubleMarkTag extends SimpleTagSupport {

    private String value;

    public RemoveDoubleMarkTag() {
    }

    public void setValue(final String value) {
        this.value = value;
    }

    @Override
    public void doTag() throws JspException, IOException {
        final int cnt = value.length();
        if (cnt > 0 && "\"".equals(String.valueOf(value.charAt(0))) && "\"".equals(String.valueOf(value.charAt(cnt - 1)))) {
            value = value.substring(1, cnt - 1);
        }
        getJspContext().getOut().write(value);
    }

}
