package com.hyundaicard.cse.common.interceptor;

import java.io.BufferedReader;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hyundaicard.cse.common.constants.ProtocolConstants;
import com.hyundaicard.cse.common.util.StringUtil;

public class AbstractInterceptor extends HandlerInterceptorAdapter {

    protected void modifyModelAndView(ModelAndView modelAndView, JSONObject json) throws Exception {
        HashMap<String, Object> responseMap = new HashMap<String, Object>();

        ObjectMapper objectMapper = new ObjectMapper();

        responseMap = objectMapper.readValue(StringUtil.getConvertFullToHalf(json.toString()),
                new TypeReference<Map<String, Object>>() {
                });

        modelAndView.addAllObjects(responseMap);
    }

    protected JSONObject getBodyJsonForApplicationJson(HttpServletRequest request) throws Exception {
        StringBuffer stringBuffer = new StringBuffer();
        String line = null;

        BufferedReader reader = request.getReader();
        while ((line = reader.readLine()) != null) {
            stringBuffer.append(line);
        }

        return new JSONObject(stringBuffer.toString());
    }

    protected JSONObject getBodyJsonForApplicationForm(HttpServletRequest request) throws Exception {
        return new JSONObject(request.getParameter(ProtocolConstants.PARAMETER_NAME));
    }
}
