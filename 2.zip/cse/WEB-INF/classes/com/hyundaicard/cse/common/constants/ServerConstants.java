package com.hyundaicard.cse.common.constants;

public class ServerConstants {

    public static final int ENC_TYPE_TEXT = 0;
    public static final int ENC_TYPE_RSA = 1;
    public static final int ENC_TYPE_SEED = 2;

    public static final String ENCRYPT_YN = "ENC_YN";
    public static final String ENCRYPT_SUCCESS = "Y";
    public static final String ENCRYPT_FAIL = "N";

}
