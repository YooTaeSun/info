package com.hyundaicard.cse.common.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.apache.commons.lang3.StringUtils;

public class FirstUpperCaseTag extends SimpleTagSupport {

    private String value;

    public FirstUpperCaseTag() {
    }

    public void setValue(final String value) {
        this.value = value;
    }

    @Override
    public void doTag() throws JspException, IOException {
        if (!StringUtils.isBlank(value)) {
            value = String.valueOf(value.charAt(0)).toUpperCase() + value.substring(1);
        }
        getJspContext().getOut().write(value);
    }

}
