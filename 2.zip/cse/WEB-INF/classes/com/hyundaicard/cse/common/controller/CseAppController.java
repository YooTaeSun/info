package com.hyundaicard.cse.common.controller;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.dao.DataAccessException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hyundaicard.cse.common.constants.ExceptionConstants;
import com.hyundaicard.cse.common.constants.ProtocolConstants;
import com.hyundaicard.cse.common.constants.ServerConstants;
import com.hyundaicard.cse.common.constants.SessionConstants;
import com.hyundaicard.cse.common.exception.BizException;
import com.hyundaicard.cse.common.exception.FrameException;
import com.hyundaicard.cse.common.exception.SessionException;
import com.hyundaicard.cse.common.util.SeedUtil;
import com.hyundaicard.cse.common.view.Request;
import com.hyundaicard.cse.common.view.Response;

public class CseAppController {

    public static final String RESULTCODE = "resultCode";
    public static final String RESULTMESSAGE = "resultMessage";

    private static final Logger logger = LoggerFactory.getLogger(CseAppController.class);

    @Autowired
    public MessageSource messageSource;

    public ModelAndView createJSONModelAndView(HttpServletRequest httpServletRequest,
            HttpServletResponse httpServletResponse, Model model, String resultCode) {

        logger.debug("createJSONModelAndView");

        model.addAttribute(RESULTCODE, resultCode);
        model.addAttribute(RESULTMESSAGE, getMessage(resultCode));

        return new ModelAndView("defaultJsonView", model.asMap());
    }

    @ExceptionHandler(Exception.class)
    public ModelAndView handleException(Exception e, HttpServletRequest httpServletRequest,
            HttpServletResponse httpServletResponse) {

        logger.debug("handle Exception!! - exceptionName : " + e.getClass().getName());

        Response response = null;

        String resultCode = "DEFAULT0001";
        String resultMessage = "";

        if (e instanceof BizException) {
            logger.debug("BizException");
            resultCode = ((BizException) e).getMessageKey();
            resultMessage = messageSource.getMessage(resultCode, null, null, Locale.getDefault());

        } else if (e instanceof FrameException) {
            logger.debug("FRAMException");
            resultCode = ((BizException) e).getMessageKey();
            resultMessage = messageSource.getMessage(resultCode, null, null, Locale.getDefault());

        } else if (e instanceof DataAccessException) {
            resultCode = ((DataAccessException) e).getMessage();

            if (resultCode.indexOf(";") > -1) {
                resultCode = resultCode.substring(0, resultCode.indexOf(";"));

                if (resultCode.equals(ExceptionConstants.DB_SELECT_EXCEPTION)
                        || resultCode.equals(ExceptionConstants.DB_DELETE_EXCEPTION)
                        || resultCode.equals(ExceptionConstants.DB_INSERT_EXCEPTION)
                        || resultCode.equals(ExceptionConstants.DB_UPDATE_EXCEPTION)) {
                    resultMessage = messageSource.getMessage(resultCode, null, null, Locale.getDefault());
                } else {
                    resultMessage = messageSource.getMessage(resultCode,
                            new String[] { "[" + e.getClass().getName() + "]" }, null, Locale.getDefault());
                }
            }

        } else if (e instanceof SessionException) {
            resultCode = ((SessionException) e).getMessageKey();
            resultMessage = getMessage(resultCode);
            resultMessage = messageSource.getMessage(resultCode, null, null, Locale.getDefault());
        } else if (e instanceof Exception) {
            resultMessage = messageSource.getMessage(resultCode, new String[] { "[" + e.getClass().getName() + "]" },
                    null, Locale.getDefault());
        } else {
            resultMessage = messageSource.getMessage(resultCode, new String[] { "[" + e.getClass().getName() + "]" },
                    null, Locale.getDefault());
        }

        try {
            return createResponseModelAndView(httpServletRequest, httpServletResponse, resultCode, resultMessage);
        } catch (Exception e2) {
            try {
                response = new Response(ExceptionConstants.FRAME_EXCEPTION, e.getMessage());
            } catch (Exception e3) {
                logger.error("[handleException!!!]" + e3.getMessage());
            }
        }

        return createJSONModelAndView(httpServletRequest, httpServletResponse, response);
    }

    /**
     * responseVO를 전달받아 ModelAndView로 변환한다. Body JSON에 Head를 붙이고 암호화를 수행한다.
     */
    private ModelAndView createJSONModelAndView(HttpServletRequest httpServletRequest,
            HttpServletResponse httpServletResponse, Response response) {
        logger.info("createJSONModelAndView - bodyJson : " + response.getResponseBodyJson().toString());
        HashMap<String, Object> responseMap = null;

        ObjectMapper objectMapper = new ObjectMapper();

        JSONObject responseJson = null;

        try {
            int encType = getEncryptType(httpServletRequest);

            responseJson = getEncryptMessage(encType, httpServletRequest, response);
            logger.info("encMessage - responseJson : " + responseJson.toString());
            setHttpHeaderForEncryptionSuccess(httpServletResponse);

            responseMap = objectMapper.readValue(responseJson.toString(), new TypeReference<Map<String, Object>>() {
            });

            logger.info("responseMap : " + responseMap);

        } catch (Exception e) {
            logger.debug(e.getMessage());
            
        } finally {
            if (responseMap == null) {
                try {
                    return createResponseModelAndView(httpServletRequest, httpServletResponse, "SERVER0002");
                } catch (Exception e) {
            
                    e.printStackTrace();
                }
            }
        }

        return new ModelAndView("defaultJsonView", responseMap);
    }

    private void setHttpHeaderForEncryptionSuccess(HttpServletResponse httpServletReponse) {
        httpServletReponse.setHeader(SessionConstants.ENCRYPTION_YN, "Y");
    }

    /** server 처리 로직에서 error 발생시 */
    public ModelAndView createResponseModelAndView(HttpServletRequest httpServletRequest,
            HttpServletResponse httpServletResponse, String resultCode, String resultMessage) throws Exception {

        Response response = new Response(resultCode, resultMessage);

        return createJSONModelAndView(httpServletRequest, httpServletResponse, response);
    }

    /** server 처리 로직에서 error 발생시 */
    public ModelAndView createResponseModelAndView(HttpServletRequest httpServletRequest,
            HttpServletResponse httpServletResponse, String resultCode) throws Exception {

        Response response = new Response(resultCode, getMessage(resultCode));

        return createJSONModelAndView(httpServletRequest, httpServletResponse, response);
    }

    /** Biz - Success */
    public ModelAndView createResponseModelAndView(HttpServletRequest httpServletRequest,
            HttpServletResponse httpServletResponse, Request request, JSONObject bodyJson) throws Exception {
        logger.info("success - bodyJson : " + bodyJson.toString());
        Response response = new Response(bodyJson, ProtocolConstants.RESULT_CODE_SUCSESS,
                getMessage(ProtocolConstants.RESULT_CODE_SUCSESS));

        return createJSONModelAndView(httpServletRequest, httpServletResponse, response);
    }

    /** Biz - error */
    public ModelAndView createResponseModelAndView(HttpServletRequest httpServletRequest,
            HttpServletResponse httpServletResponse, Request request, JSONObject bodyJson, String resultCode)
            throws Exception {
        Response response = new Response(bodyJson, resultCode, getMessage(resultCode));

        return createJSONModelAndView(httpServletRequest, httpServletResponse, response);
    }

    private int getEncryptType(HttpServletRequest httpServletRequest) {
        String encryptionYN = httpServletRequest.getHeader(ProtocolConstants.ENCRYPTION_YN);

        if (encryptionYN != null && encryptionYN.equals("N")) {
            return ServerConstants.ENC_TYPE_TEXT;
        }

        String useRsa = (String) httpServletRequest.getAttribute(SessionConstants.USE_RSA_ENCRYPTION_YN);
        String useSeed = (String) httpServletRequest.getAttribute(SessionConstants.USE_SEED_ENCRYPTION_YN);

        if (useRsa != null && useRsa.equals("Y")) {
            return ServerConstants.ENC_TYPE_RSA;
        } else if (useSeed != null && useSeed.equals("Y")) {
            return ServerConstants.ENC_TYPE_SEED;
        } else {
            return ServerConstants.ENC_TYPE_TEXT;
        }
    }

    private JSONObject getEncryptMessage(int encType, HttpServletRequest httpServletRequest, Response response)
            throws Exception {
        JSONObject bodyJson = null;

        switch (encType) {
        case ServerConstants.ENC_TYPE_TEXT:
            bodyJson = response.getResponseJson();
            break;
        case ServerConstants.ENC_TYPE_RSA:
            bodyJson = getBodyJsonForClientSeedEncryption(httpServletRequest, response);
            break;
        case ServerConstants.ENC_TYPE_SEED:
            bodyJson = getBodyJsonForServerSeedEncryption(httpServletRequest, response);
            break;
        }

        return bodyJson;
    }

    private JSONObject getBodyJsonForClientSeedEncryption(HttpServletRequest httpServletRequest, Response response)
            throws Exception {
        HttpSession httpSession = httpServletRequest.getSession();

        JSONObject responseJson = response.getResponseJson();

        String message = responseJson.optString(ProtocolConstants.PARAMETER_NAME);
        logger.debug("getBodyJsonForClientSeedEncryption");
        String encMessage = SeedUtil.getSeedEnecrypt(
                (String) httpSession.getAttribute(SessionConstants.CLIENT_SEED_KEY),
                (String) httpSession.getAttribute(SessionConstants.CLIENT_SEED_IV), message);

        if (encMessage == null) {

            responseJson.put(ProtocolConstants.PARAMETER_NAME, new JSONObject(message));
            responseJson.put(ProtocolConstants.ENCRYPTION_YN, ServerConstants.ENCRYPT_FAIL);
            return responseJson;
        }

        responseJson.put(ProtocolConstants.PARAMETER_NAME, encMessage);

        return responseJson;

    }

    private JSONObject getBodyJsonForServerSeedEncryption(HttpServletRequest httpServletRequest, Response response)
            throws Exception {
        HttpSession httpSession = httpServletRequest.getSession();

        JSONObject responseJson = response.getResponseJson();

        String message = responseJson.optString(ProtocolConstants.PARAMETER_NAME);

        String encMessage = SeedUtil.getSeedEnecrypt(
                (String) httpSession.getAttribute(SessionConstants.SERVER_SEED_KEY),
                (String) httpSession.getAttribute(SessionConstants.SERVER_SEED_IV), message);

        if (encMessage == null) {
            JSONObject jsonObject = new JSONObject(message);
            responseJson.put(ProtocolConstants.PARAMETER_NAME, jsonObject);
            responseJson.put(ProtocolConstants.ENCRYPTION_YN, ServerConstants.ENCRYPT_FAIL);
        }

        responseJson.put(ProtocolConstants.PARAMETER_NAME, encMessage);

        return responseJson;

    }

    public String getMessage(String resultCode) {
        return messageSource.getMessage(resultCode, null, Locale.getDefault());
    }

}
