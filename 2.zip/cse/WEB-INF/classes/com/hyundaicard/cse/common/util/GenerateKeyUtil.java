package com.hyundaicard.cse.common.util;

import java.text.SimpleDateFormat;
import java.util.UUID;

public class GenerateKeyUtil {

    /** random UUID 생성 */
    public static String getUUID() {
        return UUID.randomUUID().toString().replaceAll("-", "");
    }

    /** random SEED Key 생성 */
    public static String getSeedKey() {
        SimpleDateFormat dateTimeFormat = new SimpleDateFormat("HHmmss");
        return dateTimeFormat.format(new java.util.Date()) + getRandomString(10);
    }

    /** random SEED IV 생성 */
    public static String getSeedIV() {
        SimpleDateFormat dateTimeFormat = new SimpleDateFormat("HHmmss");
        return dateTimeFormat.format(new java.util.Date()) + getRandomString(10);
    }

    /** random 숫자 size만큼 생성 */
    public static String getRandomString(int size) {
        StringBuffer sb = new StringBuffer(size);

        for (int i = 0; i < size; i++) {
            int random = (int) (Math.random() * 10);
            sb.append(random);
        }

        return sb.toString();
    }
}
