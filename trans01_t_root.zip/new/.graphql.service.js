/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class GraphqlService {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async add(params) {

    params = {

    }

    let query = `mutation add($input: Filter) {
      one : add(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modify(params) {

    let query = `mutation modify($input: Filter) {
      one : modify(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async remove(params) {

    params = {
    }

    let query = `mutation remove($input: Filter) {
      one : remove(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async get(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      one: get(filter:$params) {

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async getList(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      cnt: getCnt(filter:$params)   
      list: getList(filter:$params) {

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new GraphqlService();
