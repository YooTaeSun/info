/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class Graphql매수매도판단결과000020Service {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async add매수매도판단결과000020(params) {

    params = {
             일자: ''    // 일자
            ,매수매도종류: ''    // 매수,매도
            ,전략: ''    // 전략
            ,ohlc: ''    // o_h_l_c
            ,key: ''    // key
            ,결과: ''    // Y,N
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation add매수매도판단결과000020($input: Filter) {
      one : add매수매도판단결과000020(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modify매수매도판단결과000020(params) {

    let query = `mutation modify매수매도판단결과000020($input: Filter) {
      one : modify매수매도판단결과000020(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async remove매수매도판단결과000020(params) {

    params = {
    }

    let query = `mutation remove매수매도판단결과000020($input: Filter) {
      one : remove매수매도판단결과000020(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async get매수매도판단결과000020(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      one: get매수매도판단결과000020(filter:$params) {
			일자
			매수매도종류
			전략
			ohlc
			key
			결과
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async get매수매도판단결과000020List(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      cnt: get매수매도판단결과000020Cnt(filter:$params)   
      list: get매수매도판단결과000020List(filter:$params) {
			일자
			매수매도종류
			전략
			ohlc
			key
			결과
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new Graphql매수매도판단결과000020Service();
