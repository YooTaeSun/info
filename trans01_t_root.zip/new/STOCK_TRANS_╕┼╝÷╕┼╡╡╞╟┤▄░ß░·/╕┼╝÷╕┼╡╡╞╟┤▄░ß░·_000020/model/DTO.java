package .model.dto;
import java.util.Date;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DTO {

	/**
	 * 일자(PK)
	 */
	@ApiModelProperty(value = "일자: 일자")
	private String 일자;

	/**
	 * 매수,매도(PK)
	 */
	@ApiModelProperty(value = "매수매도종류: 매수,매도")
	private String 매수매도종류;

	/**
	 * 전략(PK)
	 */
	@ApiModelProperty(value = "전략: 전략")
	private String 전략;

	/**
	 * o_h_l_c(PK)
	 */
	@ApiModelProperty(value = "ohlc: o_h_l_c")
	private String ohlc;

	/**
	 * key(PK)
	 */
	@ApiModelProperty(value = "key: key")
	private String key;

	/**
	 * Y,N
	 */
	@ApiModelProperty(value = "결과: Y,N")
	private String 결과;

	/**
	 * 입력날짜
	 */
	@ApiModelProperty(value = "insertDate: 입력날짜")
	private Date insertDate;

	/**
	 * 수정날짜
	 */
	@ApiModelProperty(value = "updateDate: 수정날짜")
	private Date updateDate;


}
