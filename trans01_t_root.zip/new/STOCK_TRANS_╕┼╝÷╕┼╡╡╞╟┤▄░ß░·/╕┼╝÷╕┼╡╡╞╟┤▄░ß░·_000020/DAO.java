package .service.dao;

import java.util.List;

import com.osstem.ows.biz.cfg.datasource.OwsMapper;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 * 매수매도판단결과_ 000020 DAO
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.08.07.						최초작성
 * </pre>
 */
@OwsMapper
public interface DAO {

	/**
     * 매수매도판단결과_ 000020 등록, 수정
     * @Method merge매수매도판단결과000020
     * @param Filter
     * @return 등록 또는 수정된 건수
     */	
	public int merge(Filter params);
	
	/**
	 * 매수매도판단결과_ 000020 여러 건 등록
	 * @Method bulkInsert매수매도판단결과000020
	 * @param Filter
	 * @return 여러 건 등록된 건수
	 */	
	public int bulkInsert(Filter params);
	
	/**
	 * 매수매도판단결과_ 000020 등록
	 * @Method insert매수매도판단결과000020
	 * @param Filter
	 * @return 등록된 건수
	 */	
	public int insert(Filter params);
	
    /**
     * 매수매도판단결과_ 000020 수정
     * @Method update매수매도판단결과000020
     * @param Filter
     * @return 수정된 건수
     */	
	public int update(Filter params);
	
    /**
     * 매수매도판단결과_ 000020 삭제 
     * @Method delete매수매도판단결과000020
     * @param Filter
     * @return 삭제된 건수
     */	
	public int delete(Filter params);
 
    /**
     * 매수매도판단결과_ 000020 단건 조회
     *
     * @param Filter
     * @return 조회 건
     */	    
	public DTO select(Filter params);

    /**
     * 매수매도판단결과_ 000020 건수 조회
     * @Method select매수매도판단결과000020Cnt
     * @param Filter
     * @return 건수
     */	
    int selectCnt(Filter params);
    
    /**
     * 매수매도판단결과_ 000020 다건 조회
     * @Method select매수매도판단결과000020List
     * @param Filter 
     * @return 조회 목록
     */	
	public List<DTO> selectList(Filter params);
}
