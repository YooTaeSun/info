package .service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import .model.dto.DTO;
import .model.filter.Filter;
import .service.매수매도판단결과000020Service;
import .service.dao.DAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 * 매수매도판단결과_ 000020 ServiceImpl
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.08.07.						최초작성
 * </pre>
 */
@Service("매수매도판단결과000020Service")
public class 매수매도판단결과000020ServiceImpl implements 매수매도판단결과000020Service {

	private static final Logger logger = LoggerFactory.getLogger(매수매도판단결과000020ServiceImpl.class);
	
	@Autowired
    private DAO DAO;
    
	/**
	 * 매수매도판단결과_ 000020 등록, 수정
     * @Method merge매수매도판단결과000020
	 * @param Filter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean merge매수매도판단결과000020(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.merge(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     * 매수매도판단결과_ 000020 여러 건 등록
     * @Method bulkInsert매수매도판단결과000020
     * @param Filter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsert매수매도판단결과000020(Filter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = DAO.bulkInsert(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 * 매수매도판단결과_ 000020 등록
     * @Method insert매수매도판단결과000020
	 * @param Filter
     * @return 등록 여부
	 */
    @Override
    public Boolean insert매수매도판단결과000020(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.insert(params);
        return (result > 0)? true:false;    	
    }

    /**
     * 매수매도판단결과_ 000020 수정
     * @Method update매수매도판단결과000020 
     * @param Filter
     * @Method update매수매도판단결과000020
     * @return 수정 여부
     */
    @Override
    public Boolean update매수매도판단결과000020(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = DAO.update(params);
        return (result > 0)? true:false;        
    }

    /**
     * 매수매도판단결과_ 000020 삭제
     * @Method delete매수매도판단결과000020
     * @param Filter
     * @return 삭제 여부 
     */
    @Override
    public Boolean delete매수매도판단결과000020(Filter params){
        int result = DAO.delete(params);
        return (result > 0)? true:false;
    }
    
    /**
     * 매수매도판단결과_ 000020 단건 조회
     * @Method select매수매도판단결과000020
     * @param  Filter
     * @return 조회 건
     */
    @Override
    public DTO select매수매도판단결과000020(Filter params){
        return DAO.select(params);
    }
    
    /**
     * 매수매도판단결과_ 000020 건수 조회
     * @Method select매수매도판단결과000020Cnt
     * @param  Filter
     * @return 건수
     */
    @Override
    public int select매수매도판단결과000020Cnt(Filter params){
        return DAO.selectCnt(params);
    }

    /**
     * 매수매도판단결과_ 000020 다건 조회
     * @Method select매수매도판단결과000020List
     * @param  Filter
     * @return 조회 목록
     */
    @Override
    public List<DTO> select매수매도판단결과000020List(Filter params){
        return DAO.selectList(params);
    }
}
