package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import .model.dto.DTO;
import .model.filter.Filter;
import .service.매수매도판단결과000020Service;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * 매수매도판단결과_ 000020 GraphQL Query
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.08.07.						최초작성
 * </pre>
 */
@Component
public class 매수매도판단결과000020Query implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(매수매도판단결과000020Mutation.class);
	
	@Autowired
	private 매수매도판단결과000020Service 매수매도판단결과000020Service;

    /**
     * 매수매도판단결과_ 000020 단건 조회
     * @Method get매수매도판단결과000020
     * @param  Filter
     * @return 조회 건
     */
    public DTO get매수매도판단결과000020(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 매수매도판단결과000020Service.select매수매도판단결과000020(params);
    }
    
    /**
     * 매수매도판단결과_ 000020 건수 조회
     * @Method get매수매도판단결과000020Cnt
     * @param  Filter
     * @return 건수
     */
    public int get매수매도판단결과000020Cnt(Filter params){
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 매수매도판단결과000020Service.select매수매도판단결과000020Cnt(params);
    }

    /**
     * 매수매도판단결과_ 000020 다건 조회
     * @Method get매수매도판단결과000020List
     * @param  Filter
     * @return 조회 목록
     */
    public List<DTO> get매수매도판단결과000020List(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 매수매도판단결과000020Service.select매수매도판단결과000020List(params);
    }
}
