package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import .model.filter.Filter;
import .service.매수매도판단결과000020Service;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * 매수매도판단결과_ 000020 GraphQL Mutation
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.08.07.						최초작성
 * </pre>
 */
@Component
public class 매수매도판단결과000020Mutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(매수매도판단결과000020Mutation.class);
	
	@Autowired
	private 매수매도판단결과000020Service 매수매도판단결과000020Service;
	
	/**
	 * 매수매도판단결과_ 000020 등록
     * @Method add매수매도판단결과000020
	 * @param Filter
	 */
    public Boolean add매수매도판단결과000020(Filter params) {
    	try {
    		return 매수매도판단결과000020Service.insert매수매도판단결과000020(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * 매수매도판단결과_ 000020 수정
     * @Method modify매수매도판단결과000020
	 * @param Filter
	 */
	public Boolean modify매수매도판단결과000020(Filter params) {
		try {
			return 매수매도판단결과000020Service.update매수매도판단결과000020(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * 매수매도판단결과_ 000020 삭제
     * @Method remove매수매도판단결과000020
	 * @param Filter
	 */
	public Boolean remove매수매도판단결과000020(Filter params) {
		try {
			return 매수매도판단결과000020Service.delete매수매도판단결과000020(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
