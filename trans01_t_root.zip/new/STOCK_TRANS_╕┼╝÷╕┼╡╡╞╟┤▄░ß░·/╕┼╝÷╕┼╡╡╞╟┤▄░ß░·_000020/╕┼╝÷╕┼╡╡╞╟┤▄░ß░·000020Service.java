package .service;

import java.util.List;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 * 매수매도판단결과_ 000020 서비스
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.08.07.						최초작성
 * </pre>
 */
public interface 매수매도판단결과000020Service {

	/**
	 * 매수매도판단결과_ 000020 등록, 수정
     * @Method merge매수매도판단결과000020
	 * @param Filter
	 */
    public Boolean merge매수매도판단결과000020(Filter params);	
    
	/**
	 * 매수매도판단결과_ 000020 여러 건 등록
     * @Method bulkInsert매수매도판단결과000020
	 * @param Filter
	 */
    public Boolean bulkInsert매수매도판단결과000020(Filter params);	    
	
	/**
	 * 매수매도판단결과_ 000020 등록
     * @Method insert매수매도판단결과000020
	 * @param Filter
	 */
    public Boolean insert매수매도판단결과000020(Filter params);

    /**
     * 매수매도판단결과_ 000020 수정
     * @Method update매수매도판단결과000020
     * @param Filter
     */
    public Boolean update매수매도판단결과000020(Filter params);

    /**
     * 매수매도판단결과_ 000020 삭제
     * @Method delete매수매도판단결과000020
     * @param Filter
     */
    public Boolean delete매수매도판단결과000020(Filter params);
    
    /**
     * 매수매도판단결과_ 000020 단건 조회
     * @Method select매수매도판단결과000020 
     * @param  Filter
     */
    public DTO select매수매도판단결과000020(Filter params);    
    
    /**
     * 매수매도판단결과_ 000020 건수 조회
     * @Method select매수매도판단결과000020Cnt
     * @param  Filter
     */
    public int select매수매도판단결과000020Cnt(Filter params);
    
    /**
     * 매수매도판단결과_ 000020 다건 조회
     * @Method select매수매도판단결과000020List
     * @param  Filter
     */
    public List<DTO> select매수매도판단결과000020List(Filter params);

}
