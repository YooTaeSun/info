package .service.dao;

import java.util.List;

import com.osstem.ows.biz.cfg.datasource.OwsMapper;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 * 키움업종등락 DAO
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.06.12.						최초작성
 * </pre>
 */
@OwsMapper
public interface DAO {

	/**
     * 키움업종등락 등록, 수정
     * @Method merge키움업종등락Kosdaq
     * @param Filter
     * @return 등록 또는 수정된 건수
     */	
	public int merge(Filter params);
	
	/**
	 * 키움업종등락 여러 건 등록
	 * @Method bulkInsert키움업종등락Kosdaq
	 * @param Filter
	 * @return 여러 건 등록된 건수
	 */	
	public int bulkInsert(Filter params);
	
	/**
	 * 키움업종등락 등록
	 * @Method insert키움업종등락Kosdaq
	 * @param Filter
	 * @return 등록된 건수
	 */	
	public int insert(Filter params);
	
    /**
     * 키움업종등락 수정
     * @Method update키움업종등락Kosdaq
     * @param Filter
     * @return 수정된 건수
     */	
	public int update(Filter params);
	
    /**
     * 키움업종등락 삭제 
     * @Method delete키움업종등락Kosdaq
     * @param Filter
     * @return 삭제된 건수
     */	
	public int delete(Filter params);
 
    /**
     * 키움업종등락 단건 조회
     *
     * @param Filter
     * @return 조회 건
     */	    
	public DTO select(Filter params);

    /**
     * 키움업종등락 건수 조회
     * @Method select키움업종등락KosdaqCnt
     * @param Filter
     * @return 건수
     */	
    int selectCnt(Filter params);
    
    /**
     * 키움업종등락 다건 조회
     * @Method select키움업종등락KosdaqList
     * @param Filter 
     * @return 조회 목록
     */	
	public List<DTO> selectList(Filter params);
}
