package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import .model.dto.DTO;
import .model.filter.Filter;
import .service.키움업종등락KosdaqService;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * 키움업종등락 GraphQL Query
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.06.12.						최초작성
 * </pre>
 */
@Component
public class 키움업종등락KosdaqQuery implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(키움업종등락KosdaqMutation.class);
	
	@Autowired
	private 키움업종등락KosdaqService 키움업종등락KosdaqService;

    /**
     * 키움업종등락 단건 조회
     * @Method get키움업종등락Kosdaq
     * @param  Filter
     * @return 조회 건
     */
    public DTO get키움업종등락Kosdaq(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 키움업종등락KosdaqService.select키움업종등락Kosdaq(params);
    }
    
    /**
     * 키움업종등락 건수 조회
     * @Method get키움업종등락KosdaqCnt
     * @param  Filter
     * @return 건수
     */
    public int get키움업종등락KosdaqCnt(Filter params){
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 키움업종등락KosdaqService.select키움업종등락KosdaqCnt(params);
    }

    /**
     * 키움업종등락 다건 조회
     * @Method get키움업종등락KosdaqList
     * @param  Filter
     * @return 조회 목록
     */
    public List<DTO> get키움업종등락KosdaqList(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 키움업종등락KosdaqService.select키움업종등락KosdaqList(params);
    }
}
