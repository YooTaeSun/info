package .service;

import java.util.List;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 * 키움업종등락 서비스
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.06.12.						최초작성
 * </pre>
 */
public interface 키움업종등락KosdaqService {

	/**
	 * 키움업종등락 등록, 수정
     * @Method merge키움업종등락Kosdaq
	 * @param Filter
	 */
    public Boolean merge키움업종등락Kosdaq(Filter params);	
    
	/**
	 * 키움업종등락 여러 건 등록
     * @Method bulkInsert키움업종등락Kosdaq
	 * @param Filter
	 */
    public Boolean bulkInsert키움업종등락Kosdaq(Filter params);	    
	
	/**
	 * 키움업종등락 등록
     * @Method insert키움업종등락Kosdaq
	 * @param Filter
	 */
    public Boolean insert키움업종등락Kosdaq(Filter params);

    /**
     * 키움업종등락 수정
     * @Method update키움업종등락Kosdaq
     * @param Filter
     */
    public Boolean update키움업종등락Kosdaq(Filter params);

    /**
     * 키움업종등락 삭제
     * @Method delete키움업종등락Kosdaq
     * @param Filter
     */
    public Boolean delete키움업종등락Kosdaq(Filter params);
    
    /**
     * 키움업종등락 단건 조회
     * @Method select키움업종등락Kosdaq 
     * @param  Filter
     */
    public DTO select키움업종등락Kosdaq(Filter params);    
    
    /**
     * 키움업종등락 건수 조회
     * @Method select키움업종등락KosdaqCnt
     * @param  Filter
     */
    public int select키움업종등락KosdaqCnt(Filter params);
    
    /**
     * 키움업종등락 다건 조회
     * @Method select키움업종등락KosdaqList
     * @param  Filter
     */
    public List<DTO> select키움업종등락KosdaqList(Filter params);

}
