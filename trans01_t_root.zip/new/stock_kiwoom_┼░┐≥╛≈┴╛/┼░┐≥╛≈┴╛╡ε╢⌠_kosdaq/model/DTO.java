package .model.dto;
import java.util.Date;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DTO {

	/**
	 * 일자
	 */
	@ApiModelProperty(value = "일자: 일자")
	private String 일자;

	/**
	 * 서버시간
	 */
	@ApiModelProperty(value = "서버시간: 서버시간")
	private String 서버시간;

	/**
	 * 체결시간
	 */
	@ApiModelProperty(value = "체결시간: 체결시간")
	private String 체결시간;

	/**
	 * 상승종목수
	 */
	@ApiModelProperty(value = "상승종목수: 상승종목수")
	private Integer 상승종목수;

	/**
	 * 상한종목수
	 */
	@ApiModelProperty(value = "상한종목수: 상한종목수")
	private Integer 상한종목수;

	/**
	 * 보합종목수
	 */
	@ApiModelProperty(value = "보합종목수: 보합종목수")
	private Integer 보합종목수;

	/**
	 * 하락종목수
	 */
	@ApiModelProperty(value = "하락종목수: 하락종목수")
	private Integer 하락종목수;

	/**
	 * 하한종목수
	 */
	@ApiModelProperty(value = "하한종목수: 하한종목수")
	private Integer 하한종목수;

	/**
	 * 누적거래량
	 */
	@ApiModelProperty(value = "누적거래량: 누적거래량")
	private Float 누적거래량;

	/**
	 * 누적거래대금
	 */
	@ApiModelProperty(value = "누적거래대금: 누적거래대금")
	private Float 누적거래대금;

	/**
	 * 현재가
	 */
	@ApiModelProperty(value = "현재가: 현재가")
	private Integer 현재가;

	/**
	 * 전일대비
	 */
	@ApiModelProperty(value = "전일대비: 전일대비")
	private Integer 전일대비;

	/**
	 * 등락율
	 */
	@ApiModelProperty(value = "등락율: 등락율")
	private Float 등락율;

	/**
	 * 거래형성종목수
	 */
	@ApiModelProperty(value = "거래형성종목수: 거래형성종목수")
	private Integer 거래형성종목수;

	/**
	 * 거래형성비율
	 */
	@ApiModelProperty(value = "거래형성비율: 거래형성비율")
	private Float 거래형성비율;

	/**
	 * 전일대비기호
	 */
	@ApiModelProperty(value = "전일대비기호: 전일대비기호")
	private String 전일대비기호;

	/**
	 * 종목코드(PK)
	 */
	@ApiModelProperty(value = "종목코드: 종목코드")
	private String 종목코드;

	/**
	 * 종목명
	 */
	@ApiModelProperty(value = "종목명: 종목명")
	private String 종목명;

	/**
	 * 입력날짜
	 */
	@ApiModelProperty(value = "insertDate: 입력날짜")
	private Date insertDate;

	/**
	 * 수정날짜
	 */
	@ApiModelProperty(value = "updateDate: 수정날짜")
	private Date updateDate;


}
