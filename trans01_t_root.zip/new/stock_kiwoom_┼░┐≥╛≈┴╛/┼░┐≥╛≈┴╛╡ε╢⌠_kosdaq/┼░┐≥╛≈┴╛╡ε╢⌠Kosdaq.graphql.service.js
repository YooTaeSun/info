/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class Graphql키움업종등락KosdaqService {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async add키움업종등락Kosdaq(params) {

    params = {
             일자: ''    // 일자
            ,서버시간: ''    // 서버시간
            ,체결시간: ''    // 체결시간
            ,상승종목수: ''    // 상승종목수
            ,상한종목수: ''    // 상한종목수
            ,보합종목수: ''    // 보합종목수
            ,하락종목수: ''    // 하락종목수
            ,하한종목수: ''    // 하한종목수
            ,누적거래량: ''    // 누적거래량
            ,누적거래대금: ''    // 누적거래대금
            ,현재가: ''    // 현재가
            ,전일대비: ''    // 전일대비
            ,등락율: ''    // 등락율
            ,거래형성종목수: ''    // 거래형성종목수
            ,거래형성비율: ''    // 거래형성비율
            ,전일대비기호: ''    // 전일대비기호
            ,종목코드: ''    // 종목코드
            ,종목명: ''    // 종목명
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation add키움업종등락Kosdaq($input: Filter) {
      one : add키움업종등락Kosdaq(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modify키움업종등락Kosdaq(params) {

    let query = `mutation modify키움업종등락Kosdaq($input: Filter) {
      one : modify키움업종등락Kosdaq(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async remove키움업종등락Kosdaq(params) {

    params = {
    }

    let query = `mutation remove키움업종등락Kosdaq($input: Filter) {
      one : remove키움업종등락Kosdaq(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async get키움업종등락Kosdaq(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      one: get키움업종등락Kosdaq(filter:$params) {
			일자
			서버시간
			체결시간
			상승종목수
			상한종목수
			보합종목수
			하락종목수
			하한종목수
			누적거래량
			누적거래대금
			현재가
			전일대비
			등락율
			거래형성종목수
			거래형성비율
			전일대비기호
			종목코드
			종목명
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async get키움업종등락KosdaqList(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      cnt: get키움업종등락KosdaqCnt(filter:$params)   
      list: get키움업종등락KosdaqList(filter:$params) {
			일자
			서버시간
			체결시간
			상승종목수
			상한종목수
			보합종목수
			하락종목수
			하한종목수
			누적거래량
			누적거래대금
			현재가
			전일대비
			등락율
			거래형성종목수
			거래형성비율
			전일대비기호
			종목코드
			종목명
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new Graphql키움업종등락KosdaqService();
