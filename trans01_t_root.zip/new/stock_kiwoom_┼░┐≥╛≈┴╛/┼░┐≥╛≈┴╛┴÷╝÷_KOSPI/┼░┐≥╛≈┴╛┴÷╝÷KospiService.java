package .service;

import java.util.List;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 * 키움업종지수 서비스
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.06.12.						최초작성
 * </pre>
 */
public interface 키움업종지수KospiService {

	/**
	 * 키움업종지수 등록, 수정
     * @Method merge키움업종지수Kospi
	 * @param Filter
	 */
    public Boolean merge키움업종지수Kospi(Filter params);	
    
	/**
	 * 키움업종지수 여러 건 등록
     * @Method bulkInsert키움업종지수Kospi
	 * @param Filter
	 */
    public Boolean bulkInsert키움업종지수Kospi(Filter params);	    
	
	/**
	 * 키움업종지수 등록
     * @Method insert키움업종지수Kospi
	 * @param Filter
	 */
    public Boolean insert키움업종지수Kospi(Filter params);

    /**
     * 키움업종지수 수정
     * @Method update키움업종지수Kospi
     * @param Filter
     */
    public Boolean update키움업종지수Kospi(Filter params);

    /**
     * 키움업종지수 삭제
     * @Method delete키움업종지수Kospi
     * @param Filter
     */
    public Boolean delete키움업종지수Kospi(Filter params);
    
    /**
     * 키움업종지수 단건 조회
     * @Method select키움업종지수Kospi 
     * @param  Filter
     */
    public DTO select키움업종지수Kospi(Filter params);    
    
    /**
     * 키움업종지수 건수 조회
     * @Method select키움업종지수KospiCnt
     * @param  Filter
     */
    public int select키움업종지수KospiCnt(Filter params);
    
    /**
     * 키움업종지수 다건 조회
     * @Method select키움업종지수KospiList
     * @param  Filter
     */
    public List<DTO> select키움업종지수KospiList(Filter params);

}
