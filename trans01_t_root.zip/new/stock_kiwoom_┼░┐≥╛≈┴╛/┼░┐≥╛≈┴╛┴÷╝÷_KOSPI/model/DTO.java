package .model.dto;
import java.util.Date;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DTO {

	/**
	 * 일자
	 */
	@ApiModelProperty(value = "일자: 일자")
	private String 일자;

	/**
	 * 서버시간
	 */
	@ApiModelProperty(value = "서버시간: 서버시간")
	private String 서버시간;

	/**
	 * 종목코드
	 */
	@ApiModelProperty(value = "종목코드: 종목코드")
	private String 종목코드;

	/**
	 * 종목명
	 */
	@ApiModelProperty(value = "종목명: 종목명")
	private String 종목명;

	/**
	 * 체결시간
	 */
	@ApiModelProperty(value = "체결시간: 체결시간")
	private String 체결시간;

	/**
	 * 현재가
	 */
	@ApiModelProperty(value = "현재가: 현재가")
	private Integer 현재가;

	/**
	 * 전일대비
	 */
	@ApiModelProperty(value = "전일대비: 전일대비")
	private Integer 전일대비;

	/**
	 * 등락율
	 */
	@ApiModelProperty(value = "등락율: 등락율")
	private Float 등락율;

	/**
	 * 거래량
	 */
	@ApiModelProperty(value = "거래량: 거래량")
	private Integer 거래량;

	/**
	 * 누적거래량
	 */
	@ApiModelProperty(value = "누적거래량: 누적거래량")
	private Float 누적거래량;

	/**
	 * 누적거래대금
	 */
	@ApiModelProperty(value = "누적거래대금: 누적거래대금")
	private Float 누적거래대금;

	/**
	 * 시가
	 */
	@ApiModelProperty(value = "시가: 시가")
	private Integer 시가;

	/**
	 * 고가
	 */
	@ApiModelProperty(value = "고가: 고가")
	private Integer 고가;

	/**
	 * 저가
	 */
	@ApiModelProperty(value = "저가: 저가")
	private Integer 저가;

	/**
	 * 전일대비기호
	 */
	@ApiModelProperty(value = "전일대비기호: 전일대비기호")
	private String 전일대비기호;

	/**
	 * 전일거래량대비_계약_주
	 */
	@ApiModelProperty(value = "전일거래량대비계약주: 전일거래량대비_계약_주")
	private Float 전일거래량대비계약주;

	/**
	 * 입력날짜
	 */
	@ApiModelProperty(value = "insertDate: 입력날짜")
	private Date insertDate;

	/**
	 * 수정날짜
	 */
	@ApiModelProperty(value = "updateDate: 수정날짜")
	private Date updateDate;


}
