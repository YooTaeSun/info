/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class Graphql키움업종지수KospiService {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async add키움업종지수Kospi(params) {

    params = {
             일자: ''    // 일자
            ,서버시간: ''    // 서버시간
            ,종목코드: ''    // 종목코드
            ,종목명: ''    // 종목명
            ,체결시간: ''    // 체결시간
            ,현재가: ''    // 현재가
            ,전일대비: ''    // 전일대비
            ,등락율: ''    // 등락율
            ,거래량: ''    // 거래량
            ,누적거래량: ''    // 누적거래량
            ,누적거래대금: ''    // 누적거래대금
            ,시가: ''    // 시가
            ,고가: ''    // 고가
            ,저가: ''    // 저가
            ,전일대비기호: ''    // 전일대비기호
            ,전일거래량대비계약주: ''    // 전일거래량대비_계약_주
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation add키움업종지수Kospi($input: Filter) {
      one : add키움업종지수Kospi(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modify키움업종지수Kospi(params) {

    let query = `mutation modify키움업종지수Kospi($input: Filter) {
      one : modify키움업종지수Kospi(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async remove키움업종지수Kospi(params) {

    params = {
    }

    let query = `mutation remove키움업종지수Kospi($input: Filter) {
      one : remove키움업종지수Kospi(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async get키움업종지수Kospi(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      one: get키움업종지수Kospi(filter:$params) {
			일자
			서버시간
			종목코드
			종목명
			체결시간
			현재가
			전일대비
			등락율
			거래량
			누적거래량
			누적거래대금
			시가
			고가
			저가
			전일대비기호
			전일거래량대비계약주
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async get키움업종지수KospiList(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      cnt: get키움업종지수KospiCnt(filter:$params)   
      list: get키움업종지수KospiList(filter:$params) {
			일자
			서버시간
			종목코드
			종목명
			체결시간
			현재가
			전일대비
			등락율
			거래량
			누적거래량
			누적거래대금
			시가
			고가
			저가
			전일대비기호
			전일거래량대비계약주
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new Graphql키움업종지수KospiService();
