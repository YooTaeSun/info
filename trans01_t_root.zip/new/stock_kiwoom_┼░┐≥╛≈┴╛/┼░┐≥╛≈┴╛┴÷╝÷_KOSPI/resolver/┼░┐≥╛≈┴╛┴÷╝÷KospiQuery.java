package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import .model.dto.DTO;
import .model.filter.Filter;
import .service.키움업종지수KospiService;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * 키움업종지수 GraphQL Query
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.06.12.						최초작성
 * </pre>
 */
@Component
public class 키움업종지수KospiQuery implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(키움업종지수KospiMutation.class);
	
	@Autowired
	private 키움업종지수KospiService 키움업종지수KospiService;

    /**
     * 키움업종지수 단건 조회
     * @Method get키움업종지수Kospi
     * @param  Filter
     * @return 조회 건
     */
    public DTO get키움업종지수Kospi(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 키움업종지수KospiService.select키움업종지수Kospi(params);
    }
    
    /**
     * 키움업종지수 건수 조회
     * @Method get키움업종지수KospiCnt
     * @param  Filter
     * @return 건수
     */
    public int get키움업종지수KospiCnt(Filter params){
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 키움업종지수KospiService.select키움업종지수KospiCnt(params);
    }

    /**
     * 키움업종지수 다건 조회
     * @Method get키움업종지수KospiList
     * @param  Filter
     * @return 조회 목록
     */
    public List<DTO> get키움업종지수KospiList(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 키움업종지수KospiService.select키움업종지수KospiList(params);
    }
}
