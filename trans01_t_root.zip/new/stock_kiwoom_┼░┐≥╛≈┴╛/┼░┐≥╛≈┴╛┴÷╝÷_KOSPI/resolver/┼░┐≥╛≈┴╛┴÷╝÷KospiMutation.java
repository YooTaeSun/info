package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import .model.filter.Filter;
import .service.키움업종지수KospiService;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * 키움업종지수 GraphQL Mutation
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.06.12.						최초작성
 * </pre>
 */
@Component
public class 키움업종지수KospiMutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(키움업종지수KospiMutation.class);
	
	@Autowired
	private 키움업종지수KospiService 키움업종지수KospiService;
	
	/**
	 * 키움업종지수 등록
     * @Method add키움업종지수Kospi
	 * @param Filter
	 */
    public Boolean add키움업종지수Kospi(Filter params) {
    	try {
    		return 키움업종지수KospiService.insert키움업종지수Kospi(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * 키움업종지수 수정
     * @Method modify키움업종지수Kospi
	 * @param Filter
	 */
	public Boolean modify키움업종지수Kospi(Filter params) {
		try {
			return 키움업종지수KospiService.update키움업종지수Kospi(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * 키움업종지수 삭제
     * @Method remove키움업종지수Kospi
	 * @param Filter
	 */
	public Boolean remove키움업종지수Kospi(Filter params) {
		try {
			return 키움업종지수KospiService.delete키움업종지수Kospi(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
