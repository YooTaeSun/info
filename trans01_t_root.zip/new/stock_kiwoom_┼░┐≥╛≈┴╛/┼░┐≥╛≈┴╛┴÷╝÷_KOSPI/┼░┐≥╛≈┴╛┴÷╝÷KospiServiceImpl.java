package .service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import .model.dto.DTO;
import .model.filter.Filter;
import .service.키움업종지수KospiService;
import .service.dao.DAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 * 키움업종지수 ServiceImpl
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.06.12.						최초작성
 * </pre>
 */
@Service("키움업종지수KospiService")
public class 키움업종지수KospiServiceImpl implements 키움업종지수KospiService {

	private static final Logger logger = LoggerFactory.getLogger(키움업종지수KospiServiceImpl.class);
	
	@Autowired
    private DAO DAO;
    
	/**
	 * 키움업종지수 등록, 수정
     * @Method merge키움업종지수Kospi
	 * @param Filter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean merge키움업종지수Kospi(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.merge(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     * 키움업종지수 여러 건 등록
     * @Method bulkInsert키움업종지수Kospi
     * @param Filter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsert키움업종지수Kospi(Filter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = DAO.bulkInsert(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 * 키움업종지수 등록
     * @Method insert키움업종지수Kospi
	 * @param Filter
     * @return 등록 여부
	 */
    @Override
    public Boolean insert키움업종지수Kospi(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.insert(params);
        return (result > 0)? true:false;    	
    }

    /**
     * 키움업종지수 수정
     * @Method update키움업종지수Kospi 
     * @param Filter
     * @Method update키움업종지수Kospi
     * @return 수정 여부
     */
    @Override
    public Boolean update키움업종지수Kospi(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = DAO.update(params);
        return (result > 0)? true:false;        
    }

    /**
     * 키움업종지수 삭제
     * @Method delete키움업종지수Kospi
     * @param Filter
     * @return 삭제 여부 
     */
    @Override
    public Boolean delete키움업종지수Kospi(Filter params){
        int result = DAO.delete(params);
        return (result > 0)? true:false;
    }
    
    /**
     * 키움업종지수 단건 조회
     * @Method select키움업종지수Kospi
     * @param  Filter
     * @return 조회 건
     */
    @Override
    public DTO select키움업종지수Kospi(Filter params){
        return DAO.select(params);
    }
    
    /**
     * 키움업종지수 건수 조회
     * @Method select키움업종지수KospiCnt
     * @param  Filter
     * @return 건수
     */
    @Override
    public int select키움업종지수KospiCnt(Filter params){
        return DAO.selectCnt(params);
    }

    /**
     * 키움업종지수 다건 조회
     * @Method select키움업종지수KospiList
     * @param  Filter
     * @return 조회 목록
     */
    @Override
    public List<DTO> select키움업종지수KospiList(Filter params){
        return DAO.selectList(params);
    }
}
