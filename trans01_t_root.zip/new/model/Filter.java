package .model.filter;

import com.osstem.ows.biz.cmm.model.filter.PageFilter;
import .model.dto.DTO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class Filter extends DTO {
	
	/**
	 * pageFilter 객체
	 */
	@ApiModelProperty(value = "pageFilter: pageFilter 객체")
	private PageFilter pageFilter;
}
