package .service;

import java.util.List;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 * 손절가_ 000020 서비스
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.04.13.						최초작성
 * </pre>
 */
public interface 손절가000020Service {

	/**
	 * 손절가_ 000020 등록, 수정
     * @Method merge손절가000020
	 * @param Filter
	 */
    public Boolean merge손절가000020(Filter params);	
    
	/**
	 * 손절가_ 000020 여러 건 등록
     * @Method bulkInsert손절가000020
	 * @param Filter
	 */
    public Boolean bulkInsert손절가000020(Filter params);	    
	
	/**
	 * 손절가_ 000020 등록
     * @Method insert손절가000020
	 * @param Filter
	 */
    public Boolean insert손절가000020(Filter params);

    /**
     * 손절가_ 000020 수정
     * @Method update손절가000020
     * @param Filter
     */
    public Boolean update손절가000020(Filter params);

    /**
     * 손절가_ 000020 삭제
     * @Method delete손절가000020
     * @param Filter
     */
    public Boolean delete손절가000020(Filter params);
    
    /**
     * 손절가_ 000020 단건 조회
     * @Method select손절가000020 
     * @param  Filter
     */
    public DTO select손절가000020(Filter params);    
    
    /**
     * 손절가_ 000020 건수 조회
     * @Method select손절가000020Cnt
     * @param  Filter
     */
    public int select손절가000020Cnt(Filter params);
    
    /**
     * 손절가_ 000020 다건 조회
     * @Method select손절가000020List
     * @param  Filter
     */
    public List<DTO> select손절가000020List(Filter params);

}
