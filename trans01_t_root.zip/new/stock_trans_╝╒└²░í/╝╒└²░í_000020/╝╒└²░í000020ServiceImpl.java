package .service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import .model.dto.DTO;
import .model.filter.Filter;
import .service.손절가000020Service;
import .service.dao.DAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 * 손절가_ 000020 ServiceImpl
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.04.13.						최초작성
 * </pre>
 */
@Service("손절가000020Service")
public class 손절가000020ServiceImpl implements 손절가000020Service {

	private static final Logger logger = LoggerFactory.getLogger(손절가000020ServiceImpl.class);
	
	@Autowired
    private DAO DAO;
    
	/**
	 * 손절가_ 000020 등록, 수정
     * @Method merge손절가000020
	 * @param Filter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean merge손절가000020(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.merge(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     * 손절가_ 000020 여러 건 등록
     * @Method bulkInsert손절가000020
     * @param Filter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsert손절가000020(Filter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = DAO.bulkInsert(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 * 손절가_ 000020 등록
     * @Method insert손절가000020
	 * @param Filter
     * @return 등록 여부
	 */
    @Override
    public Boolean insert손절가000020(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.insert(params);
        return (result > 0)? true:false;    	
    }

    /**
     * 손절가_ 000020 수정
     * @Method update손절가000020 
     * @param Filter
     * @Method update손절가000020
     * @return 수정 여부
     */
    @Override
    public Boolean update손절가000020(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = DAO.update(params);
        return (result > 0)? true:false;        
    }

    /**
     * 손절가_ 000020 삭제
     * @Method delete손절가000020
     * @param Filter
     * @return 삭제 여부 
     */
    @Override
    public Boolean delete손절가000020(Filter params){
        int result = DAO.delete(params);
        return (result > 0)? true:false;
    }
    
    /**
     * 손절가_ 000020 단건 조회
     * @Method select손절가000020
     * @param  Filter
     * @return 조회 건
     */
    @Override
    public DTO select손절가000020(Filter params){
        return DAO.select(params);
    }
    
    /**
     * 손절가_ 000020 건수 조회
     * @Method select손절가000020Cnt
     * @param  Filter
     * @return 건수
     */
    @Override
    public int select손절가000020Cnt(Filter params){
        return DAO.selectCnt(params);
    }

    /**
     * 손절가_ 000020 다건 조회
     * @Method select손절가000020List
     * @param  Filter
     * @return 조회 목록
     */
    @Override
    public List<DTO> select손절가000020List(Filter params){
        return DAO.selectList(params);
    }
}
