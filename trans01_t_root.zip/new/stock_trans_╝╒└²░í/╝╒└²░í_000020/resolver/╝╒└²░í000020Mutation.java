package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import .model.filter.Filter;
import .service.손절가000020Service;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * 손절가_ 000020 GraphQL Mutation
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.04.13.						최초작성
 * </pre>
 */
@Component
public class 손절가000020Mutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(손절가000020Mutation.class);
	
	@Autowired
	private 손절가000020Service 손절가000020Service;
	
	/**
	 * 손절가_ 000020 등록
     * @Method add손절가000020
	 * @param Filter
	 */
    public Boolean add손절가000020(Filter params) {
    	try {
    		return 손절가000020Service.insert손절가000020(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * 손절가_ 000020 수정
     * @Method modify손절가000020
	 * @param Filter
	 */
	public Boolean modify손절가000020(Filter params) {
		try {
			return 손절가000020Service.update손절가000020(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * 손절가_ 000020 삭제
     * @Method remove손절가000020
	 * @param Filter
	 */
	public Boolean remove손절가000020(Filter params) {
		try {
			return 손절가000020Service.delete손절가000020(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
