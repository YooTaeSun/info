package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import .model.dto.DTO;
import .model.filter.Filter;
import .service.손절가000020Service;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * 손절가_ 000020 GraphQL Query
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.04.13.						최초작성
 * </pre>
 */
@Component
public class 손절가000020Query implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(손절가000020Mutation.class);
	
	@Autowired
	private 손절가000020Service 손절가000020Service;

    /**
     * 손절가_ 000020 단건 조회
     * @Method get손절가000020
     * @param  Filter
     * @return 조회 건
     */
    public DTO get손절가000020(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 손절가000020Service.select손절가000020(params);
    }
    
    /**
     * 손절가_ 000020 건수 조회
     * @Method get손절가000020Cnt
     * @param  Filter
     * @return 건수
     */
    public int get손절가000020Cnt(Filter params){
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 손절가000020Service.select손절가000020Cnt(params);
    }

    /**
     * 손절가_ 000020 다건 조회
     * @Method get손절가000020List
     * @param  Filter
     * @return 조회 목록
     */
    public List<DTO> get손절가000020List(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 손절가000020Service.select손절가000020List(params);
    }
}
