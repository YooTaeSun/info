/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class Graphql손절가000020Service {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async add손절가000020(params) {

    params = {
             순번: ''    // 순번
            ,종목코드: ''    // 종목코드
            ,종목명: ''    // 종목명
            ,watchId: ''    // watch_id
            ,userId: ''    // user_id
            ,일자: ''    // 일자
            ,손절가: ''    // 손절률
            ,익절가: ''    // 익절가
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation add손절가000020($input: Filter) {
      one : add손절가000020(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modify손절가000020(params) {

    let query = `mutation modify손절가000020($input: Filter) {
      one : modify손절가000020(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async remove손절가000020(params) {

    params = {
    }

    let query = `mutation remove손절가000020($input: Filter) {
      one : remove손절가000020(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async get손절가000020(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      one: get손절가000020(filter:$params) {
			순번
			종목코드
			종목명
			watchId
			userId
			일자
			손절가
			익절가
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async get손절가000020List(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      cnt: get손절가000020Cnt(filter:$params)   
      list: get손절가000020List(filter:$params) {
			순번
			종목코드
			종목명
			watchId
			userId
			일자
			손절가
			익절가
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new Graphql손절가000020Service();
