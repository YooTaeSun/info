package .service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import .model.dto.DTO;
import .model.filter.Filter;
import .service.Naver지수Service;
import .service.dao.DAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 * Naver지수 ServiceImpl
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.05.13.						최초작성
 * </pre>
 */
@Service("naver지수Service")
public class Naver지수ServiceImpl implements Naver지수Service {

	private static final Logger logger = LoggerFactory.getLogger(Naver지수ServiceImpl.class);
	
	@Autowired
    private DAO DAO;
    
	/**
	 * Naver지수 등록, 수정
     * @Method mergeNaver지수
	 * @param Filter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean mergeNaver지수(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.merge(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     * Naver지수 여러 건 등록
     * @Method bulkInsertNaver지수
     * @param Filter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsertNaver지수(Filter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = DAO.bulkInsert(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 * Naver지수 등록
     * @Method insertNaver지수
	 * @param Filter
     * @return 등록 여부
	 */
    @Override
    public Boolean insertNaver지수(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.insert(params);
        return (result > 0)? true:false;    	
    }

    /**
     * Naver지수 수정
     * @Method updateNaver지수 
     * @param Filter
     * @Method updateNaver지수
     * @return 수정 여부
     */
    @Override
    public Boolean updateNaver지수(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = DAO.update(params);
        return (result > 0)? true:false;        
    }

    /**
     * Naver지수 삭제
     * @Method deleteNaver지수
     * @param Filter
     * @return 삭제 여부 
     */
    @Override
    public Boolean deleteNaver지수(Filter params){
        int result = DAO.delete(params);
        return (result > 0)? true:false;
    }
    
    /**
     * Naver지수 단건 조회
     * @Method selectNaver지수
     * @param  Filter
     * @return 조회 건
     */
    @Override
    public DTO selectNaver지수(Filter params){
        return DAO.select(params);
    }
    
    /**
     * Naver지수 건수 조회
     * @Method selectNaver지수Cnt
     * @param  Filter
     * @return 건수
     */
    @Override
    public int selectNaver지수Cnt(Filter params){
        return DAO.selectCnt(params);
    }

    /**
     * Naver지수 다건 조회
     * @Method selectNaver지수List
     * @param  Filter
     * @return 조회 목록
     */
    @Override
    public List<DTO> selectNaver지수List(Filter params){
        return DAO.selectList(params);
    }
}
