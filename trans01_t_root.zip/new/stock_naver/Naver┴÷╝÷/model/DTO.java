package .model.dto;
import java.util.Date;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DTO {

	/**
	 * 일자(PK)
	 */
	@ApiModelProperty(value = "일자: 일자")
	private String 일자;

	/**
	 * 순번(PK)
	 */
	@ApiModelProperty(value = "순번: 순번")
	private Integer 순번;

	/**
	 * 국가명(PK)
	 */
	@ApiModelProperty(value = "국가명: 국가명")
	private String 국가명;

	/**
	 * 지수코드(PK)
	 */
	@ApiModelProperty(value = "지수코드: 지수코드")
	private String 지수코드;

	/**
	 * 지수명
	 */
	@ApiModelProperty(value = "지수명: 지수명")
	private String 지수명;

	/**
	 * 현재가
	 */
	@ApiModelProperty(value = "현재가: 현재가")
	private Integer 현재가;

	/**
	 * 전일대비
	 */
	@ApiModelProperty(value = "전일대비: 전일대비")
	private Integer 전일대비;

	/**
	 * 등락률(%)
	 */
	@ApiModelProperty(value = "등락률: 등락률(%)")
	private Integer 등락률;

	/**
	 * 상승,하락,보합
	 */
	@ApiModelProperty(value = "방향: 상승,하락,보합")
	private String 방향;

	/**
	 * 입력날짜
	 */
	@ApiModelProperty(value = "insertDate: 입력날짜")
	private Date insertDate;

	/**
	 * 수정날짜
	 */
	@ApiModelProperty(value = "updateDate: 수정날짜")
	private Date updateDate;


}
