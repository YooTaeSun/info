package .service;

import java.util.List;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 * Naver지수 서비스
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.05.13.						최초작성
 * </pre>
 */
public interface Naver지수Service {

	/**
	 * Naver지수 등록, 수정
     * @Method mergeNaver지수
	 * @param Filter
	 */
    public Boolean mergeNaver지수(Filter params);	
    
	/**
	 * Naver지수 여러 건 등록
     * @Method bulkInsertNaver지수
	 * @param Filter
	 */
    public Boolean bulkInsertNaver지수(Filter params);	    
	
	/**
	 * Naver지수 등록
     * @Method insertNaver지수
	 * @param Filter
	 */
    public Boolean insertNaver지수(Filter params);

    /**
     * Naver지수 수정
     * @Method updateNaver지수
     * @param Filter
     */
    public Boolean updateNaver지수(Filter params);

    /**
     * Naver지수 삭제
     * @Method deleteNaver지수
     * @param Filter
     */
    public Boolean deleteNaver지수(Filter params);
    
    /**
     * Naver지수 단건 조회
     * @Method selectNaver지수 
     * @param  Filter
     */
    public DTO selectNaver지수(Filter params);    
    
    /**
     * Naver지수 건수 조회
     * @Method selectNaver지수Cnt
     * @param  Filter
     */
    public int selectNaver지수Cnt(Filter params);
    
    /**
     * Naver지수 다건 조회
     * @Method selectNaver지수List
     * @param  Filter
     */
    public List<DTO> selectNaver지수List(Filter params);

}
