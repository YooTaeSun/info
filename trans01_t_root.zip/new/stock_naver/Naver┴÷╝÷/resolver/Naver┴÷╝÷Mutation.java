package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import .model.filter.Filter;
import .service.Naver지수Service;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * Naver지수 GraphQL Mutation
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.05.13.						최초작성
 * </pre>
 */
@Component
public class Naver지수Mutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(Naver지수Mutation.class);
	
	@Autowired
	private Naver지수Service naver지수Service;
	
	/**
	 * Naver지수 등록
     * @Method addNaver지수
	 * @param Filter
	 */
    public Boolean addNaver지수(Filter params) {
    	try {
    		return naver지수Service.insertNaver지수(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * Naver지수 수정
     * @Method modifyNaver지수
	 * @param Filter
	 */
	public Boolean modifyNaver지수(Filter params) {
		try {
			return naver지수Service.updateNaver지수(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * Naver지수 삭제
     * @Method removeNaver지수
	 * @param Filter
	 */
	public Boolean removeNaver지수(Filter params) {
		try {
			return naver지수Service.deleteNaver지수(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
