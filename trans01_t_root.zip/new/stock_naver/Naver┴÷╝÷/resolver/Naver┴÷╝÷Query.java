package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import .model.dto.DTO;
import .model.filter.Filter;
import .service.Naver지수Service;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * Naver지수 GraphQL Query
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.05.13.						최초작성
 * </pre>
 */
@Component
public class Naver지수Query implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(Naver지수Mutation.class);
	
	@Autowired
	private Naver지수Service naver지수Service;

    /**
     * Naver지수 단건 조회
     * @Method getNaver지수
     * @param  Filter
     * @return 조회 건
     */
    public DTO getNaver지수(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return naver지수Service.selectNaver지수(params);
    }
    
    /**
     * Naver지수 건수 조회
     * @Method getNaver지수Cnt
     * @param  Filter
     * @return 건수
     */
    public int getNaver지수Cnt(Filter params){
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return naver지수Service.selectNaver지수Cnt(params);
    }

    /**
     * Naver지수 다건 조회
     * @Method getNaver지수List
     * @param  Filter
     * @return 조회 목록
     */
    public List<DTO> getNaver지수List(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return naver지수Service.selectNaver지수List(params);
    }
}
