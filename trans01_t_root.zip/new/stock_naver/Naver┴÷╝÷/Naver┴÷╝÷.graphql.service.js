/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class GraphqlNaver지수Service {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async addNaver지수(params) {

    params = {
             일자: ''    // 일자
            ,순번: ''    // 순번
            ,국가명: ''    // 국가명
            ,지수코드: ''    // 지수코드
            ,지수명: ''    // 지수명
            ,현재가: ''    // 현재가
            ,전일대비: ''    // 전일대비
            ,등락률: ''    // 등락률(%)
            ,방향: ''    // 상승,하락,보합
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation addNaver지수($input: Filter) {
      one : addNaver지수(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modifyNaver지수(params) {

    let query = `mutation modifyNaver지수($input: Filter) {
      one : modifyNaver지수(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async removeNaver지수(params) {

    params = {
    }

    let query = `mutation removeNaver지수($input: Filter) {
      one : removeNaver지수(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async getNaver지수(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      one: getNaver지수(filter:$params) {
			일자
			순번
			국가명
			지수코드
			지수명
			현재가
			전일대비
			등락률
			방향
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async getNaver지수List(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      cnt: getNaver지수Cnt(filter:$params)   
      list: getNaver지수List(filter:$params) {
			일자
			순번
			국가명
			지수코드
			지수명
			현재가
			전일대비
			등락률
			방향
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new GraphqlNaver지수Service();
