/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class GraphqlNaver검색상위Service {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async addNaver검색상위(params) {

    params = {
             일자: ''    // 일자
            ,순번: ''    // 순번
            ,순위: ''    // 순위
            ,종목코드: ''    // 종목코드
            ,종목명: ''    // 종목명
            ,검색비율: ''    // 검색비율
            ,현재가: ''    // 현재가
            ,전일비상태: ''    // 전일비상태
            ,전일비: ''    // 전일비
            ,등락률: ''    // 등락률
            ,거래량: ''    // 거래량전체
            ,시가: ''    // 시가
            ,고가: ''    // 고가
            ,저가: ''    // 저가
            ,per: ''    // PER(배)
            ,roe: ''    // ROE(%)
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation addNaver검색상위($input: Filter) {
      one : addNaver검색상위(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modifyNaver검색상위(params) {

    let query = `mutation modifyNaver검색상위($input: Filter) {
      one : modifyNaver검색상위(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async removeNaver검색상위(params) {

    params = {
    }

    let query = `mutation removeNaver검색상위($input: Filter) {
      one : removeNaver검색상위(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async getNaver검색상위(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      one: getNaver검색상위(filter:$params) {
			일자
			순번
			순위
			종목코드
			종목명
			검색비율
			현재가
			전일비상태
			전일비
			등락률
			거래량
			시가
			고가
			저가
			per
			roe
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async getNaver검색상위List(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      cnt: getNaver검색상위Cnt(filter:$params)   
      list: getNaver검색상위List(filter:$params) {
			일자
			순번
			순위
			종목코드
			종목명
			검색비율
			현재가
			전일비상태
			전일비
			등락률
			거래량
			시가
			고가
			저가
			per
			roe
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new GraphqlNaver검색상위Service();
