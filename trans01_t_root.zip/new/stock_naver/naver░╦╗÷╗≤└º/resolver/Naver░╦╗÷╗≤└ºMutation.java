package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import .model.filter.Filter;
import .service.Naver검색상위Service;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * naver검색상위 GraphQL Mutation
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.04.14.						최초작성
 * </pre>
 */
@Component
public class Naver검색상위Mutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(Naver검색상위Mutation.class);
	
	@Autowired
	private Naver검색상위Service naver검색상위Service;
	
	/**
	 * naver검색상위 등록
     * @Method addNaver검색상위
	 * @param Filter
	 */
    public Boolean addNaver검색상위(Filter params) {
    	try {
    		return naver검색상위Service.insertNaver검색상위(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * naver검색상위 수정
     * @Method modifyNaver검색상위
	 * @param Filter
	 */
	public Boolean modifyNaver검색상위(Filter params) {
		try {
			return naver검색상위Service.updateNaver검색상위(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * naver검색상위 삭제
     * @Method removeNaver검색상위
	 * @param Filter
	 */
	public Boolean removeNaver검색상위(Filter params) {
		try {
			return naver검색상위Service.deleteNaver검색상위(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
