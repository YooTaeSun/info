package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import .model.dto.DTO;
import .model.filter.Filter;
import .service.Naver검색상위Service;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * naver검색상위 GraphQL Query
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.04.14.						최초작성
 * </pre>
 */
@Component
public class Naver검색상위Query implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(Naver검색상위Mutation.class);
	
	@Autowired
	private Naver검색상위Service naver검색상위Service;

    /**
     * naver검색상위 단건 조회
     * @Method getNaver검색상위
     * @param  Filter
     * @return 조회 건
     */
    public DTO getNaver검색상위(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return naver검색상위Service.selectNaver검색상위(params);
    }
    
    /**
     * naver검색상위 건수 조회
     * @Method getNaver검색상위Cnt
     * @param  Filter
     * @return 건수
     */
    public int getNaver검색상위Cnt(Filter params){
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return naver검색상위Service.selectNaver검색상위Cnt(params);
    }

    /**
     * naver검색상위 다건 조회
     * @Method getNaver검색상위List
     * @param  Filter
     * @return 조회 목록
     */
    public List<DTO> getNaver검색상위List(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return naver검색상위Service.selectNaver검색상위List(params);
    }
}
