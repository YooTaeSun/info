package .service;

import java.util.List;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 * naver검색상위 서비스
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.04.14.						최초작성
 * </pre>
 */
public interface Naver검색상위Service {

	/**
	 * naver검색상위 등록, 수정
     * @Method mergeNaver검색상위
	 * @param Filter
	 */
    public Boolean mergeNaver검색상위(Filter params);	
    
	/**
	 * naver검색상위 여러 건 등록
     * @Method bulkInsertNaver검색상위
	 * @param Filter
	 */
    public Boolean bulkInsertNaver검색상위(Filter params);	    
	
	/**
	 * naver검색상위 등록
     * @Method insertNaver검색상위
	 * @param Filter
	 */
    public Boolean insertNaver검색상위(Filter params);

    /**
     * naver검색상위 수정
     * @Method updateNaver검색상위
     * @param Filter
     */
    public Boolean updateNaver검색상위(Filter params);

    /**
     * naver검색상위 삭제
     * @Method deleteNaver검색상위
     * @param Filter
     */
    public Boolean deleteNaver검색상위(Filter params);
    
    /**
     * naver검색상위 단건 조회
     * @Method selectNaver검색상위 
     * @param  Filter
     */
    public DTO selectNaver검색상위(Filter params);    
    
    /**
     * naver검색상위 건수 조회
     * @Method selectNaver검색상위Cnt
     * @param  Filter
     */
    public int selectNaver검색상위Cnt(Filter params);
    
    /**
     * naver검색상위 다건 조회
     * @Method selectNaver검색상위List
     * @param  Filter
     */
    public List<DTO> selectNaver검색상위List(Filter params);

}
