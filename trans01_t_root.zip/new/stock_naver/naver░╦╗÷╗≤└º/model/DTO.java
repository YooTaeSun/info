package .model.dto;
import java.util.Date;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DTO {

	/**
	 * 일자(PK)
	 */
	@ApiModelProperty(value = "일자: 일자")
	private String 일자;

	/**
	 * 순번
	 */
	@ApiModelProperty(value = "순번: 순번")
	private Integer 순번;

	/**
	 * 순위
	 */
	@ApiModelProperty(value = "순위: 순위")
	private Integer 순위;

	/**
	 * 종목코드(PK)
	 */
	@ApiModelProperty(value = "종목코드: 종목코드")
	private String 종목코드;

	/**
	 * 종목명(PK)
	 */
	@ApiModelProperty(value = "종목명: 종목명")
	private String 종목명;

	/**
	 * 검색비율
	 */
	@ApiModelProperty(value = "검색비율: 검색비율")
	private Float 검색비율;

	/**
	 * 현재가
	 */
	@ApiModelProperty(value = "현재가: 현재가")
	private Integer 현재가;

	/**
	 * 전일비상태
	 */
	@ApiModelProperty(value = "전일비상태: 전일비상태")
	private String 전일비상태;

	/**
	 * 전일비
	 */
	@ApiModelProperty(value = "전일비: 전일비")
	private Integer 전일비;

	/**
	 * 등락률
	 */
	@ApiModelProperty(value = "등락률: 등락률")
	private Float 등락률;

	/**
	 * 거래량전체
	 */
	@ApiModelProperty(value = "거래량: 거래량전체")
	private Integer 거래량;

	/**
	 * 시가
	 */
	@ApiModelProperty(value = "시가: 시가")
	private Integer 시가;

	/**
	 * 고가
	 */
	@ApiModelProperty(value = "고가: 고가")
	private Integer 고가;

	/**
	 * 저가
	 */
	@ApiModelProperty(value = "저가: 저가")
	private Integer 저가;

	/**
	 * PER(배)
	 */
	@ApiModelProperty(value = "per: PER(배)")
	private Float per;

	/**
	 * ROE(%)
	 */
	@ApiModelProperty(value = "roe: ROE(%)")
	private Float roe;

	/**
	 * 입력날짜
	 */
	@ApiModelProperty(value = "insertDate: 입력날짜")
	private Date insertDate;

	/**
	 * 수정날짜
	 */
	@ApiModelProperty(value = "updateDate: 수정날짜")
	private Date updateDate;


}
