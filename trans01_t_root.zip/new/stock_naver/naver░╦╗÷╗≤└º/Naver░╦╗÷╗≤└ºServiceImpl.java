package .service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import .model.dto.DTO;
import .model.filter.Filter;
import .service.Naver검색상위Service;
import .service.dao.DAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 * naver검색상위 ServiceImpl
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.04.14.						최초작성
 * </pre>
 */
@Service("naver검색상위Service")
public class Naver검색상위ServiceImpl implements Naver검색상위Service {

	private static final Logger logger = LoggerFactory.getLogger(Naver검색상위ServiceImpl.class);
	
	@Autowired
    private DAO DAO;
    
	/**
	 * naver검색상위 등록, 수정
     * @Method mergeNaver검색상위
	 * @param Filter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean mergeNaver검색상위(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.merge(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     * naver검색상위 여러 건 등록
     * @Method bulkInsertNaver검색상위
     * @param Filter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsertNaver검색상위(Filter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = DAO.bulkInsert(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 * naver검색상위 등록
     * @Method insertNaver검색상위
	 * @param Filter
     * @return 등록 여부
	 */
    @Override
    public Boolean insertNaver검색상위(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.insert(params);
        return (result > 0)? true:false;    	
    }

    /**
     * naver검색상위 수정
     * @Method updateNaver검색상위 
     * @param Filter
     * @Method updateNaver검색상위
     * @return 수정 여부
     */
    @Override
    public Boolean updateNaver검색상위(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = DAO.update(params);
        return (result > 0)? true:false;        
    }

    /**
     * naver검색상위 삭제
     * @Method deleteNaver검색상위
     * @param Filter
     * @return 삭제 여부 
     */
    @Override
    public Boolean deleteNaver검색상위(Filter params){
        int result = DAO.delete(params);
        return (result > 0)? true:false;
    }
    
    /**
     * naver검색상위 단건 조회
     * @Method selectNaver검색상위
     * @param  Filter
     * @return 조회 건
     */
    @Override
    public DTO selectNaver검색상위(Filter params){
        return DAO.select(params);
    }
    
    /**
     * naver검색상위 건수 조회
     * @Method selectNaver검색상위Cnt
     * @param  Filter
     * @return 건수
     */
    @Override
    public int selectNaver검색상위Cnt(Filter params){
        return DAO.selectCnt(params);
    }

    /**
     * naver검색상위 다건 조회
     * @Method selectNaver검색상위List
     * @param  Filter
     * @return 조회 목록
     */
    @Override
    public List<DTO> selectNaver검색상위List(Filter params){
        return DAO.selectList(params);
    }
}
