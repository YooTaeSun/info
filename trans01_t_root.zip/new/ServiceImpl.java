package .service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import .model.dto.DTO;
import .model.filter.Filter;
import .service.Service;
import .service.dao.DAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 *  ServiceImpl
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.						최초작성
 * </pre>
 */
@Service("Service")
public class ServiceImpl implements Service {

	private static final Logger logger = LoggerFactory.getLogger(ServiceImpl.class);
	
	@Autowired
    private DAO DAO;
    
	/**
	 *  등록, 수정
     * @Method merge
	 * @param Filter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean merge(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.merge(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     *  여러 건 등록
     * @Method bulkInsert
     * @param Filter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsert(Filter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = DAO.bulkInsert(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 *  등록
     * @Method insert
	 * @param Filter
     * @return 등록 여부
	 */
    @Override
    public Boolean insert(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.insert(params);
        return (result > 0)? true:false;    	
    }

    /**
     *  수정
     * @Method update 
     * @param Filter
     * @Method update
     * @return 수정 여부
     */
    @Override
    public Boolean update(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = DAO.update(params);
        return (result > 0)? true:false;        
    }

    /**
     *  삭제
     * @Method delete
     * @param Filter
     * @return 삭제 여부 
     */
    @Override
    public Boolean delete(Filter params){
        int result = DAO.delete(params);
        return (result > 0)? true:false;
    }
    
    /**
     *  단건 조회
     * @Method select
     * @param  Filter
     * @return 조회 건
     */
    @Override
    public DTO select(Filter params){
        return DAO.select(params);
    }
    
    /**
     *  건수 조회
     * @Method selectCnt
     * @param  Filter
     * @return 건수
     */
    @Override
    public int selectCnt(Filter params){
        return DAO.selectCnt(params);
    }

    /**
     *  다건 조회
     * @Method selectList
     * @param  Filter
     * @return 조회 목록
     */
    @Override
    public List<DTO> selectList(Filter params){
        return DAO.selectList(params);
    }
}
