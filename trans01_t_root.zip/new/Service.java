package .service;

import java.util.List;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 *  서비스
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.						최초작성
 * </pre>
 */
public interface Service {

	/**
	 *  등록, 수정
     * @Method merge
	 * @param Filter
	 */
    public Boolean merge(Filter params);	
    
	/**
	 *  여러 건 등록
     * @Method bulkInsert
	 * @param Filter
	 */
    public Boolean bulkInsert(Filter params);	    
	
	/**
	 *  등록
     * @Method insert
	 * @param Filter
	 */
    public Boolean insert(Filter params);

    /**
     *  수정
     * @Method update
     * @param Filter
     */
    public Boolean update(Filter params);

    /**
     *  삭제
     * @Method delete
     * @param Filter
     */
    public Boolean delete(Filter params);
    
    /**
     *  단건 조회
     * @Method select 
     * @param  Filter
     */
    public DTO select(Filter params);    
    
    /**
     *  건수 조회
     * @Method selectCnt
     * @param  Filter
     */
    public int selectCnt(Filter params);
    
    /**
     *  다건 조회
     * @Method selectList
     * @param  Filter
     */
    public List<DTO> selectList(Filter params);

}
