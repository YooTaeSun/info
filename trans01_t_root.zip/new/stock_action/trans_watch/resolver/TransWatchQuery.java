package com.osstem.ows.biz.sal.sales.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.sal.sales.model.dto.TransWatchDTO;
import com.osstem.ows.biz.sal.sales.model.filter.TransWatchFilter;
import com.osstem.ows.biz.sal.sales.service.TransWatchService;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 *  GraphQL Query
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.		system				최초작성
 * </pre>
 */
@Component
public class TransWatchQuery implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(TransWatchMutation.class);
	
	@Autowired
	private TransWatchService transWatchService;

    /**
     *  단건 조회
     * @Method getTransWatch
     * @param  transWatchFilter
     * @return 조회 건
     */
    public TransWatchDTO getTransWatch(TransWatchFilter params) {
    	params = Optional.ofNullable(params).orElseGet(TransWatchFilter::new);
    	return transWatchService.selectTransWatch(params);
    }
    
    /**
     *  건수 조회
     * @Method getTransWatchCnt
     * @param  transWatchFilter
     * @return 건수
     */
    public int getTransWatchCnt(TransWatchFilter params){
    	params = Optional.ofNullable(params).orElseGet(TransWatchFilter::new);
    	return transWatchService.selectTransWatchCnt(params);
    }

    /**
     *  다건 조회
     * @Method getTransWatchList
     * @param  transWatchFilter
     * @return 조회 목록
     */
    public List<TransWatchDTO> getTransWatchList(TransWatchFilter params) {
    	params = Optional.ofNullable(params).orElseGet(TransWatchFilter::new);
    	return transWatchService.selectTransWatchList(params);
    }
}
