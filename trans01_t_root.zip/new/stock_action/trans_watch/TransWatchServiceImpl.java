package com.osstem.ows.biz.sal.sales.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import com.osstem.ows.biz.sal.sales.model.dto.TransWatchDTO;
import com.osstem.ows.biz.sal.sales.model.filter.TransWatchFilter;
import com.osstem.ows.biz.sal.sales.service.TransWatchService;
import com.osstem.ows.biz.sal.sales.service.dao.TransWatchDAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 *  ServiceImpl
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.		system				최초작성
 * </pre>
 */
@Service("transWatchService")
public class TransWatchServiceImpl implements TransWatchService {

	private static final Logger logger = LoggerFactory.getLogger(TransWatchServiceImpl.class);
	
	@Autowired
    private TransWatchDAO transWatchDAO;
    
	/**
	 *  등록, 수정
     * @Method mergeTransWatch
	 * @param TransWatchFilter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean mergeTransWatch(TransWatchFilter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = transWatchDAO.mergeTransWatch(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     *  여러 건 등록
     * @Method bulkInsertTransWatch
     * @param TransWatchFilter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsertTransWatch(TransWatchFilter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = transWatchDAO.bulkInsertTransWatch(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 *  등록
     * @Method insertTransWatch
	 * @param TransWatchFilter
     * @return 등록 여부
	 */
    @Override
    public Boolean insertTransWatch(TransWatchFilter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = transWatchDAO.insertTransWatch(params);
        return (result > 0)? true:false;    	
    }

    /**
     *  수정
     * @Method updateTransWatch 
     * @param transWatchFilter
     * @Method updateTransWatch
     * @return 수정 여부
     */
    @Override
    public Boolean updateTransWatch(TransWatchFilter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = transWatchDAO.updateTransWatch(params);
        return (result > 0)? true:false;        
    }

    /**
     *  삭제
     * @Method deleteTransWatch
     * @param transWatchFilter
     * @return 삭제 여부 
     */
    @Override
    public Boolean deleteTransWatch(TransWatchFilter params){
        int result = transWatchDAO.deleteTransWatch(params);
        return (result > 0)? true:false;
    }
    
    /**
     *  단건 조회
     * @Method selectTransWatch
     * @param  transWatchFilter
     * @return 조회 건
     */
    @Override
    public TransWatchDTO selectTransWatch(TransWatchFilter params){
        return transWatchDAO.selectTransWatch(params);
    }
    
    /**
     *  건수 조회
     * @Method selectTransWatchCnt
     * @param  transWatchFilter
     * @return 건수
     */
    @Override
    public int selectTransWatchCnt(TransWatchFilter params){
        return transWatchDAO.selectTransWatchCnt(params);
    }

    /**
     *  다건 조회
     * @Method selectTransWatchList
     * @param  transWatchFilter
     * @return 조회 목록
     */
    @Override
    public List<TransWatchDTO> selectTransWatchList(TransWatchFilter params){
        return transWatchDAO.selectTransWatchList(params);
    }
}
