/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class GraphqlTransWatchService {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async addTransWatch(params) {

    params = {

    }

    let query = `mutation addTransWatch($input: TransWatchFilter) {
      one : addTransWatch(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modifyTransWatch(params) {

    let query = `mutation modifyTransWatch($input: TransWatchFilter) {
      one : modifyTransWatch(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async removeTransWatch(params) {

    params = {
    }

    let query = `mutation removeTransWatch($input: TransWatchFilter) {
      one : removeTransWatch(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async getTransWatch(params) {

    params = {

    }

    let query = `
    query ($params:TransWatchFilter) {
      one: getTransWatch(filter:$params) {

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async getTransWatchList(params) {

    params = {

    }

    let query = `
    query ($params:TransWatchFilter) {
      cnt: getTransWatchCnt(filter:$params)   
      list: getTransWatchList(filter:$params) {

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new GraphqlTransWatchService();
