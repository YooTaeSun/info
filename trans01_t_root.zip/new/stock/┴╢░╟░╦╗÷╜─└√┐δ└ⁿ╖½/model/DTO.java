package com.osstem.ows.biz.sal.sales.model.dto;
import java.util.Date;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DTO {

	/**
	 * 순번(PK)
	 */
	@ApiModelProperty(value = "순번: 순번")
	private Long 순번;

	/**
	 * 전략(PK)
	 */
	@ApiModelProperty(value = "전략: 전략")
	private String 전략;

	/**
	 * 삭제여부
	 */
	@ApiModelProperty(value = "delYn: 삭제여부")
	private String delYn;

	/**
	 * 입력날짜
	 */
	@ApiModelProperty(value = "insertDate: 입력날짜")
	private Date insertDate;

	/**
	 * 수정날짜
	 */
	@ApiModelProperty(value = "updateDate: 수정날짜")
	private Date updateDate;


}
