package com.osstem.ows.biz.sal.sales.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.sal.sales.model.dto.DTO;
import com.osstem.ows.biz.sal.sales.model.filter.Filter;
import com.osstem.ows.biz.sal.sales.service.조건검색식적용전략Service;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * 조건검색식적용전략 저장 테이블 GraphQL Query
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.02.17.		system				최초작성
 * </pre>
 */
@Component
public class 조건검색식적용전략Query implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(조건검색식적용전략Mutation.class);
	
	@Autowired
	private 조건검색식적용전략Service 조건검색식적용전략Service;

    /**
     * 조건검색식적용전략 저장 테이블 단건 조회
     * @Method get조건검색식적용전략
     * @param  Filter
     * @return 조회 건
     */
    public DTO get조건검색식적용전략(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 조건검색식적용전략Service.select조건검색식적용전략(params);
    }
    
    /**
     * 조건검색식적용전략 저장 테이블 건수 조회
     * @Method get조건검색식적용전략Cnt
     * @param  Filter
     * @return 건수
     */
    public int get조건검색식적용전략Cnt(Filter params){
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 조건검색식적용전략Service.select조건검색식적용전략Cnt(params);
    }

    /**
     * 조건검색식적용전략 저장 테이블 다건 조회
     * @Method get조건검색식적용전략List
     * @param  Filter
     * @return 조회 목록
     */
    public List<DTO> get조건검색식적용전략List(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 조건검색식적용전략Service.select조건검색식적용전략List(params);
    }
}
