package com.osstem.ows.biz.sal.sales.service.dao;

import java.util.List;

import com.osstem.ows.biz.cfg.datasource.OwsMapper;
import com.osstem.ows.biz.sal.sales.model.dto.DTO;
import com.osstem.ows.biz.sal.sales.model.filter.Filter;

/**
 * 조건검색식적용전략 저장 테이블 DAO
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.02.17.		system				최초작성
 * </pre>
 */
@OwsMapper
public interface DAO {

	/**
     * 조건검색식적용전략 저장 테이블 등록, 수정
     * @Method merge조건검색식적용전략
     * @param Filter
     * @return 등록 또는 수정된 건수
     */	
	public int merge(Filter params);
	
	/**
	 * 조건검색식적용전략 저장 테이블 여러 건 등록
	 * @Method bulkInsert조건검색식적용전략
	 * @param Filter
	 * @return 여러 건 등록된 건수
	 */	
	public int bulkInsert(Filter params);
	
	/**
	 * 조건검색식적용전략 저장 테이블 등록
	 * @Method insert조건검색식적용전략
	 * @param Filter
	 * @return 등록된 건수
	 */	
	public int insert(Filter params);
	
    /**
     * 조건검색식적용전략 저장 테이블 수정
     * @Method update조건검색식적용전략
     * @param Filter
     * @return 수정된 건수
     */	
	public int update(Filter params);
	
    /**
     * 조건검색식적용전략 저장 테이블 삭제 
     * @Method delete조건검색식적용전략
     * @param Filter
     * @return 삭제된 건수
     */	
	public int delete(Filter params);
 
    /**
     * 조건검색식적용전략 저장 테이블 단건 조회
     *
     * @param Filter
     * @return 조회 건
     */	    
	public DTO select(Filter params);

    /**
     * 조건검색식적용전략 저장 테이블 건수 조회
     * @Method select조건검색식적용전략Cnt
     * @param Filter
     * @return 건수
     */	
    int selectCnt(Filter params);
    
    /**
     * 조건검색식적용전략 저장 테이블 다건 조회
     * @Method select조건검색식적용전략List
     * @param Filter 
     * @return 조회 목록
     */	
	public List<DTO> selectList(Filter params);
}
