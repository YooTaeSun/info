/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class Graphql조건검색식적용전략Service {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async add조건검색식적용전략(params) {

    params = {
             순번: ''    // 순번
            ,전략: ''    // 전략
            ,delYn: ''    // 삭제여부
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation add조건검색식적용전략($input: Filter) {
      one : add조건검색식적용전략(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modify조건검색식적용전략(params) {

    let query = `mutation modify조건검색식적용전략($input: Filter) {
      one : modify조건검색식적용전략(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async remove조건검색식적용전략(params) {

    params = {
    }

    let query = `mutation remove조건검색식적용전략($input: Filter) {
      one : remove조건검색식적용전략(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async get조건검색식적용전략(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      one: get조건검색식적용전략(filter:$params) {
			순번
			전략
			delYn
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async get조건검색식적용전략List(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      cnt: get조건검색식적용전략Cnt(filter:$params)   
      list: get조건검색식적용전략List(filter:$params) {
			순번
			전략
			delYn
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new Graphql조건검색식적용전략Service();
