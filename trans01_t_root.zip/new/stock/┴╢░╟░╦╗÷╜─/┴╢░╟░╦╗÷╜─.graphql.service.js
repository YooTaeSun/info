/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class Graphql조건검색식Service {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async add조건검색식(params) {

    params = {
             일자: ''    // 일자
            ,id: ''    // id
            ,name: ''    // 조건이름
            ,타입: ''    // 조건타입
            ,종목코드: ''    // 종목코드
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation add조건검색식($input: Filter) {
      one : add조건검색식(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modify조건검색식(params) {

    let query = `mutation modify조건검색식($input: Filter) {
      one : modify조건검색식(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async remove조건검색식(params) {

    params = {
    }

    let query = `mutation remove조건검색식($input: Filter) {
      one : remove조건검색식(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async get조건검색식(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      one: get조건검색식(filter:$params) {
			일자
			id
			name
			타입
			종목코드
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async get조건검색식List(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      cnt: get조건검색식Cnt(filter:$params)   
      list: get조건검색식List(filter:$params) {
			일자
			id
			name
			타입
			종목코드
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new Graphql조건검색식Service();
