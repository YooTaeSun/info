package .service;

import java.util.List;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 * 조건검색식 저장 테이블 서비스
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.07.17.						최초작성
 * </pre>
 */
public interface 조건검색식Service {

	/**
	 * 조건검색식 저장 테이블 등록, 수정
     * @Method merge조건검색식
	 * @param Filter
	 */
    public Boolean merge조건검색식(Filter params);	
    
	/**
	 * 조건검색식 저장 테이블 여러 건 등록
     * @Method bulkInsert조건검색식
	 * @param Filter
	 */
    public Boolean bulkInsert조건검색식(Filter params);	    
	
	/**
	 * 조건검색식 저장 테이블 등록
     * @Method insert조건검색식
	 * @param Filter
	 */
    public Boolean insert조건검색식(Filter params);

    /**
     * 조건검색식 저장 테이블 수정
     * @Method update조건검색식
     * @param Filter
     */
    public Boolean update조건검색식(Filter params);

    /**
     * 조건검색식 저장 테이블 삭제
     * @Method delete조건검색식
     * @param Filter
     */
    public Boolean delete조건검색식(Filter params);
    
    /**
     * 조건검색식 저장 테이블 단건 조회
     * @Method select조건검색식 
     * @param  Filter
     */
    public DTO select조건검색식(Filter params);    
    
    /**
     * 조건검색식 저장 테이블 건수 조회
     * @Method select조건검색식Cnt
     * @param  Filter
     */
    public int select조건검색식Cnt(Filter params);
    
    /**
     * 조건검색식 저장 테이블 다건 조회
     * @Method select조건검색식List
     * @param  Filter
     */
    public List<DTO> select조건검색식List(Filter params);

}
