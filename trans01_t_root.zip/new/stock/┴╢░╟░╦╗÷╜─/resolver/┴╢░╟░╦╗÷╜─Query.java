package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import .model.dto.DTO;
import .model.filter.Filter;
import .service.조건검색식Service;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * 조건검색식 저장 테이블 GraphQL Query
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.07.17.						최초작성
 * </pre>
 */
@Component
public class 조건검색식Query implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(조건검색식Mutation.class);
	
	@Autowired
	private 조건검색식Service 조건검색식Service;

    /**
     * 조건검색식 저장 테이블 단건 조회
     * @Method get조건검색식
     * @param  Filter
     * @return 조회 건
     */
    public DTO get조건검색식(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 조건검색식Service.select조건검색식(params);
    }
    
    /**
     * 조건검색식 저장 테이블 건수 조회
     * @Method get조건검색식Cnt
     * @param  Filter
     * @return 건수
     */
    public int get조건검색식Cnt(Filter params){
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 조건검색식Service.select조건검색식Cnt(params);
    }

    /**
     * 조건검색식 저장 테이블 다건 조회
     * @Method get조건검색식List
     * @param  Filter
     * @return 조회 목록
     */
    public List<DTO> get조건검색식List(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 조건검색식Service.select조건검색식List(params);
    }
}
