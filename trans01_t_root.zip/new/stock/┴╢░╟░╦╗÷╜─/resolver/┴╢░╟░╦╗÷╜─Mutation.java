package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import .model.filter.Filter;
import .service.조건검색식Service;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * 조건검색식 저장 테이블 GraphQL Mutation
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.07.17.						최초작성
 * </pre>
 */
@Component
public class 조건검색식Mutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(조건검색식Mutation.class);
	
	@Autowired
	private 조건검색식Service 조건검색식Service;
	
	/**
	 * 조건검색식 저장 테이블 등록
     * @Method add조건검색식
	 * @param Filter
	 */
    public Boolean add조건검색식(Filter params) {
    	try {
    		return 조건검색식Service.insert조건검색식(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * 조건검색식 저장 테이블 수정
     * @Method modify조건검색식
	 * @param Filter
	 */
	public Boolean modify조건검색식(Filter params) {
		try {
			return 조건검색식Service.update조건검색식(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * 조건검색식 저장 테이블 삭제
     * @Method remove조건검색식
	 * @param Filter
	 */
	public Boolean remove조건검색식(Filter params) {
		try {
			return 조건검색식Service.delete조건검색식(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
