package .service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import .model.dto.DTO;
import .model.filter.Filter;
import .service.조건검색식Service;
import .service.dao.DAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 * 조건검색식 저장 테이블 ServiceImpl
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.07.17.						최초작성
 * </pre>
 */
@Service("조건검색식Service")
public class 조건검색식ServiceImpl implements 조건검색식Service {

	private static final Logger logger = LoggerFactory.getLogger(조건검색식ServiceImpl.class);
	
	@Autowired
    private DAO DAO;
    
	/**
	 * 조건검색식 저장 테이블 등록, 수정
     * @Method merge조건검색식
	 * @param Filter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean merge조건검색식(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.merge(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     * 조건검색식 저장 테이블 여러 건 등록
     * @Method bulkInsert조건검색식
     * @param Filter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsert조건검색식(Filter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = DAO.bulkInsert(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 * 조건검색식 저장 테이블 등록
     * @Method insert조건검색식
	 * @param Filter
     * @return 등록 여부
	 */
    @Override
    public Boolean insert조건검색식(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.insert(params);
        return (result > 0)? true:false;    	
    }

    /**
     * 조건검색식 저장 테이블 수정
     * @Method update조건검색식 
     * @param Filter
     * @Method update조건검색식
     * @return 수정 여부
     */
    @Override
    public Boolean update조건검색식(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = DAO.update(params);
        return (result > 0)? true:false;        
    }

    /**
     * 조건검색식 저장 테이블 삭제
     * @Method delete조건검색식
     * @param Filter
     * @return 삭제 여부 
     */
    @Override
    public Boolean delete조건검색식(Filter params){
        int result = DAO.delete(params);
        return (result > 0)? true:false;
    }
    
    /**
     * 조건검색식 저장 테이블 단건 조회
     * @Method select조건검색식
     * @param  Filter
     * @return 조회 건
     */
    @Override
    public DTO select조건검색식(Filter params){
        return DAO.select(params);
    }
    
    /**
     * 조건검색식 저장 테이블 건수 조회
     * @Method select조건검색식Cnt
     * @param  Filter
     * @return 건수
     */
    @Override
    public int select조건검색식Cnt(Filter params){
        return DAO.selectCnt(params);
    }

    /**
     * 조건검색식 저장 테이블 다건 조회
     * @Method select조건검색식List
     * @param  Filter
     * @return 조회 목록
     */
    @Override
    public List<DTO> select조건검색식List(Filter params){
        return DAO.selectList(params);
    }
}
