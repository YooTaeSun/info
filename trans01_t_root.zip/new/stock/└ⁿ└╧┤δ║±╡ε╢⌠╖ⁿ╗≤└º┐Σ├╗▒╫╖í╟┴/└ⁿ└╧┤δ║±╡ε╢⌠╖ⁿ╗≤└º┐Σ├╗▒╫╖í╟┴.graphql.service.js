/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class Graphql전일대비등락률상위요청그래프Service {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async add전일대비등락률상위요청그래프(params) {

    params = {
             일자: ''    // 일자
            ,종목코드: ''    // 종목코드
            ,종목명: ''    // 종목명
            ,market: ''    // 시장구분코드명
            ,filenm: ''    // filenm
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation add전일대비등락률상위요청그래프($input: Filter) {
      one : add전일대비등락률상위요청그래프(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modify전일대비등락률상위요청그래프(params) {

    let query = `mutation modify전일대비등락률상위요청그래프($input: Filter) {
      one : modify전일대비등락률상위요청그래프(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async remove전일대비등락률상위요청그래프(params) {

    params = {
    }

    let query = `mutation remove전일대비등락률상위요청그래프($input: Filter) {
      one : remove전일대비등락률상위요청그래프(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async get전일대비등락률상위요청그래프(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      one: get전일대비등락률상위요청그래프(filter:$params) {
			일자
			종목코드
			종목명
			market
			filenm
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async get전일대비등락률상위요청그래프List(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      cnt: get전일대비등락률상위요청그래프Cnt(filter:$params)   
      list: get전일대비등락률상위요청그래프List(filter:$params) {
			일자
			종목코드
			종목명
			market
			filenm
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new Graphql전일대비등락률상위요청그래프Service();
