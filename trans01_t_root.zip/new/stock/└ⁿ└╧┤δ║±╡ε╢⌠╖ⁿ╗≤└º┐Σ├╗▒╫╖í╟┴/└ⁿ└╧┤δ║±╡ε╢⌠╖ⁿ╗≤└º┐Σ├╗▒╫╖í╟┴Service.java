package .service;

import java.util.List;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 * 전일대비등락률상위요청그래프 서비스
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.07.05.						최초작성
 * </pre>
 */
public interface 전일대비등락률상위요청그래프Service {

	/**
	 * 전일대비등락률상위요청그래프 등록, 수정
     * @Method merge전일대비등락률상위요청그래프
	 * @param Filter
	 */
    public Boolean merge전일대비등락률상위요청그래프(Filter params);	
    
	/**
	 * 전일대비등락률상위요청그래프 여러 건 등록
     * @Method bulkInsert전일대비등락률상위요청그래프
	 * @param Filter
	 */
    public Boolean bulkInsert전일대비등락률상위요청그래프(Filter params);	    
	
	/**
	 * 전일대비등락률상위요청그래프 등록
     * @Method insert전일대비등락률상위요청그래프
	 * @param Filter
	 */
    public Boolean insert전일대비등락률상위요청그래프(Filter params);

    /**
     * 전일대비등락률상위요청그래프 수정
     * @Method update전일대비등락률상위요청그래프
     * @param Filter
     */
    public Boolean update전일대비등락률상위요청그래프(Filter params);

    /**
     * 전일대비등락률상위요청그래프 삭제
     * @Method delete전일대비등락률상위요청그래프
     * @param Filter
     */
    public Boolean delete전일대비등락률상위요청그래프(Filter params);
    
    /**
     * 전일대비등락률상위요청그래프 단건 조회
     * @Method select전일대비등락률상위요청그래프 
     * @param  Filter
     */
    public DTO select전일대비등락률상위요청그래프(Filter params);    
    
    /**
     * 전일대비등락률상위요청그래프 건수 조회
     * @Method select전일대비등락률상위요청그래프Cnt
     * @param  Filter
     */
    public int select전일대비등락률상위요청그래프Cnt(Filter params);
    
    /**
     * 전일대비등락률상위요청그래프 다건 조회
     * @Method select전일대비등락률상위요청그래프List
     * @param  Filter
     */
    public List<DTO> select전일대비등락률상위요청그래프List(Filter params);

}
