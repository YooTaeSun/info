package .service.dao;

import java.util.List;

import com.osstem.ows.biz.cfg.datasource.OwsMapper;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 * 전일대비등락률상위요청그래프 DAO
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.07.05.						최초작성
 * </pre>
 */
@OwsMapper
public interface DAO {

	/**
     * 전일대비등락률상위요청그래프 등록, 수정
     * @Method merge전일대비등락률상위요청그래프
     * @param Filter
     * @return 등록 또는 수정된 건수
     */	
	public int merge(Filter params);
	
	/**
	 * 전일대비등락률상위요청그래프 여러 건 등록
	 * @Method bulkInsert전일대비등락률상위요청그래프
	 * @param Filter
	 * @return 여러 건 등록된 건수
	 */	
	public int bulkInsert(Filter params);
	
	/**
	 * 전일대비등락률상위요청그래프 등록
	 * @Method insert전일대비등락률상위요청그래프
	 * @param Filter
	 * @return 등록된 건수
	 */	
	public int insert(Filter params);
	
    /**
     * 전일대비등락률상위요청그래프 수정
     * @Method update전일대비등락률상위요청그래프
     * @param Filter
     * @return 수정된 건수
     */	
	public int update(Filter params);
	
    /**
     * 전일대비등락률상위요청그래프 삭제 
     * @Method delete전일대비등락률상위요청그래프
     * @param Filter
     * @return 삭제된 건수
     */	
	public int delete(Filter params);
 
    /**
     * 전일대비등락률상위요청그래프 단건 조회
     *
     * @param Filter
     * @return 조회 건
     */	    
	public DTO select(Filter params);

    /**
     * 전일대비등락률상위요청그래프 건수 조회
     * @Method select전일대비등락률상위요청그래프Cnt
     * @param Filter
     * @return 건수
     */	
    int selectCnt(Filter params);
    
    /**
     * 전일대비등락률상위요청그래프 다건 조회
     * @Method select전일대비등락률상위요청그래프List
     * @param Filter 
     * @return 조회 목록
     */	
	public List<DTO> selectList(Filter params);
}
