package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import .model.filter.Filter;
import .service.전일대비등락률상위요청그래프Service;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * 전일대비등락률상위요청그래프 GraphQL Mutation
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.07.05.						최초작성
 * </pre>
 */
@Component
public class 전일대비등락률상위요청그래프Mutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(전일대비등락률상위요청그래프Mutation.class);
	
	@Autowired
	private 전일대비등락률상위요청그래프Service 전일대비등락률상위요청그래프Service;
	
	/**
	 * 전일대비등락률상위요청그래프 등록
     * @Method add전일대비등락률상위요청그래프
	 * @param Filter
	 */
    public Boolean add전일대비등락률상위요청그래프(Filter params) {
    	try {
    		return 전일대비등락률상위요청그래프Service.insert전일대비등락률상위요청그래프(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * 전일대비등락률상위요청그래프 수정
     * @Method modify전일대비등락률상위요청그래프
	 * @param Filter
	 */
	public Boolean modify전일대비등락률상위요청그래프(Filter params) {
		try {
			return 전일대비등락률상위요청그래프Service.update전일대비등락률상위요청그래프(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * 전일대비등락률상위요청그래프 삭제
     * @Method remove전일대비등락률상위요청그래프
	 * @param Filter
	 */
	public Boolean remove전일대비등락률상위요청그래프(Filter params) {
		try {
			return 전일대비등락률상위요청그래프Service.delete전일대비등락률상위요청그래프(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
