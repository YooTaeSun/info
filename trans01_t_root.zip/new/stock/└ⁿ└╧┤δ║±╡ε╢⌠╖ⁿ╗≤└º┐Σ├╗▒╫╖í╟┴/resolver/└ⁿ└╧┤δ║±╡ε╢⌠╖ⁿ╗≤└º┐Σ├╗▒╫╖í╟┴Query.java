package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import .model.dto.DTO;
import .model.filter.Filter;
import .service.전일대비등락률상위요청그래프Service;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * 전일대비등락률상위요청그래프 GraphQL Query
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.07.05.						최초작성
 * </pre>
 */
@Component
public class 전일대비등락률상위요청그래프Query implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(전일대비등락률상위요청그래프Mutation.class);
	
	@Autowired
	private 전일대비등락률상위요청그래프Service 전일대비등락률상위요청그래프Service;

    /**
     * 전일대비등락률상위요청그래프 단건 조회
     * @Method get전일대비등락률상위요청그래프
     * @param  Filter
     * @return 조회 건
     */
    public DTO get전일대비등락률상위요청그래프(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 전일대비등락률상위요청그래프Service.select전일대비등락률상위요청그래프(params);
    }
    
    /**
     * 전일대비등락률상위요청그래프 건수 조회
     * @Method get전일대비등락률상위요청그래프Cnt
     * @param  Filter
     * @return 건수
     */
    public int get전일대비등락률상위요청그래프Cnt(Filter params){
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 전일대비등락률상위요청그래프Service.select전일대비등락률상위요청그래프Cnt(params);
    }

    /**
     * 전일대비등락률상위요청그래프 다건 조회
     * @Method get전일대비등락률상위요청그래프List
     * @param  Filter
     * @return 조회 목록
     */
    public List<DTO> get전일대비등락률상위요청그래프List(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 전일대비등락률상위요청그래프Service.select전일대비등락률상위요청그래프List(params);
    }
}
