package .model.dto;
import java.util.Date;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DTO {

	/**
	 * 일자(PK)
	 */
	@ApiModelProperty(value = "일자: 일자")
	private String 일자;

	/**
	 * 종목코드(PK)
	 */
	@ApiModelProperty(value = "종목코드: 종목코드")
	private String 종목코드;

	/**
	 * 종목명
	 */
	@ApiModelProperty(value = "종목명: 종목명")
	private String 종목명;

	/**
	 * 시장구분코드명
	 */
	@ApiModelProperty(value = "market: 시장구분코드명")
	private String market;

	/**
	 * filenm
	 */
	@ApiModelProperty(value = "filenm: filenm")
	private String filenm;

	/**
	 * 입력날짜
	 */
	@ApiModelProperty(value = "insertDate: 입력날짜")
	private Date insertDate;

	/**
	 * 수정날짜
	 */
	@ApiModelProperty(value = "updateDate: 수정날짜")
	private Date updateDate;


}
