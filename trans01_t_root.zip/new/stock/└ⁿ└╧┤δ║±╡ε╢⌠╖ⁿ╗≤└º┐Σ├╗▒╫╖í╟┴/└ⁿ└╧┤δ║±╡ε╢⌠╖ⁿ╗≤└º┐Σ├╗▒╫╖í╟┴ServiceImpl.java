package .service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import .model.dto.DTO;
import .model.filter.Filter;
import .service.전일대비등락률상위요청그래프Service;
import .service.dao.DAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 * 전일대비등락률상위요청그래프 ServiceImpl
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.07.05.						최초작성
 * </pre>
 */
@Service("전일대비등락률상위요청그래프Service")
public class 전일대비등락률상위요청그래프ServiceImpl implements 전일대비등락률상위요청그래프Service {

	private static final Logger logger = LoggerFactory.getLogger(전일대비등락률상위요청그래프ServiceImpl.class);
	
	@Autowired
    private DAO DAO;
    
	/**
	 * 전일대비등락률상위요청그래프 등록, 수정
     * @Method merge전일대비등락률상위요청그래프
	 * @param Filter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean merge전일대비등락률상위요청그래프(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.merge(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     * 전일대비등락률상위요청그래프 여러 건 등록
     * @Method bulkInsert전일대비등락률상위요청그래프
     * @param Filter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsert전일대비등락률상위요청그래프(Filter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = DAO.bulkInsert(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 * 전일대비등락률상위요청그래프 등록
     * @Method insert전일대비등락률상위요청그래프
	 * @param Filter
     * @return 등록 여부
	 */
    @Override
    public Boolean insert전일대비등락률상위요청그래프(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.insert(params);
        return (result > 0)? true:false;    	
    }

    /**
     * 전일대비등락률상위요청그래프 수정
     * @Method update전일대비등락률상위요청그래프 
     * @param Filter
     * @Method update전일대비등락률상위요청그래프
     * @return 수정 여부
     */
    @Override
    public Boolean update전일대비등락률상위요청그래프(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = DAO.update(params);
        return (result > 0)? true:false;        
    }

    /**
     * 전일대비등락률상위요청그래프 삭제
     * @Method delete전일대비등락률상위요청그래프
     * @param Filter
     * @return 삭제 여부 
     */
    @Override
    public Boolean delete전일대비등락률상위요청그래프(Filter params){
        int result = DAO.delete(params);
        return (result > 0)? true:false;
    }
    
    /**
     * 전일대비등락률상위요청그래프 단건 조회
     * @Method select전일대비등락률상위요청그래프
     * @param  Filter
     * @return 조회 건
     */
    @Override
    public DTO select전일대비등락률상위요청그래프(Filter params){
        return DAO.select(params);
    }
    
    /**
     * 전일대비등락률상위요청그래프 건수 조회
     * @Method select전일대비등락률상위요청그래프Cnt
     * @param  Filter
     * @return 건수
     */
    @Override
    public int select전일대비등락률상위요청그래프Cnt(Filter params){
        return DAO.selectCnt(params);
    }

    /**
     * 전일대비등락률상위요청그래프 다건 조회
     * @Method select전일대비등락률상위요청그래프List
     * @param  Filter
     * @return 조회 목록
     */
    @Override
    public List<DTO> select전일대비등락률상위요청그래프List(Filter params){
        return DAO.selectList(params);
    }
}
