package com.osstem.ows.biz.sal.sales.service.dao;

import java.util.List;

import com.osstem.ows.biz.cfg.datasource.OwsMapper;
import com.osstem.ows.biz.sal.sales.model.dto.SkipStockDTO;
import com.osstem.ows.biz.sal.sales.model.filter.SkipStockFilter;

/**
 * 조건식 종목들 DAO
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.11.17.		system				최초작성
 * </pre>
 */
@OwsMapper
public interface SkipStockDAO {

	/**
     * 조건식 종목들 등록, 수정
     * @Method mergeTransWatch
     * @param SkipStockFilter
     * @return 등록 또는 수정된 건수
     */	
	public int mergeSkipStock(SkipStockFilter params);
	
	/**
	 * 조건식 종목들 여러 건 등록
	 * @Method bulkInsertTransWatch
	 * @param SkipStockFilter
	 * @return 여러 건 등록된 건수
	 */	
	public int bulkInsertSkipStock(SkipStockFilter params);
	
	/**
	 * 조건식 종목들 등록
	 * @Method insertTransWatch
	 * @param SkipStockFilter
	 * @return 등록된 건수
	 */	
	public int insertSkipStock(SkipStockFilter params);
	
    /**
     * 조건식 종목들 수정
     * @Method updateTransWatch
     * @param SkipStockFilter
     * @return 수정된 건수
     */	
	public int updateSkipStock(SkipStockFilter params);
	
    /**
     * 조건식 종목들 삭제 
     * @Method deleteTransWatch
     * @param SkipStockFilter
     * @return 삭제된 건수
     */	
	public int deleteSkipStock(SkipStockFilter params);
 
    /**
     * 조건식 종목들 단건 조회
     *
     * @param SkipStockFilter
     * @return 조회 건
     */	    
	public SkipStockDTO selectSkipStock(SkipStockFilter params);

    /**
     * 조건식 종목들 건수 조회
     * @Method selectTransWatchCnt
     * @param SkipStockFilter
     * @return 건수
     */	
    int selectSkipStockCnt(SkipStockFilter params);
    
    /**
     * 조건식 종목들 다건 조회
     * @Method selectTransWatchList
     * @param SkipStockFilter 
     * @return 조회 목록
     */	
	public List<SkipStockDTO> selectSkipStockList(SkipStockFilter params);
}
