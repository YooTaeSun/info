/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class GraphqlTransWatchService {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async addTransWatch(params) {

    params = {
             일자: ''    // 일자
            ,종목코드: ''    // 종목코드
            ,종목명: ''    // 종목명
            ,시장구분: ''    // 시장구분코드명
            ,이유: ''    // 이유
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation addTransWatch($input: SkipStockFilter) {
      one : addTransWatch(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modifyTransWatch(params) {

    let query = `mutation modifyTransWatch($input: SkipStockFilter) {
      one : modifyTransWatch(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async removeTransWatch(params) {

    params = {
    }

    let query = `mutation removeTransWatch($input: SkipStockFilter) {
      one : removeTransWatch(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async getTransWatch(params) {

    params = {

    }

    let query = `
    query ($params:SkipStockFilter) {
      one: getTransWatch(filter:$params) {
			일자
			종목코드
			종목명
			시장구분
			이유
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async getTransWatchList(params) {

    params = {

    }

    let query = `
    query ($params:SkipStockFilter) {
      cnt: getTransWatchCnt(filter:$params)   
      list: getTransWatchList(filter:$params) {
			일자
			종목코드
			종목명
			시장구분
			이유
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new GraphqlTransWatchService();
