package com.osstem.ows.biz.sal.sales.service;

import java.util.List;
import com.osstem.ows.biz.sal.sales.model.dto.SkipStockDTO;
import com.osstem.ows.biz.sal.sales.model.filter.SkipStockFilter;

/**
 * 조건식 종목들 서비스
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.11.17.		system				최초작성
 * </pre>
 */
public interface TransWatchService {

	/**
	 * 조건식 종목들 등록, 수정
     * @Method mergeTransWatch
	 * @param SkipStockFilter
	 */
    public Boolean mergeTransWatch(SkipStockFilter params);	
    
	/**
	 * 조건식 종목들 여러 건 등록
     * @Method bulkInsertTransWatch
	 * @param SkipStockFilter
	 */
    public Boolean bulkInsertTransWatch(SkipStockFilter params);	    
	
	/**
	 * 조건식 종목들 등록
     * @Method insertTransWatch
	 * @param SkipStockFilter
	 */
    public Boolean insertTransWatch(SkipStockFilter params);

    /**
     * 조건식 종목들 수정
     * @Method updateTransWatch
     * @param skipStockFilter
     */
    public Boolean updateTransWatch(SkipStockFilter params);

    /**
     * 조건식 종목들 삭제
     * @Method deleteTransWatch
     * @param skipStockFilter
     */
    public Boolean deleteTransWatch(SkipStockFilter params);
    
    /**
     * 조건식 종목들 단건 조회
     * @Method selectTransWatch 
     * @param  skipStockFilter
     */
    public SkipStockDTO selectTransWatch(SkipStockFilter params);    
    
    /**
     * 조건식 종목들 건수 조회
     * @Method selectTransWatchCnt
     * @param  skipStockFilter
     */
    public int selectTransWatchCnt(SkipStockFilter params);
    
    /**
     * 조건식 종목들 다건 조회
     * @Method selectTransWatchList
     * @param  skipStockFilter
     */
    public List<SkipStockDTO> selectTransWatchList(SkipStockFilter params);

}
