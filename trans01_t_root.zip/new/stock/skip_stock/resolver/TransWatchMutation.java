package com.osstem.ows.biz.sal.sales.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import com.osstem.ows.biz.sal.sales.model.filter.SkipStockFilter;
import com.osstem.ows.biz.sal.sales.service.TransWatchService;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * 조건식 종목들 GraphQL Mutation
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.11.17.		system				최초작성
 * </pre>
 */
@Component
public class TransWatchMutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(TransWatchMutation.class);
	
	@Autowired
	private TransWatchService transWatchService;
	
	/**
	 * 조건식 종목들 등록
     * @Method addTransWatch
	 * @param SkipStockFilter
	 */
    public Boolean addTransWatch(SkipStockFilter params) {
    	try {
    		return transWatchService.insertTransWatch(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * 조건식 종목들 수정
     * @Method modifyTransWatch
	 * @param SkipStockFilter
	 */
	public Boolean modifyTransWatch(SkipStockFilter params) {
		try {
			return transWatchService.updateTransWatch(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * 조건식 종목들 삭제
     * @Method removeTransWatch
	 * @param SkipStockFilter
	 */
	public Boolean removeTransWatch(SkipStockFilter params) {
		try {
			return transWatchService.deleteTransWatch(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
