package com.osstem.ows.biz.sal.sales.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.sal.sales.model.dto.SkipStockDTO;
import com.osstem.ows.biz.sal.sales.model.filter.SkipStockFilter;
import com.osstem.ows.biz.sal.sales.service.TransWatchService;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * 조건식 종목들 GraphQL Query
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.11.17.		system				최초작성
 * </pre>
 */
@Component
public class TransWatchQuery implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(TransWatchMutation.class);
	
	@Autowired
	private TransWatchService transWatchService;

    /**
     * 조건식 종목들 단건 조회
     * @Method getTransWatch
     * @param  skipStockFilter
     * @return 조회 건
     */
    public SkipStockDTO getTransWatch(SkipStockFilter params) {
    	params = Optional.ofNullable(params).orElseGet(SkipStockFilter::new);
    	return transWatchService.selectTransWatch(params);
    }
    
    /**
     * 조건식 종목들 건수 조회
     * @Method getTransWatchCnt
     * @param  skipStockFilter
     * @return 건수
     */
    public int getTransWatchCnt(SkipStockFilter params){
    	params = Optional.ofNullable(params).orElseGet(SkipStockFilter::new);
    	return transWatchService.selectTransWatchCnt(params);
    }

    /**
     * 조건식 종목들 다건 조회
     * @Method getTransWatchList
     * @param  skipStockFilter
     * @return 조회 목록
     */
    public List<SkipStockDTO> getTransWatchList(SkipStockFilter params) {
    	params = Optional.ofNullable(params).orElseGet(SkipStockFilter::new);
    	return transWatchService.selectTransWatchList(params);
    }
}
