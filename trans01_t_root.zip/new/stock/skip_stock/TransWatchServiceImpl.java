package com.osstem.ows.biz.sal.sales.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import com.osstem.ows.biz.sal.sales.model.dto.SkipStockDTO;
import com.osstem.ows.biz.sal.sales.model.filter.SkipStockFilter;
import com.osstem.ows.biz.sal.sales.service.TransWatchService;
import com.osstem.ows.biz.sal.sales.service.dao.SkipStockDAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 * 조건식 종목들 ServiceImpl
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.11.17.		system				최초작성
 * </pre>
 */
@Service("transWatchService")
public class TransWatchServiceImpl implements TransWatchService {

	private static final Logger logger = LoggerFactory.getLogger(TransWatchServiceImpl.class);
	
	@Autowired
    private SkipStockDAO skipStockDAO;
    
	/**
	 * 조건식 종목들 등록, 수정
     * @Method mergeTransWatch
	 * @param SkipStockFilter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean mergeTransWatch(SkipStockFilter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = skipStockDAO.mergeSkipStock(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     * 조건식 종목들 여러 건 등록
     * @Method bulkInsertTransWatch
     * @param SkipStockFilter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsertTransWatch(SkipStockFilter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = skipStockDAO.bulkInsertSkipStock(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 * 조건식 종목들 등록
     * @Method insertTransWatch
	 * @param SkipStockFilter
     * @return 등록 여부
	 */
    @Override
    public Boolean insertTransWatch(SkipStockFilter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = skipStockDAO.insertSkipStock(params);
        return (result > 0)? true:false;    	
    }

    /**
     * 조건식 종목들 수정
     * @Method updateTransWatch 
     * @param skipStockFilter
     * @Method updateTransWatch
     * @return 수정 여부
     */
    @Override
    public Boolean updateTransWatch(SkipStockFilter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = skipStockDAO.updateSkipStock(params);
        return (result > 0)? true:false;        
    }

    /**
     * 조건식 종목들 삭제
     * @Method deleteTransWatch
     * @param skipStockFilter
     * @return 삭제 여부 
     */
    @Override
    public Boolean deleteTransWatch(SkipStockFilter params){
        int result = skipStockDAO.deleteSkipStock(params);
        return (result > 0)? true:false;
    }
    
    /**
     * 조건식 종목들 단건 조회
     * @Method selectTransWatch
     * @param  skipStockFilter
     * @return 조회 건
     */
    @Override
    public SkipStockDTO selectTransWatch(SkipStockFilter params){
        return skipStockDAO.selectSkipStock(params);
    }
    
    /**
     * 조건식 종목들 건수 조회
     * @Method selectTransWatchCnt
     * @param  skipStockFilter
     * @return 건수
     */
    @Override
    public int selectTransWatchCnt(SkipStockFilter params){
        return skipStockDAO.selectSkipStockCnt(params);
    }

    /**
     * 조건식 종목들 다건 조회
     * @Method selectTransWatchList
     * @param  skipStockFilter
     * @return 조회 목록
     */
    @Override
    public List<SkipStockDTO> selectTransWatchList(SkipStockFilter params){
        return skipStockDAO.selectSkipStockList(params);
    }
}
