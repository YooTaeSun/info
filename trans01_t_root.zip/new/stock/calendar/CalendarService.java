package .service;

import java.util.List;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 *  서비스
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.						최초작성
 * </pre>
 */
public interface CalendarService {

	/**
	 *  등록, 수정
     * @Method mergeCalendar
	 * @param Filter
	 */
    public Boolean mergeCalendar(Filter params);	
    
	/**
	 *  여러 건 등록
     * @Method bulkInsertCalendar
	 * @param Filter
	 */
    public Boolean bulkInsertCalendar(Filter params);	    
	
	/**
	 *  등록
     * @Method insertCalendar
	 * @param Filter
	 */
    public Boolean insertCalendar(Filter params);

    /**
     *  수정
     * @Method updateCalendar
     * @param Filter
     */
    public Boolean updateCalendar(Filter params);

    /**
     *  삭제
     * @Method deleteCalendar
     * @param Filter
     */
    public Boolean deleteCalendar(Filter params);
    
    /**
     *  단건 조회
     * @Method selectCalendar 
     * @param  Filter
     */
    public DTO selectCalendar(Filter params);    
    
    /**
     *  건수 조회
     * @Method selectCalendarCnt
     * @param  Filter
     */
    public int selectCalendarCnt(Filter params);
    
    /**
     *  다건 조회
     * @Method selectCalendarList
     * @param  Filter
     */
    public List<DTO> selectCalendarList(Filter params);

}
