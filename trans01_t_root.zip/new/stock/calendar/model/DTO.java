package .model.dto;
import java.util.Date;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DTO {

	/**
	 * (PK)
	 */
	@ApiModelProperty(value = "id: ")
	private String id;

	/**
	 * (PK)
	 */
	@ApiModelProperty(value = "nation: ")
	private String nation;

	/**
	 * 
	 */
	@ApiModelProperty(value = "year: ")
	private Integer year;

	/**
	 * 
	 */
	@ApiModelProperty(value = "month: ")
	private Integer month;

	/**
	 * 
	 */
	@ApiModelProperty(value = "day: ")
	private Integer day;

	/**
	 * 
	 */
	@ApiModelProperty(value = "quarter: ")
	private Integer quarter;

	/**
	 * 
	 */
	@ApiModelProperty(value = "week: ")
	private Integer week;

	/**
	 * 
	 */
	@ApiModelProperty(value = "dayName: ")
	private String dayName;

	/**
	 * 
	 */
	@ApiModelProperty(value = "monthName: ")
	private String monthName;

	/**
	 * 
	 */
	@ApiModelProperty(value = "operatingFlag: ")
	private String operatingFlag;

	/**
	 * 
	 */
	@ApiModelProperty(value = "holidayFlag: ")
	private String holidayFlag;

	/**
	 * 
	 */
	@ApiModelProperty(value = "weekendFlag: ")
	private String weekendFlag;

	/**
	 * 
	 */
	@ApiModelProperty(value = "event: ")
	private String event;

	/**
	 * 
	 */
	@ApiModelProperty(value = "tradeHistory: ")
	private String tradeHistory;


}
