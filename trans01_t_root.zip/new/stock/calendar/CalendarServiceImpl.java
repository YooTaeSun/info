package .service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import .model.dto.DTO;
import .model.filter.Filter;
import .service.CalendarService;
import .service.dao.DAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 *  ServiceImpl
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.						최초작성
 * </pre>
 */
@Service("calendarService")
public class CalendarServiceImpl implements CalendarService {

	private static final Logger logger = LoggerFactory.getLogger(CalendarServiceImpl.class);
	
	@Autowired
    private DAO DAO;
    
	/**
	 *  등록, 수정
     * @Method mergeCalendar
	 * @param Filter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean mergeCalendar(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.merge(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     *  여러 건 등록
     * @Method bulkInsertCalendar
     * @param Filter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsertCalendar(Filter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = DAO.bulkInsert(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 *  등록
     * @Method insertCalendar
	 * @param Filter
     * @return 등록 여부
	 */
    @Override
    public Boolean insertCalendar(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.insert(params);
        return (result > 0)? true:false;    	
    }

    /**
     *  수정
     * @Method updateCalendar 
     * @param Filter
     * @Method updateCalendar
     * @return 수정 여부
     */
    @Override
    public Boolean updateCalendar(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = DAO.update(params);
        return (result > 0)? true:false;        
    }

    /**
     *  삭제
     * @Method deleteCalendar
     * @param Filter
     * @return 삭제 여부 
     */
    @Override
    public Boolean deleteCalendar(Filter params){
        int result = DAO.delete(params);
        return (result > 0)? true:false;
    }
    
    /**
     *  단건 조회
     * @Method selectCalendar
     * @param  Filter
     * @return 조회 건
     */
    @Override
    public DTO selectCalendar(Filter params){
        return DAO.select(params);
    }
    
    /**
     *  건수 조회
     * @Method selectCalendarCnt
     * @param  Filter
     * @return 건수
     */
    @Override
    public int selectCalendarCnt(Filter params){
        return DAO.selectCnt(params);
    }

    /**
     *  다건 조회
     * @Method selectCalendarList
     * @param  Filter
     * @return 조회 목록
     */
    @Override
    public List<DTO> selectCalendarList(Filter params){
        return DAO.selectList(params);
    }
}
