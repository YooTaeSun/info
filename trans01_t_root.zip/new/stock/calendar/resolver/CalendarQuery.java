package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import .model.dto.DTO;
import .model.filter.Filter;
import .service.CalendarService;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 *  GraphQL Query
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.						최초작성
 * </pre>
 */
@Component
public class CalendarQuery implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(CalendarMutation.class);
	
	@Autowired
	private CalendarService calendarService;

    /**
     *  단건 조회
     * @Method getCalendar
     * @param  Filter
     * @return 조회 건
     */
    public DTO getCalendar(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return calendarService.selectCalendar(params);
    }
    
    /**
     *  건수 조회
     * @Method getCalendarCnt
     * @param  Filter
     * @return 건수
     */
    public int getCalendarCnt(Filter params){
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return calendarService.selectCalendarCnt(params);
    }

    /**
     *  다건 조회
     * @Method getCalendarList
     * @param  Filter
     * @return 조회 목록
     */
    public List<DTO> getCalendarList(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return calendarService.selectCalendarList(params);
    }
}
