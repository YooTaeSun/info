package com.osstem.ows.biz.sal.sales.service;

import java.util.List;
import com.osstem.ows.biz.sal.sales.model.dto.DTO;
import com.osstem.ows.biz.sal.sales.model.filter.Filter;

/**
 * 조건검색식적용 저장 테이블 서비스
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.03.12.		system				최초작성
 * </pre>
 */
public interface TransWatchService {

	/**
	 * 조건검색식적용 저장 테이블 등록, 수정
     * @Method mergeTransWatch
	 * @param Filter
	 */
    public Boolean mergeTransWatch(Filter params);	
    
	/**
	 * 조건검색식적용 저장 테이블 여러 건 등록
     * @Method bulkInsertTransWatch
	 * @param Filter
	 */
    public Boolean bulkInsertTransWatch(Filter params);	    
	
	/**
	 * 조건검색식적용 저장 테이블 등록
     * @Method insertTransWatch
	 * @param Filter
	 */
    public Boolean insertTransWatch(Filter params);

    /**
     * 조건검색식적용 저장 테이블 수정
     * @Method updateTransWatch
     * @param Filter
     */
    public Boolean updateTransWatch(Filter params);

    /**
     * 조건검색식적용 저장 테이블 삭제
     * @Method deleteTransWatch
     * @param Filter
     */
    public Boolean deleteTransWatch(Filter params);
    
    /**
     * 조건검색식적용 저장 테이블 단건 조회
     * @Method selectTransWatch 
     * @param  Filter
     */
    public DTO selectTransWatch(Filter params);    
    
    /**
     * 조건검색식적용 저장 테이블 건수 조회
     * @Method selectTransWatchCnt
     * @param  Filter
     */
    public int selectTransWatchCnt(Filter params);
    
    /**
     * 조건검색식적용 저장 테이블 다건 조회
     * @Method selectTransWatchList
     * @param  Filter
     */
    public List<DTO> selectTransWatchList(Filter params);

}
