package com.osstem.ows.biz.sal.sales.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import com.osstem.ows.biz.sal.sales.model.dto.DTO;
import com.osstem.ows.biz.sal.sales.model.filter.Filter;
import com.osstem.ows.biz.sal.sales.service.TransWatchService;
import com.osstem.ows.biz.sal.sales.service.dao.DAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 * 조건검색식적용 저장 테이블 ServiceImpl
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.03.12.		system				최초작성
 * </pre>
 */
@Service("transWatchService")
public class TransWatchServiceImpl implements TransWatchService {

	private static final Logger logger = LoggerFactory.getLogger(TransWatchServiceImpl.class);
	
	@Autowired
    private DAO DAO;
    
	/**
	 * 조건검색식적용 저장 테이블 등록, 수정
     * @Method mergeTransWatch
	 * @param Filter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean mergeTransWatch(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.merge(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     * 조건검색식적용 저장 테이블 여러 건 등록
     * @Method bulkInsertTransWatch
     * @param Filter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsertTransWatch(Filter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = DAO.bulkInsert(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 * 조건검색식적용 저장 테이블 등록
     * @Method insertTransWatch
	 * @param Filter
     * @return 등록 여부
	 */
    @Override
    public Boolean insertTransWatch(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.insert(params);
        return (result > 0)? true:false;    	
    }

    /**
     * 조건검색식적용 저장 테이블 수정
     * @Method updateTransWatch 
     * @param Filter
     * @Method updateTransWatch
     * @return 수정 여부
     */
    @Override
    public Boolean updateTransWatch(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = DAO.update(params);
        return (result > 0)? true:false;        
    }

    /**
     * 조건검색식적용 저장 테이블 삭제
     * @Method deleteTransWatch
     * @param Filter
     * @return 삭제 여부 
     */
    @Override
    public Boolean deleteTransWatch(Filter params){
        int result = DAO.delete(params);
        return (result > 0)? true:false;
    }
    
    /**
     * 조건검색식적용 저장 테이블 단건 조회
     * @Method selectTransWatch
     * @param  Filter
     * @return 조회 건
     */
    @Override
    public DTO selectTransWatch(Filter params){
        return DAO.select(params);
    }
    
    /**
     * 조건검색식적용 저장 테이블 건수 조회
     * @Method selectTransWatchCnt
     * @param  Filter
     * @return 건수
     */
    @Override
    public int selectTransWatchCnt(Filter params){
        return DAO.selectCnt(params);
    }

    /**
     * 조건검색식적용 저장 테이블 다건 조회
     * @Method selectTransWatchList
     * @param  Filter
     * @return 조회 목록
     */
    @Override
    public List<DTO> selectTransWatchList(Filter params){
        return DAO.selectList(params);
    }
}
