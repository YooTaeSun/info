package com.osstem.ows.biz.sal.sales.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import com.osstem.ows.biz.sal.sales.model.filter.Filter;
import com.osstem.ows.biz.sal.sales.service.TransWatchService;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * 조건검색식적용 저장 테이블 GraphQL Mutation
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.03.12.		system				최초작성
 * </pre>
 */
@Component
public class TransWatchMutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(TransWatchMutation.class);
	
	@Autowired
	private TransWatchService transWatchService;
	
	/**
	 * 조건검색식적용 저장 테이블 등록
     * @Method addTransWatch
	 * @param Filter
	 */
    public Boolean addTransWatch(Filter params) {
    	try {
    		return transWatchService.insertTransWatch(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * 조건검색식적용 저장 테이블 수정
     * @Method modifyTransWatch
	 * @param Filter
	 */
	public Boolean modifyTransWatch(Filter params) {
		try {
			return transWatchService.updateTransWatch(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * 조건검색식적용 저장 테이블 삭제
     * @Method removeTransWatch
	 * @param Filter
	 */
	public Boolean removeTransWatch(Filter params) {
		try {
			return transWatchService.deleteTransWatch(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
