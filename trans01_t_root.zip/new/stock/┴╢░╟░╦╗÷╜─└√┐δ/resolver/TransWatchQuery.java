package com.osstem.ows.biz.sal.sales.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.sal.sales.model.dto.DTO;
import com.osstem.ows.biz.sal.sales.model.filter.Filter;
import com.osstem.ows.biz.sal.sales.service.TransWatchService;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * 조건검색식적용 저장 테이블 GraphQL Query
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.03.12.		system				최초작성
 * </pre>
 */
@Component
public class TransWatchQuery implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(TransWatchMutation.class);
	
	@Autowired
	private TransWatchService transWatchService;

    /**
     * 조건검색식적용 저장 테이블 단건 조회
     * @Method getTransWatch
     * @param  Filter
     * @return 조회 건
     */
    public DTO getTransWatch(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return transWatchService.selectTransWatch(params);
    }
    
    /**
     * 조건검색식적용 저장 테이블 건수 조회
     * @Method getTransWatchCnt
     * @param  Filter
     * @return 건수
     */
    public int getTransWatchCnt(Filter params){
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return transWatchService.selectTransWatchCnt(params);
    }

    /**
     * 조건검색식적용 저장 테이블 다건 조회
     * @Method getTransWatchList
     * @param  Filter
     * @return 조회 목록
     */
    public List<DTO> getTransWatchList(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return transWatchService.selectTransWatchList(params);
    }
}
