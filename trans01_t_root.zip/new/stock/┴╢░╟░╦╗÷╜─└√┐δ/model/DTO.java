package com.osstem.ows.biz.sal.sales.model.dto;
import java.util.Date;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DTO {

	/**
	 * user_id(PK)
	 */
	@ApiModelProperty(value = "userId: user_id")
	private String userId;

	/**
	 * 개발, 운영(PK)
	 */
	@ApiModelProperty(value = "개발환경: 개발, 운영")
	private String 개발환경;

	/**
	 * 조건이름(PK)
	 */
	@ApiModelProperty(value = "조건이름: 조건이름")
	private String 조건이름;

	/**
	 * 전략(PK)
	 */
	@ApiModelProperty(value = "전략: 전략")
	private String 전략;

	/**
	 * 삭제여부
	 */
	@ApiModelProperty(value = "delYn: 삭제여부")
	private String delYn;

	/**
	 * 입력날짜
	 */
	@ApiModelProperty(value = "insertDate: 입력날짜")
	private Date insertDate;

	/**
	 * 수정날짜
	 */
	@ApiModelProperty(value = "updateDate: 수정날짜")
	private Date updateDate;


}
