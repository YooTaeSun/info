/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class GraphqlTransWatchService {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async addTransWatch(params) {

    params = {
             userId: ''    // user_id
            ,개발환경: ''    // 개발, 운영
            ,조건이름: ''    // 조건이름
            ,전략: ''    // 전략
            ,delYn: ''    // 삭제여부
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation addTransWatch($input: Filter) {
      one : addTransWatch(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modifyTransWatch(params) {

    let query = `mutation modifyTransWatch($input: Filter) {
      one : modifyTransWatch(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async removeTransWatch(params) {

    params = {
    }

    let query = `mutation removeTransWatch($input: Filter) {
      one : removeTransWatch(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async getTransWatch(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      one: getTransWatch(filter:$params) {
			userId
			개발환경
			조건이름
			전략
			delYn
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async getTransWatchList(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      cnt: getTransWatchCnt(filter:$params)   
      list: getTransWatchList(filter:$params) {
			userId
			개발환경
			조건이름
			전략
			delYn
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new GraphqlTransWatchService();
