package .model.dto;
import java.util.Date;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DTO {

	/**
	 * 순번(PK)
	 */
	@ApiModelProperty(value = "순번: 순번")
	private Long 순번;

	/**
	 * 발신인
	 */
	@ApiModelProperty(value = "sender: 발신인")
	private String sender;

	/**
	 * 수신인
	 */
	@ApiModelProperty(value = "recipient: 수신인")
	private String recipient;

	/**
	 * 실시간구독, TEST
	 */
	@ApiModelProperty(value = "command: 실시간구독, TEST")
	private String command;

	/**
	 * SEND, REV
	 */
	@ApiModelProperty(value = "connKind: SEND, REV")
	private String connKind;

	/**
	 * user_id
	 */
	@ApiModelProperty(value = "userId: user_id")
	private String userId;

	/**
	 * watch_id
	 */
	@ApiModelProperty(value = "watchId: watch_id")
	private String watchId;

	/**
	 * 종목코드
	 */
	@ApiModelProperty(value = "종목코드: 종목코드")
	private String 종목코드;

	/**
	 * 종목명
	 */
	@ApiModelProperty(value = "종목명: 종목명")
	private String 종목명;

	/**
	 * command_json
	 */
	@ApiModelProperty(value = "commandJson: command_json")
	private String commandJson;

	/**
	 * 보낸시간
	 */
	@ApiModelProperty(value = "sendTime: 보낸시간")
	private String sendTime;

	/**
	 * Y,N
	 */
	@ApiModelProperty(value = "isResponse: Y,N")
	private String isResponse;

	/**
	 * 입력날짜
	 */
	@ApiModelProperty(value = "insertDate: 입력날짜")
	private Date insertDate;

	/**
	 * 수정날짜
	 */
	@ApiModelProperty(value = "updateDate: 수정날짜")
	private Date updateDate;


}
