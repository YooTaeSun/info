package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import .model.filter.Filter;
import .service.KafkaService;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * kafKa GraphQL Mutation
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.05.06.						최초작성
 * </pre>
 */
@Component
public class KafkaMutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(KafkaMutation.class);
	
	@Autowired
	private KafkaService kafkaService;
	
	/**
	 * kafKa 등록
     * @Method addKafka
	 * @param Filter
	 */
    public Boolean addKafka(Filter params) {
    	try {
    		return kafkaService.insertKafka(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * kafKa 수정
     * @Method modifyKafka
	 * @param Filter
	 */
	public Boolean modifyKafka(Filter params) {
		try {
			return kafkaService.updateKafka(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * kafKa 삭제
     * @Method removeKafka
	 * @param Filter
	 */
	public Boolean removeKafka(Filter params) {
		try {
			return kafkaService.deleteKafka(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
