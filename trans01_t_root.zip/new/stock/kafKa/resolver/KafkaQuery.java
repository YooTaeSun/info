package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import .model.dto.DTO;
import .model.filter.Filter;
import .service.KafkaService;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * kafKa GraphQL Query
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.05.06.						최초작성
 * </pre>
 */
@Component
public class KafkaQuery implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(KafkaMutation.class);
	
	@Autowired
	private KafkaService kafkaService;

    /**
     * kafKa 단건 조회
     * @Method getKafka
     * @param  Filter
     * @return 조회 건
     */
    public DTO getKafka(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return kafkaService.selectKafka(params);
    }
    
    /**
     * kafKa 건수 조회
     * @Method getKafkaCnt
     * @param  Filter
     * @return 건수
     */
    public int getKafkaCnt(Filter params){
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return kafkaService.selectKafkaCnt(params);
    }

    /**
     * kafKa 다건 조회
     * @Method getKafkaList
     * @param  Filter
     * @return 조회 목록
     */
    public List<DTO> getKafkaList(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return kafkaService.selectKafkaList(params);
    }
}
