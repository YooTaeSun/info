package .service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import .model.dto.DTO;
import .model.filter.Filter;
import .service.KafkaService;
import .service.dao.DAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 * kafKa ServiceImpl
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.05.06.						최초작성
 * </pre>
 */
@Service("kafkaService")
public class KafkaServiceImpl implements KafkaService {

	private static final Logger logger = LoggerFactory.getLogger(KafkaServiceImpl.class);
	
	@Autowired
    private DAO DAO;
    
	/**
	 * kafKa 등록, 수정
     * @Method mergeKafka
	 * @param Filter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean mergeKafka(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.merge(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     * kafKa 여러 건 등록
     * @Method bulkInsertKafka
     * @param Filter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsertKafka(Filter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = DAO.bulkInsert(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 * kafKa 등록
     * @Method insertKafka
	 * @param Filter
     * @return 등록 여부
	 */
    @Override
    public Boolean insertKafka(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.insert(params);
        return (result > 0)? true:false;    	
    }

    /**
     * kafKa 수정
     * @Method updateKafka 
     * @param Filter
     * @Method updateKafka
     * @return 수정 여부
     */
    @Override
    public Boolean updateKafka(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = DAO.update(params);
        return (result > 0)? true:false;        
    }

    /**
     * kafKa 삭제
     * @Method deleteKafka
     * @param Filter
     * @return 삭제 여부 
     */
    @Override
    public Boolean deleteKafka(Filter params){
        int result = DAO.delete(params);
        return (result > 0)? true:false;
    }
    
    /**
     * kafKa 단건 조회
     * @Method selectKafka
     * @param  Filter
     * @return 조회 건
     */
    @Override
    public DTO selectKafka(Filter params){
        return DAO.select(params);
    }
    
    /**
     * kafKa 건수 조회
     * @Method selectKafkaCnt
     * @param  Filter
     * @return 건수
     */
    @Override
    public int selectKafkaCnt(Filter params){
        return DAO.selectCnt(params);
    }

    /**
     * kafKa 다건 조회
     * @Method selectKafkaList
     * @param  Filter
     * @return 조회 목록
     */
    @Override
    public List<DTO> selectKafkaList(Filter params){
        return DAO.selectList(params);
    }
}
