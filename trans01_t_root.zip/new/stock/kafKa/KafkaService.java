package .service;

import java.util.List;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 * kafKa 서비스
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.05.06.						최초작성
 * </pre>
 */
public interface KafkaService {

	/**
	 * kafKa 등록, 수정
     * @Method mergeKafka
	 * @param Filter
	 */
    public Boolean mergeKafka(Filter params);	
    
	/**
	 * kafKa 여러 건 등록
     * @Method bulkInsertKafka
	 * @param Filter
	 */
    public Boolean bulkInsertKafka(Filter params);	    
	
	/**
	 * kafKa 등록
     * @Method insertKafka
	 * @param Filter
	 */
    public Boolean insertKafka(Filter params);

    /**
     * kafKa 수정
     * @Method updateKafka
     * @param Filter
     */
    public Boolean updateKafka(Filter params);

    /**
     * kafKa 삭제
     * @Method deleteKafka
     * @param Filter
     */
    public Boolean deleteKafka(Filter params);
    
    /**
     * kafKa 단건 조회
     * @Method selectKafka 
     * @param  Filter
     */
    public DTO selectKafka(Filter params);    
    
    /**
     * kafKa 건수 조회
     * @Method selectKafkaCnt
     * @param  Filter
     */
    public int selectKafkaCnt(Filter params);
    
    /**
     * kafKa 다건 조회
     * @Method selectKafkaList
     * @param  Filter
     */
    public List<DTO> selectKafkaList(Filter params);

}
