/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class GraphqlKafkaService {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async addKafka(params) {

    params = {
             순번: ''    // 순번
            ,sender: ''    // 발신인
            ,recipient: ''    // 수신인
            ,command: ''    // 실시간구독, TEST
            ,connKind: ''    // SEND, REV
            ,userId: ''    // user_id
            ,watchId: ''    // watch_id
            ,종목코드: ''    // 종목코드
            ,종목명: ''    // 종목명
            ,commandJson: ''    // command_json
            ,sendTime: ''    // 보낸시간
            ,isResponse: ''    // Y,N
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation addKafka($input: Filter) {
      one : addKafka(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modifyKafka(params) {

    let query = `mutation modifyKafka($input: Filter) {
      one : modifyKafka(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async removeKafka(params) {

    params = {
    }

    let query = `mutation removeKafka($input: Filter) {
      one : removeKafka(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async getKafka(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      one: getKafka(filter:$params) {
			순번
			sender
			recipient
			command
			connKind
			userId
			watchId
			종목코드
			종목명
			commandJson
			sendTime
			isResponse
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async getKafkaList(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      cnt: getKafkaCnt(filter:$params)   
      list: getKafkaList(filter:$params) {
			순번
			sender
			recipient
			command
			connKind
			userId
			watchId
			종목코드
			종목명
			commandJson
			sendTime
			isResponse
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new GraphqlKafkaService();
