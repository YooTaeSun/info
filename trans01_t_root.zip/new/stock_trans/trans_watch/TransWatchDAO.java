package com.osstem.ows.biz.sal.sales.service.dao;

import java.util.List;

import com.osstem.ows.biz.cfg.datasource.OwsMapper;
import com.osstem.ows.biz.sal.sales.model.dto.TransWatchDTO;
import com.osstem.ows.biz.sal.sales.model.filter.TransWatchFilter;

/**
 * 주식 감시 DAO
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.		system				최초작성
 * </pre>
 */
@OwsMapper
public interface TransWatchDAO {

	/**
     * 주식 감시 등록, 수정
     * @Method mergeTransWatch
     * @param TransWatchFilter
     * @return 등록 또는 수정된 건수
     */	
	public int mergeTransWatch(TransWatchFilter params);
	
	/**
	 * 주식 감시 여러 건 등록
	 * @Method bulkInsertTransWatch
	 * @param TransWatchFilter
	 * @return 여러 건 등록된 건수
	 */	
	public int bulkInsertTransWatch(TransWatchFilter params);
	
	/**
	 * 주식 감시 등록
	 * @Method insertTransWatch
	 * @param TransWatchFilter
	 * @return 등록된 건수
	 */	
	public int insertTransWatch(TransWatchFilter params);
	
    /**
     * 주식 감시 수정
     * @Method updateTransWatch
     * @param TransWatchFilter
     * @return 수정된 건수
     */	
	public int updateTransWatch(TransWatchFilter params);
	
    /**
     * 주식 감시 삭제 
     * @Method deleteTransWatch
     * @param TransWatchFilter
     * @return 삭제된 건수
     */	
	public int deleteTransWatch(TransWatchFilter params);
 
    /**
     * 주식 감시 단건 조회
     *
     * @param TransWatchFilter
     * @return 조회 건
     */	    
	public TransWatchDTO selectTransWatch(TransWatchFilter params);

    /**
     * 주식 감시 건수 조회
     * @Method selectTransWatchCnt
     * @param TransWatchFilter
     * @return 건수
     */	
    int selectTransWatchCnt(TransWatchFilter params);
    
    /**
     * 주식 감시 다건 조회
     * @Method selectTransWatchList
     * @param TransWatchFilter 
     * @return 조회 목록
     */	
	public List<TransWatchDTO> selectTransWatchList(TransWatchFilter params);
}
