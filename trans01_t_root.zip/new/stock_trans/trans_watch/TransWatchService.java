package com.osstem.ows.biz.sal.sales.service;

import java.util.List;
import com.osstem.ows.biz.sal.sales.model.dto.TransWatchDTO;
import com.osstem.ows.biz.sal.sales.model.filter.TransWatchFilter;

/**
 * 주식 감시 서비스
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.		system				최초작성
 * </pre>
 */
public interface TransWatchService {

	/**
	 * 주식 감시 등록, 수정
     * @Method mergeTransWatch
	 * @param TransWatchFilter
	 */
    public Boolean mergeTransWatch(TransWatchFilter params);	
    
	/**
	 * 주식 감시 여러 건 등록
     * @Method bulkInsertTransWatch
	 * @param TransWatchFilter
	 */
    public Boolean bulkInsertTransWatch(TransWatchFilter params);	    
	
	/**
	 * 주식 감시 등록
     * @Method insertTransWatch
	 * @param TransWatchFilter
	 */
    public Boolean insertTransWatch(TransWatchFilter params);

    /**
     * 주식 감시 수정
     * @Method updateTransWatch
     * @param transWatchFilter
     */
    public Boolean updateTransWatch(TransWatchFilter params);

    /**
     * 주식 감시 삭제
     * @Method deleteTransWatch
     * @param transWatchFilter
     */
    public Boolean deleteTransWatch(TransWatchFilter params);
    
    /**
     * 주식 감시 단건 조회
     * @Method selectTransWatch 
     * @param  transWatchFilter
     */
    public TransWatchDTO selectTransWatch(TransWatchFilter params);    
    
    /**
     * 주식 감시 건수 조회
     * @Method selectTransWatchCnt
     * @param  transWatchFilter
     */
    public int selectTransWatchCnt(TransWatchFilter params);
    
    /**
     * 주식 감시 다건 조회
     * @Method selectTransWatchList
     * @param  transWatchFilter
     */
    public List<TransWatchDTO> selectTransWatchList(TransWatchFilter params);

}
