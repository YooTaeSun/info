/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class GraphqlTransWatchService {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async addTransWatch(params) {

    params = {
             watchId: ''    // watch_id
            ,userId: ''    // user_id
            ,watchPid: ''    // 부모 watch_id
            ,reptId: ''    // 키움접수 rept_id, 키움체결 rept_id
            ,접수상태: ''    // 접수상태
            ,등록출처: ''    // 등록출처
            ,등록출처Nm: ''    // 등록출처
            ,투자금액1회: ''    // 투자금액1회
            ,손절률: ''    // 손절률
            ,전략: ''    // 전략
            ,시장구분: ''    // 시장구분
            ,종목코드: ''    // 종목코드
            ,종목명: ''    // 종목명
            ,watchKind: ''    // callNm
            ,평균체결가: ''    // 평균체결가
            ,quantity: ''    // quantity
            ,delYn: ''    // 삭제여부
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation addTransWatch($input: TransWatchFilter) {
      one : addTransWatch(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modifyTransWatch(params) {

    let query = `mutation modifyTransWatch($input: TransWatchFilter) {
      one : modifyTransWatch(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async removeTransWatch(params) {

    params = {
    }

    let query = `mutation removeTransWatch($input: TransWatchFilter) {
      one : removeTransWatch(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async getTransWatch(params) {

    params = {

    }

    let query = `
    query ($params:TransWatchFilter) {
      one: getTransWatch(filter:$params) {
			watchId
			userId
			watchPid
			reptId
			접수상태
			등록출처
			등록출처Nm
			투자금액1회
			손절률
			전략
			시장구분
			종목코드
			종목명
			watchKind
			평균체결가
			quantity
			delYn
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async getTransWatchList(params) {

    params = {

    }

    let query = `
    query ($params:TransWatchFilter) {
      cnt: getTransWatchCnt(filter:$params)   
      list: getTransWatchList(filter:$params) {
			watchId
			userId
			watchPid
			reptId
			접수상태
			등록출처
			등록출처Nm
			투자금액1회
			손절률
			전략
			시장구분
			종목코드
			종목명
			watchKind
			평균체결가
			quantity
			delYn
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new GraphqlTransWatchService();
