package com.osstem.ows.biz.sal.sales.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import com.osstem.ows.biz.sal.sales.model.filter.TransWatchFilter;
import com.osstem.ows.biz.sal.sales.service.TransWatchService;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * 주식 감시 GraphQL Mutation
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.		system				최초작성
 * </pre>
 */
@Component
public class TransWatchMutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(TransWatchMutation.class);
	
	@Autowired
	private TransWatchService transWatchService;
	
	/**
	 * 주식 감시 등록
     * @Method addTransWatch
	 * @param TransWatchFilter
	 */
    public Boolean addTransWatch(TransWatchFilter params) {
    	try {
    		return transWatchService.insertTransWatch(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * 주식 감시 수정
     * @Method modifyTransWatch
	 * @param TransWatchFilter
	 */
	public Boolean modifyTransWatch(TransWatchFilter params) {
		try {
			return transWatchService.updateTransWatch(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * 주식 감시 삭제
     * @Method removeTransWatch
	 * @param TransWatchFilter
	 */
	public Boolean removeTransWatch(TransWatchFilter params) {
		try {
			return transWatchService.deleteTransWatch(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
