package com.osstem.ows.biz.sal.sales.model.dto;
import java.util.Date;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class TransWatchDTO {

	/**
	 * watch_id(PK)
	 */
	@ApiModelProperty(value = "watchId: watch_id")
	private String watchId;

	/**
	 * user_id(PK)
	 */
	@ApiModelProperty(value = "userId: user_id")
	private String userId;

	/**
	 * 부모 watch_id
	 */
	@ApiModelProperty(value = "watchPid: 부모 watch_id")
	private String watchPid;

	/**
	 * 키움접수 rept_id, 키움체결 rept_id
	 */
	@ApiModelProperty(value = "reptId: 키움접수 rept_id, 키움체결 rept_id")
	private String reptId;

	/**
	 * 접수상태
	 */
	@ApiModelProperty(value = "접수상태: 접수상태")
	private String 접수상태;

	/**
	 * 등록출처
	 */
	@ApiModelProperty(value = "등록출처: 등록출처")
	private String 등록출처;

	/**
	 * 등록출처
	 */
	@ApiModelProperty(value = "등록출처Nm: 등록출처")
	private String 등록출처Nm;

	/**
	 * 투자금액1회
	 */
	@ApiModelProperty(value = "투자금액1회: 투자금액1회")
	private Integer 투자금액1회;

	/**
	 * 손절률
	 */
	@ApiModelProperty(value = "손절률: 손절률")
	private Float 손절률;

	/**
	 * 전략
	 */
	@ApiModelProperty(value = "전략: 전략")
	private String 전략;

	/**
	 * 시장구분
	 */
	@ApiModelProperty(value = "시장구분: 시장구분")
	private String 시장구분;

	/**
	 * 종목코드
	 */
	@ApiModelProperty(value = "종목코드: 종목코드")
	private String 종목코드;

	/**
	 * 종목명
	 */
	@ApiModelProperty(value = "종목명: 종목명")
	private String 종목명;

	/**
	 * callNm
	 */
	@ApiModelProperty(value = "watchKind: callNm")
	private String watchKind;

	/**
	 * 평균체결가
	 */
	@ApiModelProperty(value = "평균체결가: 평균체결가")
	private Integer 평균체결가;

	/**
	 * quantity
	 */
	@ApiModelProperty(value = "quantity: quantity")
	private Integer quantity;

	/**
	 * 삭제여부
	 */
	@ApiModelProperty(value = "delYn: 삭제여부")
	private String delYn;

	/**
	 * 입력날짜
	 */
	@ApiModelProperty(value = "insertDate: 입력날짜")
	private Date insertDate;

	/**
	 * 수정날짜
	 */
	@ApiModelProperty(value = "updateDate: 수정날짜")
	private Date updateDate;


}
