/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class Graphql실현손익Service {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async add실현손익(params) {

    params = {
             일자: ''    // 일자
            ,실현종류: ''    // 실현종류
            ,userId: ''    // user_id
            ,buyWatchId: ''    // buy_watch_id
            ,종목코드: ''    // 종목코드
            ,종목명: ''    // 종목명
            ,시장구분: ''    // 시장구분
            ,전략: ''    // 전략
            ,수익률: ''    // 수익률(%)
            ,수익금액: ''    // 수익금액
            ,체결량: ''    // 체결량
            ,매도체결금액: ''    // 매도체결금액
            ,매수체결금액: ''    // 매수체결금액
            ,체결금액: ''    // 체결금액
            ,당일매매수수료: ''    // 당일매매수수료
            ,당일매매세금: ''    // 당일매매세금
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation add실현손익($input: 실현손익Filter) {
      one : add실현손익(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modify실현손익(params) {

    let query = `mutation modify실현손익($input: 실현손익Filter) {
      one : modify실현손익(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async remove실현손익(params) {

    params = {
    }

    let query = `mutation remove실현손익($input: 실현손익Filter) {
      one : remove실현손익(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async get실현손익(params) {

    params = {

    }

    let query = `
    query ($params:실현손익Filter) {
      one: get실현손익(filter:$params) {
			일자
			실현종류
			userId
			buyWatchId
			종목코드
			종목명
			시장구분
			전략
			수익률
			수익금액
			체결량
			매도체결금액
			매수체결금액
			체결금액
			당일매매수수료
			당일매매세금
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async get실현손익List(params) {

    params = {

    }

    let query = `
    query ($params:실현손익Filter) {
      cnt: get실현손익Cnt(filter:$params)   
      list: get실현손익List(filter:$params) {
			일자
			실현종류
			userId
			buyWatchId
			종목코드
			종목명
			시장구분
			전략
			수익률
			수익금액
			체결량
			매도체결금액
			매수체결금액
			체결금액
			당일매매수수료
			당일매매세금
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new Graphql실현손익Service();
