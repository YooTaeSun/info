package com.osstem.ows.biz.sal.sales.service.dao;

import java.util.List;

import com.osstem.ows.biz.cfg.datasource.OwsMapper;
import com.osstem.ows.biz.sal.sales.model.dto.실현손익DTO;
import com.osstem.ows.biz.sal.sales.model.filter.실현손익Filter;

/**
 * 실현손익 DAO
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.03.10.		system				최초작성
 * </pre>
 */
@OwsMapper
public interface 실현손익DAO {

	/**
     * 실현손익 등록, 수정
     * @Method merge실현손익
     * @param 실현손익Filter
     * @return 등록 또는 수정된 건수
     */	
	public int merge실현손익(실현손익Filter params);
	
	/**
	 * 실현손익 여러 건 등록
	 * @Method bulkInsert실현손익
	 * @param 실현손익Filter
	 * @return 여러 건 등록된 건수
	 */	
	public int bulkInsert실현손익(실현손익Filter params);
	
	/**
	 * 실현손익 등록
	 * @Method insert실현손익
	 * @param 실현손익Filter
	 * @return 등록된 건수
	 */	
	public int insert실현손익(실현손익Filter params);
	
    /**
     * 실현손익 수정
     * @Method update실현손익
     * @param 실현손익Filter
     * @return 수정된 건수
     */	
	public int update실현손익(실현손익Filter params);
	
    /**
     * 실현손익 삭제 
     * @Method delete실현손익
     * @param 실현손익Filter
     * @return 삭제된 건수
     */	
	public int delete실현손익(실현손익Filter params);
 
    /**
     * 실현손익 단건 조회
     *
     * @param 실현손익Filter
     * @return 조회 건
     */	    
	public 실현손익DTO select실현손익(실현손익Filter params);

    /**
     * 실현손익 건수 조회
     * @Method select실현손익Cnt
     * @param 실현손익Filter
     * @return 건수
     */	
    int select실현손익Cnt(실현손익Filter params);
    
    /**
     * 실현손익 다건 조회
     * @Method select실현손익List
     * @param 실현손익Filter 
     * @return 조회 목록
     */	
	public List<실현손익DTO> select실현손익List(실현손익Filter params);
}
