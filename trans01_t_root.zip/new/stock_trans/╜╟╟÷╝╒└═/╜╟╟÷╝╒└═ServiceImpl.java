package com.osstem.ows.biz.sal.sales.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import com.osstem.ows.biz.sal.sales.model.dto.실현손익DTO;
import com.osstem.ows.biz.sal.sales.model.filter.실현손익Filter;
import com.osstem.ows.biz.sal.sales.service.실현손익Service;
import com.osstem.ows.biz.sal.sales.service.dao.실현손익DAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 * 실현손익 ServiceImpl
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.03.10.		system				최초작성
 * </pre>
 */
@Service("실현손익Service")
public class 실현손익ServiceImpl implements 실현손익Service {

	private static final Logger logger = LoggerFactory.getLogger(실현손익ServiceImpl.class);
	
	@Autowired
    private 실현손익DAO 실현손익DAO;
    
	/**
	 * 실현손익 등록, 수정
     * @Method merge실현손익
	 * @param 실현손익Filter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean merge실현손익(실현손익Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = 실현손익DAO.merge실현손익(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     * 실현손익 여러 건 등록
     * @Method bulkInsert실현손익
     * @param 실현손익Filter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsert실현손익(실현손익Filter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = 실현손익DAO.bulkInsert실현손익(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 * 실현손익 등록
     * @Method insert실현손익
	 * @param 실현손익Filter
     * @return 등록 여부
	 */
    @Override
    public Boolean insert실현손익(실현손익Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = 실현손익DAO.insert실현손익(params);
        return (result > 0)? true:false;    	
    }

    /**
     * 실현손익 수정
     * @Method update실현손익 
     * @param 실현손익Filter
     * @Method update실현손익
     * @return 수정 여부
     */
    @Override
    public Boolean update실현손익(실현손익Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = 실현손익DAO.update실현손익(params);
        return (result > 0)? true:false;        
    }

    /**
     * 실현손익 삭제
     * @Method delete실현손익
     * @param 실현손익Filter
     * @return 삭제 여부 
     */
    @Override
    public Boolean delete실현손익(실현손익Filter params){
        int result = 실현손익DAO.delete실현손익(params);
        return (result > 0)? true:false;
    }
    
    /**
     * 실현손익 단건 조회
     * @Method select실현손익
     * @param  실현손익Filter
     * @return 조회 건
     */
    @Override
    public 실현손익DTO select실현손익(실현손익Filter params){
        return 실현손익DAO.select실현손익(params);
    }
    
    /**
     * 실현손익 건수 조회
     * @Method select실현손익Cnt
     * @param  실현손익Filter
     * @return 건수
     */
    @Override
    public int select실현손익Cnt(실현손익Filter params){
        return 실현손익DAO.select실현손익Cnt(params);
    }

    /**
     * 실현손익 다건 조회
     * @Method select실현손익List
     * @param  실현손익Filter
     * @return 조회 목록
     */
    @Override
    public List<실현손익DTO> select실현손익List(실현손익Filter params){
        return 실현손익DAO.select실현손익List(params);
    }
}
