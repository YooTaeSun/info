package com.osstem.ows.biz.sal.sales.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import com.osstem.ows.biz.sal.sales.model.filter.실현손익Filter;
import com.osstem.ows.biz.sal.sales.service.실현손익Service;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * 실현손익 GraphQL Mutation
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.03.10.		system				최초작성
 * </pre>
 */
@Component
public class 실현손익Mutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(실현손익Mutation.class);
	
	@Autowired
	private 실현손익Service 실현손익Service;
	
	/**
	 * 실현손익 등록
     * @Method add실현손익
	 * @param 실현손익Filter
	 */
    public Boolean add실현손익(실현손익Filter params) {
    	try {
    		return 실현손익Service.insert실현손익(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * 실현손익 수정
     * @Method modify실현손익
	 * @param 실현손익Filter
	 */
	public Boolean modify실현손익(실현손익Filter params) {
		try {
			return 실현손익Service.update실현손익(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * 실현손익 삭제
     * @Method remove실현손익
	 * @param 실현손익Filter
	 */
	public Boolean remove실현손익(실현손익Filter params) {
		try {
			return 실현손익Service.delete실현손익(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
