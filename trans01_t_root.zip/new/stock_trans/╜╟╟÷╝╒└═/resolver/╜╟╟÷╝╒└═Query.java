package com.osstem.ows.biz.sal.sales.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.sal.sales.model.dto.실현손익DTO;
import com.osstem.ows.biz.sal.sales.model.filter.실현손익Filter;
import com.osstem.ows.biz.sal.sales.service.실현손익Service;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * 실현손익 GraphQL Query
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.03.10.		system				최초작성
 * </pre>
 */
@Component
public class 실현손익Query implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(실현손익Mutation.class);
	
	@Autowired
	private 실현손익Service 실현손익Service;

    /**
     * 실현손익 단건 조회
     * @Method get실현손익
     * @param  실현손익Filter
     * @return 조회 건
     */
    public 실현손익DTO get실현손익(실현손익Filter params) {
    	params = Optional.ofNullable(params).orElseGet(실현손익Filter::new);
    	return 실현손익Service.select실현손익(params);
    }
    
    /**
     * 실현손익 건수 조회
     * @Method get실현손익Cnt
     * @param  실현손익Filter
     * @return 건수
     */
    public int get실현손익Cnt(실현손익Filter params){
    	params = Optional.ofNullable(params).orElseGet(실현손익Filter::new);
    	return 실현손익Service.select실현손익Cnt(params);
    }

    /**
     * 실현손익 다건 조회
     * @Method get실현손익List
     * @param  실현손익Filter
     * @return 조회 목록
     */
    public List<실현손익DTO> get실현손익List(실현손익Filter params) {
    	params = Optional.ofNullable(params).orElseGet(실현손익Filter::new);
    	return 실현손익Service.select실현손익List(params);
    }
}
