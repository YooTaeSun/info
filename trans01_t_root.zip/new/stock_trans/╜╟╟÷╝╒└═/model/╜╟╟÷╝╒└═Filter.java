package com.osstem.ows.biz.sal.sales.model.filter;

import com.osstem.ows.biz.cmm.model.filter.PageFilter;
import com.osstem.ows.biz.sal.sales.model.dto.실현손익DTO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class 실현손익Filter extends 실현손익DTO {
	
	/**
	 * pageFilter 객체
	 */
	@ApiModelProperty(value = "pageFilter: pageFilter 객체")
	private PageFilter pageFilter;
}
