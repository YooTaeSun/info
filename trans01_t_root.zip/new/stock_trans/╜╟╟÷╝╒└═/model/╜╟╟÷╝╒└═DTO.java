package com.osstem.ows.biz.sal.sales.model.dto;
import java.util.Date;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class 실현손익DTO {

	/**
	 * 일자(PK)
	 */
	@ApiModelProperty(value = "일자: 일자")
	private String 일자;

	/**
	 * 실현종류(PK)
	 */
	@ApiModelProperty(value = "실현종류: 실현종류")
	private String 실현종류;

	/**
	 * user_id(PK)
	 */
	@ApiModelProperty(value = "userId: user_id")
	private String userId;

	/**
	 * buy_watch_id(PK)
	 */
	@ApiModelProperty(value = "buyWatchId: buy_watch_id")
	private String buyWatchId;

	/**
	 * 종목코드(PK)
	 */
	@ApiModelProperty(value = "종목코드: 종목코드")
	private String 종목코드;

	/**
	 * 종목명
	 */
	@ApiModelProperty(value = "종목명: 종목명")
	private String 종목명;

	/**
	 * 시장구분
	 */
	@ApiModelProperty(value = "시장구분: 시장구분")
	private String 시장구분;

	/**
	 * 전략
	 */
	@ApiModelProperty(value = "전략: 전략")
	private String 전략;

	/**
	 * 수익률(%)
	 */
	@ApiModelProperty(value = "수익률: 수익률(%)")
	private Float 수익률;

	/**
	 * 수익금액
	 */
	@ApiModelProperty(value = "수익금액: 수익금액")
	private Float 수익금액;

	/**
	 * 체결량
	 */
	@ApiModelProperty(value = "체결량: 체결량")
	private Integer 체결량;

	/**
	 * 매도체결금액
	 */
	@ApiModelProperty(value = "매도체결금액: 매도체결금액")
	private Float 매도체결금액;

	/**
	 * 매수체결금액
	 */
	@ApiModelProperty(value = "매수체결금액: 매수체결금액")
	private Float 매수체결금액;

	/**
	 * 체결금액
	 */
	@ApiModelProperty(value = "체결금액: 체결금액")
	private Float 체결금액;

	/**
	 * 당일매매수수료
	 */
	@ApiModelProperty(value = "당일매매수수료: 당일매매수수료")
	private Float 당일매매수수료;

	/**
	 * 당일매매세금
	 */
	@ApiModelProperty(value = "당일매매세금: 당일매매세금")
	private Float 당일매매세금;

	/**
	 * 입력날짜
	 */
	@ApiModelProperty(value = "insertDate: 입력날짜")
	private Date insertDate;

	/**
	 * 수정날짜
	 */
	@ApiModelProperty(value = "updateDate: 수정날짜")
	private Date updateDate;


}
