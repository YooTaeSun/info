package com.osstem.ows.biz.sal.sales.service;

import java.util.List;
import com.osstem.ows.biz.sal.sales.model.dto.실현손익DTO;
import com.osstem.ows.biz.sal.sales.model.filter.실현손익Filter;

/**
 * 실현손익 서비스
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.03.10.		system				최초작성
 * </pre>
 */
public interface 실현손익Service {

	/**
	 * 실현손익 등록, 수정
     * @Method merge실현손익
	 * @param 실현손익Filter
	 */
    public Boolean merge실현손익(실현손익Filter params);	
    
	/**
	 * 실현손익 여러 건 등록
     * @Method bulkInsert실현손익
	 * @param 실현손익Filter
	 */
    public Boolean bulkInsert실현손익(실현손익Filter params);	    
	
	/**
	 * 실현손익 등록
     * @Method insert실현손익
	 * @param 실현손익Filter
	 */
    public Boolean insert실현손익(실현손익Filter params);

    /**
     * 실현손익 수정
     * @Method update실현손익
     * @param 실현손익Filter
     */
    public Boolean update실현손익(실현손익Filter params);

    /**
     * 실현손익 삭제
     * @Method delete실현손익
     * @param 실현손익Filter
     */
    public Boolean delete실현손익(실현손익Filter params);
    
    /**
     * 실현손익 단건 조회
     * @Method select실현손익 
     * @param  실현손익Filter
     */
    public 실현손익DTO select실현손익(실현손익Filter params);    
    
    /**
     * 실현손익 건수 조회
     * @Method select실현손익Cnt
     * @param  실현손익Filter
     */
    public int select실현손익Cnt(실현손익Filter params);
    
    /**
     * 실현손익 다건 조회
     * @Method select실현손익List
     * @param  실현손익Filter
     */
    public List<실현손익DTO> select실현손익List(실현손익Filter params);

}
