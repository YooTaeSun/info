package com.osstem.ows.biz.sal.sales.service.repo.pred;

import org.apache.commons.lang3.StringUtils;

import com.osstem.ows.biz.sal.sales.model.entity.Q;
import com.osstem.ows.biz.sal.sales.model.filter.Filter;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.Predicate;

/**
 * 달력 JPA Pred
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.						최초작성
 * </pre>
 */
public class Pred {

	public static Predicate where(Filter params) {
 
		Q q = Q.;

		BooleanBuilder builder = new BooleanBuilder();
		
         /* id */
        if(StringUtils.isNotEmpty(params.getId())) {
            builder.and(q.id.eq(params.getId()));
        }

         /* 국가 */
        if(StringUtils.isNotEmpty(params.getNation())) {
            builder.and(q.nation.eq(params.getNation()));
        }

         /* 년도 */
        if(params.getYear() != null ) {
            builder.and(q.year.eq(params.getYear()));
        }

         /* 달 */
        if(params.getMonth() != null ) {
            builder.and(q.month.eq(params.getMonth()));
        }

         /* 일 */
        if(params.getDay() != null ) {
            builder.and(q.day.eq(params.getDay()));
        }

         /* 분기 */
        if(params.getQuarter() != null ) {
            builder.and(q.quarter.eq(params.getQuarter()));
        }

         /* 주 */
        if(params.getWeek() != null ) {
            builder.and(q.week.eq(params.getWeek()));
        }

         /* 요일 */
        if(StringUtils.isNotEmpty(params.getDayName())) {
            builder.and(q.dayName.eq(params.getDayName()));
        }

         /* 월이름 */
        if(StringUtils.isNotEmpty(params.getMonthName())) {
            builder.and(q.monthName.eq(params.getMonthName()));
        }

         /* 영업일유무 */
        if(StringUtils.isNotEmpty(params.getOperatingFlag())) {
            builder.and(q.operatingFlag.eq(params.getOperatingFlag()));
        }

         /* 주말유무 */
        if(StringUtils.isNotEmpty(params.getHolidayFlag())) {
            builder.and(q.holidayFlag.eq(params.getHolidayFlag()));
        }

         /* 주말유무2 */
        if(StringUtils.isNotEmpty(params.getWeekendFlag())) {
            builder.and(q.weekendFlag.eq(params.getWeekendFlag()));
        }

         /* 특별일 */
        if(StringUtils.isNotEmpty(params.getEvent())) {
            builder.and(q.event.eq(params.getEvent()));
        }

         /* 거래일 */
        if(StringUtils.isNotEmpty(params.getTradeHistory())) {
            builder.and(q.tradeHistory.eq(params.getTradeHistory()));
        }


		return builder;
	}
}
