package com.osstem.ows.biz.sal.sales.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import com.osstem.ows.biz.sal.sales.model.filter.Filter;
import com.osstem.ows.biz.sal.sales.service.CalendarService;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * 달력 GraphQL Mutation
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.						최초작성
 * </pre>
 */
@Component
public class CalendarMutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(CalendarMutation.class);
	
	@Autowired
	private CalendarService calendarService;
	
	/**
	 * 달력 등록
     * @Method addCalendar
	 * @param Filter
	 */
    public Boolean addCalendar(Filter params) {
    	try {
    		return calendarService.insertCalendar(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * 달력 수정
     * @Method modifyCalendar
	 * @param Filter
	 */
	public Boolean modifyCalendar(Filter params) {
		try {
			return calendarService.updateCalendar(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * 달력 삭제
     * @Method removeCalendar
	 * @param Filter
	 */
	public Boolean removeCalendar(Filter params) {
		try {
			return calendarService.deleteCalendar(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
