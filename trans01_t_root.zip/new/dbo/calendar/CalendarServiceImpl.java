package com.osstem.ows.biz.sal.sales.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.osstem.ows.biz.sal.sales.model.Mapper;
import com.osstem.ows.biz.sal.sales.model.dto.DTO;
import com.osstem.ows.biz.sal.sales.model.entity.Q;
import com.osstem.ows.biz.sal.sales.model.entity.;
import com.osstem.ows.biz.sal.sales.model.filter.Filter;
import com.osstem.ows.biz.sal.sales.service.CalendarService;
import com.osstem.ows.biz.sal.sales.service.repo.Repo;
import com.osstem.ows.biz.sal.sales.service.repo.pred.Pred;
import com.querydsl.core.types.Projections;
import com.querydsl.jpa.impl.JPAQueryFactory;

/**
 * 달력 ServiceImpl
 *
 * @author		 
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.						최초작성
 * </pre>
 */
@Service
public class CalendarServiceImpl implements CalendarService {

	private static final Logger logger = LoggerFactory.getLogger(CalendarServiceImpl.class);

	@Autowired
	@Qualifier("jpaQueryFactory")
	private JPAQueryFactory queryFactory;

	@Autowired
	private Repo Repo;

	@Autowired
	private Mapper Mapper;

	/**
	 * 달력 등록
     * @Method insertCalendar
	 * @param Filter
     * @return 등록 건
	 */	
	@Override
	@Transactional
	public Boolean insertCalendar(Filter params) {

    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);		
		
		  = Mapper.toEntity(params);
		Repo.save();
		
		return true;
	}

    /**
     * 달력 수정
     * @Method updateCalendar 
     * @param Filter
     * @Method updateCalendar
     * @return 수정 건
     */
	@Override
	@Transactional
	public Boolean updateCalendar(Filter params) {

		if(StringUtils.isEmpty(params.getId())) ||StringUtils.isEmpty(params.getNation()))) {
			throw new RuntimeException("no pk");
		}
		
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);

		List<> list = Repo.findByNation(params.getNation());
		 update = null;
		if(ObjectUtils.isNotEmpty(list) && list.size() == 1) {

			update = list.get(0);

			 /* id */
			if(StringUtils.isNotEmpty(params.getId())) {
				update.setId(params.getId());
			}
			 /* 국가 */
			if(StringUtils.isNotEmpty(params.getNation())) {
				update.setNation(params.getNation());
			}
			 /* 년도 */
			if(params.getYear() != null ) {
				update.setYear(params.getYear());
			}
			 /* 달 */
			if(params.getMonth() != null ) {
				update.setMonth(params.getMonth());
			}
			 /* 일 */
			if(params.getDay() != null ) {
				update.setDay(params.getDay());
			}
			 /* 분기 */
			if(params.getQuarter() != null ) {
				update.setQuarter(params.getQuarter());
			}
			 /* 주 */
			if(params.getWeek() != null ) {
				update.setWeek(params.getWeek());
			}
			 /* 요일 */
			if(StringUtils.isNotEmpty(params.getDayName())) {
				update.setDayName(params.getDayName());
			}
			 /* 월이름 */
			if(StringUtils.isNotEmpty(params.getMonthName())) {
				update.setMonthName(params.getMonthName());
			}
			 /* 영업일유무 */
			if(StringUtils.isNotEmpty(params.getOperatingFlag())) {
				update.setOperatingFlag(params.getOperatingFlag());
			}
			 /* 주말유무 */
			if(StringUtils.isNotEmpty(params.getHolidayFlag())) {
				update.setHolidayFlag(params.getHolidayFlag());
			}
			 /* 주말유무2 */
			if(StringUtils.isNotEmpty(params.getWeekendFlag())) {
				update.setWeekendFlag(params.getWeekendFlag());
			}
			 /* 특별일 */
			if(StringUtils.isNotEmpty(params.getEvent())) {
				update.setEvent(params.getEvent());
			}
			 /* 거래일 */
			if(StringUtils.isNotEmpty(params.getTradeHistory())) {
				update.setTradeHistory(params.getTradeHistory());
			}

			Repo.save(update);
		}
		return (update != null)? true:false;
	}

    /**
     * 달력 삭제
     * @Method deleteCalendar
     * @param Filter
     * @return 삭제 건 
     */
	@Override
	@Transactional
	public Boolean deleteCalendar(Filter params) {

		if(StringUtils.isEmpty(params.getId())) ||StringUtils.isEmpty(params.getNation()))) {
			throw new RuntimeException("no pk");
		}

		  = Mapper.toEntity(params);
		//Erase only with pk.
		List<> list = Repo.deleteByNation(params.getNation());
		return ObjectUtils.isNotEmpty(list)? true:false;
	}

    /**
     * 달력 단건 조회
     * @Method selectCalendar
     * @param  Filter
     * @return 조회 건
     */
	@Override
    public DTO selectCalendar(Filter params) {

    	var q = Q.;
    	DTO one= queryFactory
    			.select(
	    			Projections.fields(DTO.class
						,q.id			/* id */
						,q.nation			/* 국가 */
						,q.year			/* 년도 */
						,q.month			/* 달 */
						,q.day			/* 일 */
						,q.quarter			/* 분기 */
						,q.week			/* 주 */
						,q.dayName			/* 요일 */
						,q.monthName			/* 월이름 */
						,q.operatingFlag			/* 영업일유무 */
						,q.holidayFlag			/* 주말유무 */
						,q.weekendFlag			/* 주말유무2 */
						,q.event			/* 특별일 */
						,q.tradeHistory			/* 거래일 */

	    			))
    			.from(q)
    			.where(Pred.where(params))
    			.fetchOne();

        return one;
    }

    /**
     * 달력 건수 조회
     * @Method selectCalendarCnt
     * @param  Filter
     * @return 건수
     */
    @Override
    public int selectCalendarCnt(Filter params){
    	return -1;
    }	
	
    /**
     * 달력 다건 조회
     * @Method selectCalendarList
     * @param  Filter
     * @return 조회 목록
     */
    @Override
	public List<DTO> selectCalendarList(Filter params) {

    	var q = Q.;
    	List<DTO> list= queryFactory
    			.select(
	    			Projections.fields(DTO.class
						,q.id			/* id */
						,q.nation			/* 국가 */
						,q.year			/* 년도 */
						,q.month			/* 달 */
						,q.day			/* 일 */
						,q.quarter			/* 분기 */
						,q.week			/* 주 */
						,q.dayName			/* 요일 */
						,q.monthName			/* 월이름 */
						,q.operatingFlag			/* 영업일유무 */
						,q.holidayFlag			/* 주말유무 */
						,q.weekendFlag			/* 주말유무2 */
						,q.event			/* 특별일 */
						,q.tradeHistory			/* 거래일 */

	    			))
    			.from(q)
    			.where(Pred.where(params))
    			.fetch();

        return list;
	}

    /**
     * 달력 다건 조회
     * @Method selectCalendar2
     * @param  Filter
     * @return 조회 건
     */    
	@Deprecated
	public DTO selectCalendar2(Filter params) {

		List<> list = Repo.findByNation(params.getNation());
		DTO DTO = null;

		if(ObjectUtils.isNotEmpty(list) && list.size() == 1) {
			DTO = Mapper.toDto(list.get(0));
		}
		return DTO;
	}

    /**
     * 달력 다건 조회
     * @Method selectCalendarList2
     * @param  Filter
     * @return 조회 목록
     */	
	@Deprecated
	public List<DTO> selectCalendarList2(Filter params) {
		List<> list = Repo.findAll();
		List<DTO> listDto = list.stream().map(Mapper::toDto).collect(Collectors.toList());
		return listDto;
	}

}
