package com.osstem.ows.biz.sal.sales.service;

import java.util.List;

import com.osstem.ows.biz.sal.sales.model.dto.DTO;
import com.osstem.ows.biz.sal.sales.model.filter.Filter;

/**
 * 달력 Service
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.						최초작성
 * </pre>
 */
public interface CalendarService {

	/**
	 * 달력 등록
     * @Method insertCalendar
	 * @param Filter
	 */
	public Boolean insertCalendar(Filter params);

	/**
	 * 달력 수정
     * @Method insertCalendar
	 * @param Filter
	 */
	public Boolean updateCalendar(Filter params);

	/**
	 * 달력 삭제
     * @Method insertCalendar
	 * @param Filter
	 */	
	public Boolean deleteCalendar(Filter params);

    /**
     * 달력 단건 조회
     * @Method selectCalendar
     * @param  Filter
     * @return 조회 건
     */
	public DTO selectCalendar(Filter params);
	
    /**
     * 달력 건수 조회
     * @Method selectCalendarCnt
     * @param  Filter
     */
    public int selectCalendarCnt(Filter params);
    
    /**
     * 달력 다건 조회
     * @Method selectCalendarList
     * @param  Filter
     * @return 조회 목록
     */	
	public List<DTO> selectCalendarList(Filter params);

}
