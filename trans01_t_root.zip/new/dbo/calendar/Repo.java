package com.osstem.ows.biz.sal.sales.service.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.osstem.ows.biz.sal.sales.model.entity.;

/**
 * 달력 JPA Repo
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.						최초작성
 * </pre>
 */
@Repository
public interface Repo extends JpaRepository<, String> {
	
    /* id */
    List<> findById(String id);
    /* 국가 */
    List<> findByNation(String nation);
    /* 년도 */
    List<> findByYear(Integer year);
    /* 달 */
    List<> findByMonth(Integer month);
    /* 일 */
    List<> findByDay(Integer day);
    /* 분기 */
    List<> findByQuarter(Integer quarter);
    /* 주 */
    List<> findByWeek(Integer week);
    /* 요일 */
    List<> findByDayName(String dayName);
    /* 월이름 */
    List<> findByMonthName(String monthName);
    /* 영업일유무 */
    List<> findByOperatingFlag(String operatingFlag);
    /* 주말유무 */
    List<> findByHolidayFlag(String holidayFlag);
    /* 주말유무2 */
    List<> findByWeekendFlag(String weekendFlag);
    /* 특별일 */
    List<> findByEvent(String event);
    /* 거래일 */
    List<> findByTradeHistory(String tradeHistory);


    /* id */
    List<> deleteById(String id);


}
