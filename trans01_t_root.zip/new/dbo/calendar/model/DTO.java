package com.osstem.ows.biz.sal.sales.model.dto;
import java.util.Date;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DTO {

	/**
	 * id(PK)
	 */
	@ApiModelProperty(value = "id: id")
	private String id;

	/**
	 * 국가(PK)
	 */
	@ApiModelProperty(value = "nation: 국가")
	private String nation;

	/**
	 * 년도
	 */
	@ApiModelProperty(value = "year: 년도")
	private Integer year;

	/**
	 * 달
	 */
	@ApiModelProperty(value = "month: 달")
	private Integer month;

	/**
	 * 일
	 */
	@ApiModelProperty(value = "day: 일")
	private Integer day;

	/**
	 * 분기
	 */
	@ApiModelProperty(value = "quarter: 분기")
	private Integer quarter;

	/**
	 * 주
	 */
	@ApiModelProperty(value = "week: 주")
	private Integer week;

	/**
	 * 요일
	 */
	@ApiModelProperty(value = "dayName: 요일")
	private String dayName;

	/**
	 * 월이름
	 */
	@ApiModelProperty(value = "monthName: 월이름")
	private String monthName;

	/**
	 * 영업일유무
	 */
	@ApiModelProperty(value = "operatingFlag: 영업일유무")
	private String operatingFlag;

	/**
	 * 주말유무
	 */
	@ApiModelProperty(value = "holidayFlag: 주말유무")
	private String holidayFlag;

	/**
	 * 주말유무2
	 */
	@ApiModelProperty(value = "weekendFlag: 주말유무2")
	private String weekendFlag;

	/**
	 * 특별일
	 */
	@ApiModelProperty(value = "event: 특별일")
	private String event;

	/**
	 * 거래일
	 */
	@ApiModelProperty(value = "tradeHistory: 거래일")
	private String tradeHistory;


}
