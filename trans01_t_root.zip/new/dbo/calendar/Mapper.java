package com.osstem.ows.biz.sal.sales.model;

import org.mapstruct.Mapper;

import com.osstem.ows.biz.sal.sales.model.dto.DTO;
import com.osstem.ows.biz.sal.sales.model.entity.;
import com.osstem.ows.cor.model.mapper.EntityMapper;

/**
 * 달력 JPA Mapper
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.						최초작성
 * </pre>
 */
@Mapper(componentModel = "spring")
public interface Mapper extends EntityMapper<DTO, > {

    /**
     * DTO를 Entity 변경
     * @Method toEntity
     * @param DTO
     */
	 toEntity(DTO dto);

    /**
     * Entity를  DTO변경
     * @Method toDto
     * @param 
     */
	DTO toDto( entity);
}
