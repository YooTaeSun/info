/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class GraphqlCalendarService {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async addCalendar(params) {

    params = {
             id: ''    // id
            ,nation: ''    // 국가
            ,year: ''    // 년도
            ,month: ''    // 달
            ,day: ''    // 일
            ,quarter: ''    // 분기
            ,week: ''    // 주
            ,dayName: ''    // 요일
            ,monthName: ''    // 월이름
            ,operatingFlag: ''    // 영업일유무
            ,holidayFlag: ''    // 주말유무
            ,weekendFlag: ''    // 주말유무2
            ,event: ''    // 특별일
            ,tradeHistory: ''    // 거래일

    }

    let query = `mutation addCalendar($input: Filter) {
      one : addCalendar(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modifyCalendar(params) {

    let query = `mutation modifyCalendar($input: Filter) {
      one : modifyCalendar(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async removeCalendar(params) {

    params = {
    }

    let query = `mutation removeCalendar($input: Filter) {
      one : removeCalendar(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async getCalendar(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      one: getCalendar(filter:$params) {
			id
			nation
			year
			month
			day
			quarter
			week
			dayName
			monthName
			operatingFlag
			holidayFlag
			weekendFlag
			event
			tradeHistory

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async getCalendarList(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      cnt: getCalendarCnt(filter:$params)   
      list: getCalendarList(filter:$params) {
			id
			nation
			year
			month
			day
			quarter
			week
			dayName
			monthName
			operatingFlag
			holidayFlag
			weekendFlag
			event
			tradeHistory

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new GraphqlCalendarService();
