/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class Graphql당일거래량상위요청Service {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async add당일거래량상위요청(params) {

    params = {
             일자: ''    // 일자
            ,종목코드: ''    // 종목코드
            ,종목명: ''    // 종목명
            ,현재가: ''    // 현재가
            ,전일대비기호: ''    // 전일대비기호
            ,전일대비: ''    // 전일대비
            ,등락률: ''    // 등락률
            ,거래량: ''    // 거래량
            ,전일비: ''    // 전일비
            ,거래회전률: ''    // 거래회전률
            ,거래금액: ''    // 거래금액
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation add당일거래량상위요청($input: Filter) {
      one : add당일거래량상위요청(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modify당일거래량상위요청(params) {

    let query = `mutation modify당일거래량상위요청($input: Filter) {
      one : modify당일거래량상위요청(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async remove당일거래량상위요청(params) {

    params = {
    }

    let query = `mutation remove당일거래량상위요청($input: Filter) {
      one : remove당일거래량상위요청(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async get당일거래량상위요청(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      one: get당일거래량상위요청(filter:$params) {
			일자
			종목코드
			종목명
			현재가
			전일대비기호
			전일대비
			등락률
			거래량
			전일비
			거래회전률
			거래금액
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async get당일거래량상위요청List(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      cnt: get당일거래량상위요청Cnt(filter:$params)   
      list: get당일거래량상위요청List(filter:$params) {
			일자
			종목코드
			종목명
			현재가
			전일대비기호
			전일대비
			등락률
			거래량
			전일비
			거래회전률
			거래금액
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new Graphql당일거래량상위요청Service();
