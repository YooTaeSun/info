package .service.dao;

import java.util.List;

import com.osstem.ows.biz.cfg.datasource.OwsMapper;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 * 당일거래량상위요청 DAO
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.07.07.						최초작성
 * </pre>
 */
@OwsMapper
public interface DAO {

	/**
     * 당일거래량상위요청 등록, 수정
     * @Method merge당일거래량상위요청
     * @param Filter
     * @return 등록 또는 수정된 건수
     */	
	public int merge(Filter params);
	
	/**
	 * 당일거래량상위요청 여러 건 등록
	 * @Method bulkInsert당일거래량상위요청
	 * @param Filter
	 * @return 여러 건 등록된 건수
	 */	
	public int bulkInsert(Filter params);
	
	/**
	 * 당일거래량상위요청 등록
	 * @Method insert당일거래량상위요청
	 * @param Filter
	 * @return 등록된 건수
	 */	
	public int insert(Filter params);
	
    /**
     * 당일거래량상위요청 수정
     * @Method update당일거래량상위요청
     * @param Filter
     * @return 수정된 건수
     */	
	public int update(Filter params);
	
    /**
     * 당일거래량상위요청 삭제 
     * @Method delete당일거래량상위요청
     * @param Filter
     * @return 삭제된 건수
     */	
	public int delete(Filter params);
 
    /**
     * 당일거래량상위요청 단건 조회
     *
     * @param Filter
     * @return 조회 건
     */	    
	public DTO select(Filter params);

    /**
     * 당일거래량상위요청 건수 조회
     * @Method select당일거래량상위요청Cnt
     * @param Filter
     * @return 건수
     */	
    int selectCnt(Filter params);
    
    /**
     * 당일거래량상위요청 다건 조회
     * @Method select당일거래량상위요청List
     * @param Filter 
     * @return 조회 목록
     */	
	public List<DTO> selectList(Filter params);
}
