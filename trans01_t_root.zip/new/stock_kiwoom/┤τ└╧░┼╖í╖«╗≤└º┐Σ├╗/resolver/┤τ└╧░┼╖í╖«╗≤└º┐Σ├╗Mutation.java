package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import .model.filter.Filter;
import .service.당일거래량상위요청Service;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * 당일거래량상위요청 GraphQL Mutation
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.07.07.						최초작성
 * </pre>
 */
@Component
public class 당일거래량상위요청Mutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(당일거래량상위요청Mutation.class);
	
	@Autowired
	private 당일거래량상위요청Service 당일거래량상위요청Service;
	
	/**
	 * 당일거래량상위요청 등록
     * @Method add당일거래량상위요청
	 * @param Filter
	 */
    public Boolean add당일거래량상위요청(Filter params) {
    	try {
    		return 당일거래량상위요청Service.insert당일거래량상위요청(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * 당일거래량상위요청 수정
     * @Method modify당일거래량상위요청
	 * @param Filter
	 */
	public Boolean modify당일거래량상위요청(Filter params) {
		try {
			return 당일거래량상위요청Service.update당일거래량상위요청(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * 당일거래량상위요청 삭제
     * @Method remove당일거래량상위요청
	 * @param Filter
	 */
	public Boolean remove당일거래량상위요청(Filter params) {
		try {
			return 당일거래량상위요청Service.delete당일거래량상위요청(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
