package .service;

import java.util.List;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 * 당일거래량상위요청 서비스
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.07.07.						최초작성
 * </pre>
 */
public interface 당일거래량상위요청Service {

	/**
	 * 당일거래량상위요청 등록, 수정
     * @Method merge당일거래량상위요청
	 * @param Filter
	 */
    public Boolean merge당일거래량상위요청(Filter params);	
    
	/**
	 * 당일거래량상위요청 여러 건 등록
     * @Method bulkInsert당일거래량상위요청
	 * @param Filter
	 */
    public Boolean bulkInsert당일거래량상위요청(Filter params);	    
	
	/**
	 * 당일거래량상위요청 등록
     * @Method insert당일거래량상위요청
	 * @param Filter
	 */
    public Boolean insert당일거래량상위요청(Filter params);

    /**
     * 당일거래량상위요청 수정
     * @Method update당일거래량상위요청
     * @param Filter
     */
    public Boolean update당일거래량상위요청(Filter params);

    /**
     * 당일거래량상위요청 삭제
     * @Method delete당일거래량상위요청
     * @param Filter
     */
    public Boolean delete당일거래량상위요청(Filter params);
    
    /**
     * 당일거래량상위요청 단건 조회
     * @Method select당일거래량상위요청 
     * @param  Filter
     */
    public DTO select당일거래량상위요청(Filter params);    
    
    /**
     * 당일거래량상위요청 건수 조회
     * @Method select당일거래량상위요청Cnt
     * @param  Filter
     */
    public int select당일거래량상위요청Cnt(Filter params);
    
    /**
     * 당일거래량상위요청 다건 조회
     * @Method select당일거래량상위요청List
     * @param  Filter
     */
    public List<DTO> select당일거래량상위요청List(Filter params);

}
