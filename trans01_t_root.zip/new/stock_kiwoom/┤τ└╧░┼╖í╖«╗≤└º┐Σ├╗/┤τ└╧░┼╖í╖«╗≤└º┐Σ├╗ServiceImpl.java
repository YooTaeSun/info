package .service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import .model.dto.DTO;
import .model.filter.Filter;
import .service.당일거래량상위요청Service;
import .service.dao.DAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 * 당일거래량상위요청 ServiceImpl
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.07.07.						최초작성
 * </pre>
 */
@Service("당일거래량상위요청Service")
public class 당일거래량상위요청ServiceImpl implements 당일거래량상위요청Service {

	private static final Logger logger = LoggerFactory.getLogger(당일거래량상위요청ServiceImpl.class);
	
	@Autowired
    private DAO DAO;
    
	/**
	 * 당일거래량상위요청 등록, 수정
     * @Method merge당일거래량상위요청
	 * @param Filter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean merge당일거래량상위요청(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.merge(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     * 당일거래량상위요청 여러 건 등록
     * @Method bulkInsert당일거래량상위요청
     * @param Filter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsert당일거래량상위요청(Filter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = DAO.bulkInsert(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 * 당일거래량상위요청 등록
     * @Method insert당일거래량상위요청
	 * @param Filter
     * @return 등록 여부
	 */
    @Override
    public Boolean insert당일거래량상위요청(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.insert(params);
        return (result > 0)? true:false;    	
    }

    /**
     * 당일거래량상위요청 수정
     * @Method update당일거래량상위요청 
     * @param Filter
     * @Method update당일거래량상위요청
     * @return 수정 여부
     */
    @Override
    public Boolean update당일거래량상위요청(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = DAO.update(params);
        return (result > 0)? true:false;        
    }

    /**
     * 당일거래량상위요청 삭제
     * @Method delete당일거래량상위요청
     * @param Filter
     * @return 삭제 여부 
     */
    @Override
    public Boolean delete당일거래량상위요청(Filter params){
        int result = DAO.delete(params);
        return (result > 0)? true:false;
    }
    
    /**
     * 당일거래량상위요청 단건 조회
     * @Method select당일거래량상위요청
     * @param  Filter
     * @return 조회 건
     */
    @Override
    public DTO select당일거래량상위요청(Filter params){
        return DAO.select(params);
    }
    
    /**
     * 당일거래량상위요청 건수 조회
     * @Method select당일거래량상위요청Cnt
     * @param  Filter
     * @return 건수
     */
    @Override
    public int select당일거래량상위요청Cnt(Filter params){
        return DAO.selectCnt(params);
    }

    /**
     * 당일거래량상위요청 다건 조회
     * @Method select당일거래량상위요청List
     * @param  Filter
     * @return 조회 목록
     */
    @Override
    public List<DTO> select당일거래량상위요청List(Filter params){
        return DAO.selectList(params);
    }
}
