package .model.dto;
import java.util.Date;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DTO {

	/**
	 * 일자(PK)
	 */
	@ApiModelProperty(value = "일자: 일자")
	private String 일자;

	/**
	 * 종목코드(PK)
	 */
	@ApiModelProperty(value = "종목코드: 종목코드")
	private String 종목코드;

	/**
	 * 종목명
	 */
	@ApiModelProperty(value = "종목명: 종목명")
	private String 종목명;

	/**
	 * 현재가
	 */
	@ApiModelProperty(value = "현재가: 현재가")
	private Integer 현재가;

	/**
	 * 전일대비기호
	 */
	@ApiModelProperty(value = "전일대비기호: 전일대비기호")
	private Float 전일대비기호;

	/**
	 * 전일대비
	 */
	@ApiModelProperty(value = "전일대비: 전일대비")
	private Integer 전일대비;

	/**
	 * 등락률
	 */
	@ApiModelProperty(value = "등락률: 등락률")
	private Integer 등락률;

	/**
	 * 거래량
	 */
	@ApiModelProperty(value = "거래량: 거래량")
	private Float 거래량;

	/**
	 * 전일비
	 */
	@ApiModelProperty(value = "전일비: 전일비")
	private Float 전일비;

	/**
	 * 거래회전률
	 */
	@ApiModelProperty(value = "거래회전률: 거래회전률")
	private Float 거래회전률;

	/**
	 * 거래금액
	 */
	@ApiModelProperty(value = "거래금액: 거래금액")
	private Float 거래금액;

	/**
	 * 입력날짜
	 */
	@ApiModelProperty(value = "insertDate: 입력날짜")
	private Date insertDate;

	/**
	 * 수정날짜
	 */
	@ApiModelProperty(value = "updateDate: 수정날짜")
	private Date updateDate;


}
