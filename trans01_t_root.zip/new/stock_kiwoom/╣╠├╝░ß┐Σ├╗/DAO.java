package com.osstem.ows.biz.sal.sales.service.dao;

import java.util.List;

import com.osstem.ows.biz.cfg.datasource.OwsMapper;
import com.osstem.ows.biz.sal.sales.model.dto.DTO;
import com.osstem.ows.biz.sal.sales.model.filter.Filter;

/**
 * 미체결요청 DAO
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.02.10.		system				최초작성
 * </pre>
 */
@OwsMapper
public interface DAO {

	/**
     * 미체결요청 등록, 수정
     * @Method merge미체결요청
     * @param Filter
     * @return 등록 또는 수정된 건수
     */	
	public int merge(Filter params);
	
	/**
	 * 미체결요청 여러 건 등록
	 * @Method bulkInsert미체결요청
	 * @param Filter
	 * @return 여러 건 등록된 건수
	 */	
	public int bulkInsert(Filter params);
	
	/**
	 * 미체결요청 등록
	 * @Method insert미체결요청
	 * @param Filter
	 * @return 등록된 건수
	 */	
	public int insert(Filter params);
	
    /**
     * 미체결요청 수정
     * @Method update미체결요청
     * @param Filter
     * @return 수정된 건수
     */	
	public int update(Filter params);
	
    /**
     * 미체결요청 삭제 
     * @Method delete미체결요청
     * @param Filter
     * @return 삭제된 건수
     */	
	public int delete(Filter params);
 
    /**
     * 미체결요청 단건 조회
     *
     * @param Filter
     * @return 조회 건
     */	    
	public DTO select(Filter params);

    /**
     * 미체결요청 건수 조회
     * @Method select미체결요청Cnt
     * @param Filter
     * @return 건수
     */	
    int selectCnt(Filter params);
    
    /**
     * 미체결요청 다건 조회
     * @Method select미체결요청List
     * @param Filter 
     * @return 조회 목록
     */	
	public List<DTO> selectList(Filter params);
}
