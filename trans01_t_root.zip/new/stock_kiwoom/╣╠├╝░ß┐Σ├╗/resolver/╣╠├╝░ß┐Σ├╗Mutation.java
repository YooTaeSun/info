package com.osstem.ows.biz.sal.sales.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import com.osstem.ows.biz.sal.sales.model.filter.Filter;
import com.osstem.ows.biz.sal.sales.service.미체결요청Service;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * 미체결요청 GraphQL Mutation
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.02.10.		system				최초작성
 * </pre>
 */
@Component
public class 미체결요청Mutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(미체결요청Mutation.class);
	
	@Autowired
	private 미체결요청Service 미체결요청Service;
	
	/**
	 * 미체결요청 등록
     * @Method add미체결요청
	 * @param Filter
	 */
    public Boolean add미체결요청(Filter params) {
    	try {
    		return 미체결요청Service.insert미체결요청(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * 미체결요청 수정
     * @Method modify미체결요청
	 * @param Filter
	 */
	public Boolean modify미체결요청(Filter params) {
		try {
			return 미체결요청Service.update미체결요청(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * 미체결요청 삭제
     * @Method remove미체결요청
	 * @param Filter
	 */
	public Boolean remove미체결요청(Filter params) {
		try {
			return 미체결요청Service.delete미체결요청(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
