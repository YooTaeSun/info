package com.osstem.ows.biz.sal.sales.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.sal.sales.model.dto.DTO;
import com.osstem.ows.biz.sal.sales.model.filter.Filter;
import com.osstem.ows.biz.sal.sales.service.미체결요청Service;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * 미체결요청 GraphQL Query
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.02.10.		system				최초작성
 * </pre>
 */
@Component
public class 미체결요청Query implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(미체결요청Mutation.class);
	
	@Autowired
	private 미체결요청Service 미체결요청Service;

    /**
     * 미체결요청 단건 조회
     * @Method get미체결요청
     * @param  Filter
     * @return 조회 건
     */
    public DTO get미체결요청(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 미체결요청Service.select미체결요청(params);
    }
    
    /**
     * 미체결요청 건수 조회
     * @Method get미체결요청Cnt
     * @param  Filter
     * @return 건수
     */
    public int get미체결요청Cnt(Filter params){
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 미체결요청Service.select미체결요청Cnt(params);
    }

    /**
     * 미체결요청 다건 조회
     * @Method get미체결요청List
     * @param  Filter
     * @return 조회 목록
     */
    public List<DTO> get미체결요청List(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 미체결요청Service.select미체결요청List(params);
    }
}
