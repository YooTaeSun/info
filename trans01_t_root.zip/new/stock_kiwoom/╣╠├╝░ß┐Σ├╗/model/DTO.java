package com.osstem.ows.biz.sal.sales.model.dto;
import java.util.Date;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DTO {

	/**
	 * 일자(PK)
	 */
	@ApiModelProperty(value = "일자: 일자")
	private String 일자;

	/**
	 * user_id(PK)
	 */
	@ApiModelProperty(value = "userId: user_id")
	private String userId;

	/**
	 * 종목코드(PK)
	 */
	@ApiModelProperty(value = "종목코드: 종목코드")
	private String 종목코드;

	/**
	 * 종목명
	 */
	@ApiModelProperty(value = "종목명: 종목명")
	private String 종목명;

	/**
	 * 주문번호
	 */
	@ApiModelProperty(value = "주문번호: 주문번호")
	private String 주문번호;

	/**
	 * 계좌번호
	 */
	@ApiModelProperty(value = "계좌번호: 계좌번호")
	private String 계좌번호;

	/**
	 * 업무구분
	 */
	@ApiModelProperty(value = "업무구분: 업무구분")
	private String 업무구분;

	/**
	 * 주문상태
	 */
	@ApiModelProperty(value = "주문상태: 주문상태")
	private String 주문상태;

	/**
	 * 주문수량
	 */
	@ApiModelProperty(value = "주문수량: 주문수량")
	private Integer 주문수량;

	/**
	 * 주문가격
	 */
	@ApiModelProperty(value = "주문가격: 주문가격")
	private Integer 주문가격;

	/**
	 * 미체결수량
	 */
	@ApiModelProperty(value = "미체결수량: 미체결수량")
	private Integer 미체결수량;

	/**
	 * 체결누계금액
	 */
	@ApiModelProperty(value = "체결누계금액: 체결누계금액")
	private Float 체결누계금액;

	/**
	 * 원주문번호
	 */
	@ApiModelProperty(value = "원주문번호: 원주문번호")
	private String 원주문번호;

	/**
	 * 주문구분
	 */
	@ApiModelProperty(value = "주문구분: 주문구분")
	private String 주문구분;

	/**
	 * 매매구분
	 */
	@ApiModelProperty(value = "매매구분: 매매구분")
	private String 매매구분;

	/**
	 * 시간
	 */
	@ApiModelProperty(value = "시간: 시간")
	private String 시간;

	/**
	 * 체결번호
	 */
	@ApiModelProperty(value = "체결번호: 체결번호")
	private String 체결번호;

	/**
	 * 체결가
	 */
	@ApiModelProperty(value = "체결가: 체결가")
	private Float 체결가;

	/**
	 * 체결량
	 */
	@ApiModelProperty(value = "체결량: 체결량")
	private Integer 체결량;

	/**
	 * 현재가
	 */
	@ApiModelProperty(value = "현재가: 현재가")
	private Integer 현재가;

	/**
	 * 매도호가
	 */
	@ApiModelProperty(value = "매도호가: 매도호가")
	private Integer 매도호가;

	/**
	 * 매수호가
	 */
	@ApiModelProperty(value = "매수호가: 매수호가")
	private Integer 매수호가;

	/**
	 * 단위체결가
	 */
	@ApiModelProperty(value = "단위체결가: 단위체결가")
	private Float 단위체결가;

	/**
	 * 단위체결량
	 */
	@ApiModelProperty(value = "단위체결량: 단위체결량")
	private Integer 단위체결량;

	/**
	 * 당일매매수수료
	 */
	@ApiModelProperty(value = "당일매매수수료: 당일매매수수료")
	private Float 당일매매수수료;

	/**
	 * 당일매매세금
	 */
	@ApiModelProperty(value = "당일매매세금: 당일매매세금")
	private Float 당일매매세금;

	/**
	 * 개인투자자
	 */
	@ApiModelProperty(value = "개인투자자: 개인투자자")
	private String 개인투자자;

	/**
	 * 입력날짜
	 */
	@ApiModelProperty(value = "insertDate: 입력날짜")
	private Date insertDate;

	/**
	 * 수정날짜
	 */
	@ApiModelProperty(value = "updateDate: 수정날짜")
	private Date updateDate;


}
