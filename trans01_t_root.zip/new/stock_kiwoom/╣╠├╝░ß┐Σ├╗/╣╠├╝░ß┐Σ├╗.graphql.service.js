/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class Graphql미체결요청Service {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async add미체결요청(params) {

    params = {
             일자: ''    // 일자
            ,userId: ''    // user_id
            ,종목코드: ''    // 종목코드
            ,종목명: ''    // 종목명
            ,주문번호: ''    // 주문번호
            ,계좌번호: ''    // 계좌번호
            ,업무구분: ''    // 업무구분
            ,주문상태: ''    // 주문상태
            ,주문수량: ''    // 주문수량
            ,주문가격: ''    // 주문가격
            ,미체결수량: ''    // 미체결수량
            ,체결누계금액: ''    // 체결누계금액
            ,원주문번호: ''    // 원주문번호
            ,주문구분: ''    // 주문구분
            ,매매구분: ''    // 매매구분
            ,시간: ''    // 시간
            ,체결번호: ''    // 체결번호
            ,체결가: ''    // 체결가
            ,체결량: ''    // 체결량
            ,현재가: ''    // 현재가
            ,매도호가: ''    // 매도호가
            ,매수호가: ''    // 매수호가
            ,단위체결가: ''    // 단위체결가
            ,단위체결량: ''    // 단위체결량
            ,당일매매수수료: ''    // 당일매매수수료
            ,당일매매세금: ''    // 당일매매세금
            ,개인투자자: ''    // 개인투자자
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation add미체결요청($input: Filter) {
      one : add미체결요청(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modify미체결요청(params) {

    let query = `mutation modify미체결요청($input: Filter) {
      one : modify미체결요청(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async remove미체결요청(params) {

    params = {
    }

    let query = `mutation remove미체결요청($input: Filter) {
      one : remove미체결요청(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async get미체결요청(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      one: get미체결요청(filter:$params) {
			일자
			userId
			종목코드
			종목명
			주문번호
			계좌번호
			업무구분
			주문상태
			주문수량
			주문가격
			미체결수량
			체결누계금액
			원주문번호
			주문구분
			매매구분
			시간
			체결번호
			체결가
			체결량
			현재가
			매도호가
			매수호가
			단위체결가
			단위체결량
			당일매매수수료
			당일매매세금
			개인투자자
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async get미체결요청List(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      cnt: get미체결요청Cnt(filter:$params)   
      list: get미체결요청List(filter:$params) {
			일자
			userId
			종목코드
			종목명
			주문번호
			계좌번호
			업무구분
			주문상태
			주문수량
			주문가격
			미체결수량
			체결누계금액
			원주문번호
			주문구분
			매매구분
			시간
			체결번호
			체결가
			체결량
			현재가
			매도호가
			매수호가
			단위체결가
			단위체결량
			당일매매수수료
			당일매매세금
			개인투자자
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new Graphql미체결요청Service();
