package com.osstem.ows.biz.sal.sales.service;

import java.util.List;
import com.osstem.ows.biz.sal.sales.model.dto.DTO;
import com.osstem.ows.biz.sal.sales.model.filter.Filter;

/**
 * 미체결요청 서비스
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.02.10.		system				최초작성
 * </pre>
 */
public interface 미체결요청Service {

	/**
	 * 미체결요청 등록, 수정
     * @Method merge미체결요청
	 * @param Filter
	 */
    public Boolean merge미체결요청(Filter params);	
    
	/**
	 * 미체결요청 여러 건 등록
     * @Method bulkInsert미체결요청
	 * @param Filter
	 */
    public Boolean bulkInsert미체결요청(Filter params);	    
	
	/**
	 * 미체결요청 등록
     * @Method insert미체결요청
	 * @param Filter
	 */
    public Boolean insert미체결요청(Filter params);

    /**
     * 미체결요청 수정
     * @Method update미체결요청
     * @param Filter
     */
    public Boolean update미체결요청(Filter params);

    /**
     * 미체결요청 삭제
     * @Method delete미체결요청
     * @param Filter
     */
    public Boolean delete미체결요청(Filter params);
    
    /**
     * 미체결요청 단건 조회
     * @Method select미체결요청 
     * @param  Filter
     */
    public DTO select미체결요청(Filter params);    
    
    /**
     * 미체결요청 건수 조회
     * @Method select미체결요청Cnt
     * @param  Filter
     */
    public int select미체결요청Cnt(Filter params);
    
    /**
     * 미체결요청 다건 조회
     * @Method select미체결요청List
     * @param  Filter
     */
    public List<DTO> select미체결요청List(Filter params);

}
