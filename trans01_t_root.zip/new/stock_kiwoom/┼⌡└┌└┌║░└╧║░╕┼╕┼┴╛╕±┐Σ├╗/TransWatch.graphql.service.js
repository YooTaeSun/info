/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class GraphqlTransWatchService {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async addTransWatch(params) {

    params = {
             투자자구분: ''    // 투자자구분
            ,시장구분: ''    // 시장구분
            ,매매구분: ''    // 매매구분
            ,시작일자: ''    // 시작일자
            ,종료일자: ''    // 종료일자
            ,순번: ''    // 순번
            ,일자: ''    // 일자
            ,종목코드: ''    // 종목코드
            ,종목명: ''    // 종목명
            ,순매도수량: ''    // 순매도수량
            ,순매도금액: ''    // 순매도금액
            ,추청평균가: ''    // 추청평균가
            ,현재가: ''    // 현재가
            ,대비기호: ''    // 대비기호
            ,전일대비: ''    // 전일대비
            ,평균가대비: ''    // 평균가대비
            ,대비율: ''    // 대비율
            ,기간거래량: ''    // 기간거래량
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation addTransWatch($input: 투자자별일별매매종목요청Filter) {
      one : addTransWatch(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modifyTransWatch(params) {

    let query = `mutation modifyTransWatch($input: 투자자별일별매매종목요청Filter) {
      one : modifyTransWatch(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async removeTransWatch(params) {

    params = {
    }

    let query = `mutation removeTransWatch($input: 투자자별일별매매종목요청Filter) {
      one : removeTransWatch(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async getTransWatch(params) {

    params = {

    }

    let query = `
    query ($params:투자자별일별매매종목요청Filter) {
      one: getTransWatch(filter:$params) {
			투자자구분
			시장구분
			매매구분
			시작일자
			종료일자
			순번
			일자
			종목코드
			종목명
			순매도수량
			순매도금액
			추청평균가
			현재가
			대비기호
			전일대비
			평균가대비
			대비율
			기간거래량
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async getTransWatchList(params) {

    params = {

    }

    let query = `
    query ($params:투자자별일별매매종목요청Filter) {
      cnt: getTransWatchCnt(filter:$params)   
      list: getTransWatchList(filter:$params) {
			투자자구분
			시장구분
			매매구분
			시작일자
			종료일자
			순번
			일자
			종목코드
			종목명
			순매도수량
			순매도금액
			추청평균가
			현재가
			대비기호
			전일대비
			평균가대비
			대비율
			기간거래량
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new GraphqlTransWatchService();
