package com.osstem.ows.biz.sal.sales.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import com.osstem.ows.biz.sal.sales.model.dto.투자자별일별매매종목요청DTO;
import com.osstem.ows.biz.sal.sales.model.filter.투자자별일별매매종목요청Filter;
import com.osstem.ows.biz.sal.sales.service.TransWatchService;
import com.osstem.ows.biz.sal.sales.service.dao.투자자별일별매매종목요청DAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 * 투자자별일별매매종목요청 ServiceImpl
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.11.30.		system				최초작성
 * </pre>
 */
@Service("transWatchService")
public class TransWatchServiceImpl implements TransWatchService {

	private static final Logger logger = LoggerFactory.getLogger(TransWatchServiceImpl.class);
	
	@Autowired
    private 투자자별일별매매종목요청DAO 투자자별일별매매종목요청DAO;
    
	/**
	 * 투자자별일별매매종목요청 등록, 수정
     * @Method mergeTransWatch
	 * @param 투자자별일별매매종목요청Filter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean mergeTransWatch(투자자별일별매매종목요청Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = 투자자별일별매매종목요청DAO.merge투자자별일별매매종목요청(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     * 투자자별일별매매종목요청 여러 건 등록
     * @Method bulkInsertTransWatch
     * @param 투자자별일별매매종목요청Filter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsertTransWatch(투자자별일별매매종목요청Filter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = 투자자별일별매매종목요청DAO.bulkInsert투자자별일별매매종목요청(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 * 투자자별일별매매종목요청 등록
     * @Method insertTransWatch
	 * @param 투자자별일별매매종목요청Filter
     * @return 등록 여부
	 */
    @Override
    public Boolean insertTransWatch(투자자별일별매매종목요청Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = 투자자별일별매매종목요청DAO.insert투자자별일별매매종목요청(params);
        return (result > 0)? true:false;    	
    }

    /**
     * 투자자별일별매매종목요청 수정
     * @Method updateTransWatch 
     * @param 투자자별일별매매종목요청Filter
     * @Method updateTransWatch
     * @return 수정 여부
     */
    @Override
    public Boolean updateTransWatch(투자자별일별매매종목요청Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = 투자자별일별매매종목요청DAO.update투자자별일별매매종목요청(params);
        return (result > 0)? true:false;        
    }

    /**
     * 투자자별일별매매종목요청 삭제
     * @Method deleteTransWatch
     * @param 투자자별일별매매종목요청Filter
     * @return 삭제 여부 
     */
    @Override
    public Boolean deleteTransWatch(투자자별일별매매종목요청Filter params){
        int result = 투자자별일별매매종목요청DAO.delete투자자별일별매매종목요청(params);
        return (result > 0)? true:false;
    }
    
    /**
     * 투자자별일별매매종목요청 단건 조회
     * @Method selectTransWatch
     * @param  투자자별일별매매종목요청Filter
     * @return 조회 건
     */
    @Override
    public 투자자별일별매매종목요청DTO selectTransWatch(투자자별일별매매종목요청Filter params){
        return 투자자별일별매매종목요청DAO.select투자자별일별매매종목요청(params);
    }
    
    /**
     * 투자자별일별매매종목요청 건수 조회
     * @Method selectTransWatchCnt
     * @param  투자자별일별매매종목요청Filter
     * @return 건수
     */
    @Override
    public int selectTransWatchCnt(투자자별일별매매종목요청Filter params){
        return 투자자별일별매매종목요청DAO.select투자자별일별매매종목요청Cnt(params);
    }

    /**
     * 투자자별일별매매종목요청 다건 조회
     * @Method selectTransWatchList
     * @param  투자자별일별매매종목요청Filter
     * @return 조회 목록
     */
    @Override
    public List<투자자별일별매매종목요청DTO> selectTransWatchList(투자자별일별매매종목요청Filter params){
        return 투자자별일별매매종목요청DAO.select투자자별일별매매종목요청List(params);
    }
}
