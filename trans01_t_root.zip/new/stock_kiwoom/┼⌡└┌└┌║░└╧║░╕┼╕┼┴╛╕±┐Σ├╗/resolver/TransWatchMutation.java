package com.osstem.ows.biz.sal.sales.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import com.osstem.ows.biz.sal.sales.model.filter.투자자별일별매매종목요청Filter;
import com.osstem.ows.biz.sal.sales.service.TransWatchService;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * 투자자별일별매매종목요청 GraphQL Mutation
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.11.30.		system				최초작성
 * </pre>
 */
@Component
public class TransWatchMutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(TransWatchMutation.class);
	
	@Autowired
	private TransWatchService transWatchService;
	
	/**
	 * 투자자별일별매매종목요청 등록
     * @Method addTransWatch
	 * @param 투자자별일별매매종목요청Filter
	 */
    public Boolean addTransWatch(투자자별일별매매종목요청Filter params) {
    	try {
    		return transWatchService.insertTransWatch(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * 투자자별일별매매종목요청 수정
     * @Method modifyTransWatch
	 * @param 투자자별일별매매종목요청Filter
	 */
	public Boolean modifyTransWatch(투자자별일별매매종목요청Filter params) {
		try {
			return transWatchService.updateTransWatch(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * 투자자별일별매매종목요청 삭제
     * @Method removeTransWatch
	 * @param 투자자별일별매매종목요청Filter
	 */
	public Boolean removeTransWatch(투자자별일별매매종목요청Filter params) {
		try {
			return transWatchService.deleteTransWatch(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
