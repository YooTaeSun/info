package com.osstem.ows.biz.sal.sales.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.sal.sales.model.dto.투자자별일별매매종목요청DTO;
import com.osstem.ows.biz.sal.sales.model.filter.투자자별일별매매종목요청Filter;
import com.osstem.ows.biz.sal.sales.service.TransWatchService;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * 투자자별일별매매종목요청 GraphQL Query
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.11.30.		system				최초작성
 * </pre>
 */
@Component
public class TransWatchQuery implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(TransWatchMutation.class);
	
	@Autowired
	private TransWatchService transWatchService;

    /**
     * 투자자별일별매매종목요청 단건 조회
     * @Method getTransWatch
     * @param  투자자별일별매매종목요청Filter
     * @return 조회 건
     */
    public 투자자별일별매매종목요청DTO getTransWatch(투자자별일별매매종목요청Filter params) {
    	params = Optional.ofNullable(params).orElseGet(투자자별일별매매종목요청Filter::new);
    	return transWatchService.selectTransWatch(params);
    }
    
    /**
     * 투자자별일별매매종목요청 건수 조회
     * @Method getTransWatchCnt
     * @param  투자자별일별매매종목요청Filter
     * @return 건수
     */
    public int getTransWatchCnt(투자자별일별매매종목요청Filter params){
    	params = Optional.ofNullable(params).orElseGet(투자자별일별매매종목요청Filter::new);
    	return transWatchService.selectTransWatchCnt(params);
    }

    /**
     * 투자자별일별매매종목요청 다건 조회
     * @Method getTransWatchList
     * @param  투자자별일별매매종목요청Filter
     * @return 조회 목록
     */
    public List<투자자별일별매매종목요청DTO> getTransWatchList(투자자별일별매매종목요청Filter params) {
    	params = Optional.ofNullable(params).orElseGet(투자자별일별매매종목요청Filter::new);
    	return transWatchService.selectTransWatchList(params);
    }
}
