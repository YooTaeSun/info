package com.osstem.ows.biz.sal.sales.service;

import java.util.List;
import com.osstem.ows.biz.sal.sales.model.dto.투자자별일별매매종목요청DTO;
import com.osstem.ows.biz.sal.sales.model.filter.투자자별일별매매종목요청Filter;

/**
 * 투자자별일별매매종목요청 서비스
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.11.30.		system				최초작성
 * </pre>
 */
public interface TransWatchService {

	/**
	 * 투자자별일별매매종목요청 등록, 수정
     * @Method mergeTransWatch
	 * @param 투자자별일별매매종목요청Filter
	 */
    public Boolean mergeTransWatch(투자자별일별매매종목요청Filter params);	
    
	/**
	 * 투자자별일별매매종목요청 여러 건 등록
     * @Method bulkInsertTransWatch
	 * @param 투자자별일별매매종목요청Filter
	 */
    public Boolean bulkInsertTransWatch(투자자별일별매매종목요청Filter params);	    
	
	/**
	 * 투자자별일별매매종목요청 등록
     * @Method insertTransWatch
	 * @param 투자자별일별매매종목요청Filter
	 */
    public Boolean insertTransWatch(투자자별일별매매종목요청Filter params);

    /**
     * 투자자별일별매매종목요청 수정
     * @Method updateTransWatch
     * @param 투자자별일별매매종목요청Filter
     */
    public Boolean updateTransWatch(투자자별일별매매종목요청Filter params);

    /**
     * 투자자별일별매매종목요청 삭제
     * @Method deleteTransWatch
     * @param 투자자별일별매매종목요청Filter
     */
    public Boolean deleteTransWatch(투자자별일별매매종목요청Filter params);
    
    /**
     * 투자자별일별매매종목요청 단건 조회
     * @Method selectTransWatch 
     * @param  투자자별일별매매종목요청Filter
     */
    public 투자자별일별매매종목요청DTO selectTransWatch(투자자별일별매매종목요청Filter params);    
    
    /**
     * 투자자별일별매매종목요청 건수 조회
     * @Method selectTransWatchCnt
     * @param  투자자별일별매매종목요청Filter
     */
    public int selectTransWatchCnt(투자자별일별매매종목요청Filter params);
    
    /**
     * 투자자별일별매매종목요청 다건 조회
     * @Method selectTransWatchList
     * @param  투자자별일별매매종목요청Filter
     */
    public List<투자자별일별매매종목요청DTO> selectTransWatchList(투자자별일별매매종목요청Filter params);

}
