package com.osstem.ows.biz.sal.sales.service.dao;

import java.util.List;

import com.osstem.ows.biz.cfg.datasource.OwsMapper;
import com.osstem.ows.biz.sal.sales.model.dto.투자자별일별매매종목요청DTO;
import com.osstem.ows.biz.sal.sales.model.filter.투자자별일별매매종목요청Filter;

/**
 * 투자자별일별매매종목요청 DAO
 *
 * @author		system
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.11.30.		system				최초작성
 * </pre>
 */
@OwsMapper
public interface 투자자별일별매매종목요청DAO {

	/**
     * 투자자별일별매매종목요청 등록, 수정
     * @Method mergeTransWatch
     * @param 투자자별일별매매종목요청Filter
     * @return 등록 또는 수정된 건수
     */	
	public int merge투자자별일별매매종목요청(투자자별일별매매종목요청Filter params);
	
	/**
	 * 투자자별일별매매종목요청 여러 건 등록
	 * @Method bulkInsertTransWatch
	 * @param 투자자별일별매매종목요청Filter
	 * @return 여러 건 등록된 건수
	 */	
	public int bulkInsert투자자별일별매매종목요청(투자자별일별매매종목요청Filter params);
	
	/**
	 * 투자자별일별매매종목요청 등록
	 * @Method insertTransWatch
	 * @param 투자자별일별매매종목요청Filter
	 * @return 등록된 건수
	 */	
	public int insert투자자별일별매매종목요청(투자자별일별매매종목요청Filter params);
	
    /**
     * 투자자별일별매매종목요청 수정
     * @Method updateTransWatch
     * @param 투자자별일별매매종목요청Filter
     * @return 수정된 건수
     */	
	public int update투자자별일별매매종목요청(투자자별일별매매종목요청Filter params);
	
    /**
     * 투자자별일별매매종목요청 삭제 
     * @Method deleteTransWatch
     * @param 투자자별일별매매종목요청Filter
     * @return 삭제된 건수
     */	
	public int delete투자자별일별매매종목요청(투자자별일별매매종목요청Filter params);
 
    /**
     * 투자자별일별매매종목요청 단건 조회
     *
     * @param 투자자별일별매매종목요청Filter
     * @return 조회 건
     */	    
	public 투자자별일별매매종목요청DTO select투자자별일별매매종목요청(투자자별일별매매종목요청Filter params);

    /**
     * 투자자별일별매매종목요청 건수 조회
     * @Method selectTransWatchCnt
     * @param 투자자별일별매매종목요청Filter
     * @return 건수
     */	
    int select투자자별일별매매종목요청Cnt(투자자별일별매매종목요청Filter params);
    
    /**
     * 투자자별일별매매종목요청 다건 조회
     * @Method selectTransWatchList
     * @param 투자자별일별매매종목요청Filter 
     * @return 조회 목록
     */	
	public List<투자자별일별매매종목요청DTO> select투자자별일별매매종목요청List(투자자별일별매매종목요청Filter params);
}
