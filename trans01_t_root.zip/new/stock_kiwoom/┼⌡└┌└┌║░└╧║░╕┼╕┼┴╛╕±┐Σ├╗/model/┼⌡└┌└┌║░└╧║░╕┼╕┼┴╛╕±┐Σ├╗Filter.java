package com.osstem.ows.biz.sal.sales.model.filter;

import com.osstem.ows.biz.cmm.model.filter.PageFilter;
import com.osstem.ows.biz.sal.sales.model.dto.투자자별일별매매종목요청DTO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class 투자자별일별매매종목요청Filter extends 투자자별일별매매종목요청DTO {
	
	/**
	 * pageFilter 객체
	 */
	@ApiModelProperty(value = "pageFilter: pageFilter 객체")
	private PageFilter pageFilter;
}
