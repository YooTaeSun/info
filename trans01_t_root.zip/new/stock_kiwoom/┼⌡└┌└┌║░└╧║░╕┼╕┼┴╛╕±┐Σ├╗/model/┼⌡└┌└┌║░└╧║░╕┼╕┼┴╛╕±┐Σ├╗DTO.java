package com.osstem.ows.biz.sal.sales.model.dto;
import java.util.Date;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class 투자자별일별매매종목요청DTO {

	/**
	 * 투자자구분(PK)
	 */
	@ApiModelProperty(value = "투자자구분: 투자자구분")
	private String 투자자구분;

	/**
	 * 시장구분(PK)
	 */
	@ApiModelProperty(value = "시장구분: 시장구분")
	private String 시장구분;

	/**
	 * 매매구분(PK)
	 */
	@ApiModelProperty(value = "매매구분: 매매구분")
	private String 매매구분;

	/**
	 * 시작일자(PK)
	 */
	@ApiModelProperty(value = "시작일자: 시작일자")
	private String 시작일자;

	/**
	 * 종료일자(PK)
	 */
	@ApiModelProperty(value = "종료일자: 종료일자")
	private String 종료일자;

	/**
	 * 순번(PK)
	 */
	@ApiModelProperty(value = "순번: 순번")
	private Long 순번;

	/**
	 * 일자
	 */
	@ApiModelProperty(value = "일자: 일자")
	private String 일자;

	/**
	 * 종목코드
	 */
	@ApiModelProperty(value = "종목코드: 종목코드")
	private String 종목코드;

	/**
	 * 종목명
	 */
	@ApiModelProperty(value = "종목명: 종목명")
	private String 종목명;

	/**
	 * 순매도수량
	 */
	@ApiModelProperty(value = "순매도수량: 순매도수량")
	private Integer 순매도수량;

	/**
	 * 순매도금액
	 */
	@ApiModelProperty(value = "순매도금액: 순매도금액")
	private Integer 순매도금액;

	/**
	 * 추청평균가
	 */
	@ApiModelProperty(value = "추청평균가: 추청평균가")
	private Integer 추청평균가;

	/**
	 * 현재가
	 */
	@ApiModelProperty(value = "현재가: 현재가")
	private Integer 현재가;

	/**
	 * 대비기호
	 */
	@ApiModelProperty(value = "대비기호: 대비기호")
	private String 대비기호;

	/**
	 * 전일대비
	 */
	@ApiModelProperty(value = "전일대비: 전일대비")
	private Integer 전일대비;

	/**
	 * 평균가대비
	 */
	@ApiModelProperty(value = "평균가대비: 평균가대비")
	private Integer 평균가대비;

	/**
	 * 대비율
	 */
	@ApiModelProperty(value = "대비율: 대비율")
	private Integer 대비율;

	/**
	 * 기간거래량
	 */
	@ApiModelProperty(value = "기간거래량: 기간거래량")
	private Float 기간거래량;

	/**
	 * 입력날짜
	 */
	@ApiModelProperty(value = "insertDate: 입력날짜")
	private Date insertDate;

	/**
	 * 수정날짜
	 */
	@ApiModelProperty(value = "updateDate: 수정날짜")
	private Date updateDate;


}
