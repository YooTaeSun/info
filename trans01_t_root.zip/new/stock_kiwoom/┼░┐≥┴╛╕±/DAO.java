package .service.dao;

import java.util.List;

import com.osstem.ows.biz.cfg.datasource.OwsMapper;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 * 주식 종목 table DAO
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.11.09.						최초작성
 * </pre>
 */
@OwsMapper
public interface DAO {

	/**
     * 주식 종목 table 등록, 수정
     * @Method merge키움종목
     * @param Filter
     * @return 등록 또는 수정된 건수
     */	
	public int merge(Filter params);
	
	/**
	 * 주식 종목 table 여러 건 등록
	 * @Method bulkInsert키움종목
	 * @param Filter
	 * @return 여러 건 등록된 건수
	 */	
	public int bulkInsert(Filter params);
	
	/**
	 * 주식 종목 table 등록
	 * @Method insert키움종목
	 * @param Filter
	 * @return 등록된 건수
	 */	
	public int insert(Filter params);
	
    /**
     * 주식 종목 table 수정
     * @Method update키움종목
     * @param Filter
     * @return 수정된 건수
     */	
	public int update(Filter params);
	
    /**
     * 주식 종목 table 삭제 
     * @Method delete키움종목
     * @param Filter
     * @return 삭제된 건수
     */	
	public int delete(Filter params);
 
    /**
     * 주식 종목 table 단건 조회
     *
     * @param Filter
     * @return 조회 건
     */	    
	public DTO select(Filter params);

    /**
     * 주식 종목 table 건수 조회
     * @Method select키움종목Cnt
     * @param Filter
     * @return 건수
     */	
    int selectCnt(Filter params);
    
    /**
     * 주식 종목 table 다건 조회
     * @Method select키움종목List
     * @param Filter 
     * @return 조회 목록
     */	
	public List<DTO> selectList(Filter params);
}
