package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import .model.filter.Filter;
import .service.키움종목Service;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * 주식 종목 table GraphQL Mutation
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.11.09.						최초작성
 * </pre>
 */
@Component
public class 키움종목Mutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(키움종목Mutation.class);
	
	@Autowired
	private 키움종목Service 키움종목Service;
	
	/**
	 * 주식 종목 table 등록
     * @Method add키움종목
	 * @param Filter
	 */
    public Boolean add키움종목(Filter params) {
    	try {
    		return 키움종목Service.insert키움종목(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * 주식 종목 table 수정
     * @Method modify키움종목
	 * @param Filter
	 */
	public Boolean modify키움종목(Filter params) {
		try {
			return 키움종목Service.update키움종목(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * 주식 종목 table 삭제
     * @Method remove키움종목
	 * @param Filter
	 */
	public Boolean remove키움종목(Filter params) {
		try {
			return 키움종목Service.delete키움종목(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
