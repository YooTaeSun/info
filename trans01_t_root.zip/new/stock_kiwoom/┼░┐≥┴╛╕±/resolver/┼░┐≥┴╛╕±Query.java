package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import .model.dto.DTO;
import .model.filter.Filter;
import .service.키움종목Service;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * 주식 종목 table GraphQL Query
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.11.09.						최초작성
 * </pre>
 */
@Component
public class 키움종목Query implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(키움종목Mutation.class);
	
	@Autowired
	private 키움종목Service 키움종목Service;

    /**
     * 주식 종목 table 단건 조회
     * @Method get키움종목
     * @param  Filter
     * @return 조회 건
     */
    public DTO get키움종목(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 키움종목Service.select키움종목(params);
    }
    
    /**
     * 주식 종목 table 건수 조회
     * @Method get키움종목Cnt
     * @param  Filter
     * @return 건수
     */
    public int get키움종목Cnt(Filter params){
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 키움종목Service.select키움종목Cnt(params);
    }

    /**
     * 주식 종목 table 다건 조회
     * @Method get키움종목List
     * @param  Filter
     * @return 조회 목록
     */
    public List<DTO> get키움종목List(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 키움종목Service.select키움종목List(params);
    }
}
