package .service;

import java.util.List;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 * 주식 종목 table 서비스
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.11.09.						최초작성
 * </pre>
 */
public interface 키움종목Service {

	/**
	 * 주식 종목 table 등록, 수정
     * @Method merge키움종목
	 * @param Filter
	 */
    public Boolean merge키움종목(Filter params);	
    
	/**
	 * 주식 종목 table 여러 건 등록
     * @Method bulkInsert키움종목
	 * @param Filter
	 */
    public Boolean bulkInsert키움종목(Filter params);	    
	
	/**
	 * 주식 종목 table 등록
     * @Method insert키움종목
	 * @param Filter
	 */
    public Boolean insert키움종목(Filter params);

    /**
     * 주식 종목 table 수정
     * @Method update키움종목
     * @param Filter
     */
    public Boolean update키움종목(Filter params);

    /**
     * 주식 종목 table 삭제
     * @Method delete키움종목
     * @param Filter
     */
    public Boolean delete키움종목(Filter params);
    
    /**
     * 주식 종목 table 단건 조회
     * @Method select키움종목 
     * @param  Filter
     */
    public DTO select키움종목(Filter params);    
    
    /**
     * 주식 종목 table 건수 조회
     * @Method select키움종목Cnt
     * @param  Filter
     */
    public int select키움종목Cnt(Filter params);
    
    /**
     * 주식 종목 table 다건 조회
     * @Method select키움종목List
     * @param  Filter
     */
    public List<DTO> select키움종목List(Filter params);

}
