/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class Graphql키움종목Service {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async add키움종목(params) {

    params = {
             일자: ''    // 일자
            ,종목코드: ''    // 종목코드
            ,시장구분: ''    // 시장구분코드명
            ,종목명: ''    // 종목명
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation add키움종목($input: Filter) {
      one : add키움종목(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modify키움종목(params) {

    let query = `mutation modify키움종목($input: Filter) {
      one : modify키움종목(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async remove키움종목(params) {

    params = {
    }

    let query = `mutation remove키움종목($input: Filter) {
      one : remove키움종목(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async get키움종목(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      one: get키움종목(filter:$params) {
			일자
			종목코드
			시장구분
			종목명
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async get키움종목List(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      cnt: get키움종목Cnt(filter:$params)   
      list: get키움종목List(filter:$params) {
			일자
			종목코드
			시장구분
			종목명
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new Graphql키움종목Service();
