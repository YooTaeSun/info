package .service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import .model.dto.DTO;
import .model.filter.Filter;
import .service.키움종목Service;
import .service.dao.DAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 * 주식 종목 table ServiceImpl
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.11.09.						최초작성
 * </pre>
 */
@Service("키움종목Service")
public class 키움종목ServiceImpl implements 키움종목Service {

	private static final Logger logger = LoggerFactory.getLogger(키움종목ServiceImpl.class);
	
	@Autowired
    private DAO DAO;
    
	/**
	 * 주식 종목 table 등록, 수정
     * @Method merge키움종목
	 * @param Filter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean merge키움종목(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.merge(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     * 주식 종목 table 여러 건 등록
     * @Method bulkInsert키움종목
     * @param Filter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsert키움종목(Filter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = DAO.bulkInsert(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 * 주식 종목 table 등록
     * @Method insert키움종목
	 * @param Filter
     * @return 등록 여부
	 */
    @Override
    public Boolean insert키움종목(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.insert(params);
        return (result > 0)? true:false;    	
    }

    /**
     * 주식 종목 table 수정
     * @Method update키움종목 
     * @param Filter
     * @Method update키움종목
     * @return 수정 여부
     */
    @Override
    public Boolean update키움종목(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = DAO.update(params);
        return (result > 0)? true:false;        
    }

    /**
     * 주식 종목 table 삭제
     * @Method delete키움종목
     * @param Filter
     * @return 삭제 여부 
     */
    @Override
    public Boolean delete키움종목(Filter params){
        int result = DAO.delete(params);
        return (result > 0)? true:false;
    }
    
    /**
     * 주식 종목 table 단건 조회
     * @Method select키움종목
     * @param  Filter
     * @return 조회 건
     */
    @Override
    public DTO select키움종목(Filter params){
        return DAO.select(params);
    }
    
    /**
     * 주식 종목 table 건수 조회
     * @Method select키움종목Cnt
     * @param  Filter
     * @return 건수
     */
    @Override
    public int select키움종목Cnt(Filter params){
        return DAO.selectCnt(params);
    }

    /**
     * 주식 종목 table 다건 조회
     * @Method select키움종목List
     * @param  Filter
     * @return 조회 목록
     */
    @Override
    public List<DTO> select키움종목List(Filter params){
        return DAO.selectList(params);
    }
}
