/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class Graphql거래량급증요청Service {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async add거래량급증요청(params) {

    params = {
             일자: ''    // 일자
            ,순번: ''    // 순번
            ,종목코드: ''    // 종목코드
            ,종목명: ''    // 종목명
            ,현재가: ''    // 현재가
            ,전일대비기호: ''    // 전일대비기호
            ,전일대비: ''    // 전일대비
            ,등락률: ''    // 등락률
            ,이전거래량: ''    // 거래량
            ,현재거래량: ''    // 거래량
            ,급증량: ''    // 급증량
            ,급증률: ''    // 급증률
            ,insertDate: ''    // 입력날짜
            ,updateDate: ''    // 수정날짜

    }

    let query = `mutation add거래량급증요청($input: Filter) {
      one : add거래량급증요청(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modify거래량급증요청(params) {

    let query = `mutation modify거래량급증요청($input: Filter) {
      one : modify거래량급증요청(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async remove거래량급증요청(params) {

    params = {
    }

    let query = `mutation remove거래량급증요청($input: Filter) {
      one : remove거래량급증요청(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async get거래량급증요청(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      one: get거래량급증요청(filter:$params) {
			일자
			순번
			종목코드
			종목명
			현재가
			전일대비기호
			전일대비
			등락률
			이전거래량
			현재거래량
			급증량
			급증률
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async get거래량급증요청List(params) {

    params = {

    }

    let query = `
    query ($params:Filter) {
      cnt: get거래량급증요청Cnt(filter:$params)   
      list: get거래량급증요청List(filter:$params) {
			일자
			순번
			종목코드
			종목명
			현재가
			전일대비기호
			전일대비
			등락률
			이전거래량
			현재거래량
			급증량
			급증률
			insertDate
			updateDate

      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new Graphql거래량급증요청Service();
