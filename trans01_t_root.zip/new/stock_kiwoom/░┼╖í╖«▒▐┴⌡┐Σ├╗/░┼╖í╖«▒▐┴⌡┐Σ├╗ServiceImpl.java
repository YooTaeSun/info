package .service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import .model.dto.DTO;
import .model.filter.Filter;
import .service.거래량급증요청Service;
import .service.dao.DAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 * 거래량급증요청 ServiceImpl
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.07.07.						최초작성
 * </pre>
 */
@Service("거래량급증요청Service")
public class 거래량급증요청ServiceImpl implements 거래량급증요청Service {

	private static final Logger logger = LoggerFactory.getLogger(거래량급증요청ServiceImpl.class);
	
	@Autowired
    private DAO DAO;
    
	/**
	 * 거래량급증요청 등록, 수정
     * @Method merge거래량급증요청
	 * @param Filter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean merge거래량급증요청(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.merge(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     * 거래량급증요청 여러 건 등록
     * @Method bulkInsert거래량급증요청
     * @param Filter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsert거래량급증요청(Filter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = DAO.bulkInsert(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 * 거래량급증요청 등록
     * @Method insert거래량급증요청
	 * @param Filter
     * @return 등록 여부
	 */
    @Override
    public Boolean insert거래량급증요청(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = DAO.insert(params);
        return (result > 0)? true:false;    	
    }

    /**
     * 거래량급증요청 수정
     * @Method update거래량급증요청 
     * @param Filter
     * @Method update거래량급증요청
     * @return 수정 여부
     */
    @Override
    public Boolean update거래량급증요청(Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = DAO.update(params);
        return (result > 0)? true:false;        
    }

    /**
     * 거래량급증요청 삭제
     * @Method delete거래량급증요청
     * @param Filter
     * @return 삭제 여부 
     */
    @Override
    public Boolean delete거래량급증요청(Filter params){
        int result = DAO.delete(params);
        return (result > 0)? true:false;
    }
    
    /**
     * 거래량급증요청 단건 조회
     * @Method select거래량급증요청
     * @param  Filter
     * @return 조회 건
     */
    @Override
    public DTO select거래량급증요청(Filter params){
        return DAO.select(params);
    }
    
    /**
     * 거래량급증요청 건수 조회
     * @Method select거래량급증요청Cnt
     * @param  Filter
     * @return 건수
     */
    @Override
    public int select거래량급증요청Cnt(Filter params){
        return DAO.selectCnt(params);
    }

    /**
     * 거래량급증요청 다건 조회
     * @Method select거래량급증요청List
     * @param  Filter
     * @return 조회 목록
     */
    @Override
    public List<DTO> select거래량급증요청List(Filter params){
        return DAO.selectList(params);
    }
}
