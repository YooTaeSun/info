package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import .model.dto.DTO;
import .model.filter.Filter;
import .service.거래량급증요청Service;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * 거래량급증요청 GraphQL Query
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.07.07.						최초작성
 * </pre>
 */
@Component
public class 거래량급증요청Query implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(거래량급증요청Mutation.class);
	
	@Autowired
	private 거래량급증요청Service 거래량급증요청Service;

    /**
     * 거래량급증요청 단건 조회
     * @Method get거래량급증요청
     * @param  Filter
     * @return 조회 건
     */
    public DTO get거래량급증요청(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 거래량급증요청Service.select거래량급증요청(params);
    }
    
    /**
     * 거래량급증요청 건수 조회
     * @Method get거래량급증요청Cnt
     * @param  Filter
     * @return 건수
     */
    public int get거래량급증요청Cnt(Filter params){
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 거래량급증요청Service.select거래량급증요청Cnt(params);
    }

    /**
     * 거래량급증요청 다건 조회
     * @Method get거래량급증요청List
     * @param  Filter
     * @return 조회 목록
     */
    public List<DTO> get거래량급증요청List(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return 거래량급증요청Service.select거래량급증요청List(params);
    }
}
