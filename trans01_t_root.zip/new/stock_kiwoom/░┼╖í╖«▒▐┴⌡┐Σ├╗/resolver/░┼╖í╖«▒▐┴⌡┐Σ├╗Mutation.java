package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import .model.filter.Filter;
import .service.거래량급증요청Service;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * 거래량급증요청 GraphQL Mutation
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.07.07.						최초작성
 * </pre>
 */
@Component
public class 거래량급증요청Mutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(거래량급증요청Mutation.class);
	
	@Autowired
	private 거래량급증요청Service 거래량급증요청Service;
	
	/**
	 * 거래량급증요청 등록
     * @Method add거래량급증요청
	 * @param Filter
	 */
    public Boolean add거래량급증요청(Filter params) {
    	try {
    		return 거래량급증요청Service.insert거래량급증요청(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * 거래량급증요청 수정
     * @Method modify거래량급증요청
	 * @param Filter
	 */
	public Boolean modify거래량급증요청(Filter params) {
		try {
			return 거래량급증요청Service.update거래량급증요청(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * 거래량급증요청 삭제
     * @Method remove거래량급증요청
	 * @param Filter
	 */
	public Boolean remove거래량급증요청(Filter params) {
		try {
			return 거래량급증요청Service.delete거래량급증요청(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
