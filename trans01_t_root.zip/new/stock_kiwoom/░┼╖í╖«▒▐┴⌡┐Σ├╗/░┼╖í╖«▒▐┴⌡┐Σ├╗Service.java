package .service;

import java.util.List;
import .model.dto.DTO;
import .model.filter.Filter;

/**
 * 거래량급증요청 서비스
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2024.07.07.						최초작성
 * </pre>
 */
public interface 거래량급증요청Service {

	/**
	 * 거래량급증요청 등록, 수정
     * @Method merge거래량급증요청
	 * @param Filter
	 */
    public Boolean merge거래량급증요청(Filter params);	
    
	/**
	 * 거래량급증요청 여러 건 등록
     * @Method bulkInsert거래량급증요청
	 * @param Filter
	 */
    public Boolean bulkInsert거래량급증요청(Filter params);	    
	
	/**
	 * 거래량급증요청 등록
     * @Method insert거래량급증요청
	 * @param Filter
	 */
    public Boolean insert거래량급증요청(Filter params);

    /**
     * 거래량급증요청 수정
     * @Method update거래량급증요청
     * @param Filter
     */
    public Boolean update거래량급증요청(Filter params);

    /**
     * 거래량급증요청 삭제
     * @Method delete거래량급증요청
     * @param Filter
     */
    public Boolean delete거래량급증요청(Filter params);
    
    /**
     * 거래량급증요청 단건 조회
     * @Method select거래량급증요청 
     * @param  Filter
     */
    public DTO select거래량급증요청(Filter params);    
    
    /**
     * 거래량급증요청 건수 조회
     * @Method select거래량급증요청Cnt
     * @param  Filter
     */
    public int select거래량급증요청Cnt(Filter params);
    
    /**
     * 거래량급증요청 다건 조회
     * @Method select거래량급증요청List
     * @param  Filter
     */
    public List<DTO> select거래량급증요청List(Filter params);

}
