package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import .model.filter.Filter;
import .service.Service;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 *  GraphQL Mutation
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.						최초작성
 * </pre>
 */
@Component
public class Mutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(Mutation.class);
	
	@Autowired
	private Service Service;
	
	/**
	 *  등록
     * @Method add
	 * @param Filter
	 */
    public Boolean add(Filter params) {
    	try {
    		return Service.insert(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 *  수정
     * @Method modify
	 * @param Filter
	 */
	public Boolean modify(Filter params) {
		try {
			return Service.update(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 *  삭제
     * @Method remove
	 * @param Filter
	 */
	public Boolean remove(Filter params) {
		try {
			return Service.delete(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
