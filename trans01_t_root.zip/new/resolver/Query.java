package .resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import .model.dto.DTO;
import .model.filter.Filter;
import .service.Service;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 *  GraphQL Query
 *
 * @author		
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   2025.06.15.						최초작성
 * </pre>
 */
@Component
public class Query implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(Mutation.class);
	
	@Autowired
	private Service Service;

    /**
     *  단건 조회
     * @Method get
     * @param  Filter
     * @return 조회 건
     */
    public DTO get(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return Service.select(params);
    }
    
    /**
     *  건수 조회
     * @Method getCnt
     * @param  Filter
     * @return 건수
     */
    public int getCnt(Filter params){
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return Service.selectCnt(params);
    }

    /**
     *  다건 조회
     * @Method getList
     * @param  Filter
     * @return 조회 목록
     */
    public List<DTO> getList(Filter params) {
    	params = Optional.ofNullable(params).orElseGet(Filter::new);
    	return Service.selectList(params);
    }
}
