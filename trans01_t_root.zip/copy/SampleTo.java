package #packageNm#.model;

import org.mapstruct.Mapper;

import #packageNm#.model.dto.#tableNewFirstUpperName#DTO;
import #packageNm#.model.entity.#tableNewFirstUpperName#;
import com.osstem.ows.cor.model.mapper.EntityMapper;

/**
 * #desc# JPA Mapper
 *
 * @author		#author#
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   #today#.		#author#				최초작성
 * </pre>
 */
@Mapper(componentModel = "spring")
public interface #tableNewFirstUpperName#Mapper extends EntityMapper<#tableNewFirstUpperName#DTO, #tableNewFirstUpperName#> {

    /**
     * DTO를 Entity 변경
     * @Method toEntity
     * @param #tableNewFirstUpperName#DTO
     */
	#tableNewFirstUpperName# toEntity(#tableNewFirstUpperName#DTO dto);

    /**
     * Entity를  DTO변경
     * @Method toDto
     * @param #tableNewFirstUpperName#
     */
	#tableNewFirstUpperName#DTO toDto(#tableNewFirstUpperName# entity);
}
