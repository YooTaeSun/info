package #packageNm#.service;

import java.util.List;
import #packageNm#.model.dto.#tableNewFirstUpperName#DTO;
import #packageNm#.model.filter.#tableNewFirstUpperName#Filter;

/**
 * #desc# 서비스
 *
 * @author		#author#
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   #today#.		#author#				최초작성
 * </pre>
 */
public interface #taskNameFirstUpperName#Service {

	/**
	 * #desc# 등록
     * @Method insert#taskNameFirstUpperName#
	 * @param #tableNewFirstUpperName#Filter
	 */
    public Boolean insert#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params);

    /**
     * #desc# 수정
     * @Method update#taskNameFirstUpperName#
     * @param #tableNewName#Filter
     */
    public Boolean update#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params);

    /**
     * #desc# 삭제
     * @Method delete#taskNameFirstUpperName#
     * @param #tableNewName#Filter
     */
    public Boolean delete#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params);
    
    /**
     * #desc# 단건 조회
     * @Method select#taskNameFirstUpperName# 
     * @param  #tableNewName#Filter
     */
    public #tableNewFirstUpperName#DTO select#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params);    
    
    /**
     * #desc# 건수 조회
     * @Method select#taskNameFirstUpperName#Cnt
     * @param  #tableNewName#Filter
     */
    public int select#taskNameFirstUpperName#Cnt(#tableNewFirstUpperName#Filter params);
    
    /**
     * #desc# 다건 조회
     * @Method select#taskNameFirstUpperName#List
     * @param  #tableNewName#Filter
     */
    public List<#tableNewFirstUpperName#DTO> select#taskNameFirstUpperName#List(#tableNewFirstUpperName#Filter params);

}
