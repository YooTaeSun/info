package com.osstem.ows.biz.sal.demo.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.osstem.ows.biz.sal.demo.model.dto.#tableNewFirstUpperName#DTO;
import com.osstem.ows.biz.sal.demo.model.dto.#taskNameFirstUpperName#SearchDTO;
import com.osstem.ows.biz.sal.demo.service.#taskNameFirstUpperName#Service;
import com.osstem.ows.cor.model.dto.SearchResult;
import com.osstem.ows.cor.web.OController;

/**
 * #desc# 컨트롤러
 * 
 * @author		#author#
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   #today#.		#author#				최초작성
 * </pre>
 */
@Controller
@RequestMapping(value="/sal/#taskName#")
public class #taskNameFirstUpperName#Controller extends OController {

	@Autowired
	private #taskNameFirstUpperName#Service #taskName#Service;
	
	/**
	 * #desc# 등록
	 *
	 * @param  #tableNewName#DTO
	 * @throws Exception
	 */
	@RequestMapping(value="/add#taskNameFirstUpperName#.json", method=RequestMethod.POST)
	@ResponseBody
	public void add#taskNameFirstUpperName#(@RequestBody #tableNewFirstUpperName#DTO #tableNewName#DTO) throws Exception {
		#taskName#Service.insert#taskNameFirstUpperName#(#tableNewName#DTO);
	}
	
	
	/**
	 * #desc# 수정
	 *
	 * @param  #tableNewName#DTO
	 * @throws Exception
	 */
	@RequestMapping(value="/modify#taskNameFirstUpperName#.json", method=RequestMethod.POST)
	@ResponseBody
	public void modify#taskNameFirstUpperName#(@RequestBody #tableNewFirstUpperName#DTO #tableNewName#DTO) throws Exception {
		#taskName#Service.update#taskNameFirstUpperName#(#tableNewName#DTO);
	}

	/**
	 * #desc# 삭제
	 *
	 * @param  #tableNewName#DTO
	 * @throws Exception
	 */
	@RequestMapping(value="/remove#taskNameFirstUpperName#.json", method=RequestMethod.DELETE)
	@ResponseBody
	public void remove#taskNameFirstUpperName#(@RequestBody #tableNewFirstUpperName#DTO #tableNewName#DTO) throws Exception {
		#taskName#Service.delete#taskNameFirstUpperName#(#tableNewName#DTO);
	}
	
    /**
     * #desc# 다건 조회(페이징)
     * @param  #taskName#SearchDTO
     * @return
     */
    @RequestMapping(value = "/get#taskNameFirstUpperName#List.json", method = RequestMethod.POST)
    @ResponseBody
    public SearchResult get#taskNameFirstUpperName#List(@RequestBody #taskNameFirstUpperName#SearchDTO searchDTO) throws Exception {
    	SearchResult result = new SearchResult();

    	List<#tableNewFirstUpperName#DTO> #taskNameFirstUpperName#List = #taskName#Service.select#taskNameFirstUpperName#(searchDTO);

        result.setTotal(#taskName#List.size());
        if(result.getTotal() != 0){
            result.setData(#taskName#List);
        }

        return result;
    }
    
}
