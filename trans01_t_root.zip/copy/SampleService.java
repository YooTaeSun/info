package web.townsi.com.work.tibero01.#camelTableName#.biz;

import java.util.HashMap;
import java.util.List;

import web.townsi.com.work.tibero01.#camelTableName#.vo.#camelTableFirstUpperName#VO;

public interface #camelTableFirstUpperName#Biz {

	public int selectCount(HashMap params);
	public List selectList(HashMap params);
	public #camelTableFirstUpperName#VO selectOne(HashMap params);

}
