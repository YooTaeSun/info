package web.townsi.com.work.tibero01.#camelTableName#.biz.impl;

import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.townsi.com.work.tibero01.#camelTableName#.biz.#camelTableFirstUpperName#Biz;
import web.townsi.com.work.tibero01.#camelTableName#.mapper.#camelTableFirstUpperName#Mapper;
import web.townsi.com.work.tibero01.#camelTableName#.vo.#camelTableFirstUpperName#VO;

@SuppressWarnings({"rawtypes","unchecked"})
@Service
public class #camelTableFirstUpperName#BizImpl implements #camelTableFirstUpperName#Biz {

	private static final Logger log = LoggerFactory.getLogger(#camelTableFirstUpperName#BizImpl.class);

	private Logger logger = LoggerFactory.getLogger(#camelTableFirstUpperName#BizImpl.class);

	@Autowired
	#camelTableFirstUpperName#Mapper #camelTableName#Mapper;

	@Override
	public int selectCount(HashMap params) {
		return (int) #camelTableName#Mapper.selectCount(params);
	}

	@Override
	public List selectList(HashMap params) {
		List<#camelTableFirstUpperName#VO> list = #camelTableName#Mapper.selectList(params);
		return list;
	}

	@Override
	public #camelTableFirstUpperName#VO selectOne(HashMap params) {
		return (#camelTableFirstUpperName#VO) #camelTableName#Mapper.selectOne(params);
	}
}
