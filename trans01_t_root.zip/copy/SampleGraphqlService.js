/**
 * GraphQl API
 *
 */

import axios from "./base.service.js";

class Graphql#taskNameFirstUpperName#Service {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql/sal/sales`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }

  async add#taskNameFirstUpperName#(params) {

    params = {
#typeSql#
    }

    let query = `mutation add#taskNameFirstUpperName#($input: #tableNewFirstUpperName#Filter) {
      one : add#taskNameFirstUpperName#(input: $input)
    }`;
    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async modify#taskNameFirstUpperName#(params) {

    let query = `mutation modify#taskNameFirstUpperName#($input: #tableNewFirstUpperName#Filter) {
      one : modify#taskNameFirstUpperName#(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async remove#taskNameFirstUpperName#(params) {

    params = {
    }

    let query = `mutation remove#taskNameFirstUpperName#($input: #tableNewFirstUpperName#Filter) {
      one : remove#taskNameFirstUpperName#(input: $input)
    }`;

    return await this.postGraphQl({ query, variables: {input:params} });
  }

  async get#taskNameFirstUpperName#(params) {

    params = {
#pkStr#
    }

    let query = `
    query ($params:#tableNewFirstUpperName#Filter) {
      one: get#taskNameFirstUpperName#(filter:$params) {
#typeSql2#
      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }

  async get#taskNameFirstUpperName#List(params) {

    params = {
#pkStr#
    }

    let query = `
    query ($params:#tableNewFirstUpperName#Filter) {
      cnt: get#taskNameFirstUpperName#Cnt(filter:$params)   
      list: get#taskNameFirstUpperName#List(filter:$params) {
#typeSql2#
      }
    }
    `;

    return await this.postGraphQl({ query, variables: {params} });
  }
}

export default new Graphql#taskNameFirstUpperName#Service();
