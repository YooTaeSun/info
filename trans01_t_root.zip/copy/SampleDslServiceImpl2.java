package #packageNm#.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import #packageNm#.service.impl.model.dto.MemberDTO;
import #packageNm#.service.impl.model.entity.Dept;
import #packageNm#.service.impl.model.entity.#taskNameFirstUpperName#;
import #packageNm#.service.impl.model.entity.QMember;
import #packageNm#.service.repo.DeptRepo;
import #packageNm#.service.repo.MemberRepo;
import com.querydsl.core.types.Projections;
import com.querydsl.jpa.impl.JPAQueryFactory;

@Service
public class #taskNameFirstUpperName#ServiceImpl implements #taskNameFirstUpperName#Service {

	private static final Logger logger = LoggerFactory.getLogger(#taskNameFirstUpperName#ServiceImpl.class);

	@Autowired
	@Qualifier("jpaQueryFactory")
	private JPAQueryFactory queryFactory;

	@Autowired
	private #taskNameFirstUpperName#Repo #taskName#Repo;
	
	@Autowired
	private #taskNameFirstUpperName#Mapper #taskName#Mapper;

	@Override
	@Transactional
	public MemberDTO saveMember(MemberDTO params) {

		logger.debug("params >> {}", params);

		#taskNameFirstUpperName# #taskName# = memberMapper.toEntity(params);

		Dept dept = new Dept();
		dept.setDeptId(#taskName#.getDeptId());
		#taskName#.setDept(dept);
		memberRepo.save(#taskName#);

//		Optional<#taskNameFirstUpperName#> opInsertMember =  memberRepo.findById(#taskName#.getId());
		return memberMapper.toDto(#taskName#);
	}
	
	@Override
	@Transactional
	public Boolean updateMember(MemberDTO params) {

		logger.debug(" updateMember params >> {}", params);

		if(params.getId() == null) {
			throw new RuntimeException("no Id");
		}

		Optional<#taskNameFirstUpperName#> opMember = memberRepo.findById(params.getId());
		#taskNameFirstUpperName# updateMember = null;
		if(opMember.isPresent()) {
			updateMember = opMember.get();

#update#			
			
			memberRepo.save(updateMember);
			
		}
		return memberMapper.toDto(updateMember);
	}
	
	@Override
	@Transactional
	public Boolean deleteMember(MemberDTO params) {

		if(params.getId() == null) {
			throw new RuntimeException("no Id");
		}
		
		#taskNameFirstUpperName# #taskName# = memberMapper.toEntity(params);
		memberRepo.delete(#taskName#);
	}
	
	
    public #tableNewFirstUpperName#DTO getQuery#taskNameFirstUpperName#(#tableNewFirstUpperName#DTO params) {

    	var q#taskNameFirstUpperName# = Q#taskNameFirstUpperName#.#taskName#;
    	#tableNewFirstUpperName#DTO sel#taskNameFirstUpperName#= queryFactory.select(
    			Projections.fields(#tableNewFirstUpperName#DTO.class
#selectCols2#
    			)).from(q#taskNameFirstUpperName#)
    			.where(#taskNameFirstUpperName#Pred.where(params))
    			.fetchOne();

        return sel#taskNameFirstUpperName#;
    }

	public List<#tableNewFirstUpperName#DTO> getQuery#taskNameFirstUpperName#List(#tableNewFirstUpperName#DTO params) {

    	var q#taskNameFirstUpperName# = Q#taskNameFirstUpperName#.#taskName#;
    	List<#tableNewFirstUpperName#DTO> #taskName#List= queryFactory.select(
    			Projections.fields(#tableNewFirstUpperName#DTO.class
#selectCols#
    			)).from(q#taskNameFirstUpperName#)
    			.where(#taskNameFirstUpperName#Pred.where(params))
    			.fetch();

        return #taskName#List;
	}

	@Override
	public #tableNewFirstUpperName#DTO get#taskNameFirstUpperName#(#tableNewFirstUpperName#DTO params) {
		#tableNewFirstUpperName#DTO  #taskName# = this.getQuery#taskNameFirstUpperName#(params);
		return #taskName#;
	}

	@Override
	public List<#tableNewFirstUpperName#DTO> get#taskNameFirstUpperName#List(#tableNewFirstUpperName#DTO params) {
		return this.get#taskNameFirstUpperName#List(params);
	}

	@Override
	@Transactional
	public #tableNewFirstUpperName#DTO create#taskNameFirstUpperName#(#tableNewFirstUpperName#DTO params) {

		#taskNameFirstUpperName# #taskName# = #taskName#Mapper.toEntity(params);
		#taskName#Repo.save(#taskName#);

		return true;
	}

	@Override
	@Transactional
	public #tableNewFirstUpperName#DTO update#taskNameFirstUpperName#(#tableNewFirstUpperName#DTO params) {
		#taskNameFirstUpperName# #taskName# = #taskName#Mapper.toEntity(params);
		#taskName#Repo.save(#taskName#);

//		var q#taskNameFirstUpperName# = Q#taskNameFirstUpperName#.#taskName#;
//		long result = queryFactory.update(q#taskNameFirstUpperName#)
//			.set(q#taskNameFirstUpperName#.name, params.getName())
//			.where(q#taskNameFirstUpperName#.id.eq(params.getId()))
//			.execute();

		return true;
	}

	@Override
	@Transactional
	public Boolean delete#taskNameFirstUpperName#(#tableNewFirstUpperName#DTO params) {
		#taskNameFirstUpperName# #taskName# = #taskName#Mapper.toEntity(params);
		#taskName#Repo.delete(#taskName#);
		return true;
	}

}
