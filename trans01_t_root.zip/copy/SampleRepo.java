package #packageNm#.service.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import #packageNm#.model.entity.#tableNewFirstUpperName#;

/**
 * #desc# JPA Repo
 *
 * @author		#author#
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   #today#.		#author#				최초작성
 * </pre>
 */
@Repository
public interface #tableNewFirstUpperName#Repo extends JpaRepository<#tableNewFirstUpperName#, #pkType#> {
	
#where#

#delete#

}