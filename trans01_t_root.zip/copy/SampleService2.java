package web.townsi.com.work.tibero02.#camelTableName#.biz;

import java.util.HashMap;
import java.util.List;

import web.townsi.com.work.tibero02.#camelTableName#.vo.#camelTableFirstUpperName#VO;

public interface #camelTableFirstUpperName#Biz {

	public int selectCount(HashMap params);
	public List selectList(HashMap params);
	public List selectAllList(HashMap params);
	public #camelTableFirstUpperName#VO selectOne(HashMap params);
	public int bulkInsert(HashMap params);
	public int insert(HashMap params);
	public int update(HashMap params);
	public int delete(HashMap params);

}
