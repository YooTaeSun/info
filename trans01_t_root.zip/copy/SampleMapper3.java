package #packageNm#.service.dao;

import java.util.List;

import com.osstem.ows.biz.cfg.datasource.OwsMapper;
import #packageNm#.model.dto.#tableNewFirstUpperName#DTO;
import #packageNm#.model.filter.#tableNewFirstUpperName#Filter;

/**
 * #desc# DAO
 *
 * @author		#author#
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   #today#.		#author#				최초작성
 * </pre>
 */
@OwsMapper
public interface #tableNewFirstUpperName#DAO {

	/**
     * #desc# 등록
     * @Method insert#taskNameFirstUpperName#
     * @param #tableNewFirstUpperName#Filter
     * @return 등록된 건수
     */	
	public int insert#tableNewFirstUpperName#(#tableNewFirstUpperName#Filter params);
	
    /**
     * #desc# 수정
     * @Method update#taskNameFirstUpperName#
     * @param #tableNewFirstUpperName#Filter
     * @return 수정된 건수
     */	
	public int update#tableNewFirstUpperName#(#tableNewFirstUpperName#Filter params);
	
    /**
     * #desc# 삭제 
     * @Method delete#taskNameFirstUpperName#
     * @param #tableNewFirstUpperName#Filter
     * @return 삭제된 건수
     */	
	public int delete#tableNewFirstUpperName#(#tableNewFirstUpperName#Filter params);
 
    /**
     * #desc# 단건 조회
     *
     * @param #tableNewFirstUpperName#Filter
     * @return 조회 건
     */	    
	public #tableNewFirstUpperName#DTO select#tableNewFirstUpperName#(#tableNewFirstUpperName#Filter params);

    /**
     * #desc# 건수 조회
     * @Method select#taskNameFirstUpperName#Cnt
     * @param #tableNewFirstUpperName#Filter
     * @return 건수
     */	
    int select#tableNewFirstUpperName#Cnt(#tableNewFirstUpperName#Filter params);
    
    /**
     * #desc# 다건 조회
     * @Method select#taskNameFirstUpperName#List
     * @param #tableNewFirstUpperName#Filter 
     * @return 조회 목록
     */	
	public List<#tableNewFirstUpperName#DTO> select#tableNewFirstUpperName#List(#tableNewFirstUpperName#Filter params);
}