package #packageNm#.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.osstem.ows.biz.loe.exception.CustomGraphQLException;
import #packageNm#.model.filter.#tableNewFirstUpperName#Filter;
import #packageNm#.service.#taskNameFirstUpperName#Service;

import graphql.kickstart.tools.GraphQLMutationResolver;

/**
 * #desc# GraphQL Mutation
 *
 * @author		#author#
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   #today#.		#author#				최초작성
 * </pre>
 */
@Component
public class #taskNameFirstUpperName#Mutation implements GraphQLMutationResolver {

	private static final Logger logger = LoggerFactory.getLogger(#taskNameFirstUpperName#Mutation.class);
	
	@Autowired
	private #taskNameFirstUpperName#Service #taskName#Service;
	
	/**
	 * #desc# 등록
     * @Method add#taskNameFirstUpperName#
	 * @param #tableNewFirstUpperName#Filter
	 */
    public Boolean add#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params) {
    	try {
    		return #taskName#Service.insert#taskNameFirstUpperName#(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
    }

	/**
	 * #desc# 수정
     * @Method modify#taskNameFirstUpperName#
	 * @param #tableNewFirstUpperName#Filter
	 */
	public Boolean modify#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params) {
		try {
			return #taskName#Service.update#taskNameFirstUpperName#(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

	/**
	 * #desc# 삭제
     * @Method remove#taskNameFirstUpperName#
	 * @param #tableNewFirstUpperName#Filter
	 */
	public Boolean remove#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params) {
		try {
			return #taskName#Service.delete#taskNameFirstUpperName#(params);
		} catch (Exception e) {
			logger.error("{}", e);
			throw new CustomGraphQLException(20000, e.getMessage());
		}
	}

}
