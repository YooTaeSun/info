package com.osstem.ows.biz.loe.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.osstem.ows.biz.loe.model.dto.LogisticsProcessDTO;
import com.osstem.ows.biz.loe.model.entity.QLogisticsProcess;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.Projections;
import com.querydsl.jpa.impl.JPAQueryFactory;

@Service
public class LogisticsProcessServiceImpl2 {

	@Autowired
	private JPAQueryFactory queryFactory;

	public void select() {
		var logisticsProcess = QLogisticsProcess.logisticsProcess;

		String supplierPickingPersonInChargeId = "";
		
		BooleanBuilder whereSelect = new BooleanBuilder();
		if(!supplierPickingPersonInChargeId.isEmpty()) {
			whereSelect.and(logisticsProcess.supplierPickingPersonInChargeId.eq(""));
		}

		queryFactory.select(
				Projections.fields(
					LogisticsProcessDTO.class, 
					logisticsProcess.logisticsProcessId,
					logisticsProcess.programId, 
					logisticsProcess.firstRegistererId, 
					logisticsProcess.lastUpdaterId,
					logisticsProcess.lastUpdateDate, 
					logisticsProcess.logisticsOrderDetailId
				)
		).from(logisticsProcess).where(whereSelect).fetch();
	}

	public void insert() {
		var logisticsProcess = QLogisticsProcess.logisticsProcess; // 0003

	}

	public void update() {
		var logisticsProcess = QLogisticsProcess.logisticsProcess; // 0003

		BooleanBuilder whereUpdate = new BooleanBuilder();
		whereUpdate.and(logisticsProcess.logisticsProcessId.eq(1L));

		List<Path<?>> paths = new ArrayList<Path<?>>();
		List values = new ArrayList<>();

		paths.add(logisticsProcess.supplierPickingQuantity);
		values.add(0);
		paths.add(logisticsProcess.supplierPickingNoShipmentQuantity);
		values.add(1);
		paths.add(logisticsProcess.supplierPickingCompleteDate);
		values.add(new Timestamp(System.currentTimeMillis()));

		var updateQuery = queryFactory.update(logisticsProcess).set(paths, values).where(whereUpdate);

	}

	public void delete() {
		var logisticsProcess = QLogisticsProcess.logisticsProcess; // 0003

		BooleanBuilder whereDelete = new BooleanBuilder();
		whereDelete.and(logisticsProcess.logisticsProcessId.eq(1L));

		var deleteQuery = queryFactory.delete(logisticsProcess).where(whereDelete).execute();

	}

}