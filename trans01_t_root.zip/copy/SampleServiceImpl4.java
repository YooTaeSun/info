package #packageNm#.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.osstem.ows.biz.login.admin.domain.vo.UsersInfoVo;
import #packageNm#.model.dto.#tableNewFirstUpperName#DTO;
import #packageNm#.model.filter.#tableNewFirstUpperName#Filter;
import #packageNm#.service.#taskNameFirstUpperName#Service;
import #packageNm#.service.dao.#tableNewFirstUpperName#DAO;
import com.osstem.ows.biz.sec.util.SecurityUtils;

/** 
 * #desc# ServiceImpl
 *
 * @author		#author#
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   #today#.		#author#				최초작성
 * </pre>
 */
@Service("#taskName#Service")
public class #taskNameFirstUpperName#ServiceImpl implements #taskNameFirstUpperName#Service {

	private static final Logger logger = LoggerFactory.getLogger(#taskNameFirstUpperName#ServiceImpl.class);
	
	@Autowired
    private #tableNewFirstUpperName#DAO #tableNewName#DAO;
    
	/**
	 * #desc# 등록, 수정
     * @Method merge#taskNameFirstUpperName#
	 * @param #tableNewFirstUpperName#Filter
     * @return 등록,수정 여부
	 */
    @Override
    public Boolean merge#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = #tableNewName#DAO.merge#tableNewFirstUpperName#(params);
        return (result > 0)? true:false;    	
    }
    
    /**
     * #desc# 여러 건 등록
     * @Method bulkInsert#taskNameFirstUpperName#
     * @param #tableNewFirstUpperName#Filter
     * @return 등록,수정 여부
     */
    @Override
    public Boolean bulkInsert#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params){
    	
//    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
//    	String userId = userInfo.getUserId();
//    	
//    	params.setFrstRegrId(userId);
//    	params.setLastUpdrId(userId);    	
    	
    	int result = #tableNewName#DAO.bulkInsert#tableNewFirstUpperName#(params);
    	return (result > 0)? true:false;    	
    }	
	
	/**
	 * #desc# 등록
     * @Method insert#taskNameFirstUpperName#
	 * @param #tableNewFirstUpperName#Filter
     * @return 등록 여부
	 */
    @Override
    public Boolean insert#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);    	
    	
        int result = #tableNewName#DAO.insert#tableNewFirstUpperName#(params);
        return (result > 0)? true:false;    	
    }

    /**
     * #desc# 수정
     * @Method update#taskNameFirstUpperName# 
     * @param #tableNewName#Filter
     * @Method update#taskNameFirstUpperName#
     * @return 수정 여부
     */
    @Override
    public Boolean update#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params){
    	
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);  	
    	
        int result = #tableNewName#DAO.update#tableNewFirstUpperName#(params);
        return (result > 0)? true:false;        
    }

    /**
     * #desc# 삭제
     * @Method delete#taskNameFirstUpperName#
     * @param #tableNewName#Filter
     * @return 삭제 여부 
     */
    @Override
    public Boolean delete#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params){
        int result = #tableNewName#DAO.delete#tableNewFirstUpperName#(params);
        return (result > 0)? true:false;
    }
    
    /**
     * #desc# 단건 조회
     * @Method select#taskNameFirstUpperName#
     * @param  #tableNewName#Filter
     * @return 조회 건
     */
    @Override
    public #tableNewFirstUpperName#DTO select#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params){
        return #tableNewName#DAO.select#tableNewFirstUpperName#(params);
    }
    
    /**
     * #desc# 건수 조회
     * @Method select#taskNameFirstUpperName#Cnt
     * @param  #tableNewName#Filter
     * @return 건수
     */
    @Override
    public int select#taskNameFirstUpperName#Cnt(#tableNewFirstUpperName#Filter params){
        return #tableNewName#DAO.select#tableNewFirstUpperName#Cnt(params);
    }

    /**
     * #desc# 다건 조회
     * @Method select#taskNameFirstUpperName#List
     * @param  #tableNewName#Filter
     * @return 조회 목록
     */
    @Override
    public List<#tableNewFirstUpperName#DTO> select#taskNameFirstUpperName#List(#tableNewFirstUpperName#Filter params){
        return #tableNewName#DAO.select#tableNewFirstUpperName#List(params);
    }
}
