package #packageNm#.service.repo.pred;

import org.apache.commons.lang3.StringUtils;

import #packageNm#.model.entity.Q#tableNewFirstUpperName#;
import #packageNm#.model.filter.#tableNewFirstUpperName#Filter;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.Predicate;

/**
 * #desc# JPA Pred
 *
 * @author		#author#
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   #today#.		#author#				최초작성
 * </pre>
 */
public class #tableNewFirstUpperName#Pred {

	public static Predicate where(#tableNewFirstUpperName#Filter params) {
 
		Q#tableNewFirstUpperName# q#tableNewFirstUpperName# = Q#tableNewFirstUpperName#.#tableNewName#;

		BooleanBuilder builder = new BooleanBuilder();
		
#where#
		return builder;
	}
}
