package #packageNm#.model.filter;

import com.osstem.ows.biz.cmm.model.filter.PageFilter;
import #packageNm#.model.dto.#tableNewFirstUpperName#DTO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class #tableNewFirstUpperName#Filter extends #tableNewFirstUpperName#DTO {
	
	/**
	 * pageFilter 객체
	 */
	@ApiModelProperty(value = "pageFilter: pageFilter 객체")
	private PageFilter pageFilter;
}