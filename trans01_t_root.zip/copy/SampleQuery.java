package #packageNm#.resolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import #packageNm#.model.dto.#tableNewFirstUpperName#DTO;
import #packageNm#.model.filter.#tableNewFirstUpperName#Filter;
import #packageNm#.service.#taskNameFirstUpperName#Service;

import graphql.kickstart.tools.GraphQLQueryResolver;

/**
 * #desc# GraphQL Query
 *
 * @author		#author#
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   #today#.		#author#				최초작성
 * </pre>
 */
@Component
public class #taskNameFirstUpperName#Query implements GraphQLQueryResolver {

	private static final Logger logger = LoggerFactory.getLogger(#taskNameFirstUpperName#Mutation.class);
	
	@Autowired
	private #taskNameFirstUpperName#Service #taskName#Service;

    /**
     * #desc# 단건 조회
     * @Method get#taskNameFirstUpperName#
     * @param  #tableNewName#Filter
     * @return 조회 건
     */
    public #tableNewFirstUpperName#DTO get#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params) {
    	params = Optional.ofNullable(params).orElseGet(#tableNewFirstUpperName#Filter::new);
    	return #taskName#Service.select#taskNameFirstUpperName#(params);
    }
    
    /**
     * #desc# 건수 조회
     * @Method get#taskNameFirstUpperName#Cnt
     * @param  #tableNewName#Filter
     * @return 건수
     */
    public int get#taskNameFirstUpperName#Cnt(#tableNewFirstUpperName#Filter params){
    	params = Optional.ofNullable(params).orElseGet(#tableNewFirstUpperName#Filter::new);
    	return #taskName#Service.select#taskNameFirstUpperName#Cnt(params);
    }

    /**
     * #desc# 다건 조회
     * @Method get#taskNameFirstUpperName#List
     * @param  #tableNewName#Filter
     * @return 조회 목록
     */
    public List<#tableNewFirstUpperName#DTO> get#taskNameFirstUpperName#List(#tableNewFirstUpperName#Filter params) {
    	params = Optional.ofNullable(params).orElseGet(#tableNewFirstUpperName#Filter::new);
    	return #taskName#Service.select#taskNameFirstUpperName#List(params);
    }
}
