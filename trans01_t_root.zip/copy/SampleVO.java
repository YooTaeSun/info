package web.townsi.com.work.tibero01.#camelTableName#.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class #camelTableFirstUpperName#VO {

#dtoContent#
}
