package com.skt.poc.biz.component.#group#.model.dto;

import com.skt.poc.common.base.BaseDTO;
import lombok.*;

@Builder @AllArgsConstructor @NoArgsConstructor
@Getter @Setter @ToString
public class #camelTableFirstUpperName#DTO extends BaseDTO {

#dtoContent#
/* 검색 영역( Search AND 조건 ) parameters : search + 컬럼명(Camel) */
#searchDtoContent#
	public #camelTableFirstUpperName#DTO(#conParam#) {
#conParamBody#
	}
}
