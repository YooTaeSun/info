package web.townsi.com.work.tibero02.#camelTableName#.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import web.townsi.com.work.tibero02.#camelTableName#.biz.#camelTableFirstUpperName#Biz;

@Controller
@RequestMapping("/tibero02/#camelTableName#")
public class #camelTableFirstUpperName#Controller {

	private static final Logger log = LoggerFactory.getLogger(#camelTableFirstUpperName#Controller.class);

    @Autowired
    private #camelTableFirstUpperName#Biz #camelTableName#Biz;

}
