package #packageNm#.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import #packageNm#.model.#tableNewFirstUpperName#Mapper;
import #packageNm#.model.dto.#tableNewFirstUpperName#DTO;
import #packageNm#.model.entity.Q#tableNewFirstUpperName#;
import #packageNm#.model.entity.#tableNewFirstUpperName#;
import #packageNm#.model.filter.#tableNewFirstUpperName#Filter;
import #packageNm#.service.#taskNameFirstUpperName#Service;
import #packageNm#.service.repo.#tableNewFirstUpperName#Repo;
import #packageNm#.service.repo.pred.#tableNewFirstUpperName#Pred;
import com.querydsl.core.types.Projections;
import com.querydsl.jpa.impl.JPAQueryFactory;

/**
 * #desc# ServiceImpl
 *
 * @author		#author# 
 * @version		1.0
 * @Modification
 * <pre>
 *   	since			author         		description
 *  --------------  -----------------  -------------------------------------------------------
 *   #today#.		#author#				최초작성
 * </pre>
 */
@Service
public class #taskNameFirstUpperName#ServiceImpl implements #taskNameFirstUpperName#Service {

	private static final Logger logger = LoggerFactory.getLogger(#taskNameFirstUpperName#ServiceImpl.class);

	@Autowired
	@Qualifier("jpaQueryFactory")
	private JPAQueryFactory queryFactory;

	@Autowired
	private #tableNewFirstUpperName#Repo #tableNewName#Repo;

	@Autowired
	private #tableNewFirstUpperName#Mapper #tableNewName#Mapper;

	/**
	 * #desc# 등록
     * @Method insert#taskNameFirstUpperName#
	 * @param #tableNewFirstUpperName#Filter
     * @return 등록 건
	 */	
	@Override
	@Transactional
	public Boolean insert#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params) {

    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setFrstRegrId(userId);
		params.setLastUpdrId(userId);		
		
		#tableNewFirstUpperName# #tableNewName# = #tableNewName#Mapper.toEntity(params);
		#tableNewName#Repo.save(#tableNewName#);
		
		return true;
	}

    /**
     * #desc# 수정
     * @Method update#taskNameFirstUpperName# 
     * @param #tableNewName#Filter
     * @Method update#taskNameFirstUpperName#
     * @return 수정 건
     */
	@Override
	@Transactional
	public Boolean update#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params) {

		if(#pkStr#) {
			throw new RuntimeException("no pk");
		}
		
    	UsersInfoVo userInfo = SecurityUtils.getCurrentUserInfo();
		String userId = userInfo.getUserId();

		params.setLastUpdrId(userId);

		List<#tableNewFirstUpperName#> list = #tableNewName#Repo.findBy#pkMehod#(#pkGet#);
		#tableNewFirstUpperName# update#tableNewFirstUpperName# = null;
		if(ObjectUtils.isNotEmpty(list) && list.size() == 1) {

			update#tableNewFirstUpperName# = list.get(0);

#update#
			#tableNewName#Repo.save(update#tableNewFirstUpperName#);
		}
		return (update#tableNewFirstUpperName# != null)? true:false;
	}

    /**
     * #desc# 삭제
     * @Method delete#taskNameFirstUpperName#
     * @param #tableNewName#Filter
     * @return 삭제 건 
     */
	@Override
	@Transactional
	public Boolean delete#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params) {

		if(#pkStr#) {
			throw new RuntimeException("no pk");
		}

		#tableNewFirstUpperName# #tableNewName# = #tableNewName#Mapper.toEntity(params);
		//Erase only with pk.
		List<#tableNewFirstUpperName#> list = #tableNewName#Repo.deleteBy#pkMehod#(#pkGet#);
		return ObjectUtils.isNotEmpty(list)? true:false;
	}

    /**
     * #desc# 단건 조회
     * @Method select#taskNameFirstUpperName#
     * @param  #tableNewName#Filter
     * @return 조회 건
     */
	@Override
    public #tableNewFirstUpperName#DTO select#taskNameFirstUpperName#(#tableNewFirstUpperName#Filter params) {

    	var q#tableNewFirstUpperName# = Q#tableNewFirstUpperName#.#tableNewName#;
    	#tableNewFirstUpperName#DTO one= queryFactory
    			.select(
	    			Projections.fields(#tableNewFirstUpperName#DTO.class
#selectCols#
	    			))
    			.from(q#tableNewFirstUpperName#)
    			.where(#tableNewFirstUpperName#Pred.where(params))
    			.fetchOne();

        return one;
    }

    /**
     * #desc# 건수 조회
     * @Method select#taskNameFirstUpperName#Cnt
     * @param  #tableNewName#Filter
     * @return 건수
     */
    @Override
    public int select#taskNameFirstUpperName#Cnt(#tableNewFirstUpperName#Filter params){
    	return -1;
    }	
	
    /**
     * #desc# 다건 조회
     * @Method select#taskNameFirstUpperName#List
     * @param  #tableNewName#Filter
     * @return 조회 목록
     */
    @Override
	public List<#tableNewFirstUpperName#DTO> select#taskNameFirstUpperName#List(#tableNewFirstUpperName#Filter params) {

    	var q#tableNewFirstUpperName# = Q#tableNewFirstUpperName#.#tableNewName#;
    	List<#tableNewFirstUpperName#DTO> list= queryFactory
    			.select(
	    			Projections.fields(#tableNewFirstUpperName#DTO.class
#selectCols2#
	    			))
    			.from(q#tableNewFirstUpperName#)
    			.where(#tableNewFirstUpperName#Pred.where(params))
    			.fetch();

        return list;
	}

    /**
     * #desc# 다건 조회
     * @Method select#taskNameFirstUpperName#2
     * @param  #tableNewName#Filter
     * @return 조회 건
     */    
	@Deprecated
	public #tableNewFirstUpperName#DTO select#taskNameFirstUpperName#2(#tableNewFirstUpperName#Filter params) {

		List<#tableNewFirstUpperName#> list = #tableNewName#Repo.findBy#pkMehod#(#pkGet#);
		#tableNewFirstUpperName#DTO #tableNewName#DTO = null;

		if(ObjectUtils.isNotEmpty(list) && list.size() == 1) {
			#tableNewName#DTO = #tableNewName#Mapper.toDto(list.get(0));
		}
		return #tableNewName#DTO;
	}

    /**
     * #desc# 다건 조회
     * @Method select#taskNameFirstUpperName#List2
     * @param  #tableNewName#Filter
     * @return 조회 목록
     */	
	@Deprecated
	public List<#tableNewFirstUpperName#DTO> select#taskNameFirstUpperName#List2(#tableNewFirstUpperName#Filter params) {
		List<#tableNewFirstUpperName#> list = #tableNewName#Repo.findAll();
		List<#tableNewFirstUpperName#DTO> listDto = list.stream().map(#tableNewName#Mapper::toDto).collect(Collectors.toList());
		return listDto;
	}

}
