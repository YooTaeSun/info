/**
 * GraphQl API
 *
 * @since 2021.02.04
 */

import axios from "./base.service.js";

class GraphqlService {

  async postGraphQl(body) {
    try {
      let result = await axios.post(`graphql`, body);
      return result;
    } catch (error) {
      console.log(error);
      return error;
    }
  }
  
  async get#taskNameFirstUpperName#(params) {
    // let params = {
    //   id : 3,
    //   loginId : "townsi",
    //   password : "1234",
    //   name: "이봉구",
    //   nameList : ['ts','aa'],
    //   memeberList : [
    //     {loginId: 4,name: "이봉팔"},
    //     {loginId: 5,name: "이봉팔2"}
    //   ]
    // }

    let typeObj = this.getGraphQlType(params, {memeberList:"[#tableNewFirstUpperName#Filter2]", nameList:"[String]"});
    let queryType = typeObj['queryType'];
    let objType = typeObj['objType'];
    let query = `query (%s0) {
      #taskName#: get#taskNameFirstUpperName#(filter: %s1) {
#typeSql#
      }
      #taskName#List: get#taskNameFirstUpperName#List(filter: %s1) {
#typeSql#
      }
    }`
    .replace("%s0", queryType).replace(/%s1/gi, objType);
    console.log(query);
    return await this.postGraphQl({ query, variables: params });
  }  
}

export default new GraphqlService();
