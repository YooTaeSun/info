package web.townsi.com.work.tibero02.#camelTableName#.mapper;

import java.lang.invoke.MethodHandles;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import web.townsi.com.work.tibero.ddl.mapper.MapperTibero;

@Repository
public class #camelTableFirstUpperName#Mapper extends MapperTibero {

	private Logger logger = LoggerFactory.getLogger(#camelTableFirstUpperName#Mapper.class);

	private final static String NAMESPACE = MethodHandles.lookup().lookupClass().getCanonicalName() + ".";

	public Integer selectCount(Object params) {
		return sqlSession.selectOne(NAMESPACE + "selectCount", params);
	}

	public List selectList(Object params) {
		return sqlSession.selectList(NAMESPACE + "selectList", params);
	}

	public List selectAllList(Object params) {
		return sqlSession.selectOne(NAMESPACE + "selectAllList", params);
	}

	public Object selectOne(Object params) {
		return sqlSession.selectOne(NAMESPACE + "selectAllList", params);
	}

	public Integer bulkInsert(Object params) {
		int resultInt =  sqlSessionBatch.insert(NAMESPACE + "bulkInsert", params);
//		sqlSession.flushStatements();
//		sqlSessionBatch.close();
		return resultInt;
	}

	public Integer insert(Object params) {
		return sqlSession.insert(NAMESPACE + "insert", params);
	}

	public Integer update(Object params) {
		return sqlSession.update(NAMESPACE + "update", params);
	}

	public Integer delete(Object params) {
		return sqlSession.delete(NAMESPACE + "delete", params);
	}
}